import ReportWriteFormCategoryMenu from '@/components/aviation/report/ReportWriteFormCategoryMenu';
import ReportWriteFormMenu from '@/components/aviation/report/ReportWriteFormMenu';

import ReportASREditForm from '@/components/aviation/report/edit/ReportASREditForm';
import ReportCSREditFormInspection from '@/components/aviation/report/edit/csr/ReportCSREditFormInspection';
import ReportCSREditFormPaxDeplane from '@/components/aviation/report/edit/csr/ReportCSREditFormPaxDeplane';
import ReportCSREditFormPaxPatient from '@/components/aviation/report/edit/csr/ReportCSREditFormPaxPatient';
import ReportCSREditFormPaxInjury from '@/components/aviation/report/edit/csr/ReportCSREditFormPaxInjury';
import ReportCSREditFormCrewPatient from '@/components/aviation/report/edit/csr/ReportCSREditFormCrewPatient';
import ReportCSREditFormCrewInjury from '@/components/aviation/report/edit/csr/ReportCSREditFormCrewInjury';
import ReportCSREditFormUnlawful from '@/components/aviation/report/edit/csr/ReportCSREditFormUnlawful';
import ReportCSREditFormSmoking from '@/components/aviation/report/edit/csr/ReportCSREditFormSmoking';
import ReportCSREditFormMaintenance from '@/components/aviation/report/edit/csr/ReportCSREditFormMaintenance';
import ReportCSREditFormOther from '@/components/aviation/report/edit/csr/ReportCSREditFormOther';

import ReportGSREditFormDamage from '@/components/aviation/report/edit/gsr/ReportGSREditFormDamage';
import ReportGSREditFormInspection from '@/components/aviation/report/edit/gsr/ReportGSREditFormInspection';
import ReportGSREditFormPaxIrr from '@/components/aviation/report/edit/gsr/ReportGSREditFormPaxIrr';
import ReportGSREditFormCargoIrr from '@/components/aviation/report/edit/gsr/ReportGSREditFormCargoIrr';

import ReportMSREditFormAOC from '@/components/aviation/report/edit/msr/ReportMSREditFormAOC';
import ReportMSREditFormAMO from '@/components/aviation/report/edit/msr/ReportMSREditFormAMO';

import ReportDSREditForm from '@/components/aviation/report/edit/ReportDSREditForm';
import ReportFOQAEditForm from '@/components/aviation/report/edit/ReportFOQAEditForm';
import ReportHZREditForm from '@/components/aviation/report/edit/ReportHZREditForm';
import ReportRSREditForm from '@/components/aviation/report/edit/ReportRSREditForm';

const ReportEditFormRouteInfo: any = {};

// 보고서작성(대분류) : ReportWriteFormMenu : report-form
// 보고서작성(중분류) : ReportWriteFormCategoryMenu : report-form/:reportKind
// ASR : ReportASREditForm : report-form/ASR/:detail
// CSR > 수검 :ReportCSREditFormInspection : report-form/CSR/inspection/:detailId
// CSR > 승객하기 :ReportCSREditFormPaxDeplane : report-form/CSR/paxdeplane/:detailId
// CSR > 승객환자 :ReportCSREditFormPaxPatient : report-form/CSR/paxpatient/:detailId
// CSR > 승객부상 :ReportCSREditFormPaxInjury : report-form/CSR/paxinjury/:detailId
// CSR > 승무원환자 :ReportCSREditFormCrewPatient : report-form/CSR/crewpatient/:detailId
// CSR > 승무원부상 :ReportCSREditFormCrewInjury : report-form/CSR/crewinjury/:detailId
// CSR > 불법방해행위 :ReportCSREditFormUnlawful : report-form/CSR/unlawful/:detailId
// CSR > 흡연 :ReportCSREditFormSmoking : report-form/CSR/smoking/:detailId
// CSR > 설비장비 :ReportCSREditFormMaintenance : report-form/CSR/maintenance/:detailId
// CSR > 기타 보고항목 :ReportCSREditFormOther : report-form/CSR/other/:detail
// MSR > AOC : ReportMSREditFormAOC : report-form/MSR/aoc/:detailId
// MSR > AMO : ReportMSREditFormAMO : report-form/MSR/amo/:detail

// GSR > Damage : ReportGSREditFormDamage : report-form/GSR/damage/:detailId

// GSR > Inspection : ReportGSREditFormInspection : report-form/GSR/inspection/:detailId
// GSR > PAX Handling IRR : ReportGSREditFormPaxIrr : report-form/GSR/paxirr/:detailId
// GSR > Cargo Handling IRR : ReportGSREditFormCargoIrr : report-form/GSR/cargoirr/:detail

// DSR : ReportDSREditForm : report-form/DSR/:detailId
// RSR : ReportRSREditForm : report-form/RSR/:detailId
// HZR : ReportHZREditForm : report-form/HZR/:detailId

ReportEditFormRouteInfo.list = [
  {
    Component: ReportWriteFormMenu,
    path: 'report-form',
  },
  {
    Component: ReportWriteFormCategoryMenu,
    path: 'report-form/:reportKind',
  },
  {
    Component: ReportASREditForm,
    path: 'report-form/ASR/:detailId',
  },

  {
    Component: ReportCSREditFormInspection,
    path: 'report-form/CSR/inspection/:detailId',
  },
  {
    Component: ReportCSREditFormPaxDeplane,
    path: 'report-form/CSR/paxdeplane/:detailId',
  },
  {
    Component: ReportCSREditFormPaxPatient,
    path: 'report-form/CSR/paxpatient/:detailId',
  },
  {
    Component: ReportCSREditFormPaxInjury,
    path: 'report-form/CSR/paxinjury/:detailId',
  },
  {
    Component: ReportCSREditFormCrewPatient,
    path: 'report-form/CSR/crewpatient/:detailId',
  },
  {
    Component: ReportCSREditFormCrewInjury,
    path: 'report-form/CSR/crewinjury/:detailId',
  },
  {
    Component: ReportCSREditFormUnlawful,
    path: 'report-form/CSR/unlawful/:detailId',
  },
  {
    Component: ReportCSREditFormSmoking,
    path: 'report-form/CSR/smoking/:detailId',
  },
  {
    Component: ReportCSREditFormMaintenance,
    path: 'report-form/CSR/maintenance/:detailId',
  },
  {
    Component: ReportCSREditFormOther,
    path: 'report-form/CSR/other/:detailId',
  },

  {
    Component: ReportGSREditFormDamage,
    path: 'report-form/GSR/damage/:detailId',
  },
  {
    Component: ReportGSREditFormInspection,
    path: 'report-form/GSR/inspection/:detailId',
  },
  {
    Component: ReportGSREditFormPaxIrr,
    path: 'report-form/GSR/paxirr/:detailId',
  },
  {
    Component: ReportGSREditFormCargoIrr,
    path: 'report-form/GSR/cargoirr/:detailId',
  },
  {
    Component: ReportMSREditFormAOC,
    path: 'report-form/MSR/aoc/:detailId',
  },
  {
    Component: ReportMSREditFormAMO,
    path: 'report-form/MSR/amo/:detailId',
  },
  {
    Component: ReportDSREditForm,
    path: 'report-form/DSR/:detailId',
  },
  {
    Component: ReportFOQAEditForm,
    path: 'report-form/FOQA/:detailId',
  },
  {
    Component: ReportHZREditForm,
    path: 'report-form/HZR/:detailId',
  },
  {
    Component: ReportRSREditForm,
    path: 'report-form/RSR/:detailId',
  },
];

export default ReportEditFormRouteInfo;
