import AppSelect from '@/components/common/AppSelect';
import Modal from 'react-modal';
import AppRangeDatePicker from '@/components/common/AppRangeDatePicker';
import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import ApiService from '@/services/ApiService';
import AppTreeSelect from '@/components/common/AppTreeSelect';

//오늘 날짜 만들기
const today = new Date();
const year = today.getFullYear(); // 년도
const month = today.getMonth() + 1; // 월
const date = today.getDate(); // 날짜
let monthString = '';
let dateString = '';
if (month < 10) {
  monthString = '0' + month;
} else {
  monthString = month.toString();
}
if (date < 10) {
  dateString = '0' + date;
} else {
  dateString = date.toString();
}
const todayString = year + '-' + monthString + '-' + dateString;

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/common/reports',
  baseRoutePath: 'aviation/safety-risk-mgmt/investigation-report/add/edit',
};
const initSearchParam = {
  multipleValue: [],
  dateType: 'submit',
  startDate: todayString,
  endDate: todayString,
  keyword: '',
  searchInvestigation: true,
};
/* zustand store 생성 */
const useReportDocumentModalStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    multipleValue: [],
    dateType: 'submit',
    startDate: todayString,
    endDate: todayString,
    keyword: '',
    searchInvestigation: true,
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
    set({
      rangeDt: [todayString, todayString],
      conditionData: [],
      selectCheckBox: [],
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },

  // rowSelectMode = 'single' 이여도 array[] 형식으로 반환함

  //검색일
  rangeDt: [todayString, todayString],

  //보고서 구분 option 목록
  conditionData: [],

  //체크박스 선택 시 담음
  selectCheckBox: [],

  //보고서 구분 목록
  getCondition: async () => {
    const { searchParam } = get();
    const Param = { isInvestigationReport: true, searchASR: false };
    const result = await ApiService.get('avn/common/condition', Param);
    const resultConditionData = result.data || [];
    searchParam['multipleValue'].length = 0;
    resultConditionData[0].children.forEach((element) => {
      searchParam['multipleValue'].push(element.value);
    });
    set({ conditionData: resultConditionData });
    set({ searchParam: searchParam });
  },

  //보고서 구분 선택
  handleMultipleTreeSelect: (selectKey) => {
    const { searchParam } = get();
    searchParam['multipleValue'] = selectKey;
    set({ searchParam: searchParam });
  },
}));

function ReportDocumentModal(props) {
  const { isOpen, closeModal, checkDataList } = props;

  //URL 클릭 시 이동
  const CustomDate = (props) => {
    let dateText = props.value;
    dateText = dateText.substr(0, 10);
    return `${dateText}`;
  };

  const state = useReportDocumentModalStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'docNo', headerName: 'Doc No.' },
      { field: 'submittedAt', headerName: 'Submit Date', cellRenderer: CustomDate },
      { field: 'departureAt', headerName: 'Departure Date' },
      { field: 'regNo', headerName: 'Reg No.' },
      { field: 'flightNo', headerName: 'Flight No.' },
      { field: 'fromAirport', headerName: 'From' },
      { field: 'toAirport', headerName: 'To' },
      { field: 'airport', headerName: 'Occurrence AirPort' },
    ])
  );
  const {
    search,
    enterSearch,
    searchParam,
    list,
    changeSearchInput,
    initSearchInput,
    rangeDt,
    changeStateProps,
    conditionData,
    getCondition,
    handleMultipleTreeSelect,
    selectCheckBox,
    clear,
  } = state;
  // TODO : 검색 파라미터 나열
  const { multipleValue, dateType, keyword } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
  }, []);

  useEffect(() => {
    //TODO:왜 안먹히지
    //모달close시
    if (!isOpen) {
      initSearchInput();
      getCondition();
      console.log(searchParam);
      //모달 open시
    } else {
      enterSearch();
    }
    return clear;
  }, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">리포트찾기</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              <div className="boxForm">
                <div id="" className="area-detail active">
                  <div className="form-table">
                    <div className="form-cell wid30">
                      <span className="form-group wid100">
                        <AppSelect
                          id="AvnIvApprovalGroupSelectFormgroupName"
                          label={'일자 구분'}
                          value={dateType}
                          onChange={(value) => {
                            changeSearchInput('dateType', value);
                          }}
                          options={[
                            { label: 'Departure Date', value: 'departure' },
                            { label: 'Submit Date', value: 'submit' },
                          ]}
                          required
                          // errorMessage={errors['memberInfo.groupId']}
                        />
                      </span>
                    </div>
                    <div className="form-cell wid50">
                      <span className="form-group wid100">
                        <AppRangeDatePicker
                          label="검색일"
                          onChange={(value) => {
                            changeSearchInput('startDate', value[0]);
                            changeSearchInput('endDate', value[1]);
                            changeStateProps('rangeDt', value);
                          }}
                          value={rangeDt}
                          showNow
                          placeholder={['시작일', '종료일']}
                        />
                      </span>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTreeSelect
                          showSearch
                          label="보고서 구분"
                          treeData={conditionData}
                          fieldNames={{ label: 'nameKo', value: 'value' }}
                          treeDefaultExpandAll={true}
                          treeCheckable={true}
                          maxTagCount={5}
                          value={multipleValue}
                          onChange={handleMultipleTreeSelect}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSearchInput
                          label="Doc No."
                          value={keyword}
                          onChange={(value) => {
                            changeSearchInput('keyword', value);
                          }}
                          search={search}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="btn-area">
                    <button
                      type="button"
                      name="button"
                      className="btn-sm btn_text btn-darkblue-line"
                      onClick={enterSearch}
                    >
                      조회
                    </button>
                    <button
                      type="button"
                      name="button"
                      className="btn-sm btn_text btn-darkblue-line"
                      onClick={() => {
                        initSearchInput();
                      }}
                    >
                      초기화
                    </button>
                  </div>
                </div>

                {/*__control명 옆에 active  */}
                <button type="button" name="button" className="arrow button _control active">
                  <span className="hide">접기</span>
                </button>
              </div>
              {/*그리드영역 */}
              <div>
                <AppTable
                  rowData={list}
                  columns={columns}
                  setColumns={setColumns}
                  store={state}
                  handleRowDoubleClick={handleRowDoubleClick}
                  enableCheckBox
                  handleRowSelect={(value) => {
                    selectCheckBox.length = 0;
                    selectCheckBox.push(...value);
                  }}
                />
              </div>
              {/*//그리드영역 */}
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            취소
          </button>
          <button
            className="btn_text text_color_neutral-10 btn_confirm"
            onClick={() => {
              checkDataList.length = 0;
              checkDataList.push(...selectCheckBox);
              closeModal();
            }}
          >
            확인
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default ReportDocumentModal;
