import Config from '@/config/Config';
import { useImmer } from 'use-immer';
import { useState } from 'react';
import AvnReportUserSelect from '../aviation/common/AvnReportUserSelect';
import AvnReportUserSelectType2 from '../aviation/common/AvnReportUserSelectType2';
import AppNavigation from '../common/AppNavigation';

function GuideAvnReportUserSelect() {
  const [userList, setUserList] = useImmer([]);
  const [userList2, setUserList2] = useImmer([]);

  const [userSelectKind, setUserSelectKind] = useState('PF');

  const onSelect = (selectedValue) => {
    console.log(selectedValue);
    setUserList((beforeUserList) => {
      if (!beforeUserList.find((info) => info.empNo === selectedValue.empNo)) {
        beforeUserList.push(selectedValue);
      }
    });
  };

  const deleteUser = (removeIndex) => {
    setUserList((beforeUserList) => {
      beforeUserList.splice(removeIndex, 1);
    });
  };

  const onSelect2 = (selectedValue) => {
    console.log(selectedValue);
    setUserList2((beforeUserList) => {
      if (!beforeUserList.find((info) => info.empNo === selectedValue.empNo)) {
        beforeUserList.push({ ...selectedValue, tagName: userSelectKind });
      }
    });
  };

  const deleteUser2 = (removeIndex) => {
    setUserList2((beforeUserList) => {
      beforeUserList.splice(removeIndex, 1);
    });
  };

  const up = (listIndex) => {
    setUserList((beforeUserList) => {
      if (listIndex > 0) {
        const beforeInfo = beforeUserList[listIndex];
        const nextInfo = beforeUserList[listIndex - 1];
        beforeUserList[listIndex - 1] = beforeInfo;
        beforeUserList[listIndex] = nextInfo;
      }
    });
  };

  const down = (listIndex) => {
    setUserList((beforeUserList) => {
      if (listIndex < beforeUserList.length - 1) {
        const beforeInfo = beforeUserList[listIndex];
        const nextInfo = beforeUserList[listIndex + 1];
        beforeUserList[listIndex + 1] = beforeInfo;
        beforeUserList[listIndex] = nextInfo;
      }
    });
  };

  const up2 = (listIndex) => {
    setUserList2((beforeUserList) => {
      if (listIndex > 0) {
        const beforeInfo = beforeUserList[listIndex];
        const nextInfo = beforeUserList[listIndex - 1];
        beforeUserList[listIndex - 1] = beforeInfo;
        beforeUserList[listIndex] = nextInfo;
      }
    });
  };

  const down2 = (listIndex) => {
    setUserList2((beforeUserList) => {
      if (listIndex < beforeUserList.length - 1) {
        const beforeInfo = beforeUserList[listIndex];
        const nextInfo = beforeUserList[listIndex + 1];
        beforeUserList[listIndex + 1] = beforeInfo;
        beforeUserList[listIndex] = nextInfo;
      }
    });
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          GuideAvnReportUserSelect :{' '}
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideAvnReportUserSelect.tsx`}>
            GuideAvnReportUserSelect
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid50">
              <AvnReportUserSelect
                label="사용자검색"
                displaySort
                userList={userList}
                onSelect={onSelect}
                deleteUser={deleteUser}
                up={up}
                down={down}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid50">
              <AvnReportUserSelectType2
                label="사용자검색2"
                displaySort
                userList={userList2}
                onSelect={onSelect2}
                deleteUser={deleteUser2}
                up={up2}
                down={down2}
                changeUserSelectKind={(value) => setUserSelectKind(value)}
                userSelectKind={userSelectKind}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
export default GuideAvnReportUserSelect;
