import AirportSearch from '@/components/aviation/common/AirportSearch';
import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppTimePicker from '@/components/common/AppTimePicker';
import Code from '@/config/Code';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import CodeService from '@/services/CodeService';
import useCsrSmokingFormStore from '@/stores/aviation/report/useCsrSmokingFormStore';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import CsrEventContent from '../../common/CsrEventContent';
import CsrFlightInfo from '../../common/CsrFlightInfo';
import CsrInvolveList from '../../common/CsrInvolveList';

function ReportCSREditFormSmoking() {
  const formStore = useCsrSmokingFormStore();

  const {
    filghtExpanded,
    eventExpanded,
    involveExpaned,
    eventContentExpanded,
    errors,
    changeInput,
    getDetail,
    formValue,
    tempSave,
    save,
    print,
    toggleAccordionExpanded,
    isDirty,
    clear,
  } = formStore;

  const { event } = formValue;

  const {
    occurAirportCd,
    paxClsCd,
    evidenceSeizedYn,
    policeCalledYn,
    clueCd,
    smokeDetectorAlarmActivateCd,
    cabinLogYn,
    cabinOccurTime,
    cabinOccurTimezoneCd,
    inflightOccurLocationCd,
    cigaKindCodeList,
  } = event;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      clear();
    }
  }, [detailId]);

  useEffect(() => {
    return clear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['CSR']} />

      <div className="info-wrap toggle">
        <dl className={filghtExpanded ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button
              type="button"
              className="btn-tg"
              onClick={(event) => {
                event.stopPropagation();
                toggleAccordionExpanded('filghtExpanded');
              }}
            >
              비행정보
              <span className={filghtExpanded ? 'active' : ''}></span>
              <div className="tag-info-wrap-end">
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      보고서 작성 가이드
                    </a>
                  </div>
                </div>
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      의무보고의 범위
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: filghtExpanded ? '' : 'none' }}>
            <CsrFlightInfo store={formStore} />
          </dd>
        </dl>

        <dl className={eventExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트
              <span className={eventExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid100 ">
                      <div className="form-group wid50">
                        이벤트 카테고리 :{' '}
                        <span style={{ textDecoration: 'underline', fontWeight: 'bold' }}>
                          {CodeService.getCodeLabelByValue('CODE_GRP_155', 'CSR_09')}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AirportSearch
                          label="발생 공항"
                          value={occurAirportCd}
                          onChange={(value) => {
                            changeInput('event.occurAirportCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="담배 종류"
                          codeGrpId="CODE_GRP_100"
                          isMultiple
                          value={cigaKindCodeList}
                          onChange={(value) => {
                            changeInput(`event.cigaKindCodeList`, value);
                          }}
                          required
                          errorMessage={errors[`event.cigaKindCodeList`]}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="승객 탑승 클래스"
                          options={CodeService.getOptions('CODE_GRP_103')}
                          value={paxClsCd}
                          onChange={(value) => {
                            changeInput(`event.paxClsCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.paxClsCd`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="증거물 수집"
                          options={Code.reportUseYn}
                          value={evidenceSeizedYn}
                          onChange={(value) => {
                            changeInput(`event.evidenceSeizedYn`, value);
                          }}
                          required
                          errorMessage={errors[`event.evidenceSeizedYn`]}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="경찰 인계"
                          options={Code.reportUseYn}
                          value={policeCalledYn}
                          onChange={(value) => {
                            changeInput(`event.policeCalledYn`, value);
                          }}
                          required
                          errorMessage={errors[`event.policeCalledYn`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="현상"
                          options={CodeService.getOptions('CODE_GRP_101')}
                          value={clueCd}
                          onChange={(value) => {
                            changeInput(`event.clueCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.clueCd`]}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Smoke Detector 알람 작동"
                          options={Code.reportUseYn}
                          value={smokeDetectorAlarmActivateCd}
                          onChange={(value) => {
                            changeInput(`event.smokeDetectorAlarmActivateCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.smokeDetectorAlarmActivateCd`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Cabin Log 작성"
                          options={Code.reportUseYn}
                          value={cabinLogYn}
                          onChange={(value) => {
                            changeInput(`event.cabinLogYn`, value);
                          }}
                          required
                          errorMessage={errors[`event.cabinLogYn`]}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="df">
                          <div className="type3">
                            <AppTimePicker
                              label="발생 시간"
                              excludeSecondsTime
                              value={cabinOccurTime}
                              valueFormat="HHmm"
                              displayFormat="HH:mm"
                              onChange={(value) => {
                                changeInput('event.cabinOccurTime', value);
                              }}
                            />
                          </div>
                          <div className="type4">
                            <AppCodeSelect
                              codeGrpId="CODE_GRP_079"
                              value={cabinOccurTimezoneCd}
                              onChange={(value) => {
                                changeInput(`event.cabinOccurTimezoneCd`, value);
                              }}
                              required
                              errorMessage={errors[`event.cabinOccurTimezoneCd`]}
                              disabled
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="발생 위치"
                          codeGrpId="CODE_GRP_022"
                          value={inflightOccurLocationCd}
                          onChange={(value) => {
                            changeInput(`event.inflightOccurLocationCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.inflightOccurLocationCd`]}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>

        {/* 관련자 테이블 */}
        <dl className={involveExpaned ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('involveExpaned');
            }}
          >
            <button type="button" className="btn-tg">
              관련자 세부 정보
              <span className={involveExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: involveExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <CsrInvolveList store={formStore} />
              </div>
            </div>
          </dd>
        </dl>

        {/* 이벤트 내용 */}
        <dl className={eventContentExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventContentExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트 내용
              <span className={eventContentExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventContentExpanded ? '' : 'none' }}>
            <CsrEventContent store={formStore} />
          </dd>
        </dl>
      </div>

      {/* 하단버튼영역 */}
      <ReportEditBottomButton print={print} tempSave={tempSave} save={save} />
    </>
  );
}

export default ReportCSREditFormSmoking;
