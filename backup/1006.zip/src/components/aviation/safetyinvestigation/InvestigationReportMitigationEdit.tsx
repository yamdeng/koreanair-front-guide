import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import AppSelect from '@/components/common/AppSelect';
import AppEditorViewer from '@/components/common/AppEditorViewer';
import AvnReportUserSelect from '@/components/aviation/common/AvnReportUserSelect';

//위험레벨모달
// import ReportLevelModal from '@/components/modal/ReportLevelModal';
//확인모달
import ConfirmModal from '@/components/modal/ConfirmModal';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
import useInvestigationReportMitigationFormStore from '@/stores/aviation/safetyinvestigation/useInvestigationReportMitigationStore';
import useAppStore from '@/stores/useAppStore';
import { useStore } from 'zustand';
import AvnIvApprovalGroupFormModal from '@/components/modal/aviation/AvnIvApprovalGroupFormModal';
import SafetyAdvEditModal from '@/components/modal/aviation/SafetyAdvEditModal';
import SafetyActionEditModal from '@/components/modal/aviation/SafetyActionEditModal';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function InvestigationReportMitigationEdit() {
  //위험레벨모달
  // const [isOpen, setIsOpen] = useState(false);
  //위험레벨모달 끝
  //결재그룹모달
  const [isApprovalOpen, setIsApprovalOpen] = useState(false);
  const closeApprovalModal = () => {
    setIsApprovalOpen(false);
  };

  //안전권고 팝업창 컨트롤
  const [isSafetyAdv, setIsSafetyAdv] = useState(false);
  const closeSafetyAdv = () => {
    setIsSafetyAdv(false);
  };
  //안전권고 팝업창 컨트롤
  const [isSafetyAction, setIsSafetyAction] = useState(false);
  const closeSafetyAction = () => {
    setIsSafetyAction(false);
  };

  //결재그룹모달끝

  //사용자 profile 적용
  //로그인자 프로필 정보
  const profile = useStore(useAppStore, (state) => state.profile);

  const { t } = useTranslation();
  const [firstExpaned, setFirstExpaned] = useState(true);
  const [secondExpaned, setSecondExpaned] = useState(true);
  const [thirdExpaned, setThirdExpaned] = useState(true);
  const [fourExpaned, setFourExpaned] = useState(true);
  const [fiveExpaned, setFiveExpaned] = useState(true);
  const [sixExpaned, setSixExpaned] = useState(true);
  const [sevenExpaned, setSevenExpaned] = useState(true);

  const [safetyEditIndex, setSafetyEditIndex] = useState(null);
  const [safetyAdvEditType, setSafetyAdvEditType] = useState('add');

  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formValue,
    isDirty,
    save,
    cancel,
    clear,
    deleteAssumption,
    deleteRadical,
    changeErrors,
    getEventTypeList,
    getConsequenceList,
    getHazardList,
    getInvestigatior,
    getApprovalGroup,
    getMember,
    hazardListData,
    consequenceListData,
    addRiskAssessment,
    onSelectapprovalGroupList,
    up,
    down,
    isDeleteConfirmModal,
    isDeleteConfirmModalClose,
    isDeleteConfirmModalOpen,
    deleteConfirmModalOk,
    displayStatus,
    safetyAdvEditSave,
    safetyActionEditSave,
  } = useInvestigationReportMitigationFormStore();

  //formValue
  const {
    reportNo, //보고서 번호
    reportTitle, //리포트 subject
    occurrenceInformation, //발생정보
    flight, //비행정보
    crewMemberList, //승무원
    investigationReport,
    hazardList, //위해요인 리스트
    hazardId, //hazard
    hazardType, //원인구분
    consequenceId, //potential Consequence
    assumptionList, //추정원인 목록
    radicalList, //부수요인 목록
    approvalGroupID, //결재 ID
    approvalGroupList, //결재 그룹 리스트
    memberList, //결재 멤버 정보(options)
    approvalMemberList, //결재 멤버 목록(살제 값)
    empNo, //최초 작성자 사원번호
    isSubmitted, //제출여부
    reportDocument, //참고문서
    investigateName,
    safetyAdvList, //안전권고 리스트
    safetyActList, //Safety Action 리스트
  } = formValue;

  //발생정보
  const {
    eventAt, //발생일
    eventAtTz, //발생일 TimeZone
    classification, //Event Class
    classificationNameKor,
    classificationNameEng,
    eventId, //Event Type
    eventNm,
    airport, //발생 공항
    flightPhase, //발생 단계
    flightPhaseNameKor,
    flightPhaseNameEng,
    weatherText, //기상조건
    isSpi, //SPI여부
    spiFileGroupSeq, //SPI첨부파일
    locationText, //발생 장소
  } = occurrenceInformation;

  //비행정보
  const {
    departureAt, //출발일자
    flightNo, //비행편명
    registrationNo, //등록기호
    aircraftTypeText, //항공기 형식
    fromAirport, //출발항공
    toAirport, //도착공항
    divertAirport, //회항공항
    supply, //좌석수
    checkIn, //탑승자
  } = flight;

  //조사보고서
  const {
    postContents, //조사보고서 내용
    reportFileGroupSeq, //조사보고서 첨부파일
    investigateBy, //조사관
  } = investigationReport;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    //수정 ->상세정보 불러오기
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    //ASR 이벤트 목록 조회
    getEventTypeList();
    // hazard 목록 조회
    getHazardList();
    //consequence 목록 조회
    getConsequenceList();

    //조사관 처리
    getInvestigatior(profile);

    //결재 그룹 가져오기
    getApprovalGroup();

    displayStatus();

    // //reportDocument 참고문서 번호 초기화
    reportDocument.length = 0;
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2 className="reportview">
          보고서 번호
          <span>
            <a href="javascript:void(0);">{reportNo}</a>
          </span>
        </h2>
      </div>

      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">Subject</label>
                    <span className="text-desc-type1">{reportTitle}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="info-wrap toggle">
        <dl className={firstExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setFirstExpaned(!firstExpaned)}>
            <button type="button" className="btn-tg">
              {/* toggle 열어지면 active붙임*/}
              발생정보<span className={firstExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: firstExpaned ? '' : 'none' }}>
            {/* 보고서상세내용*/}
            <div className="edit-area">
              <div className="detailForm">
                {/* 보고서내용보기 상세*/}
                <div className="editbox report">
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">발생일/시간(UTC)</label>
                              <span className="text-desc-type1">{eventAt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Event Class</label>
                              <span className="text-desc-type1">{classificationNameKor}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Event Type</label>
                              <span className="text-desc-type1">{eventNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">발생 공항</label>
                              <span className="text-desc-type1">{airport}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">발생 단계</label>
                              <span className="text-desc-type1">{flightPhaseNameKor}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">기상조건</label>
                              <span className="text-desc-type1">{weatherText}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">SPI 여부</label>
                              <span style={{ marginBottom: '5px' }} className="text-desc-type1">
                                {isSpi == 'Y' ? '예' : '아니오'}
                              </span>
                            </li>
                            <li className={isSpi == 'Y' ? 'detail show' : 'detail hide'}>
                              <AppFileAttach
                                mode="view"
                                onlyImageUpload={false}
                                fileGroupSeq={spiFileGroupSeq}
                                disabled={true}
                              />
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">발생 위치</label>
                              <span className="text-desc-type1">{locationText}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                      a
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">참고문서번호</label>
                              <div className="tag-list">
                                <ul>
                                  {reportDocument == undefined
                                    ? null
                                    : reportDocument.map((el) => {
                                        return (
                                          <li key={el.id} id={el.id}>
                                            <button
                                              type="button"
                                              onClick={() => {
                                                window.open('http://www.naver.com', '_blank');
                                              }}
                                            >
                                              {el.docNo}{' '}
                                            </button>
                                          </li>
                                        );
                                      })}
                                </ul>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* //보고서내용보기 상세*/}
              </div>
            </div>
          </dd>
        </dl>

        <dl className={secondExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setSecondExpaned(!secondExpaned)}>
            <button type="button" className="btn-tg">
              비행정보<span className={secondExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: secondExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detailForm">
                {/* 보고서내용보기 상세*/}
                <div className="editbox report">
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">출발일자(UTC)</label>
                              <span className="text-desc-type1">{departureAt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">비행편명</label>
                              <span className="text-desc-type1">{flightNo}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">등록 기호</label>
                              <span className="text-desc-type1">{registrationNo}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">항공기 형식</label>
                              <span className="text-desc-type1">{aircraftTypeText}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">출발/도착 공항</label>
                              <span className="text-desc-type1">
                                {fromAirport} / {toAirport}
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">회항 공항</label>
                              <span className="text-desc-type1">{divertAirport}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">좌석수(F/C/Y)</label>
                              <span className="text-desc-type1">{supply}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">탑승자(F/C/Y)</label>
                              <span className="text-desc-type1">{checkIn}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">승무원</label>
                              {crewMemberList == undefined
                                ? null
                                : crewMemberList.map((el, index) => {
                                    return (
                                      <span key={index} className="text-desc-type1">
                                        {el.customLabel}
                                      </span>
                                    );
                                  })}
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* //보고서내용보기 상세*/}
              </div>
            </div>
          </dd>
        </dl>

        <dl className={thirdExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setThirdExpaned(!thirdExpaned)}>
            <button type="button" className="btn-tg">
              조사보고서<span className={thirdExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: thirdExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detailForm">
                {/* 보고서내용보기 상세*/}
                <div className="editbox report">
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">개요</label>
                              <span className="text-desc-type1">
                                <AppEditorViewer value={postContents} />
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li>
                              <AppFileAttach
                                mode="view"
                                onlyImageUpload={false}
                                fileGroupSeq={reportFileGroupSeq}
                                disabled={true}
                              />
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Investigator</label>
                              <span className="text-desc-type1">{investigateName}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* //보고서내용보기 상세*/}
              </div>
            </div>
          </dd>
        </dl>

        <dl className={sixExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setSixExpaned(!sixExpaned)}>
            <button type="button" className="btn-tg">
              안전권고
              <div className="tag-info-wrap-end">
                <button
                  type="button"
                  name="button"
                  className="btn_text btn_confirm"
                  onClick={(event) => {
                    //안전권고 팝업창 open
                    event.stopPropagation();
                    setSafetyAdvEditType('add');
                    setIsSafetyAdv(true);
                  }}
                >
                  + ADD ROW
                </button>
              </div>
              <span className={sixExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: sixExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="info-list">
                          {/* <h3>
                            추정원인<span className="required">*</span>
                          </h3> */}
                          <table className="info-board">
                            <colgroup>
                              <col width="15%" />
                              <col width="25%" />
                              <col width="25%" />
                              <col width="10%" />
                              <col width="10%" />
                              <col width="10%" />
                            </colgroup>
                            <thead>
                              <tr>
                                <th>번호</th>
                                <th>안전권고</th>
                                <th>조사사항</th>
                                <th>부서</th>
                                <th>발행일자</th>
                                <th>회신일자</th>
                              </tr>
                            </thead>
                            <tbody>
                              {safetyAdvList == undefined
                                ? null
                                : safetyAdvList.map((el, index) => {
                                    return (
                                      <tr
                                        key={index}
                                        onClick={() => {
                                          setSafetyEditIndex(index);
                                          setSafetyAdvEditType('edit');
                                          setIsSafetyAdv(true);
                                        }}
                                      >
                                        <td className="left">
                                          <a href="javascript:void(0);">{el.recommendNo}</a>
                                        </td>
                                        <td className="left">{el.recommend}</td>
                                        <td className="">{el.actionTaken}</td>
                                        <td className="">{el.deptCd}</td>
                                        <td className="">{el.issueAt}</td>
                                        <td className="">{el.dueAt}</td>
                                      </tr>
                                    );
                                  })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        <dl className={sevenExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setSevenExpaned(!sevenExpaned)}>
            <button type="button" className="btn-tg">
              Safety Action
              <div className="tag-info-wrap-end">
                <button
                  type="button"
                  name="button"
                  className="btn_text btn_confirm"
                  onClick={(event) => {
                    //안전권고 팝업창 open
                    event.stopPropagation();
                    setSafetyAdvEditType('add');
                    setIsSafetyAction(true);
                  }}
                >
                  + ADD ROW
                </button>
              </div>
              <span className={sevenExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: sevenExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="info-list">
                          {/* <h3>
                            추정원인<span className="required">*</span>
                          </h3> */}
                          <table className="info-board">
                            <colgroup>
                              <col width="15%" />
                              <col width="60%" />
                              <col width="15%" />
                              <col width="10%" />
                            </colgroup>
                            <thead>
                              <tr>
                                <th>번호</th>
                                <th>조치결과</th>
                                <th>부서</th>
                                <th>조치일자</th>
                              </tr>
                            </thead>
                            <tbody>
                              {safetyActList == undefined
                                ? null
                                : safetyActList.map((el, index) => {
                                    return (
                                      <tr
                                        key={index}
                                        onClick={() => {
                                          setSafetyEditIndex(index);
                                          setSafetyAdvEditType('edit');
                                          setIsSafetyAction(true);
                                        }}
                                      >
                                        <td>
                                          <a href="javascript:void(0);">{el.safetyNo}</a>
                                        </td>
                                        <td className="left">{el.actionTaken}</td>
                                        <td className="">{el.deptCd}</td>
                                        <td className="">{el.actionAt}</td>
                                      </tr>
                                    );
                                  })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>

        <dl className={fourExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setFourExpaned(!fourExpaned)}>
            <button type="button" className="btn-tg">
              2nd Risk Assessment
              <span className={fourExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: fourExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="info-list">
                          <h3>추정원인</h3>
                          <table className="info-board">
                            <colgroup>
                              <col width="30%" />
                              <col width="40%" />
                              <col width="15%" />
                              <col width="15%" />
                            </colgroup>
                            <thead>
                              <tr>
                                <th>Hazard</th>
                                <th>Potential Consequence</th>
                                <th>1st Risk Level</th>
                                <th>2nd Risk Level</th>
                              </tr>
                            </thead>
                            <tbody>
                              {hazardList == undefined
                                ? null
                                : hazardList.map((el, index) => {
                                    if (el.hazardType == 'ast') {
                                      const astJson = {
                                        hazardId: el.hazardId,
                                        hazardType: el.hazardType,
                                        consequenceId: el.consequenceId,
                                        hazardName: el.hazardName,
                                        consequenceName: el.consequenceName,
                                      };
                                      assumptionList.push(astJson);
                                      return (
                                        <tr key={index}>
                                          <td className="left">{el.hazardName}</td>
                                          <td className="left">{el.consequenceName}</td>
                                          <td className="">
                                            <div className="Safety-table-cell">
                                              <a href="javascript:void(0);">
                                                <span className="Safety-tag Select">Select</span>
                                              </a>
                                            </div>
                                          </td>
                                          <td className="">
                                            <div className="Safety-table-cell">
                                              <a href="javascript:void(0);">
                                                <span className="Safety-tag Select">Select</span>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                      );
                                    }
                                  })}
                            </tbody>
                          </table>
                        </div>
                        <div className="info-list">
                          <h3>부수요인</h3>
                          <table className="info-board">
                            <colgroup>
                              <col width="30%" />
                              <col width="40%" />
                              <col width="15%" />
                              <col width="15%" />
                            </colgroup>
                            <thead>
                              <tr>
                                <th>Hazard</th>
                                <th>Potential Consequence</th>
                                <th>1st Risk Level</th>
                                <th>2nd Risk Level</th>
                              </tr>
                            </thead>
                            <tbody>
                              {hazardList == undefined
                                ? null
                                : hazardList.map((el, index) => {
                                    if (el.hazardType == 'rdc') {
                                      const rdcJson = {
                                        hazardId: el.hazardId,
                                        hazardType: el.hazardType,
                                        consequenceId: el.consequenceId,
                                        hazardName: el.hazardName,
                                        consequenceName: el.consequenceName,
                                      };
                                      radicalList.push(rdcJson);
                                      return (
                                        <tr key={index}>
                                          <td className="left">{el.hazardName}</td>
                                          <td className="left">{el.consequenceName}</td>
                                          <td className="">
                                            <div className="Safety-table-cell">
                                              <a href="javascript:void(0);">
                                                <span className="Safety-tag Select">Select</span>
                                              </a>
                                            </div>
                                          </td>
                                          <td className="">
                                            <div className="Safety-table-cell">
                                              <a href="javascript:void(0);">
                                                <span className="Safety-tag Select">Select</span>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                      );
                                    }
                                  })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        <dl className={fiveExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setFiveExpaned(!fiveExpaned)}>
            <button type="button" className="btn-tg">
              결재정보
              <span className={fiveExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: fiveExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid50">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <AppSelect
                              id="AvnIvApprovalGroupSelectFormgroupName"
                              label={'결재Group 명'}
                              value={approvalGroupID}
                              onChange={(value) => {
                                changeInput('approvalGroupID', value);
                                getMember(value);
                              }}
                              options={approvalGroupList}
                              labelKey="groupName"
                              valueKey="id"
                              required
                              errorMessage={errors.approvalGroupID}
                            />
                          </div>
                          <div className="form-group wid100 mt10">
                            <AvnReportUserSelect
                              label="사용자검색"
                              displaySort
                              userList={memberList}
                              onSelect={onSelectapprovalGroupList}
                              deleteUser={isDeleteConfirmModalOpen}
                              up={up}
                              down={down}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="btn-area">
                        <button
                          type="button"
                          name="button"
                          className="btn-sm btn_text btn-darkblue-line"
                          onClick={() => setIsApprovalOpen(true)}
                        >
                          결재그룹설정
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={() => {
            // console.log(safetyAdvList);
          }}
        >
          출력
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_conblue"
          onClick={() => {
            changeInput('isSubmitted', 'Y');
            save();
          }}
        >
          제출
        </button>

        <button type="button" name="button" className="btn_text btn_list" onClick={cancel}>
          목록
        </button>
      </div>
      {/* //하단버튼영역 */}
      {/* 위험레벨 모달 */}

      {/* 삭제 확인 팝업창 */}
      <ConfirmModal
        title={'삭제하시겠습니까?'}
        body=""
        okLabel="삭제"
        cancelLabel="닫기"
        isOpen={isDeleteConfirmModal}
        closeModal={() => isDeleteConfirmModalClose()}
        cancel={isDeleteConfirmModalClose}
        ok={deleteConfirmModalOk}
      />
      {/* 그룹설정 팝업창 */}
      <AvnIvApprovalGroupFormModal
        isOpen={isApprovalOpen}
        closeModal={closeApprovalModal}
        getGroupIvReportEdit={getApprovalGroup}
      />
      <SafetyAdvEditModal
        isOpen={isSafetyAdv}
        closeModal={closeSafetyAdv}
        safetyAdvList={safetyAdvList}
        editIndex={safetyEditIndex}
        editType={safetyAdvEditType}
        safetyAdvEditSave={safetyAdvEditSave}
      />

      <SafetyActionEditModal
        isOpen={isSafetyAction}
        closeModal={closeSafetyAction}
        safetyActionList={safetyActList}
        editIndex={safetyEditIndex}
        editType={safetyAdvEditType}
        safetyActionEditSave={safetyActionEditSave}
      />
    </>
  );
}
export default InvestigationReportMitigationEdit;
