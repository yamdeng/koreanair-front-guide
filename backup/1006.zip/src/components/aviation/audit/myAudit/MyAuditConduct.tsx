import { useState } from 'react';
import { DatePicker, TimePicker, Select as AntSelect } from 'antd';
import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
import AppTextInput from '@/components/common/AppTextInput';
import AppTextArea from '@/components/common/AppTextArea';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import { Upload } from 'antd';
import AppRadioGroup from '@/components/common/AppRadioGroup';

import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';
import useMyAuditConductStore from '@/stores/aviation/audit/myAudit/useMyAuditConductStore';

const { Dragger } = Upload;
const props: any = {
  name: 'file',
  multiple: true,
  defaultFileList: [
    {
      uid: '1',
      name: 'xxx.png',
      // status: 'uploading',
      url: 'http://www.baidu.com/xxx.png',
      percent: 33,
    },
    // {
    //   uid: '2',
    //   name: 'yyy.png',
    //   status: 'done',
    //   url: 'http://www.baidu.com/yyy.png',
    // },
    // {
    //   uid: '3',
    //   name: 'zzz.png',
    //   status: 'error',
    //   response: 'Server Error 500',
    //   // custom error message to show
    //   url: 'http://www.baidu.com/zzz.png',
    // },
  ],
  action: 'https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload',

  onChange(info) {
    const { status } = info.file;
    if (status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (status === 'done') {
      alert(`${info.file.name} file uploaded successfully.`);
    } else if (status === 'error') {
      alert(`${info.file.name} file upload failed.`);
    }
  },

  onRemove(file) {
    return false;
  },

  onPreview(file) {
    return false;
  },

  onDrop(e) {
    console.log('Dropped files', e.dataTransfer.files);
  },
};

function MyAuditConduct() {
  const [inputValue, setInputValue] = useState('');
  const rowData = getAllData();
  const columns = testColumnInfos;

  const { hideConduct, changeQuestionList } = useMyAuditFrameStore();
  const {
    dsAuditChecklistList,
    dsAuditChapterList,
    dsAuditQuestionList,
    currentChecklistId,
    currentChapterTabIndex,
    changeChecklistIndex,
    changeChapterTabIndex,
  } = useMyAuditConductStore();

  return (
    <>
      <div id="area-CONDUCT" className={`myaudit-contents ${hideConduct}`}>
        <div className="audit-box"></div>
        <h3 className="audit-tit">Conduct</h3>
        <div className="editbox ">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="group-box-wrap wid100">
                <span className="txt">
                  Finding / Observation
                  <span className="required">*</span>
                </span>
                <div className="radio-wrap">
                  <label>
                    <input type="radio" />
                    <span>Yes</span>
                  </label>
                  <label>
                    <input type="radio" />
                    <span>No</span>
                  </label>
                </div>
                {/*<span className="errorText">error</span>*/}
              </div>
            </div>
          </div>
          <hr className="line"></hr>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput label="Audit 결과 보고" />
              </div>
            </div>
          </div>
          {/* 파일첨부영역 : drag */}
          <div className="form-cell wid100 mb-20">
            <div className="form-group wid100">
              {/* 파일첨부영역 : drag */}
              <div className="filebox error">
                <Dragger {...props}>
                  <p className="ant-upload-text ">+ 이 곳을 클릭하거나 마우스로 업로드할 파일을 끌어서 놓으세요.</p>
                </Dragger>
                <label htmlFor="file" className="file-label">
                  첨부파일 <span className="required">*</span>
                </label>
              </div>
              <span className="errorText">fileerror</span>
            </div>
          </div>
          <hr className="line"></hr>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/* <AppSelect label={'Checklist'} /> */}
                <AppSelect
                  id="divisionChecklist"
                  options={dsAuditChecklistList}
                  label="Checklist"
                  value={currentChecklistId}
                  //value={checklistInfo}
                  labelKey="listName"
                  valueKey="checklistId"
                  onChange={(selectValue, index) => {
                    //changeRevision(appSelectValue);
                    //changeInput('checklistInfo', appSelectValue);
                    changeChecklistIndex(index);
                  }}
                  // isMultiple
                  // required
                  // disabled
                />
              </div>
            </div>
          </div>
          <hr className="line"></hr>
        </div>
        {/*탭 */}
        <div className="menu-tab-nav">
          <div className="swiper-container">
            <div className="menu-tab Audit">
              {dsAuditChapterList.map((chapterInfo, index) => {
                const { chapterId, chapterName } = chapterInfo;
                return (
                  <a
                    key={chapterId}
                    href="javascript:void(0);"
                    className={currentChapterTabIndex === index ? 'active' : ''}
                    data-label={chapterName}
                    onClick={() => changeChapterTabIndex(index)}
                  >
                    {chapterName}
                  </a>
                );
              })}
            </div>

            <div className="menu-tab-nav-operations">
              <button type="button" name="button" className="menu-tab-nav-more">
                <span className="hide">더보기</span>
              </button>

              {/*<button type="button" name="button" className="menu-tab-btn-next">
              <span className="hide">다음 탭메뉴</span>
            </button>*/}
            </div>
          </div>
        </div>
        <div className="checklist-contents edit Audit">
          {/* 상세페이지 */}
          {dsAuditQuestionList.map((questionInfo, questionIndex) => {
            const {
              questionId,
              content,
              refManual,
              priorityNm,
              probabilityNm,
              severityNm,
              priorityColor,
              probabilityColor,
              severityColor,
              comment,
              findingType,
            } = questionInfo;
            return (
              <div key={questionId} className="editbox">
                <div className="form-table line">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="df">
                        <div className="type9 mt10">
                          <div className="text-desc-type1">{content}</div>
                          <div className="form-table">
                            <div className="form-cell wid100">
                              <div className="form-group wid100">
                                <span className="text-desc-type1">{refManual}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="type10">
                          <div className="form-table">
                            <div className="form-cell">
                              <div className="form-group wid100">
                                <div className="group-box-wrap wid100">
                                  <span className="txt">Priority</span>
                                  <div className="editarea-box view">
                                    <div className="label-box bwid50">
                                      <span className={priorityColor}>{priorityNm}</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="form-table">
                            <div className="form-cell wid50">
                              <div className="form-group wid100">
                                <div className="group-box-wrap wid100">
                                  <span className="txt">Severity</span>
                                  <div className="editarea-box view">
                                    <div className="label-box wid50">
                                      <span className={severityColor}>{severityNm}</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="form-table">
                            <div className="form-cell wid50">
                              <div className="form-group wid100">
                                <div className="group-box-wrap wid100">
                                  <span className="txt">Probability</span>
                                  <div className="editarea-box view">
                                    <div className="label-box wid50">
                                      <span className={probabilityColor}>{probabilityNm}</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        {/*<div className="box-view-list Audit">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <span className="text-desc-type1">
                          1-1 지점장은 공항업무(운송/운항관리/정비/안전보안) 수행에 필요한 인원 및 업무 분장을 지정,
                          파악 관리한다. (GM - Guidance Material) 지점 조직도, Safety Coordinator, 위임/대행 체계
                          인원현황(해분야 적정 경력 인력 보임 여부) <br />
                          업무분장(업무의 범위, 책임, 권한 포함)
                        </span>
                      </li>
                    </ul>
                  </div>*/}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      {/* <AppTextInput label="" placeholder="Input Comment" /> */}
                      <AppTextInput
                        inputType="text"
                        label={'Input Comment'}
                        placeholder="Input Comment"
                        value={comment}
                        onChange={(value) => {
                          changeQuestionList(questionIndex, 'comment', value);
                        }}
                      />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="group-box-wrap wid100">
                      {/* <div className="radio-wrap border-no">
                        <label>
                          <input type="radio" />
                          <span>Finding</span>
                        </label>
                        <label>
                          <input type="radio" />
                          <span>Observation</span>
                        </label>
                        <label>
                          <input type="radio" />
                          <span>N/A</span>
                        </label>
                        <label>
                          <input type="radio" />
                          <span>Yes</span>
                        </label>
                      </div> */}
                      {/*<span className="errorText">error</span>*/}
                      <AppRadioGroup
                        id="SysDeptFormrprsnUserId"
                        name="rprsnUserId"
                        label=""
                        options={[
                          { value: 'Finding', label: 'Finding' },
                          { value: 'Observation', label: 'Observation' },
                          { value: 'N/A', label: 'N/A' },
                          { value: 'Yes', label: 'Yes' },
                        ]}
                        value={findingType}
                        onChange={(value) => {
                          changeQuestionList(questionIndex, 'findingType', value);
                        }}
                        // value={rprsnUserId}
                        // onChange={(value) => changeInput('rprsnUserId', value)}
                        // errorMessage={checkedErrorMessage ? 'error' : ''}
                        // required={checkedRequired}
                        // disabled={checkedDisabled}
                        // toolTipMessage={checkedToolTip ? 'aaa\nbbb\ncccc' : ''}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
              </div>
            );
          })}
          {/*//상세페이지*/}
        </div>
        {/* 하단버튼영역 */}
        <div className="contents-btns">
          <button className="btn_text text_color_neutral-10 btn_confirm ">Delete</button>
          <button className="btn_text btn_list ">Save</button>
          <button disabled className="btn_text btn-disabled">
            Rollback
          </button>
          <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
            Next
          </button>
        </div>
        {/*//하단버튼영역*/}
      </div>
    </>
  );
}

export default MyAuditConduct;
