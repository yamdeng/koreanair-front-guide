import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/general/lawRegInfo',
  baseRoutePath: '/occupation/general/lawRegInfo',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 법규명
  lawNm: '',
  // 일자 구분
  type: '',
  // FROM 시작일자
  fromDt: '',
  // TO 시작 일자
  toDt: '',
  // 제개정 종류
  lgsltKind: '',
  // 소관부처
  respMinistryNm: '',
  // 주관부서
  subjectDeptCd: '',
  // 해당부서
  rlvtDeptCd: '',
  // 상태
  approvalStatus: '',
  // 키워드
  keyWordContent: '',
};

/* zustand store 생성 */
const OcuLawRegInfoListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    // 법규명
    lawNm: '',
    // 일자 구분
    type: '',
    // FROM 시작일자
    fromDt: '',
    // TO 시작 일자
    toDt: '',
    // 제개정 종류
    lgsltKind: '',
    // 소관부처
    respMinistryNm: '',
    // 주관부서
    subjectDeptCd: '',
    // 해당부서
    rlvtDeptCd: '',
    // 상태
    approvalStatus: '',
    // 키워드
    keyWordContent: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function OcuLawRegInfoList() {
  const state = OcuLawRegInfoListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'lawNm', headerName: '법규명' },
      { field: 'lawSeq', headerName: '법령_일련번호' },
      { field: 'fearDt', headerName: '공포일자' },
      { field: 'implDt', headerName: '시행일자' },
      { field: 'lgsltKind', headerName: '제개정 종류' },
      { field: 'respMinistryNm', headerName: '소관 부처' },
      { field: 'subjectDeptCd', headerName: '주관 부처' },
      { field: 'rlvtDeptCd', headerName: '해당 부서' },
      { field: 'inflDegreeEval', headerName: '영향도 평가' },
      { field: 'keyWordContent', headerName: 'Keyword' },
      { field: 'aprvStatNm', headerName: '상태' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    goDetailPage,
    changeSearchInput,
    // initSearchInput,
    // isExpandDetailSearch,
    // toggleExpandDetailSearch,
    clear,
  } = state;
  // TODO : 검색 파라미터 나열
  const {
    lawNm,
    type,
    fromDt,
    toDt,
    lgsltKind,
    respMinistryNm,
    subjectDeptCd,
    rlvtDeptCd,
    approvalStatus,
    keyWordContent,
  } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    // 법규 일련번호
    const detailId = data.lawSeq;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      {/*경로 */}
      <div className="conts-title">
        <h2>법규등록대장</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div id="" className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="법규명"
                  value={lawNm}
                  onChange={(value) => {
                    changeSearchInput('lawNm', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'일자'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC011"
                  value={type}
                  onChange={(value) => {
                    changeSearchInput('type', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label="등록일자"
                      value={fromDt}
                      onChange={(value) => {
                        changeSearchInput('fromDt', value);
                      }}
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label="등록일자"
                      value={toDt}
                      onChange={(value) => {
                        changeSearchInput('toDt', value);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="제개정종류"
                  value={lgsltKind}
                  onChange={(value) => {
                    changeSearchInput('lgsltKind', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label={'소관부처'}
                  value={respMinistryNm}
                  onChange={(deptCd) => {
                    changeSearchInput('respMinistryNm', deptCd);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDeptSelectInput
                  label={'주관부서'}
                  value={subjectDeptCd}
                  onChange={(deptCd) => {
                    changeSearchInput('subjectDeptCd', deptCd);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDeptSelectInput
                  label={'해당부서'}
                  value={rlvtDeptCd}
                  onChange={(deptCd) => {
                    changeSearchInput('rlvtDeptCd', deptCd);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'상태'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC012"
                  value={approvalStatus}
                  onChange={(value) => {
                    changeSearchInput('approvalStatus', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="Keyword"
                  value={keyWordContent}
                  onChange={(value) => {
                    changeSearchInput('keyWordContent', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button type="button" name="button" className="arrow button _control active">
          <span className="hide">접기</span>
        </button>
      </div>
      {/* //검색영역 */}
      {/*그리드영역 */}
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        {/* <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button> */}
      </div>
    </>
  );
}

export default OcuLawRegInfoList;
