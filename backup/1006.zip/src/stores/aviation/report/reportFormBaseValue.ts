import CommonUtil from '@/utils/CommonUtil';

// asr 비행정보
export const flighBaseValue = {
  departureDt: CommonUtil.getNowDateString('YYYYMMDD'),
  flightNo: '',
  regNo: '',
  aircraftTypeCd: '',
  departureAirportCd: '',
  arrivalAirportCd: '',
  divertAirportCd: '',
  stdTime: '',
  staTime: '',
  atdTime: '',
  ataTime: '',
  delayedMinCo: null,
  supplyNm: '',
  checkinNm: '',
};
