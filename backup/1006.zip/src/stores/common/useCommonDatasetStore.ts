import { produce } from 'immer';
import _ from 'lodash';

export const EnumType = {
  INSERT: 'A',
  DELETE: 'D',
  UPDATE: 'U',
  NORMAL: 'N',
  STATUS: '_status',
  ISERROR: '_isError',
  ISDIRTY: 'isDirty', // formSlice에서 사용하는 변수명
} as const;

/**
 * 공통데이타셋 작업중... 확장해나갈 예정
 * todo 에러처리 로직 추가 예정
 *
 * @param set
 * @param get
 * @returns
 */
export const createCommonDataset = (set, get) => {
  const CommonDS = {
    setDirty: (isDirth) => {
      set(
        produce((state) => {
          _.set(state, EnumType.ISDIRTY, isDirth);
        })
      );
    },

    getRow: (path) => {
      const state = get();
      return _.get(state, path, []);
    },

    getList: (path) => {
      const state = get();
      return _.get(state, path, []);
    },

    getColumn: (path, rowIdx, field) => {
      const state = get();
      const fullPath = rowIdx !== null ? `${path}[${rowIdx}].${field}` : `${path}.${field}`;
      return _.get(state, fullPath, null);
    },

    setColumn: (path, rowIdx, field, value) => {
      set(
        produce((state) => {
          const fullPath = rowIdx !== null ? `${path}[${rowIdx}].${field}` : `${path}.${field}`;
          const statusPath = rowIdx !== null ? `${path}[${rowIdx}].${EnumType.STATUS}` : `${path}.${EnumType.STATUS}`;

          _.set(state, fullPath, value);

          const status = _.get(state, statusPath, null);

          if (status === EnumType.NORMAL) {
            _.set(state, statusPath, EnumType.UPDATE);
          }
        })
      );
    },

    setRow: (action, path, rowIdx, value) => {
      let resultIdx = rowIdx;
      set(
        produce((state) => {
          let targetObject = _.get(state, path);

          // targetObject가 없으면 해당 경로에 빈 배열을 생성
          if (!targetObject) {
            _.set(state, path, []);
            targetObject = _.get(state, path); // 새로 생성된 배열을 가져옴
          }

          if (targetObject) {
            switch (action) {
              case EnumType.INSERT:
                if (rowIdx === null) {
                  targetObject.push({ ...value, _status: EnumType.INSERT });
                  resultIdx = targetObject.length - 1; // 추가된 인덱스
                } else {
                  targetObject.splice(rowIdx, 0, { ...value, _status: EnumType.INSERT });
                }
                break;
              case EnumType.UPDATE:
                if (targetObject[rowIdx]) {
                  targetObject[rowIdx] = { ...value };
                  if (targetObject[rowIdx]._status === EnumType.NORMAL) {
                    targetObject[rowIdx]._status = EnumType.UPDATE;
                  }
                }
                break;
              case EnumType.DELETE:
                if (targetObject[rowIdx]) {
                  if (targetObject[rowIdx]._status === EnumType.INSERT) {
                    targetObject.splice(rowIdx, 1); // 완전 삭제
                    // resultIdx = rowIdx - 1 >= 0 ? rowIdx - 1 : -1; // 이전 인덱스
                    resultIdx = rowIdx - 1; // 이전 인덱스
                  } else if (
                    targetObject[rowIdx]._status === EnumType.NORMAL ||
                    targetObject[rowIdx]._status === EnumType.UPDATE
                  ) {
                    targetObject[rowIdx]._status = EnumType.DELETE; // 상태만 삭제로 변경
                  }
                }
                break;
              default:
                console.error('Error EnumType', action, path, rowIdx, value);
            }
          }
          _.set(state, EnumType.ISDIRTY, true);
        })
      );
      return resultIdx; // 최종 인덱스 반환
    },

    // 데이터 행 추가
    addRow: (path, newData) => {
      return CommonDS.setRow(EnumType.INSERT, path, null, newData);
    },

    // 데이터 행 특정 인덱스에 삽입
    insertRow: (path, rowIdx, newData) => {
      return CommonDS.setRow(EnumType.INSERT, path, rowIdx, newData);
    },

    // 데이터 행 삭제로 표시
    deleteRow: (path, rowIdx) => {
      return CommonDS.setRow(EnumType.DELETE, path, rowIdx, {});
    },

    removeRow: (path, rowIdx) => {
      set(
        produce((state) => {
          const targetObject = _.get(state, path);
          targetObject.splice(rowIdx, 1);
          _.set(state, EnumType.ISDIRTY, true);
        })
      );
      return rowIdx - 1;
    },

    setStatus: (path, rowIdx, status) => {
      set(
        produce((state) => {
          const fullPath = rowIdx !== null ? `${path}[${rowIdx}].${EnumType.STATUS}` : `${path}.${EnumType.STATUS}`;

          _.set(state, fullPath, status);
          _.set(state, EnumType.ISDIRTY, true);
        })
      );
    },

    getStatus: (path, rowIdx) => {
      CommonDS.getColumn(path, rowIdx, `${EnumType.STATUS}`);
    },

    // 상태별 데이타 분리 ( 기본 노멀상태 제외)
    getListByStatus: (path, includeNormal = false) => {
      const state = get();
      const list = _.get(state, path, []);

      // 결과를 담을 객체
      const statusList = {
        insert: [],
        delete: [],
        update: [],
        normal: [],
      };

      // 리스트가 배열인 경우 상태별로 데이터를 분류
      if (Array.isArray(list)) {
        list.forEach((item) => {
          const status = _.get(item, EnumType.STATUS, EnumType.NORMAL);

          switch (status) {
            case EnumType.INSERT:
              statusList.insert.push(item);
              break;
            case EnumType.DELETE:
              statusList.delete.push(item);
              break;
            case EnumType.UPDATE:
              statusList.update.push(item);
              break;
            case EnumType.NORMAL:
              if (includeNormal) {
                statusList.normal.push(item);
              }
              break;
            default:
              console.error('Unknown status:', status);
          }
        });
      }

      return statusList;
    },

    // List 에 관한 에러 체크 로직 _isError 활용
    // 급한데로.. 코드정리 필요
    setValidateList: (path, errors) => {
      set(
        produce((state) => {
          // 모든 배열에 대해 _isError 기본값을 false로 설정하는 함수
          const setDefaultErrorState = (obj) => {
            for (const key in obj) {
              if (Array.isArray(obj[key])) {
                obj[key].forEach((item) => {
                  item[EnumType.ISERROR] = false;
                  setDefaultErrorState(item);
                });
              } else if (typeof obj[key] === 'object' && obj[key] !== null) {
                // 객체에 대해서도 재귀 호출
                setDefaultErrorState(obj[key]);
              }
            }
          };

          const targetObject = _.get(state, path, null);
          // 모든 배열 요소에 대해 _isError를 false로 설정
          setDefaultErrorState(targetObject);

          // errors에 기반하여 해당 배열 경로의 _isError를 true로 설정
          Object.keys(errors).forEach((errorKey) => {
            const errorPath = errorKey;
            const errorValue = errors[errorKey];

            // 배열 경로만 처리 (예: "list[0].chkItemCd -> list[0]._isError 값을 변경 )
            if (errorPath.includes('[') && errorPath.includes(']') && errorValue !== '') {
              const fullPath = `${path}.${errorPath.replace(/(\.\w+|\[\d+\])$/, ``)}.${EnumType.ISERROR}`;
              _.set(state, fullPath, true);
            }
          });
        })
      );
    },
  };

  return { CommonDS };
};
