# 대한항공 프론트 프로젝트

# tailwind 실행

npx tailwindcss -i input.css -o ./src/components/aviation/report/report.css --watch

#.css 문의항
-ag-header-cell-label{display:inline;text-align:center;flex: 1 auto;align-self:auto}

/_ ag-grid rowspan custom style _/
.ag-theme-quartz .cell-span {
background-color: #ffffff;
// border-bottom: 1px solid color(srgb 0.0941176 0.113725 0.121569 / 0.15);
// text-align: center;
display: grid;
align-items: center;
border-bottom-width: 0px;
}

\_popup.scss
columntable tbody td { padding: 7px; }

table cell component에 체크박스 반영

하이라이트 : common.scss
.highlight 반영

tree.scss
.ant-tree-title {
.current-find {
font-style: italic;
font-weight: bold;
}
}
