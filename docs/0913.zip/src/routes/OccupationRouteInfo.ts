const OccupationRouteInfo: any = {};

OccupationRouteInfo.list = [];

export default OccupationRouteInfo;
