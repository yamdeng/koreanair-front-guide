const RouteInfo: any = { rootPath: 'accident/' };

RouteInfo.list = [];

export default RouteInfo;
