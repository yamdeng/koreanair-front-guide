import ChecklistList from '@/components/occupation/inspection/checklist/ChecklistList';
import ChecklistForm from '@/components/occupation/inspection/checklist/ChecklistForm';
import ChecklistDetail from '@/components/occupation/inspection/checklist/ChecklistDetail';
import WalkAroundList from '@/components/occupation/inspection/walkAround/WalkAroundList';
import WalkAroundForm from '@/components/occupation/inspection/walkAround/WalkAroundForm';
import WalkAroundDetail from '@/components/occupation/inspection/walkAround/WalkAroundDetail';
import JointList from '@/components/occupation/inspection/joint/JointList';
import JointForm from '@/components/occupation/inspection/joint/JointForm';
import JointDetail from '@/components/occupation/inspection/joint/JointDetail';
import PeriodicList from '@/components/occupation/inspection/periodic/PeriodicList';
import PeriodicForm from '@/components/occupation/inspection/periodic/PeriodicForm';
import PeriodicDetail from '@/components/occupation/inspection/periodic/PeriodicDetail';
import CorrectionList from '@/components/occupation/inspection/correction/CorrectionList';
import CorrectionForm from '@/components/occupation/inspection/correction/CorrectionForm';
import CorrectionDetail from '@/components/occupation/inspection/correction/CorrectionDetail';

const RouteInfo: any = { rootPath: 'inspection/' };

RouteInfo.list = [
  /** 점검표관리 **/

  // 점검표관리 목록
  {
    Component: ChecklistList,
    path: 'checklist',
  },
  // 점검표관리 상세
  {
    Component: ChecklistDetail,
    path: 'checklist/:detailId',
  },
  // 점검표관리 입력,수정
  {
    Component: ChecklistForm,
    path: 'checklist/:detailId/edit',
  },

  /** 작업장순회점검 **/

  // 작업장순회점검 목록
  {
    Component: WalkAroundList,
    path: 'walkAround',
  },
  // 작업장순회점검 상세
  {
    Component: WalkAroundDetail,
    path: 'walkAround/:detailId',
  },
  // 작업장순회점검 입력,수정
  {
    Component: WalkAroundForm,
    path: 'walkAround/:detailId/edit',
  },

  /** 합동안전보건점검 **/

  // 합동안전보건점검 목록
  {
    Component: JointList,
    path: 'joint',
  },
  // 합동안전보건점검 상세
  {
    Component: JointDetail,
    path: 'joint/:detailId',
  },
  // 합동안전보건점검 입력,수정
  {
    Component: JointForm,
    path: 'joint/:detailId/edit',
  },

  /** 반기비정기점검 **/

  // 반기비정기점검 목록
  {
    Component: PeriodicList,
    path: 'periodic',
  },
  // 반기비정기점검 상세
  {
    Component: PeriodicDetail,
    path: 'periodic/:detailId',
  },
  // 반기비정기점검 입력,수정
  {
    Component: PeriodicForm,
    path: 'periodic/:detailId/edit',
  },

  /** 통합개선관리 **/

  // 통합개선관리 목록
  {
    Component: CorrectionList,
    path: 'correction',
  },
  // 통합개선관리 상세
  {
    Component: CorrectionDetail,
    path: 'correction/:detailId',
  },
  // 통합개선관리 입력,수정
  {
    Component: CorrectionForm,
    path: 'correction/:detailId/edit',
  },
];

export default RouteInfo;
