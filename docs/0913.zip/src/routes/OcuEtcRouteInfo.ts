const RouteInfo: any = { rootPath: 'etc/' };

RouteInfo.list = [];

export default RouteInfo;
