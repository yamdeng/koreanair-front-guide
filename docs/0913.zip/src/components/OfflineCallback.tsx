import { useEffect } from 'react';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';

function OfflineCallback() {
  const { profile } = useStore(useAppStore, (state) => state) as any;
  useEffect(() => {
    try {
      window.location.href = 'ksms://com.koreanair.safenet.ksms/auth?data=' + `${JSON.stringify(profile)}`;
    } catch (e) {
      //
    }
  }, []);
  return <div></div>;
}

export default OfflineCallback;
