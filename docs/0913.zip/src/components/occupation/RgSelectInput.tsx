import { useState } from 'react';
import AppSearchInput from '../common/AppSearchInput';

function RgSelectInput(props) {
  const { value, onChange } = props;
  const [isModalopen, setIsModalopen] = useState(false);

  const clearHandler = () => {
    onChange(null);
  };

  // TODO : 모달에서 받은 정보
  const handleSelectModal = (selectedValue) => {
    onChange(selectedValue, selectedValue ? selectedValue.userId : '');
    setIsModalopen(false);
  };

  const searchInputValue = value ? value.nameKor : '';

  console.log('RgSelectInput==>', RgSelectInput);

  return (
    <>
      <AppSearchInput
        {...props}
        disabled
        search={() => setIsModalopen(true)}
        clearHandler={clearHandler}
        value={searchInputValue}
      />
      {/* 목록모달 */}
    </>
  );
}

export default RgSelectInput;
