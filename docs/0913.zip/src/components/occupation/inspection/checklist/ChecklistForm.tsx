import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import useOcuCheckListFormStore from '@/stores/occupation/inspection/useOcuCheckListFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCheckListForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    useOcuCheckListFormStore();

  const { chkListClsCd, chkListTitle, regDttm, regUserId } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>점검표 관리</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_OC010"
                id="OcuCheckListFormchkListClsCd"
                name="chkListClsCd"
                label="점검표_구분_코드"
                value={chkListClsCd}
                onChange={(value) => changeInput('chkListClsCd', value)}
                errorMessage={errors.chkListClsCd}
                required
                disabled
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckListFormchkListTitle"
                name="chkListTitle"
                label="점검표_제목"
                value={chkListTitle}
                onChange={(value) => changeInput('chkListTitle', value)}
                errorMessage={errors.chkListTitle}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckListFormregDttm"
                name="regDttm"
                label="등록_일시"
                value={regDttm}
                onChange={(value) => changeInput('regDttm', value)}
                errorMessage={errors.regDttm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckListFormregUserId"
                name="regUserId"
                label="등록자_ID"
                value={regUserId}
                onChange={(value) => changeInput('regUserId', value)}
                errorMessage={errors.regUserId}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuCheckListForm;
