import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import useOcuCheckInfoFormStore from '@/stores/occupation/inspection/useOcuCheckInfoFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCheckInfoForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    useOcuCheckInfoFormStore();

  const {
    chkCls,
    chkTitle,
    chkYear,
    chkPeriodCd,
    chkRegDt,
    chkEmpno,
    remark,
    pohtoId1,
    pohtoId2,
    fileId,
    regDttm,
    regUserId,
  } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>TODO : 헤더 타이틀</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormchkCls"
                name="chkCls"
                label="점검_구분_코드"
                value={chkCls}
                onChange={(value) => changeInput('chkCls', value)}
                errorMessage={errors.chkCls}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormchkTitle"
                name="chkTitle"
                label="점검_제목"
                value={chkTitle}
                onChange={(value) => changeInput('chkTitle', value)}
                errorMessage={errors.chkTitle}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormchkYear"
                name="chkYear"
                label="점검_연도"
                value={chkYear}
                onChange={(value) => changeInput('chkYear', value)}
                errorMessage={errors.chkYear}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormchkPeriodCd"
                name="chkPeriodCd"
                label="점검_시기_코드"
                value={chkPeriodCd}
                onChange={(value) => changeInput('chkPeriodCd', value)}
                errorMessage={errors.chkPeriodCd}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormchkRegDt"
                name="chkRegDt"
                label="점검_등록_일자"
                value={chkRegDt}
                onChange={(value) => changeInput('chkRegDt', value)}
                errorMessage={errors.chkRegDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormchkEmpno"
                name="chkEmpno"
                label="점검자_사번"
                value={chkEmpno}
                onChange={(value) => changeInput('chkEmpno', value)}
                errorMessage={errors.chkEmpno}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormremark"
                name="remark"
                label="비고"
                value={remark}
                onChange={(value) => changeInput('remark', value)}
                errorMessage={errors.remark}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormpohtoId1"
                name="pohtoId1"
                label="첨부_사진1_ID"
                value={pohtoId1}
                onChange={(value) => changeInput('pohtoId1', value)}
                errorMessage={errors.pohtoId1}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormpohtoId2"
                name="pohtoId2"
                label="첨부_사진2_ID"
                value={pohtoId2}
                onChange={(value) => changeInput('pohtoId2', value)}
                errorMessage={errors.pohtoId2}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormfileId"
                name="fileId"
                label="첨부_파일_ID"
                value={fileId}
                onChange={(value) => changeInput('fileId', value)}
                errorMessage={errors.fileId}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormregDttm"
                name="regDttm"
                label="등록_일시"
                value={regDttm}
                onChange={(value) => changeInput('regDttm', value)}
                errorMessage={errors.regDttm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormregUserId"
                name="regUserId"
                label="등록자_ID"
                value={regUserId}
                onChange={(value) => changeInput('regUserId', value)}
                errorMessage={errors.regUserId}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuCheckInfoForm;
