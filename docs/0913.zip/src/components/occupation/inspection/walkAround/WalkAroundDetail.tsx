import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useParams } from 'react-router-dom';
// import { Viewer } from '@toast-ui/react-editor';
// import AppFileAttach from '@/components/common/AppFileAttach';
import useOcuSvisitCheckFormStore from '@/stores/occupation/inspection/useOcuSvisitCheckFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuSvisitCheckDetail() {
  /* formStore state input 변수 */
  const { detailInfo, getDetail, cancel, goFormPage, clear } = useOcuSvisitCheckFormStore();
  const { chkListClsCd, chkTitle, chkRegStartDt, chkRegEndDt } = detailInfo;

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>TODO : 헤더 타이틀</h2>
      </div>
      <div className="eidtbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">점검표_구분_코드</label>
                    <span className="text-desc-type1">{chkListClsCd}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">점검_제목</label>
                    <span className="text-desc-type1">{chkTitle}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">점검_등록_시작일자</label>
                    <span className="text-desc-type1">{chkRegStartDt}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">점검_등록_종료일자</label>
                    <span className="text-desc-type1">{chkRegEndDt}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          수정
        </button>
      </div>
    </>
  );
}
export default OcuSvisitCheckDetail;
