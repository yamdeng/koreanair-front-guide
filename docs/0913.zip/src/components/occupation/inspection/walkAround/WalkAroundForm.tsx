import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import useOcuSvisitCheckFormStore from '@/stores/occupation/inspection/useOcuSvisitCheckFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuSvisitCheckForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    useOcuSvisitCheckFormStore();

  const { chkListClsCd, chkTitle, chkRegStartDt, chkRegEndDt } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>TODO : 헤더 타이틀</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSvisitCheckFormchkListClsCd"
                name="chkListClsCd"
                label="점검표_구분_코드"
                value={chkListClsCd}
                onChange={(value) => changeInput('chkListClsCd', value)}
                errorMessage={errors.chkListClsCd}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSvisitCheckFormchkTitle"
                name="chkTitle"
                label="점검_제목"
                value={chkTitle}
                onChange={(value) => changeInput('chkTitle', value)}
                errorMessage={errors.chkTitle}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSvisitCheckFormchkRegStartDt"
                name="chkRegStartDt"
                label="점검_등록_시작일자"
                value={chkRegStartDt}
                onChange={(value) => changeInput('chkRegStartDt', value)}
                errorMessage={errors.chkRegStartDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSvisitCheckFormchkRegEndDt"
                name="chkRegEndDt"
                label="점검_등록_종료일자"
                value={chkRegEndDt}
                onChange={(value) => changeInput('chkRegEndDt', value)}
                errorMessage={errors.chkRegEndDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuSvisitCheckForm;
