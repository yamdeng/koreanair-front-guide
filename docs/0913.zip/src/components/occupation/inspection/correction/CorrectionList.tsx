import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/inspection/correction',
  baseRoutePath: '/occupation/inspection/correction',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  searchWord: '',
};

/* zustand store 생성 */
const OcuCheckContentListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    searchWord: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function OcuCheckContentList() {
  const state = OcuCheckContentListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'chkItemNm', headerName: '점검_항목_명' },
      { field: 'chkLclsCd', headerName: '점검_대분류_코드' },
      { field: 'chkScls', headerName: '점검_소분류_코드' },
      { field: 'chkContent', headerName: '점검_내용' },
      { field: 'chkRelLaw', headerName: '점검_관계법령' },
      { field: 'chkPohtoId1', headerName: '점검_첨부_사진_ID1' },
      { field: 'chkPohtoId2', headerName: '점검_첨부_사진_ID2' },
      { field: 'chkFile', headerName: '점검_첨부_파일' },
      { field: 'rightActionYn', headerName: '즉시_조치_여부' },
      { field: 'actionStatusCd', headerName: '조치_상태_코드' },
      { field: 'actionContent', headerName: '조치_내용' },
      { field: 'actionAttPhotoId', headerName: '조치_첨부_사진_ID' },
      { field: 'actionAttFileId', headerName: '조치_첨부_파일_ID' },
      { field: 'actionDt', headerName: '조치_일자' },
      { field: 'actionDeptCd', headerName: '조치_부서_코드' },
      { field: 'actionEmpno', headerName: '조치자_사번' },
      { field: 'aprvDt', headerName: '승인_일자' },
      { field: 'aprvDeptCd', headerName: '승인_부서_코드' },
      { field: 'aprvEmpno', headerName: '승인자_사번' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;
  // TODO : 검색 파라미터 나열
  const { searchWord } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    const detailId = data.chkResultId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>TODO: 타이틀</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="이름"
                  value={searchWord}
                  onChange={(value) => {
                    changeSearchInput('searchWord', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              초기화
            </button>
          </div>
        </div>
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default OcuCheckContentList;
