import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useParams } from 'react-router-dom';
// import { Viewer } from '@toast-ui/react-editor';
// import AppFileAttach from '@/components/common/AppFileAttach';

import useOcuSealSpaceFormStore from '@/stores/occupation/management/useOcuSealSpaceFormStore';
import { Upload } from 'antd';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuSealSpaceDetail() {
  /* formStore state input 변수 */
  const { detailInfo, getDetail, cancel, goFormPage, clear } = useOcuSealSpaceFormStore();
  const {
    sectCd,
    deptCd,
    areaCd,
    bizPlace,
    positionCls1,
    positionCls2,
    hndChmcl,
    hzdFactor,
    stdRuleCd,
    wrkCompanyNm,
    entExtIntrv,
    wrkContent,
    photoId1,
    photoId2,
    regDttm,
    regUserId,
  } = detailInfo;

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>밀폐공간현황</h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성자</label>
                    <span className="text-desc-type1">{regUserId}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성일자</label>
                    <span className="text-desc-type1">{regDttm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부문</label>
                    <span className="text-desc-type1">{sectCd}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부서</label>
                    <span className="text-desc-type1">{deptCd}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">권역</label>
                    <span className="text-desc-type1">{areaCd}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">사업장</label>
                    <span className="text-desc-type1">{bizPlace}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">위치분류1</label>
                    <span className="text-desc-type1">{positionCls1}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">위치분류2</label>
                    <span className="text-desc-type1">{positionCls2}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">취급화학물질</label>
                    <span className="text-desc-type1">{hndChmcl}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">유해인자</label>
                    <span className="text-desc-type1">{hzdFactor}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">기준에 관한 규칙</label>
                    <span className="text-desc-type1">{stdRuleCd}</span>
                  </li>
                </ul>
              </div>
              <span className="sm-txt">※ 산업안전보건기준에 관한 규칙 [별표 18] 밀폐공간(제618조제1호 관련)</span>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작업업체</label>
                    <span className="text-desc-type1">{wrkCompanyNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">출입주기</label>
                    <span className="text-desc-type1">{entExtIntrv}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">출입 시 작업내용</label>
                    <span className="text-desc-type1">{wrkContent}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">참고사진1</label>
                    <span className="text-desc-type1">
                      <div className="filebox view">
                        <Upload {...photoId1} listType="picture-card">
                          <div className="btn-area" style={{ display: 'none' }}>
                            <button type="button" name="button" className="btn-big btn_text btn-darkblue-line mg-n">
                              + Upload
                            </button>
                          </div>
                        </Upload>
                      </div>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">참고사진2</label>
                    <span className="text-desc-type1">
                      <div className="filebox view">
                        <Upload {...photoId2} listType="picture-card">
                          <div className="btn-area" style={{ display: 'none' }}>
                            <button type="button" name="button" className="btn-big btn_text btn-darkblue-line mg-n">
                              + Upload
                            </button>
                          </div>
                        </Upload>
                      </div>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <hr className="line"></hr>
      </div>
      {/*//입력영역*/}

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goFormPage}>
          수정
        </button>
        <button type="button" name="button" className="btn_text btn-del" onClick={cancel}>
          취소
        </button>
      </div>
      {/*//하단버튼영역*/}
    </>
  );
}
export default OcuSealSpaceDetail;
