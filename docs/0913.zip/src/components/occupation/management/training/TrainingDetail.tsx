import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useParams } from 'react-router-dom';
import useOcuMajorDssTrainingFormStore from '@/stores/occupation/management/useOcuMajorDssTrainingFormStore';
import { Viewer } from '@toast-ui/react-editor';
import { Upload } from 'antd';
import CommonUtil from '@/utils/CommonUtil';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuMajorDssTrainingDetail() {
  /* formStore state input 변수 */
  const { detailInfo, getDetail, cancel, goFormPage, clear } = useOcuMajorDssTrainingFormStore();
  const {
    // 부문
    sectNm,
    // 재난유형
    dssTypeNm,
    // 기타유형
    etcType,
    // 훈련일자
    trainDt,
    // 훈련장소
    trainLocation,
    // 참석자 명단
    prtcNmList,
    // 훈련명
    trainNm,
    // 평가 내용
    evalContent,
    // 첨부파일 ID
    fileId,
    // 첨부링크 ID
    linkId,
    // 수정 일시
    updDttm,
    // 수정자 ID
    updUserId,
    // 작성일자
    regDttm,
  } = detailInfo;

  // 링크 첨부 DB 작업 전 값 고정시키기
  const tempLinkAttachList = [
    { linkUrl: 'http://www.naver.com', linkSbj: '네이버' },
    { linkUrl: 'http://www.daum.net', linkSbj: '다음' },
  ];

  const convertedDate = CommonUtil.convertDate(trainDt, 'YYYYMMDD', 'YYYY-MM-DD');
  console.log('날짜좀바꿔죠라 : ' + convertedDate);
  console.log('훈련실시일 : ' + trainDt);

  // 작성일자 'YYYY-MM-DD'만 가져가기
  function getDataPortion(dateString) {
    try {
      return dateString.split('T')[0];
    } catch (error) {
      console.error('Invalid date format:', dateString);
      return dateString;
    }
  }
  const formattedDate = getDataPortion(regDttm);
  console.log('regDttm : ' + regDttm);
  console.log('얘도바꿔보쟈쫌!!! ' + formattedDate);

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>중대재해대응훈련</h2>
      </div>
      {/* These are my 1st draft of details */}
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성자</label>
                    <span className="text-desc-type1">작성자</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성일자</label>
                    <span className="text-desc-type1">{formattedDate}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부문</label>
                    <span className="text-desc-type1">{sectNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부서</label>
                    <span className="text-desc-type1">부서</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">재난유형</label>
                    <span className="text-desc-type1">{dssTypeNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">기타유형</label>
                    <span className="text-desc-type1">{etcType}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">훈련실시일</label>
                    <span className="text-desc-type1">{CommonUtil.convertDate(trainDt, 'YYYYMMDD', 'YYYY-MM-DD')}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">훈련장소</label>
                    <span className="text-desc-type1">{trainLocation}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">참석자</label>
                    <span className="text-desc-type1">{prtcNmList}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">훈련명</label>
                    <span className="text-desc-type1">{trainNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">내용(editor)</label>
                    <span className="text-desc-type1">
                      <Viewer initialValue={evalContent} />
                      {evalContent}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">첨부파일</label>
                    <span className="text-desc-type1">
                      <div className="filebox view">
                        <Upload {...fileId}>
                          <div className="btn-area" style={{ display: 'none' }}>
                            <button type="button" name="button" className="btn-big btn_text btn-darkblue-line mg-n">
                              + Upload
                            </button>
                          </div>
                        </Upload>
                      </div>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">첨부링크</label>
                    {tempLinkAttachList.map((attachInfo) => {
                      const { linkUrl, linkSbj } = attachInfo;
                      return (
                        <span key={linkUrl} className="text-desc-type2">
                          <a href={linkUrl} target="_blank">
                            {linkSbj}
                          </a>
                        </span>
                      );
                    })}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/*//입력영역*/}

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goFormPage}>
          수정
        </button>
        <button type="button" name="button" className="btn_text btn-del" onClick={cancel}>
          취소
        </button>
      </div>
      {/*//하단버튼영역*/}
    </>
  );
}
export default OcuMajorDssTrainingDetail;
