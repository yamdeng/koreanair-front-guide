import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
// import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';

/* TODO : store 경로를 변경해주세요. */
import useOcuRiskMachineFormStore from '@/stores/occupation/management/useOcuMachineFormStore';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function MachineForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, save, remove, cancel, clear } =
    useOcuRiskMachineFormStore();

  const profile = useStore(useAppStore, (state) => state.profile);
  console.log('profile==>', profile);

  //   // 사번
  //   const empNo = profile.userInfo.empNo;
  //   // 사용자명
  //   const nameKor = profile.userInfo.nameKor;

  const {
    //mchnInstrId,
    mchnInstrClsCd,
    mchnInstrNm,
    asetNo,
    unit,
    prtcDev,
    position,
    sectCd,
    deptCd,
    adminEmpno,
    useYn,
    intrDt,
    discardDt,
    sftyCrtfcTargetYn,
    sftyCrtfcPassNo,
    sftyAuditTargetYn,
    pohtoId1,
    pohtoId2,
    // regDttm,
    // regUserId,
    // updDttm,
    // updUserId,
  } = formValue;

  const { detailId } = useParams();

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>위험기계기구</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                label="기계기구 분류"
                codeGrpId="CODE_GRP_OC015"
                value={mchnInstrClsCd}
                onChange={(value) => changeInput('mchnInstrClsCd', value)}
                required
                disabled={formType !== 'add' ? true : false}
                errorMessage={errors.mchnInstrClsCd}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormmchnInstrNm"
                name="mchnInstrNm"
                label="기계기구 명칭"
                value={mchnInstrNm}
                onChange={(value) => changeInput('mchnInstrNm', value)}
                errorMessage={errors.mchnInstrNm}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormasetNo"
                name="asetNo"
                label="자산_번호"
                value={asetNo}
                onChange={(value) => changeInput('asetNo', value)}
                errorMessage={errors.asetNo}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormunit"
                name="unit"
                label="단위"
                value={unit}
                onChange={(value) => changeInput('unit', value)}
                errorMessage={errors.unit}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormprtcDev"
                name="prtcDev"
                label="방호장치"
                value={prtcDev}
                onChange={(value) => changeInput('prtcDev', value)}
                errorMessage={errors.prtcDev}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormposition"
                name="position"
                label="위치"
                value={position}
                onChange={(value) => changeInput('position', value)}
                errorMessage={errors.position}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                label="부문"
                value={sectCd}
                onChange={(value) => changeInput('sectCd', value)}
                required
                disabled={formType !== 'add' ? true : false}
                errorMessage={errors.sectCd}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormdeptCd"
                name="deptCd"
                label="부서"
                value={deptCd}
                onChange={(value) => changeInput('deptCd', value)}
                errorMessage={errors.deptCd}
                required
                // TODO: NEED TO CHECK THIS VALUE AGAIN WHEN IT IS DECIDED.
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormadminEmpno"
                name="adminEmpno"
                label="관리자_사번"
                value={adminEmpno}
                onChange={(value) => changeInput('adminEmpno', value)}
                errorMessage={errors.adminEmpno}
                required
                // TODO: NEED TO ADD _name of Team, Group, Section and the person who is in charge of.
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                label="사용여부"
                codeGrpId="CODE_GRP_OC016"
                value={useYn}
                onChange={(value) => changeInput('useYn', value)}
                errorMessage={errors.useYn}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppDatePicker
                label="도입일자"
                value={intrDt}
                onChange={(value) => changeInput('intrDt', value)}
                errorMessage={errors.intrDt}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppDatePicker
                label="폐기일자"
                value={discardDt}
                onChange={(value) => changeInput('discardDt', value)}
                errorMessage={errors.discardDt}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                label="안전인증"
                codeGrpId="CODE_GRP_PC013"
                value={sftyCrtfcTargetYn}
                onChange={(value) => changeInput('sftyCrtfcTargetYn', value)}
                errorMessage={errors.sftyCrtfcTargetYn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormsftyCrtfcPassNo"
                name="sftyCrtfcPassNo"
                label="안전인증합격번호"
                value={sftyCrtfcPassNo}
                onChange={(value) => changeInput('sftyCrtfcPassNo', value)}
                errorMessage={errors.sftyCrtfcPassNo}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                label="안전_검사대상여부"
                codeGrpId="CODE_GRP_PC013"
                value={sftyAuditTargetYn}
                onChange={(value) => changeInput('sftyAuditTargetYn', value)}
                errorMessage={errors.sftyAuditTargetYn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormpohtoId1"
                name="pohtoId1"
                label="첨부_사진1_ID"
                value={pohtoId1}
                onChange={(value) => changeInput('pohtoId1', value)}
                errorMessage={errors.pohtoId1}
                // TODO: NEED TO CHECK_ATTACHMENTS
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuRiskMachineFormpohtoId2"
                name="pohtoId2"
                label="첨부_사진2_ID"
                value={pohtoId2}
                onChange={(value) => changeInput('pohtoId2', value)}
                errorMessage={errors.pohtoId2}
                // TODO: NEED TO CHECK_ATTACHMENTS
              />
            </div>
          </div>
        </div>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default MachineForm;
