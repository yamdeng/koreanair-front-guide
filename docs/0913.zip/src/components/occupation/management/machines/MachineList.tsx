import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';

// TESTING - 240826_generated

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/machines',
  baseRoutePath: '/occupation/management/machines',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 부문
  sectCd: '',
  // 부서
  deptCd: '',
  // 관리자
  adminEmpno: '',
  // 기계기구
  mchnInstrNm: '',
  // 안전인증
  sftyCrtfcTargetYn: '',
  // 안전검사
  sftyAuditTargetYn: '',
  // 안전검사일자 ~ 차기 안전 검사 일자
  sftyAuditDt: '',
  sftyAuditNextDt: '',
  // 사용여부
  useYn: '',

  //searchWord: '',
};

/* zustand store 생성 */
const OcuRiskMachineListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    // 부문 - selectbox
    sectCd: '',
    // 부서 - search
    deptCd: '',
    // 관리자
    adminEmpno: '',
    // 기계기구
    mchnInstrClsCd: '',
    // 안전인증
    sftyCrtfcTargetYn: '',
    // 안전검사
    sftyAuditTargetYn: '',
    // 안전검사일자 ~ 차기 안전 검사 일자
    fromSftyAuditDt: '',
    toSftyAuditDt: '',
    // 사용여부
    useYn: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function OcuRiskMachineList() {
  const state = OcuRiskMachineListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'sectNm', headerName: '부문' },
      { field: 'deptCd', headerName: '부서' },
      { field: 'mchnInstrClsNm', headerName: '기계기구' },
      { field: 'asetNo', headerName: 'Asset No.' },
      { field: 'adminEmpno', headerName: '관리자' },
      { field: 'sftyCrtfcTargetNm', headerName: '안전인증' },
      { field: 'sftyAuditTargetNm', headerName: '안전검사' },
      { field: 'sftyAuditDt', headerName: '안전 검사일자' },
      { field: 'sftyAuditNextDt', headerName: '차기 안전 검사일자' },
      { field: 'unit', headerName: '용량/단위' },
      { field: 'useNm', headerName: '사용여부' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    goRegisterPage,
    changeSearchInput,
    // initSearchInput,
    // isExpandDetailSearch,
    // toggleExpandDetailSearch,
    clear,
  } = state;
  // TODO : 검색 파라미터 나열
  const {
    sectCd,
    deptCd,
    adminEmpno,
    mchnInstrClsCd,
    sftyCrtfcTargetYn,
    sftyAuditTargetYn,
    fromSftyAuditDt,
    toSftyAuditDt,
    useYn,
  } = searchParam;

  // 그리드 더블 클릭
  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    // 해당 기계기구ID
    const selectedId = data.mchnInstrId;
    goRegisterPage(selectedId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>위험기계기구</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}

      <div className="boxForm">
        {/* <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}> */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'부문'}
                applyAllSelect="true"
                codeGrpId="CODE_GRP_OC001"
                value={sectCd}
                onChange={(value) => {
                  changeSearchInput('sectCd', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppSearchInput
                label="부서"
                value={deptCd}
                onChange={(value) => {
                  changeSearchInput('deptCd', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppSearchInput
                label="관리자"
                value={adminEmpno}
                onChange={(value) => {
                  changeSearchInput('adminEmpno', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'기계기구'}
                applyAllSelect="true"
                codeGrpId="CODE_GRP_OC015"
                value={mchnInstrClsCd}
                onChange={(value) => {
                  changeSearchInput('mchnInstrClsCd', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'안전인증'}
                applyAllSelect="true"
                codeGrpId="CODE_GRP_OC013"
                value={sftyCrtfcTargetYn}
                onChange={(value) => {
                  changeSearchInput('sftyCrtfcTargetYn', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'안전검사'}
                applyAllSelect="true"
                codeGrpId="CODE_GRP_OC013"
                value={sftyAuditTargetYn}
                onChange={(value) => {
                  changeSearchInput('sftyAuditTargetYn', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group form-glow">
              <div className="df">
                <div className="date1">
                  <AppDatePicker
                    label={'안전검사기간'}
                    value={fromSftyAuditDt}
                    onChange={(value) => {
                      changeSearchInput('fromSftyAuditDt', value);
                    }}
                  />
                </div>
                <span className="unt">~</span>
                <div className="date2">
                  <AppDatePicker
                    label={'안전검사기간'}
                    value={toSftyAuditDt}
                    onChange={(value) => {
                      changeSearchInput('toSftyAuditDt', value);
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'사용여부'}
                applyAllSelect="true"
                codeGrpId="CODE_GRP_OC016"
                value={useYn}
                onChange={(value) => {
                  changeSearchInput('useYn', value);
                }}
              />
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              검색
            </button>
          </div>
        </div>
      </div>
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
          다운로드
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          등록
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
    </>
  );
}

export default OcuRiskMachineList;
