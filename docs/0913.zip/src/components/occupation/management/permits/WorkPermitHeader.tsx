import AppNavigation from '@/components/common/AppNavigation';
import WorkPermitList from './WorkPermitList';
import WorkPermitStatus from './WorkPermitStatus';
import { useEffect } from 'react';
import useOcuWorkPermitManageStore from '@/stores/occupation/management/useOcuWorkPermitManageStore';

function WorkPermitHeader() {
  const { tabIndex, changeTab, clear } = useOcuWorkPermitManageStore();

  useEffect(() => {
    changeTab(0);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>{tabIndex == 0 ? '외주작업 현황' : '외주작업 허가'}</h2>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="menu-tab">
          <a
            onClick={() => {
              changeTab(0);
            }}
            className={tabIndex == 0 ? 'active' : ''}
            data-label="현황"
            href={undefined}
          >
            현황
          </a>
          <a onClick={() => changeTab(1)} className={tabIndex == 1 ? 'active' : ''} data-label="조회">
            조회
          </a>
        </div>
      </div>
    </>
  );
}

export default WorkPermitHeader;
