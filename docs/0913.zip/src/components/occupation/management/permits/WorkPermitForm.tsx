import { useEffect, useState } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import useOcuWorkPermitFormStore from '@/stores/occupation/management/useOcuWorkPermitFormStore';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptReadOnlyInput from '@/components/common/AppDeptReadOnlyInput';
import useAppStore from '@/stores/useAppStore';
import { useStore } from 'zustand';
import CommonUtil from '@/utils/CommonUtil';
import AppCheckboxGroup from '@/components/common/AppCheckboxGroup';
import CodeService from '@/services/CodeService';
import WorkPermitEduChoiceModal from './WorkPermitEduChoiceModal';
import { Upload } from 'antd';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function WorkPermitForm() {
  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    save,
    remove,
    cancel,
    clear,
    isEduChoiceModalOpen,
    eduChoiceModalInfo,
    // saveEduChoiceModal,
    openEduChoiceModal,
    closeEduChoiceModal,
    // removeFileAttach,
  } = useOcuWorkPermitFormStore();

  const profile = useStore(useAppStore, (state) => state.profile);
  console.log(profile.userInfo);
  console.log(profile.userInfo.nameKor);

  // 작성자명 가져오기
  const userNm = profile.userInfo.nameKor;
  console.log('userNm : ', userNm);
  // 부서명 가져오기
  const loginDeptCd = profile.userInfo.deptCd;

  const {
    // 부문 코드
    sectCd,
    // 부서코드
    deptCd,
    // 공사 ID
    cntrId,
    // 공사 명
    cntrNm,
    // 공사분야코드
    cntrAreaCd,
    // 특별교육 대상 여부 - 03
    spclEduTargetYn,
    // 시공사
    cnstCmpny,
    // 담당자
    staff,
    // 연락처
    contactNo,
    // 공사장소 ID
    cnstrSiteId,
    // 공사위치명
    cntrPositionNm,
    // 공사인원수
    cntrPrsnCnt,
    // 공사신청시작일시
    cntrApplyStartDttm,
    // 공사 신청 종료 일시
    cntrApplyEndDttm,
    // 사전동의여부
    preConsentYn,
    // // 신청자 사번
    // applyEmpno,
    // // 승인자 사번
    // aprvEmpno,
    // // 승인부서의견
    // aprvDeptOpnn,
    // // 신청 상태 코드
    // applyStatusCd,
    // // 작업 상태 코드
    // wrkStatusCd,
    // // 작업 시작 일시
    // wrkStartDt,
    // // 작업 시작 비고
    // wrkStartRemark,
    // // 작업 시작 첨부 사진1 ID
    // wrkStartPhoto1Id,
    // // 작업 시작 첨부 사진2 ID
    // wrkStartPhoto2Id,
    // 교육일지 첨부 파일 ID
    // eduJrnlFileId,
    // 기타 첨부 파일 ID
    // etcFileId,
    // // 작업 종료 일자
    // wrkEndDt,
    // // 작업 종료 비고
    // wrkEndRemark,
    // 등록 일시
    regDttm,
    // 등록자 ID
    regUserId,
    // 수정 일시
    updDttm,
    // 수정자 ID
    updUserId,
    cntrWrkCd,
  } = formValue;

  const { detailId } = useParams();
  console.log('detailId : ', detailId);
  console.log('regUserId : ', regUserId);

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  // 오늘날짜 가져오기
  const currentDate = CommonUtil.getToDate();
  console.log('currentDate : ' + currentDate);

  // const [dateTimePickerType2Value, setDateTimePickerType2Value] = useState('2024-08-05 23:20');

  // const changeDateTimePickerType2Value = (valueString, valueDate) => {
  //   console.log(`changeDateTimePickerType2Value valueString : ${valueString}`);
  //   console.log(`changeDateTimePickerType2Value valueDate : ${valueDate}`);
  //   setDateTimePickerType2Value(valueString);
  // };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>외주작업허가 등록</h2>
      </div>
      {/* <div className="editbox"> */}
      <div className="info-wrap toggle">
        {/* 신청자정보 */}
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              신청자 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="부문"
                          codeGrpId="CODE_GRP_OC001"
                          value={sectCd} // NEED TO CHANGE LATER
                          onChange={(value) => changeInput('sectCd', value)}
                          required
                          disabled={formType !== 'add' ? true : false}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDeptReadOnlyInput
                          label="부서"
                          value={detailId === 'add' ? loginDeptCd : deptCd}
                          required
                          disabled
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="이름"
                          value={detailId === 'add' ? userNm : regUserId}
                          required
                          disabled="false"
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput label="연락처" value={contactNo} disabled required />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          {/* 공사정보 */}
          <dt>
            <button type="button" className="btn-tg">
              공사 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="공사명"
                          value={cntrNm}
                          onChange={(value) => changeInput('cntrNm', value)}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppCheckboxGroup
                          label="공사분야"
                          options={CodeService.getCodeListByCodeGrpId('CODE_GRP_OC030')}
                          value={cntrAreaCd}
                          labelKey={'codeNameKor'}
                          valueKey={'codeId'}
                          onChange={(value) => {
                            changeInput('cntrAreaCd', value);
                          }}
                        />
                        <span className="txt">공사분야</span>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <span className="txt">특별교육 대상</span>
                        <div className="radio-wrap">
                          <label>
                            <input type="radio" name="spclEduTarget" value="Y" />
                            <span>예</span>
                          </label>
                          <button className="radio-btn" onClick={() => openEduChoiceModal()}>
                            교육내용
                          </button>
                          <WorkPermitEduChoiceModal isOpen={isEduChoiceModalOpen} closeModal={closeEduChoiceModal} />
                          <label>
                            <input type="radio" name="spclEduTarget" value="N" />
                            <span>아니오</span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="시공사"
                          value={cnstCmpny}
                          // placeholder="시공사"
                          onChange={(value) => changeInput('cnstCmpny', value)}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="담당자"
                          value={staff}
                          onChange={(value) => changeInput('staff', value)}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="연락처"
                          value={contactNo}
                          onChange={(value) => changeInput('contactNo', value)}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="공사장소"
                          placeholder="cnstrSiteId"
                          value={cnstrSiteId}
                          onChange={(value) => changeInput('cnstrSiteId', value)}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="공사위치"
                          value={cntrPositionNm}
                          placeholder="공사위치명"
                          onChange={(value) => changeInput('cntrPositionNm', value)}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="공사인원"
                          value={cntrPrsnCnt}
                          onChange={(value) => changeInput('cntrPrsnCnt', value)}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label="공사 시작일시"
                          showTime
                          excludeSecondsTime
                          onChange={(value) => changeInput('cntrApplyStartDttm', value)}
                          value={cntrApplyStartDttm}
                          showNow={true}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* 공사종료일시가 공사 시작일시보다 앞이면 경고창 or 선택불가 필요하지 않을까? */}
                        <AppDatePicker
                          label="공사 종료일시"
                          showTime
                          excludeSecondsTime
                          onChange={(value) => changeInput('cntrApplyEndDttm', value)}
                          value={cntrApplyEndDttm}
                          showNow={true}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  {/* 그리드 시작 */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <h3 className="table-tit">
                          공사구분 <span className="required">*</span>
                        </h3>
                        <div className="work-group">
                          <table className="work-table">
                            <thead>
                              <tr>
                                <th>작업</th>
                                <th>반입장비</th>
                                <th>파일첨부</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">공통(일반)</span>
                                    </label>
                                  </div>
                                </td>
                                <td></td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="filebox ">
                                          <Upload>
                                            <div className="btn-area">
                                              <button
                                                type="button"
                                                name="button"
                                                className="btn-big btn_text btn-darkblue-line mg-n"
                                              >
                                                + Upload
                                              </button>
                                            </div>
                                          </Upload>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">화재위험작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">가스 용접·용단</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">전기·용접</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">연삭기</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="filebox ">
                                          <Upload>
                                            <div className="btn-area">
                                              <button
                                                type="button"
                                                name="button"
                                                className="btn-big btn_text btn-darkblue-line mg-n"
                                              >
                                                + Upload
                                              </button>
                                            </div>
                                          </Upload>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">전기작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">이동식 사다리</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">달비계</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">시저형 고소작업대(렌탈)</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">차량탑재형 고소작업대(스카이차)</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="filebox ">
                                          <Upload>
                                            <div className="btn-area">
                                              <button
                                                type="button"
                                                name="button"
                                                className="btn-big btn_text btn-darkblue-line mg-n"
                                              >
                                                + Upload
                                              </button>
                                            </div>
                                          </Upload>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">고소작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td></td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="filebox ">
                                          <Upload>
                                            <div className="btn-area">
                                              <button
                                                type="button"
                                                name="button"
                                                className="btn-big btn_text btn-darkblue-line mg-n"
                                              >
                                                + Upload
                                              </button>
                                            </div>
                                          </Upload>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">전기작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">이동식 사다리</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">달비계</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">시저형 고소작업대(렌탈)</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">차량탑재형 고소작업대(스카이차)</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="filebox ">
                                          <Upload>
                                            <div className="btn-area">
                                              <button
                                                type="button"
                                                name="button"
                                                className="btn-big btn_text btn-darkblue-line mg-n"
                                              >
                                                + Upload
                                              </button>
                                            </div>
                                          </Upload>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">줄걸이작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">기중기(건설기계)</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">차량탑재형 이동식 크레인(카고크레인)</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="filebox ">
                                          <Upload>
                                            <div className="btn-area">
                                              <button
                                                type="button"
                                                name="button"
                                                className="btn-big btn_text btn-darkblue-line mg-n"
                                              >
                                                + Upload
                                              </button>
                                            </div>
                                          </Upload>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">건설기계 사용작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">굴착기</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">지게차</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">덤프트럭</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">콘크리트믹서트럭</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">이 외</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="filebox ">
                                          <Upload>
                                            <div className="btn-area">
                                              <button
                                                type="button"
                                                name="button"
                                                className="btn-big btn_text btn-darkblue-line mg-n"
                                              >
                                                + Upload
                                              </button>
                                            </div>
                                          </Upload>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">밀폐공간</span>
                                    </label>
                                  </div>
                                </td>
                                <td></td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="filebox ">
                                          <Upload>
                                            <div className="btn-area">
                                              <button
                                                type="button"
                                                name="button"
                                                className="btn-big btn_text btn-darkblue-line mg-n"
                                              >
                                                + Upload
                                              </button>
                                            </div>
                                          </Upload>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              사전동의<span className="active"></span>
            </button>
          </dt>
        </dl>
      </div>
      <dd className="tg-conts">
        <div className="edit-area">
          <div className="detail-form">
            <div className="detail-list">
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <ul className="agree">
                      <li>1. 8시간 이상 진행되는 작업의 경우 작업 종료 후 재시작 시 현장 안전점검 실시</li>
                      <li>2. 현장점검 시 작업에 해당되는 점검표를 활용하여 점검 실시</li>
                      <li>3. 기계⋅전기⋅가스 등의 정지⋅차단 조치가 필요한 경우 Lock-Out, Tag-Out 실시</li>
                      <li>
                        4. 작업종료 후 외주업체 안전교육일지 및 작업 후 조치현황을 작업종료 후 2일 이내 승인부서에 통보
                        할 것
                      </li>
                      <li>5. 현장에서 안전조치 미흡/위반 사례 적발 시 즉시 작업중지 조치 예정</li>
                    </ul>
                    <div className="radio-wrap border-no pd-style">
                      <label>
                        <input type="checkbox" name="preConsentYn" value="Y" />
                        <span>위 사항에 대해 충분히 이해하고 입력한 정보로 작업허가를 신청합니다.</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </dd>

      <hr className="line"></hr>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text btn-del" onClick={cancel}>
          취소
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_conblue">
          임시저장
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
      </div>
    </>
  );
}
export default WorkPermitForm;
