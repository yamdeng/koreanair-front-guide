import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/permits',
  baseRoutePath: '/occupation/management/permits',
};

// 오늘날짜 설정하기
const currentDate = CommonUtil.getToDate();

/* zustand store 생성 */
const OcuOutSourcingListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  // 날짜검색용 초기 값
  duration: ['', ''],

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
    // 기간 검색용 날짜 추가 for AppRangeDatePicker
    set({ duration: [currentDate, currentDate] });
  },

  clear: () => {},
}));

function WorkPermitApproval() {
  const state = OcuOutSourcingListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'cntrLocationNm', headerName: '공사장소' },
      { field: 'cntrPositionNm', headerName: '공사위치' },
      { field: 'cntrAreaNm', headerName: '공사분야' },
      { field: 'cnstCmpny', headerName: '작업구분' },
      { field: 'cntrNm', headerName: '공사명' },
      {
        field: 'cntrApplyStartDttm',
        headerName: '공사기간',
        valueGetter: (p) => p.data.cntrApplyStartDttm + ' ~ ' + p.data.cntrApplyEndDttm,
      },
      { field: 'regUserId', headerName: '신청자' },
      { field: 'applyStatusNm', headerName: '신청상태' },
      { field: 'wrkStatusNm', headerName: '작업상태' },
      // NEED TO ADD LATER -
      { field: 'fileId', headerName: '작업처리' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeStateProps,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;
  // 검색 파라미터 나열
  const {} = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.cntrId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  const customButton = [
    {
      title: '공사장소관리',
      onClick: () => {
        alert('공사장소관리 is not ready yet');
      },
    },
  ];

  return (
    <>
      <div className="conts-title">
        <h2>외주작업 신청 현황</h2>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
        customButtons={customButton}
      />
    </>
  );
}

export default WorkPermitApproval;
