import { useState, useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useParams, useSearchParams } from 'react-router-dom';
import CommonUtil from '@/utils/CommonUtil';
import { Viewer } from '@toast-ui/react-editor';
import AppTable from '@/components/common/AppTable';
import AppFileAttach from '@/components/common/AppFileAttach';

/* TODO : store 경로를 변경해주세요. */
import useOcuCostFormStore from '@/stores/occupation/general/useOcuCostFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCostDetail() {
  /* formStore state input 변수 */
  const { detailInfo, getDetail, cancel, goFormPage, clear, list, search } = useOcuCostFormStore();
  const {
    // 년도
    //planYear,
    // Department
    sectNm,
    // Resp Center
    respCenter,
    // Item
    itemNm,
    // Account Name
    acntNm,
    // Account Cd
    acntCd,
    // Payterm
    payTermNm,
    // Amount
    mainPlanAmt,
    // Total Amount
    mainTotAmt,
    // Description
    lineDesc,
    // 등록자
    regDttm,
    // 등록일자
    regUserId,

    // periodNm,
    // glDt,
    // currencyCd,
    // respCenter,
    // costCenter,
    // acntCd,
    // acntNm,
    // drAmt,
    // crAmt,
    // lineDesc,
    // invoiceNo,
    // vendorNm,
    // execClsCd,
    // regDttm,
    // regUserId,
  } = detailInfo;

  //console.log('detailInfo값===>', detailInfo);

  const [searchParams] = useSearchParams();
  const planYear = searchParams.get('planYear');
  const sectCd = searchParams.get('sectCd');
  const searchRespCenter = searchParams.get('searchRespCenter');
  const itemCd = searchParams.get('itemCd');
  const searchAcntCd = searchParams.get('acntCd');

  const { detailId } = useParams();

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'execYear', headerName: '년도' },
      { field: 'execClsNm', headerName: '구분' },
      { field: 'respCenter', headerName: 'Resp Center' },
      { field: 'costCenter', headerName: 'Cost Center' },
      { field: 'acntCd', headerName: 'Acoount' },
      { field: 'acntNm', headerName: 'Account Name' },
      { field: 'invoiceDt', headerName: 'Invocice Date' },
      { field: 'drCrTotAmt', headerName: 'Amount' },
      { field: 'vendorNm', headerName: 'Supplier' },
      { field: 'invoiceNo', headerName: 'Invoice Number' },
      { field: 'glDt', headerName: 'GL Date' },
      { field: 'lineDesc', headerName: 'Description' },
      // { field: 'statRemark', headerName: '등록자' },
      // { field: 'statRemark', headerName: '등록일자' },
    ])
  );

  const init = async () => {
    await getDetail(planYear, sectCd, searchRespCenter, itemCd, searchAcntCd);
    search();
  };

  useEffect(() => {
    init();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>산업안전보건관리비</h2>
      </div>
      {/* 상세영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              계획<span className="hide"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">년도</label>
                              <span className="text-desc-type1">{planYear}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">부문</label>
                              <span className="text-desc-type1">{sectNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Resp Center</label>
                              <span className="text-desc-type1">{respCenter}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Item</label>
                              <span className="text-desc-type1">{itemNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Account Name</label>
                              <span className="text-desc-type1">{acntNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Account</label>
                              <span className="text-desc-type1">{acntCd}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Payterm</label>
                              <span className="text-desc-type1">{payTermNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Amount</label>
                              <span className="text-desc-type1">{mainPlanAmt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Total Amount</label>
                              <span className="text-desc-type1">{mainTotAmt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Description</label>
                              <span className="text-desc-type1">{lineDesc}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">등록자</label>
                              <span className="text-desc-type1">{regUserId}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">등록일자</label>
                              <span className="text-desc-type1">{regDttm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/*//상세영역*/}
      {/*그리드영역 */}
      <div className="edit-area pt-20">
        <h3 className="table-tit">실적</h3>
        {/* <AppTable rowData={list} columns={columns} setColumns={setColumns} customButtons={customButtons} /> */}
        <AppTable rowData={list} columns={columns} setColumns={setColumns} />
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          수정
        </button>
      </div>
    </>
  );
}
export default OcuCostDetail;
