import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';
import CostList from '@/components/occupation/general/cost/CostList';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
import AppTextInput from '@/components/common/AppTextInput';
import AppSelect from '@/components/common/AppSelect';

import {
  useOcuCostListStore,
  stateSectStore,
  stateRespCenterStore,
  stateExecStore,
} from '@/stores/occupation/general/useOcuCostListStore';

import history from '@/utils/history';

function OcuCostExecList() {
  const state = useOcuCostListStore();
  const stateSect = stateSectStore();
  const stateRespCenter = stateRespCenterStore();
  const stateExec = stateExecStore();

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호' },
      { field: 'planYear', headerName: '년도' },
      { field: 'sectNm', headerName: '부문' },
      { field: 'planTot', headerName: '계획' },
      { field: 'execTot', headerName: '실적' },
      { field: 'ratioTot', headerName: '실적비' },
    ])
  );

  const [columns2, setColumns2] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호' },
      { field: 'respCenter', headerName: 'Resp Center' },
      { field: 'acntNm', headerName: 'Account Name' },
      { field: 'planTot', headerName: '계획' },
      { field: 'execTot', headerName: '실적' },
      { field: 'ratioTot', headerName: '실적비' },
    ])
  );

  const [columns3, setColumns3] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호' },
      { field: 'execYear', headerName: '년도' },
      { field: 'execClsNm', headerName: '구분' },
      { field: 'respCenter', headerName: 'Resp Center' },
      { field: 'costCenter', headerName: 'Cost Center' },
      { field: 'acntCd', headerName: 'Acoount' },
      { field: 'acntNm', headerName: 'Account Name' },
      { field: 'invoiceDt', headerName: 'Invocice Date' },
      { field: 'drCrTotAmt', headerName: 'Amount' },
      { field: 'vendorNm', headerName: 'Supplier' },
      { field: 'invoiceNo', headerName: 'Invoice Number' },
      { field: 'glDt', headerName: 'GL Date' },
      { field: 'lineDesc', headerName: 'Description' },
    ])
  );

  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    //initSearchInput,
    //isExpandDetailSearch,
    //toggleExpandDetailSearch,
    clear,
    search,
    goDetailPage,
    //selectRespCenter
  } = state;

  // TODO : 검색 파라미터 나열
  const { planYear, sectCd, respCenter, itemCd, acntCd } = searchParam;

  // 부문별
  const handleRowSingleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;

    console.log('data1==> ', data);

    const keyData = {
      // 년도
      planYear: data.planYear,
      // 부문
      sectCd: data.sectCd,
      // Resp Center
      respCenter: data.respCenter,
      // Account
      acntCd: data.acntCd,
    };

    // Resp Center 조회
    stateRespCenter.search(keyData, 'C');
  }, []);

  // Resp Center
  const handleRowSingleClick2 = useCallback((selectedInfo) => {
    const data = selectedInfo.data;

    console.log('data2==> ', data);

    const keyData = {
      // 년도
      planYear: data.planYear,
      // 부문
      sectCd: data.sectCd,
      // Resp Center
      respCenter: data.respCenter,
      // Account
      acntCd: data.acntCd,
    };

    // 어카운트별 실적 조회
    stateExec.search(keyData, 'C');
  }, []);

  const handleRowSingleClick3 = useCallback((selectedInfo) => {
    const data = selectedInfo.data;

    console.log('data3==> ', data);

    // 년도, 부문, 부서, account, Item
    // const keyData = {
    //   planYear: data.planYear,
    //   sectCd: data.sectCd,
    //   respCenter: data.respCenter,
    //   itemCd: data.itemCd,
    //   acntCd: data.acntCd,
    // };
  }, []);

  useEffect(() => {
    state.search('C');
    //useOcuCostListStore.search();
    return clear;
  }, []);

  const changeCostTap = () => {
    history.push('costList');
  };

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>산업안전보건관리비</h2>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="menu-tab">
          <a href={undefined} data-label="현황" className="active">
            현황
          </a>
          <a href={undefined} data-label="목록" onClick={changeCostTap}>
            목록
          </a>
        </div>
      </div>
      {/*//탭 */}
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDatePicker
                  label={'년도'}
                  pickerType="year"
                  value={planYear}
                  onChange={(value) => {
                    changeSearchInput('planYear', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="부문"
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC001"
                  value={sectCd}
                  onChange={(value) => {
                    changeSearchInput('sectCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDeptSelectInput
                  label="Resp Center"
                  value={respCenter}
                  onChange={(value) => {
                    changeSearchInput('respCenter', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="Account Name"
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC045"
                  value={acntCd}
                  onChange={(value) => {
                    changeSearchInput('acntCd', value);
                  }}
                />
              </div>
            </div>
            <div className="btn-area">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={search}>
                조회
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* //검색영역 */}
      {/*그리드영역 */}

      <div className="table-wrap">
        <div className="left-table">
          <AppTable
            rowData={stateSect.list}
            columns={columns}
            className="h300"
            store={stateSect}
            handleRowSingleClick={handleRowSingleClick}
            hiddenPagination
          />
        </div>
        <div className="right-table">
          <AppTable
            rowData={stateRespCenter.list}
            columns={columns2}
            className="h300"
            store={stateRespCenter}
            handleRowSingleClick={handleRowSingleClick2}
            hiddenPagination
          />
        </div>
      </div>
      <AppTable
        rowData={stateExec.list}
        columns={columns3}
        store={stateExec}
        handleRowSingleClick={handleRowSingleClick3}
        hiddenPagination
      />

      {/*//그리드영역 */}
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default OcuCostExecList;
