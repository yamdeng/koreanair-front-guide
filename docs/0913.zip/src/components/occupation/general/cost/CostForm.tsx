import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
import CostExecFormModal from '@/components/modal/occupation/CostExecFormModal ';
import CommonUtil from '@/utils/CommonUtil';
import { useCallback, useEffect, useState } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';

/* TODO : store 경로를 변경해주세요. */
import useOcuCostFormStore from '@/stores/occupation/general/useOcuCostFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCostDetail() {
  /* formStore state input 변수 */
  const {
    formValue,
    getDetail,
    cancel,
    goFormPage,
    openFormModal,
    clear,
    list,
    search,
    errors,
    changeInput,
    remove,
    costSave,
    isCodeFormModalOpen,
    closeFormModal,
    okModal,
    removeByIndex,
    gridChangeStatus,
    list2,
  } = useOcuCostFormStore();
  const {
    // 년도
    //planYear,
    // Department
    sectNm,
    // Cost Center
    respCenter,
    // Item
    itemCd,
    // Account Name
    acntNm,
    // Account Cd
    acntCd,
    // Payterm
    payTerm,
    // Amount
    mainPlanAmt,
    // Total Amount
    mainTotAmt,
    // Description
    lineDesc,
    // 등록자
    regDttm,
    // 등록일자
    regUserId,
    // 저장 구분 값
    saveGubun,
    // 실적 구분 코드
    execClsCd,

    // periodNm,
    // glDt,
    // currencyCd,
    // respCenter,
    // costCenter,
    // acntCd,
    // acntNm,
    // drAmt,
    // crAmt,
    // lineDesc,
    // invoiceNo,
    // vendorNm,
    // execClsCd,
    // regDttm,
    // regUserId,
  } = formValue;

  //console.log('detailInfo값===>', detailInfo);

  const [searchParams] = useSearchParams();
  const planYear = searchParams.get('planYear');
  const sectCd = searchParams.get('sectCd');
  const searchRespCenter = searchParams.get('searchRespCenter');
  const itemCdValue = searchParams.get('itemCd');
  const searchAcntCd = searchParams.get('acntCd');

  const { detailId } = useParams();

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      //{ field: 'status', headerName: '상태' },
      { field: 'execYear', headerName: '년도' },
      { field: 'execClsNm', headerName: '구분' },
      { field: 'respCenter', headerName: 'Resp Center' },
      { field: 'costCenter', headerName: 'Cost Center' },
      { field: 'acntCd', headerName: 'Acoount' },
      { field: 'acntNm', headerName: 'Account Name' },
      { field: 'invoiceDt', headerName: 'Invocice Date' },
      { field: 'drCrTotAmt', headerName: 'Amount' },
      { field: 'vendorNm', headerName: 'Supplier' },
      { field: 'invoiceNo', headerName: 'Invoice Number' },
      { field: 'glDt', headerName: 'GL Date' },
      { field: 'lineDesc', headerName: 'Description' },
      // { field: 'statRemark', headerName: '등록자' },
      // { field: 'statRemark', headerName: '등록일자' },
      {
        pinned: 'right',
        field: 'action',
        headerName: '',
        cellRenderer: 'deleteActionButton',
        cellRendererParams: {
          onClick: removeByIndex,
        },
      },
    ])
  );

  const init = async () => {
    await getDetail(planYear, sectCd, searchRespCenter, itemCdValue, searchAcntCd);
    search();
  };

  useEffect(() => {
    init();
    return clear;
  }, []);

  const DeleteActionButton = (props) => {
    const { node, onClick, data } = props;
    const { rowIndex } = node;
    const handleClick = (event) => {
      gridChangeStatus(props);
      event.stopPropagation();
      event.preventDefault();
      event.nativeEvent.stopPropagation();
      onClick(rowIndex);
    };
    // ERP인 경우
    if (data.execClsCd === 'B') {
      return <div onClick={handleClick}>삭제</div>;
    }
  };

  // Amount 변경시 Total Amount 계산
  const changePlanAmt = (gubun, v) => {
    // Amount, payTerm
    if (!v || !formValue.payTerm) {
      // Total Amount
      formValue.mainTotAmt = '';
    } else {
      // Total Amount
      if (formValue.payTerm == 'A') {
        formValue.mainTotAmt = v;
      } else if (formValue.payTerm == 'B') {
        formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 2);
      } else if (formValue.payTerm == 'C') {
        formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 4);
      } else if (formValue.payTerm == 'D') {
        formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 12);
      }
    }

    changeInput(gubun, v);

    //formValue.totAmt = '12';
  };

  // payTerm 변경시 Total Amount 계산
  const changePayTerm = (gubun, v) => {
    console.log('v==>', v);
    // Amount, payTerm
    if (!v || !formValue.mainPlanAmt) {
      // Total Amount
      formValue.totAmt = '';
    } else {
      // Total Amount
      if (v == 'A') {
        formValue.mainTotAmt = formValue.mainPlanAmt;
      } else if (v == 'B') {
        formValue.mainTotAmt = Math.floor(formValue.mainPlanAmt.replaceAll(',', '') * 2);
        //detailInfo.mainTotAmt = detailInfo.mainPlanAmt.replaceAll(',', '') / 2;
      } else if (v == 'C') {
        formValue.mainTotAmt = Math.floor(formValue.mainPlanAmt.replaceAll(',', '') * 4);
        //detailInfo.mainTotAmt = detailInfo.mainPlanAmt / 4;
      } else if (v == 'D') {
        formValue.mainTotAmt = Math.floor(formValue.mainPlanAmt.replaceAll(',', '') * 12);
        //detailInfo.mainTotAmt = detailInfo.mainPlanAmt / 12;
      }
    }

    changeInput(gubun, v);
  };

  // 실적 등록 버튼
  const customButtons = [
    {
      title: '실적 등록',
      onClick: () => {
        // 산업안전보건 관리비 실적 등록
        costExecInsert();
      },
    },
  ];

  // 산업안전보건 관리비 실적 등록
  const costExecInsert = () => {
    openFormModal('I');
  };

  // 그리드 더블 클릭
  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    data.sectCd = sectCd;

    console.log('data==>', data);
    // 실적 등록 팝업
    openFormModal('U', data);
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>산업안전보건관리비</h2>
      </div>
      {/* 상세영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              계획<span className="hide"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">년도</label> */}
                        <AppTextInput
                          label="년도"
                          value={planYear}
                          onChange={(value) => changeInput('planYear', value)}
                          required
                          disabled
                          errorMessage={errors.planYear}
                        />
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Department</label>
                              <span className="text-desc-type1">{sectNm}</span> */}
                        <AppTextInput
                          label="부문"
                          value={sectNm}
                          onChange={(value) => changeInput('sectNm', value)}
                          required
                          disabled
                          errorMessage={errors.sectNm}
                        />
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">Cost Center</label>
                        <span className="text-desc-type1">{costCenter}</span> */}
                        <AppTextInput
                          label="Resp Center"
                          value={respCenter}
                          onChange={(value) => changeInput('respCenter', value)}
                          required
                          disabled
                          errorMessage={errors.respCenter}
                        />
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">Item</label>
                              <span className="text-desc-type1">{itemNm}</span> */}
                        <AppCodeSelect
                          label="Item"
                          codeGrpId="CODE_GRP_OC017"
                          value={itemCd}
                          onChange={(value) => changeInput('itemCd', value)}
                          required
                          //disabled
                          errorMessage={errors.itemCd}
                        />
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">Account Name</label>
                              <span className="text-desc-type1">{acntNm}</span> */}
                        <AppTextInput
                          label="Account Name"
                          value={acntNm}
                          onChange={(value) => changeInput('acntNm', value)}
                          required
                          disabled
                          errorMessage={errors.acntNm}
                        />
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">Account</label>
                        <span className="text-desc-type1">{acntCd}</span> */}
                        <AppTextInput
                          label="Account"
                          value={acntCd}
                          onChange={(value) => changeInput('acntCd', value)}
                          required
                          disabled
                          errorMessage={errors.acntCd}
                        />
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">Payterm</label>
                        <span className="text-desc-type1">{payTermNm}</span> */}
                        <AppCodeSelect
                          label="Payterm"
                          codeGrpId="CODE_GRP_OC018"
                          value={payTerm}
                          onChange={(value) => {
                            //changeInput('payTerm', value);
                            changePayTerm('payTerm', value);
                          }}
                          required
                          errorMessage={errors.payTerm}
                        />

                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">Amount</label>
                        <span className="text-desc-type1">{mainPlanAmt}</span> */}
                        <AppTextInput
                          label="Amount"
                          value={mainPlanAmt}
                          //inputType="number"
                          onChange={(value) => changePlanAmt('mainPlanAmt', value)}
                          //required
                          errorMessage={errors.mainPlanAmt}
                        />
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">Total Amount</label>
                        <span className="text-desc-type1">{mainTotAmt}</span> */}
                        <AppTextInput
                          label="Total Amount"
                          value={mainTotAmt}
                          onChange={(value) => changeInput('mainTotAmt', value)}
                          //required
                          disabled
                          errorMessage={errors.mainTotAmt}
                        />
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">Description</label>
                        <span className="text-desc-type1">{lineDesc}</span> */}
                        <AppTextInput
                          label="Description"
                          value={lineDesc}
                          onChange={(value) => changeInput('lineDesc', value)}
                          // required
                          errorMessage={errors.lineDesc}
                        />

                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">등록자</label>
                        <span className="text-desc-type1">{regUserId}</span> */}
                        <AppTextInput
                          label="등록자"
                          value={regUserId}
                          onChange={(value) => changeInput('regUserId', value)}
                          required
                          disabled
                          errorMessage={errors.regUserId}
                        />

                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list"> */}
                        {/* <label className="t-label">등록일자</label>
                        <span className="text-desc-type1">{regDttm}</span> */}
                        <AppTextInput
                          label="등록일자"
                          value={regDttm}
                          onChange={(value) => changeInput('regDttm', value)}
                          required
                          disabled
                          errorMessage={errors.regDttm}
                        />
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/*//상세영역*/}
      {/*그리드영역 */}
      <div className="edit-area pt-20">
        <h3 className="table-tit">실적</h3>
        {/* <AppTable rowData={list} columns={columns} setColumns={setColumns} customButtons={customButtons} /> */}
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          customButtons={customButtons}
          handleRowDoubleClick={handleRowDoubleClick}
          components={{
            deleteActionButton: DeleteActionButton,
          }}
        />
      </div>

      <CostExecFormModal isOpen={isCodeFormModalOpen} closeModal={closeFormModal} ok={okModal} />

      {/* 저장, 삭제, 취소  */}
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={costSave}>
          저장
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={remove}>
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>

      {/* 하단 버튼 영역 */}
      {/* <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          수정
        </button>
      </div> */}
    </>
  );
}
export default OcuCostDetail;
