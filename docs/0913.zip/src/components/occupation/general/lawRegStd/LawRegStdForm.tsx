import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';

/* TODO : store 경로를 변경해주세요. */
import useOcuLawRegStdFormStore from '@/stores/occupation/general/useOcuLawRegStdFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuLawRegInfoForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    useOcuLawRegStdFormStore();

  const {
    lawId,
    lawSeq,
    lawKind,
    fearDt,
    implDt,
    lgsltKind,
    respMinistryNm,
    lawDtlLink,
    revisionCn,
    inflDegreeEval,
    keyWordContent,
    aprvId,
  } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>TODO : 헤더 타이틀</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormlawId"
                name="lawId"
                label="법령_ID@"
                value={lawId}
                onChange={(value) => changeInput('lawId', value)}
                errorMessage={errors.lawId}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormlawSeq"
                name="lawSeq"
                label="법령_일련번호"
                value={lawSeq}
                onChange={(value) => changeInput('lawSeq', value)}
                errorMessage={errors.lawSeq}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormlawKind"
                name="lawKind"
                label="법령_종류"
                value={lawKind}
                onChange={(value) => changeInput('lawKind', value)}
                errorMessage={errors.lawKind}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormfearDt"
                name="fearDt"
                label="공포일자"
                value={fearDt}
                onChange={(value) => changeInput('fearDt', value)}
                errorMessage={errors.fearDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormimplDt"
                name="implDt"
                label="시행일자"
                value={implDt}
                onChange={(value) => changeInput('implDt', value)}
                errorMessage={errors.implDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormlgsltKind"
                name="lgsltKind"
                label="제개정_종류"
                value={lgsltKind}
                onChange={(value) => changeInput('lgsltKind', value)}
                errorMessage={errors.lgsltKind}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormrespMinistryNm"
                name="respMinistryNm"
                label="소관_부처"
                value={respMinistryNm}
                onChange={(value) => changeInput('respMinistryNm', value)}
                errorMessage={errors.respMinistryNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormlawDtlLink"
                name="lawDtlLink"
                label="법령_상세_링크"
                value={lawDtlLink}
                onChange={(value) => changeInput('lawDtlLink', value)}
                errorMessage={errors.lawDtlLink}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormrevisionCn"
                name="revisionCn"
                label="개정_내용"
                value={revisionCn}
                onChange={(value) => changeInput('revisionCn', value)}
                errorMessage={errors.revisionCn}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoForminflDegreeEval"
                name="inflDegreeEval"
                label="영향도_평가"
                value={inflDegreeEval}
                onChange={(value) => changeInput('inflDegreeEval', value)}
                errorMessage={errors.inflDegreeEval}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormkeyWordContent"
                name="keyWordContent"
                label="키워드_내용"
                value={keyWordContent}
                onChange={(value) => changeInput('keyWordContent', value)}
                errorMessage={errors.keyWordContent}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuLawRegInfoFormaprvId"
                name="aprvId"
                label="승인_ID(승인자)"
                value={aprvId}
                onChange={(value) => changeInput('aprvId', value)}
                errorMessage={errors.aprvId}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuLawRegInfoForm;
