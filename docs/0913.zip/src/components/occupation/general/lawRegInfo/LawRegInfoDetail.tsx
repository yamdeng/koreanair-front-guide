import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useParams } from 'react-router-dom';
import { Viewer } from '@toast-ui/react-editor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppTextInput from '@/components/common/AppTextInput';
import AppAutoComplete from '@/components/common/AppAutoComplete';

import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';

/* TODO : store 경로를 변경해주세요. */
import useOcuLawRegInfoFormStore from '@/stores/occupation/general/useOcuLawRegInfoFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuLawRegInfoDetail() {
  /* formStore state input 변수 */
  const { detailInfo, getDetail, formType, cancel, goFormPage, clear } = useOcuLawRegInfoFormStore();
  const {
    // 법규명
    lawNm,
    // 법령일련번호
    lawSeq,
    // 법령종류
    lawKind,
    // 공포일자
    fearDt,
    // 시행일자
    implDt,
    // 제개정 종류
    lgsltKind,
    // 소관부처
    respMinistryNm,
    // 법령상세링크
    lawDtlLink,
    // 주관부서
    subjectDeptCd,
    // 개정 내용
    revisionCn,
    // 영향도 평가
    inflDegreeEval,
    // Keyword
    keyWordContent,
    // 평가자
    evalId,
    // 승인자
    aprvId,
    // 해당 부서
    rlvtDeptCd,

    aprvStat,
  } = detailInfo;

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  // 법 api url이동
  const lawOpenApiUrlGo = () => {
    const lawUrl = 'https://www.law.go.kr' + lawDtlLink;
    window.open(lawUrl, '_blank');
  };

  const profile = useStore(useAppStore, (state) => state.profile);

  return (
    <>
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>법규등록대장</h2>
      </div>
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              기준정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">법규명</label>
                              <span className="text-desc-type1">{lawNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">법령 일련번호</label>
                              <span className="text-desc-type1">{lawSeq}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">법령종류</label>
                              <span className="text-desc-type1">{lawKind}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공포일자(개정)</label>
                              <span className="text-desc-type1">{fearDt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">시행일자</label>
                              <span className="text-desc-type1">{implDt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">제개정종류</label>
                              <span className="text-desc-type1">{lgsltKind}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">소관부처</label>
                              <span className="text-desc-type1">{respMinistryNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">법령 상세 링크</label>
                              <span className="text-desc-type1">{lawDtlLink}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">주관 부서</label>
                              <span className="text-desc-type1">{subjectDeptCd}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="btn-area">
                        <button
                          type="button"
                          name="button"
                          className="btn-sm btn_text btn-darkblue-line"
                          onClick={lawOpenApiUrlGo}
                        >
                          법령 보기
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              영향도 평가<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">개정 내용</label>
                              <span className="text-desc-type1">{revisionCn}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">영향도 평가</label>
                              <span className="text-desc-type1">{inflDegreeEval}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">Keyword</label>
                              <span className="text-desc-type1">{keyWordContent}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">평가자</label>
                              <span className="text-desc-type1">{evalId}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">승인자</label>
                              <span className="text-desc-type1">{aprvId}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              해당 부서<span className="active"></span>
              {/* rlvtDeptCd */}
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">그리드영역</div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          수정
        </button>
      </div>
    </>
  );
}
export default OcuLawRegInfoDetail;
