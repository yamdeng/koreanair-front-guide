function OccupationPortal() {
  return <div>OccupationPortal</div>;
}

export default OccupationPortal;
