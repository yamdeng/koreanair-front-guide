function ReportDSREditForm() {
  return <div>ReportDSREditForm</div>;
}
export default ReportDSREditForm;
