import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppEditor from '@/components/common/AppEditor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppSelect from '@/components/common/AppSelect';
import AppTextArea from '@/components/common/AppTextArea';
import AppTextInput from '@/components/common/AppTextInput';
import AppTimePicker from '@/components/common/AppTimePicker';
import Code from '@/config/Code';
import CodeService from '@/services/CodeService';
import useAsrFormStore from '@/stores/aviation/report/useAsrFormStore';
import AirportSearch from '../../common/AirportSearch';
import AvnReportUserSelectType2 from '../../common/AvnReportUserSelectType2';

function ReportASREditForm() {
  const {
    filghtExpanded,
    eventExpanded,
    weatherExpaned,
    birdExapned,
    userSelectKind,
    changeStateProps,
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    tempSave,
    save,
    remove,
    cancel,
    clear,
    searchFligh,
    toggleAccordionExpanded,
    onSelectFlightCrewList,
    deleteFlightCrewList,
  } = useAsrFormStore();

  const { flight, flightCrew, event, weather, bird } = formValue;

  const {
    departureDt,
    flightNo,
    regNo,
    aircraftTypeCd,
    departureAirportCd,
    arrivalAirportCd,
    divertAirportCd,
    stdTime,
    staTime,
    atdTime,
    ataTime,
    delayedMinCo,
    supplyNm,
    checkinNm,
  } = flight;

  const {
    occurPlaceNm,
    occurAirportCd,
    runwayNm,
    occurDttm,
    flightPhaseCd,
    altitudeUnitCd,
    altitudeCo,
    speedUnitCd,
    speedCo,
    subjectNm,
    descriptionTxtcn,
    fileGroupSeq,
  } = event;

  const {
    metCd,
    windOneCo,
    windTwoCo,
    gustCo,
    visibilityNm,
    cloudCd,
    tempCo,
    weatherCodeList,
    altimeterUnitCd,
    altimeterCo,
  } = weather;

  const {
    birdTypeNm,
    birdSizeCd,
    birdCoCd,
    struckBirdCoCd,
    timeTypeCd,
    landingLightYn,
    pilotWarnedYn,
    impactTimeNm,
    birdDescriptionCn,
  } = bird;

  return (
    <>
      <AppNavigation appendTitleList={['ASR']} />

      <div className="info-wrap toggle">
        <dl className="{firstExpaned ? 'tg-item active' : 'tg-item'}">
          {/* 비행정보 */}
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              비행정보
              <span
                className={filghtExpanded ? 'active' : ''}
                onClick={() => toggleAccordionExpanded('filghtExpanded')}
              ></span>
              <div className="tag-info-wrap-end">
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      보고서 작성 가이드
                    </a>
                  </div>
                </div>
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      의무보고의 범위
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: filghtExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="df">
                          <div className="type3">
                            <AppDatePicker
                              label="출발일자"
                              valueFormat="YYYYMMDD"
                              value={departureDt}
                              onChange={(value) => {
                                changeInput('flight.departureDt', value);
                              }}
                              required
                              errorMessage={errors['flight.departureDt']}
                            />
                          </div>
                          <div className="type4">
                            <AppSelect disabled value="UTC" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group va-t ant-input wid100">
                        <span className="ant-input-group-addon1">KE</span>
                        <div className="ant-input-group-addon1-input wid50 df">
                          {/*비행편명 */}
                          <AppSearchInput
                            label="비행편명"
                            value={flightNo}
                            onChange={(value) => {
                              changeInput('flight.flightNo', value);
                            }}
                            search={searchFligh}
                            required
                            hiddenClearButton
                            errorMessage={errors['flight.flightNo']}
                          />
                          <div className="btn-area">
                            <button
                              type="button"
                              name="button"
                              className="btn-sm btn_text btn-darkblue-line"
                              onClick={searchFligh}
                            >
                              Search
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group va-t ant-input wid100">
                        <span className="ant-input-group-addon1">HL</span>
                        <div className="ant-input-group-addon1-input wid50">
                          {/*등록기호 */}
                          <AppTextInput
                            label="등록부호"
                            value={regNo}
                            onChange={(value) => {
                              changeInput('flight.regNo', value);
                            }}
                            required
                            errorMessage={errors['flight.regNo']}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*항공기형식 */}
                        <AppCodeSelect
                          label="항공기형식"
                          codeGrpId="CODE_GRP_159"
                          value={aircraftTypeCd}
                          onChange={(value) => {
                            changeInput('flight.aircraftTypeCd', value);
                          }}
                          required
                          errorMessage={errors['flight.aircraftTypeCd']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*출발공항 */}
                        <AirportSearch
                          label="출발공항"
                          value={departureAirportCd}
                          onChange={(value) => {
                            changeInput('flight.departureAirportCd', value);
                          }}
                          required
                          errorMessage={errors['flight.departureAirportCd']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AirportSearch
                          label="도착공항"
                          value={arrivalAirportCd}
                          onChange={(value) => {
                            changeInput('flight.arrivalAirportCd', value);
                          }}
                          required
                          errorMessage={errors['flight.arrivalAirportCd']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*회항공항 */}
                        <AirportSearch
                          label="회항공항"
                          value={divertAirportCd}
                          onChange={(value) => {
                            changeInput('flight.divertAirportCd', value);
                          }}
                          required
                          errorMessage={errors['flight.divertAirportCd']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*STD */}
                        <AppTimePicker
                          label={'STD'}
                          excludeSecondsTime
                          value={stdTime}
                          valueFormat="HHmm"
                          displayFormat="HH:mm"
                          onChange={(value) => {
                            changeInput('flight.stdTime', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*STA */}
                        <AppTimePicker
                          label={'STA'}
                          excludeSecondsTime
                          value={staTime}
                          valueFormat="HHmm"
                          displayFormat="HH:mm"
                          onChange={(value) => {
                            changeInput('flight.staTime', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*ATD */}
                        <AppTimePicker
                          label={'ATD'}
                          excludeSecondsTime
                          value={atdTime}
                          valueFormat="HHmm"
                          displayFormat="HH:mm"
                          onChange={(value) => {
                            changeInput('flight.atdTime', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*ATA */}
                        <AppTimePicker
                          label={'ATA'}
                          excludeSecondsTime
                          value={ataTime}
                          valueFormat="HHmm"
                          displayFormat="HH:mm"
                          onChange={(value) => {
                            changeInput('flight.ataTime', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*Delay */}
                        <AppTextInput
                          inputType={'number'}
                          label="Delay"
                          value={delayedMinCo}
                          onChange={(value) => {
                            changeInput('flight.delayedMinCo', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="좌석수(F/C/Y)"
                          value={supplyNm}
                          onChange={(value) => {
                            changeInput('flight.supplyNm', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="탑승자(F/C/Y)"
                          value={checkinNm}
                          onChange={(value) => {
                            changeInput('flight.checkinNm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid50">
                        <AvnReportUserSelectType2
                          label="비행승무원"
                          userList={flightCrew}
                          onSelect={onSelectFlightCrewList}
                          deleteUser={deleteFlightCrewList}
                          changeUserSelectKind={(value) => changeStateProps('userSelectKind', value)}
                          userSelectKind={userSelectKind}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        {/* 이벤트 */}
        <dl className={eventExpanded ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button type="button" className="btn-tg">
              이벤트
              <span
                className={eventExpanded ? 'active' : ''}
                onClick={() => toggleAccordionExpanded('eventExpanded')}
              ></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid50">
                        {/*발생위치 */}
                        <AppTextInput
                          label="발생위치"
                          toolTipMessage="자유형식으로 입력가능
                          예)Waypoint, 이륙 후3시간 경과 시점 등"
                          value={occurPlaceNm}
                          onChange={(value) => {
                            changeInput('event.occurPlaceNm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*발생공항 */}
                        <AirportSearch
                          label="발생공항"
                          value={occurAirportCd}
                          onChange={(value) => {
                            changeInput('event.occurAirportCd', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*통로 */}
                        <AppTextInput
                          label="통로"
                          value={runwayNm}
                          onChange={(value) => {
                            changeInput('event.runwayNm', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="df">
                          <div className="type3">
                            <AppDatePicker
                              label="발생시간"
                              excludeSecondsTime
                              showTime
                              value={occurDttm}
                              onChange={(value) => {
                                changeInput('event.occurDttm', value);
                              }}
                            />
                          </div>
                          <div className="type4">
                            <AppSelect disabled value="UTC" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid50">
                        {/*비행단계 */}
                        <AppCodeSelect
                          label="비행단계"
                          codeGrpId="CODE_GRP_002"
                          value={flightPhaseCd}
                          onChange={(value) => {
                            changeInput('event.flightPhaseCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <div className="df">
                              <div className="type1">
                                <AppTextInput
                                  inputType={'number'}
                                  value={altitudeCo}
                                  onChange={(value) => {
                                    changeInput('event.altitudeCo', value);
                                  }}
                                />
                                <label className="file-label">Altitude</label>
                              </div>
                              <div className="type2">
                                {/*Altitude 선택 */}
                                <AppCodeSelect
                                  codeGrpId="CODE_GRP_004"
                                  value={altitudeUnitCd}
                                  onChange={(value) => {
                                    changeInput('event.altitudeUnitCd', value);
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <div className="df">
                              <div className="type1">
                                <AppTextInput
                                  inputType={'number'}
                                  value={speedCo}
                                  onChange={(value) => {
                                    changeInput('event.speedCo', value);
                                  }}
                                />
                                <label className="file-label">Speed</label>
                              </div>
                              <div className="type2">
                                {/*Speed 선택 */}
                                <AppCodeSelect
                                  codeGrpId="CODE_GRP_003"
                                  value={speedUnitCd}
                                  onChange={(value) => {
                                    changeInput('event.speedUnitCd', value);
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="제목"
                          value={subjectNm}
                          onChange={(value) => {
                            changeInput('event.subjectNm', value);
                          }}
                          required
                          errorMessage={errors['event.subjectNm']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap1 wid100 ">
                        <span className="txt">
                          내용 <span className="required">*</span>
                        </span>
                        <div className="round-wrap">
                          {/*개요 */}
                          <AppEditor
                            label="AppEditor"
                            value={descriptionTxtcn}
                            onChange={(value) => {
                              changeInput('event.descriptionTxtcn', value);
                            }}
                            required
                            errorMessage={errors['event.descriptionTxtcn']}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* 파일첨부영역 : drag */}
                  <div className="form-table ">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* 파일첨부영역 : drag */}
                        <AppFileAttach
                          label={'첨부파일'}
                          fileGroupSeq={fileGroupSeq}
                          workScope={'A'}
                          updateFileGroupSeq={(newFileGroupSeq) => {
                            changeInput('event.fileGroupSeq', newFileGroupSeq);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        {/* 날씨 */}
        <dl className={weatherExpaned ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button type="button" className="btn-tg">
              날씨
              <span
                className={weatherExpaned ? 'active' : ''}
                onClick={() => toggleAccordionExpanded('weatherExpaned')}
              ></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: weatherExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid50">
                        {/*Met */}
                        <AppCodeSelect
                          label="Met"
                          codeGrpId="CODE_GRP_005"
                          value={metCd}
                          onChange={(value) => {
                            changeInput('weather.metCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <div className="flex-between">
                              <div className="flex-start">
                                <div className="type5">
                                  <AppTextInput
                                    inputType={'number'}
                                    label={'바람1'}
                                    value={windOneCo}
                                    onChange={(value) => {
                                      changeInput('weather.windOneCo', value);
                                    }}
                                  />
                                </div>
                                <span className="unt">/</span>
                                <div className="type5">
                                  <AppTextInput
                                    inputType={'number'}
                                    label={'바람2'}
                                    value={windTwoCo}
                                    onChange={(value) => {
                                      changeInput('weather.windTwoCo', value);
                                    }}
                                  />
                                </div>
                              </div>
                              <div className="df type5">
                                <AppTextInput
                                  inputType={'number'}
                                  label={'격발'}
                                  value={gustCo}
                                  onChange={(value) => {
                                    changeInput('weather.gustCo', value);
                                  }}
                                />
                                <span className="info-tit">케츠</span>
                              </div>
                            </div>
                            <label className="file-label">실제 날씨</label>
                          </div>
                          <div className="form-group wid100 mt10">
                            <AppTextInput
                              label="시계"
                              value={visibilityNm}
                              onChange={(value) => {
                                changeInput('weather.visibilityNm', value);
                              }}
                            />
                          </div>
                          <div className="form-group wid100 mt10">
                            <div className="flex-between">
                              <div className="type5">
                                <AppCodeSelect
                                  label="구름"
                                  codeGrpId="CODE_GRP_007"
                                  value={cloudCd}
                                  onChange={(value) => {
                                    changeInput('weather.cloudCd', value);
                                  }}
                                />
                              </div>
                              <div className="df type5">
                                <AppTextInput
                                  inputType={'number'}
                                  label={'온도'}
                                  value={tempCo}
                                  onChange={(value) => {
                                    changeInput('weather.tempCo', value);
                                  }}
                                />
                                <span className="info-tit">℃</span>
                              </div>
                            </div>
                          </div>
                          <div className="form-group wid100 mt10">
                            <AppCodeSelect
                              label="Altimeter"
                              codeGrpId="CODE_GRP_006"
                              value={altimeterUnitCd}
                              onChange={(value) => {
                                changeInput('weather.altimeterUnitCd', value);
                              }}
                            />
                          </div>
                          <div className="form-group wid100 mt10">
                            <AppTextInput
                              label="Altimeter(number)"
                              inputType={'number'}
                              value={altimeterCo}
                              onChange={(value) => {
                                changeInput('weather.altimeterCo', value);
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*multiple selection 처리 */}
                        <AppCodeSelect
                          label="심각한 날씨(다중 섹션)"
                          codeGrpId="CODE_GRP_008"
                          isMultiple
                          value={weatherCodeList}
                          onChange={(value) => {
                            changeInput('weather.weatherCodeList', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        {/* 조류충돌 */}
        <dl className={birdExapned ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button type="button" className="btn-tg">
              조류충돌
              <span
                className={birdExapned ? 'active' : ''}
                onClick={() => toggleAccordionExpanded('birdExapned')}
              ></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: birdExapned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid100">
                        {/*새의 종류
                         */}
                        <AppTextInput
                          inputType="text"
                          placeholder=""
                          label="새의 종류"
                          toolTipMessage="자유형식으로 입력가능
                          예)Waypoint, 이륙 후3시간 경과 시점 등"
                          value={birdTypeNm}
                          onChange={(value) => {
                            changeInput('bird.birdTypeNm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Size of Bird"
                          options={CodeService.getOptions('CODE_GRP_093')}
                          value={birdSizeCd}
                          onChange={(value) => {
                            changeInput('bird.birdSizeCd', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Number Seen"
                          options={CodeService.getOptions('CODE_GRP_094')}
                          value={birdCoCd}
                          onChange={(value) => {
                            changeInput('bird.birdCoCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Number Struck"
                          options={CodeService.getOptions('CODE_GRP_094')}
                          value={struckBirdCoCd}
                          onChange={(value) => {
                            changeInput('bird.struckBirdCoCd', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <span className="txt">Time</span>
                        <AppRadioGroup
                          label="Time"
                          options={CodeService.getOptions('CODE_GRP_095')}
                          value={timeTypeCd}
                          onChange={(value) => {
                            changeInput('bird.timeTypeCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Landing Light"
                          options={Code.reportUseYn}
                          value={landingLightYn}
                          onChange={(value) => {
                            changeInput('bird.landingLightYn', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <span className="txt">Pilot Warned of Birds</span>
                        <AppRadioGroup
                          label="Pilot Warned of Birds"
                          options={Code.reportOnOff}
                          value={pilotWarnedYn}
                          onChange={(value) => {
                            changeInput('bird.pilotWarnedYn', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid100">
                        {/*Impact Point*/}
                        <AppTextInput
                          inputType="text"
                          label="Impact Point"
                          value={impactTimeNm}
                          onChange={(value) => {
                            changeInput('bird.impactTimeNm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid100">
                        <AppTextArea
                          label="Describe: Damage, Injuries and other information"
                          style={{ width: '100%', height: 100 }}
                          value={birdDescriptionCn}
                          onChange={(value) => {
                            changeInput('bird.birdDescriptionCn', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
          출력
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={tempSave}>
          저장
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_conblue">
          제출
        </button>
      </div>
    </>
  );
}
export default ReportASREditForm;
