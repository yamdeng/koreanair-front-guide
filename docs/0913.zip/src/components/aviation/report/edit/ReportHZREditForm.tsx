function ReportHZREditForm() {
  return <div>ReportHZREditForm</div>;
}
export default ReportHZREditForm;
