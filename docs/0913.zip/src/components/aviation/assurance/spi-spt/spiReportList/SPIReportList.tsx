import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppNavigation from '@/components/common/AppNavigation';
import AppSelect from '@/components/common/AppSelect';
import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import dayjs from 'dayjs';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { create } from 'zustand';
import PSPIReportModal from './PSPIReportModal';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/assurance/spi-spt/reports',
  baseRoutePath: '/aviation/spi-spt/spiReportList',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  searchTypeCd: '1',
  fromDate: dayjs().format('YYYY-MM-DD'),
  toDate: dayjs().format('YYYY-MM-DD'),
  reportTypeCd: '',
  spiYn: 'N',
  naYn: '',
};

/* zustand store 생성 */
const useSpiReportListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  disablePaging: true,

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    searchTypeCd: '1',
    fromDate: dayjs().format('YYYY-MM-DD'),
    toDate: dayjs().format('YYYY-MM-DD'),
    reportTypeCd: '',
    spiYn: 'N',
    naYn: '',
  },

  isPSPIReportModal: false,
  isRowData: {},

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  handlePSPIReportModal: (openVal) => {
    set({ isPSPIReportModal: openVal });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function SPIReportList() {
  const state = useSpiReportListStore();
  const { t } = useTranslation();

  const {
    enterSearch,
    searchParam,
    list,
    changeSearchInput,
    changeStateProps,
    clear,
    isRowData,
    initSearchInput,
    isPSPIReportModal,
    handlePSPIReportModal,
  } = state;

  const { searchTypeCd, fromDate, toDate, reportTypeCd, spiYn, naYn } = searchParam;

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'reportDocno', headerName: 'Doc No.', cellStyle: { textAlign: 'center' } },
      { field: 'departureDt', headerName: 'Departure Date', cellStyle: { textAlign: 'center' } },
      { field: 'aircraftTypeKor', headerName: 'Aircraft Type', cellStyle: { textAlign: 'center' } },
      { field: 'fleetNm', headerName: 'Fleet', cellStyle: { textAlign: 'center' } },
      { field: 'regNo', headerName: 'Registration No.', cellStyle: { textAlign: 'center' } },
      { field: 'flightNo', headerName: 'Flight No.', cellStyle: { textAlign: 'center' } },
      { field: 'departureAirportCd', headerName: 'From', cellStyle: { textAlign: 'center' } },
      { field: 'arrivalAirportCd', headerName: 'To', cellStyle: { textAlign: 'center' } },
      { field: 'occurAirportCd', headerName: 'Airport', cellStyle: { textAlign: 'center' } },
      { field: 'subjectNm', headerName: 'Subject', cellStyle: { textAlign: 'left' } },
      { field: 'eventName', headerName: 'Event Type', cellStyle: { textAlign: 'center' } },
      { field: 'eventSummary', headerName: 'Event Summary', cellStyle: { textAlign: 'left' } },
      { field: 'riskLevelCd', headerName: 'SPI 위험도', cellStyle: { textAlign: 'center' } },
    ])
  );

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    changeStateProps('isRowData', selectedInfo.data);
    handlePSPIReportModal(true);
    console.log(selectedInfo.data);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);
  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>Report List</h2>
      </div>

      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div id="" className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppSelect
                  label={'일자구분'}
                  value={searchTypeCd}
                  options={[
                    { label: '제출일자', value: '1' },
                    { label: '출발일자', value: '2' },
                  ]}
                  onChange={(value) => {
                    changeSearchInput('searchTypeCd', value);
                  }}
                  required
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={t('ke_change_mgmt_label_00556')}
                      pickerType="date"
                      value={fromDate}
                      onChange={(value) => {
                        changeSearchInput('fromDate', value);
                      }}
                      required
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label={t('ke_report_label_00203')}
                      pickerType="date"
                      value={toDate}
                      onChange={(value) => {
                        changeSearchInput('toDate', value);
                      }}
                      required
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'보고서 구분'}
                  value={reportTypeCd}
                  codeGrpId="CODE_GRP_092"
                  onChange={(value) => {
                    changeSearchInput('reportTypeCd', value);
                  }}
                  applyAllSelect={true}
                />
              </div>
            </div>
            <div className="form-cell wid20">
              <div className="form-group wid100">
                <AppSelect
                  label={'SPI 등록여부'}
                  value={spiYn}
                  options={[
                    { label: '예', value: 'Y' },
                    { label: '아니오', value: 'N' },
                  ]}
                  onChange={(value) => {
                    changeSearchInput('spiYn', value);
                  }}
                  required
                />
              </div>
            </div>
            <div className="form-cell wid20">
              <div className="form-group wid100">
                <AppSelect
                  label={'N/A여부'}
                  value={naYn}
                  applyAllSelect
                  options={[
                    { label: '예', value: 'Y' },
                    { label: '아니오', value: 'N' },
                  ]}
                  onChange={(value) => {
                    changeSearchInput('naYn', value);
                  }}
                  required
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              {t('ke.safety.common.label.00002')}
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              {t('ke.safety.common.label.00003')}
            </button>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button type="button" name="button" className="arrow button _control active">
          <span className="hide">접기</span>
        </button>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
          hiddenPagination
        />
      </div>
      {/*//그리드영역 */}
      {/*SPI 코드 선택 팝업 */}
      <PSPIReportModal
        isOpen={isPSPIReportModal}
        closeModal={() => handlePSPIReportModal(false)}
        ok={handlePSPIReportModal}
        searchInfo={searchParam}
        rowData={isRowData}
      />
    </>
  );
}

export default SPIReportList;
