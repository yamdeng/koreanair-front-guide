import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import { create } from 'zustand';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/assurance/sms-analysis/reportDetail',
  baseRoutePath: '/aviation/smsComprehensive/smsIntgrAnlysDashBoardList',
};

/* zustand store 생성 */
const SMSReportStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* 검색에서 사용할 input 선언 */
  searchParam: {
    gubun: '',
    code: '',
  },

  getSearchParam: () => {
    const { getPageParam } = get();
    const baseSearchParam = get().searchParam;
    const apiParam = { ...baseSearchParam, ...getPageParam() };
    return apiParam;
  },

  clear: () => {
    set(initListData);
  },

  riskDiv: (params) => {
    return (
      <div className="Safety-table-cell">
        <span className={`Safety-tag riskLevel ` + params.data.col07}>{params.value}</span>
      </div>
    );
  },
}));

function PSMSReportModal(props) {
  const state = SMSReportStore();
  const { isOpen, closeModal, searchInfo } = props;
  const { gubun, code } = searchInfo;

  const {
    enterSearch,
    searchParam,
    list,
    changeSearchInput,
    clear,
    handlePSPILoadModal,
    okPSPILoadModal,
    handlePSPINewModal,
    rowData,
    isRowData,
  } = state;

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'gubun', headerName: 'Doc No.', cellStyle: { textAlign: 'center' } },
      { field: 'col01', headerName: 'Subject', cellStyle: { textAlign: 'left' } },
      { field: 'col02', headerName: '부문', cellStyle: { textAlign: 'center' } },
      { field: 'col03', headerName: 'Event Type', cellStyle: { textAlign: 'left' } },
      { field: 'col04', headerName: 'Hazard', cellStyle: { textAlign: 'left' } },
      { field: 'col05', headerName: 'Potential Consequence', cellStyle: { textAlign: 'left' } },
      {
        field: 'col06',
        headerName: '1st Risk Assessment',
        cellStyle: { textAlign: 'center' },
        cellRenderer: state.riskDiv,
      },
      { field: 'col08', headerName: '1st Risk Assessment (Score)', cellStyle: { textAlign: 'right' } },
    ])
  );

  useEffect(() => {
    if (isOpen) {
      changeSearchInput('gubun', gubun);
      changeSearchInput('code', code);
      enterSearch();
    }
    return clear;
  }, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">보고서현황</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              {/*그리드영역 */}
              <div>
                <AppTable rowData={list} columns={columns} setColumns={setColumns} store={state} />
              </div>
              {/*//그리드영역 */}
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={closeModal}>
            닫기
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default PSMSReportModal;
