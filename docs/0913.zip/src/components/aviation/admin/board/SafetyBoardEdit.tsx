import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import AppTextInput from '@/components/common/AppTextInput';
import AppTextArea from '@/components/common/AppTextArea';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import { useTranslation } from 'react-i18next';

/* store  */
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import ApiService from '@/services/ApiService';
import AppSelect from '@/components/common/AppSelect';
import AppCheckbox from '@/components/common/AppCheckbox';

/* yup validation */
const yupFormSchema = yup.object({
  boardType: yup.string().required(),
  viewYn: yup.string().required(),
  jobType: yup.string().required(),
  titleKo: yup.string().required(),
  content: yup.string(),
  useYn: yup.string().required(),
  linkKo: yup.string(),
  linkGroupSeq: yup.number().nullable(),
  fileGroupSeq: yup.number().nullable(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  boardType: '',
  viewYn: 'N',
  jobType: '',
  titleKo: '',
  content: '',
  useYn: '',
  linkKo: '',
  viewCheckYn: false,
  linkGroupSeq: null,
  fileGroupSeq: null,
  popupYn: 'N',
  topFixYn: 'N',
  mainShowYn: 'N',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/board/board',
  baseRoutePath: '/aviation/board-manage/safety-board',
  formName: 'AvnSafetyBoardFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const AvnSafetyBoardFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  //board Type options
  boardTypeOptions: [],
  isDisabledJobType: true,
  isDisabledSafetyUrl: true,

  //board Type 가져오기
  getBoardType: async () => {
    const boardTypeList = await ApiService.get(`com/code-groups/CODE_GRP_141/codes`);
    const dataList = boardTypeList.data;
    const customValue = [];
    dataList.some((data) => {
      if (data.codeId == '20' || data.codeId == '30' || data.codeId == '40') {
        customValue.push(data);
      }
    });
    boardTypeList['data'] = customValue;

    set({ boardTypeOptions: boardTypeList });
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue }, formType: FORM_TYPE_ADD });
  },

  isDisabledAction: (value) => {
    if (value == '30') {
      set({ isDisabledJobType: false });
      set({ isDisabledSafetyUrl: true });
    } else if (value == '40') {
      set({ isDisabledSafetyUrl: false });
      set({ isDisabledJobType: true });
    } else {
      set({ isDisabledJobType: true });
      set({ isDisabledSafetyUrl: true });
    }

    const { formValue } = get();
    formValue['jobType'] = '';
    formValue['safetyUrl'] = '';
    set({ formValue: formValue });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SafetyBoardEdit() {
  // 언어 설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    save,
    remove,
    cancel,
    clear,
    boardTypeOptions,
    getBoardType,
    enterSearch,
    isDisabledJobType,
    isDisabledSafetyUrl,
    isDisabledAction,
  } = AvnSafetyBoardFormStore();

  const {
    boardType,
    viewCheckYn,
    jobType,
    titleKo,
    content,
    useYn,
    safetyUrl,
    // linkGroupSeq,
    fileGroupSeq,
  } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    //게시판 종류 가져오기
    getBoardType();
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>Safety 게시판 {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppSelect
                //codeGrpId="CODE_GRP_141" >> 20,30,40 만 선택해서 출력되도록
                //applyAllSelect
                id="AvnSafetyNoticeFormStoreboardType"
                label={t('ke.safety.Notice.label.00001')}
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={boardType}
                onChange={(value) => {
                  isDisabledAction(value);
                  changeInput('boardType', value);
                }}
                search={enterSearch}
                options={boardTypeOptions.data}
                labelKey="codeNameKor"
                valueKey="codeId"
                errorMessage={errors.boardType}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="group-box-wrap wid100">
                <AppCheckbox
                  label="열람여부"
                  //checkboxTitle="열람여부"
                  value={viewCheckYn}
                  onChange={(value) => {
                    if (value) {
                      changeInput('viewYn', 'Y');
                      changeInput('viewCheckYn', true);
                    } else {
                      changeInput('viewYn', 'N');
                      changeInput('viewCheckYn', false);
                    }
                  }}
                  required
                />
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell pr10 wid50">
            <div className="form-group wid50">
              <AppCodeSelect
                codeGrpId="CODE_GRP_143"
                //applyAllSelect
                id="AvnSafetyNoticeFormStorejobType"
                label={t('ke.safety.Notice.label.00005')}
                //disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={jobType}
                onChange={(value) => changeInput('jobType', value)}
                disabled={isDisabledJobType}
                errorMessage={errors.jobType}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnSafetyNoticeFormStoretitleKo"
                label={t('ke.safety.Notice.label.00002')}
                value={titleKo}
                onChange={(value) => changeInput('titleKo', value)}
                errorMessage={errors.titleKo}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppTextArea
                id="AvnSafetyNoticeFormStorecontent"
                label={t('ke.safety.Notice.label.00009')}
                value={content}
                onChange={(value) => changeInput('content', value)}
                errorMessage={errors.content}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid80">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnSafetyNoticeFormStoresafetyUrl"
                label="SafetyDay URL"
                value={safetyUrl}
                onChange={(value) => changeInput('safetyUrl', value)}
                disabled={isDisabledSafetyUrl}
                errorMessage={errors.safetyUrl}
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_146"
                //applyAllSelect
                id="AvnSafetyNoticeFormStoreuseYn"
                label={t('ke.safety.Notice.label.00003')}
                value={useYn}
                onChange={(value) => changeInput('useYn', value)}
                errorMessage={errors.useYn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* linkGroupSeq 컴포넌트 질문 */}
        {/* 산업안전 > 산업안전 보건위원회 */}
        <div className="form-table">
          <div className="form-cell wid80">
            <div className="group-box-wrap line wid100">
              <span className="txt">Link{/*<span className="required">*</span>*/}</span>
              <button type="button" name="button" className="btn-plus">
                추가
              </button>
              <div className="file-link">
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link첨부Link첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* 다중 파일 첨부 질문 */}
        {/* 파일첨부영역 : drag */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* 파일첨부영역 : drag */}
              <AppFileAttach
                label={t('ke.safety.Notice.label.00007')}
                fileGroupSeq={fileGroupSeq}
                workScope={'A'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileGroupSeq', newFileGroupSeq);
                }}
                errorMessage={errors.fileGroupSeq}
              />
            </div>
          </div>
        </div>
      </div>
      {/*//입력영역*/}

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
      {/*//하단 버튼 영역 */}
    </>
  );
}
export default SafetyBoardEdit;
