import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import { useTranslation } from 'react-i18next';
import AppCodeSelect from '@/components/common/AppCodeSelect';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/board/notices',
  baseRoutePath: '/aviation/board-manage/notices',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  boardType: '70',
  notiType: '',
  titleKo: '',
  popupYn: '',
};

/* zustand store 생성 */
const AvnNoticesListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    boardType: '70',
    notiType: '',
    titleKo: '',
    popupYn: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function NoticesList() {
  const { t } = useTranslation();
  const state = AvnNoticesListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번', cellStyle: { textAlign: 'center' } },
      { field: 'notiType', headerName: '공지구분', cellStyle: { textAlign: 'center' } },
      { field: 'titleKo', headerName: '제목 국문명', cellStyle: { textAlign: 'left' } },
      { field: 'popupFromDt', headerName: '팝업시작일자', cellStyle: { textAlign: 'center' } },
      { field: 'popupToDt', headerName: '팝업종료일자', cellStyle: { textAlign: 'center' } },
      { field: 'popupYn', headerName: '팝업여부', cellStyle: { textAlign: 'center' } },
      { field: 'topFixYn', headerName: '상단고정여부', cellStyle: { textAlign: 'center' } },
      { field: 'mainShowYn', headerName: '메인표출여부', cellStyle: { textAlign: 'center' } },
      { field: 'viewCount', headerName: '조회수' },
      { field: 'regUserId', headerName: '등록자', cellStyle: { textAlign: 'center' } },
      { field: 'regDttm', headerName: '등록일자', cellStyle: { textAlign: 'center' } },
    ])
  );
  const {
    enterSearch,
    search,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;
  // TODO : 검색 파라미터 나열
  const { notiType, titleKo, popupYn } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.boardId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>공지사항</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_142"
                  applyAllSelect
                  // 공지구분으로 수정 후 메시지 관리 생성
                  label={t('ke.safety.Notice.label.00001')}
                  value={notiType}
                  onChange={(value) => {
                    changeSearchInput('notiType', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label={t('ke.safety.policy.label.00002')}
                  value={titleKo}
                  onChange={(value) => {
                    changeSearchInput('titleKo', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppCodeSelect
                  // 현재 146은 사용여부 >> 팝업여부 공통코드관리에서 생성
                  codeGrpId="CODE_GRP_146"
                  applyAllSelect
                  //label={t('ke.safety.Notice.label.00001')}
                  label="팝업여부"
                  value={popupYn}
                  onChange={(value) => {
                    changeSearchInput('popupYn', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="btn-area df">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                {t('ke.safety.common.label.00002')}
              </button>
              <button
                type="button"
                name="button"
                className="btn-sm btn_text btn-darkblue-line"
                onClick={initSearchInput}
              >
                {t('ke.safety.common.label.00003')}
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
        />
      </div>
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
    </>
  );
}

export default NoticesList;
