import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import AppTextInput from '@/components/common/AppTextInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppTextArea from '@/components/common/AppTextArea';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import { useTranslation } from 'react-i18next';

/* store  */
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  jobType: yup.string().required('업무구분은 필수 입력 항목입니다.'),
  revisionDt: yup.string().required('개정일자는 필수 입력 항목입니다.'),
  manualName: yup.string().required('매뉴얼명은 필수 입력 항목입니다.'),
  languageType: yup.string().required('언어구분은 필수 입력 항목입니다.'),
  useYn: yup.string().required('사용여부는 필수 입력 항목입니다.'),
  notes: yup.string(),
  originalFileGroupSeq: yup.number().nullable().required('원문 첨부파일은 필수 입력 항목입니다.'),
  newOldFileGroupSeq: yup.number().nullable().required('신구대조표 첨부파일은 필수 입력 항목입니다.'),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  jobType: '',
  revisionDt: '',
  manualName: '',
  languageType: '',
  useYn: '',
  notes: '',
  originalFileGroupSeq: null,
  newOldFileGroupSeq: null,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/board/manuals',
  baseRoutePath: '/aviation/board-manage/safety-manual',
  formName: 'useManualFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useManualFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

function AdminSafetyManualEdit() {
  // 언어 설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, save, remove, cancel, clear } = useManualFormStore();

  const { jobType, revisionDt, manualName, languageType, useYn, notes, originalFileGroupSeq, newOldFileGroupSeq } =
    formValue;

  const { detailId } = useParams();

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>안전메뉴얼 {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_148"
                applyAllSelect
                id="ManualFormjobType"
                name="jobType"
                label={t('ke.safety.manual.label.00001')}
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={jobType}
                onChange={(value) => changeInput('jobType', value)}
                errorMessage={errors.jobType}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDatePicker
                label={t('ke.safety.manual.label.00004')}
                id="ManualFormrevisionDt"
                name="revisionDt"
                value={revisionDt}
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                onChange={(value) => changeInput('revisionDt', value)}
                errorMessage={errors.revisionDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label={t('ke.safety.manual.label.00002')}
                id="ManualFormmanualName"
                name="manualName"
                value={manualName}
                onChange={(value) => changeInput('manualName', value)}
                errorMessage={errors.manualName}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_147"
                applyAllSelect
                id="ManualFormlanguageType"
                name="languageType"
                label={t('ke.safety.manual.label.00003')}
                value={languageType}
                onChange={(value) => changeInput('languageType', value)}
                errorMessage={errors.jobType}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_146"
                applyAllSelect
                id="useSafetyBoardFormStoreuseYn"
                name="useYn"
                label={t('ke.safety.manual.label.00008')}
                value={useYn}
                onChange={(value) => changeInput('useYn', value)}
                errorMessage={errors.useYn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextArea
                id="ManualFormnotes"
                name="notes"
                label={t('ke.safety.manual.label.00005')}
                value={notes}
                onChange={(value) => changeInput('notes', value)}
                errorMessage={errors.notes}
              />
            </div>
          </div>
        </div>

        <hr className="line"></hr>
        {/* 파일첨부영역 : drag */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* 파일첨부영역 : drag */}
              <AppFileAttach
                label={t('ke.safety.manual.label.00006')}
                fileGroupSeq={originalFileGroupSeq}
                workScope={'A'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('originalFileGroupSeq', newFileGroupSeq);
                }}
                errorMessage={errors.originalFileGroupSeq}
                maxCount={1}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : drag */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppFileAttach
                label={t('ke.safety.manual.label.00007')}
                fileGroupSeq={newOldFileGroupSeq}
                workScope={'A'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('newOldFileGroupSeq', newFileGroupSeq);
                }}
                errorMessage={errors.newOldFileGroupSeq}
                maxCount={1}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/*//입력영역*/}
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
    </>
  );
}
export default AdminSafetyManualEdit;
