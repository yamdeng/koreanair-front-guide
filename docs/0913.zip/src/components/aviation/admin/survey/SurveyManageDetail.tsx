import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import AppNavigation from '@/components/common/AppNavigation';
import { useTranslation } from 'react-i18next';

/* store  */
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import AppTextInput from '@/components/common/AppTextInput';

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/survey',
  baseRoutePath: '/aviation/survey-manage',
};

/* zustand store 생성 */
const AvnSurveyManageDetailStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  clear: () => {
    set({ ...formBaseState });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SurveyManageDetail() {
  // 언어설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const { detailInfo, getDetail, formType, cancel, goFormPage, clear } = AvnSurveyManageDetailStore();
  const { titleKo, popupFromDt, linkKo, linkEn } = detailInfo;

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>안전문화설문관리 상세</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid30">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">설문일자</label>
                    <span className="text-desc-type1">{popupFromDt}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">설문제목</label>
                    <span className="text-desc-type1">{titleKo}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput label={'설문링크'} placeholder={linkKo} required disabled />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput label={'답변링크'} placeholder={linkEn} required disabled />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          {t('ke.safety.common.label.00006')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goFormPage}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00007')}
        </button>
      </div>
    </>
  );
}
export default SurveyManageDetail;
