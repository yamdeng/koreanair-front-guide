import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import { useTranslation } from 'react-i18next';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import search from 'antd/es/transfer/search';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/mail-forms',
  baseRoutePath: '/aviation/mail-form-manage',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  mailCode: '',
  mailJobType: '',
  mailName: '',
  useYn: '',
};

/* zustand store 생성 */
const AvnMailFormManageListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    mailCode: '',
    mailJobType: '',
    mailName: '',
    useYn: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function MailFormManageList() {
  // 언어설정
  const { t } = useTranslation();
  const state = AvnMailFormManageListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번', cellStyle: { textAlign: 'center' } },
      { field: 'mailCode', headerName: '메일코드', cellStyle: { textAlign: 'center' } },
      { field: 'mailJobType', headerName: '업무구분', cellStyle: { textAlign: 'center' } },
      { field: 'mailName', headerName: '제목' },
      { field: 'useYn', headerName: '사용여부', cellStyle: { textAlign: 'center' } },
      { field: 'regUserId', headerName: '등록자', cellStyle: { textAlign: 'center' } },
      { field: 'regDttm', headerName: '등록일자', cellStyle: { textAlign: 'center' } },
      { field: 'updUserId', headerName: '수정자', cellStyle: { textAlign: 'center' } },
      { field: 'updDttm', headerName: '수정일자', cellStyle: { textAlign: 'center' } },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;
  // TODO : 검색 파라미터 나열
  const { mailCode, mailJobType, mailName, useYn } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.mailCode;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>메일양식관리</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_152"
                  applyAllSelect
                  label={t('ke.safety.mail.label00001')}
                  value={mailJobType}
                  onChange={(value) => {
                    changeSearchInput('mailJobType', value);
                  }}
                />
              </div>
            </div>

            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label={'메일코드'}
                  value={mailCode}
                  onChange={(value) => {
                    changeSearchInput('mailCode', value);
                  }}
                />
              </div>
            </div>

            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label={t('ke.safety.mail.label00002')}
                  value={mailName}
                  onChange={(value) => {
                    changeSearchInput('mailName', value);
                  }}
                  search={search}
                />
              </div>
            </div>

            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_146"
                  applyAllSelect
                  label={t('ke.safety.mail.label00005')}
                  value={useYn}
                  onChange={(value) => {
                    changeSearchInput('useYn', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              {t('ke.safety.common.label.00002')}
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              {t('ke.safety.common.label.00003')}
            </button>
          </div>
        </div>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
    </>
  );
}

export default MailFormManageList;
