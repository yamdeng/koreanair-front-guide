import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import CodeSerivce from '@/services/CodeService';
import AppNavigation from '@/components/common/AppNavigation';
import ApiService from '@/services/ApiService';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function EventTypeDetail() {
  const navigate = useNavigate();
  const [detailInfo, setDetailInfo /*getDetail*/] = useState<any>({});

  const { reportType, eventName, useYn, notes } = detailInfo;

  const { detailId } = useParams();

  const cancel = () => {
    navigate(-1);
  };

  const goFormPage = () => {
    navigate(`/aviation/eventtype-manage/${detailId}/edit`);
  };

  useEffect(() => {
    // swagger에서 상세조회 후 Curl에 url복사
    ApiService.get(`avn/admin/criteria/event-types/${detailId}`).then((apiResult) => {
      const detailInfo = apiResult.data || {};
      setDetailInfo(detailInfo);
    });
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>Event Type 상세</h2>
      </div>
      <div className="eidtbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">리포트 구분</label>
                    <span className="text-desc-type1">
                      {CodeSerivce.getCodeLabelByValue('CODE_GRP_092', reportType)}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">이벤트명</label>
                    <span className="text-desc-type1">{eventName}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">사용여부</label>
                    <span className="text-desc-type1">{CodeSerivce.getCodeLabelByValue('CODE_GRP_146', useYn)}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">비고</label>
                    <span className="text-desc-type1">{notes}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          수정
        </button>
      </div>
    </>
  );
}
export default EventTypeDetail;
