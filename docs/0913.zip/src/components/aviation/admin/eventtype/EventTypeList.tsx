import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';
import Code from '@/config/Code';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import { useCallback, useEffect, useState } from 'react';
import { create } from 'zustand';
// 아래 2개의 file import
import useAppStore from '@/stores/useAppStore';
import { useStore } from 'zustand';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/criteria/event-types',
  baseRoutePath: '/aviation/eventtype-manage',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  reportType: '',
  eventName: '',
  useYn: '',
  notes: '',
};

/* zustand store 생성 */
const EventTypeListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    reportType: '',
    eventName: '',
    useYn: '',
    notes: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function EventTypeList() {
  const currentLocale = useStore(useAppStore, (state) => state.currentLocale);

  const regUserName = (props) => {
    if (currentLocale == 'ko') {
      return props.data.regUserNameKor;
    } else {
      return props.data.regUserNameEng;
    }
  };

  const updUserName = (props) => {
    if (currentLocale == 'ko') {
      return props.data.updUserNameKor;
    } else {
      return props.data.updUserNameEng;
    }
  };

  const state = EventTypeListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      {
        field: 'num',
        headerName: '순번',
        cellStyle: { textAlign: 'center' },
      },
      {
        field: 'reportType',
        headerName: '리포트 구분',
        cellStyle: { textAlign: 'center' },
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_092',
        },
      },
      { field: 'eventName', headerName: '이벤트명' },
      {
        field: 'useYn',
        headerName: '사용여부',
        cellStyle: { textAlign: 'center' },
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_146',
        },
      },
      { field: 'notes', headerName: '비고' },
      { field: 'regUserId', headerName: '등록자', cellStyle: { textAlign: 'center' }, cellRenderer: regUserName },
      { field: 'regDttm', headerName: '등록일', cellStyle: { textAlign: 'center' } },
      { field: 'updUserId', headerName: '수정자', cellStyle: { textAlign: 'center' }, cellRenderer: updUserName },
      { field: 'updDttm', headerName: '수정일', cellStyle: { textAlign: 'center' } },
    ])
  );
  const { enterSearch, searchParam, list, goAddPage, changeSearchInput, isExpandDetailSearch, clear, goDetailPage } =
    state;
  // TODO : 검색 파라미터 나열
  const { reportType, eventName, useYn, notes } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    console.log(selectedInfo);
    const data = selectedInfo.data;
    const detailId = data.eventId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>EVENT TYPE 목록</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_092"
                  applyAllSelect
                  label="리포트 구분"
                  options={Code.reportType}
                  labelKey="codeNameKor"
                  valueKey="codeId"
                  value={reportType}
                  onChange={(value) => {
                    changeSearchInput('reportType', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>

            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppTextInput
                  label="이벤트 명"
                  value={eventName}
                  onChange={(value) => {
                    changeSearchInput('eventName', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>

            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_146"
                  applyAllSelect
                  name="useYn"
                  label="사용여부"
                  labelKey="codeNameKor"
                  valueKey="codeId"
                  value={useYn}
                  onChange={(value) => changeSearchInput('useYn', value)}
                  search={enterSearch}
                />
              </div>
            </div>

            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppTextInput
                  label="비고"
                  value={notes}
                  onChange={(value) => {
                    changeSearchInput('notes', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
          </div>
        </div>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default EventTypeList;
