import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import { FORM_TYPE_ADD } from '@/config/CommonConstant';
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { useTranslation } from 'react-i18next';

/* yup validation */
const yupFormSchema = yup.object({
  division: yup.string().required('부문은 필수 입력 항목입니다.'),
  conferenceType: yup.string().required('회의구분은 필수 입력 항목입니다.'),
  conferenceDt: yup.string().required('회의일자는 필수 입력 항목입니다.'),
  conferenceTitle: yup.string().required('회의제목은 필수 입력 항목입니다.'),
  fileGroupSeq: yup.number().nullable().required('첨부파일은 필수 입력 항목입니다.'),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  division: '',
  conferenceType: '',
  conferenceDt: '',
  conferenceTitle: '',
  fileGroupSeq: null,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/policy/committee',
  baseRoutePath: '/aviation/policy/safety-committee',
  formName: 'SafetyCommitteeEdit',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useSafetyCommitteeEditStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SafetyCommitteeEdit() {
  //언어설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    useSafetyCommitteeEditStore();

  const { division, conferenceType, conferenceDt, conferenceTitle, fileGroupSeq } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>안전회의체 {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_149"
                applyAllSelect
                id="SafetyCommitteeEditdivision"
                name="division"
                label={t('ke.safety.conference.label.00001')}
                value={division}
                onChange={(value) => changeInput('division', value)}
                errorMessage={errors.division}
                required
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_150"
                applyAllSelect
                id="SafetyCommitteeEditconferenceType"
                name="conferenceType"
                label={t('ke.safety.committee.label.00004')}
                value={conferenceType}
                onChange={(value) => changeInput('conferenceType', value)}
                errorMessage={errors.conferenceType}
                required
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppDatePicker
                id="SafetyCommitteeEditconferenceDt"
                name="conferenceDt"
                label={t('ke.safety.committee.label.00005')}
                value={conferenceDt}
                onChange={(value) => changeInput('conferenceDt', value)}
                errorMessage={errors.conferenceDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="SafetyCommitteeEditconferenceTitle"
                name="conferenceTitle"
                label={t('ke.safety.committee.label.00003')}
                value={conferenceTitle}
                onChange={(value) => changeInput('conferenceTitle', value)}
                errorMessage={errors.conferenceTitle}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppFileAttach
                id="SafetyCommitteeEditfileGroupSeq"
                name="fileGroupSeq"
                label={t('ke.safety.committee.label.00006')}
                fileGroupSeq={fileGroupSeq}
                workScope={'A'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  // TODO : newFileGroupSeq를 handle
                  changeInput('fileGroupSeq', newFileGroupSeq);
                }}
                required
                maxCount={1}
                errorMessage={errors.fileGroupSeq}
              />
              <span style={{ color: 'red' }}>* 첨부파일은 1건만 가능합니다.</span>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
    </>
  );
}
export default SafetyCommitteeEdit;
