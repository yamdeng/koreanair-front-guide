import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import { DATE_PICKER_TYPE_YEAR } from '@/config/CommonConstant';
import ApiService from '@/services/ApiService';
import { useTranslation } from 'react-i18next';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/policy/committee',
  baseRoutePath: '/aviation/policy/safety-committee',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  division: '',
  conferenceYear: '',
  conferenceTitle: '',
  conferenceType: '',
};

// TODO : 검색 초기값 설정
const initGroupCount = {
  ALL: 0,
  LSC: 0,
  SRC: 0,
  SRB: 0,
  SAG: 0,
  MSSM: 0,
};

/* zustand store 생성 */
const AvnSafeConferenceListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    division: '',
    conferenceYear: '',
    conferenceTitle: '',
    conferenceType: '',
  },

  groupCount: {
    ALL: 0,
    LSC: 0,
    SRC: 0,
    SRB: 0,
    SAG: 0,
    MSSM: 0,
  },

  changeConferenceType: (value) => {
    const { changeSearchInput, enterSearch, getGroupCount } = get();
    changeSearchInput('conferenceType', value);
    getGroupCount();
    enterSearch();
  },

  getGroupCount: async () => {
    const { searchParam, groupCount } = get();
    const apiResult = await ApiService.get(`avn/policy/committee/groupCount`, searchParam);
    const data = apiResult.data;

    groupCount.ALL = 0;
    groupCount.LSC = 0;
    groupCount.SRC = 0;
    groupCount.SRB = 0;
    groupCount.SAG = 0;
    groupCount.MSSM = 0;

    data.forEach((el) => {
      if (el.conferenceType == 'lsc') {
        groupCount.LSC = el.typeCount;
      } else if (el.conferenceType == 'src') {
        groupCount.SRC = el.typeCount;
      } else if (el.conferenceType == 'srb') {
        groupCount.SRB = el.typeCount;
      } else if (el.conferenceType == 'sag') {
        groupCount.SAG = el.typeCount;
      } else if (el.conferenceType == 'mssm') {
        groupCount.MSSM = el.typeCount;
      }
    });
    groupCount.ALL = groupCount.LSC + groupCount.SRC + groupCount.SRB + groupCount.SAG + groupCount.MSSM;
  },

  searchButtonClick: async () => {
    const { getGroupCount, enterSearch } = get();
    await getGroupCount();
    await enterSearch();
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam }, groupCount: { ...initGroupCount } });
  },
}));

function SafetyCommitteeList() {
  //언어 설정
  const { t } = useTranslation();

  const state = AvnSafeConferenceListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번', cellStyle: { textAlign: 'center' } },
      { field: 'division', headerName: '부문', cellStyle: { textAlign: 'center' } },
      { field: 'conferenceType', headerName: '회의체구분', cellStyle: { textAlign: 'center' } },
      { field: 'conferenceDt', headerName: '회의일자', cellStyle: { textAlign: 'center' } },
      { field: 'conferenceTitle', headerName: '회의제목' },
      {
        field: `regUserNameKor`,
        headerName: '등록자명',
        cellStyle: { textAlign: 'center' },
      },
      { field: 'regDttm', headerName: '등록일시', cellStyle: { textAlign: 'center' } },
      { field: 'updUserNameKor', headerName: '수정자명', cellStyle: { textAlign: 'center' } },
      { field: 'updDttm', headerName: '수정일시', cellStyle: { textAlign: 'center' } },
    ])
  );
  const {
    enterSearch,
    getGroupCount,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    changeConferenceType,
    searchButtonClick,
    search,
    clear,
    goDetailPage,
    groupCount,
  } = state;

  // TODO : 검색 파라미터 나열
  const { division, conferenceYear, conferenceTitle } = searchParam;
  // 회의구분 별 값
  const { ALL, LSC, MSSM, SAG, SRB, SRC } = groupCount;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    const detailId = data.safeConferenceId;
    goDetailPage(detailId);
  }, []);

  const init = async () => {
    await getGroupCount();
    await enterSearch();
  };

  useEffect(() => {
    init();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>안전회의체 관리</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_149"
                applyAllSelect
                name="division"
                label={t('ke.safety.conference.label.00001')}
                value={division}
                onChange={(value) => changeSearchInput('division', value)}
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <div className="row1">
                <div className="date1">
                  <AppDatePicker
                    onChange={(value) => changeSearchInput('conferenceYear', value)}
                    value={conferenceYear}
                    pickerType={DATE_PICKER_TYPE_YEAR}
                    label={t('ke.safety.conference.label.00002')}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppSearchInput
                label={t('ke.safety.committee.label.00003')}
                value={conferenceTitle}
                onChange={(value) => {
                  changeSearchInput('conferenceTitle', value);
                }}
                search={search}
              />
            </div>
          </div>
          <div className="btn-area df">
            <button
              type="button"
              name="button"
              className="btn-sm btn_text btn-darkblue-line"
              onClick={searchButtonClick}
            >
              {t('ke.safety.common.label.00002')}
            </button>
          </div>
        </div>
      </div>
      {/* 신규버튼 */}
      <div className="info-field">
        <div className="inp-btns">
          <span className="inp-btn">
            <input
              type="radio"
              name="ph-chk"
              id="ph-chk01"
              onClick={() => {
                changeConferenceType('');
              }}
            />
            <label htmlFor="ph-chk01">ALL ({ALL})</label>
          </span>
          <span className="inp-btn">
            <input
              type="radio"
              name="ph-chk"
              id="ph-chk02"
              onClick={() => {
                changeConferenceType('lsc');
              }}
            />
            <label htmlFor="ph-chk02">LSC ({LSC})</label>
          </span>
          <span className="inp-btn">
            <input
              type="radio"
              name="ph-chk"
              id="ph-chk03"
              onClick={() => {
                changeConferenceType('src');
              }}
            />
            <label htmlFor="ph-chk03">SRC ({SRC})</label>
          </span>
          <span className="inp-btn">
            <input
              type="radio"
              name="ph-chk"
              id="ph-chk04"
              onClick={() => {
                changeConferenceType('srb');
                enterSearch;
              }}
            />
            <label htmlFor="ph-chk04">SRB ({SRB})</label>
          </span>
          <span className="inp-btn">
            <input
              type="radio"
              name="ph-chk"
              id="ph-chk05"
              onClick={() => {
                changeConferenceType('sag');
              }}
            />
            <label htmlFor="ph-chk05">SAG ({SAG})</label>
          </span>
          <span className="inp-btn">
            <input
              type="radio"
              name="ph-chk"
              id="ph-chk06"
              onClick={() => {
                changeConferenceType('mssm');
              }}
            />
            <label htmlFor="ph-chk06">MSSM ({MSSM})</label>
          </span>
        </div>
      </div>
      {/* //신규버튼 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
        />
      </div>
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
    </>
  );
}

export default SafetyCommitteeList;
