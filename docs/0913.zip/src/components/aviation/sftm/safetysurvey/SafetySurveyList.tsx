import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppTextInput from '@/components/common/AppTextInput';
import { useTranslation } from 'react-i18next';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/promotion/survey',
  baseRoutePath: '/aviation/sftm/safety-survey',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  popupFromDt: '',
  popupToDt: '',
  titleKo: '',
};

/* zustand store 생성 */
const AvnSafetySurveyListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    popupFromDt: '',
    popupToDt: '',
    titleKo: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function SafetySurveyList() {
  const { t } = useTranslation();
  const state = AvnSafetySurveyListStore();

  function LinkColumnComponent(params) {
    return (
      <div style={{ fontWeight: 'normal', textDecoration: 'underline' }} onClick={() => window.open(params.value)}>
        <button type="button" className="btn-togo">
          바로가기
        </button>
      </div>
    );
  }

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번', cellStyle: { textAlign: 'center' } },
      { field: 'popupFromDt', headerName: '설문일자', cellStyle: { textAlign: 'center' } },
      { field: 'titleKo', headerName: '설문제목' },
      {
        field: 'linkKo',
        headerName: '설문링크',
        cellStyle: { textAlign: 'center' },
        cellRenderer: LinkColumnComponent,
      },
      {
        field: 'linkEn',
        headerName: '답변링크',
        cellStyle: { textAlign: 'center' },
        cellRenderer: LinkColumnComponent,
      },
      { field: 'regUserId', headerName: '작성자', cellStyle: { textAlign: 'center' } },
      { field: 'regDttm', headerName: '작성일자', cellStyle: { textAlign: 'center' } },
    ])
  );
  const { enterSearch, searchParam, list, changeSearchInput, initSearchInput, goDetailPage, clear, search } = state;
  // TODO : 검색 파라미터 나열
  const { popupFromDt, popupToDt, titleKo } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.boardId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>안전문화설문 관리</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div id="" className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={'설문일자'}
                      value={popupFromDt}
                      onChange={(value) => {
                        changeSearchInput('popupFromDt', value);
                      }}
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label={'설문일자'}
                      value={popupToDt}
                      onChange={(value) => {
                        changeSearchInput('popupToDt', value);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={'제목'}
                  value={titleKo}
                  onChange={(value) => {
                    changeSearchInput('titleKo', value);
                  }}
                  search={search}
                />
              </div>
            </div>

            <div className="btn-area df">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                {t('ke.safety.common.label.00002')}
              </button>
              <button
                type="button"
                name="button"
                className="btn-sm btn_text btn-darkblue-line"
                onClick={initSearchInput}
              >
                {t('ke.safety.common.label.00003')}
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      {/*//그리드영역 */}
    </>
  );
}

export default SafetySurveyList;
