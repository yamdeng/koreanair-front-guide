import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import { useTranslation } from 'react-i18next';
import AppTextInput from '@/components/common/AppTextInput';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/promotion/notices',
  baseRoutePath: '/aviation/sftm/safetynotice',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  notiType: 'notice, safetynotice',
  titleKo: '',
};

/* zustand store 생성 */
const AvnSftmNoticesListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    notiType: 'notice, safetynotice',
    titleKo: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function SftmNoticesList() {
  const { t } = useTranslation();
  const state = AvnSftmNoticesListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번', cellStyle: { textAlign: 'center' } },
      { field: 'notiType', headerName: '구분', cellStyle: { textAlign: 'center' } },
      { field: 'titleKo', headerName: '제목' },
      { field: 'viewCount', headerName: '조회수', cellStyle: { textAlign: 'center' } },
      { field: 'regUserId', headerName: ' 작성자', cellStyle: { textAlign: 'center' } },
      { field: 'regDttm', headerName: '작성일자' },
    ])
  );
  const { enterSearch, searchParam, list, changeSearchInput, clear, goDetailPage, initSearchInput } = state;
  // TODO : 검색 파라미터 나열
  const { titleKo } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.boardId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>공지사항</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid50">
              <AppTextInput
                label={t('ke.safety.Notice.label.00002')}
                value={titleKo}
                onChange={(value) => {
                  changeSearchInput('titleKo', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>

          <div className="btn-area df">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              {t('ke.safety.common.label.00002')}
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              {t('ke.safety.common.label.00003')}
            </button>
          </div>
        </div>
      </div>
      {/* //검색영역 */}
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
    </>
  );
}

export default SftmNoticesList;
