import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
//import { useState } from 'react';
import useCheckListStore from '@/stores/aviation/audit/checklist/useCheckListStore';
import AppSelect from '@/components/common/AppSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppTextInput from '@/components/common/AppTextInput';
import AppTextArea from '@/components/common/AppTextArea';
//import { getAllData } from '@/data/grid/example-data-new';
//import { testColumnInfos } from '@/data/grid/table-column';
import CodeService from '@/services/CodeService';
import AppNavigation from '@/components/common/AppNavigation';

import ChecklistUpdModal from './ChecklistUpdModal';
import ChecklistDelModal from './ChecklistDelModal';
import ChapterAddModal from './ChapterAddModal';
import ChapterUpdModal from './ChapterUpdModal';
import ChapterDelModal from './ChapterDelModal';

function AuditCheckListEdit() {
  //const [inputValue, setInputValue] = useState('');
  //const rowData = getAllData();
  //const columns = testColumnInfos;

  const { division, checklistOrigId, chapterOrigId } = useParams();

  const {
    setAuditChapterParam,
    dsAuditChapterList,
    currentChapterTabIndex,
    changeChapterTabIndex,
    dsAuditQuestionList,
    changeRevision,
    currentRevision,
    revisions,
    clearEdit,
    changeQuestionList,
    addQuestion,
    addQuestionVisible,
    removeQuestion,

    changeChecklistInput,
    selChecklistName,
    detailChapterInfo,

    openChapterAddModal,
    closeChapterAddModal,
    isChapterAddModal,
    okChapterAddModal,

    openChapterUpdModal,
    closeChapterUpdModal,
    isChapterUpdModal,
    okChapterUpdModal,

    openChapterDelModal,
    closeChapterDelModal,
    isChapterDelModal,
    okChapterDelModal,

    openCheckListUpdModal,
    closeCheckListUpdModal,
    isCheckListUpdModal,
    okChecklistUpdModal,

    openCheckListDelModal,
    closeCheckListDelModal,
    isCheckListDelModal,
    okChecklistDelModal,

    printChecklistPage,
    moveToListPage,
  } = useCheckListStore();

  const init = async () => {
    setAuditChapterParam(division, checklistOrigId, chapterOrigId);
  };

  useEffect(() => {
    init();
    return clearEdit;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="editbox Audit">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100 Position-w">
              <AppTextInput
                id={'checklistName'}
                label=""
                value={selChecklistName}
                onChange={(value) => changeChecklistInput(value)}
                required
              />
            </div>
          </div>
          <div className="form-cell  Position-w">
            <div className="Position-end">
              <div className="number-r">
                <div className="title">Revision</div>
                <div className="form-group wid100">
                  <AppSelect
                    id="checklistRevisions"
                    options={revisions}
                    value={currentRevision}
                    labelKey="revision"
                    valueKey="revision"
                    onChange={(appSelectValue) => {
                      changeRevision(appSelectValue);
                    }}
                    disabled
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="swiper-container">
          <div className="menu-tab Audit">
            {dsAuditChapterList.map((checklistInfo) => {
              const { chapters } = checklistInfo;
              return chapters.map((chapterInfo, index) => {
                const { chapterId, chapterName, questionCount } = chapterInfo;
                return (
                  <a
                    key={chapterId}
                    href="javascript:void(0);"
                    className={currentChapterTabIndex === index ? 'active' : ''}
                    data-label={chapterName}
                    onClick={() => changeChapterTabIndex(index)}
                  >
                    {chapterName} <em>({questionCount})</em>
                    <button
                      type="button"
                      name="button"
                      className="tabs-tab-remove"
                      onClick={() => openChapterUpdModal(chapterInfo)}
                    >
                      <span className="btn-list"></span>
                    </button>
                    <button
                      type="button"
                      name="button"
                      className="tabs-tab-remove"
                      onClick={() => openChapterUpdModal(chapterInfo)}
                    >
                      <span className="btn-list-blue"></span>
                    </button>
                    <button
                      type="button"
                      name="button"
                      className="tabs-tab-remove"
                      onClick={() => openChapterDelModal(chapterInfo)}
                    >
                      <span className="delete">X</span>
                    </button>
                  </a>
                );
              });
            })}
          </div>

          <div className="menu-tab-nav-operations">
            <button type="button" name="button" className="menu-tab-nav-more">
              <span className="hide">더보기</span>
            </button>

            <button type="button" name="button" className="menu-tab-btn-next" onClick={openChapterAddModal}>
              <span className="hide">챕터 추가</span>
            </button>
          </div>
        </div>
      </div>

      <div className="checklist-contents edit">
        {/* 입력영역 */}
        {dsAuditQuestionList.map((questionInfo, questionListIndex) => {
          const { questionId, content, refManual, priority, probability, severity } = questionInfo;
          const priorityCodeInfo = CodeService.getCodeInfo('CODE_GRP_314', priority);
          const probabilityCodeInfo = CodeService.getCodeInfo('CODE_GRP_315', probability);
          const severityCodeInfo = CodeService.getCodeInfo('CODE_GRP_316', severity);
          return (
            <div key={questionId} className="editbox edit-detile Audit">
              <button type="button" className="tabs-tab-remove" onClick={() => removeQuestion(questionListIndex)}>
                <span className="btnClear">X</span>
              </button>
              <div className="form-table line">
                <div className="form-cell">
                  <div className="form-group wid100">
                    <div className="df">
                      <div className="type7 mt10">
                        <AppTextArea
                          label="Contents"
                          style={{ width: '100%', height: 145 }}
                          errorMessage=""
                          value={content}
                          onChange={(value) => {
                            changeQuestionList(questionListIndex, 'content', value);
                          }}
                        />
                        <div className="form-table">
                          <div className="form-cell wid100">
                            <div className="form-group wid100">
                              <AppTextInput
                                inputType="text"
                                label={'Reference manual'}
                                value={refManual}
                                onChange={(value) => {
                                  changeQuestionList(questionListIndex, 'refManual', value);
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="type8">
                        <div className="form-table">
                          <div className="form-cell wid100">
                            <div className="form-group wid100">
                              <div className="group-box-wrap wid100">
                                <div className="editarea-box Audit">
                                  <div className="form-group wid50">
                                    <AppCodeSelect
                                      label={'Priority'}
                                      codeGrpId="CODE_GRP_314"
                                      value={priority}
                                      onChange={(value) => {
                                        changeQuestionList(questionListIndex, 'priority', value);
                                      }}
                                    />
                                  </div>
                                  <div className="label-box bwid50">
                                    <span className={`Option-tag OptionLevel ${priorityCodeInfo.codeField1}`}>
                                      {priorityCodeInfo.codeNameKor}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="form-table">
                          <div className="form-cell wid50">
                            <div className="form-group wid100">
                              <div className="group-box-wrap wid100">
                                <div className="editarea-box Audit">
                                  <div className="form-group wid50">
                                    <AppCodeSelect
                                      label={'Severity'}
                                      codeGrpId="CODE_GRP_316"
                                      value={severity}
                                      onChange={(value) => {
                                        changeQuestionList(questionListIndex, 'severity', value);
                                      }}
                                    />
                                  </div>

                                  <div className="label-box wid50">
                                    <span className={`Option-tag OptionLevel ${severityCodeInfo.codeField1}`}>
                                      {severityCodeInfo.codeNameKor}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="form-table">
                          <div className="form-cell wid50">
                            <div className="form-group wid100">
                              <div className="group-box-wrap wid100">
                                <div className="editarea-box Audit">
                                  <div className="form-group wid50">
                                    <AppCodeSelect
                                      label={'Probability'}
                                      codeGrpId="CODE_GRP_315"
                                      value={probability}
                                      onChange={(value) => {
                                        changeQuestionList(questionListIndex, 'probability', value);
                                      }}
                                    />
                                  </div>
                                  <div className="label-box wid50">
                                    <span className={`Option-tag OptionLevel ${probabilityCodeInfo.codeField1}`}>
                                      {probabilityCodeInfo.codeNameKor}
                                    </span>
                                  </div>
                                </div>
                                <span className="errorText"></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        {/*//입력영역*/}

        {/*추가버튼*/}
        <div className="btn-area">
          <span className={addQuestionVisible}>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={addQuestion}>
              + Add Question
            </button>
          </span>
        </div>
        {/*//추가버튼*/}
      </div>

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={printChecklistPage}
        >
          Print
        </button>
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={openCheckListDelModal}
        >
          Delete
        </button>
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={openCheckListUpdModal}
        >
          Save
        </button>
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={moveToListPage}
        >
          List
        </button>
      </div>
      {/*//하단버튼영역*/}
      <ChapterAddModal
        isOpen={isChapterAddModal}
        closeModal={closeChapterAddModal}
        ok={(formValue) => okChapterAddModal(formValue)}
      />

      <ChapterUpdModal
        isOpen={isChapterUpdModal}
        detailInfo={detailChapterInfo}
        closeModal={closeChapterUpdModal}
        ok={(formValue) => okChapterUpdModal(formValue)}
      />

      <ChapterDelModal
        isOpen={isChapterDelModal}
        detailInfo={detailChapterInfo}
        closeModal={closeChapterDelModal}
        ok={(formValue) => okChapterDelModal(formValue)}
      />

      <ChecklistUpdModal
        isOpen={isCheckListUpdModal}
        openModalParam={[checklistOrigId, selChecklistName]}
        closeModal={closeCheckListUpdModal}
        ok={(formValue) => okChecklistUpdModal(formValue)}
      />

      <ChecklistDelModal
        isOpen={isCheckListDelModal}
        openModalParam={[checklistOrigId, selChecklistName]}
        closeModal={closeCheckListDelModal}
        ok={(formValue) => okChecklistDelModal(formValue)}
      />
    </>
  );
}

export default AuditCheckListEdit;
