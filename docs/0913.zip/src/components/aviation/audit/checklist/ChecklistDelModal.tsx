import { useState } from 'react';
import Modal from 'react-modal';
import AppTextInput from '@/components/common/AppTextInput';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';
import ModalService from '@/services/ModalService';

const formName = 'ChecklistDelModal';

/* yup validation */
const yupFormSchema = yup.object({
  listName: yup.string().required(),
});

/* form 초기화 */
const initFormValue = {
  listName: '',
};

function ChecklistAddModal(props) {
  const { isOpen, openModalParam, closeModal, ok } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});
  const { listName } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
  };

  const handleClose = () => {
    setErrors({});
    setFormValue({ ...initFormValue });
    closeModal();
  };

  const handleOk = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;

    // 체크리스트명 체크
    if (formValue.listName.trim() != openModalParam[1].trim()) {
      ModalService.alert({
        body: '체크리스트 명을 올바르게 입력하세요.',
      });
      return;
    }

    if (success) {
      ModalService.confirm({
        body: '체크리스트를 삭제하시겠습니까?',
        okLabel: '저장',
        ok: () => {
          ok(formValue);
        },
      });
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'confirm-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">Checklist 삭제</h3>
        <div className="pop_cont">
          <p className="pop_cont">
            체크리스트를 삭제하면 모든 챕터와 문항이 삭제됩니다. 삭제하시겠습니까?
            <br />
            체크리스트명을 아래에 입력하세요.
          </p>
          <p className="pop_cont">{openModalParam[1]}</p>
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    id={formName + openModalParam[0]}
                    label="Checklist Title"
                    value={listName}
                    onChange={(value) => changeInput('listName', value)}
                    errorMessage={errors.listName}
                  />
                  {/*<span className="errorText">auto complete error message</span>*/}
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            취소
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleOk}>
            확인
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default ChecklistAddModal;
