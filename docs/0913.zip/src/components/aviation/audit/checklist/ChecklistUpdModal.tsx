import Modal from 'react-modal';
//import { useState } from 'react';
import { useImmer } from 'use-immer';
import AppCheckbox from '@/components/common/AppCheckbox';
import ModalService from '@/services/ModalService';

const formName = 'ChecklistUpdModal';

/* form 초기화 */
const initFormValue = {
  revisionUpdate: true,
};

function ChecklistUpdModal(props) {
  const { isOpen, closeModal, ok } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  //const [checkboxValue, setCheckboxValue] = useState(true);
  const { revisionUpdate } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
  };

  const handleClose = () => {
    setFormValue({ ...initFormValue });
    closeModal();
  };

  const handleOk = async () => {
    ModalService.confirm({
      body: '저장하시겠습니까?',
      okLabel: '저장',
      ok: () => {
        ok(formValue);
      },
    });
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'confirm-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">Checklist 저장</h3>
        <div className="pop_cont">
          <p className="pop_cont ">Checklist 변경사항을 저장합니다.</p>
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="radio-wrap border-no">
                  <AppCheckbox
                    id={formName + 'revisionUpdate'}
                    label=""
                    checkboxTitle="Revision 업데이트"
                    value={revisionUpdate}
                    //onChange={(value) => setCheckboxValue(value)}
                    onChange={(value) => changeInput('revisionUpdate', value)}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            취소
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleOk}>
            확인
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default ChecklistUpdModal;
