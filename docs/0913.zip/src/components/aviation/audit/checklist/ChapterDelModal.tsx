import { useState, useEffect } from 'react';
import Modal from 'react-modal';
import AppTextInput from '@/components/common/AppTextInput';
import AppCheckbox from '@/components/common/AppCheckbox';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';
import ModalService from '@/services/ModalService';

const formName = 'ChapterDelModal';

/* yup validation */
const yupFormSchema = yup.object({
  inputChapterName: yup.string().required(),
});

/* form 초기화 */
const initFormValue = {
  inputChapterName: '',
  chapterName: '',
  revisionUpdate: true,
};

function ChapterDelModal(props) {
  const { isOpen, detailInfo, closeModal, ok } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});
  const { inputChapterName, chapterName, revisionUpdate } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
  };

  const handleClose = () => {
    setErrors({});
    setFormValue({ ...initFormValue });
    closeModal();
  };

  const handleOk = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;

    // 체크리스트명 체크
    if (inputChapterName.trim() != detailInfo.chapterName.trim()) {
      ModalService.alert({
        body: 'Chapter 명을 올바르게 입력하세요.',
      });
      return;
    }

    if (success) {
      ModalService.confirm({
        body: 'Chapter를 삭제하시겠습니까?',
        okLabel: '저장',
        ok: () => {
          ok(formValue);
        },
      });
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  useEffect(() => {
    if (isOpen && detailInfo) {
      const { chapterName } = detailInfo;
      setFormValue({
        inputChapterName: '',
        chapterName: chapterName,
        revisionUpdate: true,
      });
    } else {
      setErrors({});
    }
  }, [isOpen, detailInfo]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'confirm-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">Checklist 삭제</h3>
        <div className="pop_cont">
          <p className="pop_cont">
            Chapter를 삭제하면 해당 Chapter의 모든 문항이 삭제됩니다. 삭제하시겠습니까?
            <br />
            Chapter명을 아래에 입력하세요.
          </p>
          <p className="pop_cont">{chapterName}</p>
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    id={formName + 'inputChapterName'}
                    label="Checklist Title"
                    value={inputChapterName}
                    onChange={(value) => changeInput('inputChapterName', value)}
                    errorMessage={errors.inputChapterName}
                  />
                  {/*<span className="errorText">auto complete error message</span>*/}
                </div>
                <div className="radio-wrap border-no">
                  <AppCheckbox
                    id={formName + 'revisionUpdate'}
                    label=""
                    checkboxTitle="Revision 업데이트"
                    value={revisionUpdate}
                    //onChange={(value) => setCheckboxValue(value)}
                    onChange={(value) => changeInput('revisionUpdate', value)}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            취소
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleOk}>
            확인
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default ChapterDelModal;
