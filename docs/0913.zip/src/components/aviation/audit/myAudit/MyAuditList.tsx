import AppDatePicker from '@/components/common/AppDatePicker';
import AppNavigation from '@/components/common/AppNavigation';
import AppSelect from '@/components/common/AppSelect';
import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
import AuditCode from '@/config/AuditCode';
import useMyAuditListStore from '@/stores/aviation/audit/myAudit/useMyAuditListStore';
import CommonUtil from '@/utils/CommonUtil';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

function MyAuditList() {
  const state = useMyAuditListStore();
  const {
    enterSearch,
    searchParam,
    list,
    init,
    dsStatistics,
    divAuditYear,
    changeDivAuditYear,
    clickStatusNumber,
    setStatisticsParam,
    clearList,
  } = state;

  const { t } = useTranslation();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      //테이블 column 선언
      { field: 'auditId', headerName: 'Audit Id', cellStyle: { textAlign: 'center' } },
      { field: 'auditNo', headerName: 'Audit No.', cellStyle: { textAlign: 'center' } },
      { field: 'auditAt', headerName: 'Audit Date' },
      { field: 'title', headerName: 'Title', cellStyle: { textAlign: 'center' } },
      { field: 'auditors', headerName: 'Auditors', cellStyle: { textAlign: 'center' } },
      { field: 'cars', headerName: 'CAR', cellStyle: { textAlign: 'center' } },
    ])
  );

  //input value에 넣기 위한 분리 선언
  const { searchWord } = searchParam;

  useEffect(() => {
    init();
    return clearList;
  }, []);

  // const [inputValue, setInputValue] = useState('');
  // const rowData = getAllData();
  // const columns = testColumnInfos;
  // const customButtons = [
  //   {
  //     title: '일괄업로드',
  //     onClick: () => {
  //       alert('일괄업로드');
  //     },
  //   },
  //   {
  //     title: '+ Add Plan',
  //     onClick: () => {
  //       alert('+ Add Plan');
  //     },
  //   },
  //   {
  //     title: 'Fields',
  //     onClick: () => {
  //       alert('Fields');
  //     },
  //     iconClass: 'icon-fields',
  //   },
  // ];

  console.log(`divAuditYear ${divAuditYear}`);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      {/*사용자기준 조회범위영역 */}
      <div className="user-wrap">
        <div className="user-box">
          <div className="user-box-top">
            <div className="form-table user-head">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="df wid30">
                    <AppSelect
                      options={AuditCode.auditYear}
                      value={divAuditYear}
                      onChange={(value) => changeDivAuditYear(value)}
                    />
                  </div>
                  <div className="h4">Div. Audit</div>
                </div>
              </div>
            </div>
            <div className="user-box-bottom">
              <div className="ant-col ant-col-11">
                <dl>
                  <dt className="tot">Total</dt>
                  <dd className="tot-result text-color-blue" onClick={() => clickStatusNumber('1')}>
                    {dsStatistics.divAuditCnt}
                  </dd>
                </dl>
              </div>
              <div className="ant-col">
                <dl className="sub-count">
                  <dt>Finding</dt>
                  <dd>
                    <span className="text-color-blue">
                      {dsStatistics.divFindingCompletedCnt}/{dsStatistics.divFindingCnt}
                    </span>
                    ({dsStatistics.divFindingCompletedPer})
                  </dd>
                </dl>
                <dl className="sub-count">
                  <dt>Observation</dt>
                  <dd>
                    <span className="text-color-blue">
                      {dsStatistics.divObservationCompletedCnt}/{dsStatistics.divObservationCnt}
                    </span>
                    ({dsStatistics.divObservationCompletedPer})
                  </dd>
                </dl>
                <dl className="sub-count">
                  <dt>Overdue</dt>
                  <dd>
                    <span className="text-color-red">{dsStatistics.divDueCnt}</span>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="user-box-top">
            <div className="form-table user-head">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="df wid30">
                    <AppSelect label={'2024'} />
                  </div>
                  <div className="h4">My Audit</div>
                </div>
              </div>
            </div>
            <div className="user-box-bottom">
              <div className="ant-col ant-col-11">
                <dl>
                  <dt className="tot">Total</dt>
                  <dd className="tot-result text-color-blue" onClick={() => clickStatusNumber('2')}>
                    {dsStatistics.myAuditCnt}
                  </dd>
                </dl>
              </div>
              <div className="ant-col">
                <dl className="sub-count">
                  <dt>Finding</dt>
                  <dd>
                    <span className="text-color-blue">
                      {dsStatistics.myFindingCompletedCnt}/{dsStatistics.myFindingCnt}
                    </span>
                    ({dsStatistics.myFindingCompletedPer})
                  </dd>
                </dl>
                <dl className="sub-count">
                  <dt>Observation</dt>
                  <dd>
                    <span className="text-color-blue">
                      {dsStatistics.myObservationCompletedCnt}/{dsStatistics.myObservationCnt}
                    </span>
                    ({dsStatistics.myObservationCompletedPer})
                  </dd>
                </dl>
                <dl className="sub-count">
                  <dt>Overdue</dt>
                  <dd>
                    <span className="text-color-red">{dsStatistics.myDueCnt}</span>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
        <div className="user-box">
          <div className="user-box-top">
            <div className="form-table user-head">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="h4 tit">My Processing All</div>
                </div>
              </div>
            </div>
            <div className="user-box-bottom">
              <div className="wid100">
                <ul className="pro-list">
                  <dl>
                    <dt className="tot">Total</dt>
                    <dd className="tot-result text-color-yellow">{dsStatistics.myProcessingAuditCnt}</dd>
                  </dl>
                  <dl>
                    <dt className="tot">Plan</dt>
                    <dd className="tot-result text-color-blue">{dsStatistics.myProcessingPlanCnt}</dd>
                  </dl>
                  <dl>
                    <dt className="tot">Conduct</dt>
                    <dd className="tot-result text-color-blue">{dsStatistics.myProcessingConductCnt}</dd>
                  </dl>
                  <dl>
                    <dt className="tot">CAR</dt>
                    <dd className="tot-result text-color-blue">{dsStatistics.myProcessingCarCnt}</dd>
                  </dl>
                  <dl>
                    <dt className="tot">Overdue</dt>
                    <dd className="tot-result text-color-red">{dsStatistics.myProcessingDueCnt}</dd>
                  </dl>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*//사용자기준 조회범위영역 */}

      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div id="" className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppSelect label={'Audited Div'} />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group form-glow wid30">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker label={'Audit Date'} />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker label={'Audit Data'} />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput label="Title or CAR Title or AuditorNm" />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppSelect label={'Status'} />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group form-glow wid30">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker label={'Due Date'} />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker label={'Due Data'} />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="group-box-wrap wid100">
                <div className="radio-wrap border-no">
                  <label>
                    <input type="checkbox" checked />
                    <span>Audiror 펼치기</span>
                  </label>
                  <label>
                    <input type="checkbox" />
                    <span>CAR 펼치기</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
              Guide
            </button>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button type="button" name="button" className="arrow button _control active">
          <span className="hide">접기</span>
        </button>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <div className="">
        {/* <AppTable rowData={rowData} columns={columns} customButtons={customButtons} /> */}
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          //handleRowDoubleClick={handleRowDoubleClick}
        />
      </div>
      {/*//그리드영역 */}
    </>
  );
}

export default MyAuditList;
