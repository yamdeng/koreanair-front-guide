import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import Config from '@/config/Config';
import CommonUtil from '@/utils/CommonUtil';
import { useState } from 'react';

const list = [];

for (let index = 1; index <= 10; index++) {
  list.push({
    msgKey: `key${index}`,
    msgKor: `msgKor${index}`,
    msgEng: `msgEng${index}`,
    msgChn: `msgChn${index}`,
    msgJpn: `msgJpn${index}`,
    msgEtc: `msgEtc${index}`,
  });
}

function GuideTableCase5() {
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'msgKey', headerName: '메시지 키', width: 300 },
      { field: 'msgKor', headerName: '설명(한국어)', flex: 1 },
      { field: 'msgEng', headerName: '설명(영어)' },
      { field: 'msgChn', headerName: '설명(중국어)' },
      { field: 'msgJpn', headerName: '설명(일본어)' },
      { field: 'msgEtc', headerName: '설명(기타)' },
    ])
  );

  // rowSelectMode = 'single' 이여도 array[] 형식으로 반환함
  const handleRowSelect = (selectedRowList) => {
    console.log(`selectedInfo : ${selectedRowList}`);
  };

  const rowSelectMode = 'singleRow'; // 체크박스 선택을 하나만 선택 가능
  // const rowSelectMode = 'multipleRow'; // 체크박스 선택을 다수 선택 가능(공통컴포넌트의 기본값)

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          checkbox(multipe, disable)
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideTableCase5.tsx`}>
            GuideTableCase5
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="btn-area">
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            조회
          </button>
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            초기화
          </button>
        </div>
      </div>
      <AppTable
        rowData={list}
        setColumns={setColumns}
        columns={columns}
        handleRowSelect={handleRowSelect}
        enableCheckBox
        rowSelectMode={rowSelectMode}
        isRowSelectable={(rowNode) => (rowNode.data.msgKey === 'key1' || rowNode.data.msgKey === 'key2' ? true : false)}
        hideDisabledCheckboxes
      />
    </>
  );
}

export default GuideTableCase5;
