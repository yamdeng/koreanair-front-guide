import Config from '@/config/Config';
import { useState } from 'react';
import AppNavigation from '../common/AppNavigation';
import AppUserSearch from '../common/AppUserSearch';

function GuideAppUserSearch() {
  const [userEmpNo, setUserEmpNo] = useState('');
  const changeUserEmpNo = (value) => {
    setUserEmpNo(value);
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          GuideAppUserSearch :{' '}
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideAppUserSearch.tsx`}>
            GuideAppUserSearch
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid50">
              <AppUserSearch
                label="사용자 검색"
                value={userEmpNo}
                onChange={(value) => {
                  changeUserEmpNo(value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid50"></div>
          </div>
        </div>
      </div>
    </>
  );
}
export default GuideAppUserSearch;
