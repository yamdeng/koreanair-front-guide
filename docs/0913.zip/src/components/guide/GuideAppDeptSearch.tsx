import { useState } from 'react';
import Config from '@/config/Config';
import AppNavigation from '../common/AppNavigation';
import AppDeptSearch from '../common/AppDeptSearch';

function GuideAppDeptSearch() {
  const [deptCd, setDeptCd] = useState('');
  const changeDeptCd = (value) => {
    setDeptCd(value);
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          GuideAppDeptSearch :{' '}
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideAppDeptSearch.tsx`}>
            GuideAppDeptSearch
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid50">
              <AppDeptSearch
                label="부서검색"
                value={deptCd}
                onChange={(value) => {
                  changeDeptCd(value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid50"></div>
          </div>
        </div>
      </div>
    </>
  );
}
export default GuideAppDeptSearch;
