import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import Config from '@/config/Config';
import CommonUtil from '@/utils/CommonUtil';
import { useState } from 'react';

function GuideTableCase4() {
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'msgKey', headerName: '메시지 키', width: 300 },
      { field: 'msgKor', headerName: '설명(한국어)', flex: 1 },
      { field: 'msgEng', headerName: '설명(영어)' },
      { field: 'msgChn', headerName: '설명(중국어)' },
      { field: 'msgJpn', headerName: '설명(일본어)' },
      { field: 'msgEtc', headerName: '설명(기타)' },
    ])
  );

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          테이블 동적컬럼 반영
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideTableCase4.tsx`}>
            GuideTableCase4
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="btn-area">
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            조회
          </button>
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            초기화
          </button>
        </div>
      </div>
      <AppTable rowData={[]} setColumns={setColumns} columns={columns} useColumnDynamicSetting />
    </>
  );
}

export default GuideTableCase4;
