import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import Config from '@/config/Config';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
import CommonUtil from '@/utils/CommonUtil';

function GuideTableCase3() {
  const columns = testColumnInfos;
  columns[2].enableRowSpan = true; // rowspan 적용할 컬럼에 enableRowSpan=true을 반영

  const rowData = CommonUtil.applyGroupingRowSpanByPageSize(getAllData(), columns[2].field, 50);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          테이블 case3(rowSpan) : 하나의 컬럼만 반영해야하고 sort는 자동으로 false로 적용됨
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideTableCase3.tsx`}>
            GuideTableCase3
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="btn-area">
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            조회
          </button>
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            초기화
          </button>
        </div>
      </div>
      <AppTable rowData={rowData} columns={columns} />
    </>
  );
}

export default GuideTableCase3;
