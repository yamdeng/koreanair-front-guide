import Modal from 'react-modal';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppSelect from '@/components/common/AppSelect';
import { useState } from 'react';

function ApprovalGroupModal(props) {
  const { isOpen, closeModal } = props;
  const [isLayerPopup, setIsLayerPopup] = useState('hide');
  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'alert-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">결제그룹정보 설정</h3>
        <div className="pop_lg_cont_box">
          <div className="pop_flex_group">
            <div className="editbox">
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppSelect label={'결재Group 명'} />
                  </div>
                  <div className="btn-area inbtn">
                    <button
                      type="button"
                      name="button"
                      className="btn-x-sm btn_text btn-darkblue-line"
                      onClick={() => {
                        setIsLayerPopup('show');
                      }}
                    >
                      신규
                    </button>
                    <button type="button" name="button" className="ml3 btn-x-sm btn_text btn-darkgray-line">
                      삭제
                    </button>
                  </div>
                </div>
              </div>

              <hr className="line"></hr>

              <div className="form-table">
                <div className="form-cell">
                  <div className="form-group wid100">
                    <div className="UserChicebox error">
                      <div className="form-group wid100">
                        <AppAutoComplete label="d" />
                        <label htmlFor="file" className="file-label">
                          결재Group Member
                          <span className="required"></span>
                        </label>
                      </div>
                      <div className="form-group wid100 mt10">
                        <div className="SelectedList memberClass">
                          <ul>
                            <li>
                              <span className="num">1</span>
                              <div className="Info">
                                <div className="Name">홍길동 (170****)</div>
                                <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                              </div>
                              <div className="column-box">
                                <span className="column-btn">
                                  <a href="javascript:void(0);">
                                    <span className="up">up</span>
                                  </a>
                                  <a href="javascript:void(0);">
                                    <span className="down">down</span>
                                  </a>
                                </span>
                              </div>
                              <a href="javascript:void(0);">
                                <span className="delete">X</span>
                              </a>
                            </li>
                            <li>
                              <span className="num">2</span>
                              <div className="Info">
                                <div className="Name">홍길동 (170****)</div>
                                <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                              </div>
                              <div className="column-box">
                                <span className="column-btn">
                                  <a href="javascript:void(0);">
                                    <span className="up">up</span>
                                  </a>
                                  <a href="javascript:void(0);">
                                    <span className="down">down</span>
                                  </a>
                                </span>
                              </div>
                              <a href="javascript:void(0);">
                                <span className="delete">X</span>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="btn-area">
                    <button type="button" name="button" className="btn-x-sm btn_text btn-darkblue-line">
                      초기화
                    </button>
                  </div>
                </div>
              </div>

              <hr className="line"></hr>
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={closeModal}>
            저장
          </button>
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            취소
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>

        {/*레이어팝업 */}
        <div className={`modal-overlay ${isLayerPopup}`}></div>
        <div className={`modal ${isLayerPopup}`}>
          <div className="pop_lg_cont_box">
            <div className="pop_flex_group">
              <div className="editbox">
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppSelect label={'결재Group 명'} required />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
              </div>
            </div>
          </div>
          <div className="pop_btns">
            <button className="btn_text text_color_neutral-10 btn_confirm">저장</button>
            <button
              // disabled
              className="btn_text text_color_neutral-90 btn_close"
              onClick={() => {
                console.log('test');
                setIsLayerPopup('hide');
              }}
            >
              취소
            </button>
          </div>
        </div>
        {/*//레이어팝업 */}
      </div>

      {/*style="z-index: 1002; display: block; opacity: 0.5;"*/}
    </Modal>
  );
}

{
  /* <PayGroupModal isOpen={isOpen} closeModal={closeModal} /> */
}

export default ApprovalGroupModal;
