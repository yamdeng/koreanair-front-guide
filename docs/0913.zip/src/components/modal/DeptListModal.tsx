import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useCallback, useEffect, useState } from 'react';
import Modal from 'react-modal';
import { create } from 'zustand';
import AppSearchInput from '../common/AppSearchInput';

const initListData = {
  ...listBaseState,
  listApiPath: 'com/deptList',
};

/* zustand store 생성 */
const DeptListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    searchWord: '',
    searchGubun: '',
    searchLevel: '',
    searchDept: '',
    searchDivision: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        searchWord: '',
        searchGubun: '',
        searchLevel: '',
        searchDept: '',
        searchDivision: '',
      },
    });
  },

  clear: () => {
    set({
      ...listBaseState,
      searchParam: {
        searchWord: '',
        searchGubun: '',
        searchLevel: '',
        searchDept: '',
        searchDivision: '',
      },
    });
  },
}));

function DeptSelectModal(props) {
  const { isOpen, closeModal, isMultiple = false, ok, level, dept, division, gubun } = props;

  console.log('gubun', gubun);
  console.log('level', level);
  console.log('dept', dept);
  console.log('division', division);

  const state = DeptListStore();

  const [columns, setColumns] = useState([
    { field: 'deptCd', headerName: '부서 코드', flex: 1 },
    { field: 'nameKor', headerName: '부서명', flex: 1 },
  ]);

  const [selectDeptList, setSelectDeptList] = useState([]);
  const [selectDeptInfo, setSelectDeptInfo] = useState(null);

  const { enterSearch, searchParam, list, changeSearchInput, initSearchInput, clear } = state;
  const { searchWord, searchGubun, searchLevel, searchDept, searchDivision } = searchParam;

  // 검색 조건 셋팅
  searchParam.searchGubun = gubun;
  searchParam.searchLevel = level;
  searchParam.searchDept = dept;
  searchParam.searchDivision = division;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const { data } = selectedInfo;
    if (!isMultiple) {
      ok(data);
    }
  }, []);

  const handleRowSelect = (selectedInfo) => {
    if (isMultiple) {
      setSelectDeptList(selectedInfo);
    }
  };

  const handleRowSingleClick = (selectedInfo) => {
    const { data } = selectedInfo;
    if (!isMultiple) {
      setSelectDeptInfo(data);
    }
  };

  const handleClose = () => {
    initSearchInput();
    setSelectDeptList([]);
    setSelectDeptInfo(null);
    clear();
    closeModal();
  };

  const handleOk = () => {
    if (isMultiple) {
      ok(selectDeptList);
    } else {
      ok(selectDeptInfo);
    }
    clear();
  };

  useEffect(() => {
    return clear;
  }, []);

  let saveDisabled = false;
  if (isMultiple) {
    if (!selectDeptList || !selectDeptList.length) {
      saveDisabled = true;
    }
  } else {
    if (!selectDeptList) {
      saveDisabled = true;
    }
  }

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={handleClose}
    >
      <div className="popup-container">
        <h3 className="pop_title">부서 목록</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              <div className="boxForm">
                <div id="" className="area-detail active">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <span className="form-group wid100 mr5">
                        <AppSearchInput
                          label="부서명"
                          value={searchWord}
                          onChange={(value) => {
                            changeSearchInput('searchWord', value);
                          }}
                          search={enterSearch}
                        />
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <AppTable
                rowData={list}
                columns={columns}
                enableCheckBox={isMultiple ? true : false}
                handleRowSelect={handleRowSelect}
                handleRowDoubleClick={handleRowDoubleClick}
                handleRowSingleClick={handleRowSingleClick}
                setColumns={setColumns}
              />
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleOk} disabled={saveDisabled}>
            확인
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default DeptSelectModal;
