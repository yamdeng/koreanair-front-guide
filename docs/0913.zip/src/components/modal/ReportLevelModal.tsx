import AppSelect from '@/components/common/AppSelect';
import ApiService from '@/services/ApiService';
import { createListSlice } from '@/stores/slice/listSlice';
import { useEffect, useRef } from 'react';
import Modal from 'react-modal';
import { create } from 'zustand';
import AppDatePicker from '../common/AppDatePicker';

// TODO : 검색 초기값 설정
const initSearchParam = {};

/* zustand store 생성 */
const usePSPIReportModalStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {},

  consequenceList: [],
  hazardList: [],
  riskMatrixList: [],
  riskInfo: [],
  riskPbbtList: [],
  riskSvrtList: [],

  selectConsequenceId: '',
  selectHazardId: '',

  isReportLevelModal: false,

  handleReportLevelModal: (val) => {
    set({ isReportLevelModal: val });
  },

  initInfoSearch: async () => {
    set({ multipleSelectValue: [] });
    const apiParam = {};
    const apiResult = await ApiService.get(`avn/common/risk-matrix-info`, apiParam);
    set({ hazardList: apiResult.data.hazard });
    set({ consequenceList: apiResult.data.consequence });

    set({ riskMatrixList: apiResult.data.riskMatrix });
    set({ riskPbbtList: apiResult.data.riskPbbt });
    set({ riskSvrtList: apiResult.data.riskSvrt });

    const { riskMatrixList, riskPbbtList, riskSvrtList } = get();
    console.log(riskPbbtList);
    const arr = [];
    for (let i = 0; i < 5; i++) {
      arr.push(
        <tr key={'risk' + i}>
          <th>{5 - i}</th>
          <td id={'risk' + riskMatrixList[0 + i * 5].riskLevelCd} className={riskMatrixList[0 + i * 5].colorCd}>
            {riskMatrixList[0 + i * 5].riskLevelCd}
          </td>
          <td id={'risk' + riskMatrixList[1 + i * 5].riskLevelCd} className={riskMatrixList[1 + i * 5].colorCd}>
            {riskMatrixList[1 + i * 5].riskLevelCd}
          </td>
          <td id={'risk' + riskMatrixList[2 + i * 5].riskLevelCd} className={riskMatrixList[2 + i * 5].colorCd}>
            {riskMatrixList[2 + i * 5].riskLevelCd}
          </td>
          <td id={'risk' + riskMatrixList[3 + i * 5].riskLevelCd} className={riskMatrixList[3 + i * 5].colorCd}>
            {riskMatrixList[3 + i * 5].riskLevelCd}
          </td>
          <td id={'risk' + riskMatrixList[4 + i * 5].riskLevelCd} className={riskMatrixList[4 + i * 5].colorCd}>
            {riskMatrixList[4 + i * 5].riskLevelCd}
          </td>
        </tr>
      );
    }
    set({ riskInfo: arr });
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ searchParam: { ...initSearchParam } });
  },
}));

function ReportLevelModal(props) {
  const state = usePSPIReportModalStore();

  const {
    searchParam,
    changeStateProps,
    changeSearchInput,
    spiCodeSearch,
    spiCodeList,
    isReportLevelModal,
    handleReportLevelModal,
    initInfoSearch,
    hazardList,
    consequenceList,
    riskMatrixList,
    riskInfo,
    riskPbbtList,
    riskSvrtList,
    selectConsequenceId,
    selectHazardId,
    clear,
  } = state;

  // input value에 넣기 위한 분리 선언
  const { year, spiType, spiCode } = searchParam;

  const { isOpen, closeModal } = props;

  const hazardUl = useRef();
  const consequenceUl = useRef();

  const activeControlClick = (gubun, event, value) => {
    let targetTag;
    let targetKeyName = '';
    const targetUl = gubun == 'consequence' || gubun == 'consequenceSelect' ? consequenceUl : hazardUl;

    // id={'hazard' + hazardLvthreeId}

    if (event) {
      if (event.target.tagName == 'A') targetTag = event.target.parentElement;
      else targetTag = event.target;

      if (gubun == 'consequence') {
        changeStateProps('selectConsequenceId', value);
      } else {
        changeStateProps('selectHazardId', value);
      }

      console.log(targetTag);
    } else {
      if (gubun == 'consequenceSelect') {
        targetKeyName = 'consequence' + value;
        changeStateProps('selectConsequenceId', value);
      } else {
        targetKeyName = 'hazard' + value;
        changeStateProps('selectHazardId', value);
      }
    }

    targetUl.current.querySelectorAll('li').forEach(function (item) {
      item.className = '';
      if (item.id == targetKeyName) targetTag = item;
    });
    targetTag.className = 'active';
    targetTag.focus();
  };

  useEffect(() => {
    initInfoSearch();
    return clear;
  }, []);
  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'risk-level-search-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">위험레벨 조회</h3>
        <div className="pop_full_cont_box">
          <div className="RiskLevel-box">
            <div className="RiskLevel-list">
              <div className="RiskLevel-top-box">
                <div className="RiskLevel-Left">
                  <div className="h4-tit">Potential Consequence</div>
                  <div className="boxlist-wrap">
                    <div className="form-table">
                      <div className="form-cell">
                        <div className="form-group wid100">
                          <AppSelect
                            id="consequenceSelect"
                            name="consequenceSelect"
                            labelKey="consequenceKoNm"
                            valueKey="consequenceId"
                            options={consequenceList}
                            value={selectConsequenceId}
                            onChange={(value) => activeControlClick('consequenceSelect', null, value)}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="RiskLevel-Right">
                  <div className="h4-tit">Hazard Taxonomy</div>
                  <div className="boxlist-wrap">
                    <div className="form-table">
                      <div className="form-cell">
                        <div className="form-group wid100">
                          <AppSelect
                            id="hazardSelect"
                            name="hazardSelect"
                            labelKey="hazardLvthreeNm"
                            valueKey="hazardLvthreeId"
                            options={hazardList}
                            value={selectHazardId}
                            onChange={(value) => activeControlClick('hazardSelect', null, value)}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/*버튼 */}
                <div className="pop_btns_">
                  <button className="btn_text text_color_neutral-10 btn_confirm">초기화</button>
                </div>
              </div>

              <div className="df">
                <div className="list-box-a">
                  <div className="box-list">
                    <ul className="list" id="consequenceUl" ref={consequenceUl}>
                      {consequenceList.map((info, index) => {
                        const { consequenceId, consequenceKoNm } = info;
                        return (
                          <li
                            key={'consequence' + consequenceId}
                            id={'consequence' + consequenceId}
                            onClick={(e) => activeControlClick('consequence', e, consequenceId)}
                          >
                            <a href={undefined}>
                              {consequenceKoNm.length > 30 ? consequenceKoNm.substr(1, 30) + '...' : consequenceKoNm}
                            </a>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>
                <div className="list-box-b">
                  <div className="box-list">
                    <ul className="list" id="hazardUl" ref={hazardUl}>
                      {hazardList.map((info, index) => {
                        const { hazardLvthreeId, hazardLvthreeNm } = info;
                        return (
                          <li
                            key={'hazard' + hazardLvthreeId}
                            id={'hazard' + hazardLvthreeId}
                            onClick={(e) => activeControlClick('hazard', e, hazardLvthreeId)}
                          >
                            <a href={undefined}>
                              {hazardLvthreeNm.length > 30 ? hazardLvthreeNm.substr(1, 30) + '...' : hazardLvthreeNm}
                            </a>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="RiskLevel-area">
              <div className="h4-tit">Risk Level</div>
              {/*검색영역*/}
              <div className="search-area">
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="chk-wrap">
                      <label>
                        <input type="checkbox" checked />
                        <span>
                          이벤트 타입 : <span className="txt">Bird Strike</span>
                        </span>
                      </label>
                    </div>
                  </div>
                </div>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="chk-wrap">
                      <label>
                        <input type="checkbox" />
                        <span>
                          Potential Consequence : <span className="txt">Aircraft Change</span>
                        </span>
                      </label>
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="chk-wrap">
                      <label>
                        <input type="checkbox" />
                        <span>
                          Hazard Taxonomy : <span className="txt">Snow/Slush encounter</span>
                        </span>
                      </label>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="flex-e form-table mt10">
                  <div className="form-area">
                    <div className="flag-tag1">
                      <span className="icon-flag1 txt btn-lightblue">기간선택</span>
                      <span className="icon-flag1 txt btn-lightblue">전체</span>
                      <span className="icon-flag1 txt btn-lightblue">최근3년</span>
                      <span className="icon-flag1 txt btn-lightblue">1년</span>
                      <span className="icon-flag1 txt btn-lightblue active">6개월</span>
                      {/* 선택되는 부분은 class명에 active 표시*/}
                    </div>
                    <div className="form-cell">
                      <div className="form-group">
                        <div className="df">
                          <div className="date1">
                            <AppDatePicker label={'날짜선택'} />
                          </div>
                          <span className="unt">~</span>
                          <div className="date2">
                            <AppDatePicker label={'날짜선택'} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="pop_btns_">
                    <button className="btn_text text_color_neutral-10 btn_confirm">조회</button>
                  </div>
                </div>
              </div>
              {/*//검색영역*/}
              <div className="Level-area">
                <div className="LevelTop">
                  <div className="flex-box">
                    <div className="h5-tit">Risk</div>
                    <span className="total">
                      <span className="text_color-Warning">861</span>건
                    </span>
                  </div>
                  <div className="">
                    <table className="RiskLevelTable Risk">
                      <caption></caption>
                      <colgroup></colgroup>
                      <thead>
                        <tr>
                          <th rowSpan={2}>
                            발생
                            <br />
                            가능성
                          </th>
                          <th colSpan={5}>심각도</th>
                        </tr>
                        <tr>
                          <th>LevelA</th>
                          <th>LevelB</th>
                          <th>LevelC</th>
                          <th>LevelD</th>
                          <th>LevelE</th>
                        </tr>
                      </thead>
                      <tbody>{riskInfo}</tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div className="LevelInfo mt10">
                <p className="h5-tit">발생 가능성</p>
                <div className="tableTop">
                  <table className="RiskLevelTable left">
                    <caption></caption>
                    <colgroup></colgroup>
                    <thead>
                      <tr>
                        <th>구분</th>
                        <th>발생가능성</th>
                        <th>정성적평가</th>
                        <th>정량적평가</th>
                      </tr>
                    </thead>
                    <tbody>
                      {riskPbbtList.map((info, index) => {
                        const { codeNameKor, codeField1, codeField2 } = info;
                        return (
                          <tr key={'Pbbt' + index}>
                            <th>{riskPbbtList.length - index}</th>
                            <td className="">{codeNameKor}</td>
                            <td className="tl">{codeField1}</td>
                            <td className="tl">{codeField2}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="Level-area-bottom">
                <p className="h5-tit">심각도</p>
                <div className="tableTop">
                  <table className="RiskLevelTable severity">
                    <caption></caption>
                    <colgroup></colgroup>
                    <thead>
                      <tr>
                        <th>순번</th>
                        <th>심각도구분</th>
                        <th>매우심각</th>
                        <th>위험</th>
                        <th>중요</th>
                        <th>경이</th>
                        <th>매우경미</th>
                      </tr>
                    </thead>
                    <tbody>
                      {riskSvrtList.map((info, index) => {
                        const { codeNameKor, codeField1, codeField2, codeField3, codeField4, codeField5 } = info;
                        return (
                          <tr key={'Svrt' + index}>
                            <th>{riskSvrtList.length - index}</th>
                            <td className="">{codeNameKor}</td>
                            <td className="">{codeField1}</td>
                            <td className="">{codeField2}</td>
                            <td className="">{codeField3}</td>
                            <td className="">{codeField4}</td>
                            <td className="">{codeField5}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            닫기
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={closeModal}>
            선택
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default ReportLevelModal;
