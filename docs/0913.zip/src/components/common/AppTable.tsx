import Config from '@/config/Config';
import CommonUtil from '@/utils/CommonUtil';
import { AgGridReact } from 'ag-grid-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Modal from 'react-modal';
import { useImmer } from 'use-immer';
import AppSelect from './AppSelect';
import AppTextInput from './AppTextInput';
import GridActionButtonComponent from './GridActionButtonComponent';
import GridLinkComponent from './GridLinkComponent';
import ModalService from '@/services/ModalService';

const basicDefaultColDef = {
  sortable: true,
  filter: false,
  wrapText: false,
  autoHeight: true,
  minWidth: 100,
};

const convertColumns = (columns) => {
  const searchRowSpanColumn = columns.find((columnInfo) => columnInfo.enableRowSpan);
  const result = columns.map((columnInfo) => {
    if (columnInfo.isLink) {
      // 링크 cell convert
      columnInfo.cellRenderer = GridLinkComponent;
      columnInfo.cellRendererParams = {
        linkPath: columnInfo.linkPath,
        detailPath: columnInfo.detailPath,
        isWindowOpen: columnInfo.isWindowOpen,
      };
    } else if (columnInfo.field === 'actionsByOption') {
      // action button cell convert
      columnInfo.cellRenderer = GridActionButtonComponent;
      columnInfo.cellRendererParams = {
        actionButtons: columnInfo.actionButtons,
        actionButtonListPath: columnInfo.actionButtonListPath,
        search: columnInfo.search,
      };
    }

    if (columnInfo.enableRowSpan) {
      // rowSpan 적용
      columnInfo.rowSpan = (params) => {
        const rowspanCount = params.data.rowSpanGroupCount ? params.data.rowSpanGroupCount : 1;
        return rowspanCount;
      };
      columnInfo.cellClassRules = {
        'cell-span': (params) => params.data.rowSpanGroupCount && params.data.rowSpanGroupCount > 1,
      };
    }
    if (searchRowSpanColumn) {
      columnInfo.sortable = false;
    }
    return columnInfo;
  });
  return result;
};

const LoadingComponent = (props) => {
  const { loadingMessage } = props;
  return (
    <div className="ag-overlay-loading-center" role="presentation">
      <div
        role="presentation"
        style={{
          height: 100,
          width: 100,
          background: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cg%3E%3Ccircle cx='12' cy='2.5' r='1.5' fill='%23000' opacity='0.14'/%3E%3Ccircle cx='16.75' cy='3.77' r='1.5' fill='%23000' opacity='0.29'/%3E%3Ccircle cx='20.23' cy='7.25' r='1.5' fill='%23000' opacity='0.43'/%3E%3Ccircle cx='21.5' cy='12' r='1.5' fill='%23000' opacity='0.57'/%3E%3Ccircle cx='20.23' cy='16.75' r='1.5' fill='%23000' opacity='0.71'/%3E%3Ccircle cx='16.75' cy='20.23' r='1.5' fill='%23000' opacity='0.86'/%3E%3Ccircle cx='12' cy='21.5' r='1.5' fill='%23000'/%3E%3CanimateTransform attributeName='transform' calcMode='discrete' dur='0.75s' repeatCount='indefinite' type='rotate' values='0 12 12;30 12 12;60 12 12;90 12 12;120 12 12;150 12 12;180 12 12;210 12 12;240 12 12;270 12 12;300 12 12;330 12 12;360 12 12'/%3E%3C/g%3E%3C/svg%3E") center / contain no-repeat`,
          margin: '0 auto',
        }}
      ></div>
      <div aria-live="polite" aria-atomic="true">
        {loadingMessage}
      </div>
    </div>
  );
};

function AppTable(props) {
  const gridRef = useRef<any>(null);
  const {
    className,
    rowData,
    columns,
    setColumns,
    customButtons = [],
    tableHeight = Config.defaultGridHeight,
    noDataMessage = Config.defaultGridNoDataMessage,
    displayTableLoading = false,
    handleRowDoubleClick,
    handleRowSingleClick,
    handleRowSelect,
    rowSelectMode = 'multiRow',
    enableCheckBox = false,
    hideDisabledCheckboxes = false,
    isRowSelectable = () => true,
    pageSize = Config.defaultGridPageSize,
    pageSizeList = Config.defaultPageSizeList,
    displayCSVExportButton = false,
    gridTotalCountTemplate = Config.defaultGridTotalCountTemplate,
    useColumnDynamicSetting = false,
    useActionButtons = false,
    actionButtons = ['detail', 'delete'],
    actionButtonListPath = '',
    getGridRef,
    applyAutoHeight,
    search,
    store = null,
    hiddenPagination,
    hiddenTableHeader = false,
    readOnlyEdit = true,
    defaultColDef = basicDefaultColDef,
    localStorgeKey = '',
    ...rest
  } = props;

  // store
  const { currentPage, prevPage, nextPage, totalCount, displayPageIndexList = [], changePageSize } = store || {};

  // 컬럼 동적 셋팅 모달 open
  const [isColumnSettingModalOpen, setIsColumnSettingModalOpen] = useState(false);
  const [dynamicApplyColumnList, setDynamicApplyColumnList] = useImmer([]);

  const selection = useMemo(() => {
    if (enableCheckBox) {
      return {
        mode: rowSelectMode,
        hideDisabledCheckboxes: hideDisabledCheckboxes,
        isRowSelectable: isRowSelectable,
      };
    }
    return null;
  }, [enableCheckBox]);

  const searchRowSpanIndex = columns.findIndex((info) => info.enableRowSpan);
  const searchActionButtonIndex = columns.findIndex((info) => info.field === 'actionsByOption');

  if (useActionButtons && searchActionButtonIndex === -1) {
    columns.push({
      field: 'actionsByOption',
      headerName: 'Actions',
      actionButtons: actionButtons,
      actionButtonListPath: actionButtonListPath,
      search: store ? store.search : search,
    });
  }

  // columns convert 작업
  const applyColumns = convertColumns(columns);

  const loadingOverlayComponent = useMemo(() => {
    return LoadingComponent;
  }, []);

  const loadingOverlayComponentParams = useMemo(() => {
    return {
      loadingMessage: 'wait please...',
    };
  }, []);

  const onSelectionChanged = useCallback(() => {
    const selectedRows = gridRef.current.api.getSelectedRows();
    return handleRowSelect(selectedRows);
  }, []);

  const downloadCSVFile = useCallback(() => {
    // '', '\t', '|'
    const optionParam = {
      columnSeparator: '|',
      suppressQuotes: true, // true인 경우 ""이 제거됨
      skipColumnGroupHeaders: false,
      skipColumnHeaders: false,
      allColumns: false, // column에 설정된 hide는 기본적으로 무시되어서 처리됨
    };
    gridRef.current.api.exportDataAsCsv(optionParam);
  }, []);

  const saveColumnInfos = useCallback(() => {
    setIsColumnSettingModalOpen(false);
    const updateColumns = CommonUtil.saveColumnInfos(dynamicApplyColumnList, localStorgeKey);
    if (setColumns) {
      setColumns(updateColumns);
    }
  }, [dynamicApplyColumnList]);

  const cancelColumnInfos = useCallback(() => {
    setDynamicApplyColumnList(columns);
    setIsColumnSettingModalOpen(false);
  }, [dynamicApplyColumnList]);

  const resetColumnInfos = useCallback(() => {
    ModalService.confirm({
      title: '컬럼 초기화',
      body: '컬럼 초기화시 해당 페이지가 reload 됩니다.\n초기화하시겠습니까?.',
      ok: () => {
        CommonUtil.removeToLocalStorage(localStorgeKey ? localStorgeKey : location.pathname);
        window.location.reload();
      },
    });
  }, [dynamicApplyColumnList, localStorgeKey]);

  const changeColumnHide = (event, index) => {
    const checked = event.target.checked;
    setDynamicApplyColumnList((beforeDynamicApplyColumnList) => {
      if (checked) {
        beforeDynamicApplyColumnList[index].hide = false;
      } else {
        beforeDynamicApplyColumnList[index].hide = true;
      }
    });
  };

  const changeColumnName = (value, index) => {
    const headerName = value;
    setDynamicApplyColumnList((beforeDynamicApplyColumnList) => {
      beforeDynamicApplyColumnList[index].headerName = headerName;
    });
  };

  const changeColumnWidth = (value, index) => {
    const width = value;
    setDynamicApplyColumnList((beforeDynamicApplyColumnList) => {
      beforeDynamicApplyColumnList[index].width = width;
    });
  };

  const up = (listIndex) => {
    setDynamicApplyColumnList((beforeDynamicApplyColumnList) => {
      if (listIndex > 0) {
        const beforeInfo = beforeDynamicApplyColumnList[listIndex];
        const nextInfo = beforeDynamicApplyColumnList[listIndex - 1];
        beforeDynamicApplyColumnList[listIndex - 1] = beforeInfo;
        beforeDynamicApplyColumnList[listIndex] = nextInfo;
      }
    });
  };

  const down = (listIndex) => {
    setDynamicApplyColumnList((beforeDynamicApplyColumnList) => {
      if (listIndex < beforeDynamicApplyColumnList.length - 1) {
        const beforeInfo = beforeDynamicApplyColumnList[listIndex];
        const nextInfo = beforeDynamicApplyColumnList[listIndex + 1];
        beforeDynamicApplyColumnList[listIndex + 1] = beforeInfo;
        beforeDynamicApplyColumnList[listIndex] = nextInfo;
      }
    });
  };

  useEffect(() => {
    if (gridRef && gridRef.current && gridRef.current.api) {
      if (displayTableLoading) {
        gridRef.current.api.showLoadingOverlay();
      } else {
        gridRef.current.api.hideOverlay();
      }
    }
  }, [displayTableLoading]);

  useEffect(() => {
    setDynamicApplyColumnList(columns);
  }, [columns]);

  return (
    <>
      <div className="table-header" style={{ display: hiddenTableHeader ? 'none' : '' }}>
        <div className="count">
          Total {CommonUtil.formatString(gridTotalCountTemplate, store ? totalCount : rowData.length)}
        </div>
        <div className="btns-area">
          {customButtons.map((info) => {
            const { title, onClick } = info;
            return (
              <button
                key={title}
                name="button"
                className="btn_text btn_confirm text_color_neutral-10"
                onClick={onClick}
              >
                {title}
              </button>
            );
          })}
          <button
            name="button"
            className="btn_text btn_confirm text_color_neutral-10"
            onClick={downloadCSVFile}
            style={{ display: displayCSVExportButton ? '' : 'none' }}
          >
            download csv
          </button>
          <button
            name="button"
            className="btn_text btn_confirm text_color_neutral-10"
            onClick={() => setIsColumnSettingModalOpen(true)}
            style={{ display: useColumnDynamicSetting ? '' : 'none' }}
          >
            동적 필드 적용
          </button>
          <span>
            <AppSelect
              style={{ width: 150, display: hiddenPagination || !store ? 'none' : '' }}
              onChange={(size) => {
                changePageSize(size);
              }}
              value={store ? store.pageSize : pageSize}
              options={pageSizeList.map((size) => {
                return { value: size, label: size };
              })}
            />
          </span>
        </div>
      </div>
      <div className={className ? `ag-theme-quartz ${className}` : 'ag-theme-quartz'} style={{ height: tableHeight }}>
        <AgGridReact
          {...rest}
          ref={gridRef}
          rowModelType="clientSide"
          suppressServerSideSorting={true}
          suppressMultiSort={true}
          domLayout={applyAutoHeight ? 'autoHeight' : 'normal'}
          rowData={rowData}
          columnDefs={applyColumns}
          loadingOverlayComponent={loadingOverlayComponent}
          loadingOverlayComponentParams={loadingOverlayComponentParams}
          overlayNoRowsTemplate={noDataMessage}
          onSelectionChanged={onSelectionChanged}
          onRowDoubleClicked={handleRowDoubleClick}
          onRowClicked={handleRowSingleClick}
          selection={selection}
          paginationPageSize={store ? store.pageSize : pageSize}
          paginationPageSizeSelector={pageSizeList}
          pagination={false}
          suppressRowTransform={searchRowSpanIndex !== -1 ? true : false}
          defaultColDef={defaultColDef}
          tooltipShowDelay={100}
          tooltipHideDelay={1000}
          tooltipMouseTrack={true}
          enableBrowserTooltips={false}
          readOnlyEdit={readOnlyEdit}
          onGridReady={(params) => {
            if (displayTableLoading) {
              params.api.showLoadingOverlay();
            } else {
              params.api.hideOverlay();
            }
            if (getGridRef) {
              getGridRef(params);
            }
          }}
        />
      </div>

      {useColumnDynamicSetting && (
        <Modal
          shouldCloseOnOverlayClick={false}
          isOpen={isColumnSettingModalOpen}
          ariaHideApp={false}
          overlayClassName={'alert-modal-overlay'}
          className={'alert-modal-content'}
          onRequestClose={() => {
            cancelColumnInfos();
          }}
        >
          <div className="popup-container">
            <h3 className="pop_title">컬럼 저장 모달</h3>
            <div className="pop_cont">
              <div className="tablebox">
                <table className="columntable">
                  <colgroup>
                    <col width="10%" />
                    <col width="*" />
                    <col width="40%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th></th>
                      <th>Display Text</th>
                      <th>Width</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dynamicApplyColumnList.map((columnInfo, index) => {
                      const { field, headerName, width, hide } = columnInfo;
                      const applyWidth = width;
                      return (
                        <tr key={field}>
                          <td>
                            <div className="chk-wrap center">
                              <label className="text-no">
                                <input
                                  type="checkbox"
                                  onChange={(event) => changeColumnHide(event, index)}
                                  checked={hide ? false : true}
                                />
                                <span className="text-no"></span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-group wid100">
                              <AppTextInput
                                value={headerName}
                                onChange={(value) => changeColumnName(value, index)}
                                hiddenClearButton
                              />
                            </div>
                          </td>
                          <td>
                            <div className="form-group wid100">
                              <div className="column-box">
                                <AppTextInput
                                  value={applyWidth}
                                  onChange={(value) => changeColumnWidth(value, index)}
                                  hiddenClearButton
                                />
                                <span className="column-btn">
                                  <a href={undefined} onClick={() => up(index)}>
                                    <span className="up">up</span>
                                  </a>
                                  <a href={undefined} onClick={() => down(index)}>
                                    <span className="down">down</span>
                                  </a>
                                </span>
                              </div>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="pop_btns">
              <button className="btn_text text_color_neutral-10 btn_confirm" onClick={saveColumnInfos}>
                저장
              </button>
              <button className="btn_text text_color_neutral-90 btn_close" onClick={cancelColumnInfos}>
                취소
              </button>
              <button className="btn_text text_color_neutral-90 btn_close" onClick={resetColumnInfos}>
                Reset
              </button>
            </div>
            <span className="pop_close" onClick={cancelColumnInfos}>
              X
            </span>
          </div>
        </Modal>
      )}

      <div className="pagination" style={{ display: hiddenPagination ? 'none' : '' }}>
        <a
          className="first"
          href=""
          style={{ display: prevPage ? '' : 'none' }}
          onClick={(event) => {
            event.preventDefault();
            store.goFirstPage();
          }}
        >
          <span className="sr-only">이전</span>
        </a>
        <a
          className="prev"
          href=""
          style={{ display: prevPage ? '' : 'none' }}
          onClick={(event) => {
            event.preventDefault();
            store.changeCurrentPage(prevPage);
          }}
        >
          <span className="sr-only">이전</span>
        </a>
        <span>
          {displayPageIndexList.map((pageIndex) => {
            let pageComponent = (
              <a
                href=""
                key={pageIndex}
                onClick={(event) => {
                  event.preventDefault();
                  store.changeCurrentPage(pageIndex);
                }}
              >
                {pageIndex}
              </a>
            );
            if (pageIndex === currentPage) {
              pageComponent = (
                <strong
                  title="현재페이지"
                  key={pageIndex}
                  onClick={() => {
                    store.changeCurrentPage(pageIndex);
                  }}
                >
                  {pageIndex}
                </strong>
              );
            }
            return pageComponent;
          })}
        </span>
        <a
          className="next"
          href=""
          style={{ display: nextPage ? '' : 'none' }}
          onClick={(event) => {
            event.preventDefault();
            store.changeCurrentPage(nextPage);
          }}
        >
          <span className="sr-only">다음</span>
        </a>
        <a
          className="last"
          href=""
          style={{ display: nextPage ? '' : 'none' }}
          onClick={(event) => {
            event.preventDefault();
            store.goLastPage();
          }}
        >
          <span className="sr-only">다음</span>
        </a>
      </div>
    </>
  );
}

export default AppTable;
