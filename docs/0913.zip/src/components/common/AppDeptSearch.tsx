import AppAutoComplete from '@/components/common/AppAutoComplete';

import { getDeptLabelByLocale } from '@/services/i18n';

function AppDeptSearch(props) {
  const { ...rest } = props;

  return (
    <AppAutoComplete
      {...rest}
      apiUrl={'com/deptList'}
      dataKey="data.list"
      valueKey="deptCd"
      isMultiple={false}
      getOptionLabel={(info) => {
        return getDeptLabelByLocale(info);
      }}
      filterOption={() => true}
      isValueString
    />
  );
}

export default AppDeptSearch;
