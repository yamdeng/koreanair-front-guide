import { create } from 'zustand';
import useOcuWorkPermitStatusStore from './useOcuWorkPermitStatusStore';

/* zustand store 생성 */
const useOcuWorkPermitManageStore = create<any>((set) => ({
  tabIndex: 0,

  changeTab: (tabIndex) => {
    set({ tabIndex: tabIndex });
    // TODO : 탭이 바뀔때 마다 해당 탭의 데이터를 조회할지 여부 판단
    if (tabIndex === 0) {
      // 현황 탭일때 초기화
      useOcuWorkPermitStatusStore.getState().init();
    } else {
      // 조회 탭일때 초기화
    }
  },

  clear: () => {
    // TODO : clear
    set({ tabIndex: 0 });
  },
}));

export default useOcuWorkPermitManageStore;
