import { create } from 'zustand';
import { produce } from 'immer';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import CommonUtil from '@/utils/CommonUtil';

/* yup validation */
const yupFormSchema = yup.object({
  // 외주작업 특별교육 선택

  // 특별교육 선택 ID
  spclEduChcId: yup.number(),
  // 특별교육 항목 코드
  spclEduItemCd: yup.string(),
  // 선택 여부
  chcYn: yup.string(),
  // 공사_ID
  cntrId: yup.number().required(),
  // 첨부파일_ID
  fileId: yup.number().required(),
  // 등록_일시
  regDttm: yup.string().required(),
  // 등록자_ID
  regUserId: yup.string().required(),
  // 수정_일시
  updDttm: yup.string().required(),
  // 수정자_ID
  updUserId: yup.string().required(),
});

/* form 초기값 상세 설정 */
const initFormValue = {
  // 특별교육 선택 ID
  spclEduChcId: '',
  // 특별교육 항목 코드
  spclEduItemCd: '',
  // 선택 여부
  chcYn: '',
  // 공사_ID
  cntrId: '',
  // 첨부파일_ID
  fileId: '',
  // 등록_일시
  regDttm: '',
  // 등록자_ID
  regUserId: '',
  // 수정_일시
  updDttm: '',
  // 수정자_ID
  updUserId: '',
};

/** form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitEduChoiceModalStore',

  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuWorkPermitEduChoiceModalStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  isEduChoiceModalOpen: false,

  eduChoiceModalInfo: null,

  saveEduChoiceModal: (eduChoiceFormValue) => {
    set(
      produce((state: any) => {
        const newFormValue = { ...state.formValue };
        newFormValue.eduChocieList.push(eduChoiceFormValue);
        state.formValue = newFormValue;
        state.isEduChoiceModalOpen = false;
      })
    );
  },

  // openEduChoiceModal: (detailInfo = null) => {
  //   set({ isEduChoiceModalOpen: true, eduChoiceModalInfo: detailInfo });
  // },

  // closeEduChoiceModal: () => {
  //   set({ isEduChoiceModalOpen: false });
  // },

  removeFileAttach: (removeIndex) => {
    set(
      produce((state: any) => {
        const newFormValue = { ...state.formValue };
        newFormValue.eduChocieList.splice(removeIndex, 1);
        state.formValue = newFormValue;
      })
    );
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuWorkPermitEduChoiceModalStore;
