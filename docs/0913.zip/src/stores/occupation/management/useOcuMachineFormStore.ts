import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  mchnInstrId: yup.number().required(),
  // 기계분류코드
  mchnInstrClsCd: yup.string().required(),
  // 기계기구명
  mchnInstrNm: yup.string(),
  // 자산번호
  asetNo: yup.string().required(),
  // 단위
  unit: yup.string().required(),
  // 방호장치
  prtcDev: yup.string(),
  // 위치
  position: yup.string(),
  // 부문 코드
  sectCd: yup.string().required(),
  // 부서코드
  deptCd: yup.string().required(),
  // 관리자 사번
  adminEmpno: yup.string().required(),
  // 사용 여부
  useYn: yup.string(),
  // 도입일자
  intrDt: yup.string(),
  // 폐기일자
  discardDt: yup.string(),
  // 안전인증 대상여부
  sftyCrtfcTargetYn: yup.string().required(),
  // 안전인증 합격번호
  sftyCrtfcPassNo: yup.string(),
  // 안전검사 대상여부
  sftyAuditTargetYn: yup.string().required(),
  // 첨부사진1 ID
  pohtoId1: yup.number().nullable(),
  // 첨부사진2 ID
  pohtoId2: yup.number().nullable(),
  // 등록일시
  regDttm: yup.string().required(),
  // 등록자 ID
  regUserId: yup.string().required(),
  // 수정일시
  updDttm: yup.string().required(),
  // 수정자 ID
  updUserId: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  mchnInstrId: null,
  mchnInstrClsCd: '',
  mchnInstrNm: '',
  asetNo: '',
  unit: '',
  prtcDev: '',
  position: '',
  sectCd: '',
  deptCd: '',
  adminEmpno: '',
  useYn: '',
  intrDt: '',
  discardDt: '',
  sftyCrtfcTargetYn: '',
  sftyCrtfcPassNo: '',
  sftyAuditTargetYn: '',
  pohtoId1: null,
  pohtoId2: null,
  regDttm: '',
  regUserId: '',
  updDttm: '',
  updUserId: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/machine',
  baseRoutePath: 'ocu/management/machine',
  formName: 'useOcuMachineFormStore',
  formValue: {
    ...initFormValue,
  }
};

/* zustand store 생성 */
const useOcuRiskMachineFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuRiskMachineFormStore;
