import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import ApiService from '@/services/ApiService';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import { createListSlice } from '@/stores/slice/listSlice';
import * as yup from 'yup';
import { create } from 'zustand';
import ModalService from '@/services/ModalService';

/* yup validation */
const yupFormSchema = yup.object({
  menuId: yup.string().required(),
  workScope: yup.string().required(),
  nameKor: yup.string().required(),
  nameEng: yup.string().required(),
  nameChn: yup.string(),
  nameJpn: yup.string(),
  nameEtc: yup.string(),
  treeType: yup.string().required(),
  upperMenuId: yup.string(),
  sortOrder: yup.number().required(),
  menuUrl: yup.string(),
  useYn: yup.string().required(),
  remark: yup.string(),
  userNm: yup.string().required(),
});

const initFormValue = {
  menuId: '',
  workScope: '',
  nameKor: '',
  nameEng: '',
  nameChn: '',
  nameJpn: '',
  nameEtc: '',
  treeType: '',
  upperMenuId: '',
  sortOrder: 999, // number
  menuUrl: '',
  useYn: 'Y', // select
  remark: '',
  userNm: '',
  deptCd: '',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 부문
  userNm: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  menuTreeData: [],
  parentMenuTreeData: [],
  selectedMenuInfo: null,

  formApiPath: 'ocu/general/organization',
  baseRoutePath: '/occupation/general/organization',
  formName: 'useOcuOrganizationFormStore',

  formValue: initFormValue,
};

/* zustand store 생성 */
const useOcuOrganizationFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  selectedUserInfo: {},

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  searchParam: {
    // 부문
    userNm: '',
  },

  // 초기 화면 진입
  init: async () => {
    const { getMenuTree, getParentMenuTree, changeInput } = get();
    // 조직도 조회
    const treeData = await getMenuTree();
    if (treeData) {
      changeInput('deptCd', treeData[0].deptCd);
    }
    // 임직원 리스트 조회
    await getParentMenuTree();
  },

  // 조직도 조회
  getMenuTree: async () => {
    const { treeWorkScope } = get();
    const apiParam = {
      workScope: treeWorkScope,
    };

    const response = await ApiService.get('ocu/general/organization', apiParam);
    const treeData = response.data || [];

    set({ menuTreeData: treeData });
    return treeData;
  },

  // 임직원 리스트 조회
  getParentMenuTree: async () => {
    const { formValue, searchParam } = get();

    const apiParam = {
      deptCd: formValue.deptCd,
      nameKor: searchParam.userNm,
    };

    // 임직원 리스트, 직책 리스트  조회
    const response = await ApiService.post('ocu/general/selectDeptUserList', apiParam);

    // 부서별 사용자 정보 리스트
    const userList = response.data.userList;
    // 부서별 사용자 직책 리스트
    const dutyList = response.data.dutyList;
    let selectedUserInfo = {};

    console.log('userList===>', userList);
    // 사용자 첫번째행
    if (userList && userList.length) {
      selectedUserInfo = userList[0];
    }

    console.log('selectedUserInfo==>', selectedUserInfo);

    set({ userList, dutyList, selectedUserInfo });
  },

  changeSearchInput: (inputName, inputValue) => {
    const { searchParam } = get();
    searchParam[inputName] = inputValue;
    set({ setUserNm: searchParam });
  },

  handleTreeSelect: async (selectedKeys, info) => {
    const { getParentMenuTree } = get();
    const menuInfo = info.node;
    set({ formValue: menuInfo, formType: FORM_TYPE_UPDATE, errors: {}, selectedMenuInfo: menuInfo });
    await getParentMenuTree();
  },

  changeTreeWorkScope: async (workScope) => {
    const { formType, getMenuTree, changeWorkScope } = get();
    set({ treeWorkScope: workScope, selectedMenuInfo: null });
    await getMenuTree();
    if (formType === FORM_TYPE_ADD) {
      changeWorkScope(workScope);
    }
  },

  changeWorkScope: (workScope) => {
    const { changeInput, getParentMenuTree } = get();
    changeInput('workScope', workScope);
    changeInput('upperMenuId', '');
    getParentMenuTree();
  },

  clear: () => {
    set({ initFormData, searchParam: { ...initSearchParam } });
  },
}));

export default useOcuOrganizationFormStore;
