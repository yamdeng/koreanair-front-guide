import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import ApiService from '@/services/ApiService';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import history from '@/utils/history';
import * as yup from 'yup';
import { create } from 'zustand';
import { log } from 'console';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/general/lawRegStd',
  baseRoutePath: '/occupation/general/lawRegStd',
};

const initSearchParam = {
  // 법규명
  lawNm: '',
  // 주관부서
  subjectDeptCd: '',
};

/* yup validation */
const yupFormSchema = yup.object({
  // lawId: yup.string().required(),
  lawSeq: yup.string().required(),
  lawNm: yup.string().required(),
  subjectDeptCd: yup.string().required(),
});

const initFormValue = {
  lawId: '',
  lawSeq: '',
  lawNm: '',
  subjectDeptCd: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/general/lawRegStd',
  baseRoutePath: '/occupation/general/lawRegStd',
  formName: 'useOcuLawRegStdFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuLawRegStdFormStore = create<any>((set, get) => ({
  ...createListSlice(set, get),
  ...createFormSliceYup(set, get),

  ...initListData,

  searchDeptInfo: null,

  advCmitDeptInfo: null,

  ...initFormData,

  formName: 'LawRegStdFormModal',

  yupFormSchema: yupFormSchema,

  searchParam: {
    // 법규명
    lawNm: '',
    // 주관부서
    subjectDeptCd: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  changeAdvCmitDeptInfo: (deptInfo) => {
    set({ advCmitDeptInfo: deptInfo });
  },

  changeSearchDeptInfo: (deptInfo) => {
    set({ searchDeptInfo: deptInfo });
  },

  deleteRegStd: () => {
    const { formDetailId, formApiPath, baseRoutePath, formValue, search } = get();

    ModalService.confirm({
      body: '삭제하시겠습니까?',
      ok: async () => {
        await ApiService.delete(`${formApiPath}/${formValue.lawId}`);
        ModalService.alert({
          body: '삭제되었습니다.',

          ok: () => {
            set({ isCodeFormModalOpen: false });
            set({ formValue: { ...initFormValue } });
            search();
          },
        });
      },
    });
  },

  // 초기화
  removeAll: () => {
    set({ list2: [] });
  },

  /**  신규, 상세 팝업 **/
  openFormModal: (gubun, formValue) => {
    const { changeAdvCmitDeptInfo } = get();
    // 부서 초기화
    changeAdvCmitDeptInfo({
      deptCd: '',
      nameKor: '',
    });

    if (formValue) {
      changeAdvCmitDeptInfo({
        deptCd: formValue.subjectDeptCd,
        // nm 수정
        nameKor: formValue.subjectDeptCd,
      });
    }
    // 입력
    if (gubun == 'I') {
      set({ isCodeFormModalOpen: true, gubun: gubun });
      // 수정
    } else if (gubun == 'U') {
      set({ isCodeFormModalOpen: true, gubun: gubun, formValue: formValue });
      // 법령 선택
    } else {
      set({ isCodeFormModalOpen: true, gubun: gubun, formValue: formValue });
    }
  },

  closeFormModal: () => {
    set({ isCodeFormModalOpen: false });
    set({ formValue: { ...initFormValue } });
  },

  okModal: async (formValue) => {
    const { search } = get();
    const formApiPath = 'ocu/general/lawRegStd';
    ModalService.confirm({
      body: '저장하시겠습니까?',
      ok: async () => {
        await ApiService['post'](formApiPath, formValue, { disableLoadingBar: true });
        set({ isCodeFormModalOpen: false, formValue: { ...initFormValue }, advCmitDeptInfo: null });
        ToastService.success('저장되었습니다.');
        //await getDetail(formDetailId);
        search();
      },
    });
  },

  /**  법 OPEN API 팝업 **/
  openApiFormModal: () => {
    set({ isLawOpenApiModalOpen: true });
  },

  isLawOpenApiCloseModal: () => {
    set({ isLawOpenApiModalOpen: false });
  },

  okLawOpenApiokModal: async (okInfo) => {
    const { formValue } = get();
    const updateFormValue = { ...formValue, ...okInfo };
    set({ formValue: updateFormValue, isLawOpenApiModalOpen: false });
    // const { search } = get();
    // const formApiPath = 'ocu/general/lawRegStd';
    // ModalService.confirm({
    //   body: '저장하시겠습니까?',
    //   ok: async () => {
    //     await ApiService['post'](formApiPath, formValue, { disableLoadingBar: true });
    //     set({ isLawOpenApiModalOpen: false, formValue: { ...initFormValue }, advCmitDeptInfo: null });
    //     ToastService.success('저장되었습니다.');
    //     //await getDetail(formDetailId);
    //     search();
    //   },
    // });
  },

  lawOpenApiSearch: async () => {
    const { setList } = get();
    const { list } = get();
    const { searchParam } = get();

    //  법규명
    const apiParam = {
      lawNm: searchParam.popLawNm,
    };

    const apiResult = await ApiService.post(`ocu/general/selectLawOpenApi`, apiParam);
    const data = apiResult.data;

    set({ list2: data });
  },

  popupInit: () => {
    set({ list2: '' });
  },

  clear: () => {
    set({ ...formBaseState, ...listBaseState, formValue: { ...initFormValue }, searchParam: { ...initSearchParam } });
  },
}));

// modal store
// export const useOcuLawOpenApiModalStore = create<any>((set, get) => ({

//   ...createListSlice(set, get),
//   ...createFormSliceYup(set, get),

//   ...initListData,

//   searchDeptInfo: null,

//   advCmitDeptInfo: null,

//   ...initFormData,

//   formName: 'LawRegStdFormModal',

//   yupFormSchema: yupFormSchema,

//   searchParam: {
//     // 법규명
//     lawNm: '',
//     // 주관부서
//     subjectDeptCd: '',
//   },

//   initSearchInput: () => {
//     set({
//       searchParam: {
//         ...initSearchParam,
//       },
//     });
//   },
// }));

export default useOcuLawRegStdFormStore;
