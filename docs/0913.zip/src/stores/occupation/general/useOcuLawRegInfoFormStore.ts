import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import history from '@/utils/history';
import ApiService from '@/services/ApiService';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  // 법규명
  lawNm: yup.string().required(),
  // 법령일련번호
  lawSeq: yup.string().required(),
  // 법령종류
  lawKind: yup.string().required(),
  // 공포일자
  fearDt: yup.string().required(),
  // 시행일자
  implDt: yup.string().required(),
  // 제개정 종류
  lgsltKind: yup.string().required(),
  // 소관부처
  respMinistryNm: yup.string().required(),
  // 법령상세링크
  lawDtlLink: yup.string().required(),
  // 주관부서
  subjectDeptCd: yup.string().required(),
  // 개정 내용
  revisionCn: yup.string().required(),
  // 영향도 평가
  inflDegreeEval: yup.string().required(),
  // Keyword
  keyWordContent: yup.string(),
  // 평가자
  //evalId: yup.string(),
  // 승인자
  // aprvId: yup.string(),
  // 해당부서
  //rlvtDeptCd: yup.string(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  // 법규명
  lawNm: '',
  // 법령일련번호
  lawSeq: '',
  // 법령종류
  lawKind: '',
  // 공포일자
  fearDt: '',
  // 시행일자
  implDt: '',
  // 제개정 종류
  lgsltKind: '',
  // 소관부처
  respMinistryNm: '',
  // 법령상세링크
  lawDtlLink: '',
  // 주관부서
  subjectDeptCd: '',
  // 개정 내용
  revisionCn: '',
  // 영향도 평가
  inflDegreeEval: '',
  // Keyword
  keyWordContent: '',
  // 평가자
  evalId: '',
  // 승인자
  aprvId: '',
  // 해당부서
  rlvtDeptCd: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/general/lawRegInfo',
  baseRoutePath: '/occupation/general/lawRegInfo',
  formName: 'useOcuLawRegInfoFormStore',
  formValue: {
    ...initFormValue,
  },
};

// okModal: async (formValue) => {
//   const { search } = get();
//   const formApiPath = 'ocu/general/lawRegStd';
//   ModalService.confirm({
//     body: '저장하시겠습니까?',
//     ok: async () => {
//       await ApiService['post'](formApiPath, formValue, { disableLoadingBar: true });
//       set({ isCodeFormModalOpen: false, formValue: { ...initFormValue }, advCmitDeptInfo: null });
//       ToastService.success('저장되었습니다.');
//       //await getDetail(formDetailId);
//       search();
//     },
//   });
// },

/* zustand store 생성 */
const useOcuLawRegInfoFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },

  approval: () => {
    const { formValue, baseRoutePath } = get();
    const formApiPath = 'ocu/general/ApprovalLawRegInfo';

    ModalService.confirm({
      body: '승인하시겠습니까?',
      ok: async () => {
        await ApiService.put(`${formApiPath}/${formValue.lawSeq}`);
        ModalService.alert({
          body: '승인되었습니다.',
          ok: () => {
            history.push(`${baseRoutePath}`);
          },
        });
      },
    });

    // const formApiPath = 'ocu/general/lawRegStd';
    // ModalService.confirm({
    //   body: '저장하시겠습니까?',
    //   ok: async () => {
    //     await ApiService['post'](formApiPath, formValue, { disableLoadingBar: true });
    //     set({ isCodeFormModalOpen: false, formValue: { ...initFormValue }, advCmitDeptInfo: null });
    //     ToastService.success('저장되었습니다.');
    //     //await getDetail(formDetailId);
    //     search();
    //   },
    // });
  },
}));

export default useOcuLawRegInfoFormStore;
