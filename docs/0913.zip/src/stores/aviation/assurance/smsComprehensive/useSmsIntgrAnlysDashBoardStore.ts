import ApiService from '@/services/ApiService';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import dayjs from 'dayjs';
import { create } from 'zustand';

const now = dayjs();

const initSearchParam = {
  division: [],
  reportType: [],
  fromDate: '',
  toDate: '',
};

// 해저드 탭 그리드 1번째
export const hzdTabGrd1Store = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'avn/assurance/sms-analysis/hzdTab',
  grd: 'grd1',
  hazardName: '',

  selectSummaryRowInfo: (rowInfo) => {
    const col01 = rowInfo.col01;
    get().changeStateProps('hazardName', col01);
    hzdTabGrd2Store.getState().changeSummaryRowInfo(col01);
    hzdTabGrd3Store.getState().changeSummaryRowInfo(col01);
  },

  getSearchParam: () => {
    const { grd, hazardName, getPageParam } = get();
    const baseSearchParam = useHzrTopRiskListStore.getState().getSearchParam();
    const apiParam = { ...baseSearchParam, ...getPageParam() };
    apiParam.grd = grd;
    apiParam.hazardName = hazardName;
    return apiParam;
  },
}));

// 해저드 탭 그리드 2번째
export const hzdTabGrd2Store = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'avn/assurance/sms-analysis/hzdTab',
  grd: 'grd2',
  hazardName: '',

  changeSummaryRowInfo: (value) => {
    const { enterSearch } = get();
    set({ hazardName: value });
    enterSearch();
  },

  getSearchParam: () => {
    const { grd, hazardName, getPageParam } = get();
    const baseSearchParam = useHzrTopRiskListStore.getState().getSearchParam();
    const apiParam = { ...baseSearchParam, ...getPageParam() };
    apiParam.grd = grd;
    apiParam.hazardName = hazardName;
    return apiParam;
  },
}));

// 해저드 탭 그리드 3번째
export const hzdTabGrd3Store = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'avn/assurance/sms-analysis/hzdTab',
  grd: 'grd3',
  hazardName: '',

  changeSummaryRowInfo: (value) => {
    const { enterSearch } = get();
    set({ hazardName: value });
    enterSearch();
  },

  getSearchParam: () => {
    const { grd, hazardName, getPageParam } = get();
    const baseSearchParam = useHzrTopRiskListStore.getState().getSearchParam();
    const apiParam = { ...baseSearchParam, ...getPageParam() };
    apiParam.grd = grd;
    apiParam.hazardName = hazardName;
    return apiParam;
  },
}));

// 이벤트 탭 차트 1번째
export const eventTabChart1Store = create<any>((set, get) => ({
  listApiPath: 'avn/assurance/sms-analysis/eventTab',
  grd: 'chart1',
  eventName: '',
  pageSize: 100,
  pageNum: 0,

  changeSummaryRowInfo: (value) => {
    const { searchAfterChartMaker } = get();
    set({ eventName: value });
    searchAfterChartMaker();
  },

  searchAfterChartMaker: async () => {
    const { listApiPath, grd, eventName, pageSize, pageNum } = get();
    const apiParam = { grd: grd, eventName: eventName, pageSize: pageSize, pageNum: pageNum };
    const apiResult = await ApiService.get(listApiPath, apiParam);

    const chartList = apiResult.data.list;
    const strInnerHtml = '<canvas  width="700" height="400" id="chart_1"></canvas>';
    const chartElement = document.getElementById('chartMaker');
    chartElement.replaceChildren();
    chartElement.innerHTML = strInnerHtml;

    const canvas = document.getElementById('chart_1');
    const cvs = canvas.id;
    const data = {
      colData: [],
      valData: [],
    };
    chartList.map((chartData, targetIndex) => {
      data.colData.push(chartData.col01);
      data.valData.push(chartData.col02);
    });

    DxChart.reset(cvs);

    const pie = new DxChartPie({
      id: cvs,
      elem: canvas,
      labels: data.colData,
      data: data.valData,
      options: {
        radius: 125,
        margin: {
          Left: 0,
          Right: 0,
          Top: 165,
          Inner: 25,
          Bottom: 82,
        },
        variant: { Value: 'donut' },
        line: { Width: 5 },
        exploded: 5,
        colorsStroke: 'rgba(0,0,0,0)',
        shadow: { Use: true },
        labels: {
          Data: data.valData,
          List: false,
          Sticks: true,
          SticksLength: 40,
          SticksLineWidth: 1,
          StickStyle: 'line',
          SticksColors: ['#333333'],
        },
        key: {
          Data: data.colData,
          //PositionX : 750,
          Shadow: true,
          shadowStyle: '2px 2px 3px #aaaaaa',
          Position: 'margin',
          PositionGraphBoxed: false,
          PositionY: canvas.offsetHeight - 20 - 12,
        },
      },
    });
    pie.draw();
  },

  getSearchParam: () => {
    const { grd, eventName, getPageParam } = get();
    const baseSearchParam = useTopEventListStore.getState().getSearchParam();
    const apiParam = { ...baseSearchParam, ...getPageParam() };
    apiParam.grd = grd;
    apiParam.eventName = eventName;
    apiParam.pageSize = 100;
    return apiParam;
  },
}));

// 이벤트 탭 그리드 1번째
export const eventTabGrd1Store = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'avn/assurance/sms-analysis/eventTab',
  grd: 'grd1',
  eventName: '',

  selectSummaryRowInfo: (rowInfo) => {
    const col01 = rowInfo.col01;
    get().changeStateProps('eventName', col01);
    eventTabGrd2Store.getState().changeSummaryRowInfo(col01);
    eventTabGrd3Store.getState().changeSummaryRowInfo(col01);
    eventTabGrd4Store.getState().changeSummaryRowInfo(col01);
    eventTabChart1Store.getState().changeSummaryRowInfo(col01);
  },

  getSearchParam: () => {
    const { grd, eventName, getPageParam } = get();
    const baseSearchParam = useTopEventListStore.getState().getSearchParam();
    const apiParam = { ...baseSearchParam, ...getPageParam() };
    apiParam.grd = grd;
    apiParam.eventName = eventName;
    return apiParam;
  },
}));

// 이벤트 탭 그리드 2번째
export const eventTabGrd2Store = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'avn/assurance/sms-analysis/eventTab',
  grd: 'grd2',
  eventName: '',

  changeSummaryRowInfo: (value) => {
    const { enterSearch } = get();
    set({ eventName: value });
    enterSearch();
  },

  getSearchParam: () => {
    const { grd, eventName, getPageParam } = get();
    const baseSearchParam = useTopEventListStore.getState().getSearchParam();
    const apiParam = { ...baseSearchParam, ...getPageParam() };
    apiParam.grd = grd;
    apiParam.eventName = eventName;
    return apiParam;
  },
}));

// 이벤트 탭 그리드 3번째
export const eventTabGrd3Store = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'avn/assurance/sms-analysis/eventTab',
  grd: 'grd3',
  eventName: '',

  changeSummaryRowInfo: (value) => {
    const { enterSearch } = get();
    set({ eventName: value });
    enterSearch();
  },

  getSearchParam: () => {
    const { grd, eventName, getPageParam } = get();
    const baseSearchParam = useTopEventListStore.getState().getSearchParam();
    const apiParam = { ...baseSearchParam, ...getPageParam() };
    apiParam.grd = grd;
    apiParam.eventName = eventName;
    return apiParam;
  },
}));

// 이벤트 탭 그리드 4번째
export const eventTabGrd4Store = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'avn/assurance/sms-analysis/eventTab',
  grd: 'grd4',
  eventName: '',

  changeSummaryRowInfo: (value) => {
    const { enterSearch } = get();
    set({ eventName: value });
    enterSearch();
  },

  getSearchParam: () => {
    const { grd, eventName, getPageParam } = get();
    const baseSearchParam = useTopEventListStore.getState().getSearchParam();
    const apiParam = { ...baseSearchParam, ...getPageParam() };
    apiParam.grd = grd;
    apiParam.eventName = eventName;
    return apiParam;
  },
}));
///////////////////////////////////////////////////////////////

// 최상위 store : tab manage
export const useSmsIntgrAnlysDashBoardStore = create<any>((set, get) => ({
  tabIndex: '',
  changeTab: (tabIndex) => {
    set({ tabIndex: tabIndex });
    if (tabIndex === 0) {
      useHzrTopRiskListStore.getState().search();
    } else {
      useTopEventListStore.getState().search();
    }
  },
  searchParam: {
    isPSMSReportModal: false,
    gubun: '',
    code: '',
  },

  changeSearchInput: (inputName, inputValue) => {
    const { searchParam } = get();
    searchParam[inputName] = inputValue;
    set({ searchParam: searchParam });
  },

  openReport: (gubun, rowInfo) => {
    get().changeSearchInput('isPSMSReportModal', true);
    get().changeSearchInput('gubun', gubun);
    get().changeSearchInput('code', rowInfo.col01);
  },

  clear: () => {
    useHzrTopRiskListStore.getState().clear();
    useTopEventListStore.getState().clear();
  },
}));

// HzrTopRiskList 첫번째 탭 store
export const useHzrTopRiskListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    gubun: 'hazard',
    division: [],
    reportType: [],
    fromDate: dayjs().year() + '-01-01',
    toDate: dayjs().format('YYYY-MM-DD'),
  },

  getSearchParam: () => {
    const { searchParam } = get();
    const { gubun, division, reportType, fromDate, toDate } = searchParam;
    return {
      gubun: gubun,
      division: division.join(','),
      reportType: reportType.join(','),
      fromDate: fromDate.replaceAll('-', ''),
      toDate: toDate.replaceAll('-', ''),
    };
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  selectSingle: () => {},

  search: () => {
    hzdTabGrd1Store.getState().search();
    hzdTabGrd2Store.getState().search();
    hzdTabGrd3Store.getState().search();
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

// TopEventList 두번째 탭 store
export const useTopEventListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    gubun: 'event',
    division: [],
    fromDate: dayjs().year() + '-01-01',
    toDate: dayjs().format('YYYY-MM-DD'),
  },

  getSearchParam: () => {
    const { searchParam } = get();
    const { gubun, division, fromDate, toDate } = searchParam;
    return {
      gubun: gubun,
      division: division.join(','),
      fromDate: fromDate.replaceAll('-', ''),
      toDate: toDate.replaceAll('-', ''),
    };
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  search: async () => {
    eventTabChart1Store.getState().searchAfterChartMaker();
    eventTabGrd1Store.getState().search();
    eventTabGrd2Store.getState().search();
    eventTabGrd3Store.getState().search();
    eventTabGrd4Store.getState().search();
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));
