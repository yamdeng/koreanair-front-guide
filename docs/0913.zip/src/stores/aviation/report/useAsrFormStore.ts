import { create } from 'zustand';
import { produce } from 'immer';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';

/*

  todo : reportEditFormSlice

   1.비행편 검색
    -searchFligh
    -공통 yup 포팅



*/

/* yup validation */
const yupFormSchema = yup.object().shape({
  flight: yup.object().shape({
    departureDt: yup.string().required(),
    flightNo: yup.string().required(),
    regNo: yup.string().required(),
    aircraftTypeCd: yup.string().required(),
    departureAirportCd: yup.string().required(),
    arrivalAirportCd: yup.string().required(),
    divertAirportCd: yup.string(),
    stdTime: yup.string(),
    staTime: yup.string(),
    atdTime: yup.string(),
    ataTime: yup.string(),
    delayedMinCo: yup.number().nullable(),
    supplyNm: yup.string(),
    checkinNm: yup.string(),
  }),
  flightCrew: yup.array(),
  event: yup.object().shape({
    occurPlaceNm: yup.string(),
    occurAirportCd: yup.string(),
    runwayNm: yup.string(),
    occurDttm: yup.string(),
    occurTimezoneCd: yup.string(),
    flightPhaseCd: yup.string(),
    altitudeUnitCd: yup.string(),
    altitudeCo: yup.number().nullable(),
    speedUnitCd: yup.string(),
    speedCo: yup.number().nullable(),
    subjectNm: yup.string().required(),
    descriptionTxtcn: yup.string().required(),
  }),
  weather: yup.object().shape({
    metCd: yup.string(),
    windOneCo: yup.number().nullable(),
    windTwoCo: yup.number().nullable(),
    gustCo: yup.number().nullable(),
    visibilityNm: yup.string(),
    cloudCd: yup.string(),
    tempCo: yup.number().nullable(),
    altimeterUnitCd: yup.string(),
    altimeterCo: yup.number().nullable(),
  }),
  bird: yup.object().shape({
    birdTypeNm: yup.string(),
    birdSizeCd: yup.string(),
    birdCoCd: yup.string(),
    struckBirdCoCd: yup.string(),
    timeTypeCd: yup.string(),
    landingLightYn: yup.string(),
    pilotWarnedYn: yup.string(),
    impactTimeNm: yup.string(),
    birdDescriptionCn: yup.string(),
  }),
});

const initFormValue = {
  flight: {
    departureDt: CommonUtil.getNowDateString('YYYYMMDD'),
    flightNo: '',
    regNo: '',
    aircraftTypeCd: '',
    departureAirportCd: '',
    arrivalAirportCd: '',
    divertAirportCd: '',
    stdTime: '',
    staTime: '',
    atdTime: '',
    ataTime: '',
    delayedMinCo: null,
    supplyNm: '',
    checkinNm: '',
  },
  flightCrew: [],
  event: {
    occurPlaceNm: '',
    occurAirportCd: '',
    runwayNm: '',
    occurDttm: '',
    occurTimezoneCd: 'utc',
    flightPhaseCd: '',
    altitudeUnitCd: '',
    altitudeCo: null,
    speedUnitCd: '',
    speedCo: null,
    subjectNm: '',
    descriptionTxtcn: '',
    fileGroupSeq: null,
  },
  weather: {
    metCd: '',
    windOneCo: null,
    windTwoCo: null,
    gustCo: null,
    visibilityNm: '',
    cloudCd: '',
    tempCo: null,
    altimeterUnitCd: '',
    altimeterCo: null,
    weatherCodeList: [],
  },
  bird: {
    birdTypeNm: '',
    birdSizeCd: '',
    birdCoCd: '',
    struckBirdCoCd: '',
    timeTypeCd: '',
    landingLightYn: '',
    pilotWarnedYn: '',
    impactTimeNm: '',
    birdDescriptionCn: '',
  },
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'sys/messages',
  baseRoutePath: '/messages',
  formName: 'useAsrFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useAsrFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  filghtExpanded: true,
  eventExpanded: false,
  weatherExpaned: false,
  birdExapned: false,
  userSelectKind: 'PF',

  searchFligh: async () => {
    const { formValue } = get();
    const { flight } = formValue;
    const { flightNo } = flight;
    if (!flightNo) {
      ToastService.warn('비행편명을 입력해주세요.');
      return;
    }

    const apiResult = await ApiService.get('com/flight', { departureDate: '', fltNo: flightNo });
    const data = apiResult.data || [];
    const searchInfo = data.length ? data[0] : null;

    if (searchInfo) {
      set(
        produce((state: any) => {
          const flight = state.formValue.flight;
          flight.regNo = searchInfo.registrationNo;
          flight.aircraftTypeCd = searchInfo.aircraftType;
          flight.departureAirportCd = searchInfo.to;
          flight.arrivalAirportCd = searchInfo.from;
          flight.supplyNm = searchInfo.supply;
          flight.checkinNm = searchInfo.checkIn;
          flight.stdTime = CommonUtil.getTimeStringByDateFullString(searchInfo.std);
          flight.staTime = CommonUtil.getTimeStringByDateFullString(searchInfo.sta);
          flight.atdTime = CommonUtil.getTimeStringByDateFullString(searchInfo.atd);
          flight.ataTime = CommonUtil.getTimeStringByDateFullString(searchInfo.ata);
          flight.stdLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.stdLocTime);
          flight.staLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.staLocTime);
          flight.atdLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.atdLocTime);
          flight.ataLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.ataLocTime);
          flight.delayedMinCo = searchInfo.delay;
        })
      );
    } else {
      ToastService.warn('비행정보가 존재하지 않습니다.');
    }
  },

  // 비행승무원 선택
  onSelectFlightCrewList: (selectedValue) => {
    const { userSelectKind } = get();
    set(
      produce((state: any) => {
        const flightCrewList = state.formValue.flightCrew;
        if (!flightCrewList.find((info) => info.empNo === selectedValue.empNo)) {
          flightCrewList.push({ ...selectedValue, tagName: userSelectKind });
        }
      })
    );
  },

  // 비행승무원 삭제
  deleteFlightCrewList: (removeIndex) => {
    set(
      produce((state: any) => {
        state.formValue.flightCrew.splice(removeIndex, 1);
      })
    );
  },

  getDetail: async (id) => {
    const { formApiPath } = get();
    const response: any = await ApiService.get(`${formApiPath}/${id}`);
    const detailInfo = response.data;
    set({
      detailInfo: detailInfo,
      formValue: detailInfo,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  getReportApiParam: () => {
    const { formValue } = get();
    const { flight, flightCrew, event, weather, bird } = formValue;
    const serverReportParam = {
      reportTypeCd: 'ASR',
      ...event,
    };
    const serverAsrReportParam = {
      ...weather,
      ...bird,
      runwayNm: event.runwayNm,
      flightPhaseCd: event.flightPhaseCd,
      altitudeUnitCd: event.altitudeUnitCd,
      altitudeCo: event.altitudeCo,
      speedUnitCd: event.speedUnitCd,
      speedCo: event.speedCo,
      weatherCdarr: weather.weatherCodeList.join(','),
    };
    const reportApiParam = {
      flight: { ...flight },
      flightCrew: flightCrew.map((info) => {
        const flightServerInfo = {
          crewTypeCd: info.tagName,
          empNo: info.empNo,
        };
        return flightServerInfo;
      }),
      report: serverReportParam,
      reportAsr: serverAsrReportParam,
    };
    return reportApiParam;
  },

  // 임시저장
  tempSave: async () => {
    const { getReportApiParam, formType, formDetailId } = get();
    const apiParam = getReportApiParam();
    if (formType === FORM_TYPE_ADD) {
      await ApiService.post(`avn/report/reportInsert`, apiParam);
    } else {
      await ApiService.put(`report/reportUpdate/${formDetailId}`, apiParam);
    }
    await set({ isDirty: false });
    if (formType === FORM_TYPE_ADD) {
      // TODO : 등록일 경우 navigation 이동시키기 : reportId 기준으로
      // 등록시 받은 reportId 기준으로 정보를 다시 셋팅하기
    }
    ToastService.success('저장되었습니다.');
  },

  save: async () => {
    const { validate, getApiParam, formType, formDetailId, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          if (formType === FORM_TYPE_ADD) {
            await ApiService.post(`${formApiPath}`, apiParam);
          } else {
            await ApiService.put(`${formApiPath}/${formDetailId}`, apiParam);
          }
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    }
  },

  toggleAccordionExpanded: (accordionExapndedName) => {
    const state = get();
    const expaned = !state[accordionExapndedName];
    set({ [accordionExapndedName]: expaned });
  },

  clear: () => {
    set(initFormData);
  },
}));

export default useAsrFormStore;
