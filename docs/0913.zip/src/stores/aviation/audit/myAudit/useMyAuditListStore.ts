import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/audit/my-audit/0/list/audit-list',
  baseRoutePath: '/audit/myAudit',
  // listApiPath: 'avn/admin/board/safety-policis',
  // baseRoutePath: '/aviation/board-manage/safety-policy',
};

/* zustand store 생성 */
const useMyAuditListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    searchWord: '',
  },

  divAuditYear: new Date().getFullYear() + '',

  myAuditYaer: new Date().getFullYear() + '',

  changeDivAuditYear: (value) => {
    // TODO : api로 데이터 가져오기
    set({ divAuditYear: value });
  },

  changeMyAuditYear: (value) => {
    // TODO : api로 데이터 가져오기
    set({ myAuditYaer: value });
  },

  clickStatusNumber: (gubun) => {
    const { divAuditYear, myAuditYaer } = get();
    // statusNumberInfo 자체가 apiParam이 됨
    // gubun: 'DivAudit'
    // statusNumberInfo.gubun = 'DivAudit'
    const { enterSearch, currentPage, pageSize } = get();
    const apiParam: any = { pageNum: currentPage, pageSize: pageSize };
    if (gubun === '1') {
      apiParam.divYear = divAuditYear;
    } else if (gubun === '2') {
      apiParam.myYearYear = myAuditYaer;
    }
    enterSearch(apiParam);
  },

  enterSearch: (manualSearchParam) => {
    set({ currentPage: 1 });
    get().search(manualSearchParam);
  },

  search: async (manualSearchParam) => {
    const { listApiPath, getSearchParam, setTotalCount, listApiMethod, disablePaging } = get();
    const applyListApiMethod = listApiMethod || 'get';
    const apiParam = getSearchParam();
    let applyApiParam = apiParam;
    if (manualSearchParam) {
      applyApiParam = manualSearchParam;
    }
    const apiResult: any = await ApiService[applyListApiMethod](listApiPath, applyApiParam, {
      disableLoadingBar: true,
    });
    const data = apiResult.data;
    const list = disablePaging ? data : data.list;
    const totalCount = disablePaging && list ? list.length : data.total;
    setTotalCount(totalCount);
    set({ list: list || [] });
  },

  init: async () => {
    const { enterSearch, getMyAuditStatistics } = get();
    getMyAuditStatistics();
    enterSearch();
  },

  //초기화 버튼 클릭 시 검색 조건 초기화
  initSearchInput: () => {
    set({
      searchParam: {
        searchWord: '',
      },
    });
  },

  //-----------------------------------------------------------------------------------------------
  /* MyAuditList */
  //-----------------------------------------------------------------------------------------------
  dsStatistics: {},

  getMyAuditStatistics: async () => {
    const { divAuditYear, myAuditYaer } = get();
    const apiParam = { divYear: divAuditYear, myYear: myAuditYaer };
    const apiResult = await ApiService.get(`avn/audit/my-audit/0/list/audit-statistics`, apiParam);
    const data = apiResult.data || {};
    set({ dsStatistics: data });
  },

  // MyAuditList 화면 초기화
  clearList: () => {
    set({ isCheckListFormModal: false, dsMyAuditStatistics: [] });
  },
}));

export default useMyAuditListStore;
