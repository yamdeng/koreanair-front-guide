import ApiService from '@/services/ApiService';
import ToastService from '@/services/ToastService';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { create } from 'zustand';
import { produce } from 'immer';
import CommonUtil from '@/utils/CommonUtil';

/* yup validation */
const yupFormSchema = yup.object({
  reportTitle: yup.string().required('subject는 필수 입력 항목입니다.'),
  occurrenceInformation: yup.object().shape({
    eventAt: yup.string(), //발생일
    eventAtTz: yup.string(), //발생일 TimeZone
    classification: yup.string(), //Event Class
    eventId: yup.string(), //Event Type
    airport: yup.string(), //발생 공항
    flightPhase: yup.string(), //발생 단계
    weatherText: yup.string(), //기상조건
    isSpi: yup.string(), //SPI여부
    spiFileGroupSeq: yup.string(), //SPI첨부파일
    locationText: yup.string(), //발생 장소
    //TODO:참고문서 넣어야함
  }),

  flight: yup.object().shape({
    departureAt: yup.string(), //출발일자
    flightNo: yup.string(), //비행편명
    registrationNo: yup.string(), //등록기호
    aircraftTypeText: yup.string(), //항공기 형식
    fromAirport: yup.string(), //출발항공
    toAirport: yup.string(), //도착공항
    divertAirport: yup.string(), //회항공항
    supply: yup.string(), //좌석수
    checkIn: yup.string(), //탑승자
  }),
  crewMemberList: yup.array(), //승무원
  InvestigationReport: yup.object().shape({
    postContents: yup.string(), //조사보고서 내용
    postFileGroupSeq: yup.string(), //조사보고서 첨부파일
    investigateBy: yup.string(), //조사관
  }),
  hazardList: yup.array(), //위해요인 리스트
  hazardId: yup.string(), //hazard
  hazardType: yup.string(), //원인구분
  consequenceId: yup.string(), //potential Consequence
  assumptionList: yup.array(), //추정원인 목록
  radicalList: yup.array(), //부수요인 목록
  approvedGroupID: yup.string(), //결재 ID
  empNo: yup.string(), //최초 작성자 사원번호
  isSubmitted: yup.string(), //제출여부
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  //보고서 번호
  reportNo: '', //보고서 번호
  reportTitle: '', //리포트 subject
  //보고서 번호 끝
  //발생정보
  occurrenceInformation: {
    eventAt: '', //발생일
    eventAtTz: '', //발생일 TimeZone
    classification: '', //Event Class
    eventId: '', //Event Type
    airport: '', //발생 공항
    flightPhase: '', //발생 단계
    weatherText: '', //기상조건
    isSpi: 'N', //SPI여부
    spiFileGroupSeq: '', //SPI첨부파일
    locationText: '', //발생 장소
    //TODO:참고문서 넣어야함
  },
  //발생정보 끝
  //비행정보
  flight: {
    departureAt: '', //출발일자
    flightNo: '', //비행편명
    registrationNo: '', //등록기호
    aircraftTypeText: '', //항공기 형식
    fromAirport: '', //출발항공
    toAirport: '', //도착공항
    divertAirport: '', //회항공항
    supply: '', //좌석수
    checkIn: '', //탑승자
  },
  crewMemberList: [], //승무원
  //비행정보 끝
  InvestigationReport: {
    postContents: '', //조사보고서 내용
    postFileGroupSeq: '', //조사보고서 첨부파일
    investigateBy: '', //조사관
  },
  //위험평가
  hazardList: [], //위해요인 리스트
  hazardId: '', //hazard
  hazardType: 'ast', //원인구분
  consequenceId: '', //potential Consequence
  assumptionList: [], //추정원인 목록
  radicalList: [], //부수요인 목록
  //위험평가 끝
  approvedGroupID: '', //결재 ID
  empNo: '', //최초 작성자 사원번호
  isSubmitted: 'N', //제출여부
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/srm/investigation/reports',
  baseRoutePath: '/aviation/safety-risk-mgmt/investigation-report',
  formName: 'AvnIvReportForm',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useInvestigationReportFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },

  //비행편명 검색
  searchFligh: async () => {
    const { formValue } = get();
    const { flight } = formValue;
    const { flightNo } = flight;
    if (!flightNo) {
      ToastService.warn('비행편명을 입력해주세요.');
      return;
    }

    const apiResult = await ApiService.get('com/flight', { departureDate: '', fltNo: flightNo });
    const data = apiResult.data || [];
    const searchInfo = data.length ? data[0] : null;

    if (searchInfo) {
      set(
        produce((state: any) => {
          const flight = state.formValue.flight; //비행정보
          flight.registrationNo = searchInfo.registrationNo; //등록기호
          flight.aircraftTypeText = searchInfo.aircraftType; //항공기 형식
          flight.toAirport = searchInfo.to; //도착공항
          flight.fromAirport = searchInfo.from; //출발공항
          flight.divertAirport = searchInfo.from; //회항공항
          flight.supply = searchInfo.supply; //좌석수
          flight.checkIn = searchInfo.checkIn; //탑승자
        })
      );
    } else {
      ToastService.warn('비행정보가 존재하지 않습니다.');
    }
  },

  //asr 이벤트 목록 가져오기
  eventListData: [],
  // hazard 목록 가져오기
  hazardListData: [],
  //consequence 목록 가져오기
  consequenceListData: [],
  //승무원 정보
  crewResult: [],

  // 비행승무원 선택
  onSelectFlightCrewList: (selectedValue) => {
    set(
      produce((state: any) => {
        const crewMemberList = state.formValue.crewMemberList;
        if (!crewMemberList.find((info) => info.empNo === selectedValue.empNo)) {
          crewMemberList.push({ ...selectedValue });
        }
      })
    );
  },

  // 비행승무원 삭제
  deleteFlightCrewList: (removeIndex) => {
    set(
      produce((state: any) => {
        const crewMemberList = state.formValue.crewMemberList;
        crewMemberList.splice(removeIndex, 1);
      })
    );
  },

  //이벤트 타입 가져오기
  getEventTypeList: async () => {
    const eventList = await ApiService.get('avn/srm/investigation/eventTypeASR');

    set({ eventListData: eventList });
  },

  //Hazard 목록 가져오기
  getHazardList: async () => {
    const hazardList = await ApiService.get('avn/srm/investigation/hazard');

    set({ hazardListData: hazardList });
  },

  //Consequence 목록 가져오기
  getConsequenceList: async () => {
    const consequenceList = await ApiService.get('avn/srm/investigation/consequence');

    set({ consequenceListData: consequenceList });
  },

  //조사관 세팅
  getInvestigatior: async (profile) => {
    const { formValue } = get();
    const { InvestigationReport } = formValue;

    InvestigationReport['investigateBy'] = profile.userInfo.empNo;
    //최초 작성자 사원번호 같이 등록
    formValue['empNo'] = profile.userInfo.empNo;
    set({ formValue: formValue });
  },

  //Risk Assessment
  addRiskAssessment: () => {
    const { formValue, hazardListData, consequenceListData } = get();
    //중복체크 플래그
    let addFlag = false;

    if (formValue.hazardId == '') {
      ToastService.error('Hazard를 선택해주세요');
      document.getElementById('InvestigationReportEditHazard').focus();
      return;
    } else if (formValue.consequenceId == '') {
      ToastService.error('Potential Consequence를 선택해주세요');
      document.getElementById('InvestigationReportEditpotentialConsequence').focus();
      return;
    } else if (formValue.hazardType == '') {
      ToastService.error('원인구분을 선택해주세요');
      document.getElementById('InvestigationReportEditpotentialhazardType').focus();
    } else {
      //위험평가 중복체크
      if (formValue.hazardList.length > 0) {
        formValue.hazardList.forEach((el) => {
          if (el.hazardId == formValue.hazardId && el.consequenceId == formValue.consequenceId) {
            addFlag = true;
            if (el.hazardType == 'ast') {
              ToastService.error('추정원인에 이미 등록된 위험평가 입니다.\n확인 후 다시 진행해주세요');
              return;
            } else {
              ToastService.error('부수요인에 이미 등록된 위험평가 입니다.\n확인 후 다시 진행해주세요');
              return;
            }
          }
        });
      }

      //중복된 위험평가가 있을 시 진행하지 않음
      if (addFlag) return;

      //Risk Assessment 만들어주기
      const riskAssessment = {};
      // 값 저장
      riskAssessment['hazardId'] = formValue.hazardId;
      riskAssessment['hazardType'] = formValue.hazardType;
      riskAssessment['consequenceId'] = formValue.consequenceId;
      //hazard 이름 가져오기
      hazardListData.data.some((data) => {
        if (data.lv3Id == formValue.hazardId) {
          riskAssessment['hazardName'] = data.lv3Name;
        }
      });
      //consequence이름가져오기
      consequenceListData.data.some((data) => {
        if (data.consequenceId == formValue.consequenceId) {
          riskAssessment['consequenceName'] = data.consequenceKoNm;
        }
      });
      //추정원인일 경우
      if (formValue.hazardType == 'ast') {
        //formValue에 추정원인 넣기
        const { assumptionList } = formValue;
        const arrayData = [];
        arrayData.push(riskAssessment);
        const updatedCrewResult = [...assumptionList, ...arrayData];
        formValue['assumptionList'] = updatedCrewResult;
        //부수요인일 경우
      } else {
        //formValue에 부수요인 넣기
        const { radicalList } = formValue;
        const arrayData = [];
        arrayData.push(riskAssessment);
        const updatedCrewResult = [...radicalList, ...arrayData];
        formValue['radicalList'] = updatedCrewResult;
      }
      //최종 두개 합본
      formValue['hazardList'] = [...formValue['assumptionList'], ...formValue['radicalList']];
      set({ formValue: formValue });
      console.log(formValue);
    }
  },
}));

export default useInvestigationReportFormStore;
