// #.local navigation
// <Navigation />
//   1.menuId 추출
//   2.title recursive 하게 추출
//   3.진입시 권한 체크도 같이 함

function Navigation() {
  return <div></div>;
}

export default Navigation;
