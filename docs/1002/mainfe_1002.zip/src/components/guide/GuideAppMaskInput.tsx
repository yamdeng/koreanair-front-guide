import AppMaskInput from '@/components/common/AppMaskInput';
import AppNavigation from '@/components/common/AppNavigation';
import Config from '@/config/Config';
import { useState } from 'react';

function GuideAppMaskInput() {
  const [textValue, setTextValue] = useState('');

  const save = () => {
    alert(`textValue: ${textValue}`);
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          AppTextInput, AppSearchInput :{' '}
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideAppMaskInput.tsx`}>
            GuideAppMaskInput
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppMaskInput
                label="masktest"
                value={textValue}
                onChange={(value) => {
                  setTextValue(value);
                }}
                errorMessage="test"
                toolTipMessage="toolTipTest"
              />
            </div>
          </div>
        </div>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
      </div>
    </>
  );
}
export default GuideAppMaskInput;
