import AppNavigation from '../common/AppNavigation';

function GuideFirstLevelMenu() {
  return (
    <>
      <AppNavigation />
      <div>GuideFirstLevelMenu</div>
    </>
  );
}
export default GuideFirstLevelMenu;
