function ReportRSREditForm() {
  return <div>ReportRSREditForm</div>;
}
export default ReportRSREditForm;
