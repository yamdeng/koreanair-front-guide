import AppNavigation from '@/components/common/AppNavigation';
import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import useAsrFormStore from '@/stores/aviation/report/useAsrFormStore';

function ReportMSREditFormAOC() {
  const formStore = useAsrFormStore();

  // TODO : expeand 변수 셋팅
  const {
    filghtExpanded,
    errors,
    changeInput,
    getDetail,
    formValue,
    tempSave,
    save,
    print,
    toggleAccordionExpanded,
    isDirty,
    clear,
  } = formStore;

  const { event, weather, bird } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      clear();
    }
  }, [detailId]);

  useEffect(() => {
    return clear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['CSR']} />

      {/* 하단버튼영역 */}
      <ReportEditBottomButton print={print} tempSave={tempSave} save={save} />
    </>
  );
}

export default ReportMSREditFormAOC;
