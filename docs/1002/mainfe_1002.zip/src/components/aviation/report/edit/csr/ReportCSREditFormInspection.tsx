import AirportSearch from '@/components/aviation/common/AirportSearch';
import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppTextInput from '@/components/common/AppTextInput';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import CodeService from '@/services/CodeService';
import useCsrInspectionFormStore from '@/stores/aviation/report/useCsrInspectionFormStore';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import CsrEventContent from '../../common/CsrEventContent';
import CsrFlightInfo from '../../common/CsrFlightInfo';
import CsrInvolveList from '../../common/CsrInvolveList';

function ReportCSREditFormInspection() {
  const formStore = useCsrInspectionFormStore();

  // TODO : expeand 변수 셋팅
  const {
    filghtExpanded,
    eventExpanded,
    involveExpaned,
    eventContentExpanded,
    errors,
    changeInput,
    changeCheckKindRadio,
    getDetail,
    formValue,
    addLocationList,
    deleteLocationList,
    tempSave,
    save,
    print,
    toggleAccordionExpanded,
    isDirty,
    clear,
  } = formStore;

  const { event, hiddenFindPlaceCd, hiddenFindSeatCd, locationList } = formValue;
  const { occurAirportCd, safetyInspectionTypeCd, checkAuthorityBaseCd, findingCd, inspectorNm, checkAuthorityCd } =
    event;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      clear();
    }
  }, [detailId]);

  useEffect(() => {
    return clear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['CSR']} />

      <div className="info-wrap toggle">
        <dl className={filghtExpanded ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button
              type="button"
              className="btn-tg"
              onClick={(event) => {
                event.stopPropagation();
                toggleAccordionExpanded('filghtExpanded');
              }}
            >
              비행정보
              <span className={filghtExpanded ? 'active' : ''}></span>
              <div className="tag-info-wrap-end">
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      보고서 작성 가이드
                    </a>
                  </div>
                </div>
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      의무보고의 범위
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: filghtExpanded ? '' : 'none' }}>
            <CsrFlightInfo store={formStore} />
          </dd>
        </dl>

        <dl className={eventExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트
              <span className={eventExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid100 ">
                      <div className="form-group wid50">
                        이벤트 카테고리 : <span style={{ textDecoration: 'underline', fontWeight: 'bold' }}>수검</span>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AirportSearch
                          label="발생공항"
                          value={occurAirportCd}
                          onChange={(value) => {
                            changeInput('event.occurAirportCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="Notification-wrap wid50">
                          <p className="notice">Notification</p>
                          <ul>
                            <li>
                              <span className="point">①</span>Safety : Asked about Safety Equipments/Regulations mostly.
                            </li>
                            <li>
                              <span className="point">②</span>Security : Asked about Security Equipments/Regulations
                              mostly.
                            </li>
                            <li>
                              <span className="point">③</span>Alcohol/Drug : About the alcohol/drug test
                            </li>
                            <li>
                              <span className="point">④</span>Others : Excluding the above items.
                            </li>
                          </ul>
                          <p className="info-text01">
                            Do not write a simple boarding of a supervisor without questions/checks for cabin crew
                          </p>
                          <p className="info-text01">
                            Inspection officer boarding is not required for other sectors (operation, maintenance, etc.)
                            other than room inspection purposes
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="점검종류"
                          options={CodeService.getOptions('CODE_GRP_096')}
                          value={safetyInspectionTypeCd}
                          onChange={(value) => changeCheckKindRadio(value)}
                          required
                          errorMessage={errors[`event.safetyInspectionTypeCd`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="점검기관 Base"
                          options={CodeService.getOptions('CODE_GRP_097')}
                          value={checkAuthorityBaseCd}
                          onChange={(value) => changeInput('event.checkAuthorityBaseCd', value)}
                          required
                          errorMessage={errors[`event.checkAuthorityBaseCd`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="객실 지적사항"
                          options={CodeService.getOptions('CODE_GRP_098')}
                          value={findingCd}
                          onChange={(value) => changeInput('event.findingCd', value)}
                          required
                          errorMessage={errors[`event.findingCd`]}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="점검관"
                          value={inspectorNm}
                          onChange={(value) => changeInput('event.inspectorNm', value)}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="점검기관"
                          codeGrpId="CODE_GRP_010"
                          value={checkAuthorityCd}
                          onChange={(value) => {
                            changeInput(`event.checkAuthorityCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.checkAuthorityCd`]}
                        />
                      </div>
                    </div>
                  </div>

                  <div
                    className="form-table"
                    style={{ display: safetyInspectionTypeCd && safetyInspectionTypeCd === '100001202' ? '' : 'none' }}
                  >
                    <div className="form-cell wid50">
                      <div className="form-group wid50">
                        <div className="UserChicebox Flight ">
                          <div className="form-group wid100">
                            <div className="df">
                              <div className="type6">
                                <AppCodeSelect
                                  label="장소"
                                  codeGrpId="CODE_GRP_011"
                                  value={hiddenFindPlaceCd}
                                  onChange={(value) => {
                                    changeInput(`hiddenFindPlaceCd`, value);
                                  }}
                                />
                              </div>
                              <div className="type6">
                                <AppCodeSelect
                                  label="클래스"
                                  codeGrpId="CODE_GRP_012"
                                  value={hiddenFindSeatCd}
                                  onChange={(value) => {
                                    changeInput(`hiddenFindSeatCd`, value);
                                  }}
                                />
                              </div>
                              <div className="type4 Add">
                                <button
                                  type="button"
                                  name="button"
                                  className="btn_add btn_text"
                                  onClick={addLocationList}
                                >
                                  + Add
                                </button>
                              </div>
                            </div>
                            <label htmlFor="file" className="file-label">
                              은닉물 발견 장소 (있었던 경우)
                            </label>
                            <div className="SelectedList Location mt10">
                              <ul>
                                {locationList.map((locationCodeInfo, index) => {
                                  const { hiddenFindPlaceCd, hiddenFindSeatCd } = locationCodeInfo;
                                  return (
                                    <li key={index}>
                                      {CodeService.getCodeLabelByValue('CODE_GRP_011', hiddenFindPlaceCd)} /{' '}
                                      {CodeService.getCodeLabelByValue('CODE_GRP_012', hiddenFindSeatCd)}
                                      <a href={undefined} onClick={() => deleteLocationList(index)}>
                                        <span className="delete">X</span>
                                      </a>
                                    </li>
                                  );
                                })}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>

        {/* 관련자 테이블 */}
        <dl className={involveExpaned ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('involveExpaned');
            }}
          >
            <button type="button" className="btn-tg">
              관련자 세부 정보
              <span className={involveExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: involveExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <CsrInvolveList store={formStore} />
              </div>
            </div>
          </dd>
        </dl>

        {/* 이벤트 내용 */}

        <dl className={eventContentExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventContentExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트 내용
              <span className={eventContentExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventContentExpanded ? '' : 'none' }}>
            <CsrEventContent store={formStore} />
          </dd>
        </dl>
      </div>

      {/* 하단버튼영역 */}
      <ReportEditBottomButton print={print} tempSave={tempSave} save={save} />
    </>
  );
}

export default ReportCSREditFormInspection;
