import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppEditor from '@/components/common/AppEditor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppSelect from '@/components/common/AppSelect';
import AppTextArea from '@/components/common/AppTextArea';
import AppTextInput from '@/components/common/AppTextInput';
import Code from '@/config/Code';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import CodeService from '@/services/CodeService';
import useAsrFormStore from '@/stores/aviation/report/useAsrFormStore';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import AirportSearch from '../../common/AirportSearch';
import AsrFlightInfo from '../common/AsrFlightInfo';

function ReportASREditForm() {
  const formStore = useAsrFormStore();
  const {
    filghtExpanded,
    eventExpanded,
    weatherExpaned,
    birdExapned,
    errors,
    changeInput,
    getDetail,
    formValue,
    tempSave,
    save,
    print,
    toggleAccordionExpanded,
    isDirty,
    clear,
  } = formStore;

  const { event, weather, bird } = formValue;

  const { detailId } = useParams();

  const {
    occurPlaceNm,
    occurAirportCd,
    runwayNm,
    occurDttm,
    flightPhaseCd,
    altitudeUnitCd,
    altitudeCo,
    speedUnitCd,
    speedCo,
    subjectNm,
    descriptionTxtcn,
    fileGroupSeq,
  } = event;

  const {
    metCd,
    windOneCo,
    windTwoCo,
    gustCo,
    visibilityNm,
    cloudCd,
    tempCo,
    weatherCodeList,
    altimeterUnitCd,
    altimeterCo,
  } = weather;

  const {
    birdTypeNm,
    birdSizeCd,
    birdCoCd,
    struckBirdCoCd,
    timeTypeCd,
    landingLightYn,
    pilotWarnedYn,
    impactTimeNm,
    birdDescriptionCn,
  } = bird;

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      clear();
    }
  }, [detailId]);

  useEffect(() => {
    return clear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['ASR']} />

      <div className="info-wrap toggle">
        <dl className={filghtExpanded ? 'tg-item active' : 'tg-item'}>
          {/* 비행정보 */}
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button
              type="button"
              className="btn-tg"
              onClick={(event) => {
                event.stopPropagation();
                toggleAccordionExpanded('filghtExpanded');
              }}
            >
              비행정보
              <span className={filghtExpanded ? 'active' : ''}></span>
              <div className="tag-info-wrap-end">
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      작성 예시
                    </a>
                  </div>
                </div>
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      의무보고의 범위
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: filghtExpanded ? '' : 'none' }}>
            <AsrFlightInfo store={formStore} />
          </dd>
        </dl>
        {/* 이벤트 */}
        <dl className={eventExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트
              <span className={eventExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid50">
                        {/*발생위치 */}
                        <AppTextInput
                          label="발생위치"
                          toolTipMessage="자유형식으로 입력가능
                          예)Waypoint, 이륙 후3시간 경과 시점 등"
                          value={occurPlaceNm}
                          onChange={(value) => {
                            changeInput('event.occurPlaceNm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*발생공항 */}
                        <AirportSearch
                          label="발생공항"
                          value={occurAirportCd}
                          onChange={(value) => {
                            changeInput('event.occurAirportCd', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*통로 */}
                        <AppTextInput
                          label="통로"
                          value={runwayNm}
                          onChange={(value) => {
                            changeInput('event.runwayNm', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="df">
                          <div className="type3">
                            <AppDatePicker
                              label="발생시간"
                              excludeSecondsTime
                              showTime
                              value={occurDttm}
                              onChange={(value) => {
                                changeInput('event.occurDttm', value);
                              }}
                            />
                          </div>
                          <div className="type4">
                            <AppSelect disabled value="UTC" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid50">
                        {/*비행단계 */}
                        <AppCodeSelect
                          label="비행단계"
                          codeGrpId="CODE_GRP_002"
                          value={flightPhaseCd}
                          onChange={(value) => {
                            changeInput('event.flightPhaseCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <div className="df">
                              <div className="type1">
                                <AppTextInput
                                  inputType={'number'}
                                  value={altitudeCo}
                                  onChange={(value) => {
                                    changeInput('event.altitudeCo', value);
                                  }}
                                />
                                <label className="file-label">Altitude</label>
                              </div>
                              <div className="type2">
                                {/*Altitude 선택 */}
                                <AppCodeSelect
                                  codeGrpId="CODE_GRP_004"
                                  value={altitudeUnitCd}
                                  onChange={(value) => {
                                    changeInput('event.altitudeUnitCd', value);
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <div className="df">
                              <div className="type1">
                                <AppTextInput
                                  inputType={'number'}
                                  value={speedCo}
                                  onChange={(value) => {
                                    changeInput('event.speedCo', value);
                                  }}
                                />
                                <label className="file-label">Speed</label>
                              </div>
                              <div className="type2">
                                {/*Speed 선택 */}
                                <AppCodeSelect
                                  codeGrpId="CODE_GRP_003"
                                  value={speedUnitCd}
                                  onChange={(value) => {
                                    changeInput('event.speedUnitCd', value);
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="제목"
                          value={subjectNm}
                          onChange={(value) => {
                            changeInput('event.subjectNm', value);
                          }}
                          required
                          errorMessage={errors['event.subjectNm']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <AppEditor
                        label="AppEditor"
                        value={descriptionTxtcn}
                        onChange={(value, byPassIsDirty) => {
                          changeInput('event.descriptionTxtcn', value, byPassIsDirty);
                        }}
                        required
                        errorMessage={errors['event.descriptionTxtcn']}
                      />
                    </div>
                  </div>
                  {/* 파일첨부영역 : drag */}
                  <div className="form-table ">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* 파일첨부영역 : drag */}
                        <AppFileAttach
                          label={'첨부파일'}
                          fileGroupSeq={fileGroupSeq}
                          workScope={'A'}
                          updateFileGroupSeq={(newFileGroupSeq) => {
                            changeInput('event.fileGroupSeq', newFileGroupSeq);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        {/* 날씨 */}
        <dl className={weatherExpaned ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('weatherExpaned');
            }}
          >
            <button type="button" className="btn-tg">
              날씨
              <span className={weatherExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: weatherExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid50">
                        {/*Met */}
                        <AppCodeSelect
                          label="Met"
                          codeGrpId="CODE_GRP_005"
                          value={metCd}
                          onChange={(value) => {
                            changeInput('weather.metCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <div className="flex-between">
                              <div className="form-group wid100">
                                <div className="flex-start">
                                  <div className="">
                                    <AppTextInput
                                      inputType={'number'}
                                      label={''}
                                      value={windOneCo}
                                      onChange={(value) => {
                                        changeInput('weather.windOneCo', value);
                                      }}
                                    />
                                  </div>
                                  <span className="unt">/</span>
                                  <div className="">
                                    <AppTextInput
                                      inputType={'number'}
                                      label={''}
                                      value={windTwoCo}
                                      onChange={(value) => {
                                        changeInput('weather.windTwoCo', value);
                                      }}
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="form-group wid100 ml5">
                                <div className="df">
                                  <AppTextInput
                                    inputType={'number'}
                                    label={'격발'}
                                    value={gustCo}
                                    onChange={(value) => {
                                      changeInput('weather.gustCo', value);
                                    }}
                                  />
                                  <span className="info-tit">케츠</span>
                                </div>
                              </div>
                            </div>
                            <label htmlFor="file" className="file-label">
                              실제날씨 <span className="required"></span>
                            </label>
                          </div>

                          <div className="form-group wid100 mt10">
                            <AppTextInput
                              label="시계"
                              value={visibilityNm}
                              onChange={(value) => {
                                changeInput('weather.visibilityNm', value);
                              }}
                            />
                          </div>
                          <div className="form-group wid100 mt10">
                            <div className="flex-between">
                              <div className="form-group wid50">
                                <AppCodeSelect
                                  label="구름"
                                  codeGrpId="CODE_GRP_007"
                                  value={cloudCd}
                                  onChange={(value) => {
                                    changeInput('weather.cloudCd', value);
                                  }}
                                />
                              </div>
                              <div className="form-group wid100 ml5">
                                <div className="df">
                                  <AppTextInput
                                    inputType={'number'}
                                    label={'온도'}
                                    value={tempCo}
                                    onChange={(value) => {
                                      changeInput('weather.tempCo', value);
                                    }}
                                  />
                                  <span className="info-tit">℃</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="form-group wid100 mt10">
                            <div className="flex-between">
                              <div className="form-group wid50">
                                <AppTextInput
                                  inputType={'number'}
                                  label={'고도계'}
                                  value={altimeterCo}
                                  onChange={(value) => {
                                    changeInput('weather.altimeterCo', value);
                                  }}
                                />
                              </div>
                              <div className="form-group wid100 ml5">
                                <AppCodeSelect
                                  codeGrpId="CODE_GRP_006"
                                  value={altimeterUnitCd}
                                  onChange={(value) => {
                                    changeInput('weather.altimeterUnitCd', value);
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*multiple selection 처리 */}
                        <AppCodeSelect
                          label="심각한 날씨(다중 섹션)"
                          isMultiple
                          codeGrpId="CODE_GRP_008"
                          value={weatherCodeList}
                          onChange={(value) => {
                            changeInput('weather.weatherCodeList', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        {/* 조류충돌 */}
        <dl className={birdExapned ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('birdExapned');
            }}
          >
            <button type="button" className="btn-tg">
              조류충돌
              <span className={birdExapned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: birdExapned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid100">
                        {/*새의 종류
                         */}
                        <AppTextInput
                          inputType="text"
                          placeholder=""
                          label="새의 종류"
                          toolTipMessage="자유형식으로 입력가능
                          예)Waypoint, 이륙 후3시간 경과 시점 등"
                          value={birdTypeNm}
                          onChange={(value) => {
                            changeInput('bird.birdTypeNm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Size of Bird"
                          options={CodeService.getOptions('CODE_GRP_093')}
                          value={birdSizeCd}
                          onChange={(value) => {
                            changeInput('bird.birdSizeCd', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Number Seen"
                          options={CodeService.getOptions('CODE_GRP_094')}
                          value={birdCoCd}
                          onChange={(value) => {
                            changeInput('bird.birdCoCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Number Struck"
                          options={CodeService.getOptions('CODE_GRP_094')}
                          value={struckBirdCoCd}
                          onChange={(value) => {
                            changeInput('bird.struckBirdCoCd', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <span className="txt">Time</span>
                        <AppRadioGroup
                          label="Time"
                          options={CodeService.getOptions('CODE_GRP_095')}
                          value={timeTypeCd}
                          onChange={(value) => {
                            changeInput('bird.timeTypeCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Landing Light"
                          options={Code.reportUseYn}
                          value={landingLightYn}
                          onChange={(value) => {
                            changeInput('bird.landingLightYn', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <span className="txt">Pilot Warned of Birds</span>
                        <AppRadioGroup
                          label="Pilot Warned of Birds"
                          options={Code.reportOnOff}
                          value={pilotWarnedYn}
                          onChange={(value) => {
                            changeInput('bird.pilotWarnedYn', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid100">
                        {/*Impact Point*/}
                        <AppTextInput
                          inputType="text"
                          label="Impact Point"
                          value={impactTimeNm}
                          onChange={(value) => {
                            changeInput('bird.impactTimeNm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid100">
                        <AppTextArea
                          label="Describe: Damage, Injuries and other information"
                          style={{ width: '100%', height: 100 }}
                          value={birdDescriptionCn}
                          onChange={(value) => {
                            changeInput('bird.birdDescriptionCn', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      {/* 하단버튼영역 */}
      <ReportEditBottomButton print={print} tempSave={tempSave} save={save} />
    </>
  );
}
export default ReportASREditForm;
