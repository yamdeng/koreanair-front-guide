import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
// import AppNavigation from '@/components/common/AppNavigation';
import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';
import MyAuditPlan from './MyAuditPlan';
import MyAuditConduct from './MyAuditConduct';
import MyAuditCar from './MyAuditCar';
import MyAuditClose from './MyAuditClose';

function MyAuditFrame() {
  const { auditId, findingId } = useParams();

  const { getAuditInfo, dsAuditInfo, setAuditPhase } = useMyAuditFrameStore();
  //const useMyAuditPlanStoreState = useMyAuditPlanStore();
  //const { dsAuditPlanInfo } = useMyAuditPlanStore();

  const init = () => {
    // edit
    if (auditId && auditId.length) {
      getAuditInfo(auditId);
    }
    // add
    else {
      dsAuditInfo.phaseLevel = 1; // Plan 단계로 설정
      setAuditPhase('PLAN'); // Plan 영역 view
    }
  };

  useEffect(() => {
    init();
    //return clearView;
    //useMyAuditPlanStoreState.isAnybodyHelp();
  }, []);

  return (
    <>
      {/*경로 */}
      {/* <AppNavigation /> */}
      {/*//경로 */}

      <div className="myaudit-container">
        <div className="myaudit-header">
          <div className="ad-number">
            {/* Audit No. <span>{dsAuditInfo.auditNo}</span> */}
            Audit No. {dsAuditInfo.auditNo}
          </div>
          <div className="myaudit-tab">
            <ul>
              <li>
                <a className="active" href="javascript:void(0);" onClick={() => setAuditPhase('PLAN')}>
                  <span className="myaudit-tab-icon">아이콘</span> Plan
                </a>
              </li>
              <li>
                <a href="javascript:void(0);" onClick={() => setAuditPhase('CONDUCT')}>
                  <span className="myaudit-tab-icon">아이콘</span>Conduct
                </a>
              </li>
              <li>
                <a href="javascript:void(0);" onClick={() => setAuditPhase('CAR')}>
                  <span className="myaudit-tab-icon">아이콘</span> CAR
                </a>
              </li>
              <li>
                <a href="javascript:void(0);" onClick={() => setAuditPhase('CLOSE')}>
                  <span className="myaudit-tab-icon">아이콘</span>Close
                </a>
              </li>
            </ul>
          </div>
          {/* <div className="editbox Audit">
            <div className="form-group wid100 Position-w">Audit No. 24-LSA-0407</div>
          </div>
          {/*탭 */}
          {/* <div className="menu-tab-nav">
            <div className="ux-tab -scroll ux-order-list-tab">
              <div className="ux-order-list-tab__wrap">
                <ul className="ux-tab__list">
                  <li className="ux-tab__item ux-order-list-tab__item -scroll -active">
                    <button type="button" className="ux-order-list-tab__button">
                      <span className="ux-order-list-tab__link-text">Plan</span>
                      <span className="icon-end">
                        <span className="icon -arrow-right -gray -size24 -msize16"></span>
                      </span>
                    </button>
                  </li>
                  <li className="ux-order-list-tab__host hydrated">
                    <button type="button" className="ux-order-list-tab__button">
                      <span className="ux-order-list-tab__link-text">Conduct</span>
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>*/}
          {/*//탭 */}
        </div>
        {dsAuditInfo.phaseLevel > 0 ? <MyAuditPlan /> : <></>}
        {dsAuditInfo.phaseLevel > 1 ? <MyAuditConduct /> : <></>}
        {dsAuditInfo.phaseLevel > 2 ? <MyAuditCar /> : <></>}
        {dsAuditInfo.phaseLevel > 3 ? <MyAuditClose /> : <></>}
      </div>
    </>
  );
}

export default MyAuditFrame;
