import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppNavigation from '@/components/common/AppNavigation';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppTextInput from '@/components/common/AppTextInput';
import { useTranslation } from 'react-i18next';
import ApiService from '@/services/ApiService';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/board/boardList',
  baseRoutePath: '/aviation/board-manage/safety-board',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  boardType: '',
  titleKo: '',
  useYn: '',
  selectAll: '20,30,40',
};

/* zustand store 생성 */
const AvnSafetyBoardListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    boardType: '',
    titleKo: '',
    useYn: '',
    selectAll: '20,30,40',
  },
  //board Type options
  boardTypeOptions: [],

  //board Type 가져오기
  getBoardType: async () => {
    const boardTypeList = await ApiService.get(`com/code-groups/CODE_GRP_141/codes`);
    const dataList = boardTypeList.data;
    const customValue = [];
    dataList.some((data) => {
      if (data.codeId == '20' || data.codeId == '30' || data.codeId == '40') {
        customValue.push(data);
      }
    });

    set({ boardTypeOptions: customValue });
  },

  // getSearchParam: () => {
  //   const { searchParam, currentPage, pageSize, boardTypeOptions } = get();
  //   const { boardType } = searchParam;
  //   const apiParam = { ...searchParam };
  //   apiParam.pageNum = currentPage;
  //   apiParam.pageSize = pageSize;
  //   if (!boardType) {
  //     // debugger;
  //     apiParam.boardTypeList = boardTypeOptions.map((info) => info.codeId);
  //   }
  //   return apiParam;
  // },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  init: async () => {
    const { getBoardType, initSearchInput, enterSearch } = get();
    initSearchInput();
    //게시판 종류 가져오기
    await getBoardType();
    enterSearch();
  },

  clear: () => {
    set(initListData);
  },
}));

function SafetyBoardList() {
  // 언어설정
  const { t } = useTranslation();
  const state = AvnSafetyBoardListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번', cellStyle: { textAlign: 'center' } },
      { field: 'boardType', headerName: '게시판 구분', cellStyle: { textAlign: 'center' } },
      { field: 'jobType', headerName: '업무 구분', cellStyle: { textAlign: 'center' } },
      { field: 'titleKo', headerName: '제목' },
      { field: 'viewCount', headerName: '조회수', cellStyle: { textAlign: 'center' } },
      { field: 'useYn', headerName: '사용여부', cellStyle: { textAlign: 'center' } },
      { field: 'regUserId', headerName: '작성자', cellStyle: { textAlign: 'center' } },
      { field: 'regDttm', headerName: '작성일자', cellStyle: { textAlign: 'center' } },
    ])
  );

  // AvnSafetyBoardListStore 정의된 메소드 사용 시 이곳에 분해할당
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    clear,
    goDetailPage,
    boardTypeOptions,
    //getBoardType,
    init,
  } = state;

  // input value에 넣기 위한 분리 선언
  const { boardType, titleKo, useYn } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.boardId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    init();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>Safety 게시판</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSelect
                  //codeGrpId="CODE_GRP_141" >> 20,30,40 만 선택해서 출력되도록
                  applyAllSelect
                  label={t('ke.safety.Notice.label.00001')}
                  value={boardType}
                  onChange={(value) => {
                    if (value == '') {
                      changeSearchInput('selectAll', '20,30,40');
                      changeSearchInput('boardType', '');
                    } else {
                      changeSearchInput('selectAll', '');
                      changeSearchInput('boardType', value);
                    }
                  }}
                  search={enterSearch}
                  options={boardTypeOptions}
                  labelKey="codeNameKor"
                  valueKey="codeId"
                />
              </div>
            </div>

            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={t('ke.safety.Notice.label.00002')}
                  value={titleKo}
                  onChange={(value) => {
                    changeSearchInput('titleKo', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_146"
                  applyAllSelect
                  label={t('ke.safety.Notice.label.00003')}
                  value={useYn}
                  onChange={(value) => {
                    changeSearchInput('useYn', value);
                  }}
                />
              </div>
            </div>
            <div className="btn-area df">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                {t('ke.safety.common.label.00002')}
              </button>
              <button
                type="button"
                name="button"
                className="btn-sm btn_text btn-darkblue-line"
                onClick={initSearchInput}
              >
                {t('ke.safety.common.label.00003')}
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
        />
      </div>
      {/*//그리드영역 */}

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
      {/*//하단버튼영역*/}
    </>
  );
}

export default SafetyBoardList;
