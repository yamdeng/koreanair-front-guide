import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import AppNavigation from '@/components/common/AppNavigation';
import { useTranslation } from 'react-i18next';

/* store  */
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import AppFileAttach from '@/components/common/AppFileAttach';

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/promotion/communication/newsletters',
  baseRoutePath: '/aviation/sftm/newsletter',
};

/* zustand store 생성 */
const AvnSafetyCommunicationNewsletterDetailStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  clear: () => {
    set({ ...formBaseState });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SafetyCommunicationNewsletterDetail() {
  // 언어설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const { detailInfo, getDetail, cancel, clear } = AvnSafetyCommunicationNewsletterDetailStore();
  const { titleKo, content, fileGroupSeq } = detailInfo;

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>Newsletter 상세</h2>
      </div>
      {/*상세페이지*/}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00002')}</label>
                    <span className="text-desc-type1"> {titleKo}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00009')}</label>
                    <span className="text-desc-type1">{content}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00007')}</label>
                    <span className="text-desc-type1">
                      <AppFileAttach mode="view" onlyImageUpload={true} fileGroupSeq={fileGroupSeq} disabled={true} />
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
      </div>
      {/*//상세페이지*/}
      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text btn_list" onClick={cancel}>
          {t('ke.safety.common.label.00006')}
        </button>
      </div>
      {/*//하단버튼영역*/}
    </>
  );
}
export default SafetyCommunicationNewsletterDetail;
