import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
//import AppDatePicker from '@/components/common/AppDatePicker';
import AppEditor from '@/components/common/AppEditor';
//import AppSelect from '@/components/common/AppSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppFileAttach from '@/components/common/AppFileAttach';
import { Upload } from 'antd';
import { useState } from 'react';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import AppDatePicker from '@/components/common/AppDatePicker';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';

/* TODO : store 경로를 변경해주세요. */
import useOcuCommitteeFormStore from '@/stores/occupation/general/useOcuCommitteeFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCommitteeForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, save, remove, cancel, clear } =
    useOcuCommitteeFormStore();

  const {
    // 제목
    title,
    // 내용
    content,
    // 첨부 링크 ID
    // linkId,
    // 부문 코드
    sectCd,
    // 등록자
    regUserId,
    // 등록일자
    regDttm,
    // 첨부파일 ID
    fileId,
  } = formValue;

  const { detailId } = useParams();

  const profile = useStore(useAppStore, (state) => state.profile);
  // 사용자명
  const nameKor = profile.userInfo.nameKor;

  // 오늘 날짜
  const toDate = CommonUtil.getToDate();

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  const [fileGroupSeq, setFileGroupSeq] = useState('');

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>산업안전보건위원회</h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="제목"
                value={title}
                onChange={(value) => changeInput('title', value)}
                required
                errorMessage={errors.title}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppEditor
                placeholder="입력해주세요."
                value={content}
                onChange={(value) => changeInput('content', value)}
                required
                errorMessage={errors.content}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="group-box-wrap line wid100">
              <span className="txt">첨부파일 Link{/*<span className="required">*</span>*/}</span>
              <button type="button" name="button" className="btn-plus">
                추가
              </button>
              <div className="file-link">
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link첨부Link첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label="부문"
                codeGrpId="CODE_GRP_OC001"
                value={sectCd}
                onChange={(value) => changeInput('sectCd', value)}
                required
                disabled={formType !== 'add' ? true : false}
                errorMessage={errors.sectCd}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="등록자"
                // value={regUserId}
                value={detailId === 'add' ? nameKor : regUserId}
                //onChange={(value) => changeInput('regUserId', value)}
                onChange={(value) => changeInput(detailId === 'add' ? 'nameKor' : 'regUserId', value)}
                required
                disabled="false"
                // errorMessage={errors.regUserId}
                errorMessage={detailId === 'add' ? errors.nameKor : errors.regUserId}
                // disabled={formType !== 'add' ? true : false}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppDatePicker label={'등록일자'} /> */}
              <AppTextInput
                disabled
                label="등록일자"
                // value={regDttm}
                value={detailId === 'add' ? toDate : regDttm}
                onChange={(value) => changeInput(detailId === 'add' ? 'toDate' : 'regDttm', value)}
                required
                errorMessage={detailId === 'add' ? errors.toDate : errors.regDttm}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppFileAttach
                label="파일첨부"
                fileGroupSeq={fileId}
                workScope={'O'}
                // onlyImageUpload={true}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileId', newFileGroupSeq);
                }}
                // maxCount={1}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuCommitteeForm;
