import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDeptListSelectInput from '@/components/common/AppDeptListSelectInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';

import history from '@/utils/history';
/* TODO : store 경로를 변경해주세요. */

const currentYear = new Date().getFullYear().toString();

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/general/cost',
  baseRoutePath: '/occupation/general/costList',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 년도
  planYear: currentYear,
  // Department
  sectCd: '',
  // Resp Center
  respCenter: '',
  // Item
  itemCd: '',
  // Account Name
  acntCd: '',
};

/* zustand store 생성 */
const OcuCostExecListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  //from 상세 조회
  goDetailPage: async (keyData) => {
    const { baseRoutePath } = get();

    const queryParams = CommonUtil.objectToQueryString({
      planYear: keyData.planYear,
      sectCd: keyData.sectCd,
      searchRespCenter: keyData.respCenter,
      itemCd: keyData.itemCd,
      acntCd: keyData.acntCd,
    });

    history.push(`${baseRoutePath}/view${queryParams}`);
  },

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    // 년도
    planYear: currentYear,
    // Department
    sectCd: '',
    // Resp Center
    respCenter: '',
    // Item
    itemCd: '',
    // Account Name
    acntCd: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  goAddPage: () => {
    const { baseRoutePath } = get();
    console.log(`이곳에값==>, ${baseRoutePath}`);
    history.push(`${baseRoutePath}/insert`);
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));
function OcuCostExecList() {
  const state = OcuCostExecListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호' },
      { field: 'planYear', headerName: '년도' },
      { field: 'sectNm', headerName: 'Department' },
      //{ field: 'costCenterNm', headerName: 'Cost Center' },
      { field: 'respCenter', headerName: 'Resp Center' },
      { field: 'itemNm', headerName: 'Item' },
      { field: 'acntCd', headerName: 'Account' },
      { field: 'acntNm', headerName: 'Account Name' },
      { field: 'payTermNm', headerName: 'Payterm' },
      { field: 'mainPlanAmt', headerName: 'Amount' },
      { field: 'mainTotAmt', headerName: 'Total Amount' },
      { field: 'lineDesc', headerName: 'Description' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    //initSearchInput,
    //isExpandDetailSearch,
    //toggleExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;

  // TODO : 검색 파라미터 나열
  const { planYear, sectCd, respCenter, itemCd, acntCd } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    // 산업안전보건 관리비 id
    //console.log('data.ocuCommitId===>', data.ocuCommitId);

    // 년도, 부문, 부서, account, Item
    const keyData = {
      planYear: data.planYear,
      sectCd: data.sectCd,
      respCenter: data.respCenter,
      itemCd: data.itemCd,
      acntCd: data.acntCd,
    };

    //const detailId = data.ocuCommitId;
    goDetailPage(keyData);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  const changeCostTap = () => {
    history.push('costState');
  };

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>산업안전보건관리비</h2>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="menu-tab">
          <a href={undefined} data-label="현황" onClick={changeCostTap}>
            현황
          </a>
          <a href={undefined} className="active" data-label="목록">
            목록
          </a>
        </div>
      </div>
      {/*//탭 */}
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDatePicker
                  label={'년도'}
                  pickerType="year"
                  value={planYear}
                  onChange={(value) => {
                    changeSearchInput('planYear', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="부문"
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC001"
                  value={sectCd}
                  onChange={(value) => {
                    changeSearchInput('sectCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDeptSelectInput
                  label="Resp Center"
                  value={respCenter}
                  onChange={(value) => {
                    changeSearchInput('respCenter', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="item"
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC017"
                  value={itemCd}
                  onChange={(value) => {
                    changeSearchInput('itemCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="Account Name"
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC045"
                  value={acntCd}
                  onChange={(value) => {
                    changeSearchInput('acntCd', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button type="button" name="button" className="arrow button _control active">
          <span className="hide">접기</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default OcuCostExecList;
