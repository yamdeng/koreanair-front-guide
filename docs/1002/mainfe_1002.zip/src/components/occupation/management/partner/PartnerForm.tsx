import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import AppNavigation from '@/components/common/AppNavigation';
import AppTextInput from '@/components/common/AppTextInput';
import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import CommonUtil from '@/utils/CommonUtil';

import useOcuPartnerFormStore from '@/stores/occupation/management/useOcuPartnerFormStore';

function OcuPartnerForm() {
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    selectedPlaceIndex,
    setSelectedPlaceIndex,
    selectedPlace2ndInfoIndex,
    setSelectedPlace2ndInfoIndex,
    addPlaceRow,
    delPlaceRow,
    setPlaceColumn,
    getPlaceColumn,
    getPlaceError,
    getPlace2ndList,
    addPlace2ndInfo,
    delPlace2ndInfo,
    isDirty,
    saveAll,
    remove,
    cancel,
    clear,
  } = useOcuPartnerFormStore();

  // Grid Column  - 협력업체 사업장
  const [ocuPartnerPlaceColumns, setOcuPartnerPlaceColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: '_status', headerName: '상태' },
      { field: 'bizPlaceClsCd', headerName: '사업장분류' },
      { field: 'useSectCd', headerName: '사용부문' },
    ])
  );

  // Grid Column  - 협력업체 사업장의 2차 협력업체
  const [ocuPartner2ndInfoColumns, setOcuPartner2ndInfoColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: '_status', headerName: '상태' },
      { field: 'companyNm', headerName: '업체명' },
      { field: 'majorWorkCn', headerName: '주요업무' },
      { field: 'staffNm', headerName: '담당자명' },
      { field: 'staffContactNo', headerName: '연락처' },
    ])
  );

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  const handleRowSingleClick_OcuPartnerPlace = useCallback(
    (selectedInfo) => {
      setSelectedPlaceIndex(selectedInfo.rowIndex);
    },
    [selectedPlaceIndex]
  );

  const handleRowSingleClick_OcuPartnerPlace2ndInfo = useCallback(
    (selectedInfo) => {
      setSelectedPlace2ndInfoIndex(selectedInfo.rowIndex);
    },
    [selectedPlace2ndInfoIndex]
  );

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  // 첫번째 행 선택
  useEffect(() => {
    if (formValue?.placeList && formValue.placeList.length > 0 && selectedPlaceIndex === -1) {
      const firstRow = formValue.placeList[0];
      handleRowSingleClick_OcuPartnerPlace({ data: firstRow, rowIndex: 0 });
    }
  }, [formValue, selectedPlaceIndex]);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>협력업체 등록/수정</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          {/* <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput label="작성자" required disabled />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput label="작성일자" required disabled />
            </div>
          </div> */}

          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuPartnerInfoFormprtnrNm"
                name="prtnrNm"
                label="업체명"
                value={formValue.prtnrNm}
                onChange={(value) => changeInput('prtnrNm', value)}
                errorMessage={errors.prtnrNm}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuPartnerInfoFormbizNo"
                name="bizNo"
                label="사업자번호"
                value={formValue.bizNo}
                onChange={(value) => changeInput('bizNo', value)}
                errorMessage={errors.bizNo}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuPartnerInfoFormrprsn"
                name="rprsn"
                label="대표자"
                value={formValue.rprsn}
                onChange={(value) => changeInput('rprsn', value)}
                errorMessage={errors.rprsn}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuPartnerInfoFormbizIndst"
                name="bizIndst"
                label="업태"
                value={formValue.bizIndst}
                onChange={(value) => changeInput('bizIndst', value)}
                errorMessage={errors.bizIndst}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuPartnerInfoFormbizType"
                name="bizType"
                label="업종"
                value={formValue.bizType}
                onChange={(value) => changeInput('bizType', value)}
                errorMessage={errors.bizType}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="ck-edit-box pd-t0">
              <div className="ck-list">
                <span className="stit-btn">
                  <h3>사업장</h3>
                  <button onClick={() => addPlaceRow()}>추가</button>
                </span>
                <span className="stit-btn">
                  <button onClick={() => delPlaceRow()}>삭제</button>
                </span>
                <AppTable
                  rowData={formValue.placeList}
                  columns={ocuPartnerPlaceColumns}
                  setColumns={setOcuPartnerPlaceColumns}
                  hiddenTableHeader={true}
                  handleRowSingleClick={handleRowSingleClick_OcuPartnerPlace}
                  getRowStyle={(params) => {
                    const { data, rowIndex } = params;
                    if (rowIndex === selectedPlaceIndex) {
                      return { background: '#d6d9eb' };
                    } else if (data._isError) {
                      return { background: '#ebb2b2' };
                    }
                  }}
                />
              </div>
              <div className="ck-edit">
                <div className="boxForm">
                  <h3 className="table-tit mt-10">사업장 상세정보</h3>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="사업장분류"
                          id="OcuPartnerInfoPlaceForm_bizPlaceClsCd"
                          name="bizPlaceClsCd"
                          value={getPlaceColumn('bizPlaceClsCd')}
                          onChange={(value) => setPlaceColumn('bizPlaceClsCd', value)}
                          errorMessage={getPlaceError('bizPlaceClsCd')}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="사용부문"
                          id="OcuPartnerInfoPlaceForm_useSectCd"
                          name="useSectCd"
                          value={getPlaceColumn('useSectCd')}
                          onChange={(value) => setPlaceColumn('useSectCd', value)}
                          errorMessage={getPlaceError('useSectCd')}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="관리부서"
                          id="OcuPartnerInfoPlaceForm_mgntDeptCd"
                          name="mgntDeptCd"
                          value={getPlaceColumn('mgntDeptCd')}
                          onChange={(value) => setPlaceColumn('mgntDeptCd', value)}
                          errorMessage={getPlaceError('mgntDeptCd')}
                          required
                        />
                        {/* <AppAutoComplete
                          label="관리부서"
                          id="OcuPartnerInfoPlaceFormbizmgntDeptCd"
                          name="mgntDeptCd"
                          value={getPlaceColumn('mgntDeptCd}
                          onChange={(value) => changeInput('mgntDeptCd', value)}
                          errorMessage={errors.mgntDeptCd}
                          required
                        /> */}
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="관리자1"
                          id="OcuPartnerInfoPlaceForm_staffNm1"
                          name="staffNm1"
                          value={getPlaceColumn('staffNm1')}
                          onChange={(value) => setPlaceColumn('staffNm1', value)}
                          errorMessage={getPlaceError('staffNm1')}
                          required
                        />
                        {/* <AppAutoComplete
                          label="관리자1"
                          id="OcuPartnerInfoPlaceFormstaffNm1"
                          name="staffNm1"
                          value={getPlaceColumn('staffNm1}
                          onChange={(value) => changeInput('staffNm1', value)}
                          errorMessage={errors.staffNm1}
                          required
                        /> */}
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="연락처1"
                          id="OcuPartnerInfoPlaceForm_staffContactNo1"
                          name="staffContactNo1"
                          value={getPlaceColumn('staffContactNo1')}
                          onChange={(value) => setPlaceColumn('staffContactNo1', value)}
                          errorMessage={getPlaceError('staffContactNo1')}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="이메일1"
                          id="OcuPartnerInfoPlaceForm_staffEmail1"
                          name="staffEmail1"
                          value={getPlaceColumn('staffEmail1')}
                          onChange={(value) => setPlaceColumn('staffEmail1', value)}
                          errorMessage={getPlaceError('staffEmail1')}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="담당업무1"
                          id="OcuPartnerInfoPlaceForm_staffWork1"
                          name="staffWork1"
                          value={getPlaceColumn('staffWork1')}
                          onChange={(value) => setPlaceColumn('staffWork1', value)}
                          errorMessage={getPlaceError('staffWork1')}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="관리자2"
                          id="OcuPartnerInfoPlaceForm_staffNm2"
                          name="staffNm2"
                          value={getPlaceColumn('staffNm2')}
                          onChange={(value) => setPlaceColumn('staffNm2', value)}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="연락처2"
                          id="OcuPartnerInfoPlaceForm_staffContactNo2"
                          name="staffContactNo2"
                          value={getPlaceColumn('staffContactNo2')}
                          onChange={(value) => setPlaceColumn('staffContactNo2', value)}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="이메일2"
                          id="OcuPartnerInfoPlaceForm_staffEmail2"
                          name="staffEmail2"
                          value={getPlaceColumn('staffEmail2')}
                          onChange={(value) => setPlaceColumn('staffEmail2', value)}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="담당업무2"
                          id="OcuPartnerInfoPlaceForm_staffWork2"
                          name="staffWork2"
                          value={getPlaceColumn('staffWork2')}
                          onChange={(value) => setPlaceColumn('staffWork2', value)}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="안전관리"
                          id="OcuPartnerInfoPlaceForm_sftyMgnt"
                          name="sftyMgnt"
                          value={getPlaceColumn('sftyMgnt')}
                          onChange={(value) => setPlaceColumn('sftyMgnt', value)}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="보건관리"
                          id="OcuPartnerInfoPlaceForm_hlthMgnt"
                          name="hlthMgnt"
                          value={getPlaceColumn('hlthMgnt')}
                          onChange={(value) => setPlaceColumn('hlthMgnt', value)}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="주요업무"
                          id="OcuPartnerInfoPlaceForm_majorWorkCn"
                          name="majorWorkCn"
                          value={getPlaceColumn('majorWorkCn')}
                          onChange={(value) => setPlaceColumn('majorWorkCn', value)}
                          errorMessage={getPlaceError('majorWorkCn')}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <span className="stit-btn">
                          <h3>2차 협력업체</h3>
                          <button onClick={() => addPlace2ndInfo()}>추가</button>
                        </span>
                        <span className="stit-btn">
                          <button onClick={() => delPlace2ndInfo()}>삭제</button>
                        </span>
                        <AppTable
                          rowData={getPlace2ndList()} // 2nd info를 담은 리스트를 그리드에 표시
                          columns={ocuPartner2ndInfoColumns} // 2nd info의 칼럼
                          setColumns={setOcuPartner2ndInfoColumns}
                          handleRowSingleClick={handleRowSingleClick_OcuPartnerPlace2ndInfo}
                          hiddenTableHeader={true}
                          getRowStyle={(params) => {
                            const { data } = params;
                            if (data._isError) {
                              return { background: '#ebb2b2' };
                            }
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
      </div>

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={saveAll}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuPartnerForm;
