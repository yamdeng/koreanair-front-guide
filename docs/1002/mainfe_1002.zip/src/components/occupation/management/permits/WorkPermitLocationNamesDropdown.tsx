import React, { useEffect, useState } from 'react';

const LocationNamesDropdown = () => {
  const [locationNames, setLocationNames] = useState([]);
  const [error, setError] = useState(null);
  const [selectedLocation, setSelectedLocation] = useState(''); // 선택한 공사장소명을 저장할 상태

  useEffect(() => {
    const fetchLocationNames = async () => {
      try {
        const response = await fetch('/management/permits/locationNames');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setLocationNames(data);
      } catch (err) {
        setError(err);
      }
    };

    fetchLocationNames();
  }, []);

  const handleSelectChange = (event) => {
    setSelectedLocation(event.target.value); // 선택한 값을 상태에 저장
  };

  return (
    <div>
      <select value={selectedLocation} onChange={handleSelectChange}>
        <option value="">선택하세요</option> {/* 기본 선택 옵션 */}
        {locationNames.map((locationName, index) => (
          <option key={index} value={locationName}>
            {locationName}
          </option>
        ))}
      </select>
      <div>
        <p>선택한 공사장소명: {selectedLocation}</p> {/* 선택한 값 표시 */}
      </div>
    </div>
  );
};

export default LocationNamesDropdown;
