// 보고서 대분류 유형 : reportTypeCd
export const REPORT_TYPE_ASR = 'asr';
export const REPORT_TYPE_CSR = 'csr';
export const REPORT_TYPE_GSR = 'gsr';
export const REPORT_TYPE_MSR = 'msr';
export const REPORT_TYPE_DSR = 'dsr';
export const REPORT_TYPE_RSR = 'rsr';
export const REPORT_TYPE_HZR = 'hzr';
