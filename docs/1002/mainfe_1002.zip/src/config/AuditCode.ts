import _ from 'lodash';

const AuditCode: any = {};

const today = new Date();
const currentYear = today.getFullYear();
// 과거 3년부터 ~ 향후1년
// 2021, 2022, 2023, 2024, 2025
const auditYearList = [];

for (let index = 0; index <= 4; index++) {
  auditYearList.push(currentYear - (index - 1) + '');
}

/*
    Audit 관리 년도
*/
AuditCode.auditYear = auditYearList.map((year) => {
  return {
    label: year,
    value: year,
  };
});

/*
    Audit 결재권자 선택
*/
AuditCode.myProcessingGubun = [
  {
    label: '전체',
    value: 'all',
  },
  {
    label: 'Auditor',
    value: 'auditor',
  },
  {
    label: '결재권자',
    value: 'approve',
  },
];

// 코드명 가져오기 : value 기준
AuditCode.getCodeLabelByValue = function (codeCategory, codeValue) {
  let codeLabel = null;
  const codeList = AuditCode[codeCategory] || [];
  const searchIndex = _.findIndex(codeList, (codeInfo) => {
    if (codeValue === codeInfo.value) {
      return true;
    } else {
      return false;
    }
  });
  if (searchIndex !== -1) {
    const findCodeInfo = codeList[searchIndex];
    codeLabel = findCodeInfo.label;
  }
  return codeLabel;
};

export default AuditCode;
