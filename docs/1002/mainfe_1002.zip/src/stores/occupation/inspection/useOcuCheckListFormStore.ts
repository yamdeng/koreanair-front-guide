import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import * as yup from 'yup';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';
import _ from 'lodash';

/* yup validation */
const yupFormSchema = yup.object({
  chkListTitle: yup.string().required(),
  placeList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        prtnrId: yup.string().required(),
        bizPlaceId: yup.string().required(),
      })
    ),
  itemList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        chkClsCd: yup.string().required(),
        chkItemNm: yup.string().required(),
      })
    ),
});

/* searchParam 초기화 */
const initSearchParam = {
  sectCd: '',
  deptCd: '',
  chkListTitle: '',
  fromRegDttm: '',
  toRegDttm: '',
};

/* formValue 초기값 */
const initFormValue = {
  chkListClsCd: 'A', //점검표_구분_코드
  chkListTitle: '', //점검표_제목
  regDttm: '', //등록_일시
  regUserId: '', //등록자_ID
  updDttm: '', //수정_일시
  updUserId: '', //수정자_ID
  placeList: [],
  itemList: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/inspection/checklist',
  baseRoutePath: '/occupation/inspection/checklist',
  formName: 'OcuCheckListForm',
  formValue: {
    ...initFormValue,
  },

  selectedPlaceIndex: -1,
  selectedItemIndex: -1,
};

/* zustand store 생성 */
export const useOcuCheckListFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...createCommonDataset(set, get),

  ...initFormData,

  searchParam: {
    ...initSearchParam,
  },

  yupFormSchema: yupFormSchema,

  initSearchInput: () => {
    set({
      searchParam: {
        sectCd: '',
        deptCd: '',
        chkListTitle: '',
        fromRegDttm: '',
        toRegDttm: '',
      },
    });
  },

  getPlacePath: () => {
    return `formValue.placeList`;
  },

  getItemPath: () => {
    return `formValue.itemList`;
  },

  openItemModal: () => {
    set({ isItemFormModalOpen: true });
  },

  closeItemModal: () => {
    set({ isItemFormModalOpen: false });
  },

  setSelectedItemIndex: (index: number) => {
    set({ selectedItemIndex: index });
  },

  openPartnerModal: () => {
    set({ isPartnerModalOpen: true });
  },

  closePartnerModal: () => {
    set({ isPartnerModalOpen: false });
  },

  selectPartnerModal: (params) => {
    const { CommonDS, getPlacePath } = get();
    CommonDS.addRow(getPlacePath(), params);
  },

  // 오류 메시지 가져오기
  getPlaceError: (field: string) => {
    const { errors, selectedPlaceIndex } = get();
    const path = `placeList[${selectedPlaceIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getPlaceColumn: (field) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.getColumn(getPlacePath(), selectedPlaceIndex, field);
  },

  setPlaceColumn: (field: string, value: any) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.setColumn(getPlacePath(), selectedPlaceIndex, field, value);
  },

  addPlaceRow: () => {
    const { CommonDS, getPlacePath } = get();
    return CommonDS.addRow(getPlacePath());
  },

  delPlaceRow: (selectedPlaceIndex: number) => {
    const { CommonDS, getPlacePath } = get();
    return CommonDS.deleteRow(getPlacePath(), selectedPlaceIndex);
  },

  getItemError: (field: string) => {
    const { errors, selectedItemIndex } = get();
    const path = `itemList[${selectedItemIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getItemColumn: (field) => {
    const { CommonDS, getItemPath, selectedItemIndex } = get();
    return CommonDS.getColumn(getItemPath(), selectedItemIndex, field);
  },

  setItemColumn: (field: string, value: any) => {
    const { CommonDS, getItemPath, selectedItemIndex } = get();
    return CommonDS.setColumn(getItemPath(), selectedItemIndex, field, value);
  },

  addItemRow: () => {
    const { CommonDS, getItemPath } = get();
    return CommonDS.addRow(getItemPath());
  },

  delItemRow: (selectedItemIndex: number) => {
    const { CommonDS, getItemPath } = get();
    return CommonDS.deleteRow(getItemPath(), selectedItemIndex);
  },

  saveAll: async () => {
    const { validate, getApiParam, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          await ApiService.post(`${formApiPath}`, apiParam);
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    } else {
      const { CommonDS, errors } = get();
      CommonDS.setValidateList('formValue', errors);
    }
  },

  // form 전체 초기화
  clear: () => {
    set({
      ...formBaseState,
      formValue: { ...initFormValue },
      selectedPlace: null,
      selectedItem: null,
      selectedPlaceIndex: -1,
      selectedItemIndex: -1,
    });
  },
}));
