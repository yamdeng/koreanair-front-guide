import { create } from 'zustand';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';

import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';
import _ from 'lodash';

import history from '@/utils/history';
import * as yup from 'yup';

// 현재 연도
const currentYear = new Date().getFullYear().toString();

/* yup validation */
const yupFormSchema = yup.object({
  //periodNm: yup.string().required(),
  planYear: yup.string().required(),
  sectCd: yup.string().required(),
  respCenter: yup.string().required(),

  acntCd: yup.string().required(),
  itemCd: yup.string().required(),
  payTerm: yup.string().required(),

  planAmt: yup.number(),
  totAmt: yup.number(),
  lineDesc: yup.string(),

  //currMltpGoalDt: yup.number().required().min(1).max(100),
  //glDt: yup.string().required(),
  // currencyCd: yup.string().required(),
  // respCenter: yup.string().required(),
  // costCenter: yup.string().required(),
  // acntCd: yup.string().required(),
  // acntNm: yup.string().required(),
  // drAmt: yup.number().required(),
  // crAmt: yup.number().nullable(),
  // lineDesc: yup.string(),
  // invoiceNo: yup.string(),
  // vendorNm: yup.string(),
  // execClsCd: yup.string().required(),
  // regDttm: yup.string().required(),
  // regUserId: yup.string().required(),
});

const modalYupFormSchema = yup.object({
  //periodNm: yup.string().required(),
  glDt: yup.string().required(),
  //currencyCd: yup.string().required(),
  //respCenter: yup.string().required(),
  costCenter: yup.string().required(),
  acntCd: yup.string().required(),
  acntNm: yup.string().required(),
  //drAmt: yup.number().required(),
  drAmt: yup.number().required().min(-99999999999),
  //crAmt: yup.string().required(),
  //execLineDesc: yup.string().required(),
  //invoiceNo: yup.string().required(),
  //vendorNm: yup.string().required(),
  //execClsCd: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  periodNm: currentYear,
  glDt: '',
  currencyCd: '',
  respCenter: '',
  costCenter: '',
  acntCd: '',
  acntNm: '',
  drAmt: null,
  crAmt: null,
  lineDesc: '',
  invoiceNo: '',
  vendorNm: '',
  execClsCd: '',
  regDttm: '',
  regUserId: '',
  searchCostCenter: '',
};

const modalFormInitFormValue = {
  periodNm: '',
  glDt: '',
  currencyCd: '',
  respCenter: '',
  costCenter: '',
  acntCd: '',
  acntNm: '',
  drAmt: '',
  crAmt: '',
  lineDesc: '',
  invoiceNo: '',
  vendorNm: '',
  execClsCd: '',
  saveGubun: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/general/cost',
  baseRoutePath: '/occupation/general/costList',
  formName: 'useOcuCostFormStore',
  formValue: {
    ...initFormValue,
  },
};

// modal store
export const useOcuCostModalFormStore = create<any>((set, get) => ({
  ...formBaseState,

  formName: 'CostExecFormModal',

  formValue: {
    ...modalFormInitFormValue,
  },

  yupFormSchema: modalYupFormSchema,

  ...createFormSliceYup(set, get),

  // 실적 저장
  save: async () => {
    const { validate, formValue } = get();
    const isValid = await validate();
    if (isValid) {
      useOcuCostFormStore.getState().okModal(formValue);
    }
  },
}));

/* zustand store 생성 */
const useOcuCostFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  list2: [],

  yupFormSchema: yupFormSchema,

  // 계획 저장
  save: async () => {
    const { validate, getApiParam, formType, formDetailId, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      const apiParam = getApiParam();
      // 중복 체크
      const dupChk = await ApiService.post(`ocu/general/cost/selectCostPlanDupChk`, apiParam);

      console.log('값==>', dupChk);

      if (dupChk == '0') {
        ModalService.confirm({
          body: '저장하시겠습니까?',
          ok: async () => {
            //const apiParam = getApiParam();
            console.log(`apiParam : ${JSON.stringify(apiParam)}`);
            if (formType === FORM_TYPE_ADD) {
              // 중복체크
              await ApiService.post(`${formApiPath}`, apiParam);
            } else {
              // 중복체크
              await ApiService.put(`${formApiPath}/${formDetailId}`, apiParam);
            }
            await set({ isDirty: false });
            ToastService.success('저장되었습니다.');
            await cancel();
          },
        });
      } else {
        alert('해당년도에 이미 등록된 RespCenter별 Account입니다.');
      }
    }
  },

  // // from 상세 조회
  getDetail: async (planYear, sectCd, searchRespCenter, itemCd, searchAcntCd) => {
    const { setList } = get();

    const apiParam = {
      planYear,
      sectCd,
      searchRespCenter,
      itemCd,
      searchAcntCd,
    };

    console.log('최후값apiParam', apiParam);

    const response: any = await ApiService.post(`ocu/general/costDetail`, apiParam);
    const detailInfo = response.data;
    set({
      detailInfo: detailInfo.planResult,
      formValue: detailInfo.planResult,
      formType: FORM_TYPE_UPDATE,
    });

    setList(detailInfo.execResult);
  },

  goFormPage: () => {
    const { baseRoutePath, formValue } = get();

    const queryParams = CommonUtil.objectToQueryString({
      planYear: formValue.planYear,
      sectCd: formValue.sectCd,
      searchRespCenter: formValue.respCenter,
      itemCd: formValue.itemCd,
      acntCd: formValue.acntCd,
    });

    history.push(`${baseRoutePath}/edit/view${queryParams}`);
  },

  remove: async () => {
    const { formDetailId, formApiPath, baseRoutePath, getApiParam } = get();
    ModalService.confirm({
      body: '삭제하시겠습니까?',
      ok: async () => {
        const apiParam = getApiParam();
        // console.log('${formApiPath}===>', `${formApiPath}`);
        //console.log('apiParam===>', apiParam);
        //console.log(`apiParam : ${JSON.stringify(apiParam)}`);
        await ApiService.post(`${formApiPath}/delete`, apiParam);
        //await ApiService.post(`${formApiPath}`, apiParam);
        ModalService.alert({
          body: '삭제되었습니다.',
          ok: async () => {
            history.replace(`${baseRoutePath}`);
          },
        });
      },
    });
  },

  openFormModal: (saveGubun, data) => {
    // 등록
    if (saveGubun === 'I') {
      const { detailInfo } = get();
      detailInfo.saveGubun = saveGubun;
      detailInfo.execClsCd = 'B';
      const { setFormValue } = useOcuCostModalFormStore.getState();
      setFormValue(detailInfo);
      set({ isCodeFormModalOpen: true });
      // 수정
    } else if (saveGubun === 'U') {
      const { detailInfo } = get();
      detailInfo.saveGubun = saveGubun;
      const { setFormValue } = useOcuCostModalFormStore.getState();

      // 년도
      data.planYear = data.execYear;
      // Department
      //data.respCenter = data.respCenter;
      // Description
      data.execLineDesc = data.lineDesc;
      // saveGubun
      data.saveGubun = saveGubun;

      setFormValue(data);
      set({ isCodeFormModalOpen: true });
    }
  },

  closeFormModal: () => {
    set({ isCodeFormModalOpen: false });
  },

  okModal: async (formValue) => {
    const { formDetailId, getDetail, search } = get();

    const formApiPath = 'ocu/general/cost/saveCostExec';
    ModalService.confirm({
      body: '저장하시겠습니까?',
      ok: async () => {
        await ApiService['post'](formApiPath, formValue, { disableLoadingBar: true });
        set({ isCodeFormModalOpen: false });
        ToastService.success('저장되었습니다.');
        await getDetail(formValue.planYear, formValue.sectCd, formValue.respCenter, formValue.itemCd, formValue.acntCd);
        search();
      },
    });
  },

  gridChangeStatus: (costData, event) => {
    const { list, list2 } = get();
    // 삭제 list
    list2.push(costData.data);
    console.log('list2@@::', list2);

    //set({ list2: { ...list } });
    //set({ list2: list });
    //list[costData.rowIndex].status = 'D';
  },

  // 산업안전보건 관리비 계획, 실적 저장
  costSave: async () => {
    const { list, list2, formDetailId, formApiPath, search, formValue, baseRoutePath, validate } = get();
    const apiList = _.cloneDeep(list2);

    const isValid = await validate();

    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const formParam = formValue;
          const prcPlanAmt = formParam.mainPlanAmt.toString();
          const prcTotAmt = formParam.mainTotAmt.toString();

          formParam.mainPlanAmt = prcPlanAmt.replace(/,/g, '');
          formParam.mainTotAmt = prcTotAmt.replace(/,/g, '');

          const apiParam = {
            //list: listParam,
            list: apiList,
            form: formParam,
          };

          await ApiService.post(`${formApiPath}/saveCost`, apiParam);
          search();
          history.push(`${baseRoutePath}`);
          ToastService.success('저장되었습니다.');
        },
      });
    }
  },

  clear: () => {
    //    set({ ...listBaseState, searchParam: {} });
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuCostFormStore;
