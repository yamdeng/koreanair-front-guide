import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { createListSlice } from '@/stores/slice/listSlice';

/* yup validation*/
const yupFormSchema = yup.object({
  // 공사장소 등록 및 관리

  cnstrSiteId: yup.number(), // 공사장소ID
  cntrLocationNm: yup.string(), // 공사장소명
  useYn: yup.string(), // 사용여부
  regDttm: yup.string(), // 등록_일시
  regUserId: yup.string(), // 등록자_ID
  updDttm: yup.string(), // 수정_일시
  updUserId: yup.string(), // 수정자_ID
});

/** form 초기값 설정 : take every values from server named 'list' */
const initFormValue = {
  list: [
    {
      _status: 'N',
      cnstrSiteId: '',
      cntrLocationNm: '',
      useYn: '',
    },
  ],
};
const initSearchParam = {
  // 공사장소명
  cntrLocationNm: '',
  // 사용여부
  useYn: '',
};

/** form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits/locations',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitLocationRegisterModalStore',

  formValue: {
    ...initFormValue,
  },

  // setting the default value for selectedIndex
  selectedIndex: -1,
};

/** zustand store 생성 */
const useOcuWorkPermitLocationRegisterModalStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...createListSlice(set, get),
  ...createCommonDataset(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  // controller the opening and closing of modal
  isLocationRegisterModalOpen: false,

  searchParam: {
    //공사장소명
    cntrLocationNm: '',
    //사용여부
    useYn: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  setSelectedIndex: (index: number) => {
    set({ selectedIndex: index });
  },

  // take all the data to set the path value in here
  getList: async () => {
    const { formApiPath, searchParam } = get(); // formApiPath, searchParam 가져오기
    const response: any = await ApiService.get(`${formApiPath}`, {
      cntrLocationNm: searchParam.cntrLocationNm,
      useYn: searchParam.useYn,
    });
    console.log('response : ', response);

    // 서버에서 가져온 데이터로 formValue 설정, searchParam은 유지
    set((prevState) => ({
      ...prevState,
      formValue: response.data,
      searchParam: {
        ...prevState.searchParam, // 기존의 검색 상태 유지
      },
    }));

    const { formValue } = get();
    console.log(formValue);

    // API 호출 후 set 이후에 log를 찍어보기
    const updatedFormValue = get().formValue; // 상태 업데이트 후 최신 값을 와보기
    console.log(updatedFormValue);
  },

  // getting the column value - kind of getter for column value.
  getColumn: (field) => {
    const { CommonDS, selectedIndex } = get();
    return CommonDS.getColumn('formValue.list', selectedIndex, field);
  },

  // setting the column value - kind of setter for column value : need to pass value additionally to change it.
  setColumn: (field: string, value: any) => {
    const { CommonDS, selectedIndex } = get();
    return CommonDS.setColumn('formValue.list', selectedIndex, field, value);
  },

  // 공사장소 저장
  saveLocationRegister: async () => {
    try {
      const { validate, getApiParam, formApiPath, cancel } = get();
      const isValid = await validate();

      if (isValid) {
        ModalService.confirm({
          body: '공사장소를 저장하시겠습니까?',
          ok: async () => {
            const apiParam = getApiParam();
            console.log('요청데이터 확인 : ', `apiParam : ${JSON.stringify(apiParam)}`); // 요청 데이터 확인

            // 모든 항목의 _status확인하기
            const allStatus = apiParam.list.map((item) => item._status);
            console.log('모든 항목의 _status: ', allStatus);

            const addParams = [];
            const updateParams = [];

            // status에 따라 나눠서 처리하기
            apiParam.list.forEach((item) => {
              if (item._status === 'A') {
                addParams.push(item);
                console.log('addParams : ', addParams);
              } else if (item._status === 'U') {
                updateParams.push(item);
                console.log('updateParams : ', updateParams);
              }
            });

            if (addParams.length > 0) {
              const response = await ApiService.post(`${formApiPath}/add`, addParams);
              console.log('Add Response : ', response);
            }

            if (updateParams.length > 0) {
              const response = await ApiService.put(`${formApiPath}/update`, updateParams);
              console.log('Update Response : ', response);
            }

            await set({ isDirty: false });
            ToastService.success('저장되었습니다.');
            await cancel();
          },
        });
      }
    } catch (error) {
      console.error('Error in saveLocationRegister:', error);
    }
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuWorkPermitLocationRegisterModalStore;
