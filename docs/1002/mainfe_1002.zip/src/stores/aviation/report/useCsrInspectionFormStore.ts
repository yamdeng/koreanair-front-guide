import { FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import ApiService from '@/services/ApiService';
import ToastService from '@/services/ToastService';
import { formBaseState } from '@/stores/slice/formSlice';
import { produce } from 'immer';
import _ from 'lodash';
import * as yup from 'yup';
import { create } from 'zustand';
import { flighBaseValue } from './reportFormBaseValue';
import {
  csrFlightYupSchema,
  csrInvolveCrewListYupSchema,
  csrInvolveCustomerListYupSchema,
  csrLocationListYupSchema,
} from './reportFormYupSchema';
import { createCsrReportEditForm, createReportEditForm } from './useEditFormStore';

/* yup validation */
const yupFormSchema = yup.object().shape({
  flight: csrFlightYupSchema,
  flightCrew: yup.array(),
  event: yup.object().shape({
    occurPlaceNm: yup.string(),
    occurAirportCd: yup.string(),
    occurDttm: yup.string(),
    occurTimezoneCd: yup.string(),
    safetyInspectionTypeCd: yup.string(),
    checkAuthorityBaseCd: yup.string(),
    findingCd: yup.string(),
    inspectorNm: yup.string(),
    checkAuthorityCd: yup.string(),
    subjectNm: yup.string().required(),
    descriptionTxtcn: yup.string().required(),
  }),
  locationList: csrLocationListYupSchema,
  involveCustomerList: csrInvolveCustomerListYupSchema,
  involveCrewList: csrInvolveCrewListYupSchema,
});

const initFormValue = {
  hiddenFindPlaceCd: '',
  hiddenFindSeatCd: '',
  flight: { ...flighBaseValue },
  flightCrew: [],
  event: {
    occurPlaceNm: '',
    occurAirportCd: '',
    occurDttm: '',
    occurTimezoneCd: 'utc',
    safetyInspectionTypeCd: '',
    checkAuthorityBaseCd: '',
    findingCd: '',
    inspectorNm: '',
    checkAuthorityCd: '',
    subjectNm: '',
    descriptionTxtcn: '',
    fileGroupSeq: null,
  },
  locationList: [],
  involveCustomerList: [],
  involveCrewList: [],
};

/* form 초기화 */
const initFormData = {
  formName: 'csrForm',
  ...formBaseState,
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useCsrInspectionFormStore = create<any>((set, get) => ({
  ...createReportEditForm(set, get),
  ...createCsrReportEditForm(set),

  initFormValue: _.cloneDeep(initFormValue),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  editFormPath: '/aviation/report-form/CSR/inspection',

  // 점검종류 radio 수정
  changeCheckKindRadio: (value) => {
    const { changeInput } = get();
    if (!value || value !== '100001202') {
      changeInput('locationList', []);
    }
    changeInput('event.safetyInspectionTypeCd', value);
  },

  // 은닉물 추가
  addLocationList: () => {
    const { formValue } = get();
    const { hiddenFindPlaceCd, hiddenFindSeatCd, locationList } = formValue;
    const existInfo = locationList.find((locationInfo) => {
      return locationInfo.hiddenFindPlaceCd === hiddenFindPlaceCd && locationInfo.hiddenFindSeatCd === hiddenFindSeatCd;
    });
    if (!hiddenFindPlaceCd || !hiddenFindSeatCd) {
      ToastService.warn('은닉물 발견 장소를 추가시 장소와 클래스를 선택해야 합니다.');
      return;
    }
    if (existInfo) {
      ToastService.warn('이미지 추가한 은닉물 정보입니다.');
    } else {
      set(
        produce((state: any) => {
          state.formValue.locationList.push({
            hiddenFindPlaceCd: hiddenFindPlaceCd,
            hiddenFindSeatCd: hiddenFindSeatCd,
          });
        })
      );
    }
  },

  // 은닉물 삭제
  deleteLocationList: (removeIndex) => {
    set(
      produce((state: any) => {
        state.formValue.locationList.splice(removeIndex, 1);
      })
    );
  },

  getDetail: async (id) => {
    const response: any = await ApiService.get(`avn/report/my-reports/${id}`);
    const detailInfo = response.data;
    const { report, reportCsr, flight, flightCrew, reportDtl } = detailInfo;

    // 'report' api에서 event 정보 추출
    const applyEvent = _.pick(report, [
      'occurPlaceNm',
      'occurAirportCd',
      'occurDttm',
      'occurTimezoneCd',
      'subjectNm',
      'descriptionTxtcn',
      'fileGroupSeq',
    ]);

    // 'reportCsr' api에서 event 정보 추출
    const applyEvent2 = _.pick(reportCsr, [
      'safetyInspectionTypeCd',
      'checkAuthorityBaseCd',
      'findingCd',
      'inspectorNm',
      'checkAuthorityCd',
    ]);

    let locationList = [];
    let involveCustomerList = [];
    let involveCrewList = [];

    if (reportDtl && reportDtl.length) {
      locationList = reportDtl.filter((info) => info.reportDtlInfoTypeCd === 'CSR_03');
      involveCustomerList = reportDtl.filter((info) => info.reportDtlInfoTypeCd === 'CSR_01');
      involveCrewList = reportDtl.filter((info) => info.reportDtlInfoTypeCd === 'CSR_02');
    }

    const applyFormValue = {
      flight: flight,
      flightCrew: flightCrew.map((info) => {
        info.tagName = info.crewTypeCd;
        return info;
      }),
      event: { ...applyEvent, ...applyEvent2 },
      locationList: locationList,
      involveCustomerList: involveCustomerList,
      involveCrewList: involveCrewList,
    };
    set({
      detailInfo: detailInfo,
      formValue: applyFormValue,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  getApiParam: () => {
    const { formValue, formDetailId, detailInfo, reportTypeCd } = get();
    const { flight, flightCrew, event, locationList, involveCustomerList, involveCrewList } = formValue;
    const { report, reportCsr } = detailInfo || {};

    // 'report'
    const serverReportParam = {
      ...report,
      reportId: formDetailId ? formDetailId : null,
      reportTypeCd: reportTypeCd,
      ...event,
    };

    const serveReportDetailListParam = [];
    locationList.forEach((locationInfo) => {
      serveReportDetailListParam.push({ ...locationInfo, reportDtlInfoTypeCd: 'CSR_03' });
    });

    involveCustomerList.forEach((customerInfo) => {
      serveReportDetailListParam.push({ ...customerInfo, reportDtlInfoTypeCd: 'CSR_01' });
    });

    involveCrewList.forEach((crewInfo) => {
      serveReportDetailListParam.push({ ...crewInfo, reportDtlInfoTypeCd: 'CSR_02' });
    });

    // 'reportCsr'
    const serverCsrReportParam = {
      reportId: formDetailId ? formDetailId : null,
      reportDtlTypeCd: 'CSR_03',
      ...reportCsr,
      safetyInspectionTypeCd: event.safetyInspectionTypeCd,
      checkAuthorityBaseCd: event.checkAuthorityBaseCd,
      findingCd: event.findingCd,
      inspectorNm: event.inspectorNm,
      checkAuthorityCd: event.checkAuthorityCd,
    };
    // 최종 적용
    const reportApiParam = {
      flight: { ...flight, reportId: formDetailId ? formDetailId : null },
      flightCrew: flightCrew.map((info) => {
        const flightServerInfo = {
          crewTypeCd: info.tagName,
          empNo: info.empNo,
        };
        return flightServerInfo;
      }),
      report: serverReportParam,
      reportCsr: serverCsrReportParam,
      reportDtl: serveReportDetailListParam,
    };
    return reportApiParam;
  },
}));

export default useCsrInspectionFormStore;
