import * as yup from 'yup';

// asr 비행정보
export const asrFlightYupSchema = yup.object().shape({
  departureDt: yup.string().required(),
  flightNo: yup.string().required(),
  regNo: yup.string().required(),
  aircraftTypeCd: yup.string().required(),
  departureAirportCd: yup.string().required(),
  arrivalAirportCd: yup.string().required(),
  divertAirportCd: yup.string(),
  stdTime: yup.string(),
  staTime: yup.string(),
  atdTime: yup.string(),
  ataTime: yup.string(),
  delayedMinCo: yup.number().nullable(),
  supplyNm: yup.string(),
  checkinNm: yup.string(),
});

// csr 비행정보
export const csrFlightYupSchema = yup.object().shape({
  departureDt: yup.string().required(),
  flightNo: yup.string().required(),
  regNo: yup.string().required(),
  aircraftTypeCd: yup.string().required(),
  departureAirportCd: yup.string().required(),
  arrivalAirportCd: yup.string().required(),
  divertAirportCd: yup.string(),
  stdTime: yup.string(),
  staTime: yup.string(),
  atdTime: yup.string(),
  ataTime: yup.string(),
  delayedMinCo: yup.number().nullable(),
  supplyNm: yup.string().required(),
  checkinNm: yup.string(),
});

// csr 관련자 세부 정보 : 탑승객
export const csrInvolveCustomerListYupSchema = yup.array().of(
  yup.object().shape({
    involveCd: yup.string(),
    paxNm: yup.string(),
    genderCd: yup.string(),
    ageCo: yup.number().nullable(),
    nationNm: yup.string(),
    seatNm: yup.string(),
  })
);

// csr 관련자 세부 정보 : 승무원
export const csrInvolveCrewListYupSchema = yup.array().of(
  yup.object().shape({
    involveCd: yup.string(),
    empNo: yup.string(),
  })
);

// csr 은닉물 세부정보
export const csrLocationListYupSchema = yup.array().of(
  yup.object().shape({
    hiddenFindPlaceCd: yup.string(),
    hiddenFindSeatCd: yup.string(),
  })
);
