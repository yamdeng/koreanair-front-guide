import { FORM_TYPE_ADD } from '@/config/CommonConstant';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import CommonUtil from '@/utils/CommonUtil';
import history from '@/utils/history';
import { produce } from 'immer';
import useAppStore from '@/stores/useAppStore';
import { REPORT_TYPE_CSR } from '@/config/ReportFormConstant';

/* zustand store 생성 */
export const createReportEditForm = (set, get) => ({
  ...createFormSliceYup(set, get),

  // form 기준 path를 각 페이지마다 전달
  editFormPath: '',

  // 승무원 목록의 유형
  userSelectKind: 'PF',

  searchFligh: async () => {
    const { formValue } = get();
    const { flight } = formValue;
    const { flightNo } = flight;
    if (!flightNo) {
      ToastService.warn('비행편명을 입력해주세요.');
      return;
    }

    const apiResult = await ApiService.get('com/flight', { departureDate: '', fltNo: flightNo });
    const data = apiResult.data || [];
    const searchInfo = data.length ? data[0] : null;

    if (searchInfo) {
      set(
        produce((state: any) => {
          const flight = state.formValue.flight;
          flight.regNo = searchInfo.registrationNo;
          flight.aircraftTypeCd = searchInfo.aircraftType;
          flight.departureAirportCd = searchInfo.to;
          flight.arrivalAirportCd = searchInfo.from;
          flight.supplyNm = searchInfo.supply;
          flight.checkinNm = searchInfo.checkIn;
          flight.stdTime = CommonUtil.getTimeStringByDateFullString(searchInfo.std);
          flight.staTime = CommonUtil.getTimeStringByDateFullString(searchInfo.sta);
          flight.atdTime = CommonUtil.getTimeStringByDateFullString(searchInfo.atd);
          flight.ataTime = CommonUtil.getTimeStringByDateFullString(searchInfo.ata);
          flight.stdLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.stdLocTime);
          flight.staLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.staLocTime);
          flight.atdLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.atdLocTime);
          flight.ataLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.ataLocTime);
          flight.delayedMinCo = searchInfo.delay;
        })
      );
    } else {
      ToastService.warn('비행정보가 존재하지 않습니다.');
    }
  },

  // 비행승무원 선택
  onSelectFlightCrewList: (selectedValue) => {
    const { userSelectKind } = get();
    set(
      produce((state: any) => {
        const flightCrewList = state.formValue.flightCrew;
        if (!flightCrewList.find((info) => info.empNo === selectedValue.empNo)) {
          flightCrewList.push({ ...selectedValue, tagName: userSelectKind });
        }
      })
    );
  },

  // 비행승무원 삭제
  deleteFlightCrewList: (removeIndex) => {
    set(
      produce((state: any) => {
        state.formValue.flightCrew.splice(removeIndex, 1);
      })
    );
  },

  // 임시저장
  tempSave: async () => {
    const { getApiParam, formType, formDetailId, editFormPath } = get();
    const apiParam = getApiParam();
    let createId = null;
    if (formType === FORM_TYPE_ADD) {
      const createData: any = await ApiService.post(`avn/report/reportInsert`, apiParam);
      createId = createData.ItemCount;
    } else {
      await ApiService.put(`avn/report/reportUpdate/${formDetailId}`, apiParam);
    }
    await set({ isDirty: false });
    if (formType === FORM_TYPE_ADD) {
      // 등록시 받은 reportId 기준으로 정보를 다시 셋팅하기
      history.replace(`${editFormPath}/${createId}`);
    }
    ToastService.success('저장되었습니다.');
  },

  // 제출
  save: async () => {
    const { validate, getApiParam, formType, editFormPath } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          let createId = null;
          const createData: any = await ApiService.post(`avn/report/submitReport`, apiParam);
          if (formType === FORM_TYPE_ADD) {
            createId = createData.ItemCount;
          }
          await set({ isDirty: false });
          if (formType === FORM_TYPE_ADD) {
            // 등록시 받은 reportId 기준으로 정보를 다시 셋팅하기
            history.replace(`${editFormPath}/${createId}`);
          }
          ToastService.success('제출되었습니다.');
        },
      });
    }
  },

  // 아코디언 펼치고 닫기
  toggleAccordionExpanded: (accordionExapndedName) => {
    const state = get();
    const expaned = !state[accordionExapndedName];
    set({ [accordionExapndedName]: expaned });
  },

  // clear 공통 로직
  clear: () => {
    const initFlightCrew = [];
    const { profile } = useAppStore.getState();
    const { initFormValue } = get();
    if (profile) {
      initFlightCrew.push({ ...profile.userInfo, tagName: 'PF' });
    }
    set({
      ...formBaseState,
      formValue: {
        ...initFormValue,
        flightCrew: initFlightCrew,
      },
    });
  },
});

// CSR form 공통 로직
export const createCsrReportEditForm = (set) => ({
  reportTypeCd: REPORT_TYPE_CSR,
  filghtExpanded: true,
  eventExpanded: false,
  involveExpaned: false,
  eventContentExpanded: false,

  // 관련탑승객 추가
  addInvolveCustomerList: () => {
    set(
      produce((state: any) => {
        state.formValue.involveCustomerList.push({
          involveCd: '',
          paxNm: '',
          genderCd: '',
          ageCo: null,
          nationNm: '',
          seatNm: '',
        });
      })
    );
  },

  // 관련승무원 추가
  addInvolveCrewList: () => {
    set(
      produce((state: any) => {
        state.formValue.involveCrewList.push({
          involveCd: '',
          paxNm: '',
          genderCd: '',
          ageCo: null,
          nationNm: '',
          seatNm: '',
        });
      })
    );
  },

  // 관련탑승객 삭제
  deleteInvolveCustomerList: (removeIndex) => {
    set(
      produce((state: any) => {
        state.formValue.involveCustomerList.splice(removeIndex, 1);
      })
    );
  },

  // 관련탑승객 삭제
  deleteInvolveCrewList: (removeIndex) => {
    set(
      produce((state: any) => {
        state.formValue.involveCrewList.splice(removeIndex, 1);
      })
    );
  },
});
