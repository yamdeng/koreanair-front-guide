import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import _ from 'lodash';
import history from '@/utils/history';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { produce } from 'immer';
import ToastService from '@/services/ToastService';

import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';

/* yup validation */
const yupFormSchema = yup.object({
  title: yup.string().required(),
  division: yup.string().required(),
  urlPlan: yup.string().required(),
  // urlResult: yup.string().required(),
  timezone: yup.string(),
  auditAt: yup.string(),
  isRemote: yup.string(),
  airlineCategory: yup.number().required(),
  auditTypeCode: yup.string(),
});

const initFormValue = {
  /* Audit */
  auditId: '',
  auditNo: '',
  title: '',
  division: '',
  urlPlan: '',
  urlResult: '',
  isFinding: '',
  phase: '',
  phaseLevel: '',
  state: '',
  timezone: '',
  auditAt: '',
  isRemote: '',
  airlineCategory: '',
  auditTypeCode: '',
  isSubmmited: '',
  submittedAt: '',
  notes: '',
  approvedBy: '',
  planFileGroupSeq: '',
  resultFileGroupSeq: '',
  preFileGroupSeq: '',
  useYn: '',
  // Checklist 정보
  checklistInfo: [],
  // Auditor 정보
  auditorInfo: [
    { auditorType: 'lead', empNo: '9500890' },
    { auditorType: 'auditor', empNo: '0500673' },
  ],
  // Auditee 정보
  auditeeInfo: {
    auditeeId: '',
    area: '',
    auditeeDivision: '',
    legFromAirport: '',
    legToAirport: '',
    auditeeType: '',
    airport: '',
    companyName: '',
    lineSafetyYn: '',
    departureAt: '',
    flightNo: '',
    fromAirport: '',
    toAirport: '',
    route: '',
    fleet: '',
    registrationSign: '',
    acType: '',
    acVersion: '',
    dutyPurser: '',
    qualification: '',
    rank: '',
    numberSeats: '',
    occupant: '',
  },
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  // menuTreeData: [],
  // parentMenuTreeData: [],
  // selectedMenuInfo: null,

  // formApiPath: 'sys/menus',
  // baseRoutePath: '',
  // formName: 'useSysMenuFormStore',

  // treeWorkScope: 'A',

  formValue: initFormValue,
  // formValue: {
  //   ...initFormValue,
  // },
};

/* zustand store 생성 */
const useMyAuditPlanStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...initFormData,
  yupFormSchema: yupFormSchema,

  dsAuditPlanInfo: [],

  // Audit Plan 정보 세팅
  setAuditPlanInfo: async (auditInfo) => {
    set({ dsAuditPlanInfo: auditInfo });
    const { dsAuditPlanInfo } = get();

    set({ auditId: auditInfo.auditId });
    //alert('PlanStore : ' + dsAuditPlanInfo.auditNo);
  },

  // division select 변경시 해당 부문의 체크리스트 조회
  divisionChecklist: [],
  changeDivision: (division) => {
    // 기존 선택된 체크리스트 초기화
    // const { formValue } = get();
    // const { checklistInfo } = formValue;
    // set({ checklistInfo: '' });

    ApiService.get(`avn/audit/my-audit/1/audit/checklist/${division}`).then((apiResult) => {
      set({ divisionChecklist: apiResult.data || {} });
    });

    // //const apiResult: any = await ApiService[applyListApiMethod](listApiPath, applyApiParam);
    // const apiResult = ApiService.get(`avn/audit/my-audit/1/audit/checklist/${division}`);
    // const data = apiResult.data || [];
    // //const divisionChecklist = data[0];
    // const divisionChecklist = data;
    // //const revisions = checkListInfo.revisions
    // //debugger;
    // set({ divisionChecklist: divisionChecklist });
  },

  // Form

  // 기본 formValue input 속성 변경 : master form
  // changeInput: (inputName, inputValue) => {
  //   setFormValue((formValue) => {
  //     formValue[inputName] = inputValue;
  //   });
  // };

  //비행편명 검색
  searchFligh: async () => {
    const { formValue } = get();
    // const { flight } = formValue;
    // const { flightNo } = flight;
    const { flightNo } = formValue.auditeeInfo;
    if (!flightNo) {
      ToastService.warn('비행편명을 입력해주세요.');
      return;
    }

    const apiResult = await ApiService.get('com/flight', { departureDate: '', fltNo: flightNo });
    const data = apiResult.data || [];
    const searchInfo = data.length ? data[0] : null;

    if (searchInfo) {
      set(
        produce((state: any) => {
          //const flight = state.formValue.flight; //비행정보
          // flight.registrationNo = searchInfo.registrationNo; //등록기호
          // flight.aircraftTypeText = searchInfo.aircraftType; //항공기 형식
          // flight.toAirport = searchInfo.to; //도착공항
          // flight.fromAirport = searchInfo.from; //출발공항
          // flight.divertAirport = searchInfo.from; //회항공항
          // flight.supply = searchInfo.supply; //좌석수
          // flight.checkIn = searchInfo.checkIn; //탑승자

          state.formValue.auditeeInfo.fromAirport = searchInfo.from; //출발공항
          state.formValue.auditeeInfo.toAirport = searchInfo.to; //도착공항
          state.formValue.auditeeInfo.registrationSign = searchInfo.registrationNo; //등록기호
          state.formValue.auditeeInfo.acType = searchInfo.aircraftType; //항공기 형식
          state.formValue.auditeeInfo.acVersion = '??';

          // flight.supply = searchInfo.supply; //좌석수
          // flight.checkIn = searchInfo.checkIn; //탑승자
          state.formValue.auditeeInfo.qualification = '??'; //qualification
          state.formValue.auditeeInfo.rank = '??'; //rank
          state.formValue.auditeeInfo.numberSeats = searchInfo.supply; //좌석수
          state.formValue.auditeeInfo.occupant = searchInfo.checkIn; //탑승자
        })
      );
    } else {
      ToastService.warn('비행정보가 존재하지 않습니다.');
    }
  },

  deleteAudit: () => {
    alert('삭제 작업중입니다. (미저장시 보이지않도록 처리)');
  },

  // Audit 저장
  saveAudit: async (saveGubun) => {
    const { formValue } = get();

    // Checklist 배열형태로 변환
    const objectChecklist = { ...formValue.checklistInfo };
    const newChecklist = [];
    Object.values(objectChecklist).map((value) => {
      newChecklist.push({ checklistId: value });
    });
    formValue.checklistInfo = newChecklist;

    // 단계설정 : PLAN or CONDUCT
    formValue.phase = saveGubun;

    const apiParam = {
      ...formValue,
    };

    await ApiService.post('avn/audit/my-audit/1/plan', apiParam).then((apiResult) => {
      //const returnAuditId = apiResult.data;
      const returnAuditId = apiResult.ItemCount;
      //if (returnAuditId) {
      //  ToastService.error(returnAuditId);
      //} else {
      ToastService.success('Audit 정보가 저장되었습니다.');
      if (saveGubun === 'CONDUCT') {
        // Audit 재설정
        const { getAuditInfo } = useMyAuditFrameStore.getState();
        getAuditInfo(returnAuditId);
      }
      //}
    });
  },
}));

export default useMyAuditPlanStore;
