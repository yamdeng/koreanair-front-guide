import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import _ from 'lodash';
import history from '@/utils/history';
import { produce } from 'immer';

/* zustand store 생성 */
const useMyAuditConductStore = create<any>((set, get) => ({
  dsAuditConductInfo: [], // Audit 정보
  dsAuditChecklistList: [], // Checklist 정보
  dsAuditChapterList: [], // Chapter 정보
  dsAuditQuestionList: [], // Question 정보
  currentChecklistId: '',
  currentChecklistIndex: 0,
  currentChapterTabIndex: 0,

  // Conduct 단계 정보 설정
  setAuditConductInfo: async (auditInfo) => {
    set({ dsAuditConductInfo: auditInfo });
    const {
      dsAuditConductInfo,
      // dsAuditChapterList,
      // dsAuditQuestionList,
      currentChecklistIndex,
      currentChapterTabIndex,
    } = get();

    // 체크리스트, 챕터, 문항 정보 조회
    ApiService.get(`avn/audit/my-audit/2/conduct/checklist/${dsAuditConductInfo.auditId}`).then((apiResult) => {
      const checklistInfo = apiResult.data || {};
      set({
        dsAuditChecklistList: checklistInfo,
        currentChecklistId: checklistInfo[currentChecklistIndex].checklistId,
        dsAuditChapterList: checklistInfo[currentChecklistIndex].chapterInfo,
        dsAuditQuestionList: checklistInfo[currentChecklistIndex].chapterInfo[currentChapterTabIndex].questionInfo,
      });
    });
  },

  // checklist 선택시 해당 chapter 조회
  changeChecklistIndex: (checklistIndex) => {
    set({ currentChecklistIndex: checklistIndex });
    const { dsAuditChecklistList, currentChecklistIndex } = get();

    set({
      dsAuditChapterList: dsAuditChecklistList[currentChecklistIndex].chapterInfo,
    });
  },

  // chapter Tab 선택시 해당 문항 조회
  changeChapterTabIndex: (chapterTabIndex) => {
    set({ currentChapterTabIndex: chapterTabIndex });
    const { dsAuditChapterList, currentChapterTabIndex } = get();

    set({
      dsAuditQuestionList: dsAuditChapterList[currentChapterTabIndex].questionInfo,
    });
  },

  // 문항 수정시
  changeQuestionList: async (listLindex, keyName, value) => {
    // set(
    //   produce((state: any) => {
    //     // const questionInfo = state.dsAuditQuestionList[listLindex];
    //     // questionInfo[keyName] = value;
    //     // questionInfo.updated = true;
    //     // state.questionUpdateList.push(state.dsAuditQuestionList[listLindex]);
    //     const questionInfo = state.dsAuditQuestionList[listLindex];
    //     questionInfo[keyName] = value;
    //     questionInfo.updated = true;
    //   })
    // );
  },
}));

export default useMyAuditConductStore;
