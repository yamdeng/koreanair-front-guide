import ApiService from '@/services/ApiService';
import { create } from 'zustand';
// import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
// import _ from 'lodash';
// import history from '@/utils/history';

import useMyAuditPlanStore from '@/stores/aviation/audit/myAudit/useMyAuditPlanStore';
import useMyAuditConductStore from '@/stores/aviation/audit/myAudit/useMyAuditConductStore';
import useMyAuditCarStore from '@/stores/aviation/audit/myAudit/useMyAuditCarStore';
import useMyAuditCloseStore from '@/stores/aviation/audit/myAudit/useMyAuditCloseStore';

/* zustand store 생성 */
const useMyAuditFrameStore = create<any>((set, get) => ({
  hidePlan: 'hide',
  hideConduct: 'hide',
  hideCar: 'hide',
  hideClose: 'hide',
  isOpenPhase: false,

  // Audit 단계 설정
  setAuditPhase: (phase) => {
    const { hidePlan, hideConduct, hideCar, hideClose, isOpenPhase } = get();

    if (phase === 'PLAN') {
      set({ hidePlan: hidePlan === 'hide' ? '' : 'hide' });
      set({ isOpenPhase: hidePlan === 'hide' ? false : true });
    }

    if (phase === 'CONDUCT') {
      set({ hideConduct: hideConduct === 'hide' ? '' : 'hide' });
      set({ isOpenPhase: hideConduct === 'hide' ? false : true });
    }

    if (phase === 'CAR') {
      set({ hideCar: hideCar === 'hide' ? '' : 'hide' });
      set({ isOpenPhase: hideCar === 'hide' ? false : true });
    }

    if (phase === 'CLOSE') {
      set({ hideClose: hideClose === 'hide' ? '' : 'hide' });
      set({ isOpenPhase: hideClose === 'hide' ? false : true });
    }

    //const element = document.getElementById('planArea');
    //element.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'nearest' });
    if (isOpenPhase) {
      //const element = document.getElementById(`area-${phase}`);
      //element.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
    }
  },

  // Audit 정보 조회 (Plan,Auditor,Auditee)
  dsAuditInfo: [],

  getAuditInfo: (auditId) => {
    ApiService.get(`avn/audit/my-audit/1/audit/${auditId}`).then((apiResult) => {
      const auditInfo = apiResult.data || {};
      set({ dsAuditInfo: auditInfo });

      // 현재 단계 view
      set({ hidePlan: 'hide', hideConduct: 'hide', hideCar: 'hide', hideClose: 'hide' });

      const { setAuditPhase } = get();
      setAuditPhase(auditInfo.phase);

      // Plan Store에 Plan 정보 주입
      const { dsAuditInfo } = get();
      const { setAuditPlanInfo } = useMyAuditPlanStore.getState();
      setAuditPlanInfo(dsAuditInfo);

      // Conduct Store
      if (auditInfo.phaseLevel > 1) {
        const { dsAuditInfo } = get();
        const { setAuditConductInfo } = useMyAuditConductStore.getState();
        setAuditConductInfo(dsAuditInfo);
      }

      // CAR Store
      if (auditInfo.phaseLevel > 2) {
        const { dsAuditInfo } = get();
        const { setAuditCarInfo } = useMyAuditCarStore.getState();
        setAuditCarInfo(dsAuditInfo);
      }

      // Close Store
      if (auditInfo.phaseLevel > 3) {
        const { dsAuditInfo } = get();
        const { setAuditCloseInfo } = useMyAuditCloseStore.getState();
        setAuditCloseInfo(dsAuditInfo);
      }
    });
  },
}));

export default useMyAuditFrameStore;
