package com.koreanair.ksms.batch.job;

import lombok.extern.slf4j.Slf4j;

/**
 * 전체 리포트 중 동일 이벤트에 대해서 자동 링크 기능 처리(Centralized Report) Batch Job
 */
@Slf4j
//@Configuration
public class KsmsBatchJob011Configuration {

    public static final String JOB_NAME = "ksmsBatchJob011";
    public static final String STEP_NAME = "ksmsBatchStep011";
}
