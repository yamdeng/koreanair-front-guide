package com.koreanair.ksms.batch.mapper;

import com.koreanair.ksms.batch.dto.IfKeUserDto;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface KsmsBatchJob001Mapper {

    void deleteTempTable();

    void insertIfKeUser(IfKeUserDto dto);

    void callSPIfUser();
}
