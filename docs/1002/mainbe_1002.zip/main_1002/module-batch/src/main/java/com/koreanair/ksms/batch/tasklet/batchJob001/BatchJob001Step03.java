package com.koreanair.ksms.batch.tasklet.batchJob001;

import com.koreanair.ksms.batch.base.tasklet.BaseTasklet;
import com.koreanair.ksms.batch.service.KsmsBatchJob001Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@StepScope
public class BatchJob001Step03 extends BaseTasklet {

    @Autowired
    KsmsBatchJob001Service service;

    /**
     * 프로시저를 호출하여 데이터 병합
     *
     * @param stepContribution
     * @param chunkContext
     * @return
     */
    @Override
    public RepeatStatus run(StepContribution stepContribution, ChunkContext chunkContext) {
        
        log.info("KsmsBatchJob001 - STEP 3 실행 ==================================");

        service.callSpIfUser();
        log.info("마이그레이션 프로시저: done");

        return RepeatStatus.FINISHED;
    }

}
