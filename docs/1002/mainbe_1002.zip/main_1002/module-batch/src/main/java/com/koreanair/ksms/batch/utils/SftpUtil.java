package com.koreanair.ksms.batch.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class SftpUtil {

    private Session session = null;
    private Channel channel = null;
    private ChannelSftp channelSftp = null;

    /**
     * 서버와 연결에 필요한 값들을 가져와 초기화 시킴
     *
     * @param host 서버 주소
     * @param userName 접속에 사용될 아이디
     * @param password 비밀번호
     * @param port 포트번호
     */
    public void init(String host, String userName, String password, int port) {
        JSch jsch = new JSch();
        try {
            session = jsch.getSession(userName, host, port);
            session.setPassword(password);

            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();
        } catch (JSchException e) {
            throw new RuntimeException(e);
        }

        channelSftp = (ChannelSftp) channel;
    }

    /**
     * 가장 최근에 생성된 파일명 가져오기
     *
     * @param dir
     * @return
     */
    public String getNewFileName(String dir) {

        String fileName = "";
        int fileTime = 0;

        try {
            Vector fileList = channelSftp.ls(dir);

            for(int i=0; i<fileList.size(); i++) {
                LsEntry file = (LsEntry) fileList.get(i);

                if(file.getFilename().startsWith(".") || file.getAttrs().isDir()) {
                    continue;
                } else {
                    if (fileTime < file.getAttrs().getMTime()) {
                        fileTime = file.getAttrs().getMTime();
                        fileName = file.getFilename();
                    }
                }
            }
        } catch (SftpException e) {
            throw new RuntimeException(e);
        }

        return fileName;
    }

    /**
     * 하나의 파일을 다운로드 한다.
     *
     * @param dir 저장할 경로(서버)
     * @param downloadFileName 다운로드할 파일
     * @param path 저장될 공간
     */
    public void download(String dir, String downloadFileName, String path) {
        InputStream in = null;
        FileOutputStream out = null;
        try {
            channelSftp.cd(dir);
            in = channelSftp.get(downloadFileName);
        } catch (SftpException e) {
            e.printStackTrace();
        }

        try {
            out = new FileOutputStream(new File(path));
            int i;

            while ((i = in.read()) != -1) {
                out.write(i);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                out.close();
                in.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
    }
    
    /**
     * 서버와의 연결을 끊는다.
     */
    public void disconnection() {
        channelSftp.quit();
    }
}
