package com.koreanair.ksms.batch.job;

import com.koreanair.ksms.batch.base.listener.BaseChunkLogger;
import com.koreanair.ksms.batch.base.listener.BaseJobLogger;
import com.koreanair.ksms.batch.base.listener.BaseStepLogger;
import com.koreanair.ksms.batch.dto.IfKeUserDto;
import com.koreanair.ksms.batch.mapper.UserFieldSetMapper;
import com.koreanair.ksms.batch.tasklet.batchJob001.BatchJob001Step01;
import com.koreanair.ksms.batch.tasklet.batchJob001.BatchJob001Step03;
import com.koreanair.ksms.batch.tasklet.batchJob001.BatchJob001Step04;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.batch.MyBatisBatchItemWriter;
import org.mybatis.spring.batch.builder.MyBatisBatchItemWriterBuilder;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * =====================================================================================
 * 인사정보 I/F Batch Job
 * =====================================================================================
 * STEP 1: sftp접속하여 csv파일 다운로드 및 임시테이블 데이터 삭제
 * STEP 2: csv파일 Chunk 처리.
 *       - ChunkReader: csv파일에서 read
 *       - ChunkProcesser: 이메일 암호화
 *       - ChunkWriter: csv데이터를 DB테이블에 저장
 * STEP 3: 프로시저를 호출하여 데이터 병합
 * STEP 4: 다운로드 받은 csv파일 삭제
 */
@Slf4j
@Configuration
public class KsmsBatchJob001Configuration {

    public static final String JOB_NAME = "ksmsBatchJob001";
    private final int chunkSize = 1000;
    private final SqlSessionFactory sqlSessionFactory;

    private final BatchJob001Step01 tasklet01;
    private final BatchJob001Step03 tasklet03;
    private final BatchJob001Step04 tasklet04;

    @Value("${filepath.csv}")
    private String csvFileName;

    public KsmsBatchJob001Configuration(SqlSessionFactory sqlSessionFactory, BatchJob001Step01 tasklet01, BatchJob001Step03 tasklet03, BatchJob001Step04 tasklet04) {
        this.sqlSessionFactory = sqlSessionFactory;
        this.tasklet01 = tasklet01;
        this.tasklet03 = tasklet03;
        this.tasklet04 = tasklet04;
    }

    @Bean(JOB_NAME)
    public Job ksmsBatchJob001 (JobRepository jobRepository, Step ksmsBatchStep001, Step ksmsBatchStep002, Step ksmsBatchStep003, Step ksmsBatchStep004) {

        return new JobBuilder(JOB_NAME, jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(ksmsBatchStep001)
                .next(ksmsBatchStep002)
                .next(ksmsBatchStep003)
                .next(ksmsBatchStep004)
                .listener(new BaseJobLogger())
                .build();
    }

    /**
     * STEP 1: sftp접속하여 csv파일 다운로드
     */
    @Bean("ksmsBatchStep001")
    public Step ksmsBatchStep001(JobRepository jobRepository, PlatformTransactionManager transactionManager) {

        return new StepBuilder("ksmsBatchStep001", jobRepository)
                .tasklet(tasklet01, transactionManager)
                .listener(new BaseStepLogger())
                .build();
    }

    /**
     * STEP 2: csv파일 처리.
     */
    @Bean("ksmsBatchStep002")
    public Step ksmsBatchStep002(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        log.info("KsmsBatchJob001 - STEP 2 실행 ==================================");

        return new StepBuilder("ksmsBatchStep002", jobRepository)
                .<IfKeUserDto, IfKeUserDto> chunk(chunkSize, transactionManager)
                .reader(step02ChunkReader())
                .processor(step02ChunkProcesser())
                .writer(step02ChunkWriter())
                .listener(new BaseStepLogger())
                .listener(new BaseChunkLogger())
                .build();
    }

    /**
     * Chunk Reader
     */
    @Bean
    public FlatFileItemReader<IfKeUserDto> step02ChunkReader() {

        // CSV delimiter 설정
        DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
        tokenizer.setDelimiter("^");

        return new FlatFileItemReaderBuilder<IfKeUserDto>()
                .name("step02ChunkReader")
                .resource(new FileSystemResource(csvFileName))
                .lineTokenizer(new DelimitedLineTokenizer())
                .linesToSkip(1)
                .lineTokenizer(tokenizer)
                .fieldSetMapper(new UserFieldSetMapper())
                .build();
    }

    /**
     * Chunk Processer
     */
    @Bean
    public ItemProcessor<IfKeUserDto, IfKeUserDto> step02ChunkProcesser() {

        return dto -> {
            // TODO [sixone] 이메일 암호화
            dto.setEmailWork("TODO: encrypted email");
            return dto;
        };
    }

    /**
     * Chunk Writer
     */
    @Bean
    public MyBatisBatchItemWriter<IfKeUserDto> step02ChunkWriter() {

        return new MyBatisBatchItemWriterBuilder<IfKeUserDto>()
                .sqlSessionFactory(sqlSessionFactory)
                .statementId("com.koreanair.ksms.batch.mapper.KsmsBatchJob001Mapper.insertIfKeUser")
                .build();
    }
    /* 로그출력 테스트
    @Bean
    public ItemWriter<IfKeUserDto> step02ChunkWriter() {

        return list -> {
            for(IfKeUserDto dto: list) {
                log.info("User: {}", dto);
            }
        };
    }
    */

    /**
     * STEP 3: 프로시저를 호출하여 데이터 병합
     */
    @Bean("ksmsBatchStep003")
    public Step ksmsBatchStep003(JobRepository jobRepository, PlatformTransactionManager transactionManager) {

        return new StepBuilder("ksmsBatchStep003", jobRepository)
                .tasklet(tasklet03, transactionManager)
                .listener(new BaseStepLogger())
                .build();
    }

    /**
     * STEP 4: 다운로드 받은 csv파일 및 임시테이블 데이터 삭제
     */
    @Bean("ksmsBatchStep004")
    public Step ksmsBatchStep004(JobRepository jobRepository, PlatformTransactionManager transactionManager) {

        return new StepBuilder("ksmsBatchStep004", jobRepository)
                .tasklet(tasklet04, transactionManager)
                .listener(new BaseStepLogger())
                .build();
    }
}
