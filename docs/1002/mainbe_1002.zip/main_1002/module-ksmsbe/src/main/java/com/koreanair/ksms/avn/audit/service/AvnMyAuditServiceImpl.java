package com.koreanair.ksms.avn.audit.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.audit.dto.*;
import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AvnMyAuditServiceImpl extends AbstractBaseService implements AvnMyAuditService {

    // My Audit 현황 조회
    @Override
    public TBMyAuditStatisticsDto selectMyAuditStatistics(Map paramMap) {
        return commonSql.selectOne("AvnMyAudit.selectMyAuditStatistics", paramMap);
    }
        
    // My Audit 목록 조회
    @Override
    public PageInfo<TBMyAuditListDto> selectMyAuditList(Map paramMap) {
        List<TBMyAuditListDto> resultList = commonSql.selectList("AvnMyAudit.selectMyAuditList", paramMap);
        return PageInfo.of(resultList);
    }

    // Audit 정보 조회
    @Override
    public TBAuditDto selectAuditInfo(int auditId) {
        // Audit 상세 조회 (with Auditors,Auditee)
        TBAuditDto auditInfoDto = commonSql.selectOne("AvnMyAuditPlan.selectAuditInfo", auditId);

//        // CONDUCT 단계 이상일때
//        if(auditDto.getPhaseLevel() > 1) {
//            // Checklist 조회 (Chapter, Question 포함)
//            List<TBAuditChecklistDto> checklistDto = commonSql.selectList("AvnMyAudit.selectAuditChecklistInfo", auditId);
//            //List<TBAuditChecklistDto> checklistDto = commonSql.selectList("AvnMyAudit.selectAuditChecklistInfo2", auditId);
//            auditDto.setChecklistInfo(checklistDto);
//        }
//
//        // CAR 단계 이상일때
//        if(auditDto.getPhaseLevel() > 2) {
//            // Finding 조회 (Mitigation, Mitigation User, Root Cause 포함)
//            List<TBAuditFindingDto> findingDto = commonSql.selectList("AvnMyAudit.selectAuditFindingInfo", auditId);
//            auditDto.setFindingInfo(findingDto);
//        }
//
//        // CLOSE 단계일때
//        if(auditDto.getPhaseLevel() > 3) {
//            // Audit 공유현황 조회
//        }

        return auditInfoDto;
    }

    // 부문별 Checklist 정보 조회
    @Override
    public List<TBAuditChecklistDto> selectChecklistByDivision(String division) {
        List<TBAuditChecklistDto> checklistDto = commonSql.selectList("AvnMyAuditPlan.selectChecklistByDivision", division);
        return checklistDto;
    }

    // Audit Plan 저장
    @Override
    @Transactional
    public Integer insertAuditInfo(TBAuditDto tBAuditDto){
        // Audit 정보 저장
        if(tBAuditDto.getAuditId() == 0) {
            commonSql.insert("AvnMyAuditPlan.insertAuditInfo", tBAuditDto);
        }
        else {
            commonSql.update("AvnMyAuditPlan.updateAuditInfo", tBAuditDto);
        }

        // Auditee 정보 저장
        if(tBAuditDto.getAuditeeInfo() != null) {
            commonSql.insert("AvnMyAuditPlan.insertAuditeeInfo", tBAuditDto.getAuditeeInfo());
        }

        // Checklist 정보 저장
        if(tBAuditDto.getChecklistInfo() != null) {
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("auditId", tBAuditDto.getAuditId());
            param.put("auditChecklistList", tBAuditDto.getChecklistInfo());
            commonSql.insert("AvnMyAuditPlan.insertAuditChecklistInfo", param);
        }
        
        // Auditor 정보 저장
        if(tBAuditDto.getAuditorInfo() != null) {
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("auditId", tBAuditDto.getAuditId());
            param.put("auditorList", tBAuditDto.getAuditorInfo());
            commonSql.insert("AvnMyAuditPlan.insertAuditorInfo", param);
        }

        return tBAuditDto.getAuditId();
    }

    // Audit Checklist 정보 조회
    @Override
    public List<TBAuditChecklistDto> selectConductChecklistInfo(int auditId) {
        // Checklist 조회 (Chapter, Question 포함)
        List<TBAuditChecklistDto> checklistDto = commonSql.selectList("AvnMyAuditConduct.selectAuditChecklistInfo", auditId);
        //List<TBAuditChecklistDto> checklistDto = commonSql.selectList("AvnMyAudit.selectAuditChecklistInfo2", auditId);
        //auditDto.setChecklistInfo(checklistDto);
        return checklistDto;
    }
}
