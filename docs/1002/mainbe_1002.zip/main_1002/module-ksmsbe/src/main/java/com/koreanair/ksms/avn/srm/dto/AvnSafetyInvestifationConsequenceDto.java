package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AvnSafetyInvestifationConsequenceDto {

    @Schema(description = "Consequence ID")
    private int consequenceId;

    @Schema(description = "Report Type")
    private String reportTypeCd;

    @Schema(description = "consequence명(KOR)")
    private String consequenceKoNm;

    @Schema(description = "consequence명(ENG)")
    private String consequenceEnNm;

    @Schema(description = "표시 순번")
    private int viewSn;

    @Schema(description = "사용여부")
    private String useYn;

    @Schema(description = "비고")
    private String notesCn;
}
