package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS_강사교육_이수")
public class TbAvnInstructorEducationDto extends CommonDto {
    
    @Schema(description = "교육이수ID")
    @NotBlank
    private String educationId;
    
    @Schema(description = "사원번호")
    @NotBlank
    private String empNo;
    
    @Schema(description = "시작일자")
    private String fromDt;
    
    @Schema(description = "끝일자")
    private String toDt;
    
    @Schema(description = "교육명")
    private String educationNm;
}
