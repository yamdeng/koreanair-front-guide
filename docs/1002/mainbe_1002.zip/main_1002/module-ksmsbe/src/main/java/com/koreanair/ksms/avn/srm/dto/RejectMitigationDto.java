package com.koreanair.ksms.avn.srm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RejectMitigationDto {

    private int totalCnt;

    private int rejectCnt;

    private int groupId;

    private int hazardId;

    private int deptId;

    public boolean compare() {
        return this.totalCnt==this.rejectCnt;
    }
}