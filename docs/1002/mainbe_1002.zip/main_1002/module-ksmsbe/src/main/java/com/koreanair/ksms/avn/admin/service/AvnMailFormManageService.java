package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnMailFormDto;

public interface AvnMailFormManageService {
    // 관리자 > 메일양식관리 목록 조회
    PageInfo<TbAvnMailFormDto> selectMailList(TbAvnMailFormDto tbAvnMailFormDto);

    // 관리자 > 메일양식관리 신규 등록
    void insertMail(TbAvnMailFormDto tbAvnMailFormDto);

    // 관리자 > 메일양식관리 상세
    TbAvnMailFormDto selectMailDetail(String mailCd);

    // 관리자 > 메일양식관리 수정
    void updateMail(TbAvnMailFormDto tbAvnMailFormDto);

    // 관리자 > 메일양식관리 삭제
    void deleteMail(String mailCd);

}
