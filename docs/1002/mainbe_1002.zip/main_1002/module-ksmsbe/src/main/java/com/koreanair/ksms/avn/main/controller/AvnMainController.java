package com.koreanair.ksms.avn.main.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.koreanair.ksms.avn.main.service.AvnMainService;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * 항공안전 메인 Controller
 */
@Tag(name = "AvnMain", description = "항공안전 메인 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn/main")
public class AvnMainController {

    @Autowired
    AvnMainService service;

    /**
     * 메인화면 정보 조회
     *
     * @param 
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "메인화면 정보 조회", description = "메인화면 정보 조회 API")
    @GetMapping(value = "/main-infos")
    public ResponseEntity<?> getMainInfo() {

        String userId = SecurityContextHolder.getContext().getAuthentication().getName();
        List<Map<String, Object>> toDoList = new ArrayList<>();

        Map<String, Object> rtnMap = new HashMap<>();
        rtnMap.put("topRisk", service.getTopRiskList());
        rtnMap.put("reportProcess", service.getReportProcessList(userId));
        rtnMap.put("toDo", toDoList);
        rtnMap.put("banner", service.getBannerList());
        rtnMap.put("notice", service.getNoticeList());
        rtnMap.put("accident", service.getAccidentList());


        // 전체 조회
        return ResponseUtil.createSuccessResponse(rtnMap);
    }
}
