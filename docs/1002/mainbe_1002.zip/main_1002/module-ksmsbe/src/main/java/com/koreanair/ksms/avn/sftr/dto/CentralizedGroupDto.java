package com.koreanair.ksms.avn.sftr.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@Schema(description = "Centralized Group 정보")
public class CentralizedGroupDto extends CommonDto
{
    @Schema(description = "id")
    private int id;

    @Schema(description = "reportId")
    private Integer reportId;

    @Schema(description = "groupNo")
    private String groupNo;

    @Schema(description = "groupId")
    private int groupId;

    @Schema(description = "출발일자")
    private String departureDt;

    @Schema(description = "편명")
    private String flightNo;

    @Schema(description = "기종")
    private String regNo;

    @Schema(description = "레벨")
    private String riskLevel;

    @Schema(description = "레벨색상")
    private String riskLevelColor;

    @Schema(description = "제목")
    private String subjectNm;
    
    @Schema(description = "레포트 리스트")
    private List<CentralizedReportDto> reportList;
}
