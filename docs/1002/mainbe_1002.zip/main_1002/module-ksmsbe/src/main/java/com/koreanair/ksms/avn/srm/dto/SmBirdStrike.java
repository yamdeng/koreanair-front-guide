package com.koreanair.ksms.avn.srm.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Valid
public class SmBirdStrike {

	@NotNull
	private int id;
	
	@NotNull
	private int asrEventId;

	@Length(max = 50)
	private String birdType;

	@Length(max = 50)
	private String birdSize;

	@Length(max = 50)
	private String numberSeen;

	@Length(max = 50)
	private String numberStruck;

	@Length(max = 50)
	private String timeType;
	
	@Length(max = 1)
	private String isLandingLight;
	
	@Length(max = 1)
	private String isPilotWarned;
	
	@Length(max = 100)
	private String impactPoint;
	
	private String descr;
	
}
