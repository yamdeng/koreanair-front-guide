package com.koreanair.ksms.avn.srm.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LscMemberDto {

    private int reportId;

    private String empNo;

    private String memberType;

    private String managerEmpNo;

    public boolean isManager() {
        return  empNo.equals(managerEmpNo);
    }
    public boolean isLeader() {
        return memberType.equals("leader");
    }

}

