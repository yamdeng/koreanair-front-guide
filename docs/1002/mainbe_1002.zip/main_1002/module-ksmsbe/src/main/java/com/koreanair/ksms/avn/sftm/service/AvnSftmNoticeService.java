package com.koreanair.ksms.avn.sftm.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;

public interface AvnSftmNoticeService {

    // 안전증진 > Safety Program > 공지사항 목록
    PageInfo<TbAvnBoardDto> selectBoardList(BoardSearchDto boardSearchDto);

    // 안전증진 > Safety Program > 공지사항 상세
    TbAvnBoardDto selectBoardDetail(int boardId);
}
