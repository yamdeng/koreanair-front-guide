package com.koreanair.ksms.avn.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.koreanair.ksms.avn.admin.service.AvnRiskMatrixService;
import com.koreanair.ksms.common.controller.KsmsCommonController;
import com.koreanair.ksms.common.dto.TbAvnRiskLevelMatrixDto;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * 관리자 - 리스크매트릭스 관리
 */
@Tag(name = "AvnRiskMatrix", description = "관리자 - 리스크매트릭스 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnRiskMatrixController {

    @Autowired
    AvnRiskMatrixService service;

    @Autowired
    KsmsCommonController commService;


    /**
     * 리스크 매트릭스 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "리스크 매트릭스 목록 조회", description = "리스크 매트릭스 목록 조회 API")
    @GetMapping(value = "/admin/risk-matrix")
    public ResponseEntity<?> getRiskMatrixList() {

        List<TbAvnRiskLevelMatrixDto> rtnRiskMatrixList = service.selectRiskMatrixList();

        Map<String, Object> rtnMap = new HashMap<>();
        rtnMap.put("riskMatrix", rtnRiskMatrixList);
        rtnMap.put("riskPbbt", commService.getCodeList("CODE_GRP_172"));
        rtnMap.put("riskSvrt", commService.getCodeList("CODE_GRP_173"));

        // 전체 조회
        return ResponseUtil.createSuccessResponse(rtnMap);
    }

    /**
     * 리스크 매트릭스 목록 수정
     *
     * @param ObjectNode saveObj 
     * @return void
     * @throws Exception the exception
     */
    @Operation(summary = "리스크 매트릭스 목록 수정", description = "리스크 매트릭스 목록 수정 API")
    @PutMapping(value = "/admin/risk-matrix")
    public ResponseEntity<?> updateRiskMatrixList(@RequestBody ObjectNode saveObj) {

        service.updateRiskMatrixList(saveObj);

        // 전체 조회
        return ResponseUtil.createSuccessResponse("OK");
    }

}
