package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.koreanair.ksms.common.dto.CommonDto;
import com.koreanair.ksms.common.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.sql.Timestamp;
import java.util.Objects;

@Setter
@Getter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "보고서 내용")
public class SmReport extends CommonDto {

    @NotNull
    private int id;

    @NotNull
    private int groupId;

    private int reportId;

    private String docNo;

    @NotBlank
    private String reportType;

    private String empNo;

    private String subject;

    private String timeZone;

    private String phase;

    private String reportPhase;

    private String stateType;

    private String reportStateType;

    private String stepCode;

    private Timestamp deletedAt;

    private String isSubmitted;

    private Timestamp submittedAt;

    private String assessmentNotes;

    private String isStatisticsOnly;

    private String createdBy;

    private String isLscClose = "N";
    private String isOcuClose = "N";

    private Integer lev;
    private int currstep;
    private int mitDeptId;
    private int mitigationCenterDeptId;
    private String postDeptCd;
    private String sector;
    private String assuranceMonth;
    private String postName;
    private String mainYn;

    public SmReport(int groupId, int reportId, String state, String phase, String stepCode, String reportType) {
        this.groupId = groupId;
        this.reportId = reportId;
        this.stateType = state;
        this.phase = phase;
        this.stepCode = stepCode;
        this.reportType = reportType;
    }

    public String parseSubmittedAt() {
        if (Objects.isNull(this.submittedAt)) {
            return null;
        }
        return DateUtil.toDateFormat(this.submittedAt.getTime(), "yyyyMMdd");
    }
}