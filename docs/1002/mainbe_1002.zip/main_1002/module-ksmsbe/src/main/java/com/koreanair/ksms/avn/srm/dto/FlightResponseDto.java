package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@ToString
@Accessors(chain = true)
public class FlightResponseDto {

	private int id;

	private int reportId;

	private String departureAt;

	private String flightNo;

	private String registrationNo;

	private String aircraftType;

	private String from;

	private String to;

	private String divert;

	private String std;

	private String sta;

	private String atd;

	private String ata;

	private Timestamp departureLocAt;

	private String stdLoc;

	private String staLoc;

	private String atdLoc;

	private String ataLoc;

	private String delay;

	private String supply;

	private String checkIn;

//	public FlightResponseDto setFlightNo(String flightNo) {
//		if (flightNo != null && !flightNo.isEmpty() && flightNo.startsWith("KE")) {
//			this.flightNo = flightNo.substring(2);
//		} else {
//			this.flightNo = flightNo;
//		}
//		return this;
//	}

}