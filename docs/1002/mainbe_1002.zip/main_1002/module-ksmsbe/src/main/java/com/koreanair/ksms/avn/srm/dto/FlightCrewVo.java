package com.koreanair.ksms.avn.srm.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FlightCrewVo extends SmFlightCrew {
	
	private int userId;
	
	private String nameKo;
	
	private String nameEn;
	
	private String deptNameKo;
	
	private String deptNameEn;
	
	private String rankNameKo;
	
	private String rankNameEn;

}
