package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.constants.AvnStatusCode.*;
import com.koreanair.ksms.common.dto.TbAvnSmGroup;
import com.koreanair.ksms.common.dto.TbAvnSmGroupList;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import io.micrometer.common.util.StringUtils;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.ValidationException;
import jakarta.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import software.amazon.awssdk.services.kms.endpoints.internal.Value;

import java.util.*;

@Service
public class AvnReportProcessServiceImpl extends AbstractBaseService implements AvnReportProcessService {

    @Autowired
    private Validator validator;

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    //보고서 묶음 처리 시 유효성 체크
    @Override
    public boolean getIsValidateGroupReport(Integer groupId) {
        //보고서 상태 체크
        int cnt = commonSql.selectOne("AvnReportProcess.selectStatusValidateGroupReport", groupId);
        if (cnt == 0) {
            return false;
        }
        return true;
    }

    @Override
    public List<String> getIsValidateCountGroupReport(Integer groupId) {
        //보고서 묶임 체크(Group ID 기준)
        return commonSql.selectList("AvnReportProcess.selectGroupedValidateGroupId", groupId);
    }

    //(그리드)보고서 묶음 처리
    @Transactional
    @Override
    public void insertMergeGroupReport(List<Integer> groupReportList) {
        TbAvnSmGroupList groupList = new TbAvnSmGroupList();
        TbAvnSmGroup oldGroupList = new TbAvnSmGroup();

        for (Integer groupId : groupReportList) {
            //첫번째 보고서의 그룹ID 저장
            if (groupReportList.indexOf(groupId) == 0) {
                groupList.setGroupId(groupId);
                continue;
            }
            groupList.setOldGroupId(groupId);
            commonSql.insert("AvnReportProcess.insertMergeGroupReportList", groupList);

            oldGroupList.setId(groupId);
            //결재상태 테이블 삭제 처리
            commonSql.delete("AvnReportProcess.deleteGroupApprovalLog", oldGroupList);

            //권한 테이블 삭제 처리
            commonSql.delete("AvnReportProcess.deleteGroupFrAccount", oldGroupList);

            commonSql.delete("AvnReportProcess.deleteGroupReportList", oldGroupList);
            commonSql.delete("AvnReportProcess.deleteGroupReport", oldGroupList);
        }
    }

    //(접수대기)보고서 묶음 처리
    @Transactional
    @Override
    public void updateMergeGroupReport(Integer orgGroupId, List<Integer> groupReportList) {
        TbAvnSmGroupList groupList = new TbAvnSmGroupList();
        groupList.setGroupId(orgGroupId);

        TbAvnSmGroup oldGroupList = new TbAvnSmGroup();

        for (Integer groupId : groupReportList) {

            groupList.setOldGroupId(groupId);
            commonSql.insert("AvnReportProcess.insertMergeGroupReportList", groupList);

            oldGroupList.setId(groupId);
            //결재상태 테이블 삭제 처리
            commonSql.delete("AvnReportProcess.deleteGroupApprovalLog", oldGroupList);

            //권한 테이블 삭제 처리
            commonSql.delete("AvnReportProcess.deleteGroupFrAccount", oldGroupList);

            commonSql.delete("AvnReportProcess.deleteGroupReportList", oldGroupList);
            commonSql.delete("AvnReportProcess.deleteGroupReport", oldGroupList);
        }
    }

    //(신규)보고서 묶음 처리
    //기존에 묶음했을 경우(예:반려한 경우)에는 그룹 생성하지 않음..
    @Transactional
    public void insertGroupReport(TbAvnSmGroup group) {
        //보고서 상태 체크
        Map<String, Object> reportInfo = this.selectGroupedValidateReportId(group.getReportId());
        int cnt = Integer.parseInt(reportInfo.get("cnt").toString());
        if (cnt == 0) {
            commonSql.insert("AvnReportProcess.insertNewGroupReport", group);

            TbAvnSmGroupList groupList = new TbAvnSmGroupList();
            groupList.setGroupId(group.getId());
            groupList.setReportId(group.getReportId());
            commonSql.insert("AvnReportProcess.insertNewGroupReportList", groupList);
        } else {
            group.setId(Integer.parseInt(reportInfo.get("group_id").toString()));
        }
    }

    //보고서 대표 보고서 수정
    @Transactional
    @Override
    public void updateIsMainReport(TbAvnSmGroupList tbAvnSmGroupList) {
        commonSql.update("AvnReportProcess.updateIsMainReport", tbAvnSmGroupList);
    }

    //보고서 묶음 보고서 삭제 처리
    @Transactional
    //@Override
    public void deleteMergeGroupReport(Integer groupId, Integer reportId) throws Exception {
        TbAvnSmGroup groupInfo = new TbAvnSmGroup();
        groupInfo.setId(groupId);
        groupInfo.setReportId(reportId);

        commonSql.update("AvnReportProcess.deleteGroupReportList", groupInfo);

        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        String empNo = userInfo.getEmpNo();
        ReportProcessVo proccessVo = new ReportProcessVo(0, reportId, empNo, StepType.SUBMIT);
        boolean success = this.smsReportProcess(proccessVo);
    }

    @Override
    public Map<String, Object> selectGroupedValidateReportId(Integer reportId) {
        //보고서 묶임 체크(Report ID 기준)
        return commonSql.selectOne("AvnReportProcess.selectGroupedValidateReportId", reportId);
    }


    @Override
    public int updateVoidReportId(ReportVoidVo voidVo) {
        commonSql.update("AvnReportProcess.updateVoidReportStatus", voidVo);

        //대표보고서 변경
        int cnt = commonSql.selectOne("AvnReportProcess.selectIsMainGroupReportCnt", voidVo);
        if (cnt == 0) {
            //대표보고서가 없을 경우.
            commonSql.update("AvnReportProcess.updateIsMainFirstReport", voidVo);
        }
        return voidVo.getReportId();
    }


    /** <pre>
     * 보고서 상태 관리
     * {@link ReportProcessVo}:
     * {@link StepType}(진행상태) / reason(reject, void 시에는 사유도 같이 포함됨)
     </pre> */
    @SuppressWarnings("unused")
    @Transactional
    @Override
    public boolean smsReportProcess(ReportProcessVo processVo) throws Exception {

        validateProcessVo(processVo);

        //현재 상태 조회
        ReportProcessDto status = selectReportStatus(processVo);

        ReportProcess report = ReportProcess.find(status.getPhase(), status.getStepCode());

        ReportStatus nextStat = report.findProc(processVo.getStepType());

        logger.debug("\r\n\r\n\r\n@@@ Report {} Current Step: {} / {}, => StepType: {}: {} / {}\r\n\r\n"
                , report.name(), report.getStatus().name(), report.getStatus().getName(), nextStat.getName()
                , nextStat.name(), nextStat.getName());

        if(nextStat != null) {
            processAction(processVo, status.getReportType(), nextStat); // Execute function
            return true;
        }
        return false;
    }

    /** <pre>
     * 보고서-위험요인 상태 관리
     * {@link ReportProcessVo}: hazardId 필수
     * {@link StepType}(진행상태) / reason(reject, void 시에는 사유도 같이 포함됨)
     </pre> */
    @SuppressWarnings("unused")
    @Transactional
    @Override
    public boolean smsHazardProcess(ReportProcessVo processVo) throws Exception {

        validateProcessVo(processVo);
        if(processVo.getHazardId() == null) {
            throw new ValidationException("[ReportProcessVo.hazardId] is required");
        }

        HazardProcessDto status = selectHazardStatus(processVo.getHazardId());
        HazardProcess hazard = HazardProcess.find(status.getHazardPhase(), status.getHazardStepCode());
        ReportStatus nextStat = null;

        if(hazard == HazardProcess.FIRST_RISK_SUBMITTED && processVo.getStepType() == StepType.APPROVE) {
            /* FIRST_RISK_SUBMITTED 는 승인이 2종류
             * 1차위험도 평가를 확인후 경감초지 유무에따라 분리 */
            if(status.getIsMitigation().equalsIgnoreCase("N")) {
                nextStat = ReportStatus.ACCEPTANCE_APPROVED;
            } else {
                nextStat = ReportStatus.ACCEPTANCE_APPROVED_MIT;
            }
        }else {
            nextStat = hazard.findProc(processVo.getStepType());
        }

        logger.debug("\r\n\r\n\r\n@@@ Hazard {} Current Step: {} / {}, => StepType: {}: {} / {}\r\n\r\n"
                , hazard.name(), hazard.getStatus().name(), hazard.getStatus().getName(), nextStat.getName()
                , nextStat.name(), nextStat.getName());

        if(nextStat != null) {
            // 리포트 종결 반려 승인시 처리를위해 current process를추가
            processVo.setHazardProcess(hazard);
            processAction(processVo, status.getReportType(), nextStat); // Execute function
            return true;
        }
        return false;
    }

    /** <pre>
     * 보고서-위험요인 상태 관리(LSC 종결)
     * {@link ReportProcessVo}: hazardId 필수
     * {@link StepType}(진행상태) / reason(reject, void 시에는 사유도 같이 포함됨)
     </pre> */
    @SuppressWarnings("unused")
    @Transactional
    @Override
    public boolean smsHazardProcessExpt(ReportProcessVo processVo) throws Exception {
        HazardProcessDto status = new HazardProcessDto();
        if (processVo.getHazardId() != null) {
            selectHazardStatus(processVo.getHazardId());
        } else {
            status.setReportType("hzr");
        }
        ReportStatus nextStat = ReportStatus.HZD_CLOSE_APPROVED;
        processAction(processVo, status.getReportType(), nextStat); // Execute function

        //todo khw. 팀장에게 메일, 알림 발송 처리

        return true;
    }

    @Transactional
    @Override
    public void processAction(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception {
        for(Action action : stat.getActionList()) {
            switch (action) {
                case UPDATE_REPORT:
                    updateReportStatus(processVo, reportType, stat);
                    break;
                case UPDATE_HAZARD:
                    updateHazardStatus(processVo, reportType, stat);
                    break;
                case INSERT_ROLE:
                    insertReportRole(processVo, reportType, stat);
                    break;
                case DELETE_ROLE:
                    deleteReportRole(processVo, reportType, stat);
                    break;
                default:
                    break;
            }
        }
        // send after action completed without void and delete
        if(Step.VOIDED!=stat.getStep() && Step.DELETED !=stat.getStep()) {
            //TODO KHW. 메일, 알림 발송 처리
            //reportSysNotiService.sendNoti(processVo, stat);
            //this.sendNoti(processVo, stat);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateReportStatus(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception {

        logger.debug("\r\n\r\n* updateReportStatus\r\n");
        String state = stat.getState().getCode();
        String phase = stat.getPhase().getCode();
        String step = stat.getStep().getCode();
        String reason = processVo.getReason();

        boolean isNotReceipt = true;
        if (processVo.getGroupId() == 0) {
            isNotReceipt = false;
        }

        SmReportApprovalLog logParam = new SmReportApprovalLog(processVo.getGroupId(), processVo.getReportId(), state, phase, step, processVo.getEmpNo(), reason);
        logParam.setTimezone(processVo.getTimezone());
        if(stat.getStep() == Step.REJECTED || stat.getStep() == Step.VOIDED) {
            if(StringUtils.isBlank(processVo.getReason())) {
                throw new ValidationException("[ReportProcessVo.reason] is required");
            }
        }

        if(StringUtils.isNotBlank(processVo.getReason())) {
            logParam.setReason(processVo.getReason());
        }

        //2024-09 보고서가 제출 완료된 경우 그룹(묶음)보고서를 자동 생성함(rsr 보고서 제외)
        if(!"rsr".equals(reportType) && Phase.REPORTING==stat.getPhase() && Step.SUBMITTED == stat.getStep() ) {
            TbAvnSmGroup group = new TbAvnSmGroup();
            group.setReportType(reportType);
            group.setPhase(phase);
            group.setStateType(state);
            group.setReportId(processVo.getReportId());
            this.insertGroupReport(group);

            logParam.setGroupId(group.getId());
            processVo.setGroupId(group.getId());
        }

        commonSql.insert("AvnReportProcess.insertReportApprovalLog", logParam);

        SmReport reportParam = new SmReport(processVo.getGroupId(), processVo.getReportId(), state, phase, step, reportType);
        if ("LSC".equals(processVo.getIsCloseType())) {
            reportParam.setIsLscClose("Y");
            reportParam.setIsOcuClose("N");
        } else if ("OCU".equals(processVo.getIsCloseType())) {
            reportParam.setIsLscClose("N");
            reportParam.setIsOcuClose("Y");
        } else {
            reportParam.setIsLscClose("N");
            reportParam.setIsOcuClose("N");
        }
        if (stat.getStep() == Step.VOIDED) {
            // state => voided
            reportParam.setStateType(step);
        }

        //report 테이블 업데이트 처리(접수 처리되지 않은 건인 경우에만 -> 접수 이후에는 Report master 테이블에 상태 업데이트 하지 않음..)
        if (!isNotReceipt) {
            commonSql.update("AvnReportProcess.updateReportStatus", reportParam);
        }

        //group 테이블 업데이트 처리
        commonSql.update("AvnReportProcess.updateGroupStatus", reportParam);
        
        // 2022-06-24 RSR 보고서가 제출 완료된 경우  추가처리
        if("rsr".equals(reportType) && Phase.REPORTING==stat.getPhase() && Step.SUBMITTED == stat.getStep() ) {
            updateReportStatus(processVo, reportType, ReportStatus.REPORT_CLOSE_APPROVED); // 리포트 CLOSE
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateHazardStatus(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception {
        logger.debug("\r\n\r\n** updateHazardStatus\r\n");
        String state = stat.getState().getCode();
        String phase = stat.getPhase().getCode();
        String step = stat.getStep().getCode();
        String reason = processVo.getReason();

        SmReportApprovalLog logParam = new SmReportApprovalLog(processVo.getGroupId(), processVo.getHazardId(), state, phase, step, processVo.getEmpNo(), reason);
        logParam.setTimezone(processVo.getTimezone());
        if(stat.getStep() == Step.REJECTED ||stat.getStep()== Step.REJECTED_MIT || stat.getStep() == Step.VOIDED) {
            if(StringUtils.isBlank(processVo.getReason())) {
                throw new ValidationException("[ReportProcessVo.reason] is required");
            }
        }

        if(StringUtils.isNotBlank(processVo.getReason())) {
            logParam.setReason(processVo.getReason());
        }

        commonSql.insert("AvnReportProcess.insertHazardApprovalLog", logParam);

        //두번째 파라메터 processVo.getReportId() 값은 없으므로.. -1로 대체함..
        SmReportHazard hazardParam = new SmReportHazard(processVo.getGroupId(), -1, processVo.getHazardId(), state, phase, step);
        commonSql.update("AvnReportProcess.updateHazardStatus", hazardParam);

        // 리포트 CLOSE, VOID, DELETE 처리
        if (stat == ReportStatus.HZD_CLOSE_APPROVED || stat.getStep() == Step.VOIDED || stat.getStep() == Step.DELETED) {
            // 진행중인 HAZARD Count
            int count = commonSql.selectOne("AvnReportProcess.selectReportInProcessCount", processVo.getGroupId());
            if (count == 0) {
                if (stat == ReportStatus.HZD_CLOSE_APPROVED) {
                    // HAZARD CLOSE 시 진행중인 다른 HAZARD가 없을 경우 REPORT CLOSE
                    updateReportStatus(processVo, reportType, ReportStatus.REPORT_CLOSE_APPROVED); // 리포트 CLOSE
                } else {
                    // 종료된(Closed) HAZARD Count
                    count = commonSql.selectOne("AvnReportProcess.selectReportClosedCount", processVo.getGroupId());
                    if (count == 0) {
                        if(stat.getStep() == Step.VOIDED) {
                            // HAZARD VOID시 진행중인 다른 HAZARD가 없고 CLOSED 된 HAZARD가 없을 경우 REPORT VOID
                            // (REPORT 상태는 접수단계에서 VOID된 상태로 표시됨)
                            updateReportStatus(processVo, reportType, ReportStatus.RECEPTION_VOIDED); // 리포트 VOID
                        }
                    } else {
                        // HAZARD VOID & DELETE시 진행중인 다른 HAZARD가 없고 CLOSED 된 HAZARD가 있을경우 REPORT CLOSE
                        updateReportStatus(processVo, reportType, ReportStatus.REPORT_CLOSE_APPROVED); // 리포트 CLOSE
                    }
                }
            }
        }else if (stat == ReportStatus.SECOND_RISK_APPROVED) {
            HazardProcess current=processVo.getHazardProcess();
            if(current.getStatus()==ReportStatus.HZD_CLOSE_REJECTED_MIT){
                // 위해요인 종결 반려에서 승인한 경우는 draft 로그를 쌓는다
                updateHazardStatus(processVo, reportType, ReportStatus.SECOND_RISK_DRAFT);
            }
        } else if (processVo.getHazardProcess().getStatus() == ReportStatus.HZD_CLOSE_APPROVED
                && stat == ReportStatus.MIT_RESULT_DRAFT) {
            ReportProcessDto status = selectReportStatus(processVo);
            ReportProcess report = ReportProcess.find(status.getPhase(), status.getStepCode());
            if(report.getStatus() == ReportStatus.REPORT_CLOSE_APPROVED) {
                // 2022-08-08 경감조치 유효성 평가(안전보증) 반려시 (RECEPTION_APPROVED 상태로 변경)
                ReportStatus assurance = ReportStatus.RECEPTION_APPROVED;
                updateReportStatus(processVo, reportType, assurance);
            }
        }
    }

    // 권한 부여 (ke_report_fr_account)
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void insertReportRole(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception {
        logger.debug("\r\n\r\n*** insertReportRole\r\n");
        ReportRoleAccountDto param = new ReportRoleAccountDto();
       //param.setReportId(processVo.getReportId());
        param.setGroupId(processVo.getGroupId());
        switch (stat) {
            case REPORTING_SUBMITTED:
                /* 보고서 제출 - 시스템 관리자 (SA) Primary 열람 그룹 (PVG)
                 * 보고서별 접수담당자 그룹(?MG), 보고서별 열람 그룹(?VG) */
                param.setType("roleCd");
                param.setRoleCdList(RoleByReport.find(reportType).getRoleCdList());
                break;
            case RECEPTION_APPROVED:
                // 접수 완료 - LSC(ke.sm_lsc)
                param.setType("lsc");
                //TODO khw. 필요한지 확인 필요
                //commonSql.insert("ReportProcess.insertVgroupMember", param); // 가상그룹 추가
                break;
            case FIRST_RISK_SUBMITTED:
                // 1차위험도평가 제출 (roleCd : SSC)
                param.setType("roleCd");
                param.setRoleCdList(Arrays.asList("SSC"));
                break;
            case MIT_ASSIGN_APPROVED:
                // 경감조치 접수팀장 승인 - MIT 팀 (ke.sm_mitigation) 부서 전체 권한부여
                MitigationMemberDto mitMember = selectMitigationMember(processVo.getHazardId());
                param.setDeptId(mitMember.getDeptId());
                param.setType("mit");
                //TODO khw. 필요한지 확인 필요
                //commonSql.insert("ReportProcess.insertVgroupMember", param); // 가상그룹 추가
                break;
            default:
                break;
        }
        commonSql.insert("AvnReportProcess.insertReportFrAccount", param);
    }

    @Transactional
    @Override
    public void deleteReportRole(ReportProcessVo processVo, String reportType, ReportStatus stat) {
        logger.debug("\r\n\r\n*** deleteReportRole\r\n");
        ReportRoleAccountDto param = new ReportRoleAccountDto();
        param.setGroupId(processVo.getGroupId());
        switch (stat) {
            case MIT_ACCEPT_REJECTED:
                MitigationMemberDto mitMember = selectMitigationMember(processVo.getHazardId());
                RejectMitigationDto mitValidate = RejectMitigationDto.builder()
                        .groupId(processVo.getGroupId())
                        .deptId(mitMember.getDeptId())
                        .hazardId(processVo.getHazardId())
                        .build();
                //1. 삭제 가능 여부 체크
                if(validateDeleteMitigationRole(mitValidate)) {
                    logger.debug("\r\n\r\n*** MIT role revoke @@@\r\n");
                    param.setDeptId(mitMember.getDeptId());
                    // 1. 내 부서로 할당된 경감조치 목록중 
                    param.setType("mit");
                    commonSql.delete("AvnReportProcess.deleteReportFrAccount", param);
                }
            default:
                break;
        }
    }

    private void validateProcessVo(ReportProcessVo processVo) {
        Set<ConstraintViolation<ReportProcessVo>> violations = validator.validate(processVo);
        if (!violations.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (ConstraintViolation<ReportProcessVo> constraintViolation : violations) {
                sb.append(constraintViolation.getMessage());
            }
            throw new ConstraintViolationException("Error occurred: " + sb.toString(), violations);
        }
    }

    @Override
    public ReportProcessDto selectReportStatus(ReportProcessVo processVo) throws Exception {
        ReportProcessDto result = new ReportProcessDto();
        try {
            if (processVo.getGroupId() == 0) {
                result = commonSql.selectOne("AvnReportProcess.selectSmReportStatus", processVo);
            } else {
                result = commonSql.selectOne("AvnReportProcess.selectSmGroupReportStatus", processVo);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return result;
    }

    @Override
    public HazardProcessDto selectHazardStatus(int id) throws Exception {
        HazardProcessDto result = new HazardProcessDto();
        try {
            result = commonSql.selectOne("AvnReportProcess.selectSmHazardStatus", id);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return result;
    }

    @Override
    public MitigationMemberDto selectMitigationMember(int hazardId) {
        MitigationMemberDto mitMember = new MitigationMemberDto();
        mitMember = commonSql.selectOne("AvnReportProcess.selectMitigationMember", hazardId);
        return mitMember;
    }

    @Override
    public boolean insertLscMember(ReportRoleAccountDto param) throws Exception {
        // lsc type 고정
        param.setType("lsc");
        //commonSql.insert("ReportProcess.insertVgroupMember", param); // 가상그룹 추가
        commonSql.insert("AvnReportProcess.insertReportFrAccount", param);
        return true;
    }

    @Override
    public boolean validateDeleteMitigationRole(RejectMitigationDto param) {
        RejectMitigationDto result = commonSql.selectOne("AvnReportProcess.validateDeleteMitigationRole", param);
        return result.compare();
    }

    @Override
    public int voidReport(ReportVoidVo reportVoidVo) throws Exception {
        ReportProcessVo reportProcess = new ReportProcessVo(
                reportVoidVo.getGroupId(),
                reportVoidVo.getReportId(),
                reportVoidVo.getEmpNo(),
                StepType.VOID,
                "Asia/Seoul");
        reportProcess.setReason(reportVoidVo.getReason());
        if (this.smsReportProcess(reportProcess)) {
            logger.info("Report void process success!");
            return reportVoidVo.getReportId();
        }
        return -1;
    }

    @Override
    public List<HazardCommentLogVo> selectCommentLog(Integer hazardId) {
        return commonSql.selectList("AvnReportProcess.selectCommentLog", hazardId);
    }

    @Override
    public List<HazardViewlistVo> selectHazardlist(HazardViewlistDto.GET_Request param) {
        return commonSql.selectList("AvnReportProcess.selectHazardlist", param);
    }

    public int selectHazardCnt(HazardViewlistDto.GET_Request param) {
        return commonSql.selectOne("AvnReportProcess.selectHazardCnt", param);
    }

    @Override
    public ReportStateInfoVo selectReportStateSetting(ReportInfoDto.GET_Request dto) {
        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());

        ReportStateInfoVo reportStateInfo = new ReportStateInfoVo();
        int deptId = userInfo.getDeptId();

        Integer groupId   = dto.getP_groupId();
        Integer hazardId  = null;
        if (dto.getP_hazardId() != null) {
            hazardId  = dto.getP_hazardId();
        }

        int cnt = 0;

        HazardViewlistDto.GET_Request hazardParam = new HazardViewlistDto.GET_Request();
        hazardParam.setGroupId(groupId);
        hazardParam.setHazardId(hazardId);
        hazardParam.setEmpNo(userInfo.getEmpNo());

        //현재 레포트 상태 조회.
        List<SmReport> reportStateList = selectReportCurrentStateInfo(hazardParam);
        reportStateInfo.setReportStateList(reportStateList);

        String reportType = reportStateList.get(0).getReportType();
        reportStateInfo.setReportType(reportType);

        // 단계별 OPEN 여부 체크하고 권한체크(열람:VM | 담당:MG | Admin:SA)
        //-----------------*. 접수
        // 접수상태(Step1OpenYn) : 항상 Y임
        String step1OpenYn = "Y";
        reportStateInfo.setStep1OpenYn(step1OpenYn);

        String step1Auth = this.getReportStepRole("report_acceptance", reportType);
        reportStateInfo.setStep1Auth(step1Auth);

        //-----------------*. 1차위험평가(lsc)
        //firstRiskAssessmentVo 의 leader = true인 경우 save/submit 가능, member = true인 경우 comment 입력 가능
        String step2OpenYn = "N";
        cnt = commonSql.selectOne("AvnReportProcess.selectRiskAssessmentCnt", groupId);
        if (cnt > 0) {
            step2OpenYn = "Y";
        }
        reportStateInfo.setStep2OpenYn(step2OpenYn);

        String step2Auth = this.getReportStepRole("risk_assessment", reportType);
        reportStateInfo.setStep2Auth(step2Auth);

        //-----------------*. 1차위험평가(src)
        hazardParam.setPhase("riskAcceptance");
        cnt = this.selectHazardCnt(hazardParam);
        String step3OpenYn = cnt > 0 ? "Y" : "N";
        reportStateInfo.setStep3OpenYn(step3OpenYn);

        //step3Auth = MG | SA인 경우 입력 가능
        String step3Auth = this.getReportStepRole("ssc_review", reportType);
        reportStateInfo.setStep3Auth(step3Auth);

        //접수 팀장 여부 확인
        reportStateInfo.setIsReceiptTeamLeader("N");
        if (userInfo.getPostDeptCd() != null) {
            reportStateInfo.setIsReceiptTeamLeader("Y");
        }

        //경감팀이 부문의 안전팀 확인
        reportStateInfo.setIsSectorSafety("N");
        String deptCd = userInfo.getDeptCd();
        //부문의 안전팀 리스트
        boolean isExist = isSectorSafetyTeamChecked(deptCd);
        if (isExist) {
            reportStateInfo.setIsSectorSafety("Y");
        }

        //경감팀의 리더 및 지정한 팀원 확인
        hazardParam.setMitigationEmpType("1");

        Map<String, Object> param = new HashMap<>();
        param.put("hazardId", hazardId);
        param.put("empNo", userInfo.getEmpNo());
        param.put("type", 1);
        reportStateInfo.setIsMitigationTeamMng("N");
        cnt = commonSql.selectOne("AvnReportProcess.selectMitigationTeamMngCnt", param);
        if (cnt > 0) {
            reportStateInfo.setIsMitigationTeamMng("Y");
        }

        //경감책임자 팀원 확인
        param.put("type", 2);
        reportStateInfo.setIsMitigationTeamWork("N");
        cnt = commonSql.selectOne("AvnReportProcess.selectMitigationTeamMngCnt", param);
        if (cnt > 0) {
            reportStateInfo.setIsMitigationTeamWork("Y");
        }

        //-----------------*. 경감조치-지정
        hazardParam.setPhase("mitigationAssign");
        cnt = this.selectHazardCnt(hazardParam);
        String step4OpenYn = cnt > 0 ? "Y" : "N";
        reportStateInfo.setStep4OpenYn(step4OpenYn);

        String step4Auth = this.getReportStepRole("mitigation", reportType);
        step4Auth = "MG_DEPT".equals(step4Auth) ? "MG" : step4Auth;
        reportStateInfo.setStep4Auth(step4Auth);

        //------------------*. 경감조치 권한 조회
        String stepMitAuth = this.getReportStepRole("mitigation", reportType);
        if ("MG_DEPT".equals(stepMitAuth)) {
            //경감조치팀 조건 추가
            hazardParam.setMitigationDeptId(deptId);
        }

        //-----------------*. 경감조치-계획
        hazardParam.setPhase("mitigationAccept");
        cnt = this.selectHazardCnt(hazardParam);
        String step5OpenYn = cnt > 0 ? "Y" : "N";
        reportStateInfo.setStep5OpenYn(step5OpenYn);

        String step5Auth = "";
        if ("Y".equals(step5OpenYn) && "MG_DEPT".equals(stepMitAuth)) {
            step5Auth = "MG";
        } else {
            step5Auth = "VW";
        }
        reportStateInfo.setStep5Auth(step5Auth);


        //-----------------*. 경감조치-실행
        hazardParam.setPhase("mitigationResult");
        cnt = this.selectHazardCnt(hazardParam);

        String step6OpenYn = cnt > 0 ? "Y" : "N";
        reportStateInfo.setStep6OpenYn(step6OpenYn);

        String step6Auth = "";
        if ("Y".equals(step6OpenYn) && "MG_DEPT".equals(stepMitAuth)) {
            step6Auth = "MG";
        } else {
            step6Auth = "VW";
        }
        reportStateInfo.setStep6Auth(step6Auth);

        //-----------------*. 2차위험평가(lsc)
        hazardParam.setPhase("riskAssessment");
        cnt = this.selectHazardCnt(hazardParam);
        String step7OpenYn = cnt > 0 ? "Y" : "N";
        reportStateInfo.setStep7OpenYn(step7OpenYn);

        String step7Auth = this.getReportStepRole("risk_assessment", reportType);
        reportStateInfo.setStep7Auth(step7Auth);

        //-----------------*. 2차위험평가(src)
        hazardParam.setPhase("2ndRiskAcceptance");
        cnt = this.selectHazardCnt(hazardParam);
        String step8OpenYn = cnt > 0 ? "Y" : "N";
        reportStateInfo.setStep8OpenYn(step8OpenYn);

        String step8Auth = this.getReportStepRole("ssc_review", reportType);
        reportStateInfo.setStep8Auth(step8Auth);

        //-----------------*. 종결
        hazardParam.setPhase("riskAcceptanceApproval");
        cnt = this.selectHazardCnt(hazardParam);
        String step9OpenYn = cnt > 0 ? "Y" : "N";
        reportStateInfo.setStep9OpenYn(step9OpenYn);

        String step9Auth = this.getReportStepRole("approval", reportType);
        reportStateInfo.setStep9Auth(step9Auth);

        return reportStateInfo;
    }

    public String getReportStepRole(String auth, String reportType) {
        List<String> authList = new ArrayList<>();
        authList.add(auth);
        List<String> reportAuthority = avnCommonService.getAuthReportList(authList);

        if (reportAuthority != null) {
            if (reportAuthority.contains("all_report")) {
                return "SA";
            } else {
                if ("risk_assessment".equals(auth)) {
                    if (reportAuthority.contains("assigned_report")) {
                        return "MG";
                    }
                } else if ("mitigation".equals(auth)) {
                    if (reportAuthority.contains("assigned_hazard")) {
                        return "MG_DEPT";
                    } else {
                        return "MG";
                    }
                } else {
                    if (reportAuthority.contains(reportType)) {
                        return "MG";
                    }
                }
            }
        }
        return "VW";
    }

    @Override
    public void updateFirstRiskAssessment(SSCReveiwDto.POST_Request parameter) {
        commonSql.update("AvnReportProcess.updateFirstHazardRiskLevel", parameter);
        commonSql.update("AvnReportProcess.updateFirstHazardAssessmentNotes", parameter);
    }

    @Override
    public boolean isSectorSafetyTeamChecked(String deptCd) {
        String[] sectorSafetyList = {"SELCTPN", "SELOQS", "SELQAS", "SELFTG", "SELSOP", "SELUFE"};
        return Arrays.stream(sectorSafetyList).anyMatch(deptCd::equals);
    }

    @Override
    public List<SmReport> selectReportCurrentStateInfo(HazardViewlistDto.GET_Request hazardParam) {
         return commonSql.selectList("AvnReportProcess.selectReportCurrentStateInfo", hazardParam);
    }
}
