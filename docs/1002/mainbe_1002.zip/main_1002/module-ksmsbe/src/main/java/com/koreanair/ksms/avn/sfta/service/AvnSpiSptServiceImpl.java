package com.koreanair.ksms.avn.sfta.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.avn.sfta.dto.OpStatusDto;
import com.koreanair.ksms.avn.sfta.dto.SpiReportDto;
import com.koreanair.ksms.avn.sfta.dto.SpiStatusDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.dto.TbAvnSpiDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnSpiSptServiceImpl extends AbstractBaseService implements AvnSpiSptService {

    @Override
    public List<SpiStatusDto> selectSPICodeList(SpiStatusDto tbSsSpiDto) {
        List<SpiStatusDto> resultList = commonSql.selectList("AvnSpiSpt.selectSPICodeList", tbSsSpiDto);
        return resultList;
    }

    @Override
    public List<OpStatusDto> selectOpStatusList1(OpStatusDto opStatusDto) {
        List<OpStatusDto> resultList = commonSql.selectList("AvnSpiSpt.selectOpStatusList1", opStatusDto);
        return resultList;
    }

    @Override
    public List<OpStatusDto> selectOpStatusList2(OpStatusDto opStatusDto) {
        List<OpStatusDto> resultList = commonSql.selectList("AvnSpiSpt.selectOpStatusList2", opStatusDto);
        return resultList;
    }

    @Override
    public List<OpStatusDto> selectOpStatusList3(OpStatusDto opStatusDto) {
        List<OpStatusDto> resultList = commonSql.selectList("AvnSpiSpt.selectOpStatusList3", opStatusDto);
        return resultList;
    }

    //안전보증 > Report List > 레포트 목록
    @Override
    public List<SpiReportDto> selectSpiReportList(Map<String, Object> param) {
        List<SpiReportDto> resultList = commonSql.selectList("AvnSpiSpt.selectSpiReportList", param);
        return resultList;
    }

    //안전보증 > 지표관리 > 지표관리 목록 > 지표 SPI 및 위험도 저장
    @Override
    public void updateSpiReport(SpiReportDto param) {
        commonSql.update("AvnSpiSpt.updateSpiReport", param);
        return ;
    }

    @Override
    public List<TbAvnSpiDto> selectSpiIndicatorList(TbAvnSpiDto tbAvnSpiDto) {
        List<TbAvnSpiDto> resultList = commonSql.selectList("AvnSpiSpt.selectSpiIndicatorList", tbAvnSpiDto);
        return resultList;
    }

    @Override
    public Map<String, Object> selectSpiIndicatorCnt(TbAvnSpiDto tbSsSpiDto) {
        Map<String, Object> cnt = commonSql.selectOne("AvnSpiSpt.selectSpiIndicatorCnt", tbSsSpiDto);
        return cnt;
    }

    @Override
    public int loadSpiIndicator(TbAvnSpiDto tbSsSpiDto) {
        int cnt = commonSql.insert("AvnSpiSpt.loadSpiIndicator", tbSsSpiDto);
        return cnt;
    }

    @Override
    public void insertSpiIndicator(TbAvnSpiDto tbSsSpiDto) {
        commonSql.insert("AvnSpiSpt.insertSpiIndicator", tbSsSpiDto);
        return;
    }

    @Override
    public void updateSpiIndicator(TbAvnSpiDto tbSsSpiDto) {
        commonSql.insert("AvnSpiSpt.updateSpiIndicator", tbSsSpiDto);
        return;
    }


    // 게시판 관리 > SPI게시판 목록 조회
    @Override
    public PageInfo<TbAvnBoardDto> selectBoardList(BoardSearchDto boardSearchDto) {
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnBulletinManage.selectBoardList", boardSearchDto);
        return PageInfo.of(resultList);
    }

    // 게시판 관리 > SPI게시판 상세 조회
    @Override
    public TbAvnBoardDto selectBoardDetail(int boardId) {
        TbAvnBoardDto tbAvnBoardDto = new TbAvnBoardDto();
        tbAvnBoardDto.setBoardId(boardId);

        commonSql.update("AvnBulletinManage.updateViewCount", boardId);
        commonSql.insert("AvnBulletinManage.insertBoardDetail", tbAvnBoardDto);

        BoardSearchDto boardSearchDto = BoardSearchDto.builder().boardId(boardId).build();
        return commonSql.selectOne("AvnBulletinManage.selectBoardList", boardSearchDto);
    }

    // 게시판 관리 > SPI게시판 신규 등록
    @Override
    public  void insertBoard(TbAvnBoardDto tbAvnBoardDto) {
        commonSql.insert("AvnBulletinManage.insertBoard", tbAvnBoardDto);
    }

    // 게시판 관리 > SPI게시판 수정
    @Override
    public void updateBoard(TbAvnBoardDto tbAvnBoardDto) {
        commonSql.update("AvnBulletinManage.updateBoard", tbAvnBoardDto);
    }

    // 게시판 관리 > SPI게시판 삭제
    @Override
    public void deleteBoard(int boardId) {
        commonSql.delete("AvnBulletinManage.deleteBoard", boardId);
    }



}
