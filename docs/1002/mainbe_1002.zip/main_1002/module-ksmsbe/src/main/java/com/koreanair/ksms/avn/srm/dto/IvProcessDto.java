package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import com.koreanair.ksms.avn.srm.dto.IvStatusCode.Status;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
public class IvProcessDto extends CommonDto {

    @NotNull
    private int id;

    @NotBlank
    private String empNo;

    @NotNull
    private Status status;

    private String reason;

    private String timezone;

    private String requestType;
}
