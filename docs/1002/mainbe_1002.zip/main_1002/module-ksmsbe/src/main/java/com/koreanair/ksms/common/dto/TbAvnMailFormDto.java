package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "메일양식")
public class TbAvnMailFormDto extends CommonDto {
    
    @Schema(description = "메일ID")
    @NotBlank
    private String mailCd;
    
    @Schema(description = "메일명")
    private String mailNm;
    
    @Schema(description = "메일유형코드")
    private String mailTypeCd;
    
    @Schema(description = "메일텍스트내용")
    private String mailTxtcn;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "배치여부")
    @NotBlank
    private String batYn;
    
    @Schema(description = "파일그룹SEQ")
    private String fileGroupSeq;
}
