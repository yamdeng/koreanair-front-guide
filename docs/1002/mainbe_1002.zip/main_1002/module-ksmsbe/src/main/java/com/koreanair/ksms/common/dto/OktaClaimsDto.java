package com.koreanair.ksms.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

import java.util.List;

@Getter
public class OktaClaimsDto {

    private String jti;

    @JsonProperty("preferred_username")
    private String userId;

    private String name;
    private String employeeNumber;
    private String email;

    private List<String> groups;
}