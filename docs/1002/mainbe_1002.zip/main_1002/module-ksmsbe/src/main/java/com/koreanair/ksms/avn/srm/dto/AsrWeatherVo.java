package com.koreanair.ksms.avn.srm.dto;

import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AsrWeatherVo extends SmWeather {
	
	private int id;
	
	private int asrEventId;
	
	private List<Integer> significantWeather;
	
	private String metKo;
	
	private String metEn;
	
	private String cloudKo;
	
	private String cloudEn;
	
	private String altimeterUnitKo;
	
	private String altimeterUnitEn;
	
}
