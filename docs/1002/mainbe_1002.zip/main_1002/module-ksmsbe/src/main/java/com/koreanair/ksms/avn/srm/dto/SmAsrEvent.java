package com.koreanair.ksms.avn.srm.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class SmAsrEvent {

	@NotNull
	private int id;

	@NotNull
	private int reportId;

	@Size(max = 100)
	private String locationText;

	@Size(max = 10)
	private String airport;

	@Size(max = 3)
	private String runway;

	private Timestamp eventAt;

	@Size(max = 50)
	private String flightPhase;
	
	private int altitude;

	@Size(max = 50)
	private String altitudeUnit;

	private int speed;

	@Size(max = 50)
	private String speedUnit;
	
	@Size(max = 20)
	private String eventAtTz;
	
	private List<PoFileVo> attachment;

}
