package com.koreanair.ksms.avn.audit.vo;

import com.koreanair.ksms.common.dto.CommonDto;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class QuestionDeleteVo extends CommonDto{

	private List<Integer> deletedIds;
}