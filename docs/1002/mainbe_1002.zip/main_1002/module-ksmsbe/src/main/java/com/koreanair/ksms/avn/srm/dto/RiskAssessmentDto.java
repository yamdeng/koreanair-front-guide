package com.koreanair.ksms.avn.srm.dto;

import java.util.List;

import com.koreanair.ksms.common.dto.CommonDto;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

//1차 2차 공통적으로 사용하는 dto
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@ToString
public class RiskAssessmentDto extends CommonDto {
    private Integer groupId;
    private Integer hazardId;
    private List<String> roleList;
    private final String resourceName="risk_assessment";
    private Integer lscUserId;
    private boolean isView;
}
