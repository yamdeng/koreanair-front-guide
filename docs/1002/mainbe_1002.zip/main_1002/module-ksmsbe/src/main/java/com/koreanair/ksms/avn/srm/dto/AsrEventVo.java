package com.koreanair.ksms.avn.srm.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
public class AsrEventVo extends SmAsrEvent {

	private int id;
	
	private String subject;

	private String descr;
	
	private String flightPhaseKo;

	private String flightPhaseEn;

	private String altitudeUnitKo;
	
	private String altitudeUnitEn;
	
	private String speedUnitKo;
	
	private String speedUnitEn;
	
	private List<PoFileVo> attachment;
	
	private Timestamp eventAt;
	
	private String eventAtTzNameKo;
	
	private String eventAtTzNameEn;
	
}
