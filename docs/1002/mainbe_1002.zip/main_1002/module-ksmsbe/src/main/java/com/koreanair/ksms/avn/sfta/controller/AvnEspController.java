package com.koreanair.ksms.avn.sfta.controller;

import com.koreanair.ksms.avn.sfta.service.AvnEspService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전보증 - ESP관리
 */
@Tag(name = "AvnEsp", description = "안전보증 - ESP관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnEspController {

    @Autowired
    AvnEspService service;

    /**
     * ESP 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "ESP 목록 조회", description = "ESP 목록 조회 API")
    @GetMapping(value = "/assurance/esps")
    public ResponseEntity<?> getEspList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "ESP 상세정보 조회", description = "ESP 상세정보 조회 API")
    @GetMapping(value = "/assurance/esps/{espId}")
    public ResponseEntity<?> getEspInfo(@PathVariable(value="espId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
