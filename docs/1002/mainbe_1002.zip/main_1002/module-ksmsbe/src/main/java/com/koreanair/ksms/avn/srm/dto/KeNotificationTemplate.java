package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class KeNotificationTemplate {

	private int id;

	private String subjectEmailKo;

	private String notiType;

	private String systemType;

	private String contentEmailKo;

	private String notes;

	private String state;

	private Timestamp createdAt;

	private String sendEmail;

	private String sendAlarm;

	private String contentEmailEn;

	private String subjectEmailEn;

	private String contentAlarmKo;

	private String contentAlarmEn;

	private String subjectAlarmKo;

	private String subjectAlarmEn;

}
