package com.koreanair.ksms.avn.sfta.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SPT / SPI 지표별 현황")
public class SpiReportDto extends CommonDto {
    

    @Schema(description = "보고서 번호")
    private int    num;
    private int    reportId;

    @Schema(description = "레포트문서번호")
    private String reportDocno;

    @Schema(description = "출발일자")
    private String departureDt;
    
    @Schema(description = "항공기유형코드")
    private String aircraftTypeCd;
    private String aircraftTypeKor;
    private String aircraftTypeEng;
    private String fleetNm;

    @Schema(description = "등록번호")
    private String regNo;
    
    @Schema(description = "비행 번호")
    private String flightNo;

    @Schema(description = "공항코드")
    private String departureAirportCd;
    private String arrivalAirportCd;
    private String occurAirportCd;
    
    @Schema(description = "제목명")
    private String subjectNm;
    
    @Schema(description = "이벤트명")
    private String eventId;
    private String eventName;
    private String eventSummary;

    @Schema(description = "SPI 연도")
    private String spiYear;

    @Schema(description = "SPI 유형 코드")
    private String spiTypeCd;

    @Schema(description = "SPI 코드")
    private String spiCd;

    @Schema(description = "리스크 코드")
    private String riskLevelCd;

    @Schema(description = "컬러 코드")
    private String colorCd;

}
