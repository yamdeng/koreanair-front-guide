package com.koreanair.ksms.avn.admin.service;

import java.util.List;

import com.koreanair.ksms.common.dto.TbAvnRiskLevelMatrixDto;

public interface AvnTopRiskService {
    List<TbAvnRiskLevelMatrixDto> selectRiskMatrixList();
}
