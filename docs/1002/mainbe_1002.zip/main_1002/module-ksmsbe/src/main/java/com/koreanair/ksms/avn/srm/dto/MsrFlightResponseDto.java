package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.Length;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "접수 - MSR Flight 정보")
public class MsrFlightResponseDto {

    @NotNull
    private int id;

    @NotNull
    private int reportId;

    private Timestamp departureAt;

    @Length(max = 20)
    private String flightNo = "";

    @Length(max = 20)
    @JsonProperty(value = "registrationNo")
    private String regNo;

    @Length(max = 4)
    private String aircraftType;

    @Length(max = 10)
    @JsonProperty(value = "from")
    private String fromAirport;

    @Length(max = 10)
    @JsonProperty(value = "to")
    private String toAirport;

    @Length(max = 10)
    @JsonProperty(value = "divert")
    private String divertAirport;

    @Length(max = 5)
    @JsonProperty(value = "std")
    private String stdTime;

    @Length(max = 5)
    @JsonProperty(value = "sta")
    private String staTime;

    @Length(max = 5)
    @JsonProperty(value = "atd")
    private String atdTime;

    @Length(max = 5)
    @JsonProperty(value = "ata")
    private String ataTime;

    @JsonProperty(value = "delay")
    private int delayHour;

    @Length(max = 20)
    private String supply;

    @Length(max = 20)
    private String checkIn;

    private Timestamp departureLocAt;

    @Length(max = 5)
    @JsonProperty(value = "stdLoc")
    private String stdLocTime;

    @Length(max = 5)
    @JsonProperty(value = "staLoc")
    private String staLocTime;

    @Length(max = 5)
    @JsonProperty(value = "atdLoc")
    private String atdLocTime;

    @Length(max = 5)
    @JsonProperty(value = "ataLoc")
    private String ataLocTime;

    public void setRegNo(String regNo) {
        if (regNo != null && regNo.startsWith("HL")) {
            this.regNo = regNo.substring(2);
            return;
        }
        this.regNo = regNo;
    }
}
