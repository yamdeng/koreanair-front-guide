package com.koreanair.ksms.avn.srm.dto;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MitigationMemberDto  {

    private int reportId;

    private int hazardId;

    private int deptId;

    private String stepCode;

    private String requestedBy;

    private String leaderEmpNo;

    private String empNo;

    private Timestamp planDueAt;

    private List<String> memberEmpNoList = new ArrayList<String>();

    public void setMemberEmpNoList(String memberEmpNoList) {
        if(StringUtils.isNotEmpty(memberEmpNoList)) {
            this.memberEmpNoList = Arrays.asList(memberEmpNoList.trim().split("\\s*,\\s*"));
        }
    }


}