package com.koreanair.ksms.avn.srm.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class IvInvestigationReportDTO {
    private int postId;
    private String postContents;
    private int reportFileGroupSeq;
    private String investigateBy;
}
