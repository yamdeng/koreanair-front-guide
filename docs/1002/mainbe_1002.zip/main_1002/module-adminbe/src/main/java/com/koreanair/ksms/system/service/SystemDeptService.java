package com.koreanair.ksms.system.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.TbSysDeptDto;

import java.util.List;

public interface SystemDeptService {

    PageInfo<TbSysDeptDto> selectDeptListPage(String searchWord);
    List<TbSysDeptDto> selectDeptListTree();
    TbSysDeptDto selectDept(int deptId);
}
