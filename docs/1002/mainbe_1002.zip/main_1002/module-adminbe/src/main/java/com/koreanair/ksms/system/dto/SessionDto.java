package com.koreanair.ksms.system.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.List;

@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class SessionDto {
    private String sessionId;
    private String userIp;
    private String userId;
    private String userName;
    private String userEmail;
    private String employeeNumber;
    private List<String> userGroups;
    private List<String> userMenus;
    private String issuerType;
    private String idToken;
}