package com.koreanair.ksms.system.dao;

import com.koreanair.ksms.system.dto.SessionDto;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Repository;

import java.util.concurrent.TimeUnit;

@Repository
public class SessionRepository {
    private final RedisTemplate<String, SessionDto> redisSessionTemplate;

    @Resource(name = "redisSessionTemplate")
    ValueOperations<String, SessionDto> valueOperations;

    @Value(value = "${spring.data.redis.session-ttl.default}")
    private int redisSessionTtl;

    public SessionRepository(RedisTemplate<String, SessionDto> redisSessionTemplate) {
        this.redisSessionTemplate = redisSessionTemplate;
    }

    public void createSession(String key, SessionDto session) {
        valueOperations.set(key, session);
        redisSessionTemplate.expire(key, redisSessionTtl, TimeUnit.SECONDS);
    }

    public SessionDto getSession(String key) {
        SessionDto session = valueOperations.get(key);
        if (session != null) {
            redisSessionTemplate.expire(key, redisSessionTtl, TimeUnit.SECONDS);
        }
        return session;
    }

    public SessionDto getSessionWithoutRefreshTTL(String key) {
        return valueOperations.get(key);
    }

    public Boolean deleteSession(String key) {
        return redisSessionTemplate.delete(key);
    }

}
