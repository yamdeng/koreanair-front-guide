package com.koreanair.ksms.utils;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CryptUtilTest {

    @Test
    void encryptAES256() {
        String str = CryptUtil.encryptAES256("test string");
        System.out.println("encrypt str : " + str);

        assertTrue(true);
    }

    @Test
    void decryptAES256() {
        String str = CryptUtil.decryptAES256("JquV3pHsS1Fy14NvwtcK5jfqrOs3N2VSCqK7BBmlnj0x28La9OLcNuxWli9xB5Qiejj0vA==");
        System.out.println("decrypt str : " + str);

        assertTrue(true);
    }
}