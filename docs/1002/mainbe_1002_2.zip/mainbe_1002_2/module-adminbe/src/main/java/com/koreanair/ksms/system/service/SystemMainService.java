package com.koreanair.ksms.system.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.*;
import io.vertx.core.json.JsonObject;

import java.util.List;
import java.util.Map;

public interface SystemMainService {
    List<Map<String, Object>> selectLeftMenu(String workScope);

    List<TbSysCodeGroupDto> selectCodeGroupList();

    List<TbSysCodeDto> selectCodeList(String codeGrpId);

    List<TbSysCodeDto> selectCodeListAll();

    List<TbSysDeptDto> selectDeptList();

    PageInfo<TbSysUserDto> selectUserList(String searchWord, String deptCd);

    JsonObject selectMessagesAll();

    TbSysUserDto selectUserProfile(String userId);

    List<TbSysVirtualGroupDto> selectUserGroups(String userId);

    void createRedis(String key, String value);

    String readRedis(String key);

    void deleteRedis(String key);

    TbSysDeptDto selectDeptId(int deptId);

    TbSysDeptDto selectDeptCd(String deptCd);
}
