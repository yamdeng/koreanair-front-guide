package com.koreanair.ksms.utils;

import com.koreanair.ksms.exception.CustomBusinessException;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URLEncoder;
import java.util.Base64;
import java.util.List;
import java.util.Map;

public class ExcelUtil {

    /**
     * Default style excel sxssf workbook.
     *
     * @param sheetName   the sheet name
     * @param excelFields the excel fields
     * @param dataList    the data list
     * @return the sxssf workbook
     */
    public static SXSSFWorkbook defaultStyleExcel(String sheetName, Map<String, String> excelFields, List<?> dataList) {

        String[] columnTitles = excelFields.values().toArray(new String[excelFields.size()]);
        String[] columnNames = excelFields.keySet().toArray(new String[excelFields.size()]);

        SXSSFWorkbook excel = new SXSSFWorkbook();

        // Cell style - 컬럼
        CellStyle columnHeaderStyle = ExcelStyle.getColumnHeaderStyle(excel);
        CellStyle defaultStyle = ExcelStyle.getDefaultStyle(excel);
        CellStyle defaultNumberStyle = ExcelStyle.getDefaultNumberStyle(excel);
        CellStyle defaultDecimalStyle = ExcelStyle.getDefaultDecimalStyle(excel);

        int rowNo = 0; // 행 번호

        Sheet columnSheet = excel.createSheet(sheetName);
        Row columnRow = columnSheet.createRow(rowNo++);

        int columnCellNum = 0;

        for (String columnName : columnTitles) {
            ExcelCellUtil.createCellWithStyle(columnRow, columnCellNum++, columnName, columnHeaderStyle);

            ExcelCellUtil.resizeCell(columnSheet, columnCellNum);
        }

        Class<?> dataClass = dataList.get(0).getClass();
        Field field = null;

        int rowCellNum = 0;
        Object fieldValue = null;
        Row row = null;

        for (Object data : dataList){
            row = columnSheet.createRow(rowNo);

            rowCellNum = 0;

            for(String colName: columnNames) {
                try {
                    field = dataClass.getDeclaredField(colName);
                } catch (NoSuchFieldException e) {
                    throw new CustomBusinessException("엑셀 다운로드시 문제가 발생했습니다.");
                }

                field.setAccessible(true); // 필드에 접근하기 위해 접근성을 변경

                try {
                    fieldValue = field.get(data);
                } catch (IllegalAccessException e) {
                    throw new CustomBusinessException("엑셀 다운로드시 문제가 발생했습니다.");
                }

                if (field.getType() == Integer.class || field.getType() == BigInteger.class || field.getType() == Long.class) {
                    long value = fieldValue == null ? 0 : Long.parseLong(fieldValue.toString());
                    ExcelCellUtil.createCellWithStyle(row, rowCellNum++, String.valueOf(value), defaultNumberStyle);
                }
                else if (field.getType() == BigDecimal.class || field.getType() == Double.class) {
                    double value = fieldValue == null ? 0 : Double.parseDouble(fieldValue.toString());
                    ExcelCellUtil.createCellWithStyle(row, rowCellNum++, String.valueOf(value), defaultDecimalStyle);
                }
                else ExcelCellUtil.createCellWithStyle(row, rowCellNum++, fieldValue == null ? "" : fieldValue.toString(), defaultStyle);
            }

            if(rowNo % 10000 == 0){
                // 10000행 마다 주기적인 flush 진행
                try {
                    ((SXSSFSheet) columnSheet).flushRows(rowNo-1);
                } catch (IOException e) {
                    throw new CustomBusinessException("엑셀 다운로드시 문제가 발생했습니다.");
                }
            }

            rowNo ++;
        }

        // cell 사이즈 맞추기
        for(int i = 0; i <= rowCellNum - 1; i++) {
            ExcelCellUtil.resizeCell(columnSheet, i);
        }

        return excel;
    }

    /**
     * Download excel
     *
     * @param resultList    the data list
     * @param excelParam    the excel column info
     * @param excelFileName the excel file name
     * @return the response entity
     */
    public static ResponseEntity<?> downloadExcel(List<?> resultList, Map<String, String> excelParam, String excelFileName) {

        SXSSFWorkbook excel = ExcelUtil.defaultStyleExcel("Sheet1", excelParam, resultList);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            excel.writeAvoidingTempFiles(bos);
        } catch (IOException e) {
            throw new CustomBusinessException("엑셀 다운로드시 문제가 발생했습니다.");
        } finally {
            try {excel.close();} catch(IOException e1){throw new CustomBusinessException(e1.getMessage());}
        }

        byte[] bytes = bos.toByteArray();
        ByteArrayResource resource = new ByteArrayResource(bytes);

        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + URLEncoder.encode(excelFileName) + ".xlsx");
        header.add("Content-Transfer-Encoding", "binary");

        return ResponseEntity.ok()
                .headers(header)
                .contentLength(bytes.length)
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(resource);
    }

    /**
     * Download csv response entity.
     *
     * @param resultList  the result list
     * @param csvParam    the csv param
     * @param csvFileName the csv file name
     * @return the response entity
     */
    public static ResponseEntity<?> downloadCsv(List<?> resultList, Map<String, String> csvParam, String csvFileName) {

        StringBuilder sb = new StringBuilder();
        Class<?> dataClass = resultList.get(0).getClass();
        Field field = null;
        Object fieldValue = null;

        String[] columnTitles = csvParam.values().toArray(new String[csvParam.size()]);
        String[] columnNames = csvParam.keySet().toArray(new String[csvParam.size()]);

        for (String columnName : columnTitles) {
            sb.append(columnName).append(", ");
        }

        sb.setLength(sb.length()-2);
        sb.append("\n");

        for (Object data : resultList) {
            for(String colName: columnNames) {
                try {
                    field = dataClass.getDeclaredField(colName);
                    field.setAccessible(true);
                    fieldValue = field.get(data);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    throw new CustomBusinessException("엑셀 다운로드시 문제가 발생했습니다.");
                }

                sb.append(fieldValue.toString()).append(", ");
            }
            sb.setLength(sb.length()-2);
            sb.append("\n");
        }

        String csvData = sb.toString();

        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + URLEncoder.encode(csvFileName) + ".csv");
        //header.add("Content-Transfer-Encoding", "binary");

        return ResponseEntity.ok()
                .headers(header)
                //.contentLength(sb.length())
                .contentType(MediaType.parseMediaType("text/csv; charset=MS949"))
                .body(csvData);
    }
}