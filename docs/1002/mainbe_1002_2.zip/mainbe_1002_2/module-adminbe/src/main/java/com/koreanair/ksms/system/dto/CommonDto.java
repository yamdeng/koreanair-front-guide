package com.koreanair.ksms.system.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.security.core.context.SecurityContextHolder;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
public class CommonDto {
    private String regUserId = SecurityContextHolder.getContext().getAuthentication().getName();
    private Timestamp regDttm;
    private String updUserId = SecurityContextHolder.getContext().getAuthentication().getName();
    private Timestamp updDttm;
}
