package com.koreanair.ksms.system.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbSysFileDto extends CommonDto {

    private int fileSeq;
    private int fileGroupSeq;
    private String origFilename;
    private String fileExt;
    private long fileSize;
    private String s3Path;
    private String fileOid;
    private String useYn;
}
