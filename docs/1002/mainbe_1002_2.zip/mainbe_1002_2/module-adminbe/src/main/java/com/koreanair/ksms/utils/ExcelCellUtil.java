package com.koreanair.ksms.utils;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFSheet;

public class ExcelCellUtil {
    public static Cell createCellWithStyle(Row row, int cellNum, String value, CellStyle style){
        Cell cell = row.createCell(cellNum);

        cell.setCellValue(value);
        cell.setCellStyle(style);
        return cell;
    }

    public static void resizeCell(Sheet sheet, int cellNum) {
        ((SXSSFSheet)sheet).trackColumnForAutoSizing(cellNum);
        sheet.autoSizeColumn(cellNum);
        sheet.setColumnWidth(cellNum, Math.min(200*200, sheet.getColumnWidth(cellNum) + 1024));
    }
}