package com.koreanair.ksms.system.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbSysUserDto extends CommonDto {

    private String userId; //사용자ID
    private String empNo; //사번
    private String nameKor; //사용자명(한국어)
    private String nameEng; //사용자명(영어)
    private String nameChn; //사용자명(중국어)
    private String nameJpn; //사용자명(일본어)
    private String namaEtc; //사용자명(기타)
    private String email; //메일
    private String statusCd; //상태
    private String deptCd; //부서코드
    private String pstnCd; //직위코드
    private String dutyCd; //직책코드
    private String rankCd; //RANK코드
    private String photo; //사진파일 이름
    private int sortOrder; //정렬순서
    private String officeTelNo; //사무실전화번호
    private String mobileTelNo; //핸드폰 번호
    private String compCd; //법인코드
    private String subEmpNo; //부 사번
    private String subCompCd; //파견 법인코드
    private String subEmail; //부 메일주소
    private String empType; //직원구분
    private String dsptYn; //주재원여부
    private String jobCd; //직무코드
    private String bareaCd; //사업장코드
    private String eaiYn; //EAI연동여부
    private String classCd; //KE CLASS CODE
    private String className; //KE CLASS NAME

    private int groupId;
    private String groupCd;
    private String groupAdminYn;
    private String deptNmKor;
    private String deptNmEng;
    private String rankNmKor;
    private String rankNmEng;


}
