package com.koreanair.ksms.system.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.TbSysUserDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SystemUserServiceImpl extends AbstractBaseService implements SystemUserService {

    @Override
    public PageInfo<TbSysUserDto> selectUserListPage(String searchWord) {

        List<TbSysUserDto> resultList = commonSql.selectList("SystemUser.selectUserList", searchWord);
        return PageInfo.of(resultList);
    }

    @Override
    public TbSysUserDto selectUser(String userId) {

        return commonSql.selectOne("SystemUser.selectUser", userId);
    }
}
