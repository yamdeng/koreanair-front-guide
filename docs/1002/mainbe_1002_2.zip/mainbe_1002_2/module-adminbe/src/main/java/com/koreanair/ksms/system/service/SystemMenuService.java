package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysMenuDto;

import java.util.List;
import java.util.Map;

public interface SystemMenuService {

    List<Map<String, Object>> selectMenuList(String workScope);
    TbSysMenuDto selectMenu(String menuId);
    void insertMenu(TbSysMenuDto dto);
    void updateMenu(TbSysMenuDto dto);
    void deleteMenu(String menuId);
}
