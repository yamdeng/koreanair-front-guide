package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import com.koreanair.ksms.common.dto.CommonDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain=true)
public class SmComment extends CommonDto {

	private Integer id;

	private String empNo;

	private String content;

	private String timezone;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "Asia/Seoul")
	private Timestamp createdAt;

	private Timestamp deletedAt;

	private Integer groupId;

	private Integer hazardId;
	
}
