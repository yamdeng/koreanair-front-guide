package com.koreanair.ksms.avn.sfta.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveHzdTopRiskDto;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveSearchDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnSmsComprehensiveServiceImpl extends AbstractBaseService implements AvnSmsComprehensiveService {

    @Override
    public PageInfo<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveHzdList(SmsComprehensiveSearchDto param) {
        String qId = "";
        if(param.getGrd().equals("grd1")) qId = "AvnSmsComprehensive.selectSMSHzdList1";
        else if(param.getGrd().equals("grd2")) qId = "AvnSmsComprehensive.selectSMSHzdList2";
        else if(param.getGrd().equals("grd3")) qId = "AvnSmsComprehensive.selectSMSHzdList3";

        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList(qId, param);
        return PageInfo.of(resultList);
    }
    
    @Override
    public PageInfo<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList(SmsComprehensiveSearchDto param) {
        String qId = "";
        if(param.getGrd().equals("grd1")) qId = "AvnSmsComprehensive.selectSMSEventList1";
        else if(param.getGrd().equals("grd2")) qId = "AvnSmsComprehensive.selectSMSEventList2";
        else if(param.getGrd().equals("grd3")) qId = "AvnSmsComprehensive.selectSMSEventList3";
        else if(param.getGrd().equals("grd4")) qId = "AvnSmsComprehensive.selectSMSEventList4";
        else if(param.getGrd().equals("chart1")) qId = "AvnSmsComprehensive.selectSMSEventChart1";
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList(qId, param);
        return PageInfo.of(resultList);
    }

    @Override
    public PageInfo<SmsComprehensiveHzdTopRiskDto> selectReportDetailList(SmsComprehensiveSearchDto param) {
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList("AvnSmsComprehensive.selectReportDetailList", param);
        return PageInfo.of(resultList);
    }
}
