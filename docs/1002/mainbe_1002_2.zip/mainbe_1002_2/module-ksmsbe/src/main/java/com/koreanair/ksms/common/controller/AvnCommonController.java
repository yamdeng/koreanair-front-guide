package com.koreanair.ksms.common.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.service.AvnRiskMatrixService;
import com.koreanair.ksms.avn.srm.dto.SearchConditionDto;
import com.koreanair.ksms.common.dto.AvnIvReportApproval;
import com.koreanair.ksms.common.dto.AvnIvReportApprovalGroup;
import com.koreanair.ksms.common.dto.AvnIvReportApprovalGroupMember;
import com.koreanair.ksms.common.dto.LscGroupDto;
import com.koreanair.ksms.common.dto.LscGroupMemberDto;
import com.koreanair.ksms.common.dto.ReportSearchDto;
import com.koreanair.ksms.common.dto.SmSearchReport;
import com.koreanair.ksms.common.dto.TbAvnAircrafts;
import com.koreanair.ksms.common.dto.TbAvnAirports;
import com.koreanair.ksms.common.dto.TbAvnSysUserDto;
import com.koreanair.ksms.common.dto.TbSysCodeDto;
import com.koreanair.ksms.common.dto.TbSysUserCfgDto;
import com.koreanair.ksms.common.dto.TbTbAvnDisplayStatusDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 항공안전(AVN)공통 컨트롤러
 */
@Tag(name = "AvnCommon", description = "항공안전 공통 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn/common")
public class AvnCommonController { 

    @Autowired
    AvnCommonService service;

    @Autowired
    AvnRiskMatrixService riskService;
    
    @Autowired
    KsmsCommonService commService;


    @Operation(summary = "보고서 단계별 상태구분 목록 조회", description = "보고서 단계별 상태구분 목록 조회")
    @GetMapping(value = "/page_code/{pageCode}/state")
    public ResponseEntity<?> getPageCodeList(@PathVariable(value="pageCode", required=true) String pageCode) {

        List<TbTbAvnDisplayStatusDto> resultList = service.selectPageCodeList(pageCode);
        return ResponseUtil.createSuccessResponse(resultList);
    }

//    @Parameter(description = "keyword")
    @Operation(summary = "공항 목록 조회", description = "공항 목록 조회")
    @GetMapping(value = "/airports")
    public ResponseEntity<?> getAirportList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="searchWord", required=false) String keyword) {

        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnAirports> resultList = service.selectAirportList(keyword);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "airCraft 목록 조회", description = "airCraft 목록 조회")
    @GetMapping(value = "/aircrafts")
    public ResponseEntity<?> getAircraftList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="searchWord", required=false) String keyword) {

        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnAircrafts> resultList = service.selectAircraftList(keyword);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "개인별 환경설정 항목 조회", description = "개인별 환경설정 항목 조회 API")
    @GetMapping(value = "/user-cfg")
    public ResponseEntity<?> getUserCfg() {

        TbSysUserCfgDto result = service.selectUserCfg();

        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "개인별 환경설정 항목 저장", description = "개인별 환경설정 항목 저장 API")
    @PostMapping(value = "/user-cfg")
    public ResponseEntity<?> saveUserCfg(@Valid @RequestBody TbSysUserCfgDto dto) {

        service.saveUserCfg(dto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "전체 사용자 목록 조회(보고서)", description = "전체 사용자 목록 조회(보고서) API")
    @GetMapping(value = "/users")
    public ResponseEntity<?> getUserList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="searchWord", required=false) String searchWord) {

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnSysUserDto> pageList = service.selectUserListPage(searchWord);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "events 목록 조회", description = "events 목록 조회")
    @GetMapping("/events")
    //@EnableAuth
    public ResponseEntity<?> getEventCode(@RequestParam(required = false) String keyword,
                                                            @RequestParam(required = false) String type) {
        Map<String, Object> result = service.selectEventsCodes(keyword, type);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "hazard 목록 조회", description = "hazard 목록 조회")
    @GetMapping("/hazards")
    //@EnableAuth
    ResponseEntity<?> getHazardCode(
              @RequestParam(value = "keyword", required = false, defaultValue = "") String keyword
            , @RequestParam(value = "workType", required = false, defaultValue = "") String workType)
    {
        Map<String, Object> param = new HashMap<>();
        param.put("keyword", keyword);
        param.put("workType", workType);
        if (workType == null || workType.isEmpty()) {
            param.put("workType", "avn");
        } else {
            if (!"ocu".equals(workType)) {
                throw new CustomBusinessException("hazard 조회가 실패하였습니다.");
            }
        }

        Map<String, Object> result = service.selectHazardsCodes(param);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "consequences 목록 조회", description = "consequences 목록 조회")
    @GetMapping("/consequences")
    //@EnableAuth
    public ResponseEntity<?> getConsequenceCode(@RequestParam(required = false) String keyword,
                                                                  @RequestParam(required = false) String type) {
        Map<String, Object> result = service.selectConsequenceCodes(keyword, type);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "lsc 그룹 목록 조회", description = "lsc 그룹 목록 조회")
    @GetMapping("/lscGroup")
    //@EnableAuth
    public ResponseEntity<?> getLscGroupCode(
            @RequestParam(required = false) String keyword) {
        int userId = Integer.parseInt(SecurityContextHolder.getContext().getAuthentication().getName());
        Map<String, Object> result = service.selectLscGroupCodes(keyword,userId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "lsc 그룹 추가", description = "lsc 그룹 추가")
    @PostMapping("/lscGroup")
    //@EnableAuth
    public ResponseEntity<?> addLscGroupCode(
            @RequestBody Map<String, String> body) {
        int userId = Integer.parseInt(SecurityContextHolder.getContext().getAuthentication().getName());
        String keyword = body.get("keyword");
        LscGroupDto dto = new LscGroupDto(userId,keyword);
        Map<String, Object> result = service.addLscGroupCode(dto);

        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "lsc 그룹 삭제", description = "lsc 그룹 삭제")
    @PatchMapping("/lscGroup")
    public ResponseEntity<?> deleteLscGroupCode(
            @RequestBody Map<String, Object> body) {
        int groupId = Integer.valueOf(String.valueOf(body.get("groupId")));
        LscGroupDto dto = new LscGroupDto(groupId);
        Map<String, Object> result = service.deleteLscGroupCode(dto);

        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "lsc 그룹 멤버 목록 조회(lsc 전체 멤버를 조회함)", description = "lsc 그룹 멤버 목록 조회")
    @GetMapping("/lscGroupMember")
    public ResponseEntity<?> getLscGroupMemberCode(
            @RequestParam(required = false) String keyword) {
        Map<String, Object> result = service.selectLscGroupMemberCodes(keyword);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "lsc 그룹 멤버 추가", description = "lsc 그룹 멤버 추가")
    /*   {"groupId": 103,"lscGroupMemberList": [{"empNo" : "1801855", "memberType" : "leader"}]}   */
    @PostMapping("/lscGroupMember")
    public ResponseEntity<?> addLscGroupMemberCode(
            @RequestBody Map<String,Object> body) {
        try {
            int groupId = (Integer) body.get("groupId");
            List<Map<String, Object>> lscGroupMembers = (List<Map<String, Object>>) body.get("lscGroupMemberList");

            List<LscGroupMemberDto> lscGroupMemberList = lscGroupMembers.stream().map(memberMap -> {
                LscGroupMemberDto dto = new LscGroupMemberDto();
                dto.setGroupId(groupId);
                dto.setEmpNo(String.valueOf(memberMap.get("empNo")));
                dto.setMemberType(String.valueOf(memberMap.get("memberType")));
                dto.setTimezone("Asia/Seoul");
                return dto;
            }).collect(Collectors.toList());
            List<Map<String, Object>> results = new ArrayList<>();
            for (LscGroupMemberDto dto : lscGroupMemberList) {
                Map<String, Object> result = service.addLscGroupMemberCode(dto);
                results.add(result);
            }
            return ResponseUtil.createSuccessResponse(results);
        } catch (DataIntegrityViolationException e) {
            throw new CustomBusinessException("이미 추가된 사용자입니다.");
            //throw new MicroServiceException(HttpStatus.BAD_REQUEST, 400, "이미 추가된 사용자입니다.");
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
            //throw new MicroServiceException(HttpStatus.INTERNAL_SERVER_ERROR, 500, "System Error");
        }
    }

    @Operation(summary = "lsc 그룹 멤버 수정", description = "lsc 그룹 멤버 수정")
    @PutMapping("/lscGroupMember")
    public ResponseEntity<?> updateLscGroupMemberCode(
            @RequestBody Map<String,Object> body) {
        try {
            int groupId = (Integer) body.get("groupId");
            List<Map<String, Object>> lscGroupMembers = (List<Map<String, Object>>) body.get("lscGroupMemberList");

            List<LscGroupMemberDto> lscGroupMemberList = lscGroupMembers.stream().map(memberMap -> {
                LscGroupMemberDto dto = new LscGroupMemberDto();
                dto.setGroupId(groupId);
                dto.setEmpNo((String) memberMap.get("empNo"));
                dto.setMemberType((String) memberMap.get("memberType"));
                dto.setTimezone("Asia/Seoul");
                return dto;
            }).collect(Collectors.toList());

            service.deleteLscGroupMemberCode(groupId);

            List<Map<String, Object>> results = new ArrayList<>();
            for (LscGroupMemberDto dto : lscGroupMemberList) {
                Map<String, Object> result = service.updateLscGroupMemberCode(dto);
                results.add(result);
            }
            return ResponseUtil.createSuccessResponse(results);
        } catch (DataIntegrityViolationException e) {
            throw new CustomBusinessException("이미 추가된 사용자입니다.");
            //throw new MicroServiceException(HttpStatus.BAD_REQUEST, 400, "이미 추가된 사용자입니다.");
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
            //throw new MicroServiceException(HttpStatus.INTERNAL_SERVER_ERROR, 500, "System Error");
        }
    }



    @Operation(summary = "리스크 매트릭스 최초 조회", description = "리스크 매트릭스 최초 조회 API")
    @GetMapping(value = "/risk-matrix-info")
    public ResponseEntity<?> getRiskMatrixList(
        @RequestParam(required = false) Integer eventId,
        @RequestParam(required = false) Integer consequenceId,
        @RequestParam(required = false) String reportType,
        @RequestParam(required = false) Integer hazardId,
        @RequestParam(required = false) String fromDt,
        @RequestParam(required = false) String toDt
    ) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("eventId", eventId);
        paramMap.put("consequenceId", consequenceId);
        paramMap.put("reportType", reportType);
        paramMap.put("hazardId", hazardId);
        paramMap.put("fromDt", fromDt);
        paramMap.put("toDt", toDt);

        Map<String, Object> rtnMap = new HashMap<>();
        rtnMap.put("event", service.selectEventList(paramMap));
        rtnMap.put("hazard", service.selectHazardList(paramMap));
        rtnMap.put("consequence", service.selectConsequenceList(paramMap));

        rtnMap.put("riskMatrix", service.selectRiskMatrixList(paramMap));
        rtnMap.put("riskPbbt", commService.selectCodeList("CODE_GRP_172"));
        rtnMap.put("riskSvrt", commService.selectCodeList("CODE_GRP_173"));

        return ResponseUtil.createSuccessResponse(rtnMap);

    }

    @Operation(summary = "리스크 매트릭스 조회조건 변경마다 이벤트/해저드/잠재결과/리스크 리스트 조회", description = "리스크 매트릭스 조회조건 변경마다 이벤트/해저드/잠재결과/리스크 리스트 조회 API")
    @GetMapping(value = "/risk-matrix-change")
    public ResponseEntity<?> getHazardConsequenceList(
        @RequestParam(required = false) Integer eventId,
        @RequestParam(required = false) Integer consequenceId,
        @RequestParam(required = false) String reportType,
        @RequestParam(required = false) Integer hazardId,
        @RequestParam(required = false) String selectEventYn,
        @RequestParam(required = false) String selectHazardYn,
        @RequestParam(required = false) String selectConsequenceYn,
        @RequestParam(required = false) String fromDt,
        @RequestParam(required = false) String toDt
    ) {

        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("eventId", eventId);
        paramMap.put("consequenceId", consequenceId);
        paramMap.put("reportType", reportType);
        paramMap.put("hazardId", hazardId);
        paramMap.put("selectEventYn", selectEventYn);
        paramMap.put("selectHazardYn", selectHazardYn);
        paramMap.put("selectConsequenceYn", selectConsequenceYn);
        paramMap.put("fromDt", fromDt);
        paramMap.put("toDt", toDt);

        Map<String, Object> rtnMap = new HashMap<>();
        rtnMap.put("event", service.selectEventList(paramMap));
        rtnMap.put("hazard", service.selectHazardList(paramMap));
        rtnMap.put("consequence", service.selectConsequenceList(paramMap));

        rtnMap.put("riskMatrix", service.selectRiskMatrixList(paramMap));

        return ResponseUtil.createSuccessResponse(rtnMap);

    }


    /**
     * 권한 체크를 통한 검색 조건 데이터
     */
    @Operation(summary = "보고서 검색 팝업 조건 Setting", description = "보고서 검색 팝업 조건 Setting")
    @GetMapping("/condition")
    //@EnableAuth
    public ResponseEntity<?> getSearchCondition(
            @RequestParam(required = false) boolean isInvestigationReport,
            @RequestParam(required = false) boolean searchASR) {
        try {
            List<TbSysCodeDto> resultList = commService.selectCodeList("CODE_GRP_092");

            List<SearchConditionDto> result = Collections.emptyList();

            List<String> authList = new ArrayList<>();
            authList.add("report_popsearch");
            List<String> reportAuthority = service.getAuthReportList(authList);

            if (reportAuthority != null) {
                List<SearchConditionDto> children = new ArrayList<>();

                if (isInvestigationReport) {
                    List<String> investigationReportType = Arrays.asList("asr", "csr", "dsr", "msr", "gsr");
                    resultList.stream().filter(code -> investigationReportType.contains(code.getCodeId()))
                            .forEach(code -> children.add(SearchConditionDto.of(code)));
                } else if (searchASR) {
                    for (TbSysCodeDto code : resultList) {
                        if (code.getCodeId().toString().equalsIgnoreCase("asr")) {
                            children.add(SearchConditionDto.of(code));
                            break;
                        }
                    }
                } else {
                    if (reportAuthority.contains("all_report")) {
                        resultList.forEach(code -> children.add(SearchConditionDto.of(code)));
                    } else {
                        resultList.stream().filter(code -> reportAuthority.contains(code.getCodeId()))
                                .forEach(code -> children.add(SearchConditionDto.of(code)));
                    }
                }

                SearchConditionDto all = SearchConditionDto
                        .builder()
                        .value("all")
                        .nameKo("모두")
                        .nameEn("All")
                        .children(children)
                        .build();

                result = Arrays.asList(all);
            }
            return ResponseUtil.createSuccessResponse(result);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    /**
     * 리포트 검색
     */
    @Operation(summary = "보고서 검색 처리", description = "보고서 검색 처리")
    //@EnableAuth
    @GetMapping("/reports")
    public ResponseEntity<?> getDocuments(ReportSearchDto.GET_Request dto) {
        if (dto.getMultipleValue() == null) {
            List<String> multipleValue = dto.isSearchInvestigation() ?
                    Arrays.asList("asr", "csr", "dsr", "msr", "gsr") : checkReportType();
            dto.setMultipleValue(multipleValue);
        }
        PageHelper.startPage(dto.getPageNum(), dto.getPageSize());
        List<String> reportEvents = getReportEvents(dto.getMultipleValue());

        PageInfo<SmSearchReport> dataSource = service.selectSearchReports(dto.toEntity(reportEvents));

//			timezone 설정이 LOC 일때 사용.. 현재는 KST로 고정
//			ObjectMapper mapper = new ObjectMapper();
//			Map<String, String> metaMap = mapper.readValue(meta, Map.class);
//			String timezone = metaMap.get("timezone");

        return ResponseUtil.createSuccessResponse(dataSource);
    }

    /**
     * 그룹 리포트 검색
     */
    @Operation(summary = "그룹 보고서 검색 처리", description = "그룹 보고서 검색 처리")
    //@EnableAuth
    @GetMapping("/group/reports")
    public ResponseEntity<?> getGroupDocuments(ReportSearchDto.GET_Request dto) {
        if (dto.getOneValue() == null) {
            throw new CustomBusinessException("System Error");
        }

        List<String> authList = new ArrayList<>();
        authList.add("report_acceptance");
        List<String> reportAuthority = service.getAuthReportList(authList);
        // size가 0인경우는 allList
        if (reportAuthority.size() > 0) {
            if (!reportAuthority.contains(dto.getOneValue())) {
                throw new CustomBusinessException("System Error");
            }
        }

        PageHelper.startPage(dto.getPageNum(), dto.getPageSize());
        PageInfo<SmSearchReport> dataSource = service.selectSearchGroupReports(dto.toEntity(dto.getOneValue()));
        return ResponseUtil.createSuccessResponse(dataSource);
    }

    private List<String> checkReportType() {
        List<String> authList = new ArrayList<>();
        authList.add("report_popsearch");
        List<String> reportAuthority = service.getAuthReportList(authList);

        if (reportAuthority != null) {
            if (reportAuthority.contains("all_report")) {
                return null;
            } else {
                return reportAuthority;
            }
        }
        return Collections.emptyList();
    }

    private List<String> getReportEvents(List<String> reportTypes) {
        List<String> codes = reportTypes;

        if (reportTypes == null) {
            List<TbSysCodeDto> resultList = commService.selectCodeList("CODE_GRP_092");
            codes = resultList.stream()
                    .map(code -> code.getCodeId().toString())
                    .collect(Collectors.toList());
        }

        return codes.stream()
                .filter(code -> !(code.equals("foqa") || code.equals("hzr")))
                .collect(Collectors.toList());
    }


    /**
     * 결재 그룹 목록 조회
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전조사 조사보고서 결재 그룹 목록 조회", description = "안전조사 조사보고서 결재 그룹 목록 조회 API")
    @GetMapping(value = "/approvalGroupList")
    public ResponseEntity<?> getApprovalGroupList()
    {
        List<AvnIvReportApprovalGroup> approvalGroupList = service.selectApprovalGroupList();
        return ResponseUtil.createSuccessResponse(approvalGroupList);
    }

    /**
     * 결재 그룹 멤버 목록 조회
     * @param groupId the group id
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전조사 조사보고서 결재 그룹 멤버 목록 조회", description = "안전조사 조사보고서 결재 그룹 멤버 목록 조회 API")
    @GetMapping(value = "/approvalGroupMemberList")
    public ResponseEntity<?> getApprovalGroupMemberList(@RequestParam(value="groupId", required=false) Integer groupId)
    {
        List<AvnIvReportApprovalGroupMember> approvalGroupMemberList = service.selectApprovalGroupMemberList(groupId);
        List<TbAvnSysUserDto> userList = new ArrayList<>();
        for(AvnIvReportApprovalGroupMember memberInfo : approvalGroupMemberList){
            TbAvnSysUserDto userData = service.searchEmpNoUserInfo(memberInfo);
            userList.add(userData);
        }

        HashMap<String,Object> resultData = new HashMap<String, Object>();

        resultData.put("approvalGroupMember",approvalGroupMemberList);
        resultData.put("GroupMemberInfo",userList);

        return ResponseUtil.createSuccessResponse(resultData);
    }

    @Operation(summary = "조사보고서 결재 그룹 등록", description = "조사보고서 결재 그룹 등록 API")
    @PostMapping(value = "/approval")
    public ResponseEntity<?> insertIvApprovalGroup(@Valid @RequestBody(required=true) AvnIvReportApproval avnIvReportApproval) {

        service.insertIvApprovalGroup(avnIvReportApproval);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "결재 그룹 삭제", description = "결재그룹 삭제 API")
    @DeleteMapping(value = "/approval/group/delete/{groupId}")
    public ResponseEntity<?> deleteGroup(@PathVariable(value="groupId", required=true) int groupId) {

        service.deleteIvApprovalGroup(groupId);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "결재 그룹 멤버 삭제", description = "결재그룹 삭제 API")
    @DeleteMapping(value = "/approval/group/member/delete/{groupId}/{memberEmpNo}")
    public ResponseEntity<?> deleteGroupMember(@PathVariable(value="groupId", required=true) int groupId
            ,@PathVariable(value="memberEmpNo", required=true) String memberEmpNo) {

        AvnIvReportApprovalGroupMember avnIvReportApprovalGroupMember = new AvnIvReportApprovalGroupMember();
        avnIvReportApprovalGroupMember.setGroupId(groupId);
        avnIvReportApprovalGroupMember.setEmpNo(memberEmpNo);

        service.deleteIvApprovalGroupMember(avnIvReportApprovalGroupMember);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "결재 그룹 멤버 초기화", description = "결재 그룹 멤버 초기화 API")
    @DeleteMapping(value = "/approval/group/member/init/{groupId}")
    public ResponseEntity<?> deleteGroupMember(@PathVariable(value="groupId", required=true) int groupId) {

        service.initIvApprovalGroupMember(groupId);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "경감조치 팀원 조회", description = "경감조치 팀원 조회")
    @GetMapping("/deptUser/{deptId}")
    public ResponseEntity<?> getDeptUser(
            @PathVariable String deptId,
            @RequestParam(value="keyword", required=false)  String keyword
    ) {
        Map<String, Object> param = new HashMap<>();
        param.put("deptId", deptId);
        param.put("keyword", keyword);
        List<TbAvnSysUserDto> result = service.selectDepUserList(param);
        return ResponseUtil.createSuccessResponse(result);
    }
}
