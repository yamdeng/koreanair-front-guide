package com.koreanair.ksms.avn.sftp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.github.pagehelper.util.StringUtil;
import com.koreanair.ksms.avn.sftp.service.AvnSafetyCommitteeService;
import com.koreanair.ksms.common.dto.TbAvnSafeConferenceDto;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 안전정책 - 안전회의체
 */
@Tag(name = "AvnSafetyCommittee", description = "안전정책 - 안전회의체 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyCommitteeController {

    @Autowired
    AvnSafetyCommitteeService service;

    /**
     * 안전회의체 목록 조회
     *
     * @param pageNum the page number
     * @param pageSize the page size
     * @param division the division
     * @param conferenceYear the conference year
     * @param conferenceTitle the conference title
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전회의체 목록 조회", description = "안전회의체 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "division", description = "부문"),
            @Parameter(name = "conferenceYear", description = "회의연도"),
            @Parameter(name = "conferenceTitle", description = "회의제목"),
    })
    @GetMapping(value = "/policy/committee")
    public ResponseEntity<?> getCommitteeList(@RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="division", required=false) String division
            ,@RequestParam(value="conferenceYear", required=false, defaultValue = "") String conferenceYear
            ,@RequestParam(value="conferenceTitle", required=false) String conferenceTitle
            ,@RequestParam(value="conferenceType", required=false) String conferenceType) {

        TbAvnSafeConferenceDto tbAvnSafeConferenceDto = new TbAvnSafeConferenceDto();
        tbAvnSafeConferenceDto.setDivisionCd(division);
        // TODO conferenceYear에 null 값이 들어올때 확인
        if(!StringUtil.isEmpty(conferenceYear) && conferenceYear != null) {
            conferenceYear = conferenceYear.substring(0, 4);
            tbAvnSafeConferenceDto.setConferenceDt(conferenceYear);
        }
        tbAvnSafeConferenceDto.setConferenceSubjectNm(conferenceTitle);
        tbAvnSafeConferenceDto.setConferenceTypeCd(conferenceType);

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnSafeConferenceDto> pageList = service.selectCommitteeList(tbAvnSafeConferenceDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    /**
     * 안전회의체 회의구분별 count 조회
     *
     * @param division the division
     * @param conferenceYear the conference year
     * @param conferenceTitle the conference title
     * @return the list
     * @throws Exception the exception
     */
    @Parameters({
            @Parameter(name = "division", description = "부문"),
            @Parameter(name = "conferenceYear", description = "회의연도"),
            @Parameter(name = "conferenceTitle", description = "회의제목"),
    })
    @Operation(summary = "안전회의체 회의구분별 count 조회", description = "안전회의체 회의구분별 count 조회 API")
    @GetMapping(value = "/policy/committee/groupCount")
    public ResponseEntity<?> getCommitteeGroupCount(@RequestParam(value="division", required=false) String division
            ,@RequestParam(value="conferenceYear", required=false) String conferenceYear
            ,@RequestParam(value="conferenceTitle", required=false) String conferenceTitle) {

        TbAvnSafeConferenceDto tbAvnSafeConferenceDto = new TbAvnSafeConferenceDto();
        tbAvnSafeConferenceDto.setDivisionCd(division);
        if(!conferenceYear.isEmpty()) {
            conferenceYear = conferenceYear.substring(0, 4);
            tbAvnSafeConferenceDto.setConferenceDt(conferenceYear);
        }
        tbAvnSafeConferenceDto.setConferenceSubjectNm(conferenceTitle);

        List<TbAvnSafeConferenceDto> groupCount = service.selectCommitteeGroupCount(tbAvnSafeConferenceDto);
        return ResponseUtil.createSuccessResponse(groupCount);
    }

    @Operation(summary = "안전회의체 상세정보 조회", description = "안전회의체 상세정보 조회 API")
    @GetMapping(value = "/policy/committee/{safeConferenceId}")
    public ResponseEntity<?> getCommitteeInfo(@PathVariable(value="safeConferenceId", required=true) int safeConferenceId) {

        TbAvnSafeConferenceDto tbAvnSafeConferenceDto = service.selectCommitteeInfo(safeConferenceId);
        return ResponseUtil.createSuccessResponse(tbAvnSafeConferenceDto);
    }

    @Operation(summary = "신규 안전회의체 등록", description = "신규 안전회의체 등록 API")
    @PostMapping(value = "/policy/committee")
    public ResponseEntity<?> insertCommittee(@Valid @RequestBody(required=true) TbAvnSafeConferenceDto tbAvnSafeConferenceDto) {

        service.insertCommittee(tbAvnSafeConferenceDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전회의체 정보 수정", description = "안전회의체 정보 수정 API")
    @PutMapping(value = "/policy/committee/{safeConferenceId}")
    public ResponseEntity<?> updateCommittee(
            @PathVariable(value="safeConferenceId", required=true) int safeConferenceId,
            @Valid @RequestBody(required=true) TbAvnSafeConferenceDto tbAvnSafeConferenceDto) {

        tbAvnSafeConferenceDto.setSafetyConferenceId(safeConferenceId);
        service.updateCommittee(tbAvnSafeConferenceDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전회의체 삭제", description = "안전회의체 삭제 API")
    @DeleteMapping(value = "/policy/committee/{safeConferenceId}")
    public ResponseEntity<?> deleteCommittee(@PathVariable(value="safeConferenceId", required=true) String safeConferenceId) {
        service.deleteCommittee(safeConferenceId);
        return ResponseUtil.createSuccessResponse();
    }


}
