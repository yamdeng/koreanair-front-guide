package com.koreanair.ksms.avn.srm.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


public class HazardCommentLogDto {
	
	@Getter
	@Setter
	@AllArgsConstructor
	public static class GET_Response {
		private List<HazardCommentLogVo> commentLog;
	}


}


