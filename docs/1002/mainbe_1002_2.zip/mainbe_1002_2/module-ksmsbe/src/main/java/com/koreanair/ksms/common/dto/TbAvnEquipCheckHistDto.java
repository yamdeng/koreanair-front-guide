package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "장비점검 이력")
public class TbAvnEquipCheckHistDto extends CommonDto {
    
    @Schema(description = "점검이력ID")
    @NotBlank
    private String checkHistId;
    
    @Schema(description = "장비코드")
    @NotBlank
    private String equipCd;
    
    @Schema(description = "점검일자")
    @NotBlank
    private String checkDt;
    
    @Schema(description = "점검결과여부")
    @NotBlank
    private String checkResultYn;
    
    @Schema(description = "메모내용")
    private String notesCn;
}
