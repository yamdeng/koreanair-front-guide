package com.koreanair.ksms.avn.sftr.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TreeCodeDto extends CommonDto {
    
    @Schema(description = "코드ID : 값")
    private String codeId;
    
    @Schema(description = "코드명")
    private String codeNm;

    @Schema(description = "코드(연결할 현재코드)")
    private String cd;
    
    @Schema(description = "코드(연결할 상위코드)")
    private String upperCd;
    
    @Schema(description = "처벌코드")
    private String penaltyCd;
    
    @Schema(description = "처벌스코어코드")
    private String penaltyScoreNm;
    
    
}
