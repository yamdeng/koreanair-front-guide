package com.koreanair.ksms.avn.sfta.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SmsComprehensiveSearchDto {
    
    @Schema(description = "페이지 번호")
    private int pageNum;
    
    @Schema(description = "페이지 사이즈")
    private int pageSize;

    @Schema(description = "부문")
    private String division;
    
    @Schema(description = "보고서구분")
    private String reportType;
    
    @Schema(description = "시작일자")
    private String fromDate;
    
    @Schema(description = "종료일자")
    private String toDate;
    
    @Schema(description = "그리드")
    private String grd;
    
    @Schema(description = "구분")
    private String gubun;
    
    @Schema(description = "코드")
    private String code;
    
    
    @Builder
    public SmsComprehensiveSearchDto(
            Integer pageNum,
            Integer pageSize,
            String division,
            String reportType,
            String fromDate,
            String toDate,
            String grd,
            String gubun,
            String code
            ) {
        this.pageNum = pageNum == null ? 1 : pageNum;
        this.pageSize = pageSize == null ? 10 : pageSize;
        this.division = division;
        this.reportType = reportType;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.grd = grd;
        this.gubun = gubun;
        this.code = code;
    }
}
