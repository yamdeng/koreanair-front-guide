package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "장비점검이력")
public class TbAvnDeviceCheckHistDto extends CommonDto {
    
    @Schema(description = "점검 이력ID")
    @NotBlank
    private String checkHistId;
    
    @Schema(description = "장비코드")
    @NotBlank
    private String deviceCode;
    
    @Schema(description = "점검일자")
    @NotBlank
    private String checkDt;
    
    @Schema(description = "점검결과")
    @NotBlank
    private String checkResultYn;
    
    @Schema(description = "비고")
    @NotBlank
    private String notes;
}
