package com.koreanair.ksms.avn.main.service;

import java.util.List;
import java.util.Map;

import com.koreanair.ksms.common.dto.TbAvnBoardDto;

public interface AvnMainService {
    List<Map<String, Object>> getTopRiskList();
    List<Map<String, Object>> getReportProcessList(String userId);
    List<Map<String, Object>> getToDoList(String userId);
    List<TbAvnBoardDto> getBannerList();
    List<TbAvnBoardDto> getNoticeList();
    List<Map<String, Object>> getAccidentList();

}
