package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AvnSafetyInvestifationHazardDto {

    @Schema(description = "위해요인 Lv3 ID")
    private int lv3Id;

    @Schema(description = "위해요인 Lv3 명")
    private String lv3Name;

    @Schema(description = "위해요인 Lv3 메모")
    private String lv3Notes;

    @Schema(description = "위해요인 Lv3 표시순번")
    private int lv3ViewOrder;

    @Schema(description = "위해요인 Lv3 등록자 사번")
    private String lv3EmpNo;

    @Schema(description = "위해요인 Lv3 등록일시")
    private String lv3CreatedAt;

    @Schema(description = "위해요인 Lv2 ID")
    private int lv2Id;

    @Schema(description = "위해요인 Lv2 명")
    private String lv2Name;

    @Schema(description = "위해요인 Lv2 메모")
    private String lv2Notes;

    @Schema(description = "위해요인 Lv2 표시순번")
    private int lv2ViewOrder;

    @Schema(description = "위해요인 Lv2 등록자 사번")
    private String lv2EmpNo;

    @Schema(description = "위해요인 Lv2 등록일시")
    private String lv2CreatedAt;

    @Schema(description = "위해요인 Lv1 ID")
    private int lv1Id;

    @Schema(description = "위해요인 Lv1 명")
    private String lv1Name;

    @Schema(description = "위해요인 Lv1 메모")
    private String lv1Notes;

    @Schema(description = "위해요인 Lv1 표시순번")
    private int lv1ViewOrder;

    @Schema(description = "위해요인 Lv1 등록자 사번")
    private String lv1EmpNo;

    @Schema(description = "위해요인 Lv1 등록일시")
    private String lv1CreatedAt;

    @Schema(description = "커스텀 위해요인명")
    private String customLabel;
}
