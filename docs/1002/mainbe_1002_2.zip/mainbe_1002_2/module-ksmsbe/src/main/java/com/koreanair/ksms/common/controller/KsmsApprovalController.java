package com.koreanair.ksms.common.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.FrontErrorDto;
import com.koreanair.ksms.common.dto.TbApprovalDto;
import com.koreanair.ksms.common.dto.TbApprovalSaveDto;
import com.koreanair.ksms.common.service.KsmsApprovalService;
import com.koreanair.ksms.common.utils.CommonUtil;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 결재 컨트롤러
 */
@Tag(name = "KsmsApproval", description = "항공안전/산업안전 결재 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/com")
public class KsmsApprovalController {

    @Autowired
    KsmsApprovalService service;

    @Operation(summary = "결재 목록 조회", description = "결재 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 사이즈"),
            @Parameter(name = "dateGbn", description = "일자 구분, 요청일자(XXX)/완료일자(XXX)"),
            @Parameter(name = "fromDt", description = "검색 시작일 YYYYMMDD"),
            @Parameter(name = "toDt", description = "검색 종료일 YYYYMMDD"),
            @Parameter(name = "approvalType", description = "결재 종류. 보고서별 종결/승인요청 등(업무별 확인 필요)"),
            @Parameter(name = "reqDeptCd", description = "요청 부서코드"),
            @Parameter(name = "approvalStat", description = "상태. 제출(SUBMITTED), 승인(APPROVED), 반려(REJECTED)"),
            @Parameter(name = "empNo", description = "요청자 사번")
    })
    @GetMapping(value = "/approvals")
    public ResponseEntity<?> getApprovalList(@RequestParam final HashMap<String, Object> param) {

        String pageNumStr = (String) param.get("pageNum");
        String pageSizeStr = (String) param.get("pageSize");
        if(pageNumStr == null || "".equals(pageNumStr)) pageNumStr = "0";
        if(pageSizeStr == null || "".equals(pageSizeStr)) pageSizeStr = "10";
        int pageNum = Integer.parseInt(pageNumStr);
        int pageSize = Integer.parseInt(pageSizeStr);

        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbApprovalDto> pageList = service.selectApprovalList(param);
        return ResponseUtil.createSuccessResponse(pageList);
    }


    @Operation(summary = "결재정보 상세조회", description = "결재정보 상세조회 API")
    @GetMapping(value = "/approvals/{approvalId}")
    public ResponseEntity<?> getApprovalInfo(@PathVariable(value="approvalId", required=true) int approvalId) {

        Map<String, Object> resultMap = service.getApprovalInfo(approvalId);
        return ResponseUtil.createSuccessResponse(resultMap);
    }

    // 승인처리
    @Operation(summary = "결재정보 승인처리", description = "결재정보 승인처리 API")
    @PostMapping(value = "/approvals/approval/{approvalId}")
    public ResponseEntity<?> setApproval(@PathVariable(value="approvalId", required=true) int approvalId) {

        service.setApproval(approvalId);

        return ResponseUtil.createSuccessResponse(approvalId);
    }

    // 반려처리
    @Operation(summary = "결재정보 반려처리", description = "결재정보 반려처리 API")
    @PostMapping(value = "/approvals/reject/{approvalId}")
    public ResponseEntity<?> setReject(@PathVariable(value="approvalId", required=true) int approvalId) {

        service.setReject(approvalId);

        return ResponseUtil.createSuccessResponse(approvalId);
    }

    // 일괄승인
    @Operation(summary = "결재정보 일괄승인처리", description = "결재정보 일괄승인처리 API")
    @PostMapping(value = "/approvals/approval/batch")
    public ResponseEntity<?> setBatchApproval(@RequestBody() List<TbApprovalDto> list) {

        service.setBatchApproval(list);

        return ResponseUtil.createSuccessResponse();
    }

    // 결재정보 저장
    @Operation(summary = "결재정보 저장", description = "결재정보 저장 API")
    @PostMapping(value = "/approvals")
    public ResponseEntity<?> saveApproval(@RequestBody() TbApprovalSaveDto saveDto) {

        int approvalId = service.saveApproval(saveDto);

        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("approvalId", approvalId);

        return ResponseUtil.createSuccessResponse(resultMap);
    }
}
