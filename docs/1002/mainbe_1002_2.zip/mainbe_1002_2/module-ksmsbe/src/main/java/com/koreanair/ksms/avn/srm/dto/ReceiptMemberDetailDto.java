package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.stream.Collectors;

public class ReceiptMemberDetailDto {

    @Getter
    @Setter
    public static class GET_Request {
        @NotNull
        private int id;
        @NotNull
        private String docNo;
        @NotNull
        private String reportType;

        private String receptionPage = "/srm/analysis";
    }
    
    @Getter
    @Setter
    @Builder
    public static class GET_Response {
        private List<ReceiptMemberDto> dataSource;
        private String titleKo;
        private String titleEn;
        private String contentKo;
        private String contentEn;

        public static GET_Response of(
                GET_Request dto, 
                List<SmReceptionMember> members,
                KeNotificationTemplate template,
                SmReport report,
                String eventAt,
                String flightNo,
                String reportType
        ) {
            String docNo = dto.getDocNo();
            String receptionPage = dto.getReceptionPage();
            String reportSubject = report.getSubject();            

            String titleKo = template.getSubjectEmailKo().replace("${static_doc_no}", docNo);
            String titleEn = template.getSubjectEmailEn().replace("${static_doc_no}", docNo);
            
            String contentKo = template.getContentEmailKo()
                    .replace("${reception_page}", receptionPage)
                    .replace("${doc_no}", docNo)
                    .replace("${subject}", reportType.equals("asr") ? reportSubject : "")
                    .replace("${event_at}", reportType.equals("asr") ? eventAt : "")
                    .replace("${flight_no}", reportType.equals("asr") ? flightNo : "");
            
            String contentEn = template.getContentEmailEn()
                    .replace("${reception_page}", receptionPage)
                    .replace("${doc_no}", docNo)
                    .replace("${subject}", reportType.equals("asr") ? reportSubject : "")
                    .replace("${event_at}", reportType.equals("asr") ? eventAt : "")
                    .replace("${flight_no}", reportType.equals("asr") ? flightNo : "");

            return GET_Response.builder()
                    .dataSource(members.stream()
                    		.map(ReceiptMemberDto::of)
                    		.collect(Collectors.toList()))
                    .titleKo(titleKo)
                    .titleEn(titleEn)
                    .contentKo(contentKo)
                    .contentEn(contentEn)
                    .build();
        }
    }
	
	@Getter
	@Setter
	@Builder
	public static class ReceiptMemberDto {
		
		@JsonProperty("USER_ID")
		private int userId;
		
		@JsonProperty("DEPT_ID")
		private int deptId;
		
		@JsonProperty("EMP_NO")
		private String empNo;
		
		@JsonProperty("NAME_KOR")
		private String nameKor;
		
		@JsonProperty("NAME_ENG")
		private String nameEng;
		
		@JsonProperty("EMAIL")
		private String email;
		
		@JsonProperty("DEPT_NAME_KOR")
		private String deptNameKor;
		
		@JsonProperty("DEPT_NAME_ENG")
		private String deptNameEng;
		
		@JsonProperty("RANK_ID")
		private String rankId;
		
		@JsonProperty("RANK_NAME_KOR")
		private String rankNameKor;
		
		@JsonProperty("RANK_NAME_ENG")
		private String rankNameEng;
		
		public static ReceiptMemberDto of(SmReceptionMember entity) {
			return ReceiptMemberDto.builder()
					.userId(entity.getUserId())
					.deptId(entity.getDeptId())
					.empNo(entity.getEmpNo())
					.nameKor(entity.getNameKor())
					.nameEng(entity.getNameEng())
					.email(entity.getEmail())
					.deptNameKor(entity.getDeptNameKor())
					.deptNameEng(entity.getDeptNameEng())
					.rankId(entity.getRankId())
					.rankNameKor(entity.getRankNameKor())
					.rankNameEng(entity.getRankNameEng())
					.build();
		}
	}
	
}