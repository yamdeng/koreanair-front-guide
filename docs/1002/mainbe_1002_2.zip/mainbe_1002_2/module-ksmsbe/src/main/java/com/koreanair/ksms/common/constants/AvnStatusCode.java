package com.koreanair.ksms.common.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Getter
public class AvnStatusCode {

    /** Report Phase Code **/
    @Getter
    @AllArgsConstructor
    public enum Phase {
        REPORTING("reporting"),
        RECEPTION("reception"),
        FIRST_RISK("1st_risk"),
        ACCEPTANCE("acceptance"),
        MIT_ASSIGN("mitigation_assign"),
        MIT_ACCEPT("mitigation_accept"),
        MIT_RESULT("mitigation_result"),
        SECOND_RISK("2nd_risk"),
        SECOND_ACCEPTANCE("2nd_acceptance"),
        HZD_CLOSE("hazard_close"),
        REPORT_CLOSE("report_close");

        private String code;

        public static Phase find(String phase) {
            return Arrays.stream(values()).filter(v -> phase.equalsIgnoreCase(v.code))
                    .findFirst().orElse(null);
        }
    }

    /** Report Step Code **/
    @Getter
    @AllArgsConstructor
    public enum Step {
        DRAFT("draft"),
        DRAFT_RESULT("draft_result"), 	// 경감조치 결과 작성중 전용
        PLANNED("planned"),				// 경감조치 계획 제출 전용
        CANCELED("canceled"),				// 위해요인 결재 전용
        SUBMITTED("submitted"),
        APPROVED("approved"),
        APPROVED_MIT("approved_mit"), 	// 위해요인 수락(경감조치 있음) 전용
        REJECTED("rejected"),
        REJECTED_MIT("rejected_mit"),		// 위해요인 반려 (경감조치 있음) 전용
        VOIDED("voided"),
        DELETED("deleted"); 			// 리포트 작성중 삭제, 위해요인 수락 반려시 삭제 용

        private String code;

        public static Step find(String phase) {
            return Arrays.stream(values()).filter(v -> phase.equalsIgnoreCase(v.code))
                    .findFirst().orElse(null);
        }
    }


    /**
     * UI의 버튼 액션 기준으로 {@link Step}을 그룹화
     * <br/>프로세스 처리시 사용
     */
    @Getter
    @AllArgsConstructor
    public enum StepType {
        SAVE("save", Arrays.asList(Step.DRAFT, Step.DRAFT_RESULT)),
        SUBMIT("submit", Arrays.asList(Step.SUBMITTED, Step.PLANNED)),
        APPROVE("approve", Arrays.asList(Step.APPROVED, Step.APPROVED_MIT, Step.DRAFT)), // 승인후 Draft로 넘어가는 케이스가 있음
        REJECT("reject", Arrays.asList(Step.REJECTED,Step.REJECTED_MIT)),
        CANCEL("cancel",Arrays.asList(Step.CANCELED)),
        VOID("void", Arrays.asList(Step.VOIDED)),
        DELETE("delete", Arrays.asList(Step.DELETED));

        private String code;
        private List<Step> stepList;

        public static StepType find(Step step) {
            return Arrays.stream(values()).filter(v -> v.hasStep(step))
                    .findFirst().orElse(null);
        }

        public boolean hasStep(Step step) {
            return stepList.stream().anyMatch(v -> v == step);
        }
    }

    /** Report State Code **/
    @Getter
    @AllArgsConstructor
    public enum State {
        DRAFT("draft"),
        OPEN("open"),
        CLOSED("closed"),
        CANCEL("canceled");

        private String code;
    }

    /** 공통 처리용 함수 Code **/
    @Getter
    @AllArgsConstructor
    public enum Action {
        /** 리포트 상태 변경 **/
        UPDATE_REPORT("updateReportStatus"),
        /** 위해요소 상태 변경 **/
        UPDATE_HAZARD("updateHazardStatus"),
        /** 리포트 권한 등록 **/
        INSERT_ROLE("insertReportRole"),
        /** 리포트 권한 삭제 **/
        DELETE_ROLE("deleteReportRole");

        private String type;
    }

    /**
     * 리포트 상태 목록 ({@link State} {@link Phase} {@link Step})
     * <br/> + 상태별 실행 함수 목록 ({@link Action}) 조합
     */
    @Getter
    @AllArgsConstructor
    public enum ReportStatus {
        REPORTING_DRAFT("reportingDraft", "리포트작성중", State.DRAFT, Phase.REPORTING, Step.DRAFT
                , Arrays.asList(Action.UPDATE_REPORT)),
        REPORTING_DELETE("reportingDelete", "리포트삭제", State.DRAFT, Phase.REPORTING, Step.DELETED
                , Arrays.asList(Action.UPDATE_REPORT)),
        REPORTING_SUBMITTED("reportingSubmitted", "리포트제출완료", State.DRAFT, Phase.REPORTING, Step.SUBMITTED
                , Arrays.asList(Action.UPDATE_REPORT, Action.INSERT_ROLE)),
        RECEPTION_DRAFT("receptionDraft", "접수중", State.OPEN, Phase.RECEPTION, Step.DRAFT
                , Arrays.asList(Action.UPDATE_REPORT)),
        RECEPTION_APPROVED("receptionApproved", "접수승인", State.OPEN, Phase.RECEPTION, Step.APPROVED
                , Arrays.asList(Action.UPDATE_REPORT, Action.INSERT_ROLE)),
        RECEPTION_REJECTED("receptionRejected", "접수거절", State.OPEN, Phase.RECEPTION, Step.REJECTED
                , Arrays.asList(Action.UPDATE_REPORT)),
        RECEPTION_VOIDED("receptionVoided", "접수무효", State.OPEN, Phase.RECEPTION, Step.VOIDED
                , Arrays.asList(Action.UPDATE_REPORT)),
        FIRST_RISK_DRAFT("firstRiskDraft", "1차위험도평가중", State.OPEN, Phase.FIRST_RISK, Step.DRAFT
                , Arrays.asList(Action.UPDATE_HAZARD)),
        FIRST_RISK_SUBMITTED("firstRiskSubmitted", "1차위험도평가제출", State.OPEN, Phase.FIRST_RISK, Step.SUBMITTED
                , Arrays.asList(Action.UPDATE_HAZARD, Action.INSERT_ROLE)),
        FIRST_RISK_DELETE("firstRiskDelete", "1차위험도평가삭제", State.OPEN, Phase.FIRST_RISK, Step.DELETED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        FIRST_RISK_VOIDED("firstRiskVoided", "1차위험도평가무효", State.OPEN, Phase.FIRST_RISK, Step.VOIDED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        ACCEPTANCE_APPROVED("acceptanceApproved", "위해요인승인(경감조치없음)", State.OPEN, Phase.ACCEPTANCE, Step.APPROVED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        ACCEPTANCE_APPROVED_MIT("acceptanceApprovedMit", "위해요인승인(경감조치있음)", State.OPEN, Phase.ACCEPTANCE, Step.APPROVED_MIT
                , Arrays.asList(Action.UPDATE_HAZARD)),
        ACCEPTANCE_REJECTED("acceptanceRejected", "위해요인반려", State.OPEN, Phase.ACCEPTANCE, Step.REJECTED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        ACCEPTANCE_VOIDED("acceptanceVoided", "위해요인무효", State.OPEN, Phase.ACCEPTANCE, Step.VOIDED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_ASSIGN_SUBMITTED("mitAssignSubmitted", "경감조치팀지정제출", State.OPEN, Phase.MIT_ASSIGN, Step.SUBMITTED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_ASSIGN_APPROVED("mitAssignApproved", "경감조치팀지정승인", State.OPEN, Phase.MIT_ASSIGN, Step.APPROVED
                , Arrays.asList(Action.UPDATE_HAZARD,Action.INSERT_ROLE)),
        MIT_ASSIGN_REJECTED("mitAssignRejected", "경감조치팀지정반려", State.OPEN, Phase.MIT_ASSIGN, Step.REJECTED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_ASSIGN_VOIDED("mitAssignVoided", "경감조치팀지정무효", State.OPEN, Phase.MIT_ASSIGN, Step.VOIDED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_ACCEPT_APPROVED("mitAcceptApproved", "경감조치수행팀장승인", State.OPEN, Phase.MIT_ACCEPT, Step.APPROVED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_ACCEPT_REJECTED("mitAcceptRejected", "경감조치수행팀장반려", State.OPEN, Phase.MIT_ACCEPT, Step.REJECTED
                , Arrays.asList(Action.UPDATE_HAZARD, Action.DELETE_ROLE)),
        MIT_ACCEPT_VOIDED("mitAcceptVoided", "경감조치팀장무효", State.OPEN, Phase.MIT_ACCEPT, Step.VOIDED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_RESULT_DRAFT("mitResultDraft", "경감조치계획작성중", State.OPEN, Phase.MIT_RESULT, Step.DRAFT
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_RESULT_PLANNED("mitResultPlanned", "경감조치계획제출", State.OPEN, Phase.MIT_RESULT, Step.PLANNED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_RESULT_DRAFT_RESULT("mitResultDraftResult", "경감조치결과작성중",State.OPEN, Phase.MIT_RESULT, Step.DRAFT_RESULT
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_RESULT_SUBMITTED("mitResultSubmitted", "경감조치결과제출", State.OPEN, Phase.MIT_RESULT, Step.SUBMITTED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        MIT_RESULT_VOIDED("mitResultVoided", "경감조치무효", State.OPEN, Phase.MIT_RESULT, Step.VOIDED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        SECOND_RISK_DRAFT("secondRiskDraft", "2차위험도평가작성중", State.OPEN, Phase.SECOND_RISK, Step.DRAFT
                , Arrays.asList(Action.UPDATE_HAZARD)),
        SECOND_RISK_SUBMITTED("secondRiskSubmitted", "2차위험도평가제출", State.OPEN, Phase.SECOND_RISK, Step.SUBMITTED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        SECOND_RISK_APPROVED("secondRiskApproved", "경감조치결과승인", State.OPEN, Phase.SECOND_RISK, Step.APPROVED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        SECOND_RISK_REJECTED("secondRiskRejected", "경감조치결과반려", State.OPEN, Phase.SECOND_RISK, Step.REJECTED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        SECOND_RISK_VOIDED("secondRiskVoided", "2차위험도평가무효", State.OPEN, Phase.SECOND_RISK, Step.VOIDED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        SECOND_RISK_CANCELD("secondRiskCanceld","2차위험도평가제출취소",State.OPEN,Phase.SECOND_RISK,Step.CANCELED,
                Arrays.asList(Action.UPDATE_HAZARD)),
        SECOND_ACCEPTANCE_APPROVED("secondacceptanceApproved", "위해요인승인(경감조치있음)", State.OPEN, Phase.SECOND_ACCEPTANCE, Step.APPROVED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        SECOND_ACCEPTANCE_REJECTED("secondacceptanceRejected", "위해요인반려", State.OPEN, Phase.SECOND_ACCEPTANCE, Step.REJECTED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        SECOND_ACCEPTANCE_VOIDED("secondacceptanceVoided", "위해요인무효", State.OPEN, Phase.SECOND_ACCEPTANCE, Step.VOIDED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        HZD_CLOSE_APPROVED("hzdCloseApproved", "위해요인종결", State.CLOSED, Phase.HZD_CLOSE, Step.APPROVED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        HZD_CLOSE_REJECTED("hzdCloseRejected", "위해요인반려(경감조치 없음)", State.OPEN, Phase.HZD_CLOSE, Step.REJECTED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        HZD_CLOSE_REJECTED_MIT("hzdCloseRejectedMit", "위해요인반려(경감조치 있음)", State.OPEN, Phase.HZD_CLOSE, Step.REJECTED_MIT
                , Arrays.asList(Action.UPDATE_HAZARD)),
        HZD_CLOSE_VOIDED("hzdCloseVoided", "위해요인무효", State.CLOSED, Phase.HZD_CLOSE, Step.VOIDED
                , Arrays.asList(Action.UPDATE_HAZARD)),
        REPORT_CLOSE_APPROVED("reportCloseApproved", "승인", State.CLOSED, Phase.REPORT_CLOSE, Step.APPROVED
                , Arrays.asList(Action.UPDATE_REPORT));


        private String code;
        private String name;
        private State state;
        private Phase phase;
        private Step step;
        private List<Action> actionList;

        public static ReportStatus find(String phase, String step) {
            return Arrays.stream(values()).filter( v ->
                    v.getPhase().code.equalsIgnoreCase(phase) && v.getStep().code.equalsIgnoreCase(step)
            ).findFirst().orElse(null);
        }

    }

    /**
     * *HAZARD 상태별 프로세스 정의  <p>
     * 현재 상태({@link ReportStatus})와 처리가능한 상태({@link ReportStatus})목록
     */
    @Getter
    @AllArgsConstructor
    public enum HazardProcess {
        // [1차위험도 평가]
        FIRST_RISK_DRAFT(ReportStatus.FIRST_RISK_DRAFT, // 작성: 제출, VOID
                Arrays.asList(ReportStatus.FIRST_RISK_DRAFT, ReportStatus.FIRST_RISK_SUBMITTED, ReportStatus.FIRST_RISK_VOIDED)),
        FIRST_RISK_SUBMITTED(ReportStatus.FIRST_RISK_SUBMITTED, //제출: [위해요인 수락 단계] 승인, 승인(경강조치), 반려, VOID, (LSC)종결
                Arrays.asList(ReportStatus.ACCEPTANCE_APPROVED, ReportStatus.ACCEPTANCE_APPROVED_MIT
                        , ReportStatus.ACCEPTANCE_REJECTED, ReportStatus.ACCEPTANCE_VOIDED, ReportStatus.REPORT_CLOSE_APPROVED)),
        FIRST_RISK_VOIDED(ReportStatus.FIRST_RISK_VOIDED, Collections.emptyList()), // VOID
        // [위해요인 수락]
        ACCEPTANCE_APPROVED(ReportStatus.ACCEPTANCE_APPROVED, // 승인: [위해요인 결재 단계] 승인, 반려
                Arrays.asList(ReportStatus.HZD_CLOSE_APPROVED, ReportStatus.HZD_CLOSE_REJECTED)),
        ACCEPTANCE_APPROVED_MIT(ReportStatus.ACCEPTANCE_APPROVED_MIT, // 승인(경감조치): [경감조치(수행팀 지정) 단계] 제출, VOID
                Arrays.asList(ReportStatus.MIT_ASSIGN_SUBMITTED, ReportStatus.MIT_ASSIGN_VOIDED)),
        ACCEPTANCE_REJECTED(ReportStatus.ACCEPTANCE_REJECTED, // 반려: [1차위험도평가 단계] 작성, 제출, 삭제, VOID
                Arrays.asList(ReportStatus.FIRST_RISK_DRAFT, ReportStatus.FIRST_RISK_SUBMITTED
                        , ReportStatus.FIRST_RISK_DELETE, ReportStatus.FIRST_RISK_VOIDED)),
        ACCEPTANCE_VOIDED(ReportStatus.ACCEPTANCE_VOIDED, Collections.emptyList()), // VOID
        // [경감조치(수행팀 지정)]
        MIT_ASSIGN_SUBMITTED(ReportStatus.MIT_ASSIGN_SUBMITTED, // 제출: 승인, 반려, VOID
                Arrays.asList(ReportStatus.MIT_ASSIGN_APPROVED, ReportStatus.MIT_ASSIGN_REJECTED, ReportStatus.MIT_ASSIGN_VOIDED)),
        MIT_ASSIGN_APPROVED(ReportStatus.MIT_ASSIGN_APPROVED, // 승인: [경감조치(수행팀장 승인) 단계] 승인, 반려, VOID
                Arrays.asList(ReportStatus.MIT_ACCEPT_APPROVED, ReportStatus.MIT_ACCEPT_REJECTED, ReportStatus.MIT_ACCEPT_VOIDED)),
        MIT_ASSIGN_REJECTED(ReportStatus.MIT_ASSIGN_REJECTED, // 반려: 제출, VOID
                Arrays.asList(ReportStatus.MIT_ASSIGN_SUBMITTED, ReportStatus.MIT_ASSIGN_VOIDED)),
        MIT_ASSIGN_VOIDED(ReportStatus.MIT_ASSIGN_VOIDED, Collections.emptyList()), // VOID
        // [경감조치(수행팀장 승인)]
        MIT_ACCEPT_APPROVED(ReportStatus.MIT_ACCEPT_APPROVED, // 승인: [경감조치(계획/결과 작성) 단계] 작성, 계획제출
                Arrays.asList(ReportStatus.MIT_RESULT_DRAFT, ReportStatus.MIT_RESULT_PLANNED)),
        MIT_ACCEPT_REJECTED(ReportStatus.MIT_ACCEPT_REJECTED, // 반려: [경감조치(수행팀 지정) 단계] 제출, VOID
                Arrays.asList(ReportStatus.MIT_ASSIGN_SUBMITTED, ReportStatus.MIT_ASSIGN_VOIDED)),
        MIT_ACCEPT_VOIDED(ReportStatus.MIT_ACCEPT_VOIDED, Collections.emptyList()), // VOID
        // [경감조치(계획/결과 작성)]
        MIT_RESULT_DRAFT(ReportStatus.MIT_RESULT_DRAFT, // 작성: 저장, 계획제출, VOID
                Arrays.asList(ReportStatus.MIT_RESULT_DRAFT, ReportStatus.MIT_RESULT_PLANNED, ReportStatus.MIT_RESULT_VOIDED)),
        MIT_RESULT_PLANNED(ReportStatus.MIT_RESULT_PLANNED, // 계획제출: 결과작성, 제출, VOID
                Arrays.asList(ReportStatus.MIT_RESULT_DRAFT_RESULT, ReportStatus.MIT_RESULT_SUBMITTED, ReportStatus.MIT_RESULT_VOIDED)),
        MIT_RESULT_DRAFT_RESULT(ReportStatus.MIT_RESULT_DRAFT_RESULT, // 결과작성: 저장,제출, VOID
                Arrays.asList(ReportStatus.MIT_RESULT_DRAFT_RESULT,ReportStatus.MIT_RESULT_SUBMITTED, ReportStatus.MIT_RESULT_VOIDED)),
        MIT_RESULT_SUBMITTED(ReportStatus.MIT_RESULT_SUBMITTED, // 제출: [2차 위험도평가 단계] 작성, 승인, 반려, VOID
                Arrays.asList(ReportStatus.SECOND_RISK_DRAFT, ReportStatus.SECOND_RISK_APPROVED
                        , ReportStatus.SECOND_RISK_REJECTED, ReportStatus.SECOND_RISK_VOIDED)),
        MIT_RESULT_VOIDED(ReportStatus.MIT_RESULT_VOIDED, Collections.emptyList()), // VOID

        // [2차 위험도평가]
        SECOND_RISK_DRAFT(ReportStatus.SECOND_RISK_DRAFT, // 작성: 저장, 승인, 반려, VOID
                Arrays.asList(ReportStatus.SECOND_RISK_DRAFT, ReportStatus.SECOND_RISK_SUBMITTED
                        , ReportStatus.SECOND_RISK_REJECTED, ReportStatus.SECOND_RISK_VOIDED)),
        SECOND_RISK_SUBMITTED(ReportStatus.SECOND_RISK_SUBMITTED, // 작성제출: [2차 위해요인 단계] 승인, 반려, 무효
                Arrays.asList(ReportStatus.SECOND_ACCEPTANCE_APPROVED,ReportStatus.SECOND_ACCEPTANCE_REJECTED, ReportStatus.SECOND_ACCEPTANCE_VOIDED)),
        SECOND_RISK_APPROVED(ReportStatus.SECOND_RISK_APPROVED, // 승인: 작성, 작성제출
                Arrays.asList(ReportStatus.SECOND_RISK_DRAFT, ReportStatus.SECOND_RISK_SUBMITTED, ReportStatus.HZD_CLOSE_VOIDED)),
        SECOND_RISK_REJECTED(ReportStatus.SECOND_RISK_REJECTED, // 반려: [경감조치(계획/결과 작성) 단계] 결과작성, 제출
                Arrays.asList(ReportStatus.MIT_RESULT_DRAFT_RESULT, ReportStatus.MIT_RESULT_SUBMITTED)),
        SECOND_RISK_VOIDED(ReportStatus.SECOND_RISK_VOIDED, Collections.emptyList()), // VOID
        SECOND_RISK_CANCELD(ReportStatus.SECOND_RISK_CANCELD,Arrays.asList(ReportStatus.SECOND_RISK_DRAFT,
                ReportStatus.SECOND_RISK_SUBMITTED,ReportStatus.SECOND_RISK_VOIDED)),// 취소: [작성,작성제출,무효]

        // [2차 위해요인 수락]
        SECOND_ACCEPTANCE_APPROVED(ReportStatus.SECOND_ACCEPTANCE_APPROVED, // 승인: [위해요인 결재 단계] 승인, 반려
                Arrays.asList(ReportStatus.HZD_CLOSE_APPROVED, ReportStatus.HZD_CLOSE_REJECTED)),
        SECOND_ACCEPTANCE_REJECTED(ReportStatus.SECOND_ACCEPTANCE_REJECTED, // 반려: [2차위험도평가 단계] 작성, 제출
                Arrays.asList(ReportStatus.SECOND_RISK_DRAFT, ReportStatus.SECOND_RISK_SUBMITTED)),
        SECOND_ACCEPTANCE_VOIDED(ReportStatus.SECOND_ACCEPTANCE_VOIDED, Collections.emptyList()), // VOID

        // [위해요인 결재]
        HZD_CLOSE_APPROVED(ReportStatus.HZD_CLOSE_APPROVED, // 승인: 리포트종결, *경감조치 유효성 평가(안전보증)에서 반려처리시 MIT_RESULT_DRAFT
                Arrays.asList(ReportStatus.REPORT_CLOSE_APPROVED, ReportStatus.MIT_RESULT_DRAFT)),
        HZD_CLOSE_REJECTED(ReportStatus.HZD_CLOSE_REJECTED, // 반려: [SSC 리뷰] 승인 반려
                Arrays.asList(ReportStatus.ACCEPTANCE_APPROVED,ReportStatus.ACCEPTANCE_REJECTED)),
        HZD_CLOSE_REJECTED_MIT(ReportStatus.HZD_CLOSE_REJECTED_MIT, // 반려: [2차 위험도평가 단계] 작성, 승인
                Arrays.asList(ReportStatus.SECOND_RISK_APPROVED, ReportStatus.SECOND_RISK_REJECTED)),
        HZD_CLOSE_VOIDED(ReportStatus.HZD_CLOSE_VOIDED, Collections.emptyList()); // VOID

        private ReportStatus status;
        private List<ReportStatus> process;

        public static HazardProcess find(String phase, String step) {
            return Arrays.stream(values()).filter(v -> v.status.equals(ReportStatus.find(phase, step))).findFirst()
                    .orElse(null);
        }

        public ReportStatus findProc(String stepType) {
            return process.stream().filter(e -> StepType.find(e.getStep()).getCode().equals(stepType))
                    .findFirst().orElse(null);
        }

        public ReportStatus findProc(StepType stepType) {
            return process.stream().filter(e -> StepType.find(e.getStep()) == stepType)
                    .findFirst().orElse(null);
        }
    }

    /**
     * *REPORT 상태별 프로세스 정의  <p>
     * 현재 상태({@link ReportStatus})와 처리가능한 상태({@link ReportStatus})목록
     */
    @Getter
    @AllArgsConstructor
    public enum ReportProcess {
        // [리포트 작성]
        REPORTING_DRAFT(
                ReportStatus.REPORTING_DRAFT, // 작성: 저장, 제출, 삭제(작성자)
                Arrays.asList(
                        ReportStatus.REPORTING_DRAFT,
                        ReportStatus.REPORTING_SUBMITTED,
                        ReportStatus.REPORTING_DELETE)),
        REPORTING_SUBMITTED(
                ReportStatus.REPORTING_SUBMITTED, //제출: [접수 단계] 저장, 승인, VOID
                Arrays.asList(
                        ReportStatus.RECEPTION_DRAFT,
                        ReportStatus.RECEPTION_APPROVED,
                        ReportStatus.RECEPTION_REJECTED,
                        ReportStatus.RECEPTION_VOIDED)),
        // [접수]
        RECEPTION_DRAFT(
                ReportStatus.RECEPTION_DRAFT, // 접수대기: 저장, 승인, 거절, VOID
                Arrays.asList(
                        ReportStatus.RECEPTION_DRAFT,
                        ReportStatus.RECEPTION_APPROVED,
                        ReportStatus.RECEPTION_REJECTED,
                        ReportStatus.RECEPTION_VOIDED)),
        RECEPTION_APPROVED(
                ReportStatus.RECEPTION_APPROVED, // 접수승인: [1차위험도평가 단계] 작성, 제출
                Arrays.asList(
                        ReportStatus.FIRST_RISK_DRAFT,
                        ReportStatus.FIRST_RISK_SUBMITTED,
                        ReportStatus.RECEPTION_VOIDED)),
        RECEPTION_REJECTED(
                ReportStatus.RECEPTION_REJECTED, // 접수반려: [리포트 작성 단계] 작성, 제출, 삭제
                Arrays.asList(
                        ReportStatus.REPORTING_DRAFT,
                        ReportStatus.REPORTING_SUBMITTED,
                        ReportStatus.REPORTING_DELETE,
                        ReportStatus.RECEPTION_VOIDED)),
        RECEPTION_VOIDED(
                ReportStatus.RECEPTION_VOIDED,
                Collections.emptyList()), // VOID
        // [리포트 종결]
        REPORT_CLOSE_APPROVED(
                ReportStatus.REPORT_CLOSE_APPROVED,
                Arrays.asList(
                        ReportStatus.RECEPTION_VOIDED));
//				Collections.emptyList());

        private ReportStatus status;
        private List<ReportStatus> process;

        public static ReportProcess find(String phase, String step) {
            return Arrays.stream(values())
                    .filter(v -> v.status.equals(ReportStatus.find(phase, step)))
                    .findFirst()
                    .orElse(null);
        }

        public ReportStatus findProc(String stepType) {
            return process.stream()
                    .filter(e -> StepType.find(e.getStep()).getCode().equals(stepType))
                    .findFirst()
                    .orElse(null);
        }

        public ReportStatus findProc(StepType stepType) {
            return process.stream()
                    .filter(e -> StepType.find(e.getStep()) == stepType)
                    .findFirst()
                    .orElse(null);
        }
    }

    /** 리포트 타입별 Role Code - 권한 부여시 사용 **/
    @Getter
    @AllArgsConstructor
    public enum RoleByReport {
        FOQA_REPORT("FOQA", "FMG", Arrays.asList("SA", "PVG", "FMG", "FVG")),
        ASR_REPORT("ASR", "AMG", Arrays.asList("SA", "PVG", "AMG", "AVG")),
        CSR_REPORT("CSR", "CMG", Arrays.asList("SA", "PVG", "CMG", "CVG")),
        MSR_REPORT("MSR", "MMG", Arrays.asList("SA", "PVG", "MMG", "MVG")),
        GSR_REPORT("GSR", "GMG", Arrays.asList("SA", "PVG", "GMG", "GVG")),
        DSR_REPORT("DSR", "DMG", Arrays.asList("SA", "PVG", "DMG", "DVG")),
        RSR_REPORT("RSR", "RMG", Arrays.asList("SA", "PVG", "RMG")),
        HZR_REPORT("HZR", "HMG", Arrays.asList("SA", "PVG", "HMG"));

        //TODO khw 추가되는 레포트 정의 필요
        
        
        private String reportType;
        private String managerRoleCd;
        private List<String> roleCdList;

        public static RoleByReport find(String reportType) {
            return Arrays.stream(values()).filter(v -> v.reportType.equalsIgnoreCase(reportType))
                    .findFirst().orElse(null);
        }
    }
}
