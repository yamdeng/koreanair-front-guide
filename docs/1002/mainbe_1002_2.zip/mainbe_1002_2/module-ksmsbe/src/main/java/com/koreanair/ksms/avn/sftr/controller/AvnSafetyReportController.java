package com.koreanair.ksms.avn.sftr.controller;

import java.util.*;

import com.koreanair.ksms.avn.srm.dto.SearchConditionDto;
import com.koreanair.ksms.common.dto.TbSysCodeDto;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sftr.dto.ReportSearchDto;
import com.koreanair.ksms.avn.sftr.dto.TreeCodeDto;
import com.koreanair.ksms.avn.sftr.service.AvnSafetyReportService;
import com.koreanair.ksms.avn.srm.dto.ReportProcessVo;
import com.koreanair.ksms.avn.srm.service.AvnReportProcessService;
import com.koreanair.ksms.common.constants.AvnStatusCode.StepType;
import com.koreanair.ksms.common.dto.TbAvnReportDto;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * 안전보고서 - My Report, Report List
 */
@Tag(name = "AvnSafetyReport", description = "안전보고서 - My Report, Report List API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyReportController {

    @Autowired
    AvnSafetyReportService service;
    
    @Autowired
    AvnReportProcessService serviceProcess;

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    /**
     * My Report 목록 조회
     *
     * @param paramMap the search Map
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Report 목록 조회", description = "My Report 목록 조회 API")
    @GetMapping(value = "/report/my-reports")
    public ResponseEntity<?> getMyReportList(@RequestParam Map<String, Object> paramMap) {
        ReportSearchDto reportSearchDto = 
        ReportSearchDto.builder()
                        .pageNum( Integer.parseInt(paramMap.get("pageNum").toString()))
                        .pageSize( Integer.parseInt(paramMap.get("pageSize").toString()))
                        .reportTypeCd( paramMap.get("reportTypeCd") != null ? paramMap.get("reportTypeCd").toString() : "")
                        .reportPhaseCd( paramMap.get("reportPhaseCd") != null ? paramMap.get("reportPhaseCd").toString() : "")
                        .subjectNm( paramMap.get("subjectNm") != null ? paramMap.get("subjectNm").toString() : "")
                        .fromDate( paramMap.get("fromDate") != null ? paramMap.get("fromDate").toString() : "")
                        .toDate( paramMap.get("toDate") != null ? paramMap.get("toDate").toString() : "")
                        .build();

        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        reportSearchDto.setEmpNo(userInfo.getEmpNo());

        List<String> authList = new ArrayList<>();
        authList.add("reporting");
        List<String> reportAuthority = avnCommonService.getAuthReportList(authList);

        if (reportAuthority != null) {
            if (reportAuthority.contains("all_report")) {
                reportAuthority = Collections.emptyList();
            }
        }
        reportSearchDto.setReportList(reportAuthority);

        // Page 조회
        PageHelper.startPage(reportSearchDto.getPageNum(), reportSearchDto.getPageSize());
        PageInfo<TbAvnReportDto> pageList = service.selectMyReportList(reportSearchDto);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    /**
     * My Report 단계별 Count 조회
     *
     * @param paramMap the search Map
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Report 단계별 Count 조회", description = "My Report 단계별 Count 조회 API")
    @GetMapping(value = "/report/my-reports/cnt")
    public ResponseEntity<?> getMyReportCountInfo(@RequestParam Map<String, Object> paramMap) {
        ReportSearchDto reportSearchDto =
                ReportSearchDto.builder()
                        .pageNum(paramMap.get("pageNum") != null && !paramMap.get("pageNum").toString().isEmpty()
                                ? Integer.parseInt(paramMap.get("pageNum").toString())
                                : 1)
                        .pageSize(paramMap.get("pageSize") != null && !paramMap.get("pageSize").toString().isEmpty()
                                ? Integer.parseInt(paramMap.get("pageSize").toString())
                                : 10)
//                        .pageSize( Integer.parseInt(paramMap.get("pageSize").toString()))
                        .reportTypeCd( paramMap.get("reportTypeCd") != null ? paramMap.get("reportTypeCd").toString() : "")
                        .reportPhaseCd( paramMap.get("reportPhaseCd") != null ? paramMap.get("reportPhaseCd").toString() : "")
                        .subjectNm( paramMap.get("subjectNm") != null ? paramMap.get("subjectNm").toString() : "")
                        .fromDate( paramMap.get("fromDate") != null ? paramMap.get("fromDate").toString() : "")
                        .toDate( paramMap.get("toDate") != null ? paramMap.get("toDate").toString() : "")
                        .build();

        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        reportSearchDto.setEmpNo(userInfo.getEmpNo());

        List<String> authList = new ArrayList<>();
        authList.add("reporting");
        List<String> reportAuthority = avnCommonService.getAuthReportList(authList);

        if (reportAuthority != null) {
            if (reportAuthority.contains("all_report")) {
                reportAuthority = Collections.emptyList();
            }
        }
        reportSearchDto.setReportList(reportAuthority);

        // Page 조회
        Map<String, Object> countInfo = service.selectMyReportCountInfo(reportSearchDto);

        return ResponseUtil.createSuccessResponse(countInfo);
    }



    /**
     * My Report 상세 조회
     *
     * @param paramMap the search Map
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Report 상세 단건 조회", description = "My Report 상세 단건 조회 API")
    @GetMapping(value = "/report/my-reports/{reportId}")
    public ResponseEntity<?> getMyReportDetail(
        @PathVariable(value="reportId", required=true) int reportId
        ) {
        
        Map<String, Object> rtnMap = service.selectMyReportDetail(reportId);

        return ResponseUtil.createSuccessResponse(rtnMap);
    }

    /**
     * 레포트 신규 저장
     *
     * @param tbAvnReportDto TbAvnReportDto form 구분자 : "report"
     * @param ASR  개별 보고서 form 구분자 : "reportAsr"
     * @param ASRDTL 개별 보고서 상세 구분자 : "reportDtl"
     * @param flight 비행정보 구분자 : "flight"
     * @param flight_crew 비행승무원정보 구분자 : "flightCrew"
     * @return success
     * @throws IllegalArgumentException 
     * @throws JsonProcessingException 
     * @throws Exception the exception
     */
    @Operation(summary = "레포트 신규 저장", description = "레포트 신규 저장 API")
    @PostMapping(value = "/report/reportInsert")
    public ResponseEntity<?> insertReport(@RequestBody ObjectNode saveObj) throws JsonProcessingException, IllegalArgumentException {


        Integer reportId = service.insertReport(saveObj);
        return ResponseUtil.createSuccessResponse(reportId);
    }

    /**
     * 레포트 수정
     *
     * @param reportId report Key
     * @param tbAvnReportDto TbAvnReportDto form 구분자 : "report"
     * @param ASR  개별 보고서 form 구분자 : "reportAsr"
     * @param ASRDTL 개별 보고서 상세 구분자 : "reportDtl"
     * @param flight 비행정보 구분자 : "flight"
     * @param flight_crew 비행승무원정보 구분자 : "flightCrew"
     * @return success
     * @throws IllegalArgumentException 
     * @throws JsonProcessingException 
     * @throws Exception the exception
     */
    @Operation(summary = "레포트 수정", description = "레포트 수정 API")
    @PutMapping(value = "/report/reportUpdate/{reportId}")
    public ResponseEntity<?> updateReport(
        @PathVariable(value="reportId", required=true) int reportId,
        @RequestBody ObjectNode saveObj
    ) throws JsonProcessingException, IllegalArgumentException {


        service.updateReport(reportId, saveObj);
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 레포트 삭제
     *
     * @param reportId report Key
     * @param tbAvnReportDto TbAvnReportDto form 구분자 : "report"
     * @param ASR  개별 보고서 form 구분자 : "reportAsr"
     * @param ASRDTL 개별 보고서 상세 구분자 : "reportDtl"
     * @param flight 비행정보 구분자 : "flight"
     * @param flight_crew 비행승무원정보 구분자 : "flightCrew"
     * @return success
     * @throws IllegalArgumentException 
     * @throws JsonProcessingException 
     * @throws Exception the exception
     */
    @Operation(summary = "레포트 삭제", description = "레포트 삭제 API")
    @DeleteMapping(value = "/report/reportDelete/{reportId}")
    public ResponseEntity<?> deleteReport(
        @PathVariable(value="reportId", required=true) int reportId
    ) throws JsonProcessingException, IllegalArgumentException {


        service.deleteReport(reportId);
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 레포트 제출
     *
     * @param reportId report Key
     * @param tbAvnReportDto TbAvnReportDto form 구분자 : "report"
     * @param ASR  개별 보고서 form 구분자 : "reportAsr"
     * @param ASRDTL 개별 보고서 상세 구분자 : "reportDtl"
     * @param flight 비행정보 구분자 : "flight"
     * @param flight_crew 비행승무원정보 구분자 : "flightCrew"
     * @return success
     * @throws Exception the exception
     */
    @Operation(summary = "레포트 제출", description = "레포트 제출 API")
    @PutMapping(value = "/report/reportSubmit")
    public ResponseEntity<?> submitReport(@RequestBody ObjectNode saveObj) throws Exception {

        Integer reportId = service.submitReport(saveObj);

        String regUsrId = SecurityContextHolder.getContext().getAuthentication().getName();
        ReportProcessVo proccessVo = new ReportProcessVo(0, reportId, regUsrId, StepType.SUBMIT);
        boolean success = serviceProcess.smsReportProcess(proccessVo);

        return ResponseUtil.createSuccessResponse(reportId);
    }


    /**
     * Report List 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Report List 조회", description = "Report List 조회 API")
    @GetMapping(value = "/report/all-reports")
    public ResponseEntity<?> getAllReportList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }
    
    /**
     * 트리구조 코드 조회
     *
     * @param String codeId
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Report 트리구조 코드리스트 조회", description = "My Report 트리구조 코드리스트 조회 API(CODE_GRP_157 / CODE_GRP_158 / CODE_GRP_160)")
    @GetMapping(value = "/report/my-reports/tree-code/{codeId}")
    public ResponseEntity<?> getTreeCodeList(
        @PathVariable(value="codeId", required=true) String codeId
        ) {
        
        List<TreeCodeDto> rtnMap = service.selectTreeCodeList(codeId);

        return ResponseUtil.createSuccessResponse(rtnMap);
    }

}
