package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import lombok.experimental.Accessors;

import java.util.List;

@Getter
@Setter
@ToString
@Accessors(chain = true)
@Schema(description = "보고서 접수 상세 파라메터")
public class ReportInfoDto {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @ToString
    public static class GET_Request {

        @Schema(description = "group id")
        private Integer p_groupId;

        @Schema(description = "step Number")
        private Integer p_step;

        //@Schema(description = "보고서 타입")
        //private String p_reportType;

        @Schema(description = "hazard id")
        private Integer p_hazardId;

        @Schema(description = "role list")
        private List<String> p_roleList;

        @Schema(description = "사원번호")
        private String p_empNo;

        @Schema(description = "업무명")
        private String p_resourceName="";

        private boolean p_isView;
    }

    private Integer p_lscUserId;


}
