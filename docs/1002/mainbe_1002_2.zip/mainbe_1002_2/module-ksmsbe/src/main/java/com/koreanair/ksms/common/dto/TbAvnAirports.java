package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbAvnAirports {

    @Schema(description = "코드그룹ID")
    private String codeGrpId;

    @Schema(description = "코드ID")
    private String codeId;

    @Schema(description = "코드명(한국어)")
    private String codeNameKor;

    @Schema(description = "코드명(영어)")
    private String codeNameEng;

    @Schema(description = "예비필드1")
    private String codeField1;

    @Schema(description = "예비필드2")
    private String codeField2;

    @Schema(description = "예비필드3")
    private String codeField3;

    @Schema(description = "예비필드4")
    private String codeField4;

    @Schema(description = "예비필드5")
    private String codeField5;

    @Schema(description = "예비영문필드1")
    private String codeEnField1;

    @Schema(description = "예비영문필드2")
    private String codeEnField2;

    @Schema(description = "예비영문필드3")
    private String codeEnField3;

    @Schema(description = "예비영문필드4")
    private String codeEnField4;

    @Schema(description = "예비영문필드5")
    private String codeEnField5;

    @Schema(description = "예비숫자필드1")
    private String codeCoField1;

    @Schema(description = "예비숫자필드2")
    private String codeCoField2;

    @Schema(description = "예비숫자필드3")
    private String codeCoField3;

    @Schema(description = "예비숫자필드4")
    private String codeCoField4;

    @Schema(description = "예비숫자필드5")
    private String codeCoField5;

    @Schema(description = "정렬순서")
    private int sortOrder;
    
    @Schema(description = "사용여부")
    private String useYn;

    @Schema(description = "비고")
    private String remark;
    
    @Schema(description = "라벨")
    private String label;
    
    @Schema(description = "항공Code")
    private String airportCode;
}
