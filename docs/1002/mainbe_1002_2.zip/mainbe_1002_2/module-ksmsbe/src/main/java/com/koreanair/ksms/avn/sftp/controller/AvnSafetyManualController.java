package com.koreanair.ksms.avn.sftp.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sftp.service.AvnSafetyManualService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnManualDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전정책 - 안전 Manual
 */
@Tag(name = "AvnSafetyManual", description = "안전정책 - 안전 Manual API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyManualController {

    @Autowired
    AvnSafetyManualService service;

    /**
     * 안전Manual 목록 조회
     *
     * @param pageNum the page number
     * @param pageSize the page size
     * @param jobType the job type
     * @param manualName the manual name
     * @param languageType the language type
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전Manual 목록 조회", description = "안전Manual 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "jobType", description = "업무구분"),
            @Parameter(name = "manualName", description = "매뉴얼명"),
            @Parameter(name = "languageType", description = "언어구분"),
    })
    @GetMapping(value = "/policy/manuals")
    public ResponseEntity<?> getManualList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="jobType", required=false) String jobType
            ,@RequestParam(value="manualName", required=false) String manualName
            ,@RequestParam(value="languageType", required=false) String languageType) {

        //조회 조건 parameter
        TbAvnManualDto tbAvnManualDto = new TbAvnManualDto();
        tbAvnManualDto.setJobTypeCd(jobType);            //업무구분
        tbAvnManualDto.setManualNm(manualName);      //매뉴얼명
        tbAvnManualDto.setLanguageTypeCd(languageType);  //언어구분

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnManualDto> pageList = service.selectSafetyManualList(tbAvnManualDto);
        // 전체 조회
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "안전Manual 상세정보 조회", description = "안전Manual 상세정보 조회 API")
    @GetMapping(value = "/policy/manuals/{manualId}")
    public ResponseEntity<?> getManualInfo(@PathVariable(value="manualId", required=true) int manualId) {

        TbAvnManualDto result = service.selectSafetyManualInfo(manualId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 안전Manual 등록", description = "신규 안전Manual 등록 API")
    @PostMapping(value = "/policy/manuals")
    public ResponseEntity<?> insertManual(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전Manual 정보 수정", description = "안전Manual 정보 수정 API")
    @PutMapping(value = "/policy/manuals/{manualId}")
    public ResponseEntity<?> updateManual(
            @PathVariable(value="manualId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전Manual 삭제", description = "안전Manual 삭제 API")
    @DeleteMapping(value = "/policy/manuals/{manualId}")
    public ResponseEntity<?> deleteManual(@PathVariable(value="manualId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
