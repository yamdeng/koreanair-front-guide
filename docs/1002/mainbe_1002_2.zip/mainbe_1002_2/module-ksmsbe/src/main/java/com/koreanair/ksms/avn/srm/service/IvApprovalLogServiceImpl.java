package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.IvApprovalLog;
import org.springframework.stereotype.Service;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class IvApprovalLogServiceImpl extends AbstractBaseService implements IvApprovalLogService{

    @Override
//    @Transactional(rollbackFor = SQLException.class)
    public IvApprovalLog insertApprovalLog(IvApprovalLog log) {
        commonSql.insert("AvnSafetyInvestigation.insertApprovalLog", log);

        return null;
    }

    @Override
    public IvApprovalLog findLastLogByReportId(int reportId) {
        return commonSql.selectOne("AvnSafetyInvestigation.findApprovalLogByReportId", reportId);
    }
}
