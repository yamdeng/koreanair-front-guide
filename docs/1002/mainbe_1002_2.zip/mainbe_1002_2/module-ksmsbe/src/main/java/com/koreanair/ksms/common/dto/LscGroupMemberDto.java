package com.koreanair.ksms.common.dto;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class LscGroupMemberDto extends CommonDto
{
    private int id;
    private int groupId;
    private String empNo;
    private String memberType;
    private String timezone;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    public LscGroupMemberDto(int groupId, String empNo) {
        super();
        this.groupId = groupId;
        this.empNo = empNo;
    }
    public Map<String,Object>getMap() {
        HashMap<String,Object> res = new HashMap<String,Object>();
        res.put("groupId", groupId);
        res.put("empNo", empNo);
        res.put("memberType", memberType);
        res.put("timezone", "Asia/Seoul");
        res.put("regUserId", this.getRegUserId());
        res.put("updUserId", this.getUpdUserId());
        return res;
    }
}
