package com.koreanair.ksms.avn.sftr.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class ReportSearchDto extends CommonDto {
    
    @Schema(description = "페이지 번호")
    private int pageNum;
    
    @Schema(description = "페이지 사이즈")
    private int pageSize;

    @Schema(description = "레포트ID")
    private Integer reportId;
    
    @Schema(description = "부문코드")
    private String divisionCd;
    
    @Schema(description = "보고서구분코드")
    private String reportTypeCd;
    
    @Schema(description = "보고서단계코드")
    private String reportPhaseCd;
    
    @Schema(description = "보고서상태코드")
    private String reportStatusCd;
    
    @Schema(description = "제목명")
    private String subjectNm;

    @Schema(description = "시작일자")
    private String fromDate;
    
    @Schema(description = "종료일자")
    private String toDate;
    
    @Schema(description = "그리드")
    private String grd;
    
    @Schema(description = "구분")
    private String gubun;
    
    @Schema(description = "코드")
    private String code;

    @Schema(description = "사용자NO")
    private String empNo;

    @Schema(description = "사용자 권한에 맞는 보고서 리스트")
    private List<String> reportList;
    
    @Builder
    public ReportSearchDto(
            Integer reportId,
            Integer pageNum,
            Integer pageSize,
            String divisionCd,
            String reportTypeCd,
            String reportPhaseCd,
            String reportStatusCd,
            String subjectNm,
            String fromDate,
            String toDate,
            String grd,
            String gubun,
            String code
            ) {
        this.reportId = reportId;
        this.pageNum = pageNum == null ? 1 : pageNum;
        this.pageSize = pageSize == null ? 10 : pageSize;
        this.divisionCd = divisionCd;
        this.reportTypeCd = reportTypeCd;
        this.reportPhaseCd = reportPhaseCd;
        this.reportStatusCd = reportStatusCd;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.grd = grd;
        this.gubun = gubun;
        this.code = code;
        this.subjectNm = subjectNm;

    }
}
