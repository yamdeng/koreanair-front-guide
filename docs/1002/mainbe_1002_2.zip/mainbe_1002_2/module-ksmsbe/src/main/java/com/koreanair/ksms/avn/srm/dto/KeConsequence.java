package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KeConsequence {
    @NotNull
    private int id;
    @NotNull
    private String empNo;
    @NotNull
    private String reportType;
    @NotNull
    private String nameKo;

    private String nameEn;
    @NotNull
    private int viewOrder;

    private String state;
    @NotNull
    private String createdAt;

    private String deletedAt;
}
