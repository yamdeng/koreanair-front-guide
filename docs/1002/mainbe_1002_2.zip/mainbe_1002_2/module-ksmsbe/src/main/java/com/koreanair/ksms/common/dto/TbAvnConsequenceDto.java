package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "잠재적결과")
public class TbAvnConsequenceDto extends CommonDto {
    
    @Schema(description = "잠재결과ID")
    @NotBlank
    private String consequenceId;
    
    @Schema(description = "리포트유형코드")
    @NotBlank
    private String reportTypeCd;
    
    @Schema(description = "잠재결과국문명")
    @NotBlank
    private String consequenceKoNm;
    private String consequenceKoNmStr;
    
    @Schema(description = "잠재결과영문명")
    private String consequenceEnNm;
    private String consequenceEnNmStr;
    
    @Schema(description = "표시순번")
    @NotBlank
    private String viewSn;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "메모내용")
    private String notesCn;
    
    @Schema(description = "삭제자ID")
    private String delUserId;
    
    @Schema(description = "삭제일시")
    private String delDttm;
}
