package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "변화관리")
public class TbAvnChangeMgmtDto extends CommonDto {
    
    @Schema(description = "변화관리ID")
    @NotBlank
    private String changeMgmtId;
    
    @Schema(description = "변화관리연도")
    @NotBlank
    private String changeMgmtYear;
    
    @Schema(description = "부문코드")
    private String divisionCd;
    
    @Schema(description = "사원번호")
    private String empNo;
    
    @Schema(description = "시작일자")
    private String fromDt;
    
    @Schema(description = "끝일자")
    private String toDt;
    
    @Schema(description = "변화텍스트내용")
    private String changeTxtcn;
    
    @Schema(description = "링크그룹SEQ")
    private String linkGroupSeq;
    
    @Schema(description = "파일그룹SEQ")
    private String fileGroupSeq;
}
