package com.koreanair.ksms.avn.sftr.service;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sftr.dto.CentralizedGroupDto;
import com.koreanair.ksms.avn.sftr.dto.CentralizedReportDto;
import com.koreanair.ksms.avn.sftr.dto.CentralizedReportSearchDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AvnCentralizedReportServiceImpl extends AbstractBaseService implements AvnCentralizedReportService {

    @Override
    public PageInfo<CentralizedGroupDto> selectCentralizedGroupList(CentralizedReportSearchDto reportSearchDto) {
        List<CentralizedGroupDto> pageList = commonSql.selectList("AvnCentralizedReport.selectCentralizedGroupList", reportSearchDto);
        return PageInfo.of(pageList);
    }

    @Override
    public List<CentralizedReportDto> selectCentralizedReportList(CentralizedGroupDto param) {
        return commonSql.selectList("AvnCentralizedReport.selectCentralizedReportList", param);
    }

    @Override
    public CentralizedGroupDto selectCentralizedGroupReportInfo(CentralizedGroupDto param) {
        CentralizedGroupDto groupReportInfo = commonSql.selectOne("AvnCentralizedReport.selectCentralizedGroupInfo", param);
        groupReportInfo.setReportList(commonSql.selectList("AvnCentralizedReport.selectCentralizedReportList", param));
        return groupReportInfo;
    }

    @Override
    @Transactional(rollbackFor={Exception.class})
    public void updateCentralizedGroup(CentralizedGroupDto param) throws CustomBusinessException {
        commonSql.update("AvnCentralizedReport.updateCentralizedGroup", param);
    };

    @Override
    @Transactional(rollbackFor={Exception.class})
    public void insertCentralizedReport(CentralizedGroupDto param) throws CustomBusinessException {
        commonSql.insert("AvnCentralizedReport.insertCentralizedReport", param);
    }

    @Override
    @Transactional(rollbackFor={Exception.class})
    public void deleteCentralizedReport(CentralizedGroupDto param) throws CustomBusinessException {
        commonSql.delete("AvnCentralizedReport.deleteCentralizedReport", param);
    };










    @Transactional
    public void insertBatchCentralizedReport() {
        List<CentralizedGroupDto> flightList = commonSql.selectList("AvnCentralizedReport.selectFlightList");

        CentralizedGroupDto param = new CentralizedGroupDto();
        for (CentralizedGroupDto flightInfo : flightList) {

            //CentralizedReport 조회하여 있을 경우 키값 가져옴
            Integer id = commonSql.selectOne("AvnCentralizedReport.selectCentralizedId", flightInfo);
            if (id != null && id > 0) {
                flightInfo.setId(id);
            } else {
                commonSql.insert("AvnCentralizedReport.insertAutoCentralizedGroup", flightInfo);
            }

            List<Integer> reportList = commonSql.selectList("AvnCentralizedReport.selectCentralizedReportId", flightInfo);
            for (Integer reportId : reportList) {
                flightInfo.setReportId(reportId);
                commonSql.insert("AvnCentralizedReport.insertAutoCentralizedReport", flightInfo);
            }
        }
    }
}
