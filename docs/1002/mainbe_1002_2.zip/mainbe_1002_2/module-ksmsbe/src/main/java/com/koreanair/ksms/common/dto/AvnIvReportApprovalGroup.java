package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AvnIvReportApprovalGroup extends CommonDto {

    @Schema(description = "그룹ID")
    private int id;

    @Schema(description = "사용자ID")
    private int userId;

    @Schema(description = "그룹명")
    private String groupName;

    @Schema(description = "삭제일자")
    private String deletedAt;

    @Schema(description = "타임존")
    private String timezone;

    @Schema(description = "그룹등록여부")
    private String insertGroupFlag;
}
