package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "결재상세정보")
public class TbApprovalDtlDto extends CommonDto {

    @Schema(description = "ID")
    @NotBlank
    private int approvalEmpId;

    @Schema(description = "approval ID")
    @NotBlank
    private int approval_id;

    @Schema(description = "결재순서")
    @NotBlank
    private String approval_seq;

    @Schema(description = "사원번호")
    @NotBlank
    private String emp_no;

    @Schema(description = "결재코드(approved/rejected)")
    @NotBlank
    private String step_code;

    @Schema(description = "사유(의견)")
    private String reason;
}
