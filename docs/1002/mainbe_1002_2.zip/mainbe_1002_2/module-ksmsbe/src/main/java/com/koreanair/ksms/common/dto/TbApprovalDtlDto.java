package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "결재상세정보")
public class TbApprovalDtlDto extends CommonDto {

    @Schema(description = "ID")
    @NotBlank
    private int approvalEmpId;

    @Schema(description = "approval ID")
    @NotBlank
    private int approvalId;

    @Schema(description = "결재순서")
    @NotBlank
    private String approvalSeq;

    @Schema(description = "사원번호")
    @NotBlank
    private String empNo;
    private String empNmKor;
    private String empNmEng;

    @Schema(description = "결재코드(approved/rejected)")
    @NotBlank
    private String stepCode;

    @Schema(description = "사유(의견)")
    private String reason;
}
