package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "장비코드 관리")
public class TbAvnDeviceCodeMgmtDto extends CommonDto {
    
    @Schema(description = "장비코드")
    @NotBlank
    private String deviceCode;
    
    @Schema(description = "장비명")
    @NotBlank
    private String deviceName;
    
    @Schema(description = "모델명")
    private String modelName;
    
    @Schema(description = "자사구분(자사/타사)")
    private String companyType;
    
    @Schema(description = "부서")
    private String division;
    
    @Schema(description = "업체명")
    private String companyName;
    
    @Schema(description = "제작일자")
    private String productionDt;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
}
