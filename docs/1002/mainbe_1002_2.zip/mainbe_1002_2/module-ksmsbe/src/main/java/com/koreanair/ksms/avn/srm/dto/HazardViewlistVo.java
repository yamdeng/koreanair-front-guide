package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HazardViewlistVo extends SmReportHazard {
	
	private String docNo;

	private String reportType;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "Asia/Seoul")
	private Timestamp receiptedAt;
	
	private String receiptEmpNo;
	
	private int receiptDeptId;
	
	private String subject;

	private String lv3Name;

	private String lv2Name;

	private String lv1Name;

	private String consequenceKo;

	private String consequenceEn;

	private String riskLevel1;
	
	private int firstScore;

	private String riskLevel2;
	
	private int secondScore;
	
	private int mitigationDeptId;

	private String mitigationDeptNameKo;

	private String mitigationDeptNameEn;

	private String mitigationResult;
	
	private String action;
	
	private String statusKo;
	
	private String statusEn;
	
	private String reason;
	
	private String mitigationEmpNo;
	
	private String mitigationLeaderEmpNo;
	
	private String mitigationMemberEmpNoList;
	
	private String lscLeaderEmpNo;
	
	private String lscMember;
	
	private String nameKo;
	
	private String nameEn;
	
	private String isConfidential;
	
	private String contents;

	MitigationResultVo detailInfo;

	private String realMitigationPerform;
	
}
