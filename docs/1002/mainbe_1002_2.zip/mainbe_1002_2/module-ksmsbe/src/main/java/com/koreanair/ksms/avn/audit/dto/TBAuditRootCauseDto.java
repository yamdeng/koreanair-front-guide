package com.koreanair.ksms.avn.audit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
@Schema(description = "Audit / Root Cause")
public class TBAuditRootCauseDto extends CommonDto {
    private int rootCauseId;
    private String level1Ko;
    private String level2Ko;
    private String level3Ko;
    private String level4Ko;
    private String level1En;
    private String level2En;
    private String level3En;
    private String level4En;
    private String codeValue;
    private String causalFators;
    private int viewOrder;
    private String timezone;
    private String state;
}
