package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "보고서 Hzd Event")
public class ReceiptHzrVo extends SmReceptionHzr {

    private String name;

}

