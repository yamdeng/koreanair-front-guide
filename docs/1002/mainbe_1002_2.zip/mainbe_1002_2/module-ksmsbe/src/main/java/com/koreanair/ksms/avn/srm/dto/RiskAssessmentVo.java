package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RiskAssessmentVo extends SmReport {
    private String linkUrl;
    private List<SmReportHazardVo> reportHazardList;
    private List<SmReportHazardVo> reportHazardOcuList;
    private List<SmReportHazardVo> deleteList;
    private boolean isLeader;
    private boolean isMember;

    private boolean visibleNote = true;

    private List<PoFileVo> attachment;
    private String earNo;
    private String isHf;

    @Schema(description = "항공Hzd여부(HZD)")
    private String isAvnHzd;

    @Schema(description = "산업Hzd여부(HZD)")
    private String isOcuHzd;

    @Schema(description = "안전Hzd여부(HZD)")
    private String isSftyHzd ;

    //@Schema(description = "LSC종결여부")
    //private String isLscClose;

    //@Schema(description = "산업안전종결여부")
    //private String isOcuClose;


}