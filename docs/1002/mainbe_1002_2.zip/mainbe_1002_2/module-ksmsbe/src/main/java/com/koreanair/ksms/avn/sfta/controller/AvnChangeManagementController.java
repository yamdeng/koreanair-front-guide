package com.koreanair.ksms.avn.sfta.controller;

import com.koreanair.ksms.avn.sfta.service.AvnChangeManagementService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전보증 - 변화관리
 */
@Tag(name = "AvnChangeManagement", description = "안전보증 - 변화관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnChangeManagementController {

    @Autowired
    AvnChangeManagementService service;

    /**
     * 변화관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "변화관리 목록 조회", description = "변화관리 목록 조회 API")
    @GetMapping(value = "/assurance/changes")
    public ResponseEntity<?> getChangeList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "변화관리 상세정보 조회", description = "변화관리 상세정보 조회 API")
    @GetMapping(value = "/assurance/changes/{changeId}")
    public ResponseEntity<?> getChangeInfo(@PathVariable(value="changeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 변화관리 등록", description = "신규 변화관리 등록 API")
    @PostMapping(value = "/assurance/changes")
    public ResponseEntity<?> insertChange(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "변화관리 정보 수정", description = "변화관리 정보 수정 API")
    @PutMapping(value = "/assurance/changes/{changeId}")
    public ResponseEntity<?> updateChange(
            @PathVariable(value="changeId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "변화관리 삭제", description = "변화관리 삭제 API")
    @DeleteMapping(value = "/assurance/changes/{changeId}")
    public ResponseEntity<?> deleteChange(@PathVariable(value="changeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
