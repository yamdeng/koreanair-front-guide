package com.koreanair.ksms.avn.sfta.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.koreanair.ksms.avn.sfta.dto.DashboardDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnSmsMaturityServiceImpl extends AbstractBaseService implements AvnSmsMaturityService {

    @Override
    public List<DashboardDto> selectSMSDashboardList1(String param) {
        List<DashboardDto> resultList = commonSql.selectList("AvnSmsMaturity.selectSMSDashboardList1", param);
        return resultList;
    }

    @Override
    public List<DashboardDto> selectSMSDashboardList2(String param) {
        List<DashboardDto> resultList = commonSql.selectList("AvnSmsMaturity.selectSMSDashboardList2", param);
        return resultList;
    }
}
