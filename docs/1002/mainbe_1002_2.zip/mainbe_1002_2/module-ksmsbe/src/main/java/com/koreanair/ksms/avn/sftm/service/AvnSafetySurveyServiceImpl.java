package com.koreanair.ksms.avn.sftm.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnSafetySurveyServiceImpl extends AbstractBaseService implements AvnSafetySurveyService {

    //  안전증진 > 안전문화설문 목록 조회
    @Override
    public PageInfo<TbAvnBoardDto> selectSafetySurveyList(TbAvnBoardDto tbAvnBoardDto) {
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnSafetySurvey.selectSafetySurveyList", tbAvnBoardDto);
        return PageInfo.of(resultList);
    }

    //  안전증진 > 안전문화설문 상세
    @Override
    public TbAvnBoardDto selectSafetySurveyDetail(int boardId) {
        return commonSql.selectOne("AvnSafetySurvey.selectSafetySurveyDetail", boardId);
    }
}
