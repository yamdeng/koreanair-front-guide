package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AvnSafetyInvestigationDto extends CommonDto {

    @Schema(description = "보고서 Seq")
    private int id;

    @Schema(description = "조사보고서 고유 번호(control number")
    private String reportNo;

    @Schema(description = "제목")
    private String reportTitle;

    @Schema(description = "출발시간(YYYY-MM-DD)")
    private String departureAt;

    @Schema(description = "비행기 번호")
    private String flightNo;

    @Schema(description = "비행기 유형")
    private String aircraftTypeText;

    @Schema(description = "출발공항")
    private String fromAirport;

    @Schema(description = "도착공항코드")
    private String toAirport;

    @Schema(description = "등록번호")
    private String registrationNo;

    @Schema(description = "Supply ex) 0/33/55")
    private String supply;

    @Schema(description = "체크인")
    private String checkIn;

    @Schema(description = "발생장소(location of event)")
    private String locationText;

    @Schema(description = "Occurrence Airport")
    private String airport;

    @Schema(description = "Flight Phase, ASR 의 Flight Phase GSR 의 Phase of Operation 목록 합해서 표출")
    private String flightPhase;

    @Schema(description = "최초 작성자 사원번호")
    private String empNo;

    @Schema(description = "발생시간")
    private String eventAt;

    @Schema(description = "Time of Event 타임존")
    private String eventAtTz;

    @Schema(description = "Is include SPI")
    private String isSpi;

    @Schema(description = "Classification")
    private String classification;

    @Schema(description = "삭제일자")
    private String deletedAt;

    @Schema(description = "날씨(Text)")
    private String weatherText;

    @Schema(description = "우회공항 코드, ke_airport table")
    private String divertAirport;

    @Schema(description = "최종 제출여부")
    private String isSubmitted;

    @Schema(description = "최종 제출일자")
    private String submittedAt;

    @Schema(description = "조사담당자 사번")
    private String investigateBy;

    @Schema(description = "최종 제출자 사번")
    private String submittedBy;

    @Schema(description = "결재ID")
    private String approvedId;

    @Schema(description = "비행단계명(KOR)")
    private String flightPhaseTextKo;

    @Schema(description = "비행단계명(ENG)")
    private String flightPhaseTextEn;

    @Schema(description = "Classification(KOR)")
    private String classificationTextKo;

    @Schema(description = "Classification(ENG)")
    private String classificationTextEn;

    @Schema(description = "제출자명(KOR)")
    private String submittedByTextKo;

    @Schema(description = "제출자명(ENG)")
    private String submittedByTextEn;

    @Schema(description = "단계")
    private String phase;

    @Schema(description = "단계코드")
    private String stepCode;

    @Schema(description = "상태(KOR)")
    private String statusKo;

    @Schema(description = "상태(ENG)")
    private String statusEn;

    @Schema(description = "사유")
    private String reason;

    @Schema(description = "ca결재자ID")
    private String caApprovedBy;

    @Schema(description = "종결일시")
    private String closedAt;

    @Schema(description = "안전권고 수")
    private String caListCount;

    @Schema(description = "safety 수")
    private String caSafetyListCount;

    @Schema(description = "이벤트 ID")
    private String eventId;

    @Schema(description = "이벤트명")
    private String eventNm;

    @Schema(description = "페이지 정보")
    private  String pageCode;

    @Schema(description = "페이지 수")
    private int pageNum;

    @Schema(description = "페이지 목록 수")
    private int pageSize;

    @Schema(description = "제목 - 검색")
    private String titleSearch;

    @Schema(description = "일자구분 - 검색")
    private String evnetDateTypeSearch;

    @Schema(description = "시작날짜 - 검색")
    private String startDtSearch;

    @Schema(description = "끝날짜 - 검색")
    private String endDtSearch;

    @Schema(description = "Classification - 검색")
    private String eventClassSearch;

    @Schema(description = "발생공항 - 검색")
    private String occurrenceAirportSearch;

    @Schema(description = "발생단계 - 검색")
    private String flightPhaseSearch;

    @Schema(description = "pageCode(작성, 결재, 안전권고, 종결) - 검색")
    private String pageCodeSearch;

    @Schema(description = "stepCode(각 pageCode별 stepCode) - 검색")
    private String stepCodeSearch;

}
