package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS_교육증빙")
public class TbAvnEducationProofDto extends CommonDto {
    
    @Schema(description = "교육증빙ID")
    @NotBlank
    private String educationProofId;
    
    @Schema(description = "교육ID")
    @NotBlank
    private String educationId;
    
    @Schema(description = "사원번호")
    @NotBlank
    private String empNo;
    
    @Schema(description = "부서코드")
    @NotBlank
    private String deptCd;
    
    @Schema(description = "링크그룹SEQ")
    private String linkGroupSeq;
    
    @Schema(description = "파일그룹SEQ")
    private String fileGroupSeq;
}
