package com.koreanair.ksms.avn.sfta.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.avn.sfta.dto.OpStatusDto;
import com.koreanair.ksms.avn.sfta.dto.SpiReportDto;
import com.koreanair.ksms.avn.sfta.dto.SpiStatusDto;
import com.koreanair.ksms.avn.sfta.service.AvnSpiSptService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.dto.TbAvnSpiDto;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 안전보증 - SPI/SPT
 */
@Tag(name = "AvnSpiSpt", description = "안전보증 - SPI/SPT API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSpiSptController {

    @Autowired
    AvnSpiSptService service;

    /**
     * SPI 지표 목록 조회
     *
     * @param year the search year
     * @param spiType the search spiType
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "SPI 지표 목록 조회", description = "SPI 지표 목록 조회 API")
    @Parameters({
            @Parameter(name = "year", description = "연도"),
            @Parameter(name = "spiType", description = "지표구분")
    })
    @GetMapping(value = "/assurance/spi-spt/spiCodeList")
    public ResponseEntity<?> getSPICodeList(
        @RequestParam(value="year", required=false) String year,
        @RequestParam(value="spiType", required=false) String spiType
    ) {

        SpiStatusDto tbSsSpiDto = new SpiStatusDto();
        tbSsSpiDto.setSpiYear(year);
        tbSsSpiDto.setSpiTypeCd(spiType);


        List<SpiStatusDto> rtnList = service.selectSPICodeList(tbSsSpiDto);
        
        return ResponseUtil.createSuccessResponse(rtnList);
    }

    /**
     * 운영현황 목록 조회
     *
     * @param year the search year
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "운영현황 목록 조회", description = "운영현황 목록 조회 API")
    @Parameters({
            @Parameter(name = "year", description = "연도")
    })
    @GetMapping(value = "/assurance/spi-spt/op-status")
    public ResponseEntity<?> getOpStatusList(@RequestParam(value="year", required=false) String year) {

        OpStatusDto opStatusDto = new OpStatusDto();
        opStatusDto.setYear(year);

        List<OpStatusDto> rtnList1 = service.selectOpStatusList1(opStatusDto);
        List<OpStatusDto> rtnList2 = service.selectOpStatusList2(opStatusDto);
        List<OpStatusDto> rtnList3 = service.selectOpStatusList3(opStatusDto);

        Map<String, Object> rtnMap = new HashMap<>();
        rtnMap.put("rtnMap1", rtnList1);
        rtnMap.put("rtnMap2", rtnList2);
        rtnMap.put("rtnMap3", rtnList3);
        return ResponseUtil.createSuccessResponse(rtnMap);
    }

    /**
     * SPI현황 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "SPI현황 목록 조회", description = "SPI현황 목록 조회 API")
    @GetMapping(value = "/assurance/spi-spt/spi-status")
    public ResponseEntity<?> getSpiStatusList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 게시판 목록 조회
     *
     * @param boardSearchDto the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "게시판 목록 조회", description = "게시판 목록 조회 API")
    @GetMapping(value = "/assurance/spi-spt/bulletins")
    public ResponseEntity<?> getBulletinList(@RequestParam Map<String, Object> paramMap) {

        BoardSearchDto boardSearchDto =
                BoardSearchDto
                        .builder()
                        .pageNum( Integer.parseInt(paramMap.get("pageNum").toString()))
                        .pageSize( Integer.parseInt(paramMap.get("pageSize").toString()))
                        .boardType( paramMap.get("boardType") != null ? paramMap.get("boardType").toString() : "")
                        .titleKo( paramMap.get("titleKo") != null ? paramMap.get("titleKo").toString() : "")
                        .fromDate( paramMap.get("fromDate") != null ? paramMap.get("fromDate").toString() : "")
                        .toDate( paramMap.get("toDate") != null ? paramMap.get("toDate").toString() : "")
                        .build();
        // Page 조회
        PageHelper.startPage(boardSearchDto.getPageNum(), boardSearchDto.getPageSize());
        PageInfo<TbAvnBoardDto> pageList = service.selectBoardList(boardSearchDto);

        // 전체 조회
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "게시판 상세정보 조회", description = "게시판 상세정보 조회 API")
    @GetMapping(value = "/assurance/spi-spt/bulletins/{bulletinId}")
    public ResponseEntity<?> getBulletinInfo(@PathVariable(value="bulletinId", required=true) int boardId) {

        TbAvnBoardDto result = service.selectBoardDetail(boardId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 게시판 등록", description = "신규 게시판 등록 API")
    @PostMapping(value = "/assurance/spi-spt/bulletins")
    public ResponseEntity<?> insertBulletin(@Valid @RequestBody(required=true) TbAvnBoardDto tbAvnBoardDto) {

        service.insertBoard(tbAvnBoardDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "게시판 정보 수정", description = "게시판 정보 수정 API")
    @PutMapping(value = "/assurance/spi-spt/bulletins/{bulletinId}")
    public ResponseEntity<?> updateBulletin(
            @PathVariable(value="bulletinId", required=true) int boardId,
            @Valid @RequestBody(required=true) TbAvnBoardDto tbAvnBoardDto) {

        tbAvnBoardDto.setBoardId(boardId);
        service.updateBoard(tbAvnBoardDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "게시판 삭제", description = "게시판 삭제 API")
    @DeleteMapping(value = "/assurance/spi-spt/bulletins/{bulletinId}")
    public ResponseEntity<?> deleteBulletin(@PathVariable(value="bulletinId", required=true) int boardId) {

        service.deleteBoard(boardId);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 리포트 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "리포트 목록 조회", description = "리포트 목록 조회 API")
    @Parameters({
            @Parameter(name = "searchTypeCd", description = "일자구분"),
            @Parameter(name = "fromDate", description = "시작일자"),
            @Parameter(name = "toDate", description = "종료일자"),
            @Parameter(name = "reportTypeCd", description = "보고서 구분"),
            @Parameter(name = "spiYn", description = "SPI 적용 여부"),
            @Parameter(name = "naYn", description = "N/A여부"),
    })
    @GetMapping(value = "/assurance/spi-spt/reports")
    public ResponseEntity<?> getSpiReportList(
        @RequestParam(value="searchTypeCd", required=false) String searchTypeCd,
        @RequestParam(value="fromDate", required=false) String fromDate,
        @RequestParam(value="toDate", required=false) String toDate,
        @RequestParam(value="reportTypeCd", required=false) String reportTypeCd,
        @RequestParam(value="spiYn", required=false) String spiYn,
        @RequestParam(value="naYn", required=false) String naYn
    ) {

        Map<String, Object> rtnMap = new HashMap<>();
        rtnMap.put("searchTypeCd", searchTypeCd);
        rtnMap.put("fromDate", fromDate);
        rtnMap.put("toDate", toDate);
        rtnMap.put("reportTypeCd", reportTypeCd);
        rtnMap.put("spiYn", spiYn);
        rtnMap.put("naYn", naYn);
        
        List<SpiReportDto> pageList = service.selectSpiReportList(rtnMap);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "리포트 SPI 및 위험도 정보 수정", description = "리포트 SPI 및 위험도 정보 수정 API")
    @PutMapping(value = "/assurance/spi-spt/reports/{reportId}")
    public ResponseEntity<?> updateSpiReport(
            @PathVariable(value="reportId", required=true) int key,
            @Valid @RequestBody(required=true) SpiReportDto dto) {

        dto.setReportId(key);
        service.updateSpiReport(dto);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 지표관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "지표관리 목록 조회", description = "지표관리 목록 조회 API")
    @Parameters({
            @Parameter(name = "year", description = "연도"),
            @Parameter(name = "spiType", description = "지표구분"),
            @Parameter(name = "spiName", description = "지표명"),
    })
    @GetMapping(value = "/assurance/spi-spt/indicators")
    public ResponseEntity<?> getSpiIndicatorList(
        @RequestParam(value="year", required=false) String year, 
        @RequestParam(value="spiType", required=false) String spiType, 
        @RequestParam(value="spiName", required=false) String spiName) {

        TbAvnSpiDto tbAvnSpiDto = new TbAvnSpiDto();
        tbAvnSpiDto.setSpiYear(year);
        tbAvnSpiDto.setSpiTypeCd(spiType);
        tbAvnSpiDto.setSpiNm(spiName);


        List<TbAvnSpiDto> rtnList = service.selectSpiIndicatorList(tbAvnSpiDto);

        return ResponseUtil.createSuccessResponse(rtnList);
    }

    /**
     * 지표관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "지표 불러오기", description = "지표 불러오기 API")
    @Parameters({
            @Parameter(name = "loadYear", description = "불러올 연도"),
            @Parameter(name = "loadSpiType", description = "불러올 지표구분"),
            @Parameter(name = "createYear", description = "생성 연도"),
    })
    @PostMapping(value = "/assurance/spi-spt/indicators/loadSpiIndicator")
    public ResponseEntity<?> loadSpiIndicator(@RequestBody() TbAvnSpiDto tbAvnSpiDto) {

        Map<String, Object> spiCntInfo = service.selectSpiIndicatorCnt(tbAvnSpiDto);
        int spiCnt = Integer.parseInt(spiCntInfo.get("cnt").toString());
        String codeMsg = spiCntInfo.get("spi_type_nm").toString();
        String rtnMsg = "등록된 " + codeMsg + " 정보가 있습니다.";
        if (spiCnt > 0) return ResponseUtil.createSuccessResponse(rtnMsg);
        
        service.loadSpiIndicator(tbAvnSpiDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "지표관리 상세정보 조회", description = "지표관리 상세정보 조회 API")
    @GetMapping(value = "/assurance/spi-spt/indicators/{indicatorId}")
    public ResponseEntity<?> getSpiIndicatorInfo(@PathVariable(value="indicatorId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 지표관리 등록", description = "신규 지표관리 등록 API")
    @PostMapping(value = "/assurance/spi-spt/indicators")
    public ResponseEntity<?> insertSpiIndicator(@Valid @RequestBody(required=true) TbAvnSpiDto dto) {

        dto.setLoadYear(dto.getSpiYear());

        Map<String, Object> spiCntInfo = service.selectSpiIndicatorCnt(dto);
        int spiCnt = Integer.parseInt(spiCntInfo.get("cnt").toString());
        String rtnMsg = "해당 연도에 등록된 SPI코드 정보가 있습니다.";
        if (spiCnt > 0) return ResponseUtil.createSuccessResponse(rtnMsg);

        service.insertSpiIndicator(dto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "지표관리 정보 수정", description = "지표관리 정보 수정 API")
    @PutMapping(value = "/assurance/spi-spt/indicators/{indicatorId}")
    public ResponseEntity<?> updateSpiIndicator(
            @PathVariable(value="indicatorId", required=true) String key,
            @Valid @RequestBody(required=true) TbAvnSpiDto dto) {

        service.updateSpiIndicator(dto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "지표관리 삭제", description = "지표관리 삭제 API")
    @DeleteMapping(value = "/assurance/spi-spt/indicators/{indicatorId}")
    public ResponseEntity<?> deleteSpiIndicator(@PathVariable(value="indicatorId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
