package com.koreanair.ksms.avn.sftr.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "Centralized Report")
public class CentralizedReportDto
{
    @Schema(description = "id")
    private int id;

    @Schema(description = "group id")
    private int groupId;

    @Schema(description = "문서번호")
    private String docNo;

    @Schema(description = "제목")
    private String subject;

    @Schema(description = "내용")
    private String descriptionTxtcn;

    @Schema(description = "출발일자")
    private String departureDt;

    @Schema(description = "편명")
    private String flightNo;

    @Schema(description = "기종")
    private String regNo;

    @Schema(description = "이벤트명")
    private String eventName;

    @Schema(description = "이벤트ID")
    private String eventId;

    @Schema(description = "hazard lv1명")
    private String lv1Name;

    @Schema(description = "hazard lv2명")
    private String lv2Name;

    @Schema(description = "hazard lv3명")
    private String lv3Name;

    @Schema(description = "consequence 한글명")
    private String consequenceKo;

    @Schema(description = "consequence 영문명")
    private String consequenceEn;

    @Schema(description = "레벨1")
    private String riskLevel1;

    @Schema(description = "레벨1색상")
    private String riskLevel1Color;

    @Schema(description = "레벨2")
    private String riskLevel2;

    @Schema(description = "레벨2색상")
    private String riskLevel2Color;

    @Schema(description = "state")
    private String state;

    @Schema(description = "phase")
    private String phase;

    @Schema(description = "step_code")
    private String stepCode;

    @Schema(description = "phase 한글명")
    private String phaseNameKor;

    @Schema(description = "phase 영문명")
    private String phaseNameEng;
}
