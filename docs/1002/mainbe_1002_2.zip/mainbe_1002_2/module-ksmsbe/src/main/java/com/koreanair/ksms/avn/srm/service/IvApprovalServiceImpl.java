package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.IvApprovalLog;
import com.koreanair.ksms.avn.srm.dto.IvProcessDto;
import com.koreanair.ksms.avn.srm.dto.IvStatusCode.Action;
import com.koreanair.ksms.avn.srm.dto.IvStatusCode.Phase;
import com.koreanair.ksms.avn.srm.dto.IvStatusCode.Process;
import com.koreanair.ksms.avn.srm.dto.IvStatusCode.Status;
import com.koreanair.ksms.avn.srm.dto.IvStatusCode.Step;
import com.koreanair.ksms.avn.srm.dto.IvApprovalDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
//@Slf4j
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class IvApprovalServiceImpl implements IvApprovalService{

//    private final Validator validator;

    private final IvApprovalLogService ivApprovalLogService;

//    private final IvNotiService ivNotiService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void processInvestigation(IvProcessDto process) {
//        validateProcess(process);

        IvApprovalLog approvalLog = ivApprovalLogService.findLastLogByReportId(process.getId());
        Status nextStatus = Optional.ofNullable(approvalLog)
                .map(log -> {
                    Process currentProcess = Process.findCurrentProcess(log.getPhase(), log.getStepCode());
                    Status nextProcess = currentProcess.findNextProcess(process.getStatus());

//                    logger.info("\r\rcurrent process ::: \t "
//                                    + "id: {} \t "
//                                    + "phase: {} \t "
//                                    + "step code: {} \t"
//                                    + "\r\rnext process ::: \t "
//                                    + "phase:{} \t "
//                                    + "step code: {}\r",
//                            process.getId(),
//                            log.getPhase(),
//                            log.getStepCode(),
//                            nextProcess.getPhase().getCode(),
//                            nextProcess.getStep().getCode());

                    return nextProcess;
                })
                .orElseGet(() -> {
                    Status nextProcess = process.getStatus();

//                    logger.info("\r\rid: {} \t "
//                                    + "\r\rnext process ::: \t "
//                                    + "phase:{} \t "
//                                    + "step code: {}\r",
//                            process.getId(),
//                            nextProcess.getPhase().getCode(),
//                            nextProcess.getStep().getCode());

                    return nextProcess;
                });

        List<Action> actions = nextStatus.getActions();
        boolean hasNoti;
        if (process.getRequestType() != null) {
            hasNoti = !("PATCH".equals(process.getRequestType()) && "report_close".equals(process.getStatus().getPhase().getCode())
                    && "approved".equals(process.getStatus().getStep().getCode()));
        } else {
            hasNoti = true;
        }

        for(Action action : actions) {
            switch (action) {
                case UPDATE_INVESTIGATION:
                    IvApprovalLog log = IvApprovalLog.builder()
                            .reportId(process.getId())
                            .stateType(nextStatus.getState().getCode())
                            .phase(nextStatus.getPhase().getCode())
                            .stepCode(nextStatus.getStep().getCode())
                            .steppedBy(process.getEmpNo())
                            .reason(process.getReason())
                            .timezone(process.getTimezone())
                            .build();
                    ivApprovalLogService.insertApprovalLog(log);
                    break;
                case SEND_NOTI:
                    hasNoti = hasNoti;
                    break;
                default:
                    break;
            }
        }

//        if (hasNoti) {
//            ivNotiService.sendNoti(process);
//        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void approvalInvestigation(IvApprovalDto dto, String empNo, int id, String timezone) throws Exception {
        String step = "rejected";
        if (dto.getApprovalType().equals("approve")) {
            step = "approved";
        }
        Phase phase = Phase.findNextPhase(dto.getPhase());
        Status status = Status.find(phase.getCode(), step);

        IvProcessDto process = IvProcessDto.builder()
                .id(id)
                .empNo(empNo)
                .status(status)
                .reason(dto.getReason())
                .timezone(timezone)
                .build();

        processInvestigation(process);
    }

//    private void validateProcess(IvProcessDto process) {
//        Set<ConstraintViolation<IvProcessDto>> violations = validator.validate(process);
//        if (!violations.isEmpty()) {
//            StringBuilder builder = new StringBuilder();
//            for (ConstraintViolation<IvProcessDto> violation : violations) {
//                builder.append(String.format("%s, ", violation.getMessage()));
//            }
//            throw new ConstraintViolationException(
//                    String.format("Error occured: %s", builder.toString()),
//                    violations);
//        }
//
//        if (isRejected(process)) {
//            Optional.ofNullable(process.getReason())
//                    .orElseThrow(() -> new NullPointerException("reason is not exist"));
//        }
//    }

    private boolean isRejected(IvProcessDto process) {
        return process.getStatus().getStep() == Step.REJECTED;
    }
}
