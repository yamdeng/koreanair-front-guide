package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.constants.AvnStatusCode.HazardProcess;
import com.koreanair.ksms.common.constants.AvnStatusCode.StepType;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class ReportProcessVo {

    private Integer groupId;

    private Integer reportId;

    @NotEmpty
    private String empNo;

    @NotNull
    private StepType stepType;

    /** 위험요인 상태 관리 처리시 필수 **/
    private Integer hazardId;

    /** Reject, Void 일경우 필수 **/
    private String reason;

    private String timezone;

    // 현재 phase 저장을위한 process추가
    private HazardProcess hazardProcess;

    private String isCloseType;

    // CODE_GRP_326 : 코드ID
    private String division;

    public ReportProcessVo(int groupId, int reportId, String empNo,StepType stepType) {
        super();
        this.groupId = groupId;
        this.reportId = reportId;
        this.empNo = empNo;
        this.stepType = stepType;
    }

    public ReportProcessVo(int groupId, int reportId, String empNo, StepType stepType, String timezone) {
        super();
        this.groupId = groupId;
        this.reportId = reportId;
        this.empNo = empNo;
        this.stepType = stepType;
        this.timezone = timezone;
    }

    public ReportProcessVo(int groupId, String empNo, StepType stepType, int hazardId) {
        super();
        this.groupId = groupId;
        this.empNo = empNo;
        this.stepType = stepType;
        this.hazardId= hazardId;
    }
    public ReportProcessVo(int groupId, String empNo, StepType stepType, int hazardId, String reason) {
        super();
        this.groupId = groupId;
        this.empNo = empNo;
        this.stepType = stepType;
        this.hazardId= hazardId;
        this.reason = reason;
    }
}
