package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
public class ReportVoidVo extends CommonDto {

    private final int groupId;

    private final int reportId;

    private final String reason;

    private final String empNo;

    private String timezone;
}