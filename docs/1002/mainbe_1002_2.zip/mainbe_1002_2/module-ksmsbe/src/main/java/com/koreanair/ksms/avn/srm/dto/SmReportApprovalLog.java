package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.Length;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Valid
public class SmReportApprovalLog extends CommonDto {

    @NotNull
    private int groupId;

    //@NotNull
    private int reportId;

    @NotBlank
    @Length(max = 50)
    private String state;

    @NotBlank
    @Length(max = 50)
    private String phase;

    @NotBlank
    @Length(max = 50)
    private String stepCode;

    @NotBlank
    @Length(max = 50)
    private String empNo;

    @Length(max = 255)
    private String reason;

    @NotBlank
    @Length(max = 50)
    private String timezone;

    @NotNull
    private Timestamp createdAt;

    public SmReportApprovalLog(int groupId, int reportId, String state, String phase, String stepCode, String empNo, String reason) {
        this.groupId = groupId;
        this.reportId = reportId;
        this.state = state;
        this.phase = phase;
        this.stepCode = stepCode;
        this.empNo = empNo;
        this.reason = reason;
    }

}