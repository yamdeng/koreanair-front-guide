package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class TbAvnIvCaDto extends CommonDto {
    @Schema(description = "ID")
    private int id;

    @Schema(description = "report ID")
    private int reportId;

    @Schema(description = "approved ID")
    private int approvedId;

    @Schema(description = "삭제일자")
    private String deletedAt;
}
