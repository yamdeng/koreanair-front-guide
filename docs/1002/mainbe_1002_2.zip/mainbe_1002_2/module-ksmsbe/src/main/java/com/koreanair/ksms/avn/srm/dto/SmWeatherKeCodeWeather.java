package com.koreanair.ksms.avn.srm.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Accessors(chain = true)
public class SmWeatherKeCodeWeather {
	private Integer weatherId;
	
	private Integer codeId;
}
