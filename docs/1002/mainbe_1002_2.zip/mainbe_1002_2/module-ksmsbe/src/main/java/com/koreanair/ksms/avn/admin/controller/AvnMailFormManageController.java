package com.koreanair.ksms.avn.admin.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.service.AvnMailFormManageService;
import com.koreanair.ksms.common.dto.TbAvnMailFormDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * 관리자 - 메일 양식 관리
 */
@Tag(name = "AvnMailFormManage", description = "관리자 - 메일 양식 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnMailFormManageController {

    @Autowired
    AvnMailFormManageService service;

    /**
     * 메일 양식 관리 목록 조회
     *
     * @param pageNum the page number
     * @param pageSize the page size
     * @param mailTypeCd the 정책구분
     * @param mailNm the 제목
     * @param useYn the 사용여부
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "메일 양식 관리 목록 조회", description = "메일 양식 관리 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "mailJobType", description = "업무구분"),
            @Parameter(name = "mailCode", description = "메일코드"),
            @Parameter(name = "mailName", description = "제목"),
            @Parameter(name = "useYn", description = "사용여부")
    })
    @GetMapping(value = "/admin/mail-forms")
    public ResponseEntity<?> getMailFormManageList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="mailTypeCd") String mailTypeCd
            ,@RequestParam(value="mailCd") String mailCd
            ,@RequestParam(value="mailNm") String mailNm
            ,@RequestParam(value="useYn") String useYn) {

        //조회 조건 parameter
        TbAvnMailFormDto tbAvnMailFormDto = new TbAvnMailFormDto();
        tbAvnMailFormDto.setMailTypeCd(mailTypeCd); //정책구분
        tbAvnMailFormDto.setMailCd(mailCd);       //메일코드
        tbAvnMailFormDto.setMailNm(mailNm);       //제목
        tbAvnMailFormDto.setUseYn(useYn);             //사용여부

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnMailFormDto> pageList = service.selectMailList(tbAvnMailFormDto);

        // 전체 조회
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "메일 양식 관리 상세정보 조회", description = "메일 양식 관리 상세정보 조회 API")
    @Parameter(name = "mailCode", description = "메일 코드")
    @GetMapping(value = "/admin/mail-forms/{mailCode}")
    public ResponseEntity<?> getMailFormManageInfo(@PathVariable(value="mailCode", required=true) String mailCd) {

        TbAvnMailFormDto result = service.selectMailDetail(mailCd);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 메일 양식 관리 등록", description = "신규 메일 양식 관리 등록 API")
    @PostMapping(value = "/admin/mail-forms")
    public ResponseEntity<?> insertMail(@Valid @RequestBody(required=true) TbAvnMailFormDto tbAvnMailFormDto) {

        service.insertMail(tbAvnMailFormDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "메일 양식 관리 정보 수정", description = "메일 양식 관리 정보 수정 API")
    @PutMapping(value = "/admin/mail-forms/{mailCode}")
    public ResponseEntity<?> updateMailFormManage(
            @PathVariable(value="mailCode", required=true) String mailCd,
            @Valid @RequestBody(required=true) TbAvnMailFormDto tbAvnMailFormDto) {

        tbAvnMailFormDto.setMailCd(mailCd);
        service.updateMail(tbAvnMailFormDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "메일 양식 관리 삭제", description = "메일 양식 관리 삭제 API")
    @Parameter(name = "mailCode", description = "메일 코드")
    @DeleteMapping(value = "/admin/mail-forms/{mailCode}")
    public ResponseEntity<?> deleteMailFormManage(@PathVariable(value="mailCode", required=true) String mailCd) {

        service.deleteMail(mailCd);
        return ResponseUtil.createSuccessResponse();
    }
}
