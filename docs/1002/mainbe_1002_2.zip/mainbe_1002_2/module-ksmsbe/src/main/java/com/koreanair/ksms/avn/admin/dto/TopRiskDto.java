package com.koreanair.ksms.avn.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TopRiskDto {

    @Schema(description = "이벤트 ID")
    private String eventId;
    
    @Schema(description = "이벤트 명")
    private String eventNm;
    
    @Schema(description = "리스크 레벨1")
    private String riskLevel1;
    
    @Schema(description = "건수")
    private String cnt;
    
    @Schema(description = "1/4 분기 값")
    private String lowData ;
    
    @Schema(description = "3/4 분기 값")
    private String largeData;
    
    @Schema(description = "최빈값 : 자주 나온 값")
    private String modeData;
    
    @Schema(description = "가장 큰 값")
    private String maxData;
    
    @Schema(description = "가장 작은 값")
    private String minData;
    
    @Schema(description = "리스크 높은 값")
    private String highRiskData;
    
    @Schema(description = "리스크 낮은 값")
    private String lowRiskData;
    
    @Schema(description = "계산값")
    private String calcData;
    
    @Schema(description = "리포트 ID")
    private String reportId;
    
    @Schema(description = "리포트 유형")
    private String reportType;
    
    @Schema(description = "리포트 문서번호")
    private String docNo;
    
    @Schema(description = "리포트 제목")
    private String subject;
    
    @Schema(description = "사원 번호")
    private String empNo;
    
    @Schema(description = "사원 명")
    private String empNm;
    
}
