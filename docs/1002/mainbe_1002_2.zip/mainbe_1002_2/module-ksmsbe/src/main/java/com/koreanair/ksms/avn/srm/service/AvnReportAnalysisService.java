package com.koreanair.ksms.avn.srm.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.*;

import java.util.List;
import java.util.Map;

public interface AvnReportAnalysisService {
    
    //목록 > 보고서 리스트(권한)조회
    void getAuthSetting(ReportViewlistDto.GET_Request dto);

    //목록 조회
    PageInfo<ReportViewlistVo> getAnalysisList(ReportViewlistDto.GET_Request dto);

    //상세
    ReportInfoVo getAnalysisInfo(ReportInfoDto.GET_Request dto);

    //foqax comment 조회
    List<FoqaxCommentsVo> selectFoqaxComments (Map<String, Object> param);
}
