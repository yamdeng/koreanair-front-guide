package com.koreanair.ksms.avn.srm.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AvnReportAnalysisServiceImpl extends AbstractBaseService implements AvnReportAnalysisService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    @Autowired
    AvnReportReceiptService avnReportReceiptService;

    @Autowired
    AvnReportFirstAssessmentService avnReportFirstAssessmentService;

    @Autowired
    AvnReportSecondAssessmentService avnReportSecondAssessmentService;

    @Autowired
    AvnReportMitigationService avnReportMitigationService;

    @Autowired
    AvnReportProcessService avnReportProcessService;

    @Override
    public void getAuthSetting(ReportViewlistDto.GET_Request dto){
        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        String empNo = userInfo.getEmpNo();

        //LSC 맴버확인용 empNo;
        dto.setP_empNo(empNo);

        // report status filter 생성
        String actionPhase = dto.getP_phase();
        if ("receipt".equals(actionPhase) || "1stRiskAssessment".equals(actionPhase)) {
            selectReportAuthSetting(actionPhase, dto);
        } else {
            selectHazardAuthSetting(actionPhase, dto);
        }
    }

    //보고서접수 | 1차위험평가(LSC) Auth 조회
    public void selectReportAuthSetting(String actionPhase, ReportViewlistDto.GET_Request dto) {
        List<String> authParam = new ArrayList<>();
        if ("receipt".equals(actionPhase)) {
            //접수
            authParam.add("report_acceptance");
        } else if ("1stRiskAssessment".equals(actionPhase)) {
            //1차위험도평가
            authParam.add("risk_assessment");
        }

        //사용자 권한별 보고서 목록 조회
        List<String> reportAllList = new ArrayList<>();
        List<String> reportList = avnCommonService.getAuthReportList(authParam);
        reportAllList.addAll(reportList);
        // size가 0인경우는 allList
        if (reportList.size() > 0) {
            if (reportList.contains("assigned_report")) {
                dto.setP_assignEmpNo(dto.getP_empNo());
            }
            if ("receipt".equals(actionPhase)) {
                dto.setP_step1MergeAuthYn("Y");
            }
        } else {
            //관리자 계정
            dto.setP_step1MergeAuthYn("Y");
        }

        //SRC 권한이 있는지 여부 : 권한이 있을 경우 SRC수락/거절 버튼 보임 처리
        if ("1stRiskAssessment".equals(actionPhase)) {
            //1차 SRC
            authParam = new ArrayList<>();
            authParam.add("ssc_review");

            //사용자 권한별 보고서 목록 조회
            reportList = avnCommonService.getAuthReportList(authParam);
            reportAllList.removeAll(reportList);//중복제거
            reportAllList.addAll(reportList);
            // size가 0인경우는 allList
            if (reportList.size() > 0) {
                if (reportList.contains("assigned_report")) {
                    dto.setP_step2SrcAuthYn("Y");
                }
            } else {
                //관리자 계정
                dto.setP_step2SrcAuthYn("Y");
            }
        }
        dto.setP_reportList(reportAllList);
    }

    //1차위험평가(SRC) | 경감조치 | 2차위험평가 | 종결 Auth 조회
    public void selectHazardAuthSetting(String actionPhase, ReportViewlistDto.GET_Request dto) {
        List<String> authParam = new ArrayList<>();
        if ("riskAcceptance".equals(actionPhase)) {
            authParam.add("ssc_review");
        } else if ("mitigation".equals(actionPhase)) {
            authParam.add("mitigation");
        } else if ("2ndRiskAssessment".equals(actionPhase)) {
            authParam.add("risk_assessment");
            authParam.add("ssc_review");
        } else if ("2ndRiskAcceptance".equals(actionPhase)) {
            authParam.add("ssc_review");
        } else if("riskAcceptanceApproval".equals(actionPhase)) {
            authParam.add("approval");
        }
        //사용자 보고서 권한(ROLE)조회
        List<String> reportList = avnCommonService.getAuthReportList(authParam);

        // size가 0인경우는 allList
        if (reportList.size() > 0) {
            if ("mitigation".equals(actionPhase)) {
                if(reportList.contains("assigned_hazard")) {
                    TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
                    int deptId = userInfo.getDeptId();
                    dto.setP_mitigationDeptId(deptId);
                }
            }
            if ("2ndRiskAssessment".equals(actionPhase)) {
                if (reportList.contains("assigned_report")) {
                    dto.setP_assignEmpNo(dto.getP_empNo());
                }
            }
            dto.setP_reportList(reportList);
        }
    }

    //안전위험관리 > 보고서 분석 > 목록 조회
    @Override
    public PageInfo<ReportViewlistVo> getAnalysisList(ReportViewlistDto.GET_Request dto){

        List<ReportViewlistVo> resultReportList = new ArrayList<ReportViewlistVo>();
        List<ReportViewlistVo> resultHazardList = new ArrayList<ReportViewlistVo>();

        // report status filter 생성
        String actionPhase = dto.getP_phase();
        switch (actionPhase) {
            case "receipt":
            case "1stRiskAssessment":
                resultReportList = selectReportList(actionPhase, dto);
                return PageInfo.of(resultReportList);
            default:
                resultHazardList = selectHazardList(actionPhase, dto);
                return PageInfo.of(resultHazardList);
        }
    }

    //보고서접수 | 1차위험평가(LSC) 조회
    public List<ReportViewlistVo> selectReportList(String actionPhase, ReportViewlistDto.GET_Request dto) {
        return commonSql.selectList("AvnReportAnalysis.selectReportViewlist", dto);
    }

    //1차위험평가(SRC) | 경감조치 | 2차위험평가 | 종결 조회
    public List<ReportViewlistVo> selectHazardList(String actionPhase, ReportViewlistDto.GET_Request dto) {
        return commonSql.selectList("AvnReportAnalysis.selectHazardViewlist", dto);
    }

    //안전위험관리 > 보고서 분석 > 상세 조회
    @SuppressWarnings("unchecked")
    @Override
    public ReportInfoVo getAnalysisInfo(ReportInfoDto.GET_Request dto) {
        List<String> roleList = this.getRoleList();
        dto.setP_roleList(roleList);

        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        dto.setP_empNo(userInfo.getEmpNo());

        ReportInfoVo resultVo = new ReportInfoVo();

        //접수데이터 생성 : 대표 Report Id를 가져오기 위해서 첫번째로 실행함..
        dto.setP_resourceName("report_acceptance");
        dto.setP_isView(true); //상세조회는 권한에 상관없이 조회해야함..
        ReceiptVo receiptData = avnReportReceiptService.selectReportReceipt(dto);
        resultVo.setReceiptVo(receiptData);

        int groupId = dto.getP_groupId();
        Integer hazardId = null;
        if (dto.getP_hazardId() != null) {
            hazardId = dto.getP_hazardId();
        }

        int reportId = receiptData.getReportId();
        int receiptionId = receiptData.getId();

        //보고서 데이터 생성
        //1. 마스터 보고서 데이터
        //대표보고서 번호 가져옴

        //todo khw. 보고서 타입별로 별도로 레포트를 만들어야 될듯?
        String reportType = receiptData.getSmReport().getReportType();

        //1차위험평가 데이터
        RiskAssessmentVo firstRiskAssessmentData = new RiskAssessmentVo();
        firstRiskAssessmentData = avnReportFirstAssessmentService.selectReportFirstAssessment(dto);
        resultVo.setFirstRiskAssessmentVo(firstRiskAssessmentData);

        Map<String, Object> hazardParam = new HashMap<>();
        hazardParam.put("groupId", groupId);
        hazardParam.put("hazardId", hazardId);

        //1차SRC 데이터
        hazardParam.put("phase", "riskAcceptance");
        List<HazardViewlistVo> firstRiskAcceptance = this.selectHazardlist(hazardParam);
        resultVo.setFirstRiskAcceptanceVo(firstRiskAcceptance);

        //경감조치-지정 데이터
        hazardParam.put("phase", "mitigationAssign");
        List<HazardViewlistVo> mitigationAssignData = this.selectHazardlist(hazardParam);
        resultVo.setMitigationAssignVo(mitigationAssignData);

        //경감조치-계획 데이터
        hazardParam.put("phase", "mitigationAccept");
        List<HazardViewlistVo> mitigationAcceptData = this.selectHazardlist(hazardParam);
        resultVo.setMitigationAcceptVo(mitigationAcceptData);

        //경감조치-실행 데이터
        hazardParam.put("phase", "mitigationResult");
        List<HazardViewlistVo> mitigationResultData = this.selectHazardlist(hazardParam);
        resultVo.setMitigationResultVo(mitigationResultData);

        for (HazardViewlistVo data : mitigationResultData) {
            MitigationResultDto.GET_Request parameter= new MitigationResultDto.GET_Request(data.getId(), userInfo.getDeptId());;
            MitigationResultVo detailInfo = selectMitigationResult(parameter);
            data.setDetailInfo(detailInfo);
        }

        //2차위험평가 데이터
        hazardParam.put("phase", "riskAssessment");
        List<HazardViewlistVo> secondRiskAssessmentData = this.selectHazardlist(hazardParam);
        resultVo.setSecondRiskAssessmentVo(secondRiskAssessmentData);

        //2차SRC 데이터
        hazardParam.put("phase", "2ndRiskAcceptance");
        List<HazardViewlistVo> secondRiskAcceptance = this.selectHazardlist(hazardParam);
        resultVo.setSecondRiskAcceptanceVo(secondRiskAcceptance);

        //종결 데이터
        hazardParam.put("phase", "riskAcceptanceApproval");
        List<HazardViewlistVo> riskAcceptanceApproval = this.selectHazardlist(hazardParam);
        resultVo.setRiskAcceptanceApprovalVo(riskAcceptanceApproval);


        //todo khw .FOQA 자료 생성 : 1차 위험평가 Submit 한 경우...
        if ("foqa".equals(reportType)) {
            resultVo.setFoqaRoleType("");
            //1차위험평가 제출완료 건이면 : 보고서 내용보기의 foqa-x comment 보여줌
            if ("1st_risk".equals(firstRiskAssessmentData.getPhase()) && "submitted".equals(firstRiskAssessmentData.getStepCode())) {

            } else {

            }



            //FOQA 권한 체크
            if (roleList.contains("FMG") || roleList.contains("FSR")) {
                resultVo.setFoqaRoleType("MG");
            } else if (roleList.contains("FVG")) {
                resultVo.setFoqaRoleType("VW");
            } else {
                resultVo.setFoqaRoleType("");
            }

            //FOQA 직책 체크
            resultVo.setFoqaUserPosition(userInfo.getPostDeptCd());

            //FOQA-X인 경우(열람권한인 경우) 별도 처리 필요 : 1차평가완료한 건에 대해서 comments 조회하여 보고서내용보기, SRC리뷰에서 조회함
            // 1. 변수 - FOQA-X 건이고 1차평가완료한 경우이면 Y 아니면 N
            // 2. 변수 - 로그인자가 Approved By에 해당되는 경우 : SELOYOYI | EOY | EOO
            Map<String, Object> param = new HashMap<>();
            param.put("groupId", groupId);
            List<FoqaxCommentsVo> foqaxCommentsVo = this.selectFoqaxComments(param);
            resultVo.setFoqaxCommentsVo(foqaxCommentsVo);
        }

        return resultVo;
    }

    @Override
    public List<FoqaxCommentsVo> selectFoqaxComments (Map<String, Object> param) {
        return commonSql.selectList("AvnReportRiskAssessment.selectFoqaxComments", param);
    }

    public List<HazardViewlistVo> selectHazardlist(Map<String, Object> param) {
        HazardViewlistDto.GET_Request hazardParam = new HazardViewlistDto.GET_Request();
        hazardParam.setGroupId(Integer.parseInt(param.get("groupId").toString()));
        hazardParam.setPhase(param.get("phase").toString());

        if (param.get("hazardId") != null) {
            hazardParam.setHazardId(Integer.parseInt(param.get("hazardId").toString()));
        }

        return avnReportProcessService.selectHazardlist(hazardParam);
    }


    public List<String> getRoleList () {
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        List<String> roleList = authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());
        return roleList;
    }

    public MitigationResultVo selectMitigationResult(MitigationResultDto.GET_Request parameter) {
        MitigationResultVo vo = commonSql.selectOne("AvnReportMitigation.selectMitigationResult", parameter);

        if(vo == null) {
            return null;
        }

        int mitigationId = vo.getMitigation().getId();

        Map<String, Object> param = new HashMap<>();
        param.put("hazardId", parameter.getHazardId());
        param.put("type", "2");
        List<MitigationVo> mitigationEmpNoInfo = commonSql.selectList("AvnReportMitigation.selectMitigationEmpNoInfo", param);
        vo.setEmpInfo(mitigationEmpNoInfo);

        @SuppressWarnings("unchecked")
        List<ProgressRateVo> rate = commonSql.selectList("AvnReportMitigation.selectMitigationProgress", mitigationId);
        //List<PoFileVo> attachment = getMitigationAttachment(mitigationId);
        //todo khw 파일 첨부관련 확인 필요.
        //vo.setAttachment(attachment);
        vo.setProgressRate(rate);
        return vo;
    }

}
