package com.koreanair.ksms.common.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.*;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import com.koreanair.ksms.common.utils.DateUtil;
import com.koreanair.ksms.common.utils.JsonUtil;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.vertx.core.json.JsonObject;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 공통 컨트롤러
 */
@Tag(name = "KsmsCommon", description = "항공안전/산업안전 공통 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/com")
public class KsmsCommonController {

    @Autowired
    KsmsCommonService service;

    @Autowired
    AvnCommonService avnCommonService;

    @Operation(summary = "좌측 메뉴 조회", description = "KSMS 좌측 메뉴를 조회하는 API")
    @Parameters({
            @Parameter(name = "workScope", description = "업무구분(A:항공안전, O:산업안전, S:시스템)"),
            @Parameter(name = "isTree", description = "빈값이거나 Y 일경우 Tree형태로 조회, 아니면 List로 조회")

    })
    @GetMapping(value = "/left-menus")
    public ResponseEntity<?> getAdminLeftMenus(
            @RequestParam(value="workScope", required=true, defaultValue="O") String workScope,
            @RequestParam(value="isTree", required=false, defaultValue="Y") String isTree) {

        List<Map<String, Object>> resultList = service.selectLeftMenu(workScope);

        if("Y".equals(isTree) && !resultList.isEmpty()) {
            // 트리형태 JSON 으로 변경하여 리턴
            return ResponseUtil.createSuccessResponse(JsonUtil.convertorTreeMap(resultList, "S000000", "menuId", "upperMenuId", "nameKor", "sort"));
        }

        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "전체 코드그룹 목록 조회", description = "전체 코드그룹 목록 조회 API")
    @GetMapping(value = "/code-groups")
    public ResponseEntity<?> getCodeGroupList() {

        List<TbSysCodeGroupDto> resultList = service.selectCodeGroupList();
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "코드 그룹의 코드목록 조회", description = "코드 그룹의 코드목록 조회 API")
    @GetMapping(value = "/code-groups/{codeGroupId}/codes")
    public ResponseEntity<?> getCodeList(@PathVariable(value="codeGroupId", required=true) String codeGroupId) {

        List<TbSysCodeDto> resultList = service.selectCodeList(codeGroupId);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "전체 코드목록 조회", description = "그룹정보를 포함한 전체 코드목록 조회 API")
    @GetMapping(value = "/code-groups/codes/all")
    public ResponseEntity<?> getCodeListAll() {

        List<TbSysCodeDto> resultList = service.selectCodeListAll();
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "부서 목록 조회", description = "목록 조회 API")
    @Parameters({
            @Parameter(name = "deptCd", description = "부서코드 입력 시 해당 부서의 하위부서 목록 조회")
    })
    @GetMapping(value = "/depts")
    public ResponseEntity<?> getDeptList(
            @RequestParam(value="deptCd", required=false) String deptCd
    ) {

        List<TbSysDeptDto> resultList = service.selectDeptList(deptCd);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "사용자 검색", description = "사용자 검색 API")
    @Parameters({
            @Parameter(name = "searchWord", description = "사용자명/사번 검색"),
            @Parameter(name = "deptCd", description = "부서코드 검색")

    })
    @GetMapping(value = "/users")
    public ResponseEntity<?> searchUserList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="searchWord", required=false) String searchWord
            ,@RequestParam(value="deptCd", required=false) String deptCd
    ) {

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbSysUserDto> pageList = service.selectUserList(searchWord, deptCd);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "로그인 시 전체 다국어 메시지 조회", description = "로그인 시 전체 다국어 메시지 조회 API")
    @GetMapping(value = "/locales/translation")
    public ResponseEntity<?> selectKoTranslation() {

        JsonObject messages = service.selectMessagesAll();
        return ResponseUtil.createSuccessResponse(messages.encode());
    }

    @Operation(summary = "로그인한 사용자 profile 가져오기", description = "로그인한 사용자 profile 가져오기 API")
    @GetMapping("profile")
    public ResponseEntity<?> getProfile() {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String userId = auth.getName();

        TbSysUserDto userInfo = service.selectUserProfile(userId);
        List<TbSysVirtualGroupDto> groupInfo = service.selectUserGroups(userId);
        Map<String, Object> cfgInfo = service.selectUserCfg(userId);
        String serverTime = DateUtil.now("yyyy-MM-dd HH:mm:ss");

        Map<String, Object> result = new HashMap<String, Object>();
        result.put("userInfo", userInfo);
        result.put("groupInfo", groupInfo);
        result.put("cfgInfo", cfgInfo);
        result.put("serverTime", serverTime);

        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "특정 사용자 하나의 상세정보 조회", description = "특정 사용자 하나의 상세정보 조회 API")
    @GetMapping(value = "/users/{userId}")
    public ResponseEntity<?> getUserInfo(@PathVariable(value="userId", required=true) String userId) {

        TbSysUserDto result = service.selectUser(userId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "특정 부서 하나의 상세정보 조회(부서ID)", description = "특정 부서 하나의 상세정보 조회(부서ID) API")
    @GetMapping(value = "/depts/id/{deptId}")
    public ResponseEntity<?> getDeptIdInfo(@PathVariable(value="deptId", required=true) int deptId){

        TbSysDeptDto result = service.selectDeptId(deptId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "특정 부서 하나의 상세정보 조회(부서코드)", description = "특정 부서 하나의 상세정보 조회(부서코드) API")
    @GetMapping(value = "/depts/code/{deptCd}")
    public ResponseEntity<?> getDeptCdInfo(@PathVariable(value="deptCd", required=true) String deptCd){

        TbSysDeptDto result = service.selectDeptCd(deptCd);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "사용자 알림메시지 조회", description = "사용자 알림메시지 조회 API")
    @Parameters({
            @Parameter(name = "recvYn", description = "수신여부(Y:수신완료, N:미수신, ALL:전체)")

    })
    @GetMapping(value = "/alert-messages")
    public ResponseEntity<?> getAlertMessages(
            @RequestParam(value="recvYn", defaultValue="N") String recvYn
    ) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String userId = auth.getName();

        List<TbSysAlertMsgDto> resultList = service.selectAlertMessages(userId, recvYn);

        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "읽지 않은 알림메시지 갯수 가져오기", description = "읽지 않은 알림메시지 갯수 가져오기 API")
    @GetMapping(value = "/noti-count")
    public ResponseEntity<?> getNotReadNotiCount() {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String userId = auth.getName();

        Map<String, Object> result = service.selectNotReadNotiCount(userId);

        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "사용자 알림메시지 1건 읽음처리", description = "사용자 알림메시지 1건 읽음처리 API")
    @PostMapping(value = "/alert-messages/{alertMsgId}")
    public ResponseEntity<?> setMessageRead(@PathVariable(value="alertMsgId") int alertMsgId) {

        service.setMessageRead(alertMsgId);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "사용자 알림메시지 전부 읽음처리", description = "사용자 알림메시지 전부 읽음처리 API")
    @PostMapping(value = "/alert-messages/all")
    public ResponseEntity<?> setMessageReadAll() {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String userId = auth.getName();

        service.setMessageReadAll(userId);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Frontend 발생 오류 수신", description = "Frontend 발생 오류 수신 API")
    @PostMapping(value = "/receive-fe-error")
    public ResponseEntity<?> receiveFrontError(@Valid @RequestBody() FrontErrorDto dto) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String userId = auth.getName();
        dto.setUserId(userId);

        service.insertTbSysFeError(dto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Frontend 발생 오류 조회", description = "Frontend 발생 오류 조회 API")
    @Parameters({
            @Parameter(name = "id", description = "오류ID")
            ,@Parameter(name = "userId", description = "사용자ID 검색")
            ,@Parameter(name = "errorDate", description = "오류일자 검색 YYYYMMDD")
            ,@Parameter(name = "currentRouteUrl", description = "현재 페이지URL 검색")
            ,@Parameter(name = "beforeRouteUrl", description = "이전 페이지URL 검색")
            ,@Parameter(name = "userAgent", description = "USER AGENT 검색")
            ,@Parameter(name = "version", description = "VERSION 검색")

    })
    @GetMapping(value = "/receive-fe-error")
    public ResponseEntity<?> viewFrontError(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="id", required=false, defaultValue="0") int id
            ,@RequestParam(value="userId", required=false) String userId
            ,@RequestParam(value="errorDate", required=false) String errorDate
            ,@RequestParam(value="currentRouteUrl", required=false) String currentRouteUrl
            ,@RequestParam(value="beforeRouteUrl", required=false) String beforeRouteUrl
            ,@RequestParam(value="userAgent", required=false) String userAgent
            ,@RequestParam(value="version", required=false) String version
    ) {

        PageHelper.startPage(pageNum, pageSize);
        PageInfo<FrontErrorDto> pageList = service.selectFeErrorList(id, userId, errorDate, currentRouteUrl, beforeRouteUrl, userAgent, version);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "이메일 전송 테스트", description = "이메일 전송 테스트 API")
    @PostMapping(value = "/email-sample")
    public ResponseEntity<?> mailTest(
            @RequestParam(value="rcvEmail", required=true, defaultValue="pj.sixone@kalmate.net") String rcvEmail
            ,@RequestParam(value="rcvName", required=true, defaultValue="젤다") String rcvName
            ,@RequestParam(value="rcvEmpNo", required=true, defaultValue="1") String rcvEmpNo
            ,@RequestParam(value="title", required=true, defaultValue="메일 제목") String title
            ,@RequestParam(value="msg", required=true, defaultValue="메일 내용") String msg
            ,@RequestParam(value="strSemail", required=true, defaultValue="pj.sixone@kalmate.net") String strSemail
            ,@RequestParam(value="strSname", required=true, defaultValue="KSMS") String strSname
    ) {

        List<MailDto> mailList = new ArrayList<>();
        MailDto dto = new MailDto(rcvEmail, rcvName, title, msg, strSemail, strSname);
        mailList.add(dto);

        Map<String, Object> result = service.sendEmailTest(mailList);

        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "Flight Info 가져오기", description = "Flight Info 가져오기 API")
    @Parameters({
            @Parameter(name = "departureDate", description = "운항일자 YYYYMMDD")
            ,@Parameter(name = "fltNo", description = "비행편명 ex)0018")

    })
    @GetMapping(value = "/flight")
    public ResponseEntity<?> getFlightInfoFromKE(
            @RequestParam(value="departureDate", required=true, defaultValue="20240905") String departureDate
            ,@RequestParam(value="fltNo", required=true, defaultValue="0018") String fltNo
    ) {

        List<FlightResponseDto> list = service.getFlightsFromKE(departureDate, fltNo);

        return ResponseUtil.createSuccessResponse(list);
    }

    @Operation(summary = "Flight Crew정보 가져오기", description = "Flight Crew정보 가져오기 API")
    @Parameters({
            @Parameter(name = "departureDate", description = "운항일자 YYYYMMDD")
            ,@Parameter(name = "fltNo", description = "비행편명 ex)0018")

    })
    @GetMapping(value = "/flight-crew")
    public ResponseEntity<?> getFlightCrewFromKE(
            @RequestParam(value="departureDate", required=true, defaultValue="20240905") String departureDate
            ,@RequestParam(value="fltNo", required=true, defaultValue="0018") String fltNo
    ) {

        List<FlightCrewDto> list = service.getFlightCrewFromKE(departureDate, fltNo);

        return ResponseUtil.createSuccessResponse(list);
    }
    
    @Operation(summary = "부서 목록 트리별 리스트 조회", description = "부서 목록 트리별 리스트 조회 API")
    @GetMapping(value = "/deptList")
    public ResponseEntity<?> getDeptList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="searchWord", required=false) String searchWord
            ,@RequestParam(value="searchGubun", required=false) String searchGubun
            ,@RequestParam(value="searchLevel", required=false) String searchLevel
            ,@RequestParam(value="searchDept", required=false) String searchDept
            ,@RequestParam(value="searchDivision", required=false) String searchDivision
            ,@RequestParam(value="deptCd", required=false) String deptCd
    ) {
    	log.debug("여기@@@@@@@@@@@@@@@@@@");

//    	PageHelper.startPage(pageNum, pageSize);
//        PageInfo<TbSysUserDto> pageList = service.selectDeptList(searchWord, deptCd);
//        return ResponseUtil.createSuccessResponse(pageList);
        
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbSysDeptDto> pageList = service.selectDeptTreeList(searchWord, searchGubun, searchLevel, searchDept, searchDivision,  deptCd);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @GetMapping(value = "/todoList")
    public ResponseEntity<?> getTodoList() {
        TbSysUserDto userInfo = service.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());

        Map<String,Object> param = new HashMap<>();
        param.put("empNo", userInfo.getEmpNo());
        param.put("mitDeptId", userInfo.getDeptId());

        //사용자 보고서 권한(ROLE)조회
        List<String> authParam = new ArrayList<>();

        //접수권한 체크
        param.put("isAcceptanceAuth", "N");
        param.put("receptionReportTypeList", new ArrayList<>());
        authParam.add("report_acceptance");
        List<String> receptionReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (!receptionReportTypeList.isEmpty()) {
            param.put("isAcceptanceAuth", "Y");
            param.put("receptionReportTypeList", receptionReportTypeList);
        }
        //todo khw. 변화관리 보고서인 경우 : 부문 체크 필요


        //lsc 권한 체크
        param.put("isAssessmentAuth", "N");
        authParam = new ArrayList<>();
        authParam.add("risk_assessment");
        List<String> assessmentReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (!assessmentReportTypeList.isEmpty()) {
            if (assessmentReportTypeList.contains("assigned_report")) {
                param.put("isAssessmentAuth", "Y");
            }
        }

        //src 권한 체크
        param.put("isRiskAcceptanceAuth", "N");
        authParam = new ArrayList<>();
        authParam.add("ssc_review");
        List<String> riskAcceptanceReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (!riskAcceptanceReportTypeList.isEmpty()) {
            if (riskAcceptanceReportTypeList.contains("assigned_report")) {
                param.put("isRiskAcceptanceAuth", "Y");
            }
        }

        //로그인자의 결재 권한(직책) 체크
        boolean isDeptTeamLeader = false;
        if (userInfo.getPostDeptCd() != null) {
            if (!userInfo.getPostDeptCd().isEmpty()) {
                isDeptTeamLeader = true;
            }
        }
        //결재 권한 체크
        param.put("isApporovalAuth", "N");
        param.put("approvalReportTypeList", new ArrayList<>());
        authParam = new ArrayList<>();
        authParam.add("approval");
        List<String> approvalReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (!receptionReportTypeList.isEmpty() && isDeptTeamLeader) {
            param.put("isApporovalAuth", "Y");
            param.put("approvalReportTypeList", approvalReportTypeList);
        }

        //경감 권한 체크
        param.put("isMitigationAuth", "N");
        authParam.add("mitigation");
        List<String> mitigationReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (!mitigationReportTypeList.isEmpty()) {
            if (mitigationReportTypeList.contains("assigned_hazard")) {
                param.put("isMitigationAuth", "Y");
            }
        }

        //FOQA 권한 체크
        param.put("isFoqaXAuth", "N");
        List<String> roleList = avnCommonService.selectRoleList();
        if (roleList.contains("FVG")) {
            //열람권한
            param.put("isFoqaXAuth", "Y");
        }

        List<Map> todoList = service.selectTodoList(param);
        return ResponseUtil.createSuccessResponse(todoList);
    }

}
