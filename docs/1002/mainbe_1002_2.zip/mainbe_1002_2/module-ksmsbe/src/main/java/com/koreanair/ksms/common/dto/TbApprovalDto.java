package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "결재정보")
public class TbApprovalDto extends CommonDto {

    @Schema(description = "ID")
    @NotBlank
    private int approvalId;

    @Schema(description = "업무구분(항공 A/안전 O)")
    @NotBlank
    private String workType;

    @Schema(description = "결재구분. 공통코드 APPROVAL_TYPE")
    @NotBlank
    private String approvalType;

    @Schema(description = "결재제목")
    @NotBlank
    private String approvalSubject;

    @Schema(description = "결재Key정보(URL)")
    private String approvalKey;

    @Schema(description = "결재요청 사원번호")
    @NotBlank
    private String empNo;
    private String empNmKor;
    private String empNmEng;

    @Schema(description = "결재요청자 부서코드")
    @NotBlank
    private String deptCd;
    private String deptNmKor;
    private String deptNmEng;

    @Schema(description = "결재요청 메시지")
    private String approvalMsg;

    @Schema(description = "업무(리포트) Key")
    private String reportKey;

    @Schema(description = "(최종)승인자 사번")
    private String approvedEmpNo;
    private String approvedEmpNmKor;
    private String approvedEmpNmEng;

    @Schema(description = "(최종)완료일시")
    private Timestamp approvedDttm;

    @Schema(description = "결재진행상태")
    private String approvalStat;
}
