package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.TbSysCodeDto;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Setter
@Getter
@Builder
public class SearchConditionDto {
	
	private String value;
	
	private String nameKo;
	
	private String nameEn;
	
	private List<SearchConditionDto> children; 
	
	public static SearchConditionDto of(Map<String, Object> entity) {		
		return SearchConditionDto.builder()
				.value(entity.get("codeId").toString())
				.nameKo(entity.get("codeNameKor").toString())
				.nameEn(entity.get("nameEn").toString())
				.build();
	}
	
	public static SearchConditionDto of(TbSysCodeDto entity) {
		return SearchConditionDto.builder()
				.value(entity.getCodeId())
				.nameKo(entity.getCodeNameKor())
				.nameEn(entity.getCodeNameEng())
				.build();
	}
	
}
