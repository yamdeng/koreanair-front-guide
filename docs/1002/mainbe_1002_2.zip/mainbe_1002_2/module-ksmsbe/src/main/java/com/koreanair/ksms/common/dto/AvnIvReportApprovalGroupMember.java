package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AvnIvReportApprovalGroupMember extends CommonDto {

    @Schema(description = "그룹ID")
    private int groupId;

    @Schema(description = "정렬순번")
    private int viewSn;

    @Schema(description = "사원번호")
    private String empNo;

    @Schema(description = "타임존")
    private String timezone;
}
