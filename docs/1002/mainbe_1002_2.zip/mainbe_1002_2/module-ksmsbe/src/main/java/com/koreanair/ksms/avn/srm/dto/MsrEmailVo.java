package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "접수 - MSR이메일정보")
public class MsrEmailVo extends CommonDto {
    private String id;

    private Integer receptionId;

    private String empNo;

    private String nameKo;

    private String nameEn;

    private String rankNmKor;

    private String rankNmEng;

    private String deptNmKor;

    private String deptNmEng;
}
