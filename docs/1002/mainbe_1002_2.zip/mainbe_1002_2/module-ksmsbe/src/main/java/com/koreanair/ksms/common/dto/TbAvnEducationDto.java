package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS_교육")
public class TbAvnEducationDto extends CommonDto {
    
    @Schema(description = "교육ID")
    @NotBlank
    private String educationId;
    
    @Schema(description = "교육일자")
    @NotBlank
    private String educationDt;
    
    @Schema(description = "교육코드")
    @NotBlank
    private String educationCd;
    
    @Schema(description = "교육내용")
    private String educationCn;
    
    @Schema(description = "제목명")
    @NotBlank
    private String subjectNm;
    
    @Schema(description = "링크그룹SEQ")
    private String linkGroupSeq;
    
    @Schema(description = "파일그룹SEQ")
    private String fileGroupSeq;
}
