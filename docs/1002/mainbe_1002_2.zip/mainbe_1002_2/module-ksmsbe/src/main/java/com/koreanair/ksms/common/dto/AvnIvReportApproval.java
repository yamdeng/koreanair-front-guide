package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Setter
@Getter
@ToString
public class AvnIvReportApproval extends CommonDto{

    @Schema(description = "조사보고서 그룹")
    private AvnIvReportApprovalGroup group;

    @Schema(description = "조사보고서 그룹 멤버")
    private List<AvnIvReportApprovalGroupMember> memberList;

}
