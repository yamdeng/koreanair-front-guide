package com.koreanair.ksms.avn.audit.service;

public interface AvnAuditCAService {
}
