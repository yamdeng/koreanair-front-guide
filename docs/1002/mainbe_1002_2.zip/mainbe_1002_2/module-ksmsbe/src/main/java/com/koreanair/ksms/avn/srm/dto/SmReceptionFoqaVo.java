package com.koreanair.ksms.avn.srm.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SmReceptionFoqaVo extends SmReceptionFoqa {

	private String foqaCategoryKo;	
	
	private String foqaCategoryEn;
}
