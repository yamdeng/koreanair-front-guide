package com.koreanair.ksms.common.dto;

import java.sql.Timestamp;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode(of = {"id"})
public class SmSearchReport {
	
	@NotNull
	private int id;
	
	private String docNo;
	
	@NotBlank
	private String reportType;
	
	private String reportedBy;
	
	private String subject;
	
	private String timeZone;
	
	private String phase;
	
	private String state;
	
	private Timestamp createdAt;
	
	private Timestamp updatedAt;
	
	private Timestamp submittedAt;
	
	private String assessmentNotes;
	
	private int flightId;
	
	private String departureAt;
	
	private String flightNo;
	
	private String regNo;
	
	private String aircraftType;
	
	private String fromAirport;
	
	private String toAirport;
	
	private String divertAirport;
	
	private String stdTime;
	
	private String staTime;
	
	private String atdTime;
	
	private String ataTime;
	
	private int delayHour;
	
	private String supply;
	
	private String checkIn;
	
	private int fleetId;
	
	private String fleetCode;
	
	private String stepCode;
	
	private String airport;
	
}
