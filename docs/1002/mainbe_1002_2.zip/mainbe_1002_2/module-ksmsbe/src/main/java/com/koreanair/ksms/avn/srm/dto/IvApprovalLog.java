package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@Builder
public class IvApprovalLog extends CommonDto {

    private int id;

    private int reportId;

    private String stateType;

    private String phase;

    private String stepCode;

    private String steppedBy;

    private String reason;

    private String timezone;
}
