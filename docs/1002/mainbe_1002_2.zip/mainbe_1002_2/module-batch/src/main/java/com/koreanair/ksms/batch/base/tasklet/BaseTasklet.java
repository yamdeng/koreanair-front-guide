package com.koreanair.ksms.batch.base.tasklet;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.transaction.annotation.Transactional;

public abstract class BaseTasklet implements Tasklet, StepExecutionListener {
    private static final Logger log = LoggerFactory.getLogger(BaseTasklet.class);
    private JobParameters jobParameters;
    @Getter
    @Setter
    private ExecutionContext jobContext;
    @Getter
    @Setter
    private StepExecution stepExecution;
    @Getter
    private StepContribution stepContribution;
    private ChunkContext chunkContext;
    @Getter
    private String jobId;
    @Getter
    private String stepId;

    @Transactional
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
            throws Exception {
        this.jobId =
                contribution.getStepExecution().getJobExecution().getJobInstance().getJobName();
        this.stepId = contribution.getStepExecution().getStepName();

        return this.run(contribution, chunkContext);
    }

    public abstract RepeatStatus run(StepContribution stepContribution, ChunkContext chunkContext)
            throws Exception;

    public JobParameters getJobParameters() {
        return this.getStepExecution().getJobParameters();
    }

    public void setParameters(JobParameters jobParameters) {
        this.jobParameters = jobParameters;
    }

    public ChunkContext getChunkContext() {
        return this.getChunkContext();
    }

    public void setJobContextData(String key, Object value) {
        this.jobContext.put(key, value);
    }

    public Object getJobContextData(String key) {
        return this.jobContext.get(key);
    }

    public void beforeStep(StepExecution stepExecution) {
        this.jobParameters = stepExecution.getJobParameters();
        this.setJobContext(stepExecution.getJobExecution().getExecutionContext());
        this.setStepExecution(stepExecution);
    }

    public ExitStatus afterStep(StepExecution paramStepExecution) {
        return paramStepExecution.getExitStatus();
    }
}
