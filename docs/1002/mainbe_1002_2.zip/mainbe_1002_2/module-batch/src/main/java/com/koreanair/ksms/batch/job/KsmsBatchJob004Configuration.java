package com.koreanair.ksms.batch.job;

import lombok.extern.slf4j.Slf4j;

/**
 * 경감조치 유효성 평가 대상 목록 추출 Batch Job
 */
@Slf4j
//@Configuration
public class KsmsBatchJob004Configuration {

    public static final String JOB_NAME = "ksmsBatchJob004";
    public static final String STEP_NAME = "ksmsBatchStep004";
}
