package com.koreanair.ksms.batch.mapper;

import com.koreanair.ksms.batch.entity.SampleEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SampleMapper {
    List<SampleEntity> selectEmployeeTable();

    int insertEmployeeTableTasklet(List<SampleEntity> sampleEntityList);

    void deleteSample();
}
