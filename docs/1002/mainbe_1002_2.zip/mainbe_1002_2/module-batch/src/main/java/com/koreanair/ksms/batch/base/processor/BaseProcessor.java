package com.koreanair.ksms.batch.base.processor;

import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;

@Setter
public abstract class BaseProcessor<I, O> implements ItemProcessor<I, O>, StepExecutionListener {
    private static final Logger log = LoggerFactory.getLogger(BaseProcessor.class);
    private JobParameters jobParameters;
    @Getter
    private ExecutionContext jobContext;
    @Getter
    private StepExecution stepExecution;

    public O process(I item) throws Exception {
        return this.run(item);
    }

    public abstract O run(I item) throws Exception;

    public void beforeStep(StepExecution stepExecution) {
        this.jobParameters = stepExecution.getJobParameters();
        this.setJobContext(stepExecution.getJobExecution().getExecutionContext());
        this.setStepExecution(stepExecution);
    }

    public ExitStatus afterStep(StepExecution stepExecution) {
        return stepExecution.getExitStatus();
    }

    public JobParameters getJobParameters() {
        return this.getStepExecution().getJobParameters();
    }

    public void setJobContextData(String key, Object value) {
        this.jobContext.put(key, value);
    }

    public Object getJobContextData(String key) {
        return this.jobContext.get(key);
    }
}
