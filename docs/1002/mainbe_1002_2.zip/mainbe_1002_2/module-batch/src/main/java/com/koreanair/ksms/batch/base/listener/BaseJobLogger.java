package com.koreanair.ksms.batch.base.listener;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.StepExecution;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Objects;

public class BaseJobLogger implements JobExecutionListener {
    private static final Logger log = LoggerFactory.getLogger(BaseJobLogger.class);
    private final SimpleDateFormat dateFormat;

    public BaseJobLogger() {
        this.dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS", Locale.KOREA);
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
        ch.qos.logback.classic.Logger log = loggerContext.getLogger("com.koreanair.ksms.batch");

        //String logLevel = jobExecution.getJobParameters().getString("logLevel");
        //log.setLevel(Level.toLevel(logLevel == null ? log.getLevel().toString() : logLevel));

        MDC.put("job_name", jobExecution.getJobInstance().getJobName());
        log.info("Job starting ........");
        log.info("jobExecution.getStartTime() : " + jobExecution.getStartTime());
        log.info(
                String.format(
                        "\n==================================================================================================\n				Job : [%s]\n--------------------------------------------------------------------------------------------------\n Job Execution Id: %-15s	Job Parameters : %s \n Status : %-15s	Start: %s \n==================================================================================================",
                        jobExecution.getJobInstance().getJobName(),
                        jobExecution.getJobId(),
                        jobExecution.getJobParameters(),
                        jobExecution.getStatus(),
                        Objects.requireNonNull(jobExecution.getStartTime()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                ));
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        MDC.put("job_name", jobExecution.getJobInstance().getJobName());
        StringBuilder report = new StringBuilder(1000);
        report.append("Job finished\n				<Job Execution Report >");
        Collection<StepExecution> stepExecs = jobExecution.getStepExecutions();

        for (StepExecution stepExec : stepExecs) {
            report.append(
                    String.format(
                            "\n==================================================================================================\n				Step : [%s]\n--------------------------------------------------------------------------------------------------\n	ID : %-14s	Version : %s\n ReadCount	: %3s	Filtercount	: %3s	WriterCount		: %3s\n ReadSkipCount	: %3s	WriteSkipCount	: %3s	ProcessSkipCount	: %3s\n CommitCount	: %3s	RollbackCount	: %3s\n Status	: %s	Exit Status	: %s",
                            stepExec.getStepName(),
                            stepExec.getId(),
                            stepExec.getVersion(),
                            stepExec.getReadCount(),
                            stepExec.getFilterCount(),
                            stepExec.getWriteCount(),
                            stepExec.getReadSkipCount(),
                            stepExec.getWriteSkipCount(),
                            stepExec.getProcessSkipCount(),
                            stepExec.getCommitCount(),
                            stepExec.getRollbackCount(),
                            stepExec.getStatus(),
                            stepExec.getExitStatus()));
        }

        report.append(
                String.format(
                        "\n==================================================================================================\n				Job : [%s]\n--------------------------------------------------------------------------------------------------\n	ID : %s		Job Parameters: %s\n Status : %s	Exit Status: %s\n Start : %s\n End : %s\n Elapsed Time: %.3f sec \n==================================================================================================",
                        jobExecution.getJobInstance().getJobName(),
                        jobExecution.getJobId(),
                        jobExecution.getJobParameters(),
                        jobExecution.getStatus(),
                        jobExecution.getExitStatus(),
                        Objects.requireNonNull(jobExecution.getStartTime()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                        Objects.requireNonNull(jobExecution.getEndTime()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                        Duration.between(
                                        Objects.requireNonNull(jobExecution.getStartTime()),
                                        jobExecution.getEndTime())
                                .toMillis()
                                / 1000.0D));

        log.info(report.toString());
        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
            log.info("Batch job completed successfully: CODE[0]");
        } else {
            log.info("Batch job completed status : " + jobExecution.getStatus());
        }
    }
}
