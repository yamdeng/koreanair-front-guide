package com.koreanair.ksms.batch.service;

import com.koreanair.ksms.batch.dto.SampleDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public interface SampleService {
    public List<SampleDTO> retrieveSample() ;
    public int insertSample(List<SampleDTO> sampleDTO);

    void deleteSample();
}
