package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysCodeDto;
import com.koreanair.ksms.system.dto.TbSysCodeGroupDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SystemCodeServiceImpl extends AbstractBaseService implements SystemCodeService {

    @Override
    public List<TbSysCodeGroupDto> selectCodeGroupList(String workScope, String searchWord) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("workScope", workScope);
        param.put("searchWord", searchWord);

        return commonSql.selectList("SystemCode.selectCodeGroupList", param);
    }

    @Override
    public TbSysCodeGroupDto selectCodeGroup(String codeGrpId) {

        return commonSql.selectOne("SystemCode.selectCodeGroup", codeGrpId);
    }

    @Override
    public void insertCodeGroup(TbSysCodeGroupDto dto) {

        commonSql.insert("SystemCode.insertCodeGroup", dto);
    }

    @Override
    public void updateCodeGroup(TbSysCodeGroupDto dto) {

        commonSql.update("SystemCode.updateCodeGroup", dto);
    }

    @Override
    @Transactional
    public void deleteCodeGroup(String codeGrpId) {

        commonSql.delete("SystemCode.deleteCodeGroup", codeGrpId);
    }

    /*****************************************************************************************************************/

    @Override
    public List<TbSysCodeDto> selectCodeList(String codeGrpId) {

        return commonSql.selectList("SystemCode.selectCodeList", codeGrpId);
    }

    @Override
    public TbSysCodeDto selectCode(String codeGrpId, String codeId) {

        TbSysCodeDto param = new TbSysCodeDto();
        param.setCodeGrpId(codeGrpId);
        param.setCodeId(codeId);

        return commonSql.selectOne("SystemCode.selectCode", param);
    }

    @Override
    public void insertCode(TbSysCodeDto dto) {

        commonSql.insert("SystemCode.insertCode", dto);
    }

    @Override
    public void updateCode(TbSysCodeDto dto) {

        commonSql.update("SystemCode.updateCode", dto);
    }

    @Override
    public void deleteCode(String codeGrpId, String codeId) {

        TbSysCodeDto param = new TbSysCodeDto();
        param.setCodeGrpId(codeGrpId);
        param.setCodeId(codeId);

        commonSql.delete("SystemCode.deleteCode", param);
    }

    @Override
    @Transactional
    public void saveCode(String codeGrpId, List<TbSysCodeDto> dtoList) {

        // 기존 코드 전체삭제
        commonSql.delete("SystemCode.deleteCodeAll", codeGrpId);

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("codeGrpId", codeGrpId);
        param.put("list", dtoList);

        // 코드 일괄저장
        commonSql.insert("SystemCode.insertCodeAll", param);
    }
}
