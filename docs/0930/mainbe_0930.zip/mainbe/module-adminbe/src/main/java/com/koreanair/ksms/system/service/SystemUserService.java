package com.koreanair.ksms.system.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.TbSysUserDto;

public interface SystemUserService {

    PageInfo<TbSysUserDto> selectUserListPage(String searchWord);
    TbSysUserDto selectUser(String userId);
}
