package com.koreanair.ksms.exception;

import com.koreanair.ksms.constants.HttpHeaderConstants;
import com.koreanair.ksms.constants.ResponseHeaderCode;
import com.koreanair.ksms.constants.StatusCodeConstants;
import com.koreanair.ksms.system.dto.ResponseDto;
import com.koreanair.ksms.utils.ResponseUtil;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.StringJoiner;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.HandlerMethodValidationException;

@Slf4j
@RestControllerAdvice(basePackages = "com.koreanair.ksms.system.controller")
public class RestControllerExceptionAdvice {

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResponseDto<String>> customExceptionHandler(Exception e) {
        ResponseEntity<ResponseDto<String>> result = null;

        // 필수값 validation 처리
        if (e instanceof BindException bindException) {
            List<FieldError> errorList = bindException.getBindingResult().getFieldErrors();
            var message = new StringJoiner(",");
            for (final FieldError error : errorList) {
                message.add(error.getField());
            }
            result = ResponseUtil.createFailResponse(
                    StatusCodeConstants.MANDATORY_PARAM_ERROR,
                    message.toString(),
                    HttpStatus.OK,
                    ResponseHeaderCode.INVALID_PARAMETER);
        }

        // 필수값 validation 처리
        else if (e instanceof MissingServletRequestParameterException missingServletRequestParameterException) {
            result = ResponseUtil.createFailResponse(
                    StatusCodeConstants.MANDATORY_PARAM_ERROR,
                    missingServletRequestParameterException.getParameterName(),
                    HttpStatus.OK,
                    ResponseHeaderCode.INVALID_PARAMETER);
        }

        // HandlerMethodValidation
        else if (e instanceof HandlerMethodValidationException handlerMethodValidationException) {
            result = ResponseUtil.createFailResponse(
                    StatusCodeConstants.MANDATORY_PARAM_ERROR,
                    handlerMethodValidationException.getMessage(),
                    HttpStatus.OK,
                    ResponseHeaderCode.INVALID_PARAMETER);
        }

        // PK 중복
        /*
        else if (e instanceof DuplicateKeyException duplicateKeyException) {
            result = ResponseUtil.createFailResponse(
                    StatusCodeConstants.FAIL,
                    duplicateKeyException.getMessage(),
                    HttpStatus.OK,
                    ResponseHeaderCode.NOT_PROCESSED);
        }
        */

        else {
            result = ResponseUtil.createFailResponse(
                    StatusCodeConstants.INTERNAL_SERVER_ERROR,
                    null,
                    HttpStatus.OK,
                    ResponseHeaderCode.UNAVAILABLE_SERVICE);
        }

        // 로컬개발용 오류 출력
        String profile = System.getProperty("spring.profiles.active");
        if("local".equals(profile)) {
            log.error("서버 오류 :", e);
        }

        return result;
    }

    @ExceptionHandler(CustomBusinessException.class)
    public ResponseEntity<?> customBusinessExceptionHandler(HttpServletRequest request, CustomBusinessException e) {
        if (MediaType.APPLICATION_OCTET_STREAM_VALUE.equals(request.getHeader(HttpHeaderConstants.ACCEPT))
                && StatusCodeConstants.SESSION_EXPIRE.equals(e.getStatusCode())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(null);
        } else {
            return ResponseUtil.createFailResponse(e.getStatusCode(), e.getMessage(), HttpStatus.OK, e.getHeaderCode());
        }
    }
}