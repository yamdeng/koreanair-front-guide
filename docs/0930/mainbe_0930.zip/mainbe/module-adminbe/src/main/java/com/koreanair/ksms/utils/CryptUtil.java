package com.koreanair.ksms.utils;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.AlgorithmParameters;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.InvalidParameterSpecException;
import java.util.Base64;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptUtil {

	private static final int SALT_BYTE_SIZE = 20;
	private static final int KEY_LENGTH = 256;
	private static final int ITERATION_COUNT = 1000;
	
	private static String KEY = "r4FjqFq1QPgHAuD4ZAbzAMXkjGAV";

	public static String encryptAES256(String msg) {
		String returnValue = "";
		try {
			SecureRandom random = new SecureRandom();
			byte salt[] = new byte[SALT_BYTE_SIZE];
			random.nextBytes(salt);

			PBEKeySpec spec = new PBEKeySpec(KEY.toCharArray(), salt, ITERATION_COUNT, KEY_LENGTH);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			SecretKey secretKey = factory.generateSecret(spec);
			SecretKeySpec secret = new SecretKeySpec(secretKey.getEncoded(), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secret);

			AlgorithmParameters params = cipher.getParameters();
			byte[] ivBytes = params.getParameterSpec(IvParameterSpec.class).getIV();
			byte[] encryptedTextBytes = cipher.doFinal(msg.getBytes("UTF-8"));
			byte[] buffer = new byte[salt.length + ivBytes.length + encryptedTextBytes.length];

			System.arraycopy(salt, 0, buffer, 0, salt.length);
			System.arraycopy(ivBytes, 0, buffer, salt.length, ivBytes.length);
			System.arraycopy(encryptedTextBytes, 0, buffer, salt.length + ivBytes.length, encryptedTextBytes.length);

			returnValue = Base64.getEncoder().encodeToString(buffer);
		} catch(Exception e) {
			// handle exception
		}
	    return returnValue;
	}
	
	public static String decryptAES256(String msg) {
		String returnValue = "";
		try {
			ByteBuffer buffer = ByteBuffer.wrap(Base64.getDecoder().decode(msg));
			
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			
			byte[] salt = new byte[SALT_BYTE_SIZE];
			buffer.get(salt, 0, salt.length);
			byte[] ivBytes = new byte[cipher.getBlockSize()];
			buffer.get(ivBytes, 0, ivBytes.length);
			byte[] encryoptedTextBytes = new byte[buffer.capacity() - salt.length - ivBytes.length];
			buffer.get(encryoptedTextBytes);
			
			PBEKeySpec spec = new PBEKeySpec(KEY.toCharArray(), salt, ITERATION_COUNT, KEY_LENGTH);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			SecretKey secretKey = factory.generateSecret(spec);
			SecretKeySpec secret = new SecretKeySpec(secretKey.getEncoded(), "AES");
			
			cipher.init(Cipher.DECRYPT_MODE, secret, new IvParameterSpec(ivBytes));
			
			byte[] decryptedTextBytes = cipher.doFinal(encryoptedTextBytes);
			returnValue = new String(decryptedTextBytes);
		} catch (Exception e) {
			// handle exception
		}
		return returnValue;

	}
}
