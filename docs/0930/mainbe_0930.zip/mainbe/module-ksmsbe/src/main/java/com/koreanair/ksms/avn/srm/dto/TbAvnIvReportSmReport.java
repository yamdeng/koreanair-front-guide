package com.koreanair.ksms.avn.srm.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbAvnIvReportSmReport {
    private int ivReportId;
    private int smReportId;
}
