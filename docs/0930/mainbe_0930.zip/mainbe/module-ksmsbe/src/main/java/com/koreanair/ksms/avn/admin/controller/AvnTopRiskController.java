package com.koreanair.ksms.avn.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.koreanair.ksms.avn.admin.service.AvnTopRiskService;
import com.koreanair.ksms.common.dto.TbAvnRiskLevelMatrixDto;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * 관리자 - Top Risk 관리
 */
@Tag(name = "AvnTopMatrix", description = "관리자 - Top Event / Hazard 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnTopRiskController {

    @Autowired
    AvnTopRiskService service;


    /**
     * 리스크 매트릭스 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "top-risk 목록 조회", description = "top-risk 목록 조회 API")
    @GetMapping(value = "/admin/top-risk")
    public ResponseEntity<?> getTopRiskList() {

        List<TbAvnRiskLevelMatrixDto> rtnRiskMatrixList = service.selectRiskMatrixList();

        Map<String, Object> rtnMap = new HashMap<>();
        rtnMap.put("riskMatrix", rtnRiskMatrixList);

        // 전체 조회
        return ResponseUtil.createSuccessResponse(rtnMap);
    }


}
