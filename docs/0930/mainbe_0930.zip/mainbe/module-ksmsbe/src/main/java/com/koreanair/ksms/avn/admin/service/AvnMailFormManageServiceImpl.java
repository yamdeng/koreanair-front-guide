package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.*;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnMailFormManageServiceImpl extends AbstractBaseService implements AvnMailFormManageService {

    //  관리자 > 메일양식관리 조회
    @Override
    public PageInfo<TbAvnMailFormDto> selectMailList(TbAvnMailFormDto tbAvnMailFormDto) {
        List<TbAvnMailFormDto> resultList = commonSql.selectList("AvnMailFormManage.selectMailList", tbAvnMailFormDto);
        return PageInfo.of(resultList);
    }

    //  관리자 > 메일양식관리 신규 등록
    @Override
    public void insertMail(TbAvnMailFormDto tbAvnMailFormDto) {
        commonSql.insert("AvnMailFormManage.insertMail", tbAvnMailFormDto);
    }

    //  관리자 > 메일양식관리 상세
    @Override
    public TbAvnMailFormDto selectMailDetail(String mailCd) {
        return commonSql.selectOne("AvnMailFormManage.selectMailDetail", mailCd);
    }

    //  관리자 > 메일양식관리 수정
    @Override
    public void updateMail(TbAvnMailFormDto tbAvnMailFormDto) {
        commonSql.update("AvnMailFormManage.updateMail", tbAvnMailFormDto);
    }

    //  관리자 > 메일양식관리 삭제
    @Override
    public void deleteMail(String mailCode) {
        commonSql.delete("AvnMailFormManage.deleteMail", mailCode);
    }
}
