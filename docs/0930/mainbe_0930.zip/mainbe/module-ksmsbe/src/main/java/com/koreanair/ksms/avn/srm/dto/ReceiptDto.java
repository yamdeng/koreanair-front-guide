package com.koreanair.ksms.avn.srm.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

public class ReceiptDto {
	
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class GET_Request {
		@NotNull
		private int reportId;
		private List<String> roleList;
		private final String resourceName="report_acceptance";
		private boolean isView;
	}
	
	@Getter
	@AllArgsConstructor
	@ToString
	public static class GET_Response {
		private ReceiptVo receiptDetail;
		//private final ReportPaths reportPaths = ReportPaths.getInstance();
	}
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	@JsonInclude(value = Include.NON_NULL)
	public static class POST_Request {
		private ReceiptVo receiptDetail;
		private boolean submit;
		private String timezone;
	}
	
	@Getter
	@AllArgsConstructor
	@ToString
	public static class POST_Response {
		private ReceiptVo receiptDetail;
		//private final String url = PortalAppIdStore.RECEPTION.getAppUrl();
	}
	
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	@JsonInclude(value = Include.NON_NULL)
	public static class PUT_Request {
		private ReceiptVo receiptDetail;
		private boolean submit;
		private String timezone;
	}
	
	@Getter
	@AllArgsConstructor
	@ToString
	public static class PUT_Response {
		private ReceiptVo receiptDetail;
		//private final String url = PortalAppIdStore.RECEPTION.getAppUrl();
	}
	
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	@JsonInclude(value = Include.NON_NULL)
	public static class PATCH_Request {
		private ReceiptVo receiptDetail;
		private String timezone;
	}
	
	@Getter
	@AllArgsConstructor
	@ToString
	public static class PATCH_Response {
		private ReceiptVo receiptDetail;
		//private final String url = PortalAppIdStore.RECEPTION.getAppUrl();
	}
	
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class DELETE_Request {
		@NotNull
		private int reportId;
		@NotNull
		private String reason;
	}

	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class DELETE_Request_Hazard {
		@NotNull
		private int id;

		private int groupId;

		@NotNull
		private String workScopeCd;
	}

	@Getter
	@AllArgsConstructor
	@ToString
	public static class DELETE_Response {
		//private final String url = PortalAppIdStore.RECEPTION.getAppUrl();
	}

}

