package com.koreanair.ksms.avn.srm.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ReportMitigationDto {
	private int reportId;

	private List<ReportMitigationVo> mitigations;

	private List<PoFileVo> attachments;

}