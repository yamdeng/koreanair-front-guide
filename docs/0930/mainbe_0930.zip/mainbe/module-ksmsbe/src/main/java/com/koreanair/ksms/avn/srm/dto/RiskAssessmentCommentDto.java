package com.koreanair.ksms.avn.srm.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonInclude(value = Include.NON_NULL)
public class RiskAssessmentCommentDto {
	
	@NotNull
	private int groupId;
	
	private Integer hazardId;

	private Integer id; //comment id
	
	private String content;
	
	private String empNo;
	
	private String timezone;

	private String decision_type;

	private String decision_comments;

	public RiskAssessmentCommentDto(@NotNull int groupId, String content) {
		super();
		this.groupId = groupId;
		this.content = content;
	}

}
