package com.koreanair.ksms.common.dto;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트")
public class TbAvnReportDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotNull
    private Integer reportId;
    
    @Schema(description = "레포트문서번호")
    private String reportDocno;
    
    @Schema(description = "레포트유형코드")
    @NotBlank
    private String reportTypeCd;
    private String reportTypeKor;
    private String reportTypeEng;
    
    @Schema(description = "사원번호")
    @NotBlank
    private String empNo;
    
    @Schema(description = "제목명")
    private String subjectNm;
    
    @Schema(description = "타임존코드")
    private String timezoneCd;
    private String timezoneKor;
    private String timezoneEng;
    
    @Schema(description = "레포트단계코드")
    @NotBlank
    private String reportPhaseCd;
    private String reportPhaseKor;
    private String reportPhaseEng;
    
    @Schema(description = "레포트상태코드")
    @NotBlank
    private String reportStatusCd;
    private String reportStatusKor;
    private String reportStatusEng;
    
    @Schema(description = "등록일자")
    @NotBlank
    private String regDt;
    
    @Schema(description = "변경일자")
    @NotBlank
    private String changeDt;
    
    @Schema(description = "삭제일자")
    private String delDt;
    private Timestamp delDttm;
    
    @Schema(description = "최종제출여부")
    @NotBlank
    private String finalSubmittedYn;
    
    @Schema(description = "최종제출일자")
    private String finalSubmittedDt;
    private Timestamp finalSubmittedDttm;
    
    @Schema(description = "표시순번")
    private int viewSn;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Schema(description = "발생일시")
    private Timestamp occurDttm;
    
    @Schema(description = "발생타임존코드")
    private String occurTimezoneCd;
    private String occurTimezoneKor;
    private String occurTimezoneEng;
    
    @Schema(description = "발생장소명")
    private String occurPlaceNm;
    
    @Schema(description = "발생공항코드")
    private String occurAirportCd;
    
    @Schema(description = "설명텍스트내용")
    private String descriptionTxtcn;
    
    @Schema(description = "파일그룹SEQ")
    private int fileGroupSeq;
    
    @Schema(description = "작업스코프코드")
    private String workScopeCd;
    
    @Schema(description = "위험도평가메모내용")
    private String riskAssessmentNotesCn;
    
    @Schema(description = "SPI연도")
    private String spiYear;
    
    @Schema(description = "SPI코드")
    private String spiCode;
    private String spiName;
    private String riskLevelCd;
    private String colorCd;
    private String spiTypeCd;
    private String offlineYn;
}
