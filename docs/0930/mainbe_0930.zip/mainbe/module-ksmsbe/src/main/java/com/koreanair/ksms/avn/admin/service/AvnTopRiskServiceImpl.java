package com.koreanair.ksms.avn.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.koreanair.ksms.common.dto.TbAvnRiskLevelMatrixDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnTopRiskServiceImpl extends AbstractBaseService implements AvnTopRiskService {

    //  관리자 > risk matrix 목록 조회
    @Override
    public List<TbAvnRiskLevelMatrixDto> selectRiskMatrixList() {
        List<TbAvnRiskLevelMatrixDto> resultList = commonSql.selectList("AvnTopRisk.selectRiskMatrixList");
        return resultList;
    }

}
