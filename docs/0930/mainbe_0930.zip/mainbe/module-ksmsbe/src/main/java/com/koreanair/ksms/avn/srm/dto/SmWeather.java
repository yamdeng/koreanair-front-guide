package com.koreanair.ksms.avn.srm.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
public class SmWeather {

	@NotNull
	private int id;
	
	@NotNull
	private int asrEventId;
	
	private String met;
	
	@Min(value = 0)
	private int wind1;
	
	@Min(value = 0)
	private int wind2;
	
	@Min(value = 0)
	private int gust;
	
	@Size(max = 50)
	private String visibility;
	
	@Size(max = 50)
	private String cloud;
	
	private int temp;
	
	@Min(value = 0)
	private int altimeter;
	
	@Size(max = 50)
	private String altimeterUnit;
	
}
