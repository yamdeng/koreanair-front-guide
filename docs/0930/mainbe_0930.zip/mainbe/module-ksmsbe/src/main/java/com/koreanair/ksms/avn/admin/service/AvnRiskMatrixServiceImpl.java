package com.koreanair.ksms.avn.admin.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.koreanair.ksms.common.dto.TbAvnRiskLevelMatrixDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnRiskMatrixServiceImpl extends AbstractBaseService implements AvnRiskMatrixService {

    //  관리자 > risk matrix 목록 조회
    @Override
    public List<TbAvnRiskLevelMatrixDto> selectRiskMatrixList() {
        List<TbAvnRiskLevelMatrixDto> resultList = commonSql.selectList("AvnRiskMatrix.selectRiskMatrixList");
        return resultList;
    }

    //  관리자 > risk matrix 수정
    @Override
    @Transactional(rollbackFor={Exception.class})
    public void updateRiskMatrixList(ObjectNode saveObj) {

        ObjectMapper mapper = new ObjectMapper();   // JSON을 Object화 하기 위한 Jackson ObjectMapper 이용
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        try {
            List<Map<String, Object>> riskMatrixList = mapper.treeToValue(saveObj.get("riskMatrix"), ArrayList.class);
            commonSql.delete("AvnRiskMatrix.deleteRiskMatrix");
            for (Map<String, Object> data : riskMatrixList) {
                TbAvnRiskLevelMatrixDto tbAvnRiskLevelMatrixDto = 
                    TbAvnRiskLevelMatrixDto
                        .builder()
                        .riskLevelCd( data.get("riskLevelCd") != null ? data.get("riskLevelCd").toString() : "")
                        .colorCd( data.get("colorCd") != null ? data.get("colorCd").toString() : "")
                        .scoreCo( data.get("scoreCo") != null ? Integer.parseInt(data.get("scoreCo").toString()) : 0)
                        .build();
                commonSql.insert("AvnRiskMatrix.insertRiskMatrix", tbAvnRiskLevelMatrixDto);
            };

            List<Map<String, Object>> riskPbbtList = mapper.treeToValue(saveObj.get("riskPbbt"), ArrayList.class);
            commonSql.delete("AvnRiskMatrix.deleteRiskCode", riskPbbtList.get(0));
            for (Map<String, Object> data : riskPbbtList) {
                commonSql.insert("AvnRiskMatrix.insertRiskCode", data);
            };

            List<Map<String, Object>> riskSvrtList = mapper.treeToValue(saveObj.get("riskSvrt"), ArrayList.class);
            commonSql.delete("AvnRiskMatrix.deleteRiskCode", riskSvrtList.get(0));
            for (Map<String, Object> data : riskSvrtList) {
                commonSql.insert("AvnRiskMatrix.insertRiskCode", data);
            };
        
        } catch (JsonProcessingException | IllegalArgumentException e) {
            throw new CustomBusinessException(e.getMessage());
        }

        return ;
    }

}
