package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Accessors(chain = true)
public class SmFlightCrew {

	@NotNull
	private int id;

	@NotNull
	private int flightId;
	
	@NotNull
	@Size(max = 50)
	@JsonProperty(value = "userType")
	private String crewType;
	
	@NotNull
//	@JsonProperty(value = "EMP_NO")
	private String empNo;
}
