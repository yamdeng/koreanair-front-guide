package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.IvApprovalDto;
import com.koreanair.ksms.avn.srm.dto.IvProcessDto;

public interface IvApprovalService {
    void processInvestigation(IvProcessDto process);

    void approvalInvestigation(IvApprovalDto dto, String empNo, int id, String timezone) throws Exception;
}
