package com.koreanair.ksms.avn.audit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.Builder;
import org.apache.commons.lang3.StringUtils;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
@Schema(description = "Checklist / Chapter")
@JsonIgnoreProperties(value = {"handler"})
public class TBAuditChapterDto extends CommonDto {

    @Schema(description = "chapterId")
    @NotNull
    private int chapterId;

    @Schema(description = "원본 ID")
    private int origId;

    @Schema(description = "체크리스트 원본 ID")
    private int checklistOrigId;

    @Schema(description = "리비전")
    private int revision;

    @Schema(description = "체크리스트 리비전")
    private int checklistRevision;

    @Schema(description = "챕터명")
    private String chapterName;

    @Schema(description = "표시 순서")
    private String viewOrder;

    @Schema(description = "메모")
    private String notes;

    @Schema(description = "활성/비활성 상태")
    private String state;

    @Schema(description = "삭제일시")
    private Timestamp deletedAt;

    @Schema(description = "리비전 update Y/N")
    private boolean revisionUpdate;

    private List<TBAuditQuestionDto> questionInfo;

    /*public void setChapterName(String chapterName) {
        if (StringUtils.isNotBlank(chapterName)) {
            this.chapterName = chapterName;
        }
    }

    public TBAuditChapterDto createNextRevision(int checklistRevision, String regUserId) {
        return TBAuditChapterDto.builder()
            .chapterId(this.chapterId)
            .checklistOrigId(this.checklistOrigId)
            .revision(this.revision + 1)
            .chapterName(this.chapterName)
            .viewOrder(this.viewOrder)
            .notes(this.notes)
            .state(this.state)
            .checklistRevision(checklistRevision)
            .regUserId(regUserId)
            .build();
    }*/
}
