package com.koreanair.ksms.avn.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.service.AvnSurveyManageService;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 관리자 - 안전문화설문
 */
@Tag(name = "AvnSurveyManage", description = "관리자 - 안전문화설문 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSurveyManageController {

    @Autowired
    AvnSurveyManageService service;

    /**
     * 안전문화설문 목록 조회
     * @param pageNum the page number
     * @param pageSize the page size
     * @param popupFromDt the 설문일자
     * @param popupToDt the 설문일자
     * @param titleKo the 제목
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전문화설문 목록 조회", description = "안전문화설문 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "popupFromDt", description = "설문일자"),
            @Parameter(name = "popupToDt", description = "설문일자"),
            @Parameter(name = "titleKo", description = "제목")
    })
    @GetMapping(value = "/admin/survey")
    public ResponseEntity<?> getSurveyList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="popupFromDt") String popupFromDt
            ,@RequestParam(value="popupToDt") String popupToDt
            ,@RequestParam(value="titleKo") String titleKo){

        //조회 조건 parameter
        TbAvnBoardDto tbAvnBoardDto = new TbAvnBoardDto();

        tbAvnBoardDto.setPopupFromDt(popupFromDt);  // 설문일자
        tbAvnBoardDto.setPopupToDt(popupToDt);  // 설문일자
        tbAvnBoardDto.setSubjectKoNm(titleKo);          // 제목

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnBoardDto> pageList = service.selectSurveyList(tbAvnBoardDto);

        // 전체 조회
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "안전문화설문 상세정보 조회", description = "안전문화설문 상세정보 조회 API")
    @Parameter(name = "boardId", description = "게시판 ID")
    @GetMapping(value = "/admin/survey/{boardId}")
    public ResponseEntity<?> getSurveyManageInfo(@PathVariable(value="boardId", required=true) int boardId) {

        TbAvnBoardDto result = service.selectSurveyDetail(boardId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 안전문화설문 등록", description = "신규 안전문화설문 등록 API")
    @PostMapping(value = "/admin/survey")
    public ResponseEntity<?> insertSurvey(@Valid @RequestBody(required=true) TbAvnBoardDto tbAvnBoardDto) {

        service.insertSurvey(tbAvnBoardDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전문화설문 정보 수정", description = "안전문화설문 정보 수정 API")
    @PutMapping(value = "/admin/survey/{boardId}")
    public ResponseEntity<?> updateSurvey(
            @PathVariable(value="boardId", required=true) int boardId,
            @Valid @RequestBody(required=true) TbAvnBoardDto tbAvnBoardDto) {

        tbAvnBoardDto.setBoardId(boardId);
        service.updateSurvey(tbAvnBoardDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전문화설문 삭제", description = "안전문화설문 삭제 API")
    @Parameter(name = "boardId", description = "게시판 ID")
    @DeleteMapping(value = "/admin/survey/{boardId}")
    public ResponseEntity<?> deleteSurvey(@PathVariable(value="boardId", required=true) int boardId) {

        service.deleteSurvey(boardId);
        return ResponseUtil.createSuccessResponse();
    }
}
