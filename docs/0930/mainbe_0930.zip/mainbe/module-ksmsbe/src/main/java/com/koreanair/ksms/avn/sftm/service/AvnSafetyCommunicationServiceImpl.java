package com.koreanair.ksms.avn.sftm.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnSafetyCommunicationServiceImpl extends AbstractBaseService implements AvnSafetyCommunicationService {

    // 안전증진 > Safety Program > Newsletter 목록
    @Override
    public PageInfo<TbAvnBoardDto> selectBoardList(BoardSearchDto boardSearchDto) {
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnBulletinManage.selectBoardList", boardSearchDto);
        return PageInfo.of(resultList);
    }

    // 안전증진 > Safety Program > Newsletter 상세
    @Override
    public TbAvnBoardDto selectBoardDetail(int boardId) {
        TbAvnBoardDto tbAvnBoardDto = new TbAvnBoardDto();
        tbAvnBoardDto.setBoardId(boardId);

        commonSql.update("AvnBulletinManage.updateViewCount", boardId);
        commonSql.insert("AvnBulletinManage.insertBoardDetail", tbAvnBoardDto);

        BoardSearchDto boardSearchDto = BoardSearchDto.builder().boardId(boardId).build();
        return commonSql.selectOne("AvnBulletinManage.selectBoardList", boardSearchDto);
    }
}
