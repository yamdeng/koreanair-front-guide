package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS_교육_열람_다운로드")
public class TbAvnEducationViewDownloadDto extends CommonDto {
    
    @Schema(description = "교육열람다운로드ID")
    @NotBlank
    private String educationViewDownloadId;
    
    @Schema(description = "교육ID")
    @NotBlank
    private String educationId;
    
    @Schema(description = "사원번호")
    @NotBlank
    private String empNo;
    
    @Schema(description = "부서코드")
    private String deptCd;
    
    @Schema(description = "열람다운로드코드")
    private String viewDownloadCd;
}
