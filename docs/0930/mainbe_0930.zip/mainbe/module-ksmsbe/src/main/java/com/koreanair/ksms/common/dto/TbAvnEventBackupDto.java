package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "EVENT_TYPE_백업")
public class TbAvnEventBackupDto extends CommonDto {
    
    @Schema(description = "이벤트ID")
    @NotBlank
    private String eventId;
    
    @Schema(description = "사원번호")
    @NotBlank
    private String empNo;
    
    @Schema(description = "리포트유형코드")
    @NotBlank
    private String reportTypeCd;
    
    @Schema(description = "이벤트국문명")
    @NotBlank
    private String eventKoNm;
    
    @Schema(description = "이벤트영문명")
    @NotBlank
    private String eventEnNm;
    
    @Schema(description = "표시순번")
    private String viewSn;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
}
