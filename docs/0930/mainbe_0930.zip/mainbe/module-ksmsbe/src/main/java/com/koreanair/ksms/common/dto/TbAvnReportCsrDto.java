package com.koreanair.ksms.common.dto;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트_CSR")
public class TbAvnReportCsrDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "레포트상세유형코드 : CODE_GRP_155")
    private String reportDtlTypeCd;
    private String reportDtlTypeKor;
    private String reportDtlTypeEng;
    
    @Schema(description = "환자유형코드 : CODE_GRP_099")
    private String patientTypeCd;
    private String patientTypeKor;
    private String patientTypeEng;
    
    @Schema(description = "발생시점코드 : CODE_GRP_021")
    private String occurTimeCd;
    private String occurTimeKor;
    private String occurTimeEng;
    
    @Schema(description = "주요증상코드 : CODE_GRP_015")
    private String mainSymptomCd;
    private String mainSymptomKor;
    private String mainSymptomEng;
    
    @Schema(description = "의사치료코드 : CODE_GRP_017")
    private String doctorTreatmentCd;
    private String doctorTreatmentKor;
    private String doctorTreatmentEng;
    
    @Schema(description = "문서코드 : CODE_GRP_018")
    private String documentCd;
    private String documentKor;
    private String documentEng;
    
    @Schema(description = "기내발생위치코드 : CODE_GRP_022")
    private String inflightOccurLocationCd;
    private String inflightOccurLocationKor;
    private String inflightOccurLocationEng;
    
    @Schema(description = "부상부위코드 : CODE_GRP_024")
    private String injuryPartCd;
    private String injuryPartKor;
    private String injuryPartEng;
    
    @Schema(description = "좌석벨트표시여부")
    @NotBlank
    private String seatbeltViewYn;
    
    @Schema(description = "주요원인코드 : CODE_GRP_027")
    private String mainCauseCd;
    private String mainCauseKor;
    private String mainCauseEng;
    
    @Schema(description = "행위종류코드 : CODE_GRP_029")
    private String actKindCd;
    private String actKindKor;
    private String actKindEng;
    
    @Schema(description = "승객클래스코드 : CODE_GRP_103")
    private String paxClsCd;
    private String paxClsKor;
    private String paxClsEng;
    
    @Schema(description = "카빈발생시간")
    private String cabinOccurTime;
    
    @Schema(description = "카빈발생타임존코드 : CODE_GRP_021 - kst 고정")
    private String cabinOccurTimezoneCd;
    private String cabinOccurTimezoneKor;
    private String cabinOccurTimezoneEng;
    
    @Schema(description = "안전수검유형코드 : CODE_GRP_096")
    private String safetyInspectionTypeCd;
    private String safetyInspectionTypeKor;
    private String safetyInspectionTypeEng;
    
    @Schema(description = "점검기관베이스코드 : CODE_GRP_097")
    private String checkAuthorityBaseCd;
    private String checkAuthorityBaseKor;
    private String checkAuthorityBaseEng;
    
    @Schema(description = "점검기관코드 : CODE_GRP_010")
    private String checkAuthorityCd;
    private String checkAuthorityKor;
    private String checkAuthorityEng;
    
    @Schema(description = "지적사항코드 : CODE_GRP_098")
    private String findingCd;
    private String findingKor;
    private String findingEng;
    
    @Schema(description = "점검관명")
    private String inspectorNm;
    
    @Schema(description = "담배종류코드 : CODE_GRP_100")
    private String cigaKindCd;
    private String cigaKindKor;
    private String cigaKindEng;
    
    @Schema(description = "증거수집여부")
    @NotBlank
    private String evidenceSeizedYn;
    
    @Schema(description = "경찰호출여부")
    @NotBlank
    private String policeCalledYn;
    
    @Schema(description = "단서코드 : CODE_GRP_101")
    private String clueCd;
    private String clueKor;
    private String clueEng;
    
    @Schema(description = "연기감지기알람작동코드 : CODE_GRP_102")
    private String smokeDetectorAlarmActivateCd;
    private String smokeDetectorAlarmActivateKor;
    private String smokeDetectorAlarmActivateEng;
    
    @Schema(description = "카빈로그여부")
    @NotBlank
    private String cabinLogYn;
    
    @Schema(description = "자발적하기여부")
    @NotBlank
    private String voluntaryDeplaneYn;
    
    @Schema(description = "하기원인코드 : CODE_GRP_013")
    private String deplaneCauseCd;
    private String deplaneCauseKor;
    private String deplaneCauseEng;
    
    @Schema(description = "동승승객여부")
    @NotBlank
    private String accompaniedPaxYn;
    
    @Schema(description = "지연여부")
    @NotBlank
    private String delayedYn;
    
    @Schema(description = "정비결함종류코드 : CODE_GRP_031")
    private String maintenanceDefectKindCd;
    private String maintenanceDefectKindKor;
    private String maintenanceDefectKindEng;
    
    @Schema(description = "기타보고종류코드 : CODE_GRP_032")
    private String etcBriefingKindCd;
    private String etcBriefingKindKor;
    private String etcBriefingKindEng;
    
    @Schema(description = "기타보고항목코드 : CODE_GRP_033")
    private String etcBriefingItemCd;
    private String etcBriefingItemKor;
    private String etcBriefingItemEng;
    
    @Schema(description = "화재연기냄새코드 : CODE_GRP_035")
    private String fireSmokeSmellCd;
    private String fireSmokeSmellKor;
    private String fireSmokeSmellEng;
    
    @Schema(description = "기타원인코드 : CODE_GRP_037")
    private String etcCauseCd;
    private String etcCauseKor;
    private String etcCauseEng;
    
    @Schema(description = "사용의료장비코드배열 : CODE_GRP_016")
    private String useMedicalEquipCdarr;
    private List<TbSysCodeDto> useMedicalEquipCdList;
    
    @Schema(description = "조치사항코드배열 : CODE_GRP_164")
    private String carCdarr;
    private List<TbSysCodeDto>  carCdList;
    
    @Schema(description = "추가조치사항코드배열 : CODE_GRP_164")
    private String addCarCdarr;
    private List<TbSysCodeDto>  addCarCdList;
    
    @Schema(description = "사용비상장비코드배열 : CODE_GRP_038")
    private String useEmergencyEquipCdarr;
    private List<TbSysCodeDto>  useEmergencyEquipCdList;
}
