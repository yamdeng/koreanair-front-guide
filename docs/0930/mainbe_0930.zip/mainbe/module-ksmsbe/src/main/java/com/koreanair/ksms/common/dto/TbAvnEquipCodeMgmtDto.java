package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "장비코드 관리")
public class TbAvnEquipCodeMgmtDto extends CommonDto {
    
    @Schema(description = "장비코드")
    @NotBlank
    private String equipCd;
    
    @Schema(description = "장비명")
    @NotBlank
    private String equipNm;
    
    @Schema(description = "모델명")
    private String modelNm;
    
    @Schema(description = "자사유형코드")
    @NotBlank
    private String companyTypeCd;
    
    @Schema(description = "부문코드")
    private String divisionCd;
    
    @Schema(description = "업체명")
    private String companyNm;
    
    @Schema(description = "제작일자")
    @NotBlank
    private String productionDt;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
}
