package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HazardCommentLogVo {
	private Integer id;
	
	private Integer hazardId;

	private String empNo;

	private String reason;
	
	private String phase;

	private String timezone;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "Asia/Seoul")
	private Timestamp regDttm;
	
	private String nameKor;
	
	private String nameEng;
	
	private Integer reportId;

	private String docNo;

}
