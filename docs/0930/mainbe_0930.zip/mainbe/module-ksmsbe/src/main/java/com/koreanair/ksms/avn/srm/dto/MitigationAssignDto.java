package com.koreanair.ksms.avn.srm.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

public class MitigationAssignDto {
	
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	@JsonInclude(value = Include.NON_NULL)
	public static class POST_Request {
		@NotNull
		private String leaderEmpNo;
		@NotNull
		private int deptId;
		
		private int hazardId;
		@NotNull
		private int groupId;
		
		private List<String> memberEmpNoList;
		
		private String timezone;
		
		private String reason;

		private String realMitigationPerform;
	}
	
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class PUT_Request {
		@NotNull
		private String leaderEmpNo;
		@NotNull
		private int deptId;
		
		private int hazardId;
		@NotNull
		private int groupId;
		
		private List<String> memberEmpNoList;
		
		private String reason;

		private Integer mitigationCenterDeptId;
		
	}

	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class PATCH_Request {
		@NotNull
		private String approvalType;
		@NotNull
		private int groupId;
		private String reason;
	}
}
