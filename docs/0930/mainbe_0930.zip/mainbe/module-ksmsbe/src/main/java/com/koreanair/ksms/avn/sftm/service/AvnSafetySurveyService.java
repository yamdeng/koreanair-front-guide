package com.koreanair.ksms.avn.sftm.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;

public interface AvnSafetySurveyService {

    // 안전증진 > 안전문화설문 목록 조회
    PageInfo<TbAvnBoardDto> selectSafetySurveyList(TbAvnBoardDto tbAvnBoardDto);

    // 안전증진 > 안전문화설문 상세
    TbAvnBoardDto selectSafetySurveyDetail(int boardId);
}
