package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.Accessors;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "lsc 정보")
public class SmLsc {
    @NotNull
    private int id;

    @NotNull
    private int receptionId;

    @NotNull
    private String empNo;

    private String memberType;

    private String groupId;

    private String timezone;

    //@NotNull
    //private Timestamp createdAt;

    //@NotNull
    //private Timestamp updatedAt;

    private Timestamp deletedAt;
}
