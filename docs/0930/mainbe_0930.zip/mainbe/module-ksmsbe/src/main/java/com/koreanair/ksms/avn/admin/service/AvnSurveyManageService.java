package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;

public interface AvnSurveyManageService {
    // 관리자 > 안전문화설문관리 목록 조회
    PageInfo< TbAvnBoardDto> selectSurveyList(TbAvnBoardDto tbAvnBoardDto);

    // 관리자 > 안전문화설문관리 신규 등록
    void insertSurvey(TbAvnBoardDto tbAvnBoardDto);

    // 관리자 > 안전문화설문관리 상세
    TbAvnBoardDto selectSurveyDetail(int boardId);

    // 관리자 > 안전문화설문관리 수정
    void updateSurvey(TbAvnBoardDto tbAvnBoardDto);

    // 관리자 > 안전문화설문관리 삭제
    void deleteSurvey(int boardId);
}








