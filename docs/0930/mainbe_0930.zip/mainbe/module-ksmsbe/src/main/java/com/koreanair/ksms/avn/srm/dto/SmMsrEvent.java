package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "접수 - MSR 이벤트 정보")
public class SmMsrEvent {

    @NotNull
    private int id;

    @NotNull
    private int reportId;

    @NotBlank
    @Size(max = 50)
    private String msrType;

    @Size(max = 100)
    private String locationText;

    @Size(max = 10)
    private String airport;

    @Size(max = 10)
    private String eventCode;

    @NotBlank
    @Size(max = 10)
    private String category;

    @Size(max = 50)
    private String maintenanceScope;

    @Size(max = 50)
    private String engine;

    @Size(max = 50)
    private String components;

    @Size(max = 50)
    private String etc;
}
