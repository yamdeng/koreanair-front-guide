package com.koreanair.ksms.common.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
public class LoggingAspect {

	 	@Pointcut("execution(* com.koreanair.ksms..*Controller.*(..))")
	    public void allControllerMethods() {}

	    @Pointcut("@annotation(com.koreanair.ksms.common.aspect.annotations.NoLoggingAspect)")
	    public void noLoggingAnnotation() {}

	    @Pointcut("allControllerMethods() && !noLoggingAnnotation())")
	    public void loggingPointcut() {}
	    
	  
	    
    
}
