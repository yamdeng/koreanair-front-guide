package com.koreanair.ksms.common.dto;

import java.util.List;

import lombok.Getter;
import lombok.experimental.SuperBuilder;

@Getter
@SuperBuilder
public class SearchReportConditionVo extends AvnSearchCondition {

	private List<String> reportEvents;
	
	private boolean searchASR;

	private String reportType;
}
