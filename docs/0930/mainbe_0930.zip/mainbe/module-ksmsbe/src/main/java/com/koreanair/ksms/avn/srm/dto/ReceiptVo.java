package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "보고서 접수 조회 항목")
public class ReceiptVo extends SmReception {
    private SmReport smReport;
    private KeEvent keEvent;
    private List<ReceiptAsrVo> receiptAsr;
    private SmReceptionFoqaVo receiptFoqa;
    private ReceiptHzrVo receiptHzr;
    private List<ReceiptLscVo> lscList;
    private List<PoFileVo> attachment;

    private List<ReceiptGroupListVo> receiptGroupList;

    private List<MsrEmailVo> msrEmailInfo;

    private String receiptEmpNo;
    private String receiptNameKo;
    private String receiptNameEn;
    private Integer receiptDeptId;

    private String ataAdapterTypeNameKo;
    private String ataAdapterTypeNameEn;
    private String controlDeptTypeNameKo;
    private String controlDeptTypeNameEn;
    private String classificationNameKo;
    private String classificationNameEn;

    private boolean isCreate;
    private String certification;
    private String sector;

    private String curPhase;
    private String curStepCode;
}
