package com.koreanair.ksms.avn.sftm.service;

public interface AvnSmsTrainingService {
}
