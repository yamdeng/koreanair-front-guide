package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "보고서 Hzd Event")
public class SmReceptionHzr {

    @NotNull
    private int hazardBenefitId;

    @NotNull
    private int receptionId;
}
