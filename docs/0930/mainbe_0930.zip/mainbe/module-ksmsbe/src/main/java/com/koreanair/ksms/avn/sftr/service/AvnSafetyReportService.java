package com.koreanair.ksms.avn.sftr.service;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sftr.dto.ReportSearchDto;
import com.koreanair.ksms.avn.sftr.dto.TreeCodeDto;
import com.koreanair.ksms.common.dto.TbAvnReportDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;

public interface AvnSafetyReportService {
    PageInfo<TbAvnReportDto> selectMyReportList(ReportSearchDto param) ;

    Map<String, Object> selectMyReportCountInfo(ReportSearchDto param) ;

    Map<String, Object> selectMyReportDetail(int reportId) ;
    Integer insertReport(ObjectNode saveObj) throws CustomBusinessException;
    void updateReport(int reportId, ObjectNode saveObj) throws CustomBusinessException;
    void deleteReport(int reportId) ;
    Integer submitReport(ObjectNode saveObj) throws CustomBusinessException;

    List<TreeCodeDto> selectTreeCodeList(String codetId) ;
    
}
