package com.koreanair.ksms.common.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CommonConstants {

    public static final String SESSION_NAME = "sessionInfo";
    public static final String DEFAULT_PROFILE = "local";

    public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";
    public static final String DATE_FORMAT_YYMMDD = "yyMMdd";
    public static final String DATE_FORMAT_YYYYMMDD_HHMMSS = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT_HHMMSS_SS = "HH:mm:ss.SS";
    public static final String DATE_FORMAT_DDMMYY = "ddMMyy";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSSMS = "yyyyMMddHHmmssSS";

    public static final String DATE_FORMAT_TIME_MILLISECONDS = "HHmmssSSS";

    public static final String YES_FLAG = "Y";
    public static final String NO_FLAG = "N";

    public static final int API_MAX_REQUEST_COUNT_IN_TTL = 5;

    public static final String SESSION_URI = "/v1/session";
    public static final String TEST_AUTOMATION_SESSION_URI = "/v1/testAutomation/session";

    public static final String HTTP_METHOD_OPTIONS = "OPTIONS";
    public static final String HTTP_METHOD_GET = "GET";
    public static final String HTTP_METHOD_POST = "POST";
    public static final String HTTP_METHOD_PUT = "PUT";
    public static final String HTTP_METHOD_DELETE = "DELETE";

    public static final String OKTA_ID_TOKEN = "idToken";
    public static final String APPLICATION_TOKEN = "applicationToken";
}