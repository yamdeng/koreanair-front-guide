package com.koreanair.ksms.batch.job;

/**
 * 부서정보 I/F Batch Job
 */
public class KsmsBatchJob002Configuration {
}
