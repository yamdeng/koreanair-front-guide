package com.koreanair.ksms.batch.base.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

public class BaseChunkLogger implements ChunkListener {

    private static final Logger log = LoggerFactory.getLogger(BaseChunkLogger.class);

    @Override
    public void beforeChunk(ChunkContext context) {
        StepContext stepContext = context.getStepContext();
        StepExecution stepExecution = stepContext.getStepExecution();

        //log.info("Chunk Starting ......... : " + context.toString());
        log.info("Chunk Starting ... : " + stepExecution.getReadCount());
    }

    @Override
    public void afterChunk(ChunkContext context) {

        //log.info("Chunk finished : " + context.toString());
        log.info("Chunk finished ... ");
    }

    @Override
    public void afterChunkError(ChunkContext context) {
        log.error("Chunk error occured : " + context.toString());
    }
}
