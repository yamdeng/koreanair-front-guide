package com.koreanair.ksms.batch.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class IfKeUserDto {

    private String eeid;
    private String nameKor;
    private String nameEng;
    private String emailWork;
    private String phone;
    private String jobLevelId;
    private String jobLevel;
    private String commCode;
    private String classC;
    private String classN;
    private String postTitle;
    private String divisionId;
    private String divisionCode;
    private String divisionName;
    private String departmentId;
    private String departmentCode;
    private String departmentName;
    private String teamId;
    private String teamCode;
    private String teamName;
    private String groupId;
    private String groupCode;
    private String groupName;
    private String lineteamId;
    private String lineteamCode;
    private String lineteamName;
}
