import { useState } from 'react';
import Config from '@/config/Config';
import AppNavigation from '../common/AppNavigation';
import AirportSearch from '../aviation/common/AirportSearch';

function GuideAirportSearch() {
  const [fromAirport, setFromAirport] = useState('');
  const changeFromAirport = (value) => {
    setFromAirport(value);
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          GuideAirportSearch :{' '}
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideAirportSearch.tsx`}>
            GuideAirportSearch
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid50">
              <AirportSearch
                label="출발 공항"
                value={fromAirport}
                onChange={(value) => {
                  changeFromAirport(value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid50">
              {/* <AvnReportUserSelectType2
                label="사용자검색2"
                userList={userList2}
                onSelect={onSelect2}
                deleteUser={deleteUser2}
                changeUserSelectKind={(value) => setUserSelectKind(value)}
                userSelectKind={userSelectKind}
              /> */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
export default GuideAirportSearch;
