import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
//import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';
import shareImage from '@/resources/images/share.svg';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useLocation } from 'react-router-dom';
import { Viewer } from '@toast-ui/react-editor';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';

import AppSearchInput from '@/components/common/AppSearchInput';

import useOcuRiskMasterStore from '@/stores/occupation/risk/useOcuRiskMasterStore';
import AppTextInput from '@/components/common/AppTextInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppUserSelectInput from '@/components/common/AppUserSelectInput';
import RiskHelpPeriodModal from '@/components/modal/occupation/RiskHelpPeriodModal';

import AppTextArea from '@/components/common/AppTextArea';

import {
  useOcuRiskTab2FormStore,
  useOcuRiskTab2SiteVisitListStore,
} from '@/stores/occupation/risk/useOcuRiskTab2FormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalFormTab2() {
  /* formStore state input 변수 */
  // const { detailInfo, getDetail, formType, cancel, goFormPage, clear, search, list } = useOcuRiskTab1FormStore();

  const { tabIndex, changeTab } = useOcuRiskMasterStore();

  // 청취조사
  const listenInfo = useOcuRiskTab2FormStore();
  // 현장순화
  const visitInfo = useOcuRiskTab2SiteVisitListStore();

  const {
    detailInfo,
    formValue,
    getDetail,
    formType,
    cancel,
    clear,
    search,
    removeByIndex,

    //goForm,
    changeInput,
    errors,
    // 청취조사
    listenChange,
    listenSaveStrore,
    listenAddRowStore,
    deleteListenList,
    // 현장순회
    deleteVisitList,
    visitChange,
    visitAddRowStore,
    visitSaveStrore,
    saveUseOcuRiskTab2,
    openFormModal,
    isCodeFormModalOpen,
    closeFormModal,
    okModal,
  } = listenInfo;

  const {
    /* 기본정보 */
    // 안전보건 정보 내용
    hlthSftyInfoCn,

    /* 청취조사 */
    // 위험성평가 문서 번호
    revalDocNo,

    // 근로자 성명
    lsurveyEmplNm,
    // 대상공정(작업)
    lsurveyProcNm,
    // 유해,위험요인에 대한 의견
    lsurveyHzdOpnn,

    /* 현장순회 */

    // 순회일자
    svisitDt,
    // 대상공정(작업)
    svisitProcNm,
    // 유해,위험요인에 대한 의견
    svisitHzdOpnn,
    // 사진 첨부
    svisitFileId,
  } = formValue;

  const { detailId } = useParams();
  const { docNo } = useParams();

  // 청취조사 행 삭제
  const DeleteActionButton = (props) => {
    const { node, onClick, data } = props;
    const { rowIndex } = node;

    const handleClick = (event) => {
      // 청취조사 삭제 list전달
      deleteListenList(props);
      event.stopPropagation();
      event.preventDefault();
      event.nativeEvent.stopPropagation();
      onClick(rowIndex);
    };
    return <div onClick={handleClick}>삭제</div>;
  };

  //  현장순회 행 삭제
  const DeleteActionButton2 = (props) => {
    const { node, onClick, data } = props;
    const { rowIndex } = node;

    const handleClick2 = (event) => {
      // 현장순회 삭제 list전달
      visitInfo.deleteVisitList(props);
      event.stopPropagation();
      event.preventDefault();
      event.nativeEvent.stopPropagation();
      onClick(rowIndex);
    };
    return <div onClick={handleClick2}>삭제</div>;
  };

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호', flex: 1 },
      { field: 'lsurveyEmplNm', headerName: '근로자', flex: 1 },
      { field: 'lsurveyProcNm', headerName: '대상공정(작업)', flex: 1 },
      { field: 'lsurveyHzdOpnn', headerName: '유해, 위험요인에 대한 의견', flex: 1 },
      {
        pinned: 'right',
        field: 'action',
        headerName: '',
        //flex: 1,
        // flex: 1,
        cellRenderer: 'deleteActionButton',
        cellRendererParams: {
          onClick: removeByIndex,
        },
      },
    ])
  );

  const [columns2, setColumns2] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호' },
      { field: 'svisitDt', headerName: '순회일자', flex: 1 },
      { field: 'svisitProcNm', headerName: '대상공정(작업)', flex: 1 },
      { field: 'svisitHzdOpnn', headerName: '유해, 위험요인에 대한 의견', flex: 1 },
      {
        pinned: 'right',
        field: 'action',
        headerName: '',
        //flex: 1,
        flex: 1,
        cellRenderer: 'deleteActionButton2',
        cellRendererParams: {
          onClick: visitInfo.removeByIndex,
        },
      },
    ])
  );

  // 청취조사 추가 버튼
  const customButtons1 = [
    {
      title: '추가',
      onClick: () => {
        listenAddRow();
      },
    },
  ];

  // 현장순회 추가 버튼
  const customButtons2 = [
    {
      title: '추가',
      onClick: () => {
        visitAddRow();
      },
    },
  ];

  // 청취조사 행 추가
  const listenAddRow = () => {
    console.log('로우 추가');
    setColumns((prevColumns) => [...prevColumns]);

    // 근로자 성명
    formValue.lsurveyEmplNm = '';
    // 대상공정(작업)
    formValue.lsurveyProcNm = '';
    // 유해,위험요인에 대한 의견
    formValue.lsurveyHzdOpnn = '';

    listenAddRowStore();
  };

  // 현장순회 행 추가
  const visitAddRow = () => {
    console.log('로우 추가');
    setColumns((prevColumns) => [...prevColumns]);

    // 순회일자
    formValue.svisitDt = '';
    // 대상공정(작업)
    formValue.svisitProcNm = '';
    // 유해,위험요인에 대한 의견
    formValue.svisitHzdOpnn = '';
    // 사진 첨부
    formValue.svisitFileId = '';

    visitInfo.visitAddRowStore();
  };

  const init = async () => {
    getDetail(detailId);
    search();
  };

  // useEffect(() => {
  //   init();
  //   return clear;
  // }, []);

  useEffect(() => {
    console.log('detailId===>', detailId);
    if (detailId && detailId !== 'add') {
      init();
    } else {
      console.log('초기화');
      // 리스트 초기화
      listenInfo.deleteAll();
      visitInfo.deleteAll();
    }
    return clear;
  }, []);

  // 청취조사 구성 행 변경
  const handleRowSingleClick = useCallback((selectedInfo) => {
    // const { rowIndex } = props;

    console.log('selectedInfo==>', selectedInfo);

    setColumns((prevColumns) => [...prevColumns]);
    listenChange(selectedInfo.data, selectedInfo.rowIndex);
  }, []);

  // 현장순회 행 변경
  const handleRowSingleClick2 = useCallback((selectedInfo) => {
    // const { rowIndex } = props;

    console.log('selectedInfo==>', selectedInfo);

    setColumns((prevColumns) => [...prevColumns]);
    visitInfo.visitChange(selectedInfo.data, selectedInfo.rowIndex);
  }, []);

  // 청취조사 저장
  const listenSave = () => {
    setColumns((prevColumns) => [...prevColumns]);

    const data = {
      // 근로자 성명
      lsurveyEmplNm: lsurveyEmplNm,
      // 대상공정(작업)
      lsurveyProcNm: lsurveyProcNm,
      // 유해,위험요인에 대한 의견
      lsurveyHzdOpnn: lsurveyHzdOpnn,
    };

    listenSaveStrore(data);
  };

  // 현장순회 저장
  const visitSave = () => {
    setColumns((prevColumns) => [...prevColumns]);

    console.log('svisitDt==>', svisitDt);

    const data = {
      // 순회일자
      svisitDt: svisitDt,
      // 대상공정(작업)
      svisitProcNm: svisitProcNm,
      // 유해,위험요인에 대한 의견
      svisitHzdOpnn: svisitHzdOpnn,
      // 사진 첨부
      svisitFileId: svisitFileId,
    };

    visitInfo.visitSaveStrore(data);
  };

  // // 평가 시기 도움말 팝업
  // const helpPeriod = () => {
  //   openFormModal(null);
  // };
  return (
    <>
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              청취조사<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="ck-edit-box">
                        <div className="ck-list">
                          {/* 그리드영역 */}
                          <AppTable
                            rowData={listenInfo.list}
                            columns={columns}
                            setColumns={setColumns}
                            store={listenInfo}
                            handleRowSingleClick={handleRowSingleClick}
                            customButtons={customButtons1}
                            hiddenPagination
                            components={{
                              deleteActionButton: DeleteActionButton,
                            }}
                          />
                        </div>
                        <div className="ck-edit">
                          <div className="boxForm">
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  <AppTextInput
                                    label="근로자"
                                    value={lsurveyEmplNm}
                                    onChange={(value) => {
                                      changeInput('lsurveyEmplNm', value);
                                    }}
                                    required
                                    errorMessage={errors.lsurveyEmplNm}
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  <AppTextInput
                                    label="대상공정(작업)"
                                    value={lsurveyProcNm}
                                    onChange={(value) => {
                                      changeInput('lsurveyProcNm', value);
                                    }}
                                    required
                                    errorMessage={errors.lsurveyProcNm}
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        {/* <textarea */}
                                        <AppTextArea
                                          id="testArea1"
                                          label="유해,위험요인에 대한 의견"
                                          // className="form-tag custom_textarea"
                                          // style={{ width: '100%' }}
                                          value={lsurveyHzdOpnn}
                                          onChange={(value) => changeInput('lsurveyHzdOpnn', value)}
                                          errorMessage={errors.lsurveyHzdOpnn}
                                        />
                                        {/* <label className="f-label" htmlFor="testArea1">
                                          유해,위험요인에 대한 의견
                                        </label> */}
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="btn-area-type01 mg-top">
                              <button type="button" name="button" className="btn_text btn_confirm" onClick={listenSave}>
                                저장
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              현장순회<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="ck-edit-box">
                        <div className="ck-list ck-list-grid">
                          {/* 그리드영역 */}
                          <AppTable
                            rowData={visitInfo.list}
                            columns={columns2}
                            setColumns={setColumns2}
                            handleRowSingleClick={handleRowSingleClick2}
                            store={visitInfo}
                            customButtons={customButtons2}
                            hiddenPagination
                            components={{
                              deleteActionButton2: DeleteActionButton2,
                            }}
                          />
                        </div>
                        <div className="ck-edit">
                          <div className="boxForm">
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  <AppDatePicker
                                    label={'순회일자'}
                                    pickerType="date"
                                    value={svisitDt}
                                    onChange={(value) => {
                                      changeInput('svisitDt', value);
                                    }}
                                    required
                                    errorMessage={errors.svisitDt}
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  <AppTextInput
                                    label="대상공정(작업)"
                                    value={svisitProcNm}
                                    onChange={(value) => {
                                      changeInput('svisitProcNm', value);
                                    }}
                                    required
                                    errorMessage={errors.svisitProcNm}
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <AppTextArea
                                          id="testArea1"
                                          label="유해,위험요인에 대한 의견"
                                          className="form-tag custom_textarea"
                                          // style={{ width: '100%' }}
                                          value={svisitHzdOpnn}
                                          onChange={(value) => changeInput('svisitHzdOpnn', value)}
                                          errorMessage={errors.svisitHzdOpnn}
                                        />
                                        {/* style={{ width: '100%' }} */}
                                        {/* <textarea
                                          id="testArea1"
                                          className="form-tag custom_textarea"
                                          style={{ width: '100%' }}
                                          name="testArea1"
                                          value={svisitHzdOpnn}
                                        />
                                        <label className="f-label" htmlFor="testArea1">
                                          유해,위험요인에 대한 의견
                                        </label> */}
                                        {/* <span className="text-desc-type1">{svisitHzdOpnn}</span> */}
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <h3 className="table-tit mb-10">사진 첨부</h3>
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="사진 첨부"
                                    fileGroupSeq={svisitFileId}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      changeInput('svisitFileId', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="btn-area-type01 mg-top">
                              <button type="button" name="button" className="btn_text btn_confirm" onClick={visitSave}>
                                저장
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              안전보건 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextArea
                          id="testArea1"
                          label="내용"
                          className="form-tag custom_textarea"
                          value={hlthSftyInfoCn}
                          onChange={(value) => changeInput('hlthSftyInfoCn', value)}
                          errorMessage={errors.hlthSftyInfoCn}
                        />

                        {/* <textarea
                          id="testArea1"
                          className="form-tag custom_textarea"
                          style={{ width: '100%' }}
                          name="testArea1"
                          value={hlthSftyInfoCn}
                        />
                        <label className="f-label" htmlFor="testArea1">
                          내용
                        </label> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      <RiskHelpPeriodModal isOpen={isCodeFormModalOpen} closeModal={closeFormModal} ok={okModal} />

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text btn-share">
          <img src={shareImage} />
          {/* onClick={() => handleCopyClipBoard(`${baseUrl}${location.pathname}`)} */}
          {/* baseurl 추가해야함 */}
          {/* <span onClick={() => handleCopy(`${location.pathname}`)}>공유</span> */}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={saveUseOcuRiskTab2}
          // style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          저장
        </button>
        {/* <button type="button" name="button" className="btn_text btn-del">
          삭제
        </button> */}
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
      </div>
    </>
  );
}
export default RevalFormTab2;
