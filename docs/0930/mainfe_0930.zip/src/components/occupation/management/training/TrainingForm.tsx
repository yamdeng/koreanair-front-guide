import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppEditor from '@/components/common/AppEditor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import AppTextInput from '@/components/common/AppTextInput';
import useAppStore from '@/stores/useAppStore';
import CommonUtil from '@/utils/CommonUtil';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from 'zustand';
import AppUserReadOnlyInput from '@/components/common/AppUserReadOnlyInput';
import LinkAttachModal from '@/components/modal/LinkAttachModal';
import AppDeptReadOnlyInput from '@/components/common/AppDeptReadOnlyInput';
/* TODO : store 경로를 변경해주세요. */
import useOcuMajorDssTrainingFormStore from '@/stores/occupation/management/useOcuMajorDssTrainingFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function TrainingForm() {
  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    save,
    remove,
    // cancel,
    clear,
    openLinkAttachModal,
    isLinkAttachModalOpen,
    closeLinkAttachModal,
    linkAttachDetailInfo,
    okLinkAttachModal,
    removeLinkAttach,
  } = useOcuMajorDssTrainingFormStore();

  const profile = useStore(useAppStore, (state) => state.profile);

  // 작성자명
  const userId = profile.userInfo.userId;
  const loginDeptCd = profile.userInfo.deptCd;
  console.log('profile==>', profile);

  // 오늘날짜 가져오기
  const currentDate = CommonUtil.getToDate();
  const {
    // 부문 코드
    sectCd,
    // 재난유형코드
    dssTypeCd,
    // 기타유형
    etcType,
    // 부서코드
    deptCd,
    // 훈련일
    trainDt,
    // 훈련장소
    trainLocation,
    // 참석자 명단
    prtcNmList,
    // 훈련명
    trainNm,
    // 평가내용
    evalContent,
    // 첨부파일 ID
    fileId,
    // 첨부링크 ID
    linkId,
    // 링크 첨부 리스트
    linkAttachList,
    // 등록일시
    regDttm,
    // 등록자 ID
    regUserId,
  } = formValue;

  const { detailId } = useParams();

  useEffect(() => {
    console.log('detailId==>', detailId);
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>중대재해대응훈련</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppUserReadOnlyInput
                label="작성자"
                value={detailId === 'add' ? userId : regUserId}
                required
                disabled="false"
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDatePicker
                label="작성일자"
                value={detailId === 'add' ? currentDate : regDttm}
                onChange={(value) => changeInput(detailId === 'add' ? 'currentDate' : 'regDttm', value)}
                required
                disabled
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label="부문"
                codeGrpId="CODE_GRP_OC001"
                value={sectCd} // 작성자 정보로 부문 가져와야함
                onChange={(value) => changeInput('sectCd', value)}
                required
                disabled={formType !== 'add' ? true : false}
                errorMessage={errors.sectCd}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDeptReadOnlyInput label="부서" value={detailId === 'add' ? loginDeptCd : deptCd} required />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label="재난유형"
                codeGrpId="CODE_GRP_OC006"
                value={dssTypeCd}
                onChange={(value) => changeInput('dssTypeCd', value)}
                errorMessage={errors.dssTypeCd}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuMajorDssTrainingFormetcType"
                name="etcType"
                label="기타유형"
                value={etcType}
                onChange={(value) => changeInput('etcType', value)}
                errorMessage={errors.etcType}
                placeholder="기타 선택 시 입력"
                disabled={dssTypeCd !== 'M'}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDatePicker
                label="훈련 실시일자"
                value={trainDt}
                onChange={(value) => changeInput('trainDt', value)}
                valueFormat="YYYYMMDD"
                errorMessage={errors.trainDt}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="훈련장소"
                value={trainLocation}
                onChange={(value) => changeInput('trainLocation', value)}
                errorMessage={errors.trainLocation}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="참석자명단"
                value={prtcNmList}
                onChange={(value) => changeInput('prtcNmList', value)}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="훈련명"
                value={trainNm}
                onChange={(value) => changeInput('trainNm', value)}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppEditor
                id="OcuMajorDssTrainingFormevalContent"
                name="evalContent"
                label="내용 및 평가"
                value={evalContent}
                onChange={(value) => changeInput('evalContent', value)}
                errorMessage={errors.evalContent}
                required
                placeholder="훈련 내용을 입력해주세요."
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppFileAttach
                mode="edit"
                label="파일첨부"
                fileGroupSeq={fileId}
                workScope={'O'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileId', newFileGroupSeq);
                }}
              />
            </div>
          </div>
        </div>

        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="group-box-wrap line wid100">
              <span className="txt">링크 첨부</span>
              {/* 링크팝업명: MU1P5detail2Modal */}
              <button type="button" name="button" className="btn-plus" onClick={() => openLinkAttachModal()}>
                추가
              </button>
              <div className="file-link">
                {linkAttachList
                  ? linkAttachList.map((linkInfo, linkAttachListLindex) => {
                      const { linkUrl, linkSbj } = linkInfo;
                      return (
                        <div key={linkUrl} className="link-box">
                          <a href={undefined} onClick={() => openLinkAttachModal(linkInfo)}>
                            {linkSbj}
                          </a>
                          <a href={undefined} onClick={() => removeLinkAttach(linkAttachListLindex)}>
                            <span className="close-btn">close</span>
                          </a>
                        </div>
                      );
                    })
                  : null}
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <LinkAttachModal
          isOpen={isLinkAttachModalOpen}
          closeModal={closeLinkAttachModal}
          ok={okLinkAttachModal}
          detailInfo={linkAttachDetailInfo}
        />
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={close}>
          취소
        </button>
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
      </div>
    </>
  );
}
export default TrainingForm;
