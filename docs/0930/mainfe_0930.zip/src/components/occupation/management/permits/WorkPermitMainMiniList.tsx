import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/permits',
  baseRoutePath: '/occupation/management/permits',
};

/* zustand store 생성 */
const OcuOutSourcingListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  clear: () => {},
}));

function WorkPermitMainMiniList() {
  const state = OcuOutSourcingListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      // NEED TO CHECK : NEED TO CHECK THE DATA FOR TABLE
      { field: 'cntrLocationNm', headerName: '공사장소' },
      { field: 'cntrPositionNm', headerName: '공사위치' },
      { field: 'cntrAreaNm', headerName: '공사분야' },
      { field: 'cnstCmpny', headerName: '작업구분' },
      { field: 'cntrNm', headerName: '공사명' },
      {
        field: 'cntrApplyStartDttm',
        headerName: '공사기간',
        valueGetter: (p) => p.data.cntrApplyStartDttm + ' ~ ' + p.data.cntrApplyEndDttm,
      },
      { field: 'wrkStatusNm', headerName: '작업상태' },
    ])
  );
  const { enterSearch, list, clear, goDetailPage } = state;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    const detailId = data.cntrId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <div className="conts-title">
        <h2>외주작업 신청 현황</h2>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
    </>
  );
}

export default WorkPermitMainMiniList;
