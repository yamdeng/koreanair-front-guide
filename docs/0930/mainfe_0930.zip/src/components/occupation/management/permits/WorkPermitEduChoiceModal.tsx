import AppFileAttach from '@/components/common/AppFileAttach';
import useOcuWorkPermitEduChoiceModalStore from '@/stores/occupation/management/useOcuWorkPermitEduChoiceModalStore';
import ReactUtil from '@/utils/ReactUtil';
import { Upload } from 'antd';
import { useEffect, useState } from 'react';
import Modal from 'react-modal';

function WorkPermitEduChoiceModal(props) {
  const { isOpen, isClose, onSubmit, ok } = props;

  const state = useOcuWorkPermitEduChoiceModalStore();
  const { changeInput, formValue, baseEduChoiceList } = state;

  const { eduChoiceList } = formValue;

  // const handleClearSelection = () => {
  //   setCheckboxStates({''});
  // };

  useEffect(() => {
    if (isOpen) {
      console.log('Modal is opened.');
    }
  }, [isOpen]);

  useEffect(() => {
    console.log(eduChoiceList);
  });

  const handleClose = () => {
    alert('교육 내용이 첨부되지 않았습니다. 창을 닫으시겠습니까?');
    // 닫을 때 선택 정보 초기화
    isClose();
  };

  // 선택한 체크박스 항목을 배열에 반영해야혀
  const handleSubmit = () => {
    // ok();
    // 부모 컴포넌트로 eduChoiceList 전달 - NEED TO CHECK : NEED TO FILL IN
    onSubmit(eduChoiceList);
    alert('교육내용이 저장되었습니다.');
    isClose();
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">특별교육</h3>
        <span className="txt-guide">산업안전보건법 시행규칙 제26조 및 별표5</span>
        <div className="pop_cont">
          <div className="editbox">
            {eduChoiceList.map((info, index) => {
              const { spclEduItemCd, title, subList, chcYn } = info;
              return (
                <>
                  <div className="form-table">
                    <div className="form-cell1 wid50">
                      <div className="group-box-wrap wid100">
                        <div className="radio-wrap">
                          <label className="type01">
                            <input
                              type="checkbox"
                              checked={chcYn === 'Y' ? true : false}
                              onChange={(event) => {
                                const checked = event.target.checked;
                                changeInput(`eduChoiceList[${index}].chcYn`, checked ? 'Y' : 'N');
                              }}
                            />
                            <span
                              className="type01"
                              dangerouslySetInnerHTML={{ __html: ReactUtil.convertEnterStringToBrTag(title) }}
                            />
                            <ul className="ck-guide">
                              {subList.map((subListTititle, index) => {
                                return <li key={index}>{subListTititle}</li>;
                              })}
                            </ul>
                          </label>
                        </div>
                      </div>
                      {/* 파일첨부영역 : button */}
                      <div className="form-table">
                        <div className="form-cell wid50">
                          <div className="form-group wid100">
                            <AppFileAttach
                              mode="edit"
                              label="파일첨부"
                              fileGroupSeq={''}
                              workScope={'O'}
                              updateFileGroupSeq={(newFileGroupSeq) => {
                                changeInput(`eduChoiceList[${index}].fileId`, newFileGroupSeq);
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr className="line"></hr>
                </>
              );
            })}
          </div>
        </div>

        <div className="pop_btns mt-20">
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleSubmit}>
            저장
          </button>
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            취소
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default WorkPermitEduChoiceModal;
