import { useEffect, useState } from 'react';
import AppTextInput from '@/components/common/AppTextInput';
import AppFileAttach from '@/components/common/AppFileAttach';
import useOcuWorkPermitFormStore from '@/stores/occupation/management/useOcuWorkPermitFormStore';

const list = [
  {
    name: '전설기계 사용작업',
    checked: false,
    children: [
      {
        code: 'A',
        checked: false,
      },
      {
        code: 'B',
        checked: false,
      },
      {
        code: 'C',
        checked: false,
      },
      {
        code: 'D',
        checked: false,
        fileGroupSeq: null,
        text: '',
      },
    ],
  },
];

function WorkPermitDeviceChecklist() {
  const { changeInput, formValue } = useOcuWorkPermitFormStore();
  const [selectedWorkWithDeviceInfo, setSelectedWorkWithDeviceInfo] = useState([
    {
      checkedWork: '',
      checkedDevice: '',
      fileGroupSeq: '',
    },
  ]);
  console.log('selectedWorkWithDeviceInfo : ', selectedWorkWithDeviceInfo);

  const {
    // 공사 작업코드
    cntrWrkCd,
    // 반입장비코드
    imprtEqpmCd,
    // 파일ID
    fileId,
    // 수기입력
    importEqpmNm,
  } = formValue;

  // 1. Manage Parent checkbox states
  const [selectedWork, setSelectedWork] = useState({
    // common: true, always already checked - default
    // NEED TO CHECK : DELETE THE COMMON IN GROUP CODE AS WELL_DONE(Sep 27th)
    // 밀페공간
    confinedSpace: false,
    // 전기작업
    electrical: false,
    // 화재
    fireRisk: false,
    // 고소작업
    highPlace: false,
    // 줄걸이
    hanging: false,
    // 기계
    constructionMachine: false,
  });

  // Change checkbox state on Click
  const handleCheckboxChange = (event) => {
    const { name, checked } = event.target;
    console.log(`Checkbox ${name} is now ${checked}!!!!`);
    setSelectedWork((prev) => ({
      ...prev,
      [name]: checked,
    }));
    console.log(`${name} checked: ${checked}`);
  };

  const [selectedParentValue, setSelectedParentValue] = useState(null);
  const handleFirstCheckboxChange = (e) => {
    handleCheckboxChange(e);
    const { name, value, checked } = e.target;
    if (checked) {
      setSelectedParentValue(value); // store the value of the 1st checkbox
      setSelectedWork((prevState) => ({
        ...prevState,
        [value]: null, // When selected, use the value as the key
        [name]: checked,
      }));
    } else {
      const updatedWork = { ...selectedWork };
      delete updatedWork[value];
      setSelectedParentValue(null); // Reset the parentValue when uncheked
      // setSelectedWork(null);
    }
    console.log('Currently Selected Parent value is : ', value);

    /*
      1. 체크여부판단
      2. 체크 X - 작업구분리스트에서 ROW 삭제 ( 부모값을 가진 모든걸 찾아서 삭제 )
      
    */
  };

  const handleSecondCheckboxChange = (e, parentValue) => {
    const { value } = e.target;
    setSelectedWork((prevState) => ({
      ...prevState,
      [selectedParentValue]: [value], // Link the 2nd checkbox value to the parent checkbox's value
    }));
    console.log(`Parent ${selectedParentValue} linked to value: ${value}`);
    console.log('selectedWork : ', selectedWork);
    /*
      1. 체크여부판단
      2. 체크 O - 작업구분리스트에서 ROW 추가
      3. 체크 X - 작업구분리스트에서 ROW 삭제 ( 찾아서 삭제 )
      
    */
  };

  useEffect(() => {
    console.log('Currently selected work:', selectedWork);
  }, [selectedWork]); // Whenever selectedWork is changed,

  return (
    <div className="form-table">
      <div className="form-cell wid50">
        <div className="form-group wid100">
          <h3 className="table-tit">작업 구분</h3>
          <div className="work-group">
            <table className="work-table">
              <thead>
                <tr>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input type="checkbox" name="common" checked />
                        <span className="type02">공통(일반)</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input
                          type="checkbox"
                          name="confinedSpace"
                          onClick={handleFirstCheckboxChange}
                          onChange={(value) => changeInput('cntrCd', value)}
                          checked={selectedWork.confinedSpace}
                          value="S"
                        />
                        <span className="type02">밀폐공간작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input
                          type="checkbox"
                          name="electrical"
                          onClick={handleFirstCheckboxChange}
                          onChange={(value) => changeInput('cntrCd', value)}
                          checked={selectedWork.electrical}
                          value="E"
                        />
                        <span className="type02">전기작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input
                          type="checkbox"
                          name="fireRisk"
                          onClick={handleFirstCheckboxChange}
                          onChange={(value) => changeInput('cntrCd', value)}
                          checked={selectedWork.fireRisk}
                          value="F"
                        />
                        <span className="type02">화재위험작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input
                          type="checkbox"
                          name="highPlace"
                          onClick={handleFirstCheckboxChange}
                          onChange={(value) => changeInput('cntrCd', value)}
                          checked={selectedWork.highPlace}
                          value="H"
                        />
                        <span className="type02">고소작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input
                          type="checkbox"
                          name="hanging"
                          onClick={handleFirstCheckboxChange}
                          onChange={(value) => changeInput('cntrCd', value)}
                          checked={selectedWork.hanging}
                          value="R"
                        />
                        <span className="type02">줄걸이작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input
                          type="checkbox"
                          name="constructionMachine"
                          onClick={handleFirstCheckboxChange}
                          onChange={(value) => changeInput('cntrCd', value)}
                          // checked={
                          // {
                          /**
                           * 1. 작업구분LIST 작업이 있는지 건수를 체크하는 함수 개발
                           *  - 파라미터 받기 ( 작업구분 )
                           *  - 작업구분이  0 > TRUE, FALSE
                           */
                          //     true
                          //   }
                          // }
                          value="C"
                        />
                        <span className="type02">건설기계 사용작업</span>
                      </label>
                    </div>
                  </th>
                </tr>
              </thead>
              {/* The start point of 2nd Chceckbox area */}
              <tbody>
                <tr>
                  <td colSpan={7}>
                    {/* 밀폐공간작업선택 - active */}
                    <div className={`work-ck-list ${selectedWork.confinedSpace ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th>밀폐공간작업</th>
                          <td>해당사항없음</td>
                          <td></td>
                        </tr>
                      </table>
                    </div>
                    {/* 전기작업선택 - active */}
                    <div className={`work-ck-list ${selectedWork.electrical ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th>전기작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  value="O"
                                  // checked={/**
                                  //  * 1. 함수를 만든다
                                  //  *  - 파라미터를 2개를 받는다 (내꺼)
                                  //  *  - 1건 나오면. true, false
                                  //  */}
                                  onChange={handleSecondCheckboxChange}
                                />
                                <span className="type02">
                                  고압 전기작업 (1,500~7,000V 직류전압 또는 1,000~7,000V 교류전압)
                                </span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                      </table>
                    </div>

                    {/* 화재위험작업선택 */}
                    <div className={`work-ck-list ${selectedWork.fireRisk ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th rowSpan={3}>화재위험작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="A" onChange={handleSecondCheckboxChange} />
                                <span className="type02">가스 용접·용단작업</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="B" onChange={handleSecondCheckboxChange} />
                                <span className="type02">전기 용접작업</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="C" onChange={handleSecondCheckboxChange} />
                                <span className="type02">연삭기 사용작업</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                      </table>
                    </div>

                    {/* 고소 작업선택 */}
                    <div className={`work-ck-list ${selectedWork.highPlace ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th rowSpan={4}>고소 작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="D" onChange={handleSecondCheckboxChange} />
                                <span className="type02">이동식 사다리</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="E" onChange={handleSecondCheckboxChange} />
                                <span className="type02">달비계</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="F" onChange={handleSecondCheckboxChange} />
                                <span className="type02">시저형 고소작업대(렌탈)</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={''}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      changeInput('fileId', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">- 안전인증서</span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="G" onChange={handleSecondCheckboxChange} />
                                <span className="type02">차량탑재형 고소작업대(스카이차)</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={''}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      changeInput('fileId', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 자동차등록증 - 안전검사합격증명서 - 기능기운전기능사 또는 교육기관 교육 이수 - 화물운전
                              종사 자격증
                            </span>
                          </td>
                        </tr>
                      </table>
                    </div>

                    {/* 줄걸이 작업선택 */}
                    <div className={`work-ck-list ${selectedWork.hanging ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th rowSpan={2}>줄걸이 작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="H" onChange={handleSecondCheckboxChange} />
                                <span className="type02">기중기(건설기계)</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={''}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      changeInput('fileId', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 건설기계등록증 - 건설기계조종사 면허증 - 건설기계조종사 안전교육 이수증
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="I" onChange={handleSecondCheckboxChange} />
                                <span className="type02">차량탑재형 이동식크레인(카고크레인)</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={''}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      changeInput('fileId', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 자동차등록증 - 안전검사합격증명서 - 기능기운전기능사 또는 교육기관 교육 이수 - 화물운전
                              종사 자격증
                            </span>
                          </td>
                        </tr>
                      </table>
                    </div>
                    {/* 건설기계 작업선택 */}
                    <div className={`work-ck-list ${selectedWork.constructionMachine ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th rowSpan={3}>건설기계 사용 작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="J" onChange={handleSecondCheckboxChange} />
                                <span className="type02">굴착기</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={''}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      changeInput('fileId', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 건설기계등록증 - 건설기계조종사 면허증 - 건설기계조종사 안전교육 이수증
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" value="K" onChange={handleSecondCheckboxChange} />
                                <span className="type02">지게차</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={''}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      changeInput('fileId', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 건설기계등록증 - 건설기계조종사 면허증 - 건설기계조종사 안전교육 이수증
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input type="checkbox" />
                                <span className="type02">수기 입력 : </span>
                              </label>
                            </div>
                            <div className="form-cell wid100 border-b-no">
                              <div className="form-group wid100">
                                <AppTextInput
                                  label="수기입력"
                                  value={importEqpmNm}
                                  onChange={(value) => changeInput('importEqpmNm', value)}
                                />
                              </div>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={''}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      changeInput('fileId', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </table>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
export default WorkPermitDeviceChecklist;
