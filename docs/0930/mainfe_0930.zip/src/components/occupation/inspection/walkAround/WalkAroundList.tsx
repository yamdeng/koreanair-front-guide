import { create } from 'zustand';
import { useEffect, useState, useCallback } from 'react';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import CommonUtil from '@/utils/CommonUtil';
import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppTextInput from '@/components/common/AppTextInput';
import AppUserSelectInput from '@/components/common/AppUserSelectInput';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';

/* zustand store 생성 */
const OcuSvisitCheckStatusStore = create<any>((set, get) => ({
  ...createListSlice(set, get),
  ...listBaseState,
  listApiPath: 'ocu/inspection/walkAround/content',
  baseRoutePath: '/occupation/inspection/walkAround',
  searchParam: { sectStatusCd: '', deptStatusCd: '', chkYearMonth: '', bizPlaceClsCd: '' },
}));

const OcuSvisitCheckStatusDetailStore = create<any>((set, get) => ({
  ...createListSlice(set, get),
  ...listBaseState,
  listApiPath: 'ocu/inspection/walkAround/content',

  searchDetail: async (detailId) => {
    const { listApiPath, search } = get();
    await set({ listApiPath: listApiPath`/${detailId}` });
    search();
  },
}));

const OcuSvisitCheckListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),
  ...listBaseState,
  listApiPath: 'ocu/inspection/walkAround',
  baseRoutePath: '/occupation/inspection/walkAround',
  searchStatusParam: { sectCd: '', deptCd: '', fromActionDt: '', toActionDt: '', regUserId: '' },
}));

function OcuSvisitCheck() {
  const [activeTab, setActiveTab] = useState('A');

  return (
    <>
      <AppNavigation />
      {/* 헤더 */}
      <div className="conts-title">
        <h2>작업장 순회 점검 현황</h2>
      </div>
      {/* 탭 */}
      <div className="menu-tab-nav">
        <div className="menu-tab">
          <a
            href="javascript:void(0);"
            className={activeTab === 'A' ? 'active' : ''} // activeTab 상태에 따라 className을 동적으로 설정합니다.
            data-label="현황"
            onClick={(e) => {
              e.preventDefault(); // 페이지 이동을 막습니다.
              setActiveTab('A');
            }}
          >
            현황
          </a>
          <a
            href="javascript:void(0);"
            className={activeTab === 'B' ? 'active' : ''} // activeTab 상태에 따라 className을 동적으로 설정합니다.
            data-label="목록"
            onClick={(e) => {
              e.preventDefault(); // 페이지 이동을 막습니다.
              setActiveTab('B');
            }}
          >
            목록
          </a>
        </div>
      </div>

      {/* 현황탭 */}
      <div style={{ display: activeTab === 'A' ? 'block' : 'none' }}>
        <OcuSvisitCheckStatus />
      </div>

      {/*목록 */}
      <div style={{ display: activeTab === 'B' ? 'block' : 'none' }}>
        <OcuSvisitCheckList />
      </div>
    </>
  );
}

function OcuSvisitCheckStatus() {
  const state1 = OcuSvisitCheckStatusStore();
  const state2 = OcuSvisitCheckStatusDetailStore();
  const {
    search,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    enterSearch,
    searchParam,
  } = state1;
  const { searchDetail } = state2;

  const profile = useStore(useAppStore, (state) => state.profile);

  const storeDeptCd = profile.userInfo.deptCd; // 사용자 부서

  const adminDeptCd = 'AAA'; // TODO: 관리 부서 세팅

  const { sectStatusCd, deptStatusCd, chkYearMonth, bizPlaceClsCd } = searchParam;

  const [columnsStatus, setColumnsStatus] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'ptnrId', headerName: '협력업체' },
      { field: 'bizPlaceClsCd', headerName: '사업장 구분' },
      { field: 'chkDate', headerName: '점검일자' },
    ])
  );

  const [columnsStatusDeail, setColumnsStatusDeail] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'ptnrNm', headerName: '협력업체' },
      { field: 'bizPlaceClsCd', headerName: '사업장 구분' },
      { field: 'actionDt', headerName: '점검일자' },
      { field: 'chkItemNm', headerName: '점검 항목' },
      { field: 'chkContent', headerName: '점검 내용' },
    ])
  );

  const handleStatusRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    const detailId = data.chkItemId;
    searchDetail(detailId);
  }, []);

  useEffect(() => {
    enterSearch();

    return clear;
  }, []);

  return (
    <>
      {/* 검색 input 영역 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  applyAllSelect={adminDeptCd === storeDeptCd ? true : false}
                  label={'부문'}
                  codeGrpId="CODE_GRP_OC001"
                  value={sectStatusCd}
                  onChange={(value) => {
                    changeSearchInput('sectStatusCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDeptSelectInput
                  label={'부서'}
                  value={deptStatusCd}
                  onChange={(value) => {
                    changeSearchInput('deptStatusCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDatePicker
                  label={'점검연월'}
                  value={chkYearMonth}
                  onChange={(value) => {
                    changeSearchInput('chkYearMonth', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_OC010"
                  label={'사업장 구분'}
                  value={bizPlaceClsCd}
                  onChange={(value) => {
                    changeSearchInput('bizPlaceClsCd', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={search}>
              조회
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              초기화
            </button>
          </div>
        </div>
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>

      {/*그리드영역 */}
      <div>
        <h3 className="table-tit">점검 현황</h3>
        <AppTable
          rowData={state1.list}
          columns={columnsStatus}
          setColumns={setColumnsStatus}
          store={state1}
          handleRowDoubleClick={handleStatusRowDoubleClick}
          hiddenPagination
        />
        <div className="pt-20">
          <h3 className="table-tit">부적합 사항</h3>
          <AppTable
            rowData={state2.list}
            columns={columnsStatusDeail}
            setColumns={setColumnsStatusDeail}
            store={state2}
            hiddenPagination
          />
        </div>
      </div>
    </>
  );
}

function OcuSvisitCheckList() {
  const state = OcuSvisitCheckListStore();
  const {
    search,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    getDetail,
  } = state;

  const { sectCd, deptCd, chkRegStartDt, chkRegEndDt, regUserId } = searchParam;

  const profile = useStore(useAppStore, (state) => state.profile);

  const storeDeptCd = profile.userInfo.deptCd; // 사용자 부서

  const adminDeptCd = 'AAA'; // TODO: 관리 부서 세팅

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'chkListClsCd', headerName: '점검표_구분_코드' },
      { field: 'chkTitle', headerName: '점검_제목' },
      { field: 'chkRegStartDt', headerName: '점검_등록_시작일자' },
      { field: 'chkRegEndDt', headerName: '점검_등록_종료일자' },
    ])
  );

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    const detailId = data.chkId;
    getDetail(detailId);
  }, []);

  useEffect(() => {
    search();

    return clear;
  }, []);

  return (
    <>
      {/* 검색 input 영역 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  applyAllSelect={adminDeptCd === storeDeptCd ? true : false}
                  label={'부문'}
                  codeGrpId="CODE_GRP_OC001"
                  value={sectCd}
                  onChange={(value) => {
                    changeSearchInput('sectCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDeptSelectInput
                  label={'부서'}
                  value={deptCd}
                  onChange={(value) => {
                    changeSearchInput('deptCd', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={'점검기간'}
                      value={chkRegStartDt}
                      onChange={(value) => {
                        changeSearchInput('chkRegStartDt', value);
                      }}
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label={'점검기간'}
                      value={chkRegEndDt}
                      onChange={(value) => {
                        changeSearchInput('chkRegEndDt', value);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppUserSelectInput
                  label="작성자"
                  value={regUserId}
                  onChange={(value) => {
                    changeSearchInput('regUserId', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput label={'제목'} />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={search}>
              조회
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              초기화
            </button>
          </div>
        </div>
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>

      {/*그리드영역 */}
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />

      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default OcuSvisitCheck;
