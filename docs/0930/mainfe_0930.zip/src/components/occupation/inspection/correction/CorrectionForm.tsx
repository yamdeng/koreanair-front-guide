import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  chkItemNm: yup.string().required(),
  chkLclsCd: yup.string().required(),
  chkScls: yup.string().required(),
  chkContent: yup.string().required(),
  chkRelLaw: yup.string(),
  chkPohtoId1: yup.number().nullable(),
  chkPohtoId2: yup.number().nullable(),
  chkFile: yup.number().nullable(),
  rightActionYn: yup.string(),
  actionStatusCd: yup.string(),
  actionContent: yup.string(),
  actionAttPhotoId: yup.number().nullable(),
  actionAttFileId: yup.number().nullable(),
  actionDt: yup.string(),
  actionDeptCd: yup.string(),
  actionEmpno: yup.string(),
  aprvDt: yup.string(),
  aprvDeptCd: yup.string(),
  aprvEmpno: yup.string(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  chkItemNm: '',
  chkLclsCd: '',
  chkScls: '',
  chkContent: '',
  chkRelLaw: '',
  chkPohtoId1: null,
  chkPohtoId2: null,
  chkFile: null,
  rightActionYn: '',
  actionStatusCd: '',
  actionContent: '',
  actionAttPhotoId: null,
  actionAttFileId: null,
  actionDt: '',
  actionDeptCd: '',
  actionEmpno: '',
  aprvDt: '',
  aprvDeptCd: '',
  aprvEmpno: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/inspection/correction',
  baseRoutePath: '/occupation/correction',
  formName: 'OcuCheckContentForm',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuCheckContentFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCheckContentForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    useOcuCheckContentFormStore();

  const {
    chkItemNm,
    chkLclsCd,
    chkScls,
    chkContent,
    chkRelLaw,
    chkPohtoId1,
    chkPohtoId2,
    chkFile,
    rightActionYn,
    actionStatusCd,
    actionContent,
    actionAttPhotoId,
    actionAttFileId,
    actionDt,
    actionDeptCd,
    actionEmpno,
    aprvDt,
    aprvDeptCd,
    aprvEmpno,
  } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>TODO : 헤더 타이틀</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkItemNm"
                name="chkItemNm"
                label="점검_항목_명"
                value={chkItemNm}
                onChange={(value) => changeInput('chkItemNm', value)}
                errorMessage={errors.chkItemNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkLclsCd"
                name="chkLclsCd"
                label="점검_대분류_코드"
                value={chkLclsCd}
                onChange={(value) => changeInput('chkLclsCd', value)}
                errorMessage={errors.chkLclsCd}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkScls"
                name="chkScls"
                label="점검_소분류_코드"
                value={chkScls}
                onChange={(value) => changeInput('chkScls', value)}
                errorMessage={errors.chkScls}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkContent"
                name="chkContent"
                label="점검_내용"
                value={chkContent}
                onChange={(value) => changeInput('chkContent', value)}
                errorMessage={errors.chkContent}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkRelLaw"
                name="chkRelLaw"
                label="점검_관계법령"
                value={chkRelLaw}
                onChange={(value) => changeInput('chkRelLaw', value)}
                errorMessage={errors.chkRelLaw}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkPohtoId1"
                name="chkPohtoId1"
                label="점검_첨부_사진_ID1"
                value={chkPohtoId1}
                onChange={(value) => changeInput('chkPohtoId1', value)}
                errorMessage={errors.chkPohtoId1}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkPohtoId2"
                name="chkPohtoId2"
                label="점검_첨부_사진_ID2"
                value={chkPohtoId2}
                onChange={(value) => changeInput('chkPohtoId2', value)}
                errorMessage={errors.chkPohtoId2}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkFile"
                name="chkFile"
                label="점검_첨부_파일"
                value={chkFile}
                onChange={(value) => changeInput('chkFile', value)}
                errorMessage={errors.chkFile}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormrightActionYn"
                name="rightActionYn"
                label="즉시_조치_여부"
                value={rightActionYn}
                onChange={(value) => changeInput('rightActionYn', value)}
                errorMessage={errors.rightActionYn}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionStatusCd"
                name="actionStatusCd"
                label="조치_상태_코드"
                value={actionStatusCd}
                onChange={(value) => changeInput('actionStatusCd', value)}
                errorMessage={errors.actionStatusCd}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionContent"
                name="actionContent"
                label="조치_내용"
                value={actionContent}
                onChange={(value) => changeInput('actionContent', value)}
                errorMessage={errors.actionContent}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionAttPhotoId"
                name="actionAttPhotoId"
                label="조치_첨부_사진_ID"
                value={actionAttPhotoId}
                onChange={(value) => changeInput('actionAttPhotoId', value)}
                errorMessage={errors.actionAttPhotoId}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionAttFileId"
                name="actionAttFileId"
                label="조치_첨부_파일_ID"
                value={actionAttFileId}
                onChange={(value) => changeInput('actionAttFileId', value)}
                errorMessage={errors.actionAttFileId}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionDt"
                name="actionDt"
                label="조치_일자"
                value={actionDt}
                onChange={(value) => changeInput('actionDt', value)}
                errorMessage={errors.actionDt}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionDeptCd"
                name="actionDeptCd"
                label="조치_부서_코드"
                value={actionDeptCd}
                onChange={(value) => changeInput('actionDeptCd', value)}
                errorMessage={errors.actionDeptCd}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionEmpno"
                name="actionEmpno"
                label="조치자_사번"
                value={actionEmpno}
                onChange={(value) => changeInput('actionEmpno', value)}
                errorMessage={errors.actionEmpno}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormaprvDt"
                name="aprvDt"
                label="승인_일자"
                value={aprvDt}
                onChange={(value) => changeInput('aprvDt', value)}
                errorMessage={errors.aprvDt}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormaprvDeptCd"
                name="aprvDeptCd"
                label="승인_부서_코드"
                value={aprvDeptCd}
                onChange={(value) => changeInput('aprvDeptCd', value)}
                errorMessage={errors.aprvDeptCd}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormaprvEmpno"
                name="aprvEmpno"
                label="승인자_사번"
                value={aprvEmpno}
                onChange={(value) => changeInput('aprvEmpno', value)}
                errorMessage={errors.aprvEmpno}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuCheckContentForm;
