import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppDatePicker from '@/components/common/AppDatePicker';
import dayjs from 'dayjs';

import { useTranslation } from 'react-i18next';

/* yup validation */
const yupFormSchema = yup.object({
  subjectKoNm: yup.string().required(),
  popupFromDt: yup.string().required(),
  popupToDt: yup.string().required(),
  bannerTypeCd: yup.string().required(),
  linkKoNm: yup.string(),
  fileGroupSeq: yup.number().nullable(),
  useYn: yup.string().required(),
  viewSn: yup.number(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  boardTypeCd: '60',
  subjectKoNm: '',
  popupFromDt: dayjs().format('YYYY-MM-DD'),
  popupToDt: dayjs().format('YYYY-MM-DD'),
  bannerTypeCd: '',
  linkKoNm: '',
  fileGroupSeq: null,
  useYn: '',
  viewSn: null,

  // 필수값
  popupYn: 'N',
  viewYn: 'Y',
  topFixYn: 'N',
  mainShowYn: 'N',
  viewCo: 0,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/board/board',
  baseRoutePath: '/aviation/board-manage/banner-manage',
  formName: 'AvnBannerManageFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const AvnBannerManageFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue }, formType: FORM_TYPE_ADD });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function BannerManageEdit() {
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    AvnBannerManageFormStore();

  const { subjectKoNm, popupFromDt, popupToDt, bannerTypeCd, linkKoNm, fileGroupSeq, useYn, viewSn } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>배너관리 {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnBannerManageFormStoresubjectKoNm"
                name="subjectKoNm"
                label="제목"
                value={subjectKoNm}
                onChange={(value) => changeInput('subjectKoNm', value)}
                errorMessage={errors[subjectKoNm]}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid30">
            <div className="form-group wid30">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={t('ke_change_mgmt_label_00556')}
                      //pickerType="date"
                      value={popupFromDt}
                      onChange={(value) => {
                        changeInput('popupFromDt', value);
                      }}
                      required
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label={t('ke_report_label_00203')}
                      //pickerType="date"
                      value={popupToDt}
                      onChange={(value) => {
                        changeInput('popupToDt', value);
                      }}
                      required
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid30">
              <AppCodeSelect
                codeGrpId="CODE_GRP_151"
                id="AvnBannerManageFormStorebannerTypeCd"
                name="bannerTypeCd"
                label="배너구분"
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={bannerTypeCd}
                onChange={(value) => changeInput('bannerTypeCd', value)}
                errorMessage={errors['bannerTypeCd']}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* linkGroupAttach 여부 질문 */}
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnBannerManageFormStoreStorelinkKoNm"
                name="linkKoNm"
                label="URL"
                value={linkKoNm}
                onChange={(value) => changeInput('linkKoNm', value)}
                errorMessage={errors.linkKoNm}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* 파일첨부영역 : drag */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppFileAttach
                label="파일첨부"
                fileGroupSeq={fileGroupSeq}
                workScope={'A'}
                onlyImageUpload={true}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileGroupSeq', newFileGroupSeq);
                }}
                maxCount={1}
              />
              <span style={{ color: 'red' }}>* 이미지 규격은 가로 ***px, 세로 ***px 입니다.</span>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid30">
              <AppCodeSelect
                codeGrpId="CODE_GRP_146"
                id="AvnBannerManageFormStoreuseYn"
                name="useYn"
                label="사용여부"
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={useYn}
                onChange={(value) => changeInput('useYn', value)}
                errorMessage={errors['useYn']}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnBannerManageFormStoreviewSn"
                name="viewSn"
                label="정렬순서"
                value={viewSn}
                onChange={(value) => changeInput('viewSn', value)}
                errorMessage={errors.viewSn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
    </>
  );
}
export default BannerManageEdit;
