import AppDatePicker from '@/components/common/AppDatePicker';
import AppNavigation from '@/components/common/AppNavigation';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import dayjs from 'dayjs';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { create } from 'zustand';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/board/boardList',
  baseRoutePath: '/aviation/spi-spt/spiBoardList',
};

/* zustand store 생성 */
const BoardListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    boardType: '120',
    fromDate: dayjs().format('YYYY-MM-DD'),
    toDate: dayjs().format('YYYY-MM-DD'),
    titleKo: '',
  },
  //초기화 버튼 클릭 시 검색 조건 초기화
  initSearchInput: () => {
    set({
      searchParam: {
        boardType: '120',
        fromDate: dayjs().format('YYYY-MM-DD'),
        toDate: dayjs().format('YYYY-MM-DD'),
        titleKo: '',
      },
    });
  },

  clear: () => {
    set(initListData);
  },
}));

function SPIBoardList() {
  const { t } = useTranslation();
  const state = BoardListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번', cellStyle: { textAlign: 'center' } },
      { field: 'titleKo', headerName: '제목', cellStyle: { textAlign: 'left' } },
      { field: 'regUserNm', headerName: '작성자', cellStyle: { textAlign: 'center' } },
      { field: 'regDttm', headerName: '작성일', cellStyle: { textAlign: 'center' } },
    ])
  );

  //BoardListStore에서 정의된 메소드 사용시 이곳에서 분해할당
  const { enterSearch, searchParam, list, goAddPage, initSearchInput, changeSearchInput, clear, goDetailPage, search } =
    state;

  //input value에 넣기 위한 분리 선언
  const { fromDate, toDate, titleKo } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    //더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.boardId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    initSearchInput();
    return clear;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>게시판</h2>
      </div>

      {/*검색영역 */}

      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid30">
            <div className="form-group form-glow">
              <div className="df">
                <div className="date1">
                  <AppDatePicker
                    label={t('admin.AdminMain.NotifyAdmin.regDttm')}
                    pickerType="date"
                    value={fromDate}
                    onChange={(value) => {
                      changeSearchInput('fromDate', value);
                    }}
                  />
                </div>
                <span className="unt">~</span>
                <div className="date2">
                  <AppDatePicker
                    label={t('admin.AdminMain.NotifyAdmin.regDttm')}
                    pickerType="date"
                    value={toDate}
                    onChange={(value) => {
                      changeSearchInput('toDate', value);
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppSearchInput
                label={t('ke.safety.policy.label.00002')}
                value={titleKo}
                onChange={(value) => {
                  changeSearchInput('titleKo', value);
                }}
                search={search}
              />
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              {t('ke.safety.common.label.00002')}
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              {t('ke.safety.common.label.00003')}
            </button>
          </div>
        </div>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
          hiddenPagination
        />
      </div>
      {/*//그리드영역 */}
    </>
  );
}

export default SPIBoardList;
