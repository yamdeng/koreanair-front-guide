import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import ApiService from '@/services/ApiService';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';

function SPIBoardDetail() {
  //언어설정
  const { t } = useTranslation();

  const navigate = useNavigate();
  const [detailInfo, setDetailInfo] = useState<any>({});

  const { titleKo, content, fileGroupSeq, regUserId } = detailInfo;

  const { detailId } = useParams();

  const cancel = () => {
    navigate('/aviation/spi-spt/spiBoardList');
  };

  useEffect(() => {
    ApiService.get(`avn/admin/board/boardList/${detailId}`).then((apiResult) => {
      const detailInfo = apiResult.data || {};
      setDetailInfo(detailInfo);
    });
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>게시판 상세</h2>
      </div>
      {/*상세페이지*/}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid30">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      제목 <span className="required">*</span>
                    </label>
                    <span className="text-desc-type1">{titleKo}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      게시기간 <span className="required">*</span>
                    </label>
                    <span className="text-desc-type1">2024-06-03 ~ 2025-01-15</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      내용 <span className="required">*</span>
                    </label>
                    <span className="text-desc-type1">{content}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">첨부파일</label>
                    <span className="text-desc-type1">
                      <AppFileAttach mode="view" fileGroupSeq={fileGroupSeq} disabled={true} />
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/*//상세페이지*/}

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text btn_list" onClick={cancel}>
          목록
        </button>
      </div>
      {/*//하단버튼영역*/}
    </>
  );
}

export default SPIBoardDetail;
