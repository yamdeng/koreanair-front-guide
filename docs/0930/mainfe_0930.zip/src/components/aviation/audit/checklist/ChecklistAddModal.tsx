import { useState } from 'react';
import Modal from 'react-modal';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppTextInput from '@/components/common/AppTextInput';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';
import ModalService from '@/services/ModalService';

const formName = 'ChecklistAddModal';

/* yup validation */
const yupFormSchema = yup.object({
  division: yup.string().required(),
  listName: yup.string().required(),
});

/* form 초기화 */
const initFormValue = {
  division: null,
  listName: '',
};

function ChecklistAddModal(props) {
  const { isOpen, closeModal, ok } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});
  const { division, listName } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
  };

  const handleClose = () => {
    setErrors({});
    setFormValue({ ...initFormValue });
    closeModal();
  };

  const handleOk = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;
    if (success) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        okLabel: '저장',
        ok: () => {
          ok(formValue);
        },
      });
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'confirm-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">Checklist 추가</h3>
        <div className="pop_cont">
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppCodeSelect
                    id={formName + division}
                    label={'Audit Type'}
                    codeGrpId="CODE_GRP_301"
                    value={division}
                    onChange={(value) => changeInput('division', value)}
                    required
                    errorMessage={errors.division}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    id={formName + listName}
                    label="Checklist Title"
                    value={listName}
                    onChange={(value) => changeInput('listName', value)}
                    errorMessage={errors.listName}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            취소
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleOk}>
            확인
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default ChecklistAddModal;
