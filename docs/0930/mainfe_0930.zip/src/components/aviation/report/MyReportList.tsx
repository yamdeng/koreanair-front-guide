import AppNavigation from '@/components/common/AppNavigation';
import AppRangeDatePicker from '@/components/common/AppRangeDatePicker';
import AppSelect from '@/components/common/AppSelect';
import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
import ApiService from '@/services/ApiService';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import history from '@/utils/history';
import { useCallback, useEffect, useState } from 'react';
import { create } from 'zustand';
import LoadingBar from '@/utils/LoadingBar';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/report/my-reports',
  baseRoutePath: '/aviation/report/my-report',
  disableLoadingBar: true,
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  reportTypeCd: '',
  reportPhaseCd: '1',
  subjectNm: '',
  fromDate: '',
  toDate: '',
};

/* zustand store 생성 */
const AvnReportListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    reportTypeCd: '',
    reportPhaseCd: '1',
    subjectNm: '',
    fromDate: '',
    toDate: '',
  },
  //보고서 상태 count수
  groupCount: {
    step1: 0,
    step2: 0,
    step3: 0,
    step4: 0,
    step5: 0,
    step6: 0,
  },

  //보고서 상태 active
  stepActive1: 'active',
  stepActive2: '',
  stepActive3: '',
  stepActive4: '',
  stepActive5: '',
  stepActive6: '',

  //보고서 종류 목록
  reportTypeList: [],

  //검색일 rangeDate 값
  rangeDt: ['', ''],

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
      rangeDt: ['', ''],
    });
  },

  searchAll: async () => {
    const { enterSearch, getReportListCnt } = get();
    LoadingBar.show();
    await enterSearch();
    await getReportListCnt();
    // LoadingBar.hide();
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam }, rangeDt: ['', ''] });
  },

  //보고서 종류 가져오기
  getReportTypeCd: async () => {
    const reportList = [];
    await ApiService.get(`com/code-groups/CODE_GRP_RESOURCE_TYPE/codes`).then((apiResult) => {
      const data = apiResult.data;
      data.forEach((el) => {
        if (el.codeId == 'asr' || el.codeId == 'hzr') {
          reportList.push(el);
        }
      });
      set({ reportTypeList: reportList });
    });
  },

  //보고서 상태 count 수 가져오기
  getReportListCnt: async () => {
    const apiResult = await ApiService.get(`avn/report/my-reports/cnt`, null, { disableLoadingBar: true });
    const data = apiResult.data;
    console.log(data);
    if (data) {
      set({ groupCount: data });
    } else {
      set({ groupCount: { step1: 0, step2: 0, step3: 0, step4: 0, step5: 0, step6: 0 } });
    }
  },

  //상태 값에 따라 active 설정
  changeStepCode: () => {
    const { searchParam } = get();
    const { reportPhaseCd } = searchParam;
    if (reportPhaseCd == '1') {
      set({
        stepActive1: 'active',
        stepActive2: '',
        stepActive3: '',
        stepActive4: '',
        stepActive5: '',
        stepActive6: '',
      });
    } else if (reportPhaseCd == '2') {
      set({
        stepActive1: '',
        stepActive2: 'active',
        stepActive3: '',
        stepActive4: '',
        stepActive5: '',
        stepActive6: '',
      });
    } else if (reportPhaseCd == '3') {
      set({
        stepActive1: '',
        stepActive2: '',
        stepActive3: 'active',
        stepActive4: '',
        stepActive5: '',
        stepActive6: '',
      });
    } else if (reportPhaseCd == '4') {
      set({
        stepActive1: '',
        stepActive2: '',
        stepActive3: '',
        stepActive4: 'active',
        stepActive5: '',
        stepActive6: '',
      });
    } else if (reportPhaseCd == '5') {
      set({
        stepActive1: '',
        stepActive2: '',
        stepActive3: '',
        stepActive4: '',
        stepActive5: 'active',
        stepActive6: '',
      });
    } else if (reportPhaseCd == '6') {
      set({
        stepActive1: '',
        stepActive2: '',
        stepActive3: '',
        stepActive4: '',
        stepActive5: '',
        stepActive6: 'active',
      });
    }
  },
}));

function MyReportList() {
  //신규버튼 생성
  const customButtons = [
    {
      title: '신규',
      onClick: () => {
        alert('신규');
      },
    },
  ];

  //리포트 순번
  const reportNum = (props) => {
    return <>{props.node.rowIndex + 1}</>;
  };

  const state = AvnReportListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'reportId', headerName: '순번', cellRenderer: reportNum },

      { field: 'regDt', headerName: '작성일' },
      { field: 'finalSubmittedDt', headerName: '제출일' },
      // { field: 'reportPhaseEng', headerName: '상태' },
      { field: 'reportDocno', headerName: '보고서 번호' },
      { field: 'reportTypeCd', headerName: '보고서 종류' },

      { field: 'subjectNm', headerName: '제목' },
      { field: 'reportPhaseKor', headerName: '상태' },
    ])
  );
  const {
    searchAll,
    getReportListCnt, //목록 count 조회
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    getReportTypeCd, //보고서 종류 공통코드에서 조회
    reportTypeList, //보고서 종류 목록
    changeStateProps, //날짜 props상태 변경
    rangeDt, //날짜
    groupCount, // 상태별 목록 수
    stepActive1,
    stepActive2,
    stepActive3,
    stepActive4,
    stepActive5,
    stepActive6,
    changeStepCode,
    clear,
  } = state;
  // TODO : 검색 파라미터 나열
  const { reportTypeCd, reportPhaseCd, subjectNm, fromDate, toDate } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const detailId = selectedInfo.data.reportId;
    history.push(`aviation/report-form/ASR/${detailId}`);
  }, []);

  useEffect(() => {
    getReportTypeCd();
    searchAll();
    return clear;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>My Report</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div id="" className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppSelect
                  label={'보고서종류'}
                  value={reportTypeCd}
                  applyAllSelect={true}
                  allValue=""
                  allLabel="전체"
                  options={reportTypeList}
                  labelKey="codeNameKor"
                  valueKey="codeId"
                  onChange={(value) => {
                    changeSearchInput('reportTypeCd', value);
                  }}
                />
                {/* com/code-groups/${codeGrpId}/codes */}
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group form-glow wid30">
                <AppRangeDatePicker
                  label="작성일"
                  onChange={(value) => {
                    changeSearchInput('fromDate', value[0]);
                    changeSearchInput('toDate', value[1]);
                    changeStateProps('rangeDt', value);
                  }}
                  value={rangeDt}
                  showNow
                  placeholder={['시작일', '종료일']}
                />
              </div>
            </div>

            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppTextInput
                  label={'제목'}
                  value={subjectNm}
                  onChange={(value) => {
                    changeSearchInput('subjectNm', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="btn-area">
                <button
                  type="button"
                  name="button"
                  className="btn-sm btn_text btn-darkblue-line"
                  onClick={() => {
                    changeStepCode();
                    searchAll();
                  }}
                >
                  조회
                </button>
                <button
                  type="button"
                  name="button"
                  className="btn-sm btn_text btn-darkblue-line"
                  onClick={initSearchInput}
                >
                  초기화
                </button>
              </div>
            </div>
          </div>
          <div className="form-table"></div>
        </div>
        {/*__control명 옆에 active  */}
        {/* <button type="button" name="button" className="arrow button _control active">
          <span className="hide">접기</span>
        </button> */}
      </div>
      {/* //검색영역 */}

      {/* 마이리포트 프로세스 */}
      <div className="">
        <div className="c-step-wrap">
          <ol className="c-step-list-type-5">
            <li className={stepActive1}>
              <a href="javascript:void(0);" data-label="작성">
                <p
                  className={`info-title ${stepActive1}`}
                  onClick={() => {
                    changeSearchInput('reportPhaseCd', '1');
                    changeStepCode();
                    searchAll();
                  }}
                >
                  <span className="hide">1단계</span>
                  작성중 <strong>{groupCount.step1}</strong> 건
                </p>
              </a>
              <span className="after-arrow"></span>
            </li>
            <li className={stepActive2}>
              <a href="javascript:void(0);" data-label="결제">
                <p
                  className={`info-title ${stepActive2}`}
                  onClick={() => {
                    changeSearchInput('reportPhaseCd', '2');
                    changeStepCode();
                    searchAll();
                  }}
                >
                  <span className="hide">2단계</span>
                  제출완료 <strong>{groupCount.step2}</strong> 건
                </p>
              </a>
              <span className="after-arrow"></span>
            </li>
            <li className={stepActive3}>
              <a href="javascript:void(0);" data-label="안전권고">
                <p
                  className={`info-title ${stepActive3}`}
                  onClick={() => {
                    changeSearchInput('reportPhaseCd', '3');
                    changeStepCode();
                    searchAll();
                  }}
                >
                  <span className="hide">3단계</span>
                  접수중 <strong>{groupCount.step3}</strong> 건
                </p>
              </a>
              <span className="after-arrow"></span>
            </li>
            <li className={stepActive4}>
              <a href="javascript:void(0);" data-label="종결">
                <p
                  className={`info-title ${stepActive4}`}
                  onClick={() => {
                    changeSearchInput('reportPhaseCd', '4');
                    changeStepCode();
                    searchAll();
                  }}
                >
                  <span className="hide">4단계</span>
                  반려 <strong>{groupCount.step4}</strong> 건
                </p>
              </a>
              <span className="after-arrow"></span>
            </li>
            <li className={stepActive5}>
              <a href="javascript:void(0);" data-label="안전권고">
                <p
                  className={`info-title ${stepActive5}`}
                  onClick={() => {
                    changeSearchInput('reportPhaseCd', '5');
                    changeStepCode();
                    searchAll();
                  }}
                >
                  <span className="hide">5단계</span>
                  처리중 <strong>{groupCount.step5}</strong> 건
                </p>
              </a>
              <span className="after-arrow"></span>
            </li>
            <li className={stepActive6}>
              <a href="javascript:void(0);" data-label="종결">
                <p
                  className={`info-title ${stepActive6}`}
                  onClick={() => {
                    changeSearchInput('reportPhaseCd', '6');
                    changeStepCode();
                    searchAll();
                  }}
                >
                  <span className="hide">6단계</span>
                  종결 <strong>{groupCount.step6}</strong> 건
                </p>
              </a>
            </li>
          </ol>
        </div>
      </div>

      {/*그리드영역 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
          customButtons={customButtons}
          displayTableLoading={true}
        />
      </div>
      {/*//그리드영역 */}
    </>
  );
}

export default MyReportList;
