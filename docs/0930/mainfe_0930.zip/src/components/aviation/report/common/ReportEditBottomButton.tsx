function ReportEditBottomButton({ print, tempSave, save }) {
  return (
    <div className="contents-btns">
      <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={print}>
        출력
      </button>
      <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={tempSave}>
        저장
      </button>
      <button type="button" name="button" className="btn_text text_color_neutral-10 btn_conblue" onClick={save}>
        제출
      </button>
    </div>
  );
}

export default ReportEditBottomButton;
