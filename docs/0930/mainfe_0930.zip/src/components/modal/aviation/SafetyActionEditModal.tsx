import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';
import AppTextInput from '@/components/common/AppTextInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppTextArea from '@/components/common/AppTextArea';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';

//오늘 날짜 만들기
const today = new Date();
const year = today.getFullYear(); // 년도
const month = today.getMonth() + 1; // 월
const date = today.getDate(); // 날짜
// const nowHours = today.getHours(); //시
// const nowMins = today.getMinutes(); //분
let monthString = '';
let dateString = '';
if (month < 10) {
  monthString = '0' + month;
} else {
  monthString = month.toString();
}
if (date < 10) {
  dateString = '0' + date;
} else {
  dateString = date.toString();
}
const todayString = year + '-' + monthString + '-' + dateString;

const formName = 'SafetyActionEditModal';

/* form 초기화 */
const initsafetyActionFormValue = {
  id: null,
  caId: null,
  safetyNo: '',
  actionTaken: '',
  actionAt: todayString,
  deptCd: '',
  empNo: '',
};

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SafetyActionEditModal(props) {
  const profile = useStore(useAppStore, (state) => state.profile);
  const { isOpen, closeModal, safetyActionList, editIndex, editType, safetyActionEditSave } = props;
  const [safetyActionFormValue, setSafetyActionFormValue] = useImmer({ ...initsafetyActionFormValue });
  const [errors, setErrors] = useState<any>({});
  const [isDirty, setIsDirty] = useState(false);

  const { id, caId, safetyNo, actionTaken, actionAt, deptCd, empNo } = safetyActionFormValue;

  const changeInput = (inputName, inputValue) => {
    setSafetyActionFormValue((safetyActionFormValue) => {
      safetyActionFormValue[inputName] = inputValue;
    });
    setIsDirty(true);
  };

  useEffect(() => {
    // TODO : isOpen일 경우에 상세 api 호출 할지 결정 : if(isOpen)
    if (isOpen) {
      console.log(editType);
      console.log(editIndex);
      if (editType == 'edit') {
        console.log(safetyActionList[editIndex]);
        setSafetyActionFormValue(safetyActionList[editIndex]);
      }
    } else {
      console.log('여기?');
      setSafetyActionFormValue(initsafetyActionFormValue);
    }
  }, [isOpen]);

  return (
    <>
      <Modal
        shouldCloseOnOverlayClick={false}
        isOpen={isOpen}
        ariaHideApp={false}
        overlayClassName={'alert-modal-overlay'}
        className={'alert-modal-content'}
        onRequestClose={() => {
          closeModal();
        }}
      >
        <div className="popup-container">
          <h3 className="pop_title">Safety Action 관리</h3>

          <div className="pop_cont">
            {/*등록 */}
            <div className="editbox">
              <div className="form-table">
                <div className="form-table line">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="SafetyActionEditModalsafetyNo"
                        name="safetyNo"
                        label="번호"
                        value={safetyNo}
                        disabled
                      />
                    </div>
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
              <div className="form-table line">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      id="SafetyActionEditModaldeptCd"
                      value={deptCd}
                      name="deptCd"
                      label="부서"
                      onChange={(value) => changeInput('deptCd', value)}
                      errorMessage={errors.deptCd}
                    />
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
              <div className="form-table line">
                <div className="form-cell wid50">
                  <div className="form-group wid50">
                    <AppDatePicker
                      id="SafetyActionEditModalactionAt"
                      value={actionAt}
                      name="actionAt"
                      label="조치일자"
                      onChange={(value) => changeInput('actionAt', value)}
                      errorMessage={errors.actionAt}
                    />
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
              <div className="form-table line">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextArea
                      label="조치결과"
                      style={{ width: '100%', height: 145 }}
                      id="SafetyActionEditModalactionTaken"
                      name="actionTaken"
                      value={actionTaken}
                      onChange={(value) => changeInput('actionTaken', value)}
                      errorMessage={errors.actionTaken}
                    />
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
            </div>
            {/*//등록 */}
          </div>
          <div className="pop_btns">
            <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
              삭제
            </button>
            <button
              className="btn_text text_color_neutral-10 btn_confirm"
              onClick={() => {
                changeInput('empNo', profile.userInfo.empNo);
                safetyActionEditSave(safetyActionFormValue, editIndex, editType);
                closeModal();
              }}
            >
              임시저장
            </button>
            <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
              닫기
            </button>
          </div>
          <span className="pop_close" onClick={closeModal}>
            X
          </span>
        </div>
      </Modal>
    </>
  );
}
export default SafetyActionEditModal;
