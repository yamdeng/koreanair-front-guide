import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

// const baseEqpmList = [
//   {
//     name: '건설기계 사용작업',
//     checked: false,
//     children: [
//       {
//         code: 'A',
//         checked: false,
//       },
//       {
//         code: 'B',
//         checked: false,
//       },
//       {
//         code: 'C',
//         checked: false,
//       },
//       {
//         code: 'D',
//         checked: false,
//         fileGroupSeq: null,
//         text: '',
//       },
//     ],
//   },
// ];

/* yup validation */
const yupFormSchema = yup.object({
  // 외주작업
  // 공사ID
  cntrId: yup.number(),

  // 외주작업 반입장비
  // 반입장비 ID
  imprtEqpmId: yup.number(),
  // 공사 작업 코드
  cntrWrkCd: yup.string(),
  // 반입 장비 코드
  imprtEqpmCd: yup.string(),
  // 반입 장비 수기 입력
  importEqpmNm: yup.string(),
  // 첨부파일 ID
  fileId: yup.number(),
  // regDttm: yup.string().required(),
  // regUserId: yup.string().required(),
  // updDttm: yup.string().required(),
  // updUserId: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  equipmentList: [
    {
      cntrWrkCd: '', // 공사작업코드
      imprtEqpmCd: '', // 반입장비코드
      importEqpmNm: '', // 반입장비_수기_입력
      fileId: '', // 첨부파일 ID
    },
  ],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits/locations',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitDeviceChecklistFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuWorkPermitDeviceChecklistFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuWorkPermitDeviceChecklistFormStore;
