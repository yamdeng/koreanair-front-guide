import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  // 외주작업
  // 공사ID
  cntrId: yup.number(),
  // 공사명
  cntrNm: yup.string(),
  // 사용부문코드
  sectCd: yup.string(),
  // 관리부서코드
  deptCd: yup.string(),
  // 공사분야코드
  cntrAreaCd: yup.string(),
  // 특별교육대상여부
  spclEduTargetYn: yup.string(),
  // 시공사
  cnstCmpny: yup.string(),
  // 담당자
  staff: yup.string(),
  // 연락처
  contactNo: yup.string(),
  // 공사장소ID
  cntrStieid: yup.number(),
  // 공사 위치명
  cntrPositionNm: yup.string(),
  // 공사 인원 수
  cntrPrsnCnt: yup.number(),
  // 공사 신청 시작 일시
  cntrApplyStartDttm: yup.string(),
  // 공사 신청 종료 일시
  cntrApplyEndDttm: yup.string(),
  // 사전동의 여부
  preConsentYn: yup.string(),
  // 신청자 사번
  applyEmpno: yup.string(),
  // 승인자 사번
  aprvEmpno: yup.string(),
  // 승인 부서 의견
  aprvDeptOpnn: yup.string(),
  // 신청 상태 코드
  applyStatusCd: yup.string(),
  // 작업 상태 코드
  wrkStatusCd: yup.string(),
  // 작업 시작 일자
  wrkStartDt: yup.string(),
  // 작업 시작 비고
  wrkStartRemark: yup.string(),
  // 작업 시작 첨부 사진1 ID
  wrkStartPhoto1Id: yup.number().nullable(),
  // 작업 시작 첨부 사진2 ID
  wrkStartPhoto2Id: yup.number().nullable(),
  // 교육일지 첨부 파일 ID
  eduJrnlFileId: yup.number().nullable(),
  // 기타 첨부 파일 ID
  etcFileId: yup.number().nullable(),
  // 작업 종료 일자
  wrkEndDt: yup.string(),
  // 작업 종료 비고
  wrkEndRemark: yup.string(),
  // 등록 일시
  regDttm: yup.string(),
  // 등록자 ID
  regUserId: yup.string(),
  // 수정 일시
  updDttm: yup.string(),
  // 수정자 ID
  updUserId: yup.string(),

  // 외주작업 반입장비
  // 반입장비 ID
  imprtEqpmId: yup.number(),
  // 공사 작업 코드
  cntrWrkCd: yup.string(),
  // 반입 장비 코드
  imprtEqpmCd: yup.string(),
  // 첨부파일 ID
  fileId: yup.number(),

  // 외주작업 연장
  // 공사연장 ID
  cntrExtnsId: yup.number(),
  // 공사 종료 연장 일시
  cntrExtnsDttm: yup.string(),
  // 공사 종료 연장 사유
  cntrExtns: yup.string(),
  // 공사 종료 연장 승인 일시
  cntrExtnsAprvDttm: yup.string(),
  // 공사 종료 연장전 요청 일시
  cntrExtnsReqDttm: yup.string(),

  // 외주작업 특별교육 선택
  // 특별교육 선택 ID
  spclEduChcId: yup.number(),
  // 특별교육 항목 코드
  spclEduItemCd: yup.string(),
  // 선택 여부
  chcYn: yup.string(),

  // 외주작업 체크리스트 선택
  // 체크리스트 선택 ID
  chkListChcId: yup.number(),
  // 체크리스트 분류 코드
  chkListClsCd: yup.string(),
  // 체크리스트 항목 코드
  chkListItemCd: yup.string(),

  // 외주작업 공사장소
  // 공사장소 ID
  cnstrSiteId: yup.number(),
  // 공사 장소 명
  cntrLocationNm: yup.string(),
  // 사용 여부
  useYn: yup.string(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  cntrNm: '',
  spclEduTargetYn: '',
  cnstCmpny: '',
  staff: '',
  contactNo: '',
  cntrLocationCd: '',
  cntrPositionNm: '',
  cntrPrsnCnt: null,
  cntrApplyStartDttm: '',
  cntrApplyEndDttm: '',
  preConsentYn: '',
  applyEmpno: '',
  aprvEmpno: '',
  aprvDeptOpnn: '',
  applyStatusCd: '',
  wrkStatusCd: '',
  wrkStartDt: '',
  wrkStartRemark: '',
  wrkStartPhoto1Id: null,
  wrkStartPhoto2Id: null,
  eduJrnlFileId: null,
  etcFileId: null,
  wrkEndDt: '',
  wrkEndRemark: '',
  regDttm: '',
  regUserId: '',
  updDttm: '',
  updUserId: '',
  cntrLocationNm: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitApprovalStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuWorkPermitApprovalStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  isLocationRegisterModalOpen: false,

  openLocationRegisterModal: (detailInfo = null) => {
    set({ isLocationRegisterModalOpen: true, locationRegisterModalInfo: detailInfo });
  },

  closeLocationRegisterModal: () => {
    set({ isLocationRegisterModalOpen: false });
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuWorkPermitApprovalStore;
