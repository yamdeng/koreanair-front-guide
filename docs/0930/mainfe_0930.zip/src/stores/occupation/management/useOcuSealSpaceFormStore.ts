import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import CommonUtil from '@/utils/CommonUtil';

/* yup validation */
const yupFormSchema = yup.object({
  // 부문코드
  sectCd: yup.string().required(),
  // 부서코드
  deptCd: yup.string(),
  // 권역코드
  areaCd: yup.string().required(),
  // 사업장
  bizPlace: yup.string().required(),
  // 위치분류1
  positionCls1: yup.string().required(),
  //위치분류2
  positionCls2: yup.string(),
  // 취급화학물질
  hndChmcl: yup.string(),
  // 유해인자
  hzdFactor: yup.string(),
  // 기준에 관한 규칙 코드
  stdRuleCd: yup.string().required(),
  // 작업업체명
  wrkCompanyNm: yup.string().required(),
  // 출입주기
  entExtIntrv: yup.string().required(),
  // 작업내용
  wrkContent: yup.string().required(),
  // 참고사진1
  photoId1: yup.number().nullable(),
  // 참고사진2
  photoId2: yup.number().nullable(),
  // 등록일시
  //regDttm: yup.string(),
  // 등록자
  regUserId: yup.string(),
  // 수정자
  updUserId: yup.string(),
});

const currentDate = CommonUtil.getToDate();

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  sectCd: '',
  deptCd: '',
  areaCd: '',
  bizPlace: '',
  positionCls1: '',
  positionCls2: '',
  hndChmcl: '',
  hzdFactor: '',
  stdRuleCd: '',
  wrkCompanyNm: '',
  entExtIntrv: '',
  wrkContent: '',
  photoId1: null,
  photoId2: null,
  regDttm: '',
  regUserId: '',
  updUserId: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/sealSpace',
  baseRoutePath: '/occupation/management/sealSpace',
  formName: 'useOcuSealSpaceFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuSealSpaceFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuSealSpaceFormStore;
