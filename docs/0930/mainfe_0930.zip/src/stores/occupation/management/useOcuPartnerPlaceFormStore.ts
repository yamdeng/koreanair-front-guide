import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import { FORM_TYPE_UPDATE } from '@/config/CommonConstant';
/* yup validation */
const yupFormSchema = yup.object({
  prtnrId: yup.number().required(),
  bizPlaceClsCd: yup.string().required(),
  useSectCd: yup.string().required(),
  mgntDeptCd: yup.string().required(),
  staffNm1: yup.string().required(),
  staffContactNo1: yup.string().required(),
  staffEmail1: yup.string().required(),
  staffWork1: yup.string().required(),
  staffNm2: yup.string(),
  staffContactNo2: yup.string(),
  staffEmail2: yup.string(),
  staffWork2: yup.string(),
  sftyMgnt: yup.string(),
  hlthMgnt: yup.string(),
  majorWorkCn: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  prtnrId: '',
  bizPlaceClsCd: '',
  bizPlaceId: '',
  hlthMgnt: '',
  majorWorkCn: '',
  mgntDeptCd: '',
  regDttm: '',
  regUserId: '',
  regUserNm: '',
  sftyMgnt: '',
  staffContactNo1: '',
  staffContactNo2: '',
  staffEmail1: '',
  staffEmail2: '',
  staffNm1: '',
  staffNm2: '',
  staffWork1: '',
  staffWork2: '',
  updDttm: '',
  updUserId: '',
  updUserNm: '',
  useSectCd: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/partner/palce',
  baseRoutePath: '/occupation/management/partner',
  formName: 'OcuPartnerPlaceForm',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuPartnerPlaceFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...createListSlice(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  search: async () => {
    const { formDetailId, setList } = get();
    const apiResult = await ApiService.get(`ocu/management/partner/palce/${formDetailId}`);
    const data = apiResult.data;
    setList(data);

    set({
      detailInfo: data[0],
      formValue: data[0],
      formDetailId: data[0].bizPlaceId,
      formType: FORM_TYPE_UPDATE,
    });
  },

  search2nd: async (params) => {
    const { setList } = get();
    const apiResult = await ApiService.get(`ocu/management/partner/2ndinfo/${params.bizPlaceId}`);
    const data = apiResult.data;
    setList(data);
    console.log(data);

    if (data !== undefined) {
      set({
        detailInfo: data[0],
        formValue: data[0],
        formDetailId: data[0].scndPrtnId,
        formType: FORM_TYPE_UPDATE,
      });
    }
  },

  clear: () => {
    set({ ...listBaseState, searchParam: {} });
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },

  clearForm: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuPartnerPlaceFormStore;
