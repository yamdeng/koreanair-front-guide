import { create } from 'zustand';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formListObjectSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import { produce } from 'immer';
import { FORM_TYPE_ADD } from '@/config/CommonConstant';

/* yup validation */
const yupFormSchema = yup.object().shape({
  chkListClsCd: yup.string().required(),
  chkTitle: yup.string().required(),
  chkRegStartDt: yup.string().required(),
  chkRegEndDt: yup.string().required(),
});

//yupListSchema
const yupTargetListSchema = yup
  .array()
  .min(1, '목록은 최소 하나여야 합니다.')
  .of(
    yup.object().shape({
      bizPlaceId: yup.string().required(),
      prtnrId: yup.string().required(),
      regUserDept: yup.string().required(),
    })
  );

const yupContentListSchema = yup
  .array()
  .min(1, '목록은 최소 하나여야 합니다.')
  .of(
    yup.object().shape({
      chkClsCd: yup.string().required(),
      chkItemNm: yup.string().required(),
      chkItemOX: yup.string().required(),
    })
  );

//yupListFormSchema
const yupTargetFormSchema = yup.object({
  bizPlaceId: yup.string().required(),
  prtnrId: yup.string().required(),
  regUserDept: yup.string().required(),
});

const yupContentFormSchema = yup.object({
  chkClsCd: yup.string().required(),
  chkItemNm: yup.string().required(),
  chkResultCd: yup.string().required(),
  chkLclsCd: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && val == '' ? false : true)),
  chkScls: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && val == '' ? false : true)),
  chkContent: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && val == '' ? false : true)),
  chkRelLaw: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && val == '' ? false : true)),
  rightActionYn: yup.string().required(),
  actionContent: yup.string().test((val, obj) => (obj.parent.rightActionYn === 'Y' && val == '' ? false : true)),
  actionDeptCd: yup.string().test((val, obj) => (obj.parent.rightActionYn === 'Y' && val == '' ? false : true)),
  aprvDeptCd: yup.string().test((val, obj) => (obj.parent.rightActionYn === 'Y' && val == '' ? false : true)),
});

/* formValue 초기값 */
const initFormValue = {
  chkListId: '',
  chkListClsCd: '',
  chkTitle: '',
  chkRegStartDt: '',
  chkRegEndDt: '',
};

const initContentFormResultValue = {
  chkLclsCd: '', //점검_대분류_코드
  chkScls: '', //점검_소분류_코드
  chkContent: '', //점검_내용
  chkRelLaw: '', //점검_관계_법령
  chkPohtoId1: '', //점검_첨부_사진_ID1
  chkPohtoId2: '', //점검_첨부_사진_ID2
  chkFile: '', //점검_첨부_파일
};

const initContentFormActionValue = {
  actionStatusCd: '', //조치_상태_코드
  actionContent: '', //조치_내용
  actionAttPhotoId: '', //조치_첨부_사진_ID
  actionAttFileId: '', //조치_첨부_파일_ID
  actionDt: '', //조치_일자
  actionDeptCd: '', //조치_부서_코드
  actionEmpno: '', //조치자_사번
  aprvDt: '', //승인_일자
  aprvDeptCd: '', //승인_부서_코드
  aprvEmpno: '', //승인자_사번
};
const initContentFormValue = {
  chkId: '', //점검_ID
  bizPlaceId: '', //사업장_ID
  prtnrId: '', //협력업체_ID
  chkItemId: '', //점검항목_ID
  chkListId: '', //점검표_ID
  chkResultCd: 'O', //점검_결과_코드
  ...initContentFormResultValue,
  rightActionYn: 'N', //즉시_조치_여부
  ...initContentFormActionValue,
};
const initTargetFormValue = {
  chkId: '', //점검_ID
  chkDt: '', //점검_일자
  chkEmpno: '', //점검자_사번
  remark: '', //비고
};

/* zustand store 생성 */
export const useOcuSvisitCheckFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...formBaseState,
  formApiPath: 'ocu/inspection/walkAround',
  baseRoutePath: '/occupation/inspection/walkAround',
  formName: 'OcuSvisitCheckForm',
  formValue: {
    ...initFormValue,
  },
  yupFormSchema: yupFormSchema,

  openChecklistModal: () => {
    set({ isChecklistModalOpen: true });
  },

  closeChecklistModal: () => {
    set({ isChecklistModalOpen: false });
  },

  selectChecklistModal: (params) => {
    useOcuSvisitCheckTargetFormStore.getState().selectChecklistModal(params.listPlace);
    useOcuSvisitCheckContentFormStore.getState().selectChecklistModal(params.listItem);
    set({ formValue: { chkListId: params.chkListId } });
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export const useOcuSvisitCheckTargetFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...formBaseState,
  formName: 'OcuSvisitCheckTargetForm',
  yupListSchema: yupTargetListSchema,
  yupListFormSchema: yupTargetFormSchema,
  isChecklistModalOpen: false,

  // 조회
  searchTarget: async (formDetailId) => {
    const apiResult: any = await ApiService.get(`ocu/inspection/walkAround/${formDetailId}/target`);
    const list = apiResult.data;
    const totalCount = list.length;

    if (list) {
      list.map((info) => {
        info.status = 'N';
        return info;
      });
    }

    await set({ list: list || [], totalCount: totalCount });
  },

  //점검표 검색을 통한 그리드 세팅
  selectChecklistModal: (params) => {
    const { formType } = get();
    const newList = [];

    if (formType == FORM_TYPE_ADD && params) {
      params.forEach((info) => {
        newList.push({
          bizPlaceId: info.bizPlaceId,
          prtnrId: info.prtnrId,
          status: 'N',
          ...initTargetFormValue,
        });
      });
    }

    set(
      produce((state: any) => {
        state.list = newList;
      })
    );
  },
}));

export const useOcuSvisitCheckContentFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...formBaseState,
  formName: 'OcuSvisitCheckContentForm',
  yupListSchema: yupContentListSchema,
  yupListFormSchema: yupContentFormSchema,
  resultFormValue: {},
  actionFormValue: {},

  // 조회
  searchContent: async (formDetailId) => {
    const apiResult: any = await ApiService.get(`ocu/inspection/walkAround/${formDetailId}/content`);
    const list = apiResult.data;
    const totalCount = list.length;

    if (list) {
      list.map((info) => {
        info.status = 'N';
        return info;
      });
    }
    await set({ list: list || [], totalCount: totalCount });
  },

  // 점검표 검색을 통한 그리드 세팅
  selectChecklistModal: (params) => {
    const { formType } = get();
    const newList = [];

    if (formType == FORM_TYPE_ADD && params) {
      params.forEach((info) => {
        newList.push({ chkClsCd: info.chkClsCd, chkItemNm: info.chkItemNm, status: 'N', ...initContentFormValue });
      });
    }

    set(
      produce((state: any) => {
        state.list = newList;
      })
    );
  },

  setSelectedListIndex: (index, selectedRowInfo, detailFormValue) => {
    const { formType } = get();
    if (formType == FORM_TYPE_ADD) {
      const targetInfo = useOcuSvisitCheckTargetFormStore.getState().detailFormValue;
      set({
        detailFormValue: {
          ...selectedRowInfo,
          ...detailFormValue,
          bizPlaceId: targetInfo.bizPlaceId,
          prtnrId: targetInfo.prtnrId,
        },
      });
    }
    set({ selectedListIndex: index });
  },

  openContentModal: () => {
    set({ isContentModalOpen: true });
  },

  closeContentModal: () => {
    const { clearFrom } = get();
    set({ isContentModalOpen: false });
    clearFrom();
  },

  closeConfirmModal: async () => {
    const {
      closeContentModal,
      validateDetailFormValue,
      selectedListIndex,
      detailFormValue,
      updateList,
      updateListStatus,
    } = get();
    const targetIdx = useOcuSvisitCheckTargetFormStore.getState().selectedListIndex;
    const { isValid } = await validateDetailFormValue();
    if (isValid) {
      await updateList(selectedListIndex, detailFormValue); //detailFormValue 변경
      await updateListStatus(selectedListIndex, 'U'); //status 'N'은 'U'로 변경
      await useOcuSvisitCheckTargetFormStore.getState().updateListStatus(targetIdx, 'U'); //status 'N'은 'U'로 변경
      closeContentModal();
    }
  },

  clearResult: (detailFormValue) => {
    set({
      detailFormValue: {
        ...detailFormValue,
        ...initContentFormResultValue,
        rightActionYn: 'N',
      },
    });
  },

  clearAction: (detailFormValue) => {
    set({ detailFormValue: { ...detailFormValue, ...initContentFormActionValue } });
  },

  clearFrom: () => {
    set({ detailFormErrors: {}, isDirty: false, isValid: false, detailFormValue: { ...initContentFormValue } });
  },
}));
