import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import history from '@/utils/history';
import { el } from '@faker-js/faker';
import { getDetailData } from '@/data/grid/example-data-new';
import useOcuRiskMasterStore from './useOcuRiskMasterStore';

/* yup validation */
const yupFormSchema = yup.object({
  /* 기본 정보 */

  // 부문
  // authorSectCd: yup.string().required(),
  // 부서
  // authorDeptCd: yup.string().required(),
  // 위험성평가 문서 번호
  // revalDocNo: yup.string(),
  // 위험성평가 년도
  revalYear: yup.string().required(),
  // 위험성평가 시기
  revalPeriod: yup.string().required(),
  // 평가 시작일자
  evalStartDt: yup.string().required(),
  // 평가 종료일자
  evalEndDt: yup.string().required(),
  // 위험성평가 제목
  revalTitle: yup.string().required(),
  // 재해발생보고서 문서 번호
  dssReportDocNo: yup.string(),
  // 근로자_수
  emplCnt: yup.number().nullable(),
  // 근무형태
  workForm: yup.string(),
  // 위험성평가 1번 문항
  revalItem1: yup.string().nullable(),
  // 위험성평가 2번 문항
  revalItem2: yup.string().nullable(),
  // 위험성평가 3번 문항
  revalItem3: yup.string().nullable(),
  // 위험성평가 4번 문항
  revalItem4: yup.string().nullable(),
  // 안전보건_정보_내용
  hlthSftyInfoCn: yup.string().nullable(),
  // 준비_관련_첨부_파일_ID
  prepareRelFileId: yup.string().nullable(),
  /* 추진팀 정보 */
  // 추진팀 구분 코드
  execTeamClsCd: yup.string().nullable(),
  // 추진팀 성명
  execTeamNm: yup.string().nullable(),
  // 추진팀 사번
  execTeamEmpno: yup.string().nullable(),
  // 추진팀 부문 코드
  execTeamSectCd: yup.string().nullable(),
  // 추진팀 부서 코드
  execTeamDeptCd: yup.string().nullable(),
  //  추진팀 업체명
  execTeamCompNm: yup.string().nullable(),
  // 추진팀 직책 코드
  execTeamPosCd: yup.string().nullable(),
  /* 공정 정보 */
  // 공정 명
  procNm: yup.string().nullable(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  /* 기본 정보 */

  // 위험성평가 문서 번호
  rEvalDocNo: '',
  // 위험성평가 년도
  rEvalYear: '',
  // 위험성평가 시기
  rEvalPeriod: '',
  // 평가 시작일자
  evalStartDt: '',
  // 평가 종료일자
  evalEndDt: '',
  // 위험성평가 제목
  rEvalTitle: '',
  // 재해발생보고서 문서 번호
  dssReportDocNo: '',
  // 근로자_수
  emplCnt: 0,
  // 근무형태
  workForm: '',
  // 위험성평가 1번 문항
  revalItem1: '',
  // 위험성평가 2번 문항
  rEvalItem2: '',
  // 위험성평가 3번 문항
  rEvalItem3: '',
  // 위험성평가 4번 문항
  rEvalItem4: '',
  // 안전보건_정보_내용
  hlthSftyInfoCn: '',
  // 준비_관련_첨부_파일_ID
  prepareRelFileId: '',
  /* 추진팀 정보 */

  // 그리드 상태
  //execTeamGubun: 'N',
  // 추진팀 구분 코드
  execTeamClsCd: '',
  // 추진팀 성명
  execTeamNm: '',
  // 추진팀 사번
  execTeamEmpno: '',
  // 추진팀 부문 코드
  execTeamSectCd: '',
  // 추진팀 부서 코드
  execTeamDeptCd: '',
  //  추진팀 업체명
  execTeamCompNm: '',
  // 추진팀 직책 코드
  execTeamPosCd: '',
  /* 공정 정보 */

  // 공정 명
  procNm: '',
};

// 추진팀 폼
const execDeptInitFormValue = {
  /* 기본 정보 */

  /* 추진팀 정보 */

  // 추진팀 구분 코드
  execTeamClsCd: '',
  // 추진팀 성명
  execTeamNm: '',
  // 추진팀 사번
  execTeamEmpno: '',
  // 추진팀 부문 코드
  execTeamSectCd: '',
  // 추진팀 부서 코드
  execTeamDeptCd: '',
  //  추진팀 업체명
  execTeamCompNm: '',
  // 추진팀 직책 코드
  execTeamPosCd: '',
  /* 공정 정보 */
};

const newItem = {
  num: '',
  evalStartDt: null,
  evalEndDt: null,
  dssReportDocNo: null,
  emplCnt: 0,
  workForm: null,
  hlthSftyInfoCn: null,
  prepareRelFileId: 0,
  meetDataPhotoId: 0,
  meetDataFileId: 0,
  eduDataPhotoFileId: 0,
  eduDataFileFileId: 0,
  chmclMtrlFileId: 0,
  authorSectCd: null,
  authorDeptCd: null,
  execTeamId: '',
  execTeamClsCd: '',
  execTeamNm: '',
  execTeamEmpno: '',
  execTeamSectCd: '',
  execTeamDeptCd: '',
  execTeamCompNm: null,
  execTeamPosCd: '',
  procNm: null,
  detailWrkNm: null,
  riskClsCd: null,
  riskFactorCd: null,
  riskOcurStatRes: null,
  currHlthSftyAction: null,
  riskDcsnPsbltVal: 0,
  riskDcsnImprtVal: 0,
  riskDcsnRiskVal: 0,
  riskDcsnCd: 0,
  rdcmsrCd: null,
  rdcmsrStatCd: null,
  staffEmpno: null,
  befImprSchdDt: null,
  befImprFileId: 0,
  aftImprCmpltDt: 0,
  aftImprFileId: 0,
  aftImprContent: 0,
  aftImprPsbltVal: null,
  aftImprImprtVal: null,
  aftImprRiskVal: null,
  revalYear: null,
  revalPeriod: null,
  revalDocNo: '',
  revalTitle: null,
  revalItem2: null,
  revalItem1: '',
  revalItem4: null,
  revalProcessId: 0,
  revalItem3: null,
};

const clearNewItem = {
  num: '',
  evalStartDt: null,
  evalEndDt: null,
  dssReportDocNo: null,
  emplCnt: 0,
  workForm: null,
  hlthSftyInfoCn: null,
  prepareRelFileId: 0,
  meetDataPhotoId: 0,
  meetDataFileId: 0,
  eduDataPhotoFileId: 0,
  eduDataFileFileId: 0,
  chmclMtrlFileId: 0,
  authorSectCd: null,
  authorDeptCd: null,
  execTeamId: '',
  execTeamClsCd: '',
  execTeamNm: '',
  execTeamEmpno: '',
  execTeamSectCd: '',
  execTeamDeptCd: '',
  execTeamCompNm: null,
  execTeamPosCd: '',
  procNm: null,
  detailWrkNm: null,
  riskClsCd: null,
  riskFactorCd: null,
  riskOcurStatRes: null,
  currHlthSftyAction: null,
  riskDcsnPsbltVal: 0,
  riskDcsnImprtVal: 0,
  riskDcsnRiskVal: 0,
  riskDcsnCd: 0,
  rdcmsrCd: null,
  rdcmsrStatCd: null,
  staffEmpno: null,
  befImprSchdDt: null,
  befImprFileId: 0,
  aftImprCmpltDt: 0,
  aftImprFileId: 0,
  aftImprContent: 0,
  aftImprPsbltVal: null,
  aftImprImprtVal: null,
  aftImprRiskVal: null,
  revalYear: null,
  revalPeriod: null,
  revalDocNo: '',
  revalTitle: null,
  revalItem2: null,
  revalItem1: null,
  revalItem4: null,
  revalProcessId: 0,
  revalItem3: null,
};
/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/risk/reval',
  baseRoutePath: '/occupation/risk/reval',
  formName: 'useOcuRiskTab1FormStore',
  formValue: {
    ...initFormValue,
  },
};

// 최상위 store
export const useOcuRiskTab1FormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  // 추진팀 삭제 list
  deleteExecDeptGridList: [],

  // 추진팀 그리드 list
  //deleteExecDeptlist: [],

  yupFormSchema: yupFormSchema,

  openFormModal: () => {
    // const { detailInfo } = get();
    // const { setFormValue } = useOcuZeroHzdGoalModalFormStore.getState();
    // setFormValue(detailInfo);
    set({ isCodeFormModalOpen: true });
  },

  closeFormModal: () => {
    set({ isCodeFormModalOpen: false });
  },

  initAddChk: () => {
    useOcuRiskMasterStore.getState().addChk = 'add';
  },

  // from 상세 조회
  getDetail: async (id) => {
    const { setList, disablePaging, originExecDeptlist, setTotalCount, execDeptChange } = get();

    // setList(null);

    const { formApiPath } = get();
    const response: any = await ApiService.get(`${formApiPath}/${id}`);
    const detailInfo = response.data;

    console.log('조회값===>', detailInfo);

    useOcuRiskMasterStore.getState().addChk = 'detail';

    set({
      // 위험성 평가 기본 정보
      detailInfo: detailInfo.revalBase,
      formValue: detailInfo.revalBase,
      formType: FORM_TYPE_UPDATE,
      // 없으면 입력 상태
      addChk: id,
    });

    // 추진팀 구성
    setTotalCount(detailInfo.revalExecDept.length);
    setList(detailInfo.revalExecDept);

    const { list } = get();
    // 상태값 N 추가
    list.map((info) => {
      info.execTeamGubun = 'N';
    });

    set({ originExecDeptlist: detailInfo.revalExecDept });

    console.log(' 리스트==>', list);
    console.log('원본 리스트==>', originExecDeptlist);

    // 공정 정보
    useOcuRiskTab1ProcessListStore.getState().getDetail(detailInfo.revalProcess);
    execDeptChange(detailInfo.revalExecDept[0], 0);
  },
  // 추진팀 저장
  execDeptSaveStrore: (execData) => {
    const { execDeptrow, list, originExecDeptlist } = get();

    console.log('추진팀 저장 행:', execDeptrow);
    console.log('execData::', execData);
    console.log('list[execDeptrow]::저장 리스트', list[execDeptrow]);

    let execTeamGubun = '';
    if (list[execDeptrow].execTeamId) {
      // 구분
      execTeamGubun = 'U';
    } else {
      // 구분
      execTeamGubun = 'I';
    }

    const data = {
      // 저장 구분(N: 기본 ,I: 신규,U:수정)
      execTeamGubun: (list[execDeptrow].execTeamGubun = execTeamGubun),
      // 구분 코드
      execTeamClsCd: (list[execDeptrow].execTeamClsCd = execData.execTeamClsCd),
      // 구분명
      execTeamClsNm: (list[execDeptrow].execTeamClsNm = execData.execTeamClsNm),
      // 이름
      execTeamNm: (list[execDeptrow].execTeamNm = execData.execTeamNm),
      // 사번
      execTeamEmpno: (list[execDeptrow].execTeamEmpno = execData.execTeamEmpno),
      // 부문
      execTeamSectCd: (list[execDeptrow].execTeamSectCd = execData.execTeamSectCd),
      // 부서
      execTeamDeptCd: (list[execDeptrow].execTeamDeptCd = execData.execTeamDeptCd),
      // 업체
      execTeamCompNm: (list[execDeptrow].execTeamCompNm = execData.execTeamCompNm),
      // 직책코드
      execTeamPosCd: (list[execDeptrow].execTeamPosCd = execData.execTeamPosCd),
      // 직책명
      execTeamPosNm: (list[execDeptrow].execTeamPosNm = execData.execTeamPosNm),
    };

    // 추진팀 저장 list
    //originExecDeptlist.push(data);

    console.log('저장 후 LIST값==>', list);
  },

  // 추진팀 삭제
  deleteExecDeptList: (delExecDeptdata) => {
    const { deleteExecDeptGridList } = get();

    // 삭제 row 추가
    if (delExecDeptdata.data.execTeamId) {
      deleteExecDeptGridList.push(delExecDeptdata.data);
    }

    console.log('삭제후 추진팀 리스트==>', deleteExecDeptGridList);
  },

  // 추진팀 행 추가
  execDeptAddRowStore: () => {
    const { execDeptrow, list, formValue, setList } = get();

    console.log('로우 추가::', list);
    //console.log('newItem::', newItem);
    console.log('clearNewItem::', clearNewItem);

    const newItem = {
      // 구분 값
      execTeamGubun: 'I',
      num: list.length + 1,
      execTeamId: '',
      execTeamClsCd: '',
      execTeamNm: '',
      execTeamEmpno: '',
      execTeamSectCd: '',
      execTeamDeptCd: '',
      execTeamCompNm: null,
      execTeamPosCd: '',
    };

    setList([...list, newItem]);
    // 추진팀행
    set({ execDeptrow: list.length });
  },

  // 추진팀 row 변경
  execDeptChange: (data, rowIndex) => {
    const { detailInfo, formValue, list } = get();

    // 구분
    detailInfo.execTeamClsCd = data.execTeamClsCd;
    // 구분명
    detailInfo.execTeamClsNm = data.execTeamClsNm;
    // 이름
    detailInfo.execTeamNm = data.execTeamNm;
    // 사번
    detailInfo.execTeamEmpno = data.execTeamEmpno;
    // 부문
    detailInfo.execTeamSectCd = data.execTeamSectCd;
    // 부문명
    detailInfo.execTeamSectNm = data.execTeamSectNm;
    // 부서
    detailInfo.execTeamDeptCd = data.execTeamDeptCd;
    // 업체
    detailInfo.execTeamCompNm = data.execTeamCompNm;
    // 직책
    detailInfo.execTeamPosCd = data.execTeamPosCd;
    // 직책명
    detailInfo.execTeamPosNm = data.execTeamPosNm;

    //구분
    formValue.execTeamClsCd = data.execTeamClsCd;
    // 구분명
    formValue.execTeamClsNm = data.execTeamClsNm;
    // 이름
    formValue.execTeamNm = data.execTeamNm;
    // 사번
    formValue.execTeamEmpno = data.execTeamEmpno;
    // 부문
    formValue.execTeamSectCd = data.execTeamSectCd;
    // 부문명
    formValue.execTeamSectNm = data.execTeamSectNm;
    // 부서
    formValue.execTeamDeptCd = data.execTeamDeptCd;
    // 업체
    formValue.execTeamCompNm = data.execTeamCompNm;
    // 직책
    formValue.execTeamPosCd = data.execTeamPosCd;
    // 직책명
    formValue.execTeamPosNm = data.execTeamPosNm;

    console.log('추진팀행::', rowIndex);
    console.log('formValue전::', formValue);
    console.log('detailInfo::', detailInfo);
    // 추진팀행
    set({ execDeptrow: rowIndex, formValue: formValue });

    console.log('formValue후::', formValue);
  },

  goFormPage: (id) => {
    const { baseRoutePath } = get();
    history.push(`${baseRoutePath}/${id}/edit`);
  },

  // listValidate: (list, requiredData) => {
  //   console.log('함수 list값==>', list);
  //   console.log('함수 필수값==>', requiredData);

  //   return list.every((item) => {
  //     return requiredData.every((field) => {
  //       if (!Object.prototype.hasOwnProperty.call(item, field)) {
  //         alert(`${field}는 필수입니다!.`);
  //         return false;
  //       }

  //       const value = item[field];
  //       if (value === null || value === '') {
  //         alert(`${item[field]}는 필수입니다@.`);
  //         return false;
  //       }

  //       return true;
  //     });
  //   });
  // },

  // 위험성평가 사전준비 탭 저장
  saveUseOcuRiskTab1: async () => {
    const {
      list,
      formDetailId,
      formApiPath,
      search,
      formValue,
      baseRoutePath,
      deleteExecDeptGridList,
      validate,
      listValidate,
      getDetail,
    } = get();

    //const { list, formDetailId, formApiPath, search, formValue, baseRoutePath } = get();

    //useOcuRiskTab1ProcessListStore.getState().list;
    const apiList = _.cloneDeep(list);

    console.log('기본정보===>', formValue);
    console.log('추진팀===>', apiList);
    console.log('추진팀 삭제 ===>', deleteExecDeptGridList);
    console.log('공정===>', useOcuRiskTab1ProcessListStore.getState().list);
    console.log('공정 삭제===>', useOcuRiskTab1ProcessListStore.getState().deleteProcessGridList);

    // 상태 변경 안된 항목 빼고 추진팀 List 재구성
    const execDeptInfoList = apiList.filter((item) => item.execTeamGubun !== 'N');
    // 상태 변경 안된 항목 빼고 공정 List 재구성
    const processInfoList = useOcuRiskTab1ProcessListStore.getState().list.filter((item) => item.procGubun !== 'N');

    console.log('추진팀===>', execDeptInfoList);
    console.log('공정스===>', processInfoList);

    const isValid = await validate();

    const requiredData = ['execTeamClsNm'];

    // execTeamClsNm

    // list 필수 체크
    // console.log('최종값===>', listValidate(apiList, requiredData));

    console.log('isValid==>', isValid);

    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const formParam = formValue;
          const apiParam = {
            // 기본정보
            form: formParam,
            // 추진팀
            execDeptInfoList: execDeptInfoList,
            // 추진팀 삭제 리스트
            deleteExecDeptList: deleteExecDeptGridList,
            // 공정 정보
            processInfoList: processInfoList,
            // 공정 정보 삭제 리스트
            deleteProcList: useOcuRiskTab1ProcessListStore.getState().deleteProcessGridList,
          };

          console.log('보내는 저장값===>', apiParam);

          const id = await ApiService.post(`${formApiPath}/${formValue.revalDocNo}/saveRiskTab1`, apiParam);
          // await ApiService.post(`${formApiPath}/${formDetailId}`, apiParam);
          // search();
          //history.push(`${baseRoutePath}`);

          console.log('id======>', id);

          ToastService.success('저장되었습니다.');
          useOcuRiskMasterStore.getState().addChk = 'detail';

          const { baseRoutePath } = get();
          history.push(`${baseRoutePath}/${id.data}/edit`);

          // getDetail(id.data);
        },
      });
    }
  },
  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

// 평가항목 선정 store
export const useOcuRiskTab1ProcessListStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  // 공정 정보 삭제 list
  deleteProcessGridList: [],

  yupFormSchema: yupFormSchema,
  // from 상세 조회
  getDetail: async (revalProcess) => {
    const { setList, disablePaging, setTotalCount, procChange } = get();

    setTotalCount(revalProcess.length);
    setList(revalProcess);

    useOcuRiskMasterStore.getState().addChk = 'detail';

    const { list } = get();
    // 상태값 N 추가
    list.map((info) => {
      info.procGubun = 'N';
    });

    console.log('추진팀:', revalProcess[0]);

    procChange(revalProcess[0], 0);
  },

  // 공정 행 추가
  procAddRowStore: () => {
    const { list, setList } = get();

    console.log('로우 추가::', list);
    //console.log('newItem::', newItem);
    console.log('clearNewItem::', clearNewItem);

    const newItem = {
      // 구분 값
      procGubun: 'I',
      num: list.length + 1,
      revalProcessId: '',
      // 공정 명
      procNm: '',
    };

    setList([...list, newItem]);
    // 추진팀행
    set({ procRow: list.length });
  },

  // 공정 삭제
  deleteProcList: (delProcessdata) => {
    const { deleteProcessGridList } = get();
    // 삭제 row 추가
    if (delProcessdata.data.revalProcessId) {
      deleteProcessGridList.push(delProcessdata.data);
    }
    console.log('삭제후 공정 리스트==>', deleteProcessGridList);
  },

  // 공정 row 변경
  procChange: (data, rowIndex) => {
    const { detailInfo, formValue, list } = get();

    console.log('공정명::', data.procNm);
    console.log('detailInfo::', useOcuRiskTab1FormStore.getState().detailInfo);
    // 공정명
    useOcuRiskTab1FormStore.getState().detailInfo.procNm = data.procNm;

    // 공정명
    useOcuRiskTab1FormStore.getState().formValue.procNm = data.procNm;

    // const { setFormValue } = useOcuRiskTab1FormStore.getState();
    // setFormValue(useOcuRiskTab1FormStore.getState().detailInfo);

    // 공정행
    set({ procRow: rowIndex });
  },

  // 공정 저장
  procSaveStrore: (procData) => {
    const { procRow, list } = get();

    console.log('공정 저장 행:', procRow);
    console.log('공정 데이터::', procData);
    console.log('list[execDeptrow]::저장 리스트', list[procRow]);

    let procGubun = '';
    if (list[procRow].revalProcessId) {
      // 구분
      procGubun = 'U';
    } else {
      // 구분
      procGubun = 'I';
    }

    const data = {
      // 구분
      procGubun: (list[procRow].procGubun = procGubun),
      procNm: (list[procRow].procNm = procData.procNm),
    };

    // 추진팀 저장 list
    //originExecDeptlist.push(data);

    console.log('저장 후 LIST값==>', list);
  },
  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuRiskTab1FormStore;
