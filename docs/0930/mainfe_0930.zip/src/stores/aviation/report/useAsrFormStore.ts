import { FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { REPORT_TYPE_ASR } from '@/config/ReportFormConstant';
import ApiService from '@/services/ApiService';
import { formBaseState } from '@/stores/slice/formSlice';
import CommonUtil from '@/utils/CommonUtil';
import _ from 'lodash';
import * as yup from 'yup';
import { create } from 'zustand';
import { asrFlightYupSchema } from './reportFormYupSchema';
import { createReportEditForm } from './useEditFormStore';

/* yup validation */
const yupFormSchema = yup.object().shape({
  flight: asrFlightYupSchema,
  flightCrew: yup.array(),
  event: yup.object().shape({
    occurPlaceNm: yup.string(),
    occurAirportCd: yup.string(),
    runwayNm: yup.string(),
    occurDttm: yup.string(),
    occurTimezoneCd: yup.string(),
    flightPhaseCd: yup.string(),
    altitudeUnitCd: yup.string(),
    altitudeCo: yup.number().nullable(),
    speedUnitCd: yup.string(),
    speedCo: yup.number().nullable(),
    subjectNm: yup.string().required(),
    descriptionTxtcn: yup.string().required(),
  }),
  weather: yup.object().shape({
    metCd: yup.string(),
    windOneCo: yup.number().nullable(),
    windTwoCo: yup.number().nullable(),
    gustCo: yup.number().nullable(),
    visibilityNm: yup.string(),
    cloudCd: yup.string(),
    tempCo: yup.number().nullable(),
    altimeterUnitCd: yup.string(),
    altimeterCo: yup.number().nullable(),
  }),
  bird: yup.object().shape({
    birdTypeNm: yup.string(),
    birdSizeCd: yup.string(),
    birdCoCd: yup.string(),
    struckBirdCoCd: yup.string(),
    timeTypeCd: yup.string(),
    landingLightYn: yup.string(),
    pilotWarnedYn: yup.string(),
    impactTimeNm: yup.string(),
    birdDescriptionCn: yup.string(),
  }),
});

const initFormValue = {
  flight: {
    departureDt: CommonUtil.getNowDateString('YYYYMMDD'),
    flightNo: '',
    regNo: '',
    aircraftTypeCd: '',
    departureAirportCd: '',
    arrivalAirportCd: '',
    divertAirportCd: '',
    stdTime: '',
    staTime: '',
    atdTime: '',
    ataTime: '',
    delayedMinCo: null,
    supplyNm: '',
    checkinNm: '',
  },
  flightCrew: [],
  event: {
    occurPlaceNm: '',
    occurAirportCd: '',
    runwayNm: '',
    occurDttm: '',
    occurTimezoneCd: 'utc',
    flightPhaseCd: '',
    altitudeUnitCd: '',
    altitudeCo: null,
    speedUnitCd: '',
    speedCo: null,
    subjectNm: '',
    descriptionTxtcn: '',
    fileGroupSeq: null,
  },
  weather: {
    metCd: '',
    windOneCo: null,
    windTwoCo: null,
    gustCo: null,
    visibilityNm: '',
    cloudCd: '',
    tempCo: null,
    altimeterCo: null,
    altimeterUnitCd: '',
    weatherCodeList: [],
  },
  bird: {
    birdTypeNm: '',
    birdSizeCd: '',
    birdCoCd: '',
    struckBirdCoCd: '',
    timeTypeCd: '',
    landingLightYn: '',
    pilotWarnedYn: '',
    impactTimeNm: '',
    birdDescriptionCn: '',
  },
};

/* form 초기화 */
const initFormData = {
  formName: 'asrForm',
  ...formBaseState,
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useAsrFormStore = create<any>((set, get) => ({
  ...createReportEditForm(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  editFormPath: '/aviation/report-form/ASR',

  reportTypeCd: REPORT_TYPE_ASR,

  filghtExpanded: true,
  eventExpanded: false,
  weatherExpaned: false,
  birdExapned: false,

  getDetail: async (id) => {
    const response: any = await ApiService.get(`avn/report/my-reports/${id}`);
    const detailInfo = response.data;
    const { report, reportAsr, flight, flightCrew } = detailInfo;

    // 'report' api에서 event 정보 추출
    const applyEvent = _.pick(report, [
      'occurPlaceNm',
      'occurAirportCd',
      'occurDttm',
      'occurTimezoneCd',
      'subjectNm',
      'descriptionTxtcn',
      'fileGroupSeq',
    ]);

    // 'reportAsr' api에서 event 정보 추출
    const applyEvent2 = _.pick(reportAsr, [
      'flightPhaseCd',
      'altitudeUnitCd',
      'altitudeCo',
      'speedUnitCd',
      'speedCo',
      'runwayNm',
    ]);

    const applyWeather = _.pick(reportAsr, [
      'metCd',
      'windOneCo',
      'windTwoCo',
      'gustCo',
      'visibilityNm',
      'cloudCd',
      'tempCo',
      'altimeterUnitCd',
      'altimeterCo',
    ]);

    const applyBird = _.pick(reportAsr, [
      'birdTypeNm',
      'birdSizeCd',
      'birdCoCd',
      'struckBirdCoCd',
      'timeTypeCd',
      'landingLightYn',
      'pilotWarnedYn',
      'impactTimeNm',
      'birdDescriptionCn',
    ]);

    const weatherCodeList = reportAsr.weatherCdarr ? reportAsr.weatherCdarr.split(',') : [];
    const applyFormValue = {
      flight: flight,
      flightCrew: flightCrew.map((info) => {
        info.tagName = info.crewTypeCd;
        return info;
      }),
      event: { ...applyEvent, ...applyEvent2 },
      weather: { ...applyWeather, weatherCodeList: weatherCodeList },
      bird: { ...applyBird },
    };
    set({
      detailInfo: detailInfo,
      formValue: applyFormValue,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  getApiParam: () => {
    const { formValue, formDetailId, detailInfo, reportTypeCd } = get();
    const { flight, flightCrew, event, weather, bird } = formValue;
    const { report } = detailInfo || {};

    // 'report'
    const serverReportParam = {
      ...report,
      reportId: formDetailId ? formDetailId : null,
      reportTypeCd: reportTypeCd,
      ...event,
    };
    // 'reportAsr'
    const serverAsrReportParam = {
      reportId: formDetailId ? formDetailId : null,
      reportDtlTypeCd: 'ASR_01',
      ...weather,
      ...bird,
      runwayNm: event.runwayNm,
      flightPhaseCd: event.flightPhaseCd,
      altitudeUnitCd: event.altitudeUnitCd,
      altitudeCo: event.altitudeCo,
      speedUnitCd: event.speedUnitCd,
      speedCo: event.speedCo,
      weatherCdarr: weather.weatherCodeList ? weather.weatherCodeList.join(',') : '',
    };
    // 최종 적용
    const reportApiParam = {
      flight: { ...flight, reportId: formDetailId ? formDetailId : null },
      flightCrew: flightCrew.map((info) => {
        const flightServerInfo = {
          crewTypeCd: info.tagName,
          empNo: info.empNo,
        };
        return flightServerInfo;
      }),
      report: serverReportParam,
      reportAsr: serverAsrReportParam,
    };
    return reportApiParam;
  },

  clear: () => {
    set({
      ...formBaseState,
      formValue: {
        ...initFormValue,
      },
    });
  },
}));

export default useAsrFormStore;
