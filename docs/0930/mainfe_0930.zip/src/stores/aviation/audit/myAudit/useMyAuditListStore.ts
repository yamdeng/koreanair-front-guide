import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import _ from 'lodash';
import history from '@/utils/history';

//-----------------------------------------------------------------------------------------------
/* MyAuditList */
//-----------------------------------------------------------------------------------------------

const today = new Date();
const year = today.getFullYear(); // 년도
const nowMonth = today.getMonth() + 1;
let nowMonthString = '';

if (nowMonth < 10) {
  nowMonthString = '0' + nowMonth;
} else {
  nowMonthString = nowMonth.toString();
}

const todayFirstMonth = year + '-' + '01';
const todayNowMonth = year + '-' + nowMonthString;

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/audit/my-audit/0/list/audit-list',
  baseRoutePath: '/audit/myAudit',
};

/* zustand store 생성 */
const useMyAuditListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  manualSearchParam: null,

  expandedList: ['auditor', 'car'],
  expandedAuditor: true,
  expandedCar: true,

  setExpandedList: (expandedList) => {
    // TODO :
    const expandedAuditor = expandedList.find((checkboxValue) => checkboxValue === 'auditor') ? true : false;
    const expandedCar = expandedList.find((checkboxValue) => checkboxValue === 'car') ? true : false;
    set({ expandedList: expandedList, expandedAuditor: expandedAuditor, expandedCar: expandedCar });
  },

  toggleExpandAuditor: () => {
    const { expandedAuditor } = get();
    set({ expandedAuditor: !expandedAuditor });
  },

  toggleExpandCar: () => {
    const { expandedCar } = get();
    set({ expandedCar: !expandedCar });
  },

  init: async () => {
    const { getMyAuditStatistics, clickStatusNumber } = get();
    getMyAuditStatistics(); // 상단 통계 조회
    clickStatusNumber(null, '3', '3_1'); // 화면진입시 My Processing All 의 Total 조건으로 Audit 목록 조회
  },

  //-----------------------------------------------------------------------------------------------
  /* 상단 통계 start */
  //-----------------------------------------------------------------------------------------------
  divAuditYear: new Date().getFullYear() + '',
  myAuditYear: new Date().getFullYear() + '',
  myProcessingGubun: 'all',
  dsStatistics: {},

  // 상단 통계 년도 변경시
  changeAuditYear: (gubun, value) => {
    if (gubun == 'div') {
      set({ divAuditYear: value });
    } else if (gubun == 'my') {
      set({ myAuditYear: value });
    } else if (gubun == 'processing') {
      set({ myProcessingGubun: value });
    }
    const { getMyAuditStatistics } = get();
    getMyAuditStatistics();
  },

  getMyAuditStatistics: async () => {
    const { divAuditYear, myAuditYear, myProcessingGubun, searchParam } = get();
    const apiParam = {
      divYear: divAuditYear,
      myYear: myAuditYear,
      processingGubun: myProcessingGubun,
      empNo: searchParam.empNo,
      divSearchList: searchParam.divSearchList,
    };

    const apiResult = await ApiService.get(`avn/audit/my-audit/0/list/audit-statistics`, apiParam);
    const data = apiResult.data || {};
    set({ dsStatistics: data });
  },

  // 상단통계 토글색상
  ToggleColor1_1: 'text-color-blue',
  ToggleColor1_2: 'text-color-blue',
  ToggleColor1_3: 'text-color-blue',
  ToggleColor1_4: 'text-color-blue',
  ToggleColor1_5: 'text-color-blue',
  ToggleColor1_6: 'text-color-red',
  ToggleColor2_1: 'text-color-blue',
  ToggleColor2_2: 'text-color-blue',
  ToggleColor2_3: 'text-color-blue',
  ToggleColor2_4: 'text-color-blue',
  ToggleColor2_5: 'text-color-blue',
  ToggleColor2_6: 'text-color-red',
  ToggleColor3_1: 'text-color-blue',
  ToggleColor3_2: 'text-color-blue',
  ToggleColor3_3: 'text-color-blue',
  ToggleColor3_4: 'text-color-blue',
  ToggleColor3_5: 'text-color-red',

  initStatisticsColor: () => {
    set({
      ToggleColor1_1: 'text-color-blue',
      ToggleColor1_2: 'text-color-blue',
      ToggleColor1_3: 'text-color-blue',
      ToggleColor1_4: 'text-color-blue',
      ToggleColor1_5: 'text-color-blue',
      ToggleColor1_6: 'text-color-red',
      ToggleColor2_1: 'text-color-blue',
      ToggleColor2_2: 'text-color-blue',
      ToggleColor2_3: 'text-color-blue',
      ToggleColor2_4: 'text-color-blue',
      ToggleColor2_5: 'text-color-blue',
      ToggleColor2_6: 'text-color-red',
      ToggleColor3_1: 'text-color-blue',
      ToggleColor3_2: 'text-color-blue',
      ToggleColor3_3: 'text-color-blue',
      ToggleColor3_4: 'text-color-blue',
      ToggleColor3_5: 'text-color-red',
    });
  },

  // 상단 통계 숫자 클릭시
  clickStatusNumber: (evt, gubun, detail) => {
    // 클릭된 객체의 색상 변경
    set({
      ToggleColor1_1: detail === '1_1' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor1_2: detail === '1_2' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor1_3: detail === '1_3' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor1_4: detail === '1_4' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor1_5: detail === '1_5' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor1_6: detail === '1_6' ? 'text-color-yellow' : 'text-color-red',
      ToggleColor2_1: detail === '2_1' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor2_2: detail === '2_2' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor2_3: detail === '2_3' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor2_4: detail === '2_4' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor2_5: detail === '2_5' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor2_6: detail === '2_6' ? 'text-color-yellow' : 'text-color-red',
      ToggleColor3_1: detail === '3_1' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor3_2: detail === '3_2' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor3_3: detail === '3_3' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor3_4: detail === '3_4' ? 'text-color-yellow' : 'text-color-blue',
      ToggleColor3_5: detail === '3_5' ? 'text-color-yellow' : 'text-color-red',
    });

    if (detail === '1_1') {
      set({ ToggleColor1_1: 'text-color-yellow' });
    }

    //debugger;
    if (evt) {
      if (evt.target.classList.contains('text-color-blue')) {
        //evt.target.classList.replace('text-color-blue', 'text-color-yellow');
        //evt.target.classList.remove('text-color-blue');
        //evt.target.classList.add('text-color-yellow');
      } else if (evt.target.classList.contains('text-color-red')) {
        //evt.target.classList.remove('text-color-red');
        //evt.target.classList.add('text-color-yellow');
      }
    }

    const { divAuditYear, myAuditYear, myProcessingGubun, searchParam } = get();
    // statusNumberInfo 자체가 apiParam이 됨
    const { enterSearch } = get();
    const apiParam: any = {};

    // Div Audit 영역
    if (gubun === '1') {
      apiParam.staSearchYear = divAuditYear;
    }
    // My Audit 영역
    else if (gubun === '2') {
      apiParam.staSearchYear = myAuditYear;
    }
    // My Processing 영역
    else if (gubun === '3') {
      apiParam.staSearchYear = '';
    }
    apiParam.searchType = 'statistics'; // 상단통계 클릭 조회
    apiParam.staSearchGubun = gubun;
    apiParam.staSearchDetail = detail;
    apiParam.empNo = searchParam.empNo;
    apiParam.processingGubun = myProcessingGubun;
    apiParam.divSearchList = searchParam.divSearchList;
    enterSearch(apiParam);
  },
  //-----------------------------------------------------------------------------------------------
  /* 상단 통계 end */
  //-----------------------------------------------------------------------------------------------

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    searchType: '', // 검색유형 : 상단통계 or 조회조건폼
    divSearchList: ['SELOYE'], // 로그인 사용자의 부문으로 처리 요망
    empNo: '0500673', // 로그인 사용자의 사번으로 처리 요망
    phaseSearchList: [],
    auditStartDtSearch: todayFirstMonth,
    auditEndDtSearch: todayNowMonth,
    dueStartDtSearch: '',
    dueEndDtSearch: '',
    titleSearch: '',
  },

  changeAuditStartDtSearch: (value) => {
    const { changeSearchInput } = get();
    if (value && value.length) {
      changeSearchInput('auditStartDtSearch', value);
    } else {
      changeSearchInput('auditStartDtSearch', '');
    }
  },
  changeAuditEndDtSearch: (value) => {
    const { changeSearchInput } = get();
    if (value && value.length) {
      changeSearchInput('auditEndDtSearch', value);
    } else {
      changeSearchInput('auditEndDtSearch', '');
    }
  },
  changeDueStartDtSearch: (value) => {
    const { changeSearchInput } = get();
    if (value && value.length) {
      changeSearchInput('dueStartDtSearch', value);
    } else {
      changeSearchInput('dueStartDtSearch', '');
    }
  },
  changeDueEndDtSearch: (value) => {
    const { changeSearchInput } = get();
    if (value && value.length) {
      changeSearchInput('dueEndDtSearch', value);
    } else {
      changeSearchInput('dueEndDtSearch', '');
    }
  },

  enterSearch: (manualSearchParam) => {
    if (manualSearchParam) {
      set({ currentPage: 1, manualSearchParam: manualSearchParam });
    } else {
      set({ currentPage: 1, manualSearchParam: null });
    }
    get().search();
  },

  search: async () => {
    const {
      listApiPath,
      getSearchParam,
      setTotalCount,
      listApiMethod,
      disablePaging,
      initStatisticsColor,
      manualSearchParam,
    } = get();
    const applyListApiMethod = listApiMethod || 'get';
    //const applyListApiMethod = listApiMethod || 'post';
    const apiParam = getSearchParam();
    let applyApiParam = _.cloneDeep(apiParam);

    // 상단통계 조회시
    if (manualSearchParam) {
      applyApiParam = { ...applyApiParam, ...manualSearchParam };
    } else {
      initStatisticsColor();
    }

    //console.log('applyApiParam: ' + applyApiParam);

    const apiResult: any = await ApiService[applyListApiMethod](listApiPath, applyApiParam);
    const data = apiResult.data;
    const list = disablePaging ? data : data.list;
    const totalCount = disablePaging && list ? list.length : data.total;
    setTotalCount(totalCount);
    set({ list: list || [] });
  },

  // MyAuditList 화면 초기화
  clearList: () => {
    set({ isCheckListFormModal: false, dsMyAuditStatistics: [] });
  },

  addAuditPlan: () => {
    //history.push(`/aviation/audit/myAudit/add`);
    window.open(`/aviation/audit/myAudit/add`, '_blank', 'noopener noreferrer');
  },

  editAuditProcess: (auditId) => {
    //history.push(`/aviation/audit/myAudit/${auditId}/edit`);
    window.open(`/aviation/audit/myAudit/${auditId}/edit`, '_blank', 'noopener noreferrer');
  },

  editAuditProcessCar: (auditId, findingId) => {
    //history.push(`/aviation/audit/myAudit/${auditId}/${findingId}/edit`);
    window.open(`/aviation/audit/myAudit/${auditId}/${findingId}/edit`, '_blank', 'noopener noreferrer');
  },
}));

export default useMyAuditListStore;
