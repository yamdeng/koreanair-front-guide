import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import _ from 'lodash';
import history from '@/utils/history';
import { produce } from 'immer';

/* zustand store 생성 */
const useMyAuditConductStore = create<any>((set, get) => ({
  dsAuditConductInfo: [],
  dsAuditChecklistInfo: [],
  dsAuditChapterList: [],
  dsAuditQuestionList: [],
  currentChecklistIndex: 0,
  currentChapterTabIndex: 0,

  // 체크리스트, 챕터, 문항 정보 조회
  setAuditConductInfo: async (auditInfo) => {
    set({ dsAuditConductInfo: auditInfo });
    const {
      dsAuditConductInfo,
      // dsAuditChapterList,
      // dsAuditQuestionList,
      currentChecklistIndex,
      currentChapterTabIndex,
    } = get();

    ApiService.get(`avn/audit/my-audit/2/conduct/checklist/${dsAuditConductInfo.auditId}`).then((apiResult) => {
      const checklistInfo = apiResult.data || {};
      set({
        dsAuditChecklistInfo: checklistInfo[currentChecklistIndex],
        dsAuditChapterList: checklistInfo[currentChecklistIndex].chapterInfo,
        dsAuditQuestionList: checklistInfo[currentChecklistIndex].chapterInfo[currentChapterTabIndex].questionInfo,
      });
    });
  },

  // chapter Tab 선택시 해당 문항 조회
  changeChapterTabIndex: (chapterTabIndex) => {
    set({ currentChapterTabIndex: chapterTabIndex });
    const { dsAuditChapterList, currentChapterTabIndex } = get();

    set({
      dsAuditQuestionList: dsAuditChapterList[currentChapterTabIndex].questionInfo,
    });
  },

  // 문항 수정시
  changeQuestionList: async (listLindex, keyName, value) => {
    // set(
    //   produce((state: any) => {
    //     // const questionInfo = state.dsAuditQuestionList[listLindex];
    //     // questionInfo[keyName] = value;
    //     // questionInfo.updated = true;
    //     // state.questionUpdateList.push(state.dsAuditQuestionList[listLindex]);
    //     const questionInfo = state.dsAuditQuestionList[listLindex];
    //     questionInfo[keyName] = value;
    //     questionInfo.updated = true;
    //   })
    // );
  },
}));

export default useMyAuditConductStore;
