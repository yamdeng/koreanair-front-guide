import { produce } from 'immer';
import { create } from 'zustand';
import CodeService from '@/services/CodeService';
import ApiService from '@/services/ApiService';
import history from '@/utils/history';
import CommonUtil from '@/utils/CommonUtil';
import ToastService from '@/services/ToastService';
import useAppStore from '@/stores/useAppStore';
import ModalService from '@/services/ModalService';

/* zustand store 생성 */
const useCheckListStore = create<any>((set, get) => ({
  //-----------------------------------------------------------------------------------------------
  /* 체크리스트 - 목록 */
  //-----------------------------------------------------------------------------------------------
  dsDivisionList: [],
  dsAuditChecklist: [],
  currentDivisionTabIndex: 0,
  isCheckListAddModal: false,
  langCode: 'ALL', // 언어코드

  changeLangCode: (selValue) => {
    set({ langCode: selValue });
    const { getAuditCheckList } = get();
    getAuditCheckList();
  },

  // 부문 목록 조회
  getDivisionList: (division) => {
    const getCodeList = CodeService.getCodeListByCodeGrpId('CODE_GRP_301');
    const searchIndex = getCodeList.findIndex((codeInfo) => {
      return codeInfo.codeId === division;
    });
    set({ dsDivisionList: getCodeList, currentDivisionTabIndex: searchIndex !== -1 ? searchIndex : 0 });
    const { getAuditCheckList } = get();
    getAuditCheckList(); // 부문 조회 후 체크리스트 조회
  },

  // 체크리스트,챕터 목록 조회
  getAuditCheckList: async () => {
    const { currentDivisionTabIndex, dsDivisionList, langCode } = get();
    const currentTabInfo = dsDivisionList[currentDivisionTabIndex];
    const { codeId } = currentTabInfo;
    const apiParam = { division: codeId, langCode: langCode };
    const apiResult = await ApiService.get(`avn/audit/checklist/1/checklist-chapter`, apiParam);
    const data = apiResult.data;
    set({ dsAuditChecklist: data });
  },

  // 부문탭 선택시 체크리스트,챕터 재조회
  changeDivisionTabIndex: (tabIndex) => {
    const { getAuditCheckList, dsDivisionList } = get();
    const currentTabInfo = dsDivisionList[tabIndex];
    const queryString = CommonUtil.objectToQueryString({ division: currentTabInfo.codeId });
    history.replace({
      pathname: history.location.pathname,
      search: queryString,
    });
    set({ currentDivisionTabIndex: tabIndex });
    getAuditCheckList();
  },

  // 상세화면으로 이동
  viewSelectedChapter: (division, checklistOrigId, chapterOrigId) => {
    history.push(`/aviation/audit/checklist/${division}/${checklistOrigId}/${chapterOrigId}`);
  },

  // 편집화면으로 이동
  editSelectedChapter: (division, checklistOrigId, chapterOrigId) => {
    history.push(`/aviation/audit/checklist/${division}/${checklistOrigId}/${chapterOrigId}/edit`);
  },

  openCheckListUploadModal: () => {
    ModalService.alert({
      body: '작업중입니다.',
    });
  },

  // 체크리스트 등록 팝업 오픈
  openCheckListAddModal: () => {
    set({ isCheckListAddModal: true });
  },

  closeCheckListAddModal: () => {
    set({ isCheckListAddModal: false });
  },

  // 체크리스트 등록
  okChecklistAddModal: async (formValue) => {
    const { getAuditCheckList, closeCheckListAddModal } = get();
    // TODO : 체크리스트 등록 api 호출후 완료되면 getAuditCheckList() 호출
    const { currentLocale } = useAppStore.getState();
    const apiParam = { ...formValue, langCode: currentLocale }; // 현재 설정된 언어코드
    await ApiService.post('avn/audit/checklist/3/checklist-insert', apiParam);
    ToastService.success('체크리스트가 추가되었습니다.');
    getAuditCheckList();
    closeCheckListAddModal();
  },

  // 체크리스트 화면 초기화
  clearList: () => {
    set({ isCheckListFormModal: false, currentDivisionTabIndex: 0, dsDivisionList: [], dsAuditChecklist: [] });
  },

  //-----------------------------------------------------------------------------------------------
  /* 체크리스트 - 상세 */
  //-----------------------------------------------------------------------------------------------
  paramDivision: '',
  paramChecklistOrigId: '',
  paramChapterOrigId: '',
  currentChapterTabIndex: 0,
  currentChapterId: 0,
  currentChapterOrigId: 0,
  selChecklistName: '',
  addQuestionVisible: '',

  dsAuditChapterList: [],
  dsAuditQuestionList: [],
  revisions: [],

  currentRevision: null,
  isLastRevision: true,
  isCheckListDelModal: false,
  isCheckListViewFormModal: false,

  // 상세화면 파라미터 설정
  setAuditChapterParam: (division, checklistOrigId, selectedChapterOrigId) => {
    set({
      paramDivision: division,
      paramChecklistOrigId: checklistOrigId,
      paramChapterOrigId: selectedChapterOrigId,
      currentRevision: null, // 화면진입시 리비전 초기화
    });
    const { getAuditChapterList } = get();
    getAuditChapterList();
  },

  // 상세보기 - checklist, chapter 조회
  getAuditChapterList: async () => {
    const { paramDivision, paramChecklistOrigId, paramChapterOrigId, currentRevision, langCode } = get();
    const apiParam = {
      division: paramDivision,
      origId: paramChecklistOrigId,
      revision: !currentRevision ? 0 : currentRevision,
      langCode: langCode,
    };
    const apiResult = await ApiService.get(`avn/audit/checklist/1/checklist-chapter`, apiParam);
    const data = apiResult.data || [];
    const checkListChapterInfo = data[0];
    const revisions = checkListChapterInfo.revisions;
    set({
      dsAuditChapterList: data,
      revisions: revisions,
      currentRevision: currentRevision ? currentRevision : revisions[revisions.length - 1].revision,
      // 최종버전일때만 삭제,편집 가능
      isLastRevision:
        currentRevision == revisions[revisions.length - 1].revision || currentRevision == null ? true : false,
      selChecklistName: data[0].checklistName, // 상세,편집 화면 상단의 체크리스트명
    });

    // 선택된 챕터 인덱스로 설정
    data[0].chapters.forEach((chapterInfo, index) => {
      if (chapterInfo.chapterOrigId == paramChapterOrigId) {
        set({ currentChapterTabIndex: index });
      }
    });

    // 해당 체크리스트에 챕터정보가 있으면 문항 조회
    if (data[0].chapters && data[0].chapters.length) {
      set({ addQuestionVisible: 'visible' });
      const { getAuditQuestionList } = get();
      getAuditQuestionList();
    } else {
      set({ addQuestionVisible: 'hide' });
    }
  },

  // chapter Tab 선택시 해당 chapter 문항 조회
  changeChapterTabIndex: (chapterTabIndex) => {
    set({ currentChapterTabIndex: chapterTabIndex });
    const { getAuditQuestionList } = get();
    getAuditQuestionList();
  },

  // 리비전 select 변경시 체크리스트,챕터 해당 리비전으로 재조회
  changeRevision: async (revision) => {
    set({ currentRevision: revision });
    const { getAuditChapterList } = get();
    getAuditChapterList();
  },

  // 상세보기 - question 조회
  getAuditQuestionList: async () => {
    const { currentChapterTabIndex, dsAuditChapterList, currentRevision } = get();
    const currentChapterInfo = dsAuditChapterList[0].chapters[currentChapterTabIndex];
    const { chapterOrigId } = currentChapterInfo;
    set({ currentChapterId: currentChapterInfo.chapterId });
    set({ currentChapterOrigId: currentChapterInfo.chapterOrigId });
    set({ paramChapterOrigId: currentChapterInfo.chapterOrigId });

    const apiParam = { chapterOrigId: chapterOrigId, revision: currentRevision };
    const apiResult = await ApiService.get(`avn/audit/checklist/2/questions`, apiParam);
    const data = apiResult.data;
    set({ dsAuditQuestionList: data });
  },

  // 상세화면 초기화
  clearView: () => {
    set({
      isCheckListViewFormModal: false,
      currentChapterTabIndex: 0,
      dsAuditChapterList: [],
      dsAuditQuestionList: [],
      revisions: [],
    });
  },

  // 체크리스트 삭제 팝업 오픈
  openCheckListDelModal: () => {
    set({ isCheckListDelModal: true });
  },

  closeCheckListDelModal: () => {
    set({ isCheckListDelModal: false });
  },

  // 체크리스트 삭제
  okChecklistDelModal: async (formValue) => {
    const { paramChecklistOrigId } = get();
    // TODO : 체크리스트 삭제 api 호출후 완료되면 getAuditCheckList() 호출
    const apiParam = { ...formValue, origId: paramChecklistOrigId }; // 현재 설정된 언어코드
    await ApiService.delete('avn/audit/checklist/5/checklist-delete', { data: apiParam });
    ToastService.success('체크리스트가 삭제되었습니다.');
    //history.back();
    //history.push('/aviation/audit/checklist');
    history.replace('/aviation/audit/checklist');
  },

  //-----------------------------------------------------------------------------------------------
  /* 체크리스트 - 편집 */
  //-----------------------------------------------------------------------------------------------
  isCheckListEditFormModal: false,

  // 챕터 등록 팝업 오픈
  openChapterAddModal: () => {
    set({ isChapterAddModal: true });
  },

  closeChapterAddModal: () => {
    set({ isChapterAddModal: false, formValue: null });
  },

  // 챕터 등록
  okChapterAddModal: async (formValue) => {
    const { paramChecklistOrigId, closeChapterAddModal, getAuditChapterList } = get();
    const apiParam = { ...formValue, checklistOrigId: paramChecklistOrigId };
    await ApiService.post('avn/audit/checklist/6/chapter-insert', apiParam);
    ToastService.success('Chapter가 추가되었습니다.');

    set({ currentRevision: null }); // 챕터등록후 리비전 초기화 (revision 업데이트시 최신 버전으로 재조회)
    getAuditChapterList();
    closeChapterAddModal();
  },

  detailChapterInfo: null, // 챕터 수정 팝업창에 보낼 파라미터 (챕터 정보)

  // 챕터 수정 팝업 오픈
  openChapterUpdModal: (chapterInfo) => {
    set({
      isChapterUpdModal: true,
      detailChapterInfo: chapterInfo,
    });
  },

  closeChapterUpdModal: () => {
    set({ isChapterUpdModal: false, formValue: null });
  },

  // 챕터 수정
  okChapterUpdModal: async (formValue) => {
    const { paramChecklistOrigId, currentChapterOrigId, currentChapterId, closeChapterUpdModal, getAuditChapterList } =
      get();
    const apiParam = {
      ...formValue,
      checklistOrigId: paramChecklistOrigId,
      origId: currentChapterOrigId,
      chapterId: currentChapterId,
    };
    await ApiService.put('avn/audit/checklist/7/chapter-update', apiParam);
    ToastService.success('Chapter가 수정되었습니다.');

    set({ currentRevision: null }); // 챕터수정후 리비전 초기화 (revision 업데이트시 최신 버전으로 재조회)
    getAuditChapterList();
    closeChapterUpdModal();
  },

  // 챕터 삭제 팝업 오픈
  openChapterDelModal: (chapterInfo) => {
    set({
      isChapterDelModal: true,
      detailChapterInfo: chapterInfo,
    });
  },

  closeChapterDelModal: () => {
    set({ isChapterDelModal: false, formValue: null });
  },

  // 챕터 삭제
  okChapterDelModal: async (formValue) => {
    const { paramChecklistOrigId, currentChapterOrigId, currentChapterId, closeChapterDelModal, getAuditChapterList } =
      get();
    // TODO : 체크리스트 삭제 api 호출후 완료되면 getAuditCheckList() 호출
    const apiParam = {
      ...formValue,
      checklistOrigId: paramChecklistOrigId,
      origId: currentChapterOrigId,
      chapterId: currentChapterId,
    };
    await ApiService.delete('avn/audit/checklist/8/chapter-delete', { data: apiParam });
    ToastService.success('Chapter가 삭제되었습니다.');

    set({ currentRevision: null }); // 챕터수정후 리비전 초기화 (revision 업데이트시 최신 버전으로 재조회)
    getAuditChapterList();
    closeChapterDelModal();
  },

  questionInsertList: [], // 저장시 추가된 문항목록
  questionUpdateList: [], // 저장시 수정된 문항목록
  questionDeleteList: [], // 저장시 삭제된 문항목록

  // 문항 추가시
  addQuestion: async () => {
    set(
      produce((state: any) => {
        state.dsAuditQuestionList.push({
          content: '',
          refManual: '',
          priority: 'C31404',
          probability: 'C31506',
          severity: 'C31606',
        });
      })
    );
  },

  // 문항 수정시
  changeQuestionList: async (listLindex, keyName, value) => {
    set(
      produce((state: any) => {
        // const questionInfo = state.dsAuditQuestionList[listLindex];
        // questionInfo[keyName] = value;
        // questionInfo.updated = true;
        // state.questionUpdateList.push(state.dsAuditQuestionList[listLindex]);
        const questionInfo = state.dsAuditQuestionList[listLindex];
        questionInfo[keyName] = value;
        questionInfo.updated = true;
      })
    );
  },

  // 문항 삭제시
  removeQuestion: async (listLindex) => {
    ModalService.confirm({
      body: '삭제하시겠습니까?',
      okLabel: '삭제',
      ok: () => {
        const { dsAuditQuestionList } = get();
        const removeQuestionInfo = { ...dsAuditQuestionList[listLindex] };
        set(
          produce((state: any) => {
            state.dsAuditQuestionList.splice(listLindex, 1);
            if (removeQuestionInfo.questionId) {
              state.questionDeleteList.push(removeQuestionInfo.questionId);
            }
          })
        );
      },
    });
  },

  // 편집화면 초기화
  clearEdit: () => {
    set({
      isCheckListEditFormModal: false,
      currentChapterTabIndex: 0,
      dsAuditChapterList: [],
      dsAuditQuestionList: [],
      revisions: [],
    });
  },

  // 체크리스트 수정 팝업 오픈
  openCheckListUpdModal: () => {
    set({ isCheckListUpdModal: true });
  },

  closeCheckListUpdModal: () => {
    set({ isCheckListUpdModal: false });
  },

  changeChecklistInput: (selValue) => {
    set({ selChecklistName: selValue });
  },

  // 체크리스트 저장 (챕터,문항 포함)
  okChecklistUpdModal: async (formValue) => {
    // TODO : 체크리스트 수정 api 호출후 완료되면 getAuditCheckList() 호출
    const {
      selChecklistName,
      paramChecklistOrigId,
      currentChapterOrigId,
      dsAuditQuestionList,
      questionDeleteList,
      closeCheckListUpdModal,
    } = get();

    const questionInsertList = dsAuditQuestionList.filter((info) => !info.questionId);
    const questionUpdateList = dsAuditQuestionList.filter((info) => info.questionId && info);
    const apiParam = {
      ...formValue, // revisionUpdate
      checklistOrigId: paramChecklistOrigId,
      chapterOrigId: currentChapterOrigId,
      listName: selChecklistName,
      inserted: questionInsertList,
      updated: questionUpdateList,
      deleted: questionDeleteList,
    };

    //debugger;
    await ApiService.put('avn/audit/checklist/4/checklist-update', apiParam);
    ToastService.success('체크리스트가 저장되었습니다.');
    closeCheckListUpdModal();
    //history.back();
    //history.push('/aviation/audit/checklist');
    history.replace('/aviation/audit/checklist');
  },

  // print 클릭시
  printChecklistPage: async () => {
    // ModalService.alert({
    //   body: '작업중입니다.',
    // });
    window.print();
  },

  // Checklist 목록으로 이동
  moveToListPage: async () => {
    history.push('/aviation/audit/checklist');
  },
}));

export default useCheckListStore;
