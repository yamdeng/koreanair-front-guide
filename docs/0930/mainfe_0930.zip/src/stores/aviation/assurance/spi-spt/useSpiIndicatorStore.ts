import { formBaseState } from '@/stores/slice/formSlice';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import dayjs from 'dayjs';
import * as yup from 'yup';
import { create } from 'zustand';

/* yup validation */
const yupFormSchema = yup.object({
  spiYear: yup.string().required(),
  spiCd: yup.string().required(),
  spiNm: yup.string().required(),
  spiTypeCd: yup.string(),
  spiTaxonomyCd: yup.string(),
  spiOutputStndCd: yup.string(),
  spiDescrCn: yup.string(),
  dataSourcesCd: yup.string(),
  spiCautionScore: yup.number().nullable(),
  spiWarnScore: yup.number().nullable(),
  spiCriticalScore: yup.number().nullable(),
  spiTargetScore: yup.number().nullable(),
  useYn: yup.string().required(),
  viewSn: yup.number().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  spiYear: '',
  spiCd: '',
  spiNm: '',
  spiTypeCd: '',
  spiTaxonomyCd: '',
  spiOutputStndCd: '',
  spiDescrCn: '',
  dataSourcesCd: '',
  spiCautionScore: '',
  spiWarnScore: '',
  spiCriticalScore: '',
  spiTargetScore: '',
  useYn: '',
  viewSn: '',
};

const now = dayjs();

const initListData = {
  ...listBaseState,
  disablePaging: true,
  listApiPath: 'avn/assurance/spi-spt/indicators',
  baseRoutePath: '/aviation/spi-spt/spiIndicatorList',
};

const initSearchParam = {
  spiYear: '' + now.year(),
  spiTypeCd: 'A',
  spiNm: '',
};

/* zustand store 생성 */
export const useSpiIndicatorStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  yupFormSchema: yupFormSchema,
  rowData: {},

  isRowData: (rowData) => {
    set({ rowData: rowData });
  },

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    year: '' + now.year(),
    spiType: 'A',
    spiName: '',
  },

  isPSPILoadModal: false,
  isPSPINewModal: false,

  okPSPILoadModal: (formValue) => {
    set({ isPSPILoadModal: false });
  },

  handlePSPILoadModal: (isPSPILoadModal) => {
    set({ isPSPILoadModal: isPSPILoadModal });
  },
  handlePSPINewModal: (isPSPINewModal) => {
    set({ isPSPINewModal: isPSPINewModal });
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  getSearchParam: () => {
    const { searchParam } = get();
    const { spiYear, spiTypeCd, spiNm } = searchParam;
    return {
      spiYear: spiYear,
      spiTypeCd: spiTypeCd,
      spiNm: spiNm,
    };
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue }, searchParam: { ...initSearchParam } });
  },
}));
