import {
  DATE_PICKER_TYPE_DATE,
  DATE_PICKER_TYPE_MONTH,
  DATE_PICKER_TYPE_QUARTER,
  DATE_PICKER_TYPE_YEAR,
  ERROR_TYPE_CORE,
} from '@/config/CommonConstant';
import dayjs from 'dayjs';
import _ from 'lodash';
import { nanoid } from 'nanoid';
import Logger from './Logger';
import useUIStore from '@/stores/useUIStore';
import useAppStore from '@/stores/useAppStore';
import { AxiosError } from 'axios';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

const convertEnterStringToBrTag = function (value) {
  return value.replace(/\\r\\n|\r\n|\n|\\n/g, '<br/>');
};

const replaceHighlightMarkup = function (text, highlightText, className = '') {
  let resultMarkup = text;
  if (text && highlightText) {
    highlightText = _.escapeRegExp(highlightText);
    const highlightRegExp = new RegExp(highlightText, 'g');
    let applyClassName = 'highlight';
    if (className) {
      applyClassName = `$${className} highlight`;
    }
    resultMarkup = text.replace(highlightRegExp, `<span class="${applyClassName}">${highlightText}</span>`);
  }
  return resultMarkup;
};

const getFilterListByMenuList = (menuList, keyword) => {
  const list = menuList;
  const filtedList = list.filter((menuInfo) => {
    const { title, fileName, path } = menuInfo;
    const componentName = fileName || path;
    if (keyword) {
      return title.indexOf(keyword) !== -1 || componentName.indexOf(keyword) !== -1;
    } else {
      return true;
    }
  });
  return filtedList;
};

const formatString = (template, ...args) => {
  return template.replace(/{([0-9]+)}/g, function (match, index) {
    return typeof args[index] === 'undefined' ? match : args[index];
  });
};

// 로컬 스토리지에 정보 저장 : json string으로 저장
const saveInfoToLocalStorage = (key, value) => {
  if (value || value === 0) {
    localStorage.setItem(key, JSON.stringify(value));
  } else {
    localStorage.setItem(key, '');
  }
};

const removeToLocalStorage = (key) => {
  if (key) {
    localStorage.removeItem(key);
  }
};

// 로컬 스토리지에 정보 가져오기 : json object로 가져옴
const getByLocalStorage = (key) => {
  const jsonString = localStorage.getItem(key);
  try {
    if (jsonString) {
      return JSON.parse(jsonString);
    } else {
      return null;
    }
  } catch (e) {
    Logger.error(`localStorage getByLocalStorage error : ${key}`);
  }
  return null;
};

const mergeColumnInfosByLocal = (sourceColumns, localStorgeKey = '') => {
  const localColumnInfos = getByLocalStorage(localStorgeKey ? localStorgeKey : location.pathname);

  if (localColumnInfos && localColumnInfos.length) {
    // 유효성 체크 1 : 컬럼 목록의 size가 같아야 함
    if (localColumnInfos.length !== sourceColumns.length) {
      return sourceColumns;
    }

    let validate = true;
    const applyColumns = [];
    localColumnInfos.forEach((localColumnInfo) => {
      const searchSourceColumnInfo = sourceColumns.find((localInfo) => localInfo.field === localColumnInfo.field);
      if (searchSourceColumnInfo) {
        const applyColumn = Object.assign({}, searchSourceColumnInfo, localColumnInfo);
        // 적용된 width 값이 존재하면 flex 보다 우선시되게끔 반영
        if (localColumnInfo.width === 0 || localColumnInfo.width) {
          applyColumn.flex = null;
        } else {
          applyColumn.flex = localColumnInfo.sourceFlex;
        }
        applyColumns.push(applyColumn);
      } else {
        validate = false;
      }
    });
    // 유효성 체크 2 : 저장된 컬럼된 정보가 field, headerName 키값으로 존재해야 함
    if (!validate) {
      return sourceColumns;
    }
    return applyColumns;
  }
  return sourceColumns;
};

const saveColumnInfos = (columns, localStorgeKey = '') => {
  const applyColumns = _.cloneDeep(columns);
  applyColumns.forEach((columInfo) => {
    columInfo.sourceFlex = columInfo.flex || columInfo.sourceFlex;
    if (columInfo.width === 0 || columInfo.width) {
      columInfo.flex = null;
    } else {
      columInfo.flex = columInfo.sourceFlex;
    }
  });
  saveInfoToLocalStorage(localStorgeKey ? localStorgeKey : location.pathname, applyColumns);
  return applyColumns;
};

const applyGroupingRowSpanByPageSize = (data, columnName, pageSize = 1000000) => {
  let applyRowIndex = 0;
  let rowSpanGroupCount = 1;
  let diffValue = '';

  for (let index = 0; index < data.length; index++) {
    const dataInfo = data[index];
    const currentValue = dataInfo[columnName];
    if (index !== 0 && index % pageSize === 0) {
      data[applyRowIndex].rowSpanGroupCount = rowSpanGroupCount;
      rowSpanGroupCount = 1;
      applyRowIndex = index;
    } else {
      if (diffValue === currentValue) {
        rowSpanGroupCount++;
        if (index === data.length - 1) {
          data[applyRowIndex].rowSpanGroupCount = rowSpanGroupCount;
        }
      } else {
        data[applyRowIndex].rowSpanGroupCount = rowSpanGroupCount;
        rowSpanGroupCount = 1;
        applyRowIndex = index;
      }
    }
    diffValue = currentValue;
  }
  return _.cloneDeep(data);
};

// upper_dept_cd = '0'
// listToTreeData(deptList.result, 'DEPT_ID', 'PRNT_ID', '10073')
function listToTreeData(items, treeKey, treeParentKey, rootValue) {
  const rootItems = [];
  const lookup = {};
  for (const item of items) {
    const lookUpTreeValue = item[treeKey];
    const lookUpTreeParentValue = item[treeParentKey];
    if (!lookup[lookUpTreeValue]) {
      lookup[lookUpTreeValue] = { children: [] };
    }
    lookup[lookUpTreeValue] = { ...item, children: lookup[lookUpTreeValue].children };

    // if (lookUpTreeParentValue == rootValue) {
    // if (lookUpTreeValue == rootValue) {
    if (lookUpTreeParentValue == rootValue) {
      rootItems.push(lookup[lookUpTreeValue]);
    } else {
      if (!lookup[lookUpTreeParentValue]) {
        lookup[lookUpTreeParentValue] = { children: [] };
      }
      lookup[lookUpTreeParentValue].children.push(lookup[lookUpTreeValue]);
    }
  }
  return rootItems;
}

function convertTreeData(treeData, titleColumn, valueColumn) {
  treeData.forEach((treeInfo) => {
    if (titleColumn) {
      treeInfo.title = treeInfo[titleColumn];
    }
    if (valueColumn) {
      treeInfo.value = treeInfo[valueColumn];
    }
    if (treeInfo.children && treeInfo.children.length) {
      convertTreeData(treeInfo.children, titleColumn, valueColumn);
    }
  });
}

// 검색된 키 목록을 기준으로 전체 트리 목록에서 펼쳐져야하는 key 목록을 셋탱해줌 : 검색된 정보의 상위 트리를 열어줘야 함
const addExpandedKeys = function (allList, resultKeys, info, key, parentKey) {
  if (info) {
    resultKeys.push(info[key]);
    const searchIndex = _.findIndex(allList, (tree) => {
      return tree[key] === info[parentKey];
    });
    addExpandedKeys(allList, resultKeys, allList[searchIndex], key, parentKey);
  }
};

const getDateFormatByPickerType = (pickerType, useWithTimePicker, excludeSecondsTime) => {
  if (pickerType === DATE_PICKER_TYPE_DATE) {
    if (useWithTimePicker) {
      if (excludeSecondsTime) {
        return 'YYYY-MM-DD HH:mm';
      } else {
        return 'YYYY-MM-DD HH:mm:ss';
      }
    } else {
      return 'YYYY-MM-DD';
    }
  } else if (pickerType === DATE_PICKER_TYPE_MONTH) {
    return 'YYYY-MM';
  } else if (pickerType === DATE_PICKER_TYPE_YEAR) {
    return 'YYYY';
  } else if (pickerType === DATE_PICKER_TYPE_QUARTER) {
    return `YYYY-MM-DD`;
  }
};

// 'YYYY-MM-DD'인 날짜를 분기 문자열로 변환
const convertDateToQuarterValueString = (dateStringInfo) => {
  let result = null;
  if (dateStringInfo) {
    if (Array.isArray(dateStringInfo)) {
      if (dateStringInfo.length) {
        result = dateStringInfo.map((dateString) => dayjs(dateString, 'YYYY-MM-DD').format('YYYY-[Q]Q'));
      }
    } else {
      result = dayjs(dateStringInfo, 'YYYY-MM-DD').format('YYYY-[Q]Q');
    }
  }

  return result;
};

/**
 *
 * @param params : query string으로 변환할 object
 * 예시) { page:1, pageSize: 10} : ?page=1&pageSize=10
 * https://developer.mozilla.org/ko/docs/Web/API/URLSearchParams
 */
const objectToQueryString = (params: object): string => {
  const urlSearchParamsInstance = new URLSearchParams(params as Record<string, string>);

  return urlSearchParamsInstance.toString() ? '?' + urlSearchParamsInstance.toString() : '';
};

const getQueryStringByArray = (parameterName: string, arr: string[]): string => {
  let result = '';
  if (arr && arr.length) {
    for (let arrIndex = 0; arrIndex < arr.length; arrIndex++) {
      const stringValue = arr[arrIndex];
      if (arrIndex === 0) {
        result = result + `?${encodeURIComponent(parameterName)}=` + stringValue;
      } else {
        result = result + `&${encodeURIComponent(parameterName)}=` + stringValue;
      }
    }
  }

  return result;
};

const getUUID = () => {
  return nanoid();
};

const validateYupForm = async (yupFormSchema, formValue) => {
  let success = true;
  let firstErrorFieldKey = '';
  const errors = {};
  try {
    await yupFormSchema.validate(formValue, { abortEarly: false });
  } catch (error: any) {
    success = false;
    console.log(error.errors);
    const yupErrors = error.inner;
    firstErrorFieldKey = yupErrors[0].path;
    const groupErrorInfo = _.groupBy(yupErrors, 'path');
    const errorKeys = Object.keys(groupErrorInfo);
    errorKeys.forEach((errorKey) => {
      errors[errorKey] = groupErrorInfo[errorKey][0].message;
    });
  }
  return { success, firstErrorFieldKey, errors };
};

const getNowByServerTime = (dateType = 'dateTime') => {
  const serverTimeDiffSecondValue = getByLocalStorage('serverTimeDiffSecondValue') || 0;
  const resultDate = dayjs().add(serverTimeDiffSecondValue, 'second');
  if (dateType === 'date') {
    return resultDate.format('YYYY-MM-DD');
  } else {
    return resultDate.format('YYYY-MM-DD HH:mm:ss');
  }
};

const convertNumberFormat = (numberValue) => {
  const result = '';
  if (numberValue !== null && numberValue !== undefined) {
    return Number(numberValue).toLocaleString();
  }
  return result;
};

// 오늘날짜 가져오기 (EX: 2024-08-28)
const getToDate = () => {
  const now = new Date();
  const formattedDate = now.toISOString().split('T')[0];
  return formattedDate;
};

// 전역 promise 에러 handle
const handleGlobalUnhandledRejection = function (event) {
  const reason = event.reason;
  if (reason) {
    const errorType = reason.errorType || '';
    if (reason instanceof AxiosError || errorType === 'api') {
      const apiConfig = reason.config || {};
      if (reason.response && reason.response.status === 401) {
        return;
      }

      const appErrorObject = {
        errorType: 'api',
        message: reason.message,
        url: apiConfig.url || '',
        method: apiConfig.method || '',
        stack: reason.stack ? reason.stack : '',
      };
      Logger.error('appErrorObject : ' + JSON.stringify(appErrorObject));
    } else {
      const appErrorObject = {
        errorType: 'otherpromis',
        message: reason.message || reason.toString(),
        stack: reason.stack ? reason.stack : '',
      };
      Logger.error('appErrorObject : ' + JSON.stringify(appErrorObject));
    }
  }
};

// 전역 오류 에러 handle
const handleGlobalError = function (message, sourceUrl, lineNumber, column, errorObject) {
  if (sourceUrl && sourceUrl.includes('.vite')) {
    // Vite와 관련된 에러는 무시
    return true;
  }
  const { lastErrorMessage, lastSourceUrl } = useUIStore.getState();
  if (message && sourceUrl) {
    if (lastErrorMessage === message && sourceUrl === lastSourceUrl) {
      return true;
    }
    useUIStore.getState().changeErrorInfo(message, sourceUrl);
  }
  errorObject = errorObject || {};
  if (errorObject && typeof errorObject === 'string') {
    errorObject = {
      message: errorObject,
    };
  }
  if (!errorObject.message) {
    errorObject.message = message || 'no_message';
  }

  // full error message
  let displayErrorMessage = '';
  displayErrorMessage = displayErrorMessage + 'url : ' + sourceUrl + '\n';
  displayErrorMessage = displayErrorMessage + 'lineNumber : ' + lineNumber + '\n';
  displayErrorMessage = displayErrorMessage + 'column : ' + column + '\n';
  displayErrorMessage = displayErrorMessage + 'message : ' + errorObject.message + '\n';

  // message, stack, errorType
  const appErrorObject: any = { errorType: errorObject.errorType || ERROR_TYPE_CORE, message: displayErrorMessage };
  if (errorObject.stack) {
    appErrorObject.statck = errorObject.stack;
  }
  Logger.error('appErrorObject : ' + JSON.stringify(appErrorObject));

  return false;
};

// report 페이지 handle 공통 함수
const openReportPage = (fileName, reportArg) => {
  const { accessToken, refreshToken } = useAppStore.getState();

  window.open(
    `${import.meta.env.VITE_API_URL}/api/v1/ubihtml?reportFile=${fileName}&reportArg=${encodeURIComponent(reportArg)}&accessToken=${encodeURIComponent(accessToken)}&refreshToken=${encodeURIComponent(refreshToken)}`,
    '_blank',
    'status=no,titlebar=no,menubar=no'
  );
};

// yup error 기준으로 오류가 난 list index 추출, 첫번째 에러 정보 반환(row의 어떤 컬럼이 오류가 났는지)
const getYupListErrorInfo = (yupErrors, firstErrorPath, listKey = 'list') => {
  const validResult: any = {
    firstListErrorPath: '',
    firstErrorIndex: -1,
    isListFirstError: false,
    listErrorIndexList: [],
  };
  const listErrorIndexList = yupErrors
    .filter((error) => error.path.startsWith(listKey))
    .map((error) => {
      // const match = error.path.match(/list\[(\d+)\]/);
      const regex = listKey ? new RegExp(`${listKey}\\[(\\d+)\\]`) : new RegExp(`\\[(\\d+)\\]`);
      const match = error.path.match(regex);
      return match ? parseInt(match[1], 10) : null;
    })
    .filter((index) => index !== null);

  // 첫 번째 에러와 해당 경로 추출
  if (listErrorIndexList.length > 0) {
    const applyListErrorIndexList = _.uniq(listErrorIndexList);
    const firstErrorIndex = applyListErrorIndexList[0];
    const firstError = yupErrors.find((error) => error.path.indexOf(`${listKey}[${firstErrorIndex}]`) !== -1);
    validResult.listErrorIndexList = applyListErrorIndexList;
    validResult.firstListErrorPath = firstError.path;
    validResult.firstErrorIndex = firstErrorIndex;
    // 첫번째 에러가 list 에러면은 flag 반영
    if (firstErrorPath === validResult.firstListErrorPath) {
      validResult.isListFirstError = true;
    }
  }
  return validResult;
};

const getNowDateString = (displayFormat = 'YYYY-MM-DD') => {
  return dayjs().format(displayFormat);
};

const getNowMonthString = (displayFormat = 'YYYY-MM') => {
  return dayjs().format(displayFormat);
};

// date value를 custom한 format으로 변환
const convertDate = (value, valueFormat, displayFormat = '') => {
  let displayDate = '';
  const applyDisplayFormat = displayFormat ? displayFormat : valueFormat;
  if (value) {
    displayDate = dayjs(value, valueFormat).format(applyDisplayFormat);
  }
  return displayDate;
};

const getDateListByMonth = (searchMonth, monthFormat = 'YYYY-MM') => {
  const result = [];
  const dateFormat = 'YYYYMMDD';
  const firstDateString = dayjs(searchMonth, monthFormat).startOf('month').format(dateFormat);
  const endDateString = dayjs(searchMonth, monthFormat).endOf('month').format(dateFormat);

  // dateString : '20240901'
  // date : 1 ~ 31
  // weekday : 0 ~ 6

  let dayPlusIndex = 0;

  while (dayPlusIndex < 32) {
    const nextDate = dayjs(firstDateString, dateFormat).add(dayPlusIndex, 'day');
    const nextDateString = nextDate.format(dateFormat);
    const weekday = nextDate.day();
    result.push({
      dateString: nextDateString,
      date: nextDate.date(),
      weekday: nextDate.day(),
      isHoliday: weekday === 0,
      isSaturday: weekday === 6,
    });
    if (nextDateString === endDateString) {
      break;
    }
    dayPlusIndex++;
  }

  return result;
};

const convertWeekDayList = (dataList) => {
  const result = [];
  // 0 ~ 6 : 일 ~ 토
  let weekDayList = [null, null, null, null, null, null, null];
  // for : 1~31일 반복함
  for (let index = 0; index < dataList.length; index++) {
    // 해당 일에 요일 정보를 가져옴 : 일 ~ 토
    const dayInfo = dataList[index];
    weekDayList[dayInfo.weekday] = dayInfo;
    // 토요일이면 초기화 넣고 초기화
    if (dayInfo.weekday === 6 || index === dataList.length - 1) {
      result.push(weekDayList);
      // 마지막일이 아닌 경우만 변수 초기화 셋팅
      if (index !== dataList.length - 1) {
        weekDayList = [null, null, null, null, null, null, null];
      }
    }
  }
  return result;
};

const calculateDate = (value, valueFormat, dateKind, calculateNumber, displayFormat = '') => {
  let displayDate = '';
  const applyDisplayFormat = displayFormat ? displayFormat : valueFormat;
  if (value) {
    displayDate = dayjs(value, valueFormat).add(calculateNumber, dateKind).format(applyDisplayFormat);
  }
  return displayDate;
};

const getTimeStringByDateFullString = (dateFullString) => {
  let result = '';
  if (dateFullString) {
    result = dateFullString.substring(8, 10) + dateFullString.substring(10, 12);
  }
  return result;
};

// 라이브러리 용량이 커서
const printById = async (htmlId = 'user-content') => {
  const element = document.getElementById(htmlId);
  if (element) {
    const canvas = await html2canvas(element);
    const dataUrl = canvas.toDataURL('image/png');

    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const pdfWindow = window.open('', '_blank');
      pdfWindow.document.write('<html><head><title>Print</title></head><body>');
      pdfWindow.document.write('<img src="' + dataUrl + '" style="max-width: 100%;" />');
      pdfWindow.document.write('</body></html>');
      pdfWindow.document.close();
      pdfWindow.focus();
      pdfWindow.print();
      pdfWindow.close();
    };
  }
};

const downloadPDfById = (htmlId = 'user-content') => {
  const element = document.getElementById(htmlId);
  if (element) {
    html2canvas(element)
      .then((canvas) => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF();

        const imgWidth = 190; // PDF 페이지에 맞춘 이미지 너비
        const pageHeight = pdf.internal.pageSize.height;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        let heightLeft = imgHeight;

        let position = 0;

        // 첫 페이지에 이미지 추가
        pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;

        // 페이지가 남아있으면 추가 페이지 생성
        while (heightLeft >= 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;
        }

        pdf.save('download.pdf');
      })
      .catch((error) => {
        Logger.error('Error generating PDF:', error);
      });
  }
};

// 오늘 하루 않보이기
const hiddenNoticeByExpireInfo = (gubun, articleId) => {
  const expireDateString = getByLocalStorage(gubun + '-' + articleId);
  const nowDate = dayjs();
  if (expireDateString) {
    const expireDate = dayjs(expireDateString);
    const diffMinutes = nowDate.diff(expireDate, 'minutes');
    // expireDate 가 현재 시간보다 크면은 hidden 처리
    if (diffMinutes < 0) {
      return true;
    }
    return false;
  }
  return false;
};

const saveNoticeExpireInfo = (gubun, articleId, days) => {
  const expireDateString = dayjs().add(days, 'days').format('YYYY-MM-DD HH:mm:ss');
  saveInfoToLocalStorage(gubun + '-' + articleId, expireDateString);
};

const downloadCurrentDisplayById = (htmlId = 'user-content') => {
  const target = document.getElementById(htmlId);
  if (!target) {
    return alert('사진 저장에 실패했습니다.');
  }
  html2canvas(target).then((canvas) => {
    const link = document.createElement('a');
    document.body.appendChild(link);
    link.href = canvas.toDataURL('image/png');
    link.download = 'safenet-display.png'; // 다운로드 이미지 파일 이름
    link.click();
    document.body.removeChild(link);
  });
};

export default {
  convertEnterStringToBrTag,
  replaceHighlightMarkup,
  getFilterListByMenuList,
  formatString,
  saveInfoToLocalStorage,
  removeToLocalStorage,
  getByLocalStorage,
  mergeColumnInfosByLocal,
  saveColumnInfos,
  applyGroupingRowSpanByPageSize,
  listToTreeData,
  getDateFormatByPickerType,
  convertDateToQuarterValueString,
  getQueryStringByArray,
  objectToQueryString,
  getUUID,
  validateYupForm,
  getNowByServerTime,
  convertNumberFormat,
  convertTreeData,
  addExpandedKeys,
  getToDate,
  handleGlobalError,
  handleGlobalUnhandledRejection,
  openReportPage,
  getYupListErrorInfo,
  getNowDateString,
  getNowMonthString,
  convertDate,
  getDateListByMonth,
  convertWeekDayList,
  calculateDate,
  getTimeStringByDateFullString,
  printById,
  downloadPDfById,
  hiddenNoticeByExpireInfo,
  saveNoticeExpireInfo,
  downloadCurrentDisplayById,
};
