package com.koreanair.ksms.batch.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class DataShareBean<T> {
    private static final Logger log = LoggerFactory.getLogger(DataShareBean.class);
    private final Map<String, T> shareDataMap = new ConcurrentHashMap<>();

    public void putData(String key, T data) {
        shareDataMap.put(key, data);
    }

    public T getData(String key) {
        return shareDataMap.get(key);
    }

    public int getSize() {
        return shareDataMap.size();
    }
}
