package com.koreanair.ksms.batch.base.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
public class BaseStepLogger implements StepExecutionListener{
    private static final Logger log = LoggerFactory.getLogger(BaseJobLogger.class);

    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.info(String.format("Step [%s] starting ........", stepExecution.getStepName()));
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        log.info(
                String.format(
                        "Step [%s] finished. Status : %s",
                        stepExecution.getStepName(), stepExecution.getStatus()));

        if (stepExecution.getStatus() != BatchStatus.COMPLETED) {
            log.info("Exit status : " + stepExecution.getExitStatus());
        }

        return stepExecution.getExitStatus();
    }
}
