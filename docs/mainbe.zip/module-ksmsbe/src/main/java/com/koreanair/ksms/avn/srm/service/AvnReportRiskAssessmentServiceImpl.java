package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AvnReportRiskAssessmentServiceImpl extends AbstractBaseService implements AvnReportRiskAssessmentService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    @Override
    public RiskAssessmentVo selectReportRiskAssessment(RiskAssessmentDto parameter, TbSysUserDto userInfo) {
        RiskAssessmentVo detail = commonSql.selectOne("AvnReportRiskAssessment.selectRiskAssessmentReport", parameter);
        if(detail==null) {
            return null;
        }

        @SuppressWarnings("unchecked")
        List<SmReportHazardVo> reportHazardList = commonSql.selectList("AvnReportRiskAssessment.selectReportHazard", parameter);
        detail.setReportHazardList(reportHazardList);

        List<SmReportHazardVo> reportHazardOcuList = commonSql.selectList("AvnReportRiskAssessment.selectReportHazardOcu", parameter);
        detail.setReportHazardOcuList(reportHazardOcuList);

        String reportType=detail.getReportType();
        //detail.setLinkUrl(PortalAppIdStore.getDataByName(reportType).getAppUrl());

        // 회의록 가림 처리
        hideAssessment(detail, userInfo);

        /*todo khw . 파일처리 관련해서 확인 필요
        int groupId = detail.getGroupId();
        List<Integer> hazardIds = commonSql.selectList("AvnReportRiskAssessment.selectReportHazrdId", groupId);
        if( hazardIds != null ) {
            for(Integer hazardId : hazardIds) {
                List<PoFileVo> attachment = getFirstRiskAssessmentAttachment(hazardId);
                detail.setAttachment(attachment);
            }
        };
        */
        return detail;
    }

    /**
     *  report가 hazard: non-confidential인 경우 해당 권한을 가진 자만 회의록 확인 가능
     *
     *  System Admin
     *  작성자 본인
     *  담당그룹
     * 	경감조치 수행팀
     *  LSC 멤버
     *  SSC멤버
     */
    private void hideAssessment(RiskAssessmentVo detail, TbSysUserDto userInfo) {
        String reportType = detail.getReportType();
        if (reportType.equals("hzr")) {

            int groupId = detail.getGroupId();
            int reportId = detail.getReportId();
            String isConfidential = commonSql.selectOne("AvnReportRiskAssessment.selectConfidential", reportId);

            if (isConfidential.equals("Y")) {
                return;
            }

            // 회의록을 볼 수 있는 사람의 목록을 가져오기
            // account_ids: user id 목록
            // emp_noㅣ 작성자의 사번

            Map<String, Object> parameter = new HashMap<>();
            parameter.put("reportId", groupId);
            parameter.put("empNo", userInfo.getEmpNo());
            parameter.put("accountIds", ksmsCommonService.selectAccountIdList());

            int result = commonSql.selectOne("AvnReportRiskAssessment.selectAssessmentNoteAuth", parameter);
            logger.debug("result: {}", result);

            if (result <= 0) {
                detail.setAssessmentNotes(null);
                detail.setVisibleNote(false);
            }
        }
    }

    @Override
    public String selectHzrConfidential(int reportId) {
        return commonSql.selectOne("AvnReportRiskAssessment.selectConfidential", reportId);
    }

    @Override
    public void updateReportAssessment(RiskAssessmentVo detail) throws Exception {
        // as-is -> Assessment 데이터를 update시킬때는 sm_report 테이블의 update_dt를 변경하지 않으려고함
        commonSql.update("AvnReportRiskAssessment.updateReportAssessment", detail);
    }

    @Override
    public ArrayList<SmReportHazardVo> insertFirstReportHazard(RiskAssessmentVo parameter) throws Exception {
        RiskAssessmentVo detail = parameter;
        int groupId = detail.getGroupId();

        ////todo khw. statistics only, 산업안전 종결, LSC종결 건은 기존 Hazard List를 삭제후 처리해야함..
        if ("Y".equals(parameter.getIsStatisticsOnly())
                || "Y".equals(parameter.getIsLscClose())
                || "Y".equals(parameter.getIsOcuClose())
        ) {
            commonSql.update("AvnReportRiskAssessment.deleteReportHazardAll", detail);
        }

        // generate data
        ArrayList<SmReportHazardVo> result = new ArrayList<SmReportHazardVo>();
        for (SmReportHazardVo item : detail.getReportHazardList()) {
            item.setGroupId(groupId);
            item.setTimeZone("Asia/Seoul");
            int id = item.getId();
            if (id == -1) {
                // insert if id is not exist
                commonSql.insert("AvnReportRiskAssessment.insertReportHazard", item);
            } else {
                commonSql.update("AvnReportRiskAssessment.updateFirstReportHazard", item);
            }
            result.add(item);
        }
        return result;
    }

    @Override
    public ArrayList<SmReportHazardVo> updateFirstReportHazard(RiskAssessmentVo parameter) throws Exception {
        RiskAssessmentVo detail = parameter;
        int groupId = detail.getGroupId();

        // generate data
        ArrayList<SmReportHazardVo> result = new ArrayList<SmReportHazardVo>();
        for (SmReportHazardVo item : detail.getReportHazardList()) {
            item.setGroupId(groupId);

            // 반려 상태이거나 id가 -1인경우만 처리가능
            String hazardPhase = item.getPhase();
            String hazardStepCode = item.getStepCode();
            int id = item.getId();
            item.setTimeZone("Asia/Seoul");

            if (id == -1) {
                commonSql.insert("AvnReportRiskAssessment.insertReportHazard", item);
                result.add(item);
            } else if ("acceptance".equals(hazardPhase) && "rejected".equals(hazardStepCode)) {
                commonSql.update("AvnReportRiskAssessment.updateFirstReportHazard", item);
                result.add(item);
            } else {
                commonSql.update("AvnReportRiskAssessment.updateFirstReportHazard", item);
            }

            List<PoFileVo> attachment = detail.getAttachment();

            /* todo khw 파일 처리 관련 수정 필요
            // attachment insert
            if( attachment != null && attachment.size() > 0) {
                List<Integer> hazardIds = commonSql.selectList("RiskAssessment.getReportHazrdId", reportId);
                if( hazardIds != null ) {
                    for(int hazardId : hazardIds) {
                        firstRiskAssessmentAttachment(detail, hazardId);
                    }
                };
            }
            */
        }
        return result;
    }

    @Override
    public ArrayList<SmReportHazardVo> updateFirstReportHazardOcu(RiskAssessmentVo parameter) throws Exception {
        RiskAssessmentVo detail = parameter;
        int groupId = detail.getGroupId();
        //hazard 내역 모두 삭제 후 Insert 처리
        commonSql.delete("AvnReportRiskAssessment.deleteReportHazardOcuAll", groupId);

        // generate data
        ArrayList<SmReportHazardVo> result = new ArrayList<SmReportHazardVo>();
        for (SmReportHazardVo item : detail.getReportHazardOcuList()) {
            item.setGroupId(groupId);

            commonSql.insert("AvnReportRiskAssessment.insertReportHazardOcu", item);
            result.add(item);
        }
        return result;
    }

    @Override
    public int deleteReportHazard(ReceiptDto.DELETE_Request_Hazard parameter) throws Exception {
        // as-is --> Assessment 데이터를 update시킬때는 sm_report 테이블의 update_dt를 변경하지 않으려고함
        // 삭제전 statistics only flag를 N으로 변경
        RiskAssessmentDto dto = new RiskAssessmentDto();
        dto.setHazardId(parameter.getId());
        SmReportHazardVo reportHazard = commonSql.selectOne("AvnReportRiskAssessment.selectReportHazard", dto);
        RiskAssessmentVo vo = new RiskAssessmentVo();
        vo.setId(reportHazard.getGroupId());
        vo.setIsStatisticsOnly("N");
        commonSql.update("AvnReportRiskAssessment.updateReportAssessment", vo);
        return commonSql.update("AvnReportRiskAssessment.deleteReportHazard", dto);
    }

    @Override
    public int deleteReportHazardOcu(ReceiptDto.DELETE_Request_Hazard parameter) throws Exception {
        return commonSql.update("AvnReportRiskAssessment.deleteReportHazardOcu", parameter);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<SmCommentVo> selectSmCommentList(RiskAssessmentCommentDto parameter) {
        return commonSql.selectList("AvnReportRiskAssessment.selectSmCommentList", parameter);
    }

    @Override
    public void insertSmComment(RiskAssessmentCommentDto parameter) throws Exception {
        Integer hazardId=parameter.getHazardId();
        SmComment smComment = new SmComment()
                .setGroupId(parameter.getGroupId())
                .setContent(parameter.getContent())
                .setEmpNo(parameter.getEmpNo())
                .setTimezone(parameter.getTimezone());
        if(hazardId!=null) {
            smComment.setHazardId(hazardId);
        }
        commonSql.insert("AvnReportRiskAssessment.insertSmComment", smComment);
    }

    @Override
    public void deleteSmComment(RiskAssessmentCommentDto parameter) throws Exception {
        SmComment smComment = new SmComment().setId(parameter.getId());
        commonSql.update("AvnReportRiskAssessment.deleteSmComment", smComment);
    }

    @Override
    public void updateSmComment(RiskAssessmentCommentDto parameter) throws Exception {
        SmComment smComment = new SmComment()
                .setId(parameter.getId())
                .setContent(parameter.getContent());
        commonSql.update("AvnReportRiskAssessment.updateSmComment", smComment);


    }

    @Override
    public int updateSecondReportHazard(SecondRiskAssessmentDto.PUT_Request parameter) throws Exception {
        SmReportHazardVo reportHazardVo = parameter.getDetail().getReportHazardList().get(0);

        commonSql.update("AvnReportRiskAssessment.updateSecondReportHazard", reportHazardVo);
        return reportHazardVo.getId();

    }

    @Override
    public boolean isLscLeader(SmsAuthDto parameter,boolean checkAdmin) {
        if(checkAdmin) {
            if(this.isSystemAdmin(parameter)) return true;
        }
        parameter.setLscType("leader");
        String lscEmpNo=commonSql.selectOne("AvnReportRiskAssessment.selectIsLsc", parameter);
        return parameter.getEmpNo().equals(lscEmpNo);
    }

    @Override
    public boolean isLscMember(SmsAuthDto parameter,boolean checkAdmin) {
        if(checkAdmin) {
            if(this.isSystemAdmin(parameter)) return true;
        }
        parameter.setLscType("member");
        String lscEmpNo=commonSql.selectOne("AvnReportRiskAssessment.selectIsLsc", parameter);
        return parameter.getEmpNo().equals(lscEmpNo);
    }

    public boolean isSystemAdmin(SmsAuthDto parameter) {
        List<String> roleList = avnCommonService.selectRoleList();
        if (roleList.contains("SA")) {
            return true;
        } else {
            return false;
        }
    }


    @Override
    public void insertFoqaxComments(RiskAssessmentVo parameter) throws Exception {
        commonSql.insert("AvnReportRiskAssessment.insertFoqaxComments", parameter);
        //todo khw. 알림메시지 전송 필요

    }

    @Override
    public void updateFoqaxComments(FoqaxCommentsVo parameter) throws Exception {
        commonSql.update("AvnReportRiskAssessment.updateFoqaxComments", parameter);
    }

}
