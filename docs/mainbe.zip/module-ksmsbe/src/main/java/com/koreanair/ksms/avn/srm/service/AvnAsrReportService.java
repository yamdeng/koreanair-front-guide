package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.AsrReportSelectDto;

public interface AvnAsrReportService {
    AsrReportSelectDto findAsrReport(int groupId, int reportId, String reportType) throws Exception;
}
