package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.AvnIvReportApprovalGroup;
import com.koreanair.ksms.common.dto.AvnIvReportApprovalGroupMember;
import com.koreanair.ksms.common.dto.CommonDto;
import com.koreanair.ksms.common.dto.SmSearchReport;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@Builder
@ToString


public class AvnSafetyInvestigationDetailDto extends CommonDto {
    @Schema(description = "조사보고서ID")
    private int id;

    private String reportNo;

    @Schema(description = "조사보고서 Subject")
    private String reportTitle;

    @Schema(description = "조사보고서 발생정보")
    private IvOccurrenceInformationDTO occurrenceInformation;

    @Schema(description = "조사보고서 비행정보")
    private IvFlightDTO flight;

    @Schema(description = "조사보고서 ")
    private List<IvCrewMemberDTO> crewMemberList;

    private IvInvestigationReportDTO investigationReport;

    private List<TbAvnIvHazard> hazardList;

    private String hazardId;

    private String hazardType;

    private String consequenceId;

    private List<IvAssumptionDTO> assumptionList;

    private List<IvRadicalDTO> radicalList;

    private int approvalGroupID;

    private List<IvCrewMemberDTO> memberList;

    private List<AvnIvReportApprovalGroup> approvalGroupList;

    private List<AvnIvReportApprovalGroupMember> approvalMemberList;

    private String createReportID;

    private String empNo;

    private String isSubmitted;

    private List<SmSearchReport> reportDocument;

    private List<TbAvnIvReportSmReport> tbAvnIvReportSmReport;

//    private String investigateName;
}
