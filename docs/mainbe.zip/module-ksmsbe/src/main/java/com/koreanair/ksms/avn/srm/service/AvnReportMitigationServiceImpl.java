package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.constants.AvnStatusCode;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import io.micrometer.common.util.StringUtils;
import jakarta.validation.Valid;
import jakarta.validation.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AvnReportMitigationServiceImpl extends AbstractBaseService implements AvnReportMitigationService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    @Autowired
    AvnReportRiskAssessmentService avnReportRiskAssessmentService;

    @Autowired
    AvnReportProcessService avnReportProcessService;

    @Override
    public ReportMitigationDto selectMitigationByReportId(ReportInfoDto.GET_Request dto) {
        int groupId= dto.getP_groupId();
        return commonSql.selectOne("AvnReportMitigation.selectMitigationByReportId", groupId);
    }

    @Override
    @Transactional
    public SmMitigation insertMitigationAssign(MitigationAssignDto.POST_Request parameter) throws Exception {
        SmMitigation mitigation = new SmMitigation()
                .setLeaderEmpNo(parameter.getLeaderEmpNo())
                .setDeptId(parameter.getDeptId())
                .setHazardId(parameter.getHazardId())
                .setTimezone(parameter.getTimezone());
        commonSql.insert("AvnReportMitigation.insertMitigationAssign", mitigation);

        //todo khw. 팀원 테이블(신규)로 insert 필요
        MitigationAcceptDto.POST_Request_Appointer paramAccept = new MitigationAcceptDto.POST_Request_Appointer();
        paramAccept.setId(mitigation.getHazardId());
        paramAccept.setMitigationEmpType("M");
        paramAccept.setEmpList(parameter.getMemberEmpNoList());
        updateMitigationAppointer(paramAccept);
        return mitigation;
    }

    @Override
    public SmMitigation updateMitigationAssign(@Valid MitigationAssignDto.PUT_Request parameter) throws Exception {
        SmMitigation mitigation = new SmMitigation().setLeaderEmpNo(parameter.getLeaderEmpNo())
                .setMemberEmpNoList(parameter.getMemberEmpNoList())
                .setDeptId(parameter.getDeptId())
                .setHazardId(parameter.getHazardId());
        commonSql.update("AvnReportMitigation.updateMitigationAssign", mitigation);
        return mitigation;
    }

    @Override
    public void updatePlanDueAt(MitigationAcceptDto.POST_Request parameter) throws Exception {
        commonSql.update("AvnReportMitigation.updatePlanDueAt", parameter);
    }

    @Override
    public SmMitigation selectMitigation(int hazardId) {
        return commonSql.selectOne("AvnReportMitigation.selectMitigation", hazardId);
    }

    @Override
    @Transactional
    public void updateMitigationAppointer(MitigationAcceptDto.POST_Request_Appointer parameter) throws Exception {
        commonSql.update("AvnReportMitigation.updateMitigationAccept", parameter);

        commonSql.delete("AvnReportMitigation.deleteMitigationEmpNo", parameter);
        commonSql.insert("AvnReportMitigation.insertMitigationEmpNo", parameter);

    }

    @Override
    public MitigationResultVo selectMitigationResult(MitigationResultDto.GET_Request parameter) throws Exception {
        MitigationResultVo vo = commonSql.selectOne("AvnReportMitigation.selectMitigationResult", parameter);

        if(vo == null) {
            return null;
        }

        int mitigationId = vo.getMitigation().getId();

        @SuppressWarnings("unchecked")
        List<ProgressRateVo> rate = commonSql.selectList("AvnReportMitigation.selectMitigationProgress", mitigationId);

        //todo khw. 첨부파일 관련 처리필요
        //List<PoFileVo> attachment = getMitigationAttachment(mitigationId);

        //vo.setAttachment(attachment);
        vo.setProgressRate(rate);
        return vo;
    }

    @Override
    public void updateMitigationResult(MitigationResultDto.PUT_Request parameter) throws Exception {
        MitigationResultVo detail = parameter.getDetail();
        List<ProgressRateVo> progressRateList = detail.getProgressRate();

        MitigationVo vo = detail.getMitigation();
        int hazardId = detail.getId();

        vo.setHazardId(hazardId);

        commonSql.update("AvnReportMitigation.updateMitigationResult", vo);

        if(vo.getIsSubmittedPlan().equals("Y") && vo.getHazardNo().contains("MSR")) {
            for (ProgressRateVo item : progressRateList) {
                item.setRateMitigationId(vo.getId());
                int id = item.getRateId();

                if( id == -1 || id == 0) {
                    // insert
                    commonSql.insert("AvnReportMitigation.insertMitigationProgress", item);
                } else {
                    // update
                    commonSql.update("AvnReportMitigation.updateMitigationProgress", item);
                }
            }
        }

        SmMitigation updated = commonSql.selectOne("AvnReportMitigation.selectMitigation", hazardId);
        //todo khw. 첨부파일 관련 처리필요
        //mergeMitigationAttachment(detail, updated.getId());
    }

    @Override
    public void updateMitigationPlanSubmit(int hazardId) {
        commonSql.update("AvnReportMitigation.updateMitigationPlanSubmit", hazardId);
    }

    @Override
    public void updateMitigationResultSubmit(int hazardId) {
        commonSql.update("AvnReportMitigation.updateMitigationResultSubmit", hazardId);

    }

    @Override
    public void deleteMitigationProgressRateList(int listId) {
        commonSql.delete("AvnReportMitigation.deleteMitigationProgress", listId);
    }

    @Override
    @Transactional
    public SmMitigation updateMitigationTransfer(MitigationAssignDto.PUT_Request parameter) throws Exception {
        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        String empNo = userInfo.getEmpNo();

        //기존 Mitigation 삭제 처리((deleteReportRole ->> insertReportRole)
        ReportProcessVo proccessVo = new ReportProcessVo()
                .setGroupId(parameter.getGroupId())
                .setEmpNo(empNo)
                .setHazardId(parameter.getHazardId())
                .setReason("")
                .setTimezone("Asia/Seoul");
        avnReportProcessService.deleteReportRole(proccessVo, "", AvnStatusCode.ReportStatus.MIT_ACCEPT_REJECTED); //Reject 으로 처리하여 기존 등록된 Role 정보를 삭제처리함..

        //신규 Mitigation 추가 처리
        SmMitigation mitigation = new SmMitigation().setLeaderEmpNo(parameter.getLeaderEmpNo())
                .setMemberEmpNoList(parameter.getMemberEmpNoList())
                .setDeptId(parameter.getDeptId())
                .setHazardId(parameter.getHazardId())
                .setMitigationCenterDeptId(parameter.getMitigationCenterDeptId())
                ;
        commonSql.update("AvnReportMitigation.updateMitigationAssign", mitigation);

        this.updateMitigationStatus(proccessVo);

        avnReportProcessService.insertReportRole(proccessVo, "", AvnStatusCode.ReportStatus.MIT_ASSIGN_APPROVED);

        //todo khw. 이메일/알림 발송 처리 필요

        return mitigation;
    }

    public void updateMitigationStatus(ReportProcessVo processVo) throws Exception {
        logger.debug("\r\n\r\n** updateMitigationStatus\r\n");

        String state = "open";
        String phase = "mitigation_assign";
        String step = "approved";
        SmReportApprovalLog logParam = new SmReportApprovalLog(processVo.getGroupId(), processVo.getHazardId(), state, phase, step, processVo.getEmpNo(), "");
        logParam.setTimezone(processVo.getTimezone());

        commonSql.insert("AvnReportProcess.insertHazardApprovalLog", logParam);

        //두번째 파라메터 processVo.getReportId() 값은 없으므로.. -1로 대체함..
        SmReportHazard hazardParam = new SmReportHazard(processVo.getGroupId(), -1, processVo.getHazardId(), state, phase, step);
        commonSql.update("AvnReportProcess.updateHazardStatus", hazardParam);
    }

    @Override
    public List<SmReport> selectMitigationDeptUserList(MitigationAssignDto.PUT_Request param) {
        return commonSql.selectList("AvnReportMitigation.selectMitigationDeptUserList", param);
    }

    @Override
    public String selectMitigationDeptSectorInfo(Integer deptId) {
        return commonSql.selectOne("AvnReportMitigation.selectMitigationDeptSectorInfo", deptId);
    }

    @Override
    public List<SmMitigation> selectMitigationEmpNo(MitigationAcceptDto.POST_Request_Appointer parameter) {
        return commonSql.selectList("AvnReportMitigation.selectMitigationEmpNo", parameter);
    }
}
