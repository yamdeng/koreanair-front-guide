package com.koreanair.ksms.avn.sfta.service;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.avn.sfta.dto.OpStatusDto;
import com.koreanair.ksms.avn.sfta.dto.SpiReportDto;
import com.koreanair.ksms.avn.sfta.dto.SpiStatusDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.dto.TbAvnSpiDto;

public interface AvnSpiSptService {

    //안전보증 > SPI/SPT > 운영현황
    List<SpiStatusDto> selectSPICodeList(SpiStatusDto tbSsSpiDto);

    //안전보증 > SPI/SPT > 운영현황
    List<OpStatusDto> selectOpStatusList1(OpStatusDto opStatusDto);
    List<OpStatusDto> selectOpStatusList2(OpStatusDto opStatusDto);
    List<OpStatusDto> selectOpStatusList3(OpStatusDto opStatusDto);

    
    //안전보증 > 지표관리 > 지표관리 목록
    List<TbAvnSpiDto> selectSpiIndicatorList(TbAvnSpiDto tbSsSpiDto);
    
    //안전보증 > 지표관리 > 생성할 지표건수 조회
    Map<String, Object> selectSpiIndicatorCnt(TbAvnSpiDto tbSsSpiDto);
    int loadSpiIndicator(TbAvnSpiDto tbSsSpiDto);

    //안전보증 > 지표관리 > 지표등록/수정
    void insertSpiIndicator(TbAvnSpiDto tbSsSpiDto);
    void updateSpiIndicator(TbAvnSpiDto tbSsSpiDto);
    

    //안전보증 > Report List > 레포트 목록
    List<SpiReportDto> selectSpiReportList(Map<String, Object> param);

    //안전보증 > Report List > 레포트 목록 > 지표 SPI 및 위험도 저장
    void updateSpiReport(SpiReportDto param);

    // 관리자 > 게시판 관리 > SPI게시판 목록/상세
    PageInfo<TbAvnBoardDto> selectBoardList(BoardSearchDto boardSearchDto);
    TbAvnBoardDto selectBoardDetail(int boardId);

    // 관리자 > 게시판 관리 > SPI게시판 등록/수정/삭제
    void insertBoard(TbAvnBoardDto tbAvnBoardDto);
    void updateBoard(TbAvnBoardDto tbAvnBoardDto);
    void deleteBoard(int boardId);
}
