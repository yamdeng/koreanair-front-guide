package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.TbSysUserDto;
import io.vertx.core.json.JsonObject;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain =true)
@ToString
public class SmsAuthDto {
	private TbSysUserDto userInfo;
	private int id; // groupId or hazardId
	private String empNo;
	private String lscType;
	private String reportType;
	
	public SmsAuthDto(TbSysUserDto userInfo) {
		this.userInfo=userInfo;
	}
}
