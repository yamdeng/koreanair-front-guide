package com.koreanair.ksms.avn.srm.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;

public class MitigationResultDto {

	@Getter
	@Setter
	@AllArgsConstructor
	@ToString
	public static class GET_Request {
		@NotNull
		private int hazardId;
		@NotNull
		private Integer deptId;

	}

	@Getter
	@Setter
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	public static class PUT_Request {
		MitigationResultVo detail;
	}
}