package com.koreanair.ksms.avn.main.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnMainServiceImpl extends AbstractBaseService implements AvnMainService {

    @Override
    public List<Map<String, Object>> getTopRiskList() {

        List<Map<String, Object>> resultList = commonSql.selectList("AvnMain.selectTopRiskList");

        return resultList;
    }

    @Override
    public List<Map<String, Object>> getReportProcessList(String userId) {

        List<Map<String, Object>> resultList = commonSql.selectList("AvnMain.selectReportProcessList", userId);

        return resultList;
    }

    @Override
    public List<Map<String, Object>> getToDoList(String userId) {

        List<Map<String, Object>> resultList = commonSql.selectList("AvnMain.selectToDoList", userId);

        return resultList;
    }

    @Override
    public List<TbAvnBoardDto> getBannerList() {
        BoardSearchDto boardSearchDto = BoardSearchDto.builder().viewYn("Y").boardType("60").useYn("Y").build();
        
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnMain.selectBoardList", boardSearchDto);

        return resultList;
    }

    @Override
    public List<TbAvnBoardDto> getNoticeList() {
        BoardSearchDto boardSearchDto = 
            BoardSearchDto.builder()
                            .viewYn("Y")
                            .boardType("70")
                            .useYn("Y")
                            .build();
        
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnMain.selectBoardList", boardSearchDto);

        return resultList;
    }

    @Override
    public List<Map<String, Object>> getAccidentList() {

        List<Map<String, Object>> resultList = commonSql.selectList("AvnMain.selectAccidentList");

        return resultList;
    }
}
