package com.koreanair.ksms.avn.srm.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbAvnIvCrew {
    private int id;
    private int reportID;
    private String empNo;
}
