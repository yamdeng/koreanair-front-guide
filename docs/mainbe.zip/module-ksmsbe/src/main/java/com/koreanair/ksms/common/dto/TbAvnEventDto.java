package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "보고서_별_EVENT_TYPE")
public class TbAvnEventDto extends CommonDto {
    
    @Schema(description = "이벤트ID")
    @NotBlank
    private int eventId;
    
    @Schema(description = "리포트유형코드")
    @NotBlank
    private String reportTypeCd;
    
    @Schema(description = "이벤트명")
    @NotBlank
    private String eventNm;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "표시순번")
    private String viewSn;
    
    @Schema(description = "이벤트구ID")
    private String eventOldId;
    
    @Schema(description = "메모내용")
    private String notesCn;
}
