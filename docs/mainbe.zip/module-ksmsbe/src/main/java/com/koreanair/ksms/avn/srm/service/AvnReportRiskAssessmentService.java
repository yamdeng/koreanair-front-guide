package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.dto.TbSysUserDto;

import java.util.ArrayList;
import java.util.List;

public interface AvnReportRiskAssessmentService {
    RiskAssessmentVo selectReportRiskAssessment(RiskAssessmentDto parameter, TbSysUserDto userInfo);

    void updateReportAssessment(RiskAssessmentVo detail) throws Exception;

    ArrayList<SmReportHazardVo> insertFirstReportHazard(RiskAssessmentVo parameter) throws Exception;

    ArrayList<SmReportHazardVo> updateFirstReportHazard(RiskAssessmentVo parameter) throws Exception;

    ArrayList<SmReportHazardVo> updateFirstReportHazardOcu(RiskAssessmentVo parameter) throws Exception;

    int deleteReportHazard(ReceiptDto.DELETE_Request_Hazard parameter) throws Exception;

    int deleteReportHazardOcu(ReceiptDto.DELETE_Request_Hazard parameter) throws Exception;

    List<SmCommentVo> selectSmCommentList(RiskAssessmentCommentDto parameter);

    void insertSmComment(RiskAssessmentCommentDto parameter) throws Exception;

    void deleteSmComment(RiskAssessmentCommentDto parameter) throws Exception;

    void updateSmComment(RiskAssessmentCommentDto parameter) throws Exception;

    boolean isLscLeader(SmsAuthDto parameter, boolean checkAdmin);

    boolean isLscMember(SmsAuthDto parameter, boolean checkAdmin);

    int updateSecondReportHazard(SecondRiskAssessmentDto.PUT_Request parameter) throws Exception;

    String selectHzrConfidential(int reportId);

    void insertFoqaxComments(RiskAssessmentVo parameter) throws Exception;

    void updateFoqaxComments(FoqaxCommentsVo parameter) throws Exception;
}
