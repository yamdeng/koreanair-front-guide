package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "리포트 - LSC 그룹의 멤버 정보")
public class LscGroupWithMemberDto {
    @Schema(description = "ID")
    private Integer id;

    @Schema(description = "그룹ID")
    private String groupId;

    @Schema(description = "사원ID")
    private String empNo;

    @Schema(description = "멤버구분")
    private String memberType;

    @Schema(description = "등록일자")
    private String regDttm;

    @Schema(description = "수정일자")
    private String updDttm;

    @Schema(description = "삭제일자")
    private String deletedAt;

    @Schema(description = "타임존")
    private String timezone;

    @Schema(description = "멤버ID")
    private String userId;

    @Schema(description = "멤버명(한글)")
    private String nameKo;

    @Schema(description = "멤버명(영문)")
    private String nameEn;

    @Schema(description = "멤버부서(한글)")
    private String deptNameKo;

    @Schema(description = "멤버부서(영문)")
    private String deptNameEn;
}
