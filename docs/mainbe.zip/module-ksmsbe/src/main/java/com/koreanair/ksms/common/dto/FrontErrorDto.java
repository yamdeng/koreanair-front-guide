package com.koreanair.ksms.common.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FrontErrorDto extends CommonDto {

    private int id;
    private String userId;
    private String token;
    private String message;
    private String created;
    private String currentRouteUrl;
    private String beforeRouteUrl;
    private String userAgent;
    private String version;
}
