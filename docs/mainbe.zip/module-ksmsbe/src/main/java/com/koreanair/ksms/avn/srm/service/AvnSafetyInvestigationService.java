package com.koreanair.ksms.avn.srm.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.dto.TbAvnSysUserDto;
import com.koreanair.ksms.common.dto.AvnIvReportApproval;
import com.koreanair.ksms.common.dto.AvnIvReportApprovalGroup;
import com.koreanair.ksms.common.dto.AvnIvReportApprovalGroupMember;

public interface AvnSafetyInvestigationService {

    // 안전위험관리 > 안전조사 > 조사보고서 목록 조회
    PageInfo<AvnSafetyInvestigationDto> selectInveReportList(AvnSafetyInvestigationDto avnSafetyInvestigationDto);

    // 이벤트 타입 목록 조회
    List<AvnSafetyInvestigationEventTypeDto> selectEventTypeASRList();

    // consequence 목록 조회
    List<AvnSafetyInvestifationConsequenceDto> selectConsequenceList();

    // hazard 목록 조회
    List<AvnSafetyInvestifationHazardDto> selectHazardList();

    //안전위험관리 > 안전조사 > 조사보고서 신규
    void insertInvestigation(AvnSafetyInvestigationFormDto avnSafetyInvestigationFormDto);

    //안전위험관리 > 안전조사 > 조사보고서 결재 그룹 목록 조회
    List<AvnIvReportApprovalGroup> selectApprovalGroupList();

    //안전위험관리 > 안전조사 > 조사보고서 결재 그룹 멤버 목록 조회
    List<AvnIvReportApprovalGroupMember> selectApprovalGroupMemberList(int groupId);
    
    //안전위험관리 > 안전조사 > 조사보고서 결재 그룹 생성
    void insertIvApprovalGroup(AvnIvReportApproval avnIvReportApproval);

    //사원번호로 회원정보 검색
    TbAvnSysUserDto searchEmpNoUserInfo(AvnIvReportApprovalGroupMember avnIvReportApprovalGroupMember);

    //안전위험관리 > 안전조사 > 조사보고서 상세
    AvnSafetyInvestigationDetailDto selectIvReportDetail(int id);
    
    
}
