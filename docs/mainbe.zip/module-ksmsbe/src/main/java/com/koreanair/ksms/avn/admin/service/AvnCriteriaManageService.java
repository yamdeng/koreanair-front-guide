package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.*;

public interface AvnCriteriaManageService {

    // Potential Consequesnce 목록 조회
    PageInfo<TbAvnConsequenceDto> selectConsequenceList(TbAvnConsequenceDto tbAvnConsequenceDto);

    // Potential Consequesnce 신규 등록
    void insertPotentialConsequence(TbAvnConsequenceDto tbAvnConsequenceDto);

    // Potential Consequesnce 상세
    TbAvnConsequenceDto selectConsequenceDetail(String consequenceId);

    // Potential Consequesnce 수정
    void updatePotentialConsequence(TbAvnConsequenceDto tbAvnConsequenceDto);

    // Potential Consequesnce 삭제
    void deletePotentialConsequence(String consequenceId);

    // Taxonomy 목록 조회
//    PageInfo<TbKeHazardLv1> selectTaxonomyList(TbKeHazardLv1 tbKeHazardLv1);
//    PageInfo<TbKeHazardLv2> selectTaxonomyList(TbKeHazardLv2 tbKeHazardLv2);
    PageInfo<TbAvnHazardLv3Dto> selectTaxonomyList(TbAvnHazardLv3Dto tbAvnHazardLv3Dto);

    // Taxonomy 신규 등록
    void insertTaxonomy(TbAvnHazardLv3Dto tbAvnHazardLv3Dto);

    // Taxonomy 상세
    TbAvnHazardLv3Dto selectTaxonomyDetail(String tbAvnHazardLv3Dto);

    // Taxonomy 수정
    void updateTaxonomy(TbAvnHazardLv3Dto tbAvnHazardLv3Dto);

    // Taxonomy 삭제
    void deleteTaxonomy(String tbAvnHazardLv3Dto);

    // EVENT TYPE 목록 조회
    PageInfo<TbAvnEventDto> selectEventTypeList(TbAvnEventDto tbAvnEventDto);

    // EVENT TYPE 신규 등록
    void insertEventType(TbAvnEventDto tbAvnEventDto);

    // EVENT TYPE 상세
    TbAvnEventDto selectEventTypeDetail(String tbAvnEventDto);

    // EVENT TYPE 수정
    void updateEventType(TbAvnEventDto tbAvnEventDto);

    // EVENT TYPE 삭제
    void deleteEventType(String tbAvnEventDto);
}
