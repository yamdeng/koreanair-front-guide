package com.koreanair.ksms.avn.srm.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class IvOccurrenceInformationDTO {
    private String eventAt;
    private String eventAtTz;
    private String classification;
    private int eventId;
    private String airport;
    private String flightPhase;
    private String weatherText;
    private String isSpi;
    private String spiFileGroupSeq;
    private String locationText;
}
