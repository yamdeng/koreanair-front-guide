package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.ReportInfoDto;
import com.koreanair.ksms.avn.srm.dto.RiskAssessmentDto;
import com.koreanair.ksms.avn.srm.dto.RiskAssessmentVo;
import com.koreanair.ksms.avn.srm.dto.SmsAuthDto;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnReportSecondAssessmentServiceImpl extends AbstractBaseService implements AvnReportSecondAssessmentService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    @Autowired
    AvnReportRiskAssessmentService avnReportRiskAssessmentService;

    @Override
    public RiskAssessmentVo selectReportSecondAssessment(ReportInfoDto.GET_Request dto) {

        int hazardId = dto.getP_hazardId();
        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        String empNo = userInfo.getEmpNo();
        Integer userId = Integer.parseInt(userInfo.getUserId());
        RiskAssessmentDto parameter = new RiskAssessmentDto().setHazardId(hazardId);
        parameter.setLscUserId(userId);

        RiskAssessmentVo detail = avnReportRiskAssessmentService.selectReportRiskAssessment(parameter, userInfo);
        int groupId = dto.getP_groupId();
        // lsc 담당자(리더) 여부를 체크하여 flag를 넣어줌
        SmsAuthDto authDto = new SmsAuthDto(userInfo)
                .setId(groupId)
                .setEmpNo(empNo);
        boolean leader = isLscLeader(authDto, false);
        detail.setLeader(leader);

        // STEP1.데이터를 가져온다
        return detail;
    }




    @Override
    public boolean isLscLeader(SmsAuthDto parameter,boolean checkAdmin) {
        if(checkAdmin) {
            if(this.isSystemAdmin(parameter)) return true;
        }
        parameter.setLscType("leader");
        String lscEmpNo=commonSql.selectOne("AvnReportRiskAssessment.selectIsLsc", parameter);
        return parameter.getEmpNo().equals(lscEmpNo);
    }

    @Override
    public boolean isLscMember(SmsAuthDto parameter,boolean checkAdmin) {
        if(checkAdmin) {
            if(this.isSystemAdmin(parameter)) return true;
        }
        parameter.setLscType("member");
        String lscEmpNo=commonSql.selectOne("AvnReportRiskAssessment.selectIsLsc", parameter);
        return parameter.getEmpNo().equals(lscEmpNo);
    }

    public boolean isSystemAdmin(SmsAuthDto parameter) {
        List<String> roleList = avnCommonService.selectRoleList();
        if (roleList.contains("SA")) {
            return true;
        } else {
            return false;
        }
    }
}
