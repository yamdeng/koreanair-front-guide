package com.koreanair.ksms.avn.srm.dto;

import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
public class HazardProcessDto {

    private Integer id;

    private String docNo;

    private String reportType;

    private String empNo;

    private String subject;

    private String timeZone;

    private Timestamp createdAt;

    private Timestamp updatedAt;

    private Timestamp deletedAt;

    private Integer hazardId;

    private String hazardNo;

    private int consequenceId;

    private String hazardEmpNo;

    private String riskLevel;

    private String isMitigation;

    private String hazardTimezone;

    private Timestamp hazardCreatedAt;

    private Timestamp hazardDeletedAt;

    private Integer hazardLogId;

    private String hazardPhase; // = "1st_risk";

    private String hazardState; // = "open";

    private String hazardStepCode; // = "draft";

    private String hazardApprovalEmpNo;

    private String hazardApprovalReason;

    private String hazardApprovalTimezone;

    private Timestamp hazardApprovalCreatedAt;

    public String getHazardNo() {
        return this.hazardNo;
    }

}
