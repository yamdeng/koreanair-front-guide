package com.koreanair.ksms.common.dto;

import lombok.Getter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@SuperBuilder
@ToString
public class AvnSearchCondition {
	private List<String> conditions;

	private String dateType;
	
	//private Date to;
	
	//private Date from;

	private String to;

	private String from;

	private String keyword;
	
	private Integer userId;
}
