package com.koreanair.ksms.avn.sftp.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnSafeConferenceDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnSafetyCommitteeServiceImpl extends AbstractBaseService implements AvnSafetyCommitteeService {

    //안전정책 > 안전회의체 목록 조회
    @Override
    public PageInfo<TbAvnSafeConferenceDto> selectCommitteeList(TbAvnSafeConferenceDto tbAvnSafeConferenceDto){
        List<TbAvnSafeConferenceDto> resultList = commonSql.selectList("AvnSafetyCommittee.selectCommitteeList", tbAvnSafeConferenceDto);
        return PageInfo.of(resultList);
    }

    //안전정책 > 안전회의체 회의구분별 count 조회
    @Override
    public List<TbAvnSafeConferenceDto> selectCommitteeGroupCount(TbAvnSafeConferenceDto tbAvnSafeConferenceDto){
        List<TbAvnSafeConferenceDto> resultCountList = commonSql.selectList("AvnSafetyCommittee.selectCommitteeGroupCount", tbAvnSafeConferenceDto);
        return resultCountList;
    }

    //안전정책 > 안전회의체 신규
    @Override
    public void insertCommittee(TbAvnSafeConferenceDto tbAvnSafeConferenceDto){
        //날짜 "-" 제거
        String newDateText = tbAvnSafeConferenceDto.getConferenceDt().replace("-","");
        tbAvnSafeConferenceDto.setConferenceDt(newDateText);

        commonSql.insert("AvnSafetyCommittee.insertCommittee", tbAvnSafeConferenceDto);
    }

    //안전정책 > 안전회의체 상세 조회
    @Override
    public TbAvnSafeConferenceDto selectCommitteeInfo(int safeConferenceId){
        return commonSql.selectOne("AvnSafetyCommittee.selectCommitteeInfo", safeConferenceId);
    }

    //안전정책 > 안전회의체 수정
    @Override
    public void updateCommittee(TbAvnSafeConferenceDto tbAvnSafeConferenceDto){
        //날짜 "-" 제거
        String newDateText = tbAvnSafeConferenceDto.getConferenceDt().replace("-","");
        tbAvnSafeConferenceDto.setConferenceDt(newDateText);

        commonSql.update("AvnSafetyCommittee.updateCommittee",tbAvnSafeConferenceDto);
    }

    //안전정책 > 안전회의체 삭제
    @Override
    public void deleteCommittee(String safeConferenceId){
        commonSql.delete("AvnSafetyCommittee.deleteCommittee", safeConferenceId);
    }

}
