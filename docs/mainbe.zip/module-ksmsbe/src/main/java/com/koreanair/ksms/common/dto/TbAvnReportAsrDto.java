package com.koreanair.ksms.common.dto;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트_ASR")
public class TbAvnReportAsrDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "레포트상세유형코드 : CODE_GRP_155")
    private String reportDtlTypeCd;
    private String reportDtlTypeKor;
    private String reportDtlTypeEng;
    
    @Schema(description = "발생통로명")
    private String runwayNm;
    
    @Schema(description = "비행단계코드 : CODE_GRP_002")
    private String flightPhaseCd;
    private String flightPhaseKor;
    private String flightPhaseEng;
    
    @Schema(description = "고도수")
    private int altitudeCo;
    
    @Schema(description = "고도단위코드 : CODE_GRP_004")
    private String altitudeUnitCd;
    private String altitudeUnitKor;
    private String altitudeUnitEng;
    
    @Schema(description = "속도수")
    private int speedCo;
    
    @Schema(description = "속도단위코드 : CODE_GRP_003")
    private String speedUnitCd;
    private String speedUnitKor;
    private String speedUnitEng;
    
    @Schema(description = "MET코드 : CODE_GRP_005")
    private String metCd;
    private String metKor;
    private String metEng;
    
    @Schema(description = "바람1수")
    private int windOneCo;
    
    @Schema(description = "바람2수")
    private int windTwoCo;
    
    @Schema(description = "돌풍수")
    private int gustCo;
    
    @Schema(description = "시정명")
    private String visibilityNm;
    
    @Schema(description = "구름코드 : CODE_GRP_007")
    private String cloudCd;
    private String cloudKor;
    private String cloudEng;
    
    @Schema(description = "고도계수")
    private int altimeterCo;
    
    @Schema(description = "고도계단위코드 : CODE_GRP_006")
    private String altimeterUnitCd;
    private String altimeterUnitKor;
    private String altimeterUnitEng;
    
    @Schema(description = "온도수")
    private int tempCo;
    
    @Schema(description = "날씨코드배열 : CODE_GRP_008")
    private String weatherCdarr;
    private List<TbSysCodeDto> weatherCdList;
    
    @Schema(description = "새유형명")
    private String birdTypeNm;
    
    @Schema(description = "새크기코드 : CODE_GRP_093")
    private String birdSizeCd;
    private String birdSizeKor;
    private String birdSizeEng;
    
    @Schema(description = "새수코드 : CODE_GRP_094")
    private String birdCoCd;
    private String birdCoKor;
    private String birdCoEng;
    
    @Schema(description = "부딫친새수코드 : CODE_GRP_094")
    private String struckBirdCoCd;
    private String struckBirdCoKor;
    private String struckBirdCoEng;
    
    @Schema(description = "시간유형코드 : CODE_GRP_095")
    private String timeTypeCd;
    private String timeTypeKor;
    private String timeTypeEng;
    
    @Schema(description = "착륙점등여부")
    @NotBlank
    private String landingLightYn;
    
    @Schema(description = "파일럿경고여부")
    @NotBlank
    private String pilotWarnedYn;
    
    @Schema(description = "충돌시점명")
    private String impactTimeNm;
    
    @Schema(description = "새설명내용")
    private String birdDescriptionCn;
}
