package com.koreanair.ksms.avn.admin.controller;

import com.koreanair.ksms.avn.admin.service.AvnEspManageService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 - ESP관리
 */
@Tag(name = "AvnEspManage", description = "관리자 - ESP관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnEspManageController {

    @Autowired
    AvnEspManageService service;

    /**
     * ESP관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "ESP관리 목록 조회", description = "ESP관리 목록 조회 API")
    @GetMapping(value = "/admin/esps")
    public ResponseEntity<?> getEspManageList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "ESP관리 상세정보 조회", description = "ESP관리 상세정보 조회 API")
    @GetMapping(value = "/admin/esps/{espId}")
    public ResponseEntity<?> getEspManageInfo(@PathVariable(value="espId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 ESP관리 등록", description = "신규 ESP관리 등록 API")
    @PostMapping(value = "/admin/esps")
    public ResponseEntity<?> insertEspManage(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "ESP관리 정보 수정", description = "ESP관리 정보 수정 API")
    @PutMapping(value = "/admin/esps/{espId}")
    public ResponseEntity<?> updateEspManage(
            @PathVariable(value="espId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "ESP관리 삭제", description = "ESP관리 삭제 API")
    @DeleteMapping(value = "/admin/esps/{espId}")
    public ResponseEntity<?> deleteEspManage(@PathVariable(value="espId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
