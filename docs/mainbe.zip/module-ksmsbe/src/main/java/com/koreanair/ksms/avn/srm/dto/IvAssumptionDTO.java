package com.koreanair.ksms.avn.srm.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class IvAssumptionDTO {
    private int hazardId;
    private String hazardType;
    private int consequenceId;
    private String hazardName;
    private String consequenceName;
}
