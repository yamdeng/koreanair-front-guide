package com.koreanair.ksms.avn.srm.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.avn.srm.service.*;
import com.koreanair.ksms.common.aspect.annotations.EnableAuth;
import com.koreanair.ksms.common.constants.AvnStatusCode;
import com.koreanair.ksms.common.constants.AvnStatusCode.Phase;
import com.koreanair.ksms.common.constants.AvnStatusCode.Step;
import com.koreanair.ksms.common.constants.AvnStatusCode.StepType;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import com.koreanair.ksms.common.utils.DateUtil;
import com.koreanair.ksms.common.utils.KeUtils;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.micrometer.common.util.StringUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 안전위험관리 - 보고서분석
 */
@Tag(name = "AvnReportAnalysis", description = "안전위험관리 - 보고서분석 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnReportAnalysisController {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnReportAnalysisService serviceAnalysis;

    @Autowired
    AvnReportReceiptService serviceReceipt;

    @Autowired
    AvnReportProcessService avnReportProcessService;

    @Autowired
    AvnReportSysNotiService avnReportSysNotiService;

    @Autowired
    AvnCommonService avnCommonService;

    @Autowired
    AvnAsrReportService asrReportService;

    @Autowired
    AvnReportRiskAssessmentService avnReportRiskAssessmentService;

    @Autowired
    AvnReportFirstAssessmentService avnReportFirstAssessmentService;

    @Autowired
    AvnReportMitigationService avnReportMitigationService;

    //todo khw. 수정 필요
    //@Value("${site.user.url}")
    private String siteUrl;

    /**
     * 보고서 분석 목록 조회
     *
     * @param ReportViewlistDto.GET_Request
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "보고서 분석 - 목록 조회", description = "보고서 분석 목록 조회 API")
    @GetMapping(value = "/srm/analysis")
    public ResponseEntity<?> getAnalysisList(
            @Valid ReportViewlistDto.GET_Request dto
    ) {
        String startDate = dto.getP_startDate();
        String endDate = dto.getP_endDate();
        dto.setS_startDate(startDate);
        dto.setS_endDate(endDate);

        if (dto.getP_workType() == null || dto.getP_workType().isEmpty()) {
            dto.setP_workType("avn");
        } else {
            if (!"ocu".equals(dto.getP_workType())) {
                throw new CustomBusinessException("보고서 조회가 실패하였습니다.");
            }
        }
        java.sql.Date p_startDate = java.sql.Date.valueOf(startDate);
        java.sql.Date p_endDate = java.sql.Date.valueOf(endDate);

        if (KeUtils.validatePeriodByYear(p_startDate, p_endDate, 5)) {
            serviceAnalysis.getAuthSetting(dto);
            PageHelper.startPage(dto.getPageNum(), dto.getPageSize());
            //보고접수 and 1차위험도평가
            PageInfo<ReportViewlistVo> pageList = serviceAnalysis.getAnalysisList(dto);
            ReportViewlistDto.GET_Response reult = new ReportViewlistDto.GET_Response(pageList);
            return ResponseUtil.createSuccessResponse(reult);
        }
        throw new CustomBusinessException("보고서 조회가 실패하였습니다.");
    }

    /**
     * 보고서 분석 - (리스트)보고서 묶기(Group) 처리
     *
     * @param List<Map<String, Object>> : reportType, groupId 예)[{"reportType":"asr", "groupId":"115501"}, {"reportType":"asr", "groupId":"115502"}]
     * @return
     * @throws CustomBusinessException the exception
     */
    @Operation(summary = "보고서 분석 - (리스트)보고서 묶기(Group) Insert 처리", description = "(리스트)보고서 분석 보고서 묶기(Group) Insert 처리 API")
    @PostMapping(value = "/srm/analysis/group")
    @EnableAuth(role = { "SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG" })
    public ResponseEntity<?> insertGroupList(
            @Valid @RequestBody(required=true) List<Map<String, Object>> groupList
    )
    {
        List<Integer> groupReportList = new ArrayList<>();
        //groupReportList : reportType, groupId
        String tmpReportType = "";
        String tmpAnonyYn = "N";
        for (Map<String, Object> param : groupList) {
            //보고서 리스트 중 이미 묶여있는 보고서 체크 && 보고서 상태 체크(접수대기인지)
            int groupId = Integer.parseInt(param.get("groupId").toString());
            boolean isChked = avnReportProcessService.getIsValidateGroupReport(groupId);
            if (!isChked) {
                throw new CustomBusinessException("보고서 묶음 처리가 실패하였습니다.(상태확인)");
            }

            //보고서 묶임 체크
            List<String> reportList = avnReportProcessService.getIsValidateCountGroupReport(groupId);
            if (reportList.size() != 1) {
                throw new CustomBusinessException("보고서 묶음 처리가 실패하였습니다.(중복묶음)");
            }
            int reportId = Integer.valueOf(String.valueOf(reportList.get(0)));

            groupReportList.add(groupId);

            //첫번째 보고서의 보고서종류 저장
            if (groupList.indexOf(param) == 0) {
                tmpReportType = param.get("reportType").toString();

                //hazard 보고서인 경우 : 익명여부(Y) 체크 필요
                if ("hzr".equals(param.get("reportType").toString())) {
                    tmpAnonyYn = avnReportRiskAssessmentService.selectHzrConfidential(reportId);
                }
                continue;
            }

            if (!tmpReportType.equals(param.get("reportType").toString())) {
                throw new CustomBusinessException("보고서 묶음 처리가 실패하였습니다.(보고서종류확인)");
            }

            if ("hzr".equals(param.get("reportType").toString())) {
                String tmpNewAnonyYn = avnReportRiskAssessmentService.selectHzrConfidential(reportId);
                if (!tmpAnonyYn.equals(tmpNewAnonyYn)) {
                    throw new CustomBusinessException("보고서 묶음 처리가 실패하였습니다.(익명여부확인)");
                }
            }

        }
        //보고서 묶음 처리
        avnReportProcessService.insertMergeGroupReport(groupReportList);
        return ResponseUtil.createSuccessResponse(groupReportList);
    }

    /**
     * 보고서 분석(상세 - 접수대기) - 보고서 묶기(Group) 처리
     * @param Integer groupId : group Id
     * @param List<Map<String, Object>> : reportType, groupId 예)[{"reportType":"asr", "groupId":"115501"}, {"reportType":"asr", "groupId":"115502"}]
     * @return
     * @throws CustomBusinessException the exception
     */
    @Operation(summary = "보고서 분석 - (접수)보고서 묶기(Group) Update 처리", description = "(접수)보고서 분석 보고서 묶기(Group) Update 처리 API")
    @PutMapping(value = "/srm/analysis/group")
    //@EnableAuth(role = { "SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG" })
    public ResponseEntity<?> updateGroupList(
              @RequestParam(required = true) Integer groupId
            , @Valid @RequestBody(required=true) List<Map<String, Object>> groupList
    )
    {
        SmReport report = serviceReceipt.selectReportDetail(groupId);
        List<Integer> groupReportList = new ArrayList<>();
        //groupReportList : reportType, groupId
        String tmpReportType = report.getReportType();
        String tmpAnonyYn = "N";
        //hazard 보고서인 경우 : 익명여부(Y) 체크 필요
        if ("hzr".equals(tmpReportType)) {
            tmpAnonyYn = avnReportRiskAssessmentService.selectHzrConfidential(report.getReportId());
        }

        for (Map<String, Object> param : groupList) {
            //보고서 리스트 중 이미 묶여있는 보고서 체크 && 보고서 상태 체크(접수대기인지)
            int tempGroupId = Integer.valueOf(String.valueOf(param.get("groupId")));
            boolean isChked = avnReportProcessService.getIsValidateGroupReport(tempGroupId);
            if (!isChked) {
                throw new CustomBusinessException("보고서 묶음 처리가 실패하였습니다.(상태확인)");
            }

            //보고서 묶임 체크
            List<String> reportList = avnReportProcessService.getIsValidateCountGroupReport(tempGroupId);
            if (reportList.size() != 1) {
                throw new CustomBusinessException("보고서 묶음 처리가 실패하였습니다.(중복묶음)");
            }
            int reportId = Integer.valueOf(String.valueOf(reportList.get(0)));

            groupReportList.add(tempGroupId);

            if (!tmpReportType.equals(param.get("reportType").toString())) {
                throw new CustomBusinessException("보고서 묶음 처리가 실패하였습니다.(보고서종류확인)");
            }
            if ("hzr".equals(param.get("reportType").toString())) {
                String tmpNewAnonyYn = avnReportRiskAssessmentService.selectHzrConfidential(reportId);
                if (!tmpAnonyYn.equals(tmpNewAnonyYn)) {
                    throw new CustomBusinessException("보고서 묶음 처리가 실패하였습니다.(익명여부확인)");
                }
            }
        }
        //보고서 묶음 처리
        avnReportProcessService.updateMergeGroupReport(groupId, groupReportList);
        return ResponseUtil.createSuccessResponse(groupReportList);
    }

    /**
     * 보고서 분석(상세 - 접수대기) - 보고서 묶기(Group) 삭제
     * @param Integer orgGroupId : group Id
     * @param List<Map<String, Object>> : reportType, groupId 예)[{"reportType":"asr", "groupId":"115501"}, {"reportType":"asr", "groupId":"115502"}]
     * @return
     * @throws CustomBusinessException the exception
     */
    @Operation(summary = "보고서 분석 - (접수)보고서 묶기(Group) Delete 처리", description = "(접수)보고서 분석 보고서 묶기(Group) Delete 처리 API")
    @DeleteMapping(value = "/srm/analysis/group")
    //@EnableAuth(role = { "SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG" })
    public ResponseEntity<?> updateGroupList(
              @RequestParam(required = true) Integer groupId
            , @RequestParam(required = true) Integer reportId
    )
    {
        SmReport report = serviceReceipt.selectReportDetail(groupId);
        List<Integer> groupReportList = new ArrayList<>();
        //groupReportList : reportType, groupId
        String tmpReportType = report.getReportType();

        //묶음 보고서 건수가 1건인 경우
        List<String> reportList = avnReportProcessService.getIsValidateCountGroupReport(groupId);
        if (reportList.isEmpty() || reportList.size() == 1) {
            throw new CustomBusinessException("보고서 묶음 삭제 처리가 실패하였습니다.(묶음 보고서 확인)");
        }

        //묶음 보고서에 없는 건인 경우
        if (!reportList.contains(Integer.valueOf(reportId))) {
            throw new CustomBusinessException("보고서 묶음 삭제 처리가 실패하였습니다.(묶음 보고서 확인)");
        }
        //보고서 묶음 삭제 처리
        try {
            avnReportProcessService.deleteMergeGroupReport(groupId, reportId);
            return ResponseUtil.createSuccessResponse(groupReportList);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    /**
     * 보고서 분석 - 전체 상세정보 조회 : 접수 ~ 1차위험평가(LSC)
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "보고서 분석 - 전체 상세정보 조회 : 접수 ~ 1차위험평가(LSC)", description = "보고서 분석 전체 상세정보 조회 API : 접수 ~ 1차위험평가(LSC)")
    @GetMapping(value = "/srm/analysis/{step}/{groupId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG"})
    public ResponseEntity<?> getAnalysisWithOutHazardInfo(
              @PathVariable(value="step", required=true) int step
            , @PathVariable(value="groupId", required=true) Integer groupId
    )
    {
        ReportInfoDto.GET_Request dto = new ReportInfoDto.GET_Request();
        dto.setP_step(step);
        dto.setP_groupId(groupId);
        ReportInfoVo resultInfo = serviceAnalysis.getAnalysisInfo(dto);

        ReportStateInfoVo reportStateInfo = avnReportProcessService.selectReportStateSetting(dto);
        resultInfo.setReportStateInfo(reportStateInfo);

        if (step == 1 || step == 5) {
        } else {
            step = reportStateInfo.getReportStateList().get(0).getCurrstep();
        }
        resultInfo.setStep(step);
        return ResponseUtil.createSuccessResponse(resultInfo);
    }

    /**
     * 보고서 분석 - 전체 상세정보 조회 : 1차위험평가(SRC) ~ 종결
     *
     * @param groupId the group id
     * @param id the id(Hazard list id)
     * @param stateType the step(9단계)
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "보고서 분석 - 전체 상세정보 조회 : 1차위험평가(SRC) ~ 종결", description = "보고서 분석 전체 상세정보 조회 API : 1차위험평가(SRC) ~ 종결")
    @GetMapping(value = "/srm/analysis/{step}/{groupId}/{hazardId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG","MIT"})
    public ResponseEntity<?> getAnalysisWithHazardInfo(
              @PathVariable(value="step", required=true) Integer step
            , @PathVariable(value="groupId", required=true) Integer groupId
            , @PathVariable(value="hazardId", required=true) Integer hazardId
        )
    {
        ReportInfoDto.GET_Request dto = new ReportInfoDto.GET_Request();
        dto.setP_groupId(groupId);
        dto.setP_hazardId(hazardId);
        dto.setP_step(step);
        ReportInfoVo resultInfo = serviceAnalysis.getAnalysisInfo(dto);

        ReportStateInfoVo reportStateInfo = avnReportProcessService.selectReportStateSetting(dto);
        resultInfo.setReportStateInfo(reportStateInfo);

        if (step == 1 || step == 5) {
        } else {
            step = reportStateInfo.getReportStateList().get(0).getCurrstep();
        }
        resultInfo.setStep(step);
        return ResponseUtil.createSuccessResponse(resultInfo);
    }

    @Operation(summary = "보고서 분석 - 접수 Insert", description = "보고서 분석 - 접수 Insert API")
    @PostMapping(value = "/srm/analysis/{groupId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG"})
    public ResponseEntity<?> insertReceiptInfo(@Valid @RequestBody(required=true) ReceiptVo receiptVo
                                             , @RequestParam(required = true) boolean submit
    ) {
        try {

            // 보고서 정보를 가져오기위해 report 정보를 select 한다.
            ReceiptVo vo = receiptVo;

            // 보고서 empNo, smReport 세팅 및 reportId리턴
            // 보고서가 현재 처리가 가능한 step인지 확인한다.
            int groupId = this.preProcessing(vo, true);

            // STEP 2 Insert Data
            vo.setTimezone("Asia/Seoul");
            serviceReceipt.insertReceiptDetail(vo);
            int receiptId = vo.getId();
            vo.setId(receiptId);

            // STEP 3. update status
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            if (submit) {
                ReportProcessVo proccessVo = new ReportProcessVo(vo.getGroupId(), vo.getReportId(), empNo, StepType.APPROVE);
                boolean success = avnReportProcessService.smsReportProcess(proccessVo);
                if (success) {
                    // STEP 4. 성공한 경우 Receipt at 정보를 update 시킨다.
                    serviceReceipt.updateReceiptAt(receiptId);
                    
                    //todo khw. msr인 경우 이메일 발송 처리
                }
            } else {
                ReportProcessVo proccessVo = new ReportProcessVo(vo.getGroupId(), vo.getReportId(), empNo, StepType.SAVE);
                avnReportProcessService.smsReportProcess(proccessVo);
            }
            return ResponseUtil.createSuccessResponse(vo);

        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 접수 Update", description = "보고서 분석 - 접수 Update API")
    @PutMapping(value = "/srm/analysis/{groupId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG"})
    public ResponseEntity<?> updateReceiptInfo(
              @Valid @RequestBody(required=true) ReceiptVo receiptVo
            , @RequestParam(required = true) boolean submit
    ) {
        try {

            // 보고서 정보를 가져오기위해 report 정보를 select 한다.
            ReceiptVo vo = receiptVo;

            // 보고서 empNo, smReport 세팅 및 reportId리턴
            // 보고서가 현재 처리가 가능한 step인지 확인한다.
            int groupId = this.preProcessing(vo, true);

            // STEP 2 Insert Data
            vo.setTimezone("Asia/Seoul");
            serviceReceipt.updateReceiptDetail(vo);

            // STEP 3. update status
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            if (submit) {
                ReportProcessVo proccessVo = new ReportProcessVo(vo.getGroupId(), vo.getReportId(), empNo, StepType.APPROVE);
                boolean success = avnReportProcessService.smsReportProcess(proccessVo);
                if (success) {
                    // STEP 4. 성공한 경우 Receipt at 정보를 update 시킨다.
                    int receiptId = vo.getId();
                    serviceReceipt.updateReceiptAt(receiptId);
                }
            } else {
                ReportProcessVo proccessVo = new ReportProcessVo(vo.getGroupId(), vo.getReportId(), empNo, StepType.SAVE);
                avnReportProcessService.smsReportProcess(proccessVo);
            }
            return ResponseUtil.createSuccessResponse(vo);

        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    /**
     * 보고서 분석 - 접수 반려
     *
     * @param VO 예) {"reportId": "115515","reason": "무엇일까요?"}
     * @return
     * @throws Exception the exception
     */
    @Operation(summary = "보고서 분석 - 접수 반려", description = "보고서 분석 - 접수 반려 API")
    @DeleteMapping(value = "/srm/analysis/{groupId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG"})
    public ResponseEntity<?> rejectReceiptInfo(
            @Valid @RequestBody ReceiptDto.DELETE_Request parameter, @Valid @PathVariable int groupId
    )
    {
        try {
            //여러개 묶여 있는 보고서는 반려 불가하도록 함
            List<String> reportList = avnReportProcessService.getIsValidateCountGroupReport(groupId);
            if (reportList.size() != 1) {
                throw new CustomBusinessException("처리가 실패하였습니다.(다중 묶음 보고서)");
            }

            // TODO method put으로통합 delete는 데이터 삭제에 가까움
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            String reason = parameter.getReason();
            ReportProcessVo proccessVo = new ReportProcessVo(groupId, parameter.getReportId(), empNo, StepType.REJECT);
            proccessVo.setReason(reason);
            avnReportProcessService.smsReportProcess(proccessVo);

            /*
            ReceiptDto.DELETE_Response data = new ReceiptDto.DELETE_Response();
            GetResponseDetail<ReceiptDto.DELETE_Response> response = new GetResponseDetail<ReceiptDto.DELETE_Response>();
            response.setData(data);

            return ResponseEntity.ok(response);
            */

            return ResponseUtil.createSuccessResponse();
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 1차위험평가(lsc) Insert", description = "보고서 분석 - 1차위험평가(lsc) Insert API")
    @PostMapping(value = "/srm/analysis/first/risk-assessment/{groupId}")
    //@EnableAuth(role = {"LSC"})
    public ResponseEntity<?> insertFirstRiskAssessment(
              @Valid @RequestBody(required=true) RiskAssessmentVo parameter
            , @RequestParam(required = true) boolean submit
    ) {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            parameter.setEmpNo(empNo);
            parameter.setTimeZone("Asia/Seoul");

            // validate hazardList가 없는상태로올경우 error리턴
            RiskAssessmentVo detail = parameter;
            detail.setIsOcuClose("N");
            //Hazard 리포트인 경우..
            if ("hzr".equals(detail.getReportType())) {
                if ("N".equals(detail.getIsAvnHzd()) && "N".equals(detail.getIsOcuHzd())){
                    throw new CustomBusinessException("항공안전여부,산업안전여부는 필수입니다.");
                }

                if ("Y".equals(detail.getIsAvnHzd())) {
                    if(detail.getReportHazardList().size()==0) {
                        throw new CustomBusinessException("hazardList는 필수입니다.");
                    }
                    if ("Y".equals(detail.getIsOcuHzd())) {
                        if(detail.getReportHazardOcuList().size()==0) {
                            throw new CustomBusinessException("산업안전 hazardList는 필수입니다.");
                        }
                    }
                } else {
                    //산업안전만 체크했을 경우.. 마감 처리 필요..
                    detail.setIsOcuClose("Y");
                }
            } else {
                if(detail.getReportHazardList().size()==0) {
                    throw new CustomBusinessException("hazardList는 필수입니다.");
                }
            }


            // 1. UPDATE REPORT assessmnet info (is Statistics/note)
            avnReportRiskAssessmentService.updateReportAssessment(detail);

            // 2-1. UPDATE REPORT_HAZARD(항공)
            int groupId = detail.getGroupId();
            ArrayList<SmReportHazardVo> reportHazardList = avnReportRiskAssessmentService.insertFirstReportHazard(detail);

            // 2-2. UPDATE REPORT_HAZARD(산업)
            ArrayList<SmReportHazardVo> reportHazardOcuList = avnReportRiskAssessmentService.updateFirstReportHazardOcu(detail);
            detail.setReportHazardOcuList(reportHazardOcuList);

            // 3. PROCCESS REPORT_HAZARD
            detail.setReportHazardList(reportHazardList);
            if(submit || "Y".equals(parameter.getIsLscClose())) {
                //4. submit시 leader or 관리자 여부를 체크
                SmsAuthDto authDto = new SmsAuthDto(userInfo).setId(groupId).setEmpNo(empNo);
                boolean leader = avnReportRiskAssessmentService.isLscLeader(authDto, false);
                if (!(leader)) {
                    throw new CustomBusinessException("System Error");
                }
            }
                
            for(SmReportHazardVo hazardVo : reportHazardList) {
                int hazardId=hazardVo.getId();
                if(submit) {
                    if ("Y".equals(parameter.getIsOcuClose())) {
                        ReportProcessVo processVo = new ReportProcessVo(detail.getGroupId(), detail.getReportId(), empNo, StepType.APPROVE);
                        processVo.setHazardId(hazardId);
                        processVo.setIsCloseType("OCU");
                        processVo.setTimezone("Asia/Seoul");
                        avnReportProcessService.smsHazardProcessExpt(processVo);
                    } else {
                        ReportProcessVo processVo = new ReportProcessVo(detail.getGroupId(), detail.getReportId(),empNo,StepType.SUBMIT);
                        processVo.setHazardId(hazardId);
                        processVo.setTimezone("Asia/Seoul");
                        avnReportProcessService.smsHazardProcess(processVo);
                    }
                } else {
                    //LSC종결인 경우 처리 : APPROVE 처리 || 저장인 경우 : SAVE 처리
                    if ("Y".equals(parameter.getIsLscClose())) {
                        ReportProcessVo processVo = new ReportProcessVo(detail.getGroupId(), detail.getReportId(), empNo, StepType.APPROVE);
                        processVo.setHazardId(hazardId);
                        processVo.setIsCloseType("LSC");
                        processVo.setTimezone("Asia/Seoul");
                        avnReportProcessService.smsHazardProcessExpt(processVo);
                    } else {
                        ReportProcessVo processVo = new ReportProcessVo(detail.getGroupId(), detail.getReportId(), empNo, StepType.SAVE);
                        processVo.setHazardId(hazardId);
                        processVo.setTimezone("Asia/Seoul");
                        avnReportProcessService.smsHazardProcess(processVo);
                    }
                }
            }

            // (추가처리) - FOCA-X인 경우
            if(submit) {
                if ("foqa".equals(parameter.getReportType())) {
                   //todo khw. foqa x인 경우 조건
                   if (1==2) {
                       avnReportRiskAssessmentService.insertFoqaxComments(parameter);
                   }
                }
            }
            return ResponseUtil.createSuccessResponse(detail);

        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 1차위험평가(lsc) Update(XXXXXXX   사용안하는듯함..XXXXX)", description = "보고서 분석 - 1차위험평가(lsc) Update API")
    @PutMapping(value = "/srm/analysis/first/risk-assessment/{groupId}")
    @EnableAuth(role = {"LSC"})
    ResponseEntity<?> updateFirstRiskAssessment(
              @Valid @RequestBody(required=true) RiskAssessmentVo parameter
            , @RequestParam(required = true) boolean submit)
    {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            parameter.setEmpNo(empNo);
            parameter.setTimeZone("Asia/Seoul");

            RiskAssessmentVo detail=parameter;
            // 1. UPDATE REPORT assessmnet info (is Statistics/note)
            avnReportRiskAssessmentService.updateReportAssessment(detail);

            int groupId = detail.getGroupId();

            // 2-1. UPDATE REPORT_HAZARD
            ArrayList<SmReportHazardVo> reportHazardList=avnReportRiskAssessmentService.updateFirstReportHazard(parameter);

            // 2-2. UPDATE REPORT_HAZARD(산업)
            ArrayList<SmReportHazardVo> reportHazardOcuList = avnReportRiskAssessmentService.updateFirstReportHazardOcu(detail);
            detail.setReportHazardOcuList(reportHazardOcuList);

            //todo khw delete list ???? 확인 필요
            // 3. DELETE LIST 처리(parameter로 넘어온 삭제될 목록)
            Optional<List<SmReportHazardVo>> optional = Optional.ofNullable(detail.getDeleteList());
            ArrayList<SmReportHazardVo> deleteList =
                    new ArrayList<SmReportHazardVo>(optional.orElse(new ArrayList<SmReportHazardVo>()));

            if(submit) {
                //4. submit시 leader or 관리자 여부를 체크
                SmsAuthDto authDto = new SmsAuthDto(userInfo).setId(groupId).setEmpNo(empNo);
                boolean leader = avnReportRiskAssessmentService.isLscLeader(authDto, false);
                if (!(leader)) {
                    throw new CustomBusinessException("System Error");
                }
            }
            for(SmReportHazardVo hazardVo : deleteList) {
                if(submit) {
                    int hazardId=hazardVo.getId();
                    ReportProcessVo processVo = new ReportProcessVo(detail.getGroupId(), detail.getReportId(),empNo,StepType.DELETE).setHazardId(hazardId);
                    processVo.setTimezone("Asia/Seoul");
                    // proccess에 log를 남긴다.
                    avnReportProcessService.smsHazardProcess(processVo);
                }
            }

            for(SmReportHazardVo hazardVo : reportHazardList) {
                int hazardId=hazardVo.getId();
                if(submit) {
                    // Validation 제출은 LSC 리더만 가능함;
                    ReportProcessVo processVo = new ReportProcessVo(detail.getGroupId(), detail.getReportId(), empNo, StepType.SUBMIT).setHazardId(hazardId);
                    processVo.setTimezone("Asia/Seoul");
                    avnReportProcessService.smsHazardProcess(processVo);
                }else {
                    //LSC종결인 경우 처리 : APPROVE 처리 || 저장인 경우 : SAVE 처리
                    ReportProcessVo processVo = new ReportProcessVo(detail.getGroupId(), detail.getReportId(), empNo, "Y".equals(detail.getIsLscClose())?StepType.APPROVE:StepType.SAVE);
                    processVo.setTimezone("Asia/Seoul");
                    avnReportProcessService.smsHazardProcess(processVo);
                }
            }

            // (추가처리) - FOCA-X인 경우
            if(submit) {
                if ("foqa".equals(parameter.getReportType())) {
                    //todo khw. foqa x인 경우 조건
                    if (1==2) {
                        avnReportRiskAssessmentService.insertFoqaxComments(parameter);
                    }
                }
            }

            return ResponseUtil.createSuccessResponse(detail);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }

    }

    @Operation(summary = "보고서 분석 - 1차위험평가(lsc) delete", description = "보고서 분석 - 1차위험평가(lsc) delete API")
    @DeleteMapping(value = "/srm/analysis/first/risk-assessment/{hazardId}")
    @EnableAuth(role = {"LSC"})
    ResponseEntity<?> deleteFirstRiskAssessment (
              @Valid @PathVariable int hazardId
            , @RequestParam(required = true) Integer groupId
            , @RequestParam(required = true) String workScopeCd
    )
    {
        try {
            ReceiptDto.DELETE_Request_Hazard parameter = new ReceiptDto.DELETE_Request_Hazard();
            parameter.setId(hazardId);
            parameter.setGroupId(groupId);
            //항공 Hazard인 경우
            if ("A".equals(workScopeCd)) {
                int cnt=avnReportRiskAssessmentService.deleteReportHazard(parameter);
            } else if ("O".equals(workScopeCd)) {
                int cnt=avnReportRiskAssessmentService.deleteReportHazardOcu(parameter);
            } else {
                throw new CustomBusinessException("System Error");
            }
            return ResponseUtil.createSuccessResponse();
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }

    }

    @Operation(summary = "보고서 분석 - 1차위험평가(lsc) Comment 조회", description = "보고서 분석 - 1차위험평가(lsc) Comment 조회 API")
    @GetMapping(value = "/srm/analysis/risk-assessment/comment")
    @EnableAuth(role = {"LSC"})
    ResponseEntity<?> selectCommentList(
            @ModelAttribute RiskAssessmentCommentDto parameter) {
        try {
            List<SmCommentVo> list = avnReportRiskAssessmentService.selectSmCommentList(parameter);
            return ResponseUtil.createSuccessResponse(list);
        } catch (NullPointerException e) {
            throw new CustomBusinessException("data notfound");
        }

    }


    @Operation(summary = "보고서 분석 - 1차위험평가(lsc) Comment Insert", description = "보고서 분석 - 1차위험평가(lsc) Comment Insert API")
    @PostMapping(value = "/srm/analysis/risk-assessment/comment")
    @EnableAuth(role = {"LSC"})
    ResponseEntity<?> createCommentList(
            @Valid @RequestBody RiskAssessmentCommentDto parameter
    ) {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            parameter.setEmpNo(empNo);
            parameter.setTimezone("Asia/Seoul");

            avnReportRiskAssessmentService.insertSmComment(parameter);
            return ResponseUtil.createSuccessResponse(parameter);
        } catch (NullPointerException e) {
            throw new CustomBusinessException("data notfound");
        } catch(Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 1차위험평가(lsc) Comment update", description = "보고서 분석 - 1차위험평가(lsc) Comment update API")
    @PutMapping("/srm/analysis/risk-assessment/comment/{id}")
    @EnableAuth(role = {"LSC"})
    ResponseEntity<?> updateCommentList(
            @RequestBody RiskAssessmentCommentDto parameter,
            @PathVariable(required = true) Integer id) {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            parameter.setEmpNo(empNo);
            parameter.setId(id);

            avnReportRiskAssessmentService.updateSmComment(parameter);
            return ResponseUtil.createSuccessResponse(parameter);
        } catch (NullPointerException e) {
            throw new CustomBusinessException("data notfound");
        } catch(Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 1차위험평가(lsc) Comment delete", description = "보고서 분석 - 1차위험평가(lsc) Comment delete API")
    @DeleteMapping("/srm/analysis/risk-assessment/comment/{id}")
    @EnableAuth(role = {"LSC"})
    ResponseEntity<?> deleteCommentList(
            @ModelAttribute RiskAssessmentCommentDto parameter,
            @PathVariable(required = true) Integer id) {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            parameter.setEmpNo(empNo);
            parameter.setId(id);

            avnReportRiskAssessmentService.deleteSmComment(parameter);
            return ResponseUtil.createSuccessResponse(parameter);
        } catch (NullPointerException e) {
            throw new CustomBusinessException("data notfound");
        } catch(Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 1차위험평가(src) insert", description = "보고서 분석 - 1차위험평가(src) insert API")
    @PostMapping("/srm/analysis/ssc-review/{hazardId}")
    //@EnableAuth(role= {"SSC"})
    ResponseEntity<?> getFirstRiskAssessment(
              @PathVariable(required = true) Integer hazardId
            , @RequestBody @Valid SSCReveiwDto.POST_Request parameter) {
        try {
            int groupId=parameter.getGroupId();
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            String approvalType=parameter.getApprovalType();
            ReportProcessVo vo =new ReportProcessVo()
                    .setEmpNo(empNo)
                    .setGroupId(groupId)
                    .setHazardId(hazardId)
                    .setTimezone("Asia/Seoul");
            if(StepType.APPROVE.getCode().equals(approvalType)) {
                vo.setStepType(StepType.APPROVE);
            }else if(StepType.REJECT.getCode().equals(approvalType)) {
                String reason = parameter.getReason();
                vo.setStepType(StepType.REJECT).setReason(reason);
            }else {
                throw new Exception("invalid approvalType");
            }
            //risk level 수정 및 회의록 수정
            avnReportProcessService.updateFirstRiskAssessment(parameter);
            
            avnReportProcessService.smsHazardProcess(vo);
            return ResponseUtil.createSuccessResponse(vo);
        }catch(Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 1차위험평가 결재 처리", description = "보고서 분석 - 1차위험평가 결재 처리 API")
    @PostMapping("/srm/analysis/risk-acceptance/approval/{hazardId}")
    @EnableAuth()
    ResponseEntity<?> updateFirstRiskAssessment(
            @RequestBody @Valid RiskAcceptanceDto.POST_Request parameter,
            @Valid @PathVariable int hazardId) {
        try {
            // TODO API 권한체크

            int groupId=parameter.getGroupId();
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            String approvalType=parameter.getApprovalType();
            String phase="hazard_close";
            String stepCode="";
            String reason = parameter.getReason();
            ReportProcessVo vo =new ReportProcessVo()
                    .setEmpNo(empNo)
                    .setGroupId(groupId)
                    .setHazardId(hazardId)
                    .setReason(reason)
                    .setTimezone("Asia/Seoul");
            if(StepType.APPROVE.getCode().equals(approvalType)) {
                vo.setStepType(StepType.APPROVE);
                stepCode=Step.APPROVED.getCode();
            }else if(StepType.REJECT.getCode().equals(approvalType)) {
                vo.setStepType(StepType.REJECT);
                stepCode=Step.REJECTED.getCode();
            }else if(StepType.CANCEL.getCode().equals(approvalType)){
                vo.setStepType(StepType.CANCEL);
                stepCode=Step.CANCELED.getCode();
            }else {
                throw new Exception("invalid approvalType");
            }
            avnReportProcessService.smsHazardProcess(vo);
            return ResponseUtil.createSuccessResponse(vo);

        }catch(Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 경감조치 할당 insert 처리", description = "보고서 분석 - 경감조치 할당 insert 처리 API")
    @PostMapping("/srm/analysis/mitigation/assign/{hazardId}")
    //@EnableAuth
    public ResponseEntity<?> createMitigationAssign(
            @Valid @RequestBody MitigationAssignDto.POST_Request parameter,
            @Valid @PathVariable int hazardId) {
        try {
            int groupId=parameter.getGroupId();
            String reason = parameter.getReason();
            parameter.setHazardId(hazardId);
            parameter.setTimezone("Asia/Seoul");
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            //1. update mitigation assign info
            SmMitigation mitigation= avnReportMitigationService.insertMitigationAssign(parameter);

            //2. proccess approval status
            ReportProcessVo proccessVo = new ReportProcessVo(groupId, empNo, StepType.SUBMIT, hazardId, reason);
            proccessVo.setTimezone("Asia/Seoul");
            avnReportProcessService.smsHazardProcess(proccessVo);

            //todo khw. 결재에 추가해야될지 ?

            return ResponseUtil.createSuccessResponse(proccessVo);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 경감조치 할당 update 처리", description = "보고서 분석 - 경감조치 할당 update 처리 API")
    @PutMapping("/srm/analysis/mitigation/assign/{hazardId}")
    @EnableAuth
    public ResponseEntity<?> updateMitigationAssign(
            @Valid @RequestBody MitigationAssignDto.PUT_Request parameter,
            @Valid @PathVariable int hazardId) {
        try {
            int groupId=parameter.getGroupId();
            parameter.setHazardId(hazardId);
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            String reason = parameter.getReason();
            //1. update mitigation assign info
            SmMitigation mitigation= avnReportMitigationService.updateMitigationAssign(parameter);

            //2. proccess approval status
            ReportProcessVo processVo = new ReportProcessVo(groupId, empNo, StepType.SUBMIT, hazardId, reason);
            processVo.setTimezone("Asia/Seoul");
            avnReportProcessService.smsHazardProcess(processVo);

            return ResponseUtil.createSuccessResponse(processVo);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 경감조치 할당 결재 처리", description = "보고서 분석 - 경감조치 할당 결재 처리 API")
    @PatchMapping("/srm/analysis/mitigation/assign/approval/{hazardId}")
    //@EnableAuth
    public ResponseEntity<?> updateMitigationAssign(
              @Valid @RequestBody MitigationAssignDto.PATCH_Request parameter
            , @Valid @PathVariable int hazardId) {
        try {
            // 0. TODO validation step status
            int groupId=parameter.getGroupId();
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();

            // 1. Update approval status
            String approvalType=parameter.getApprovalType();
            if(StepType.APPROVE.getCode().equals(approvalType) || StepType.REJECT.getCode().equals(approvalType)) {
                StepType stepType=StepType.APPROVE.getCode().equals(approvalType)?StepType.APPROVE:StepType.REJECT;
                String reason=parameter.getReason();
                ReportProcessVo processVo = new ReportProcessVo(groupId, empNo, stepType, hazardId, reason);
                processVo.setTimezone("Asia/Seoul");
                avnReportProcessService.smsHazardProcess(processVo);
            }
            return ResponseUtil.createSuccessResponse();
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 경감조치 이관(transfer) insert 처리", description = "보고서 분석 - 경감조치 이관(transfer) insert 처리 API")
    @PostMapping("/srm/analysis/mitigation/transfer/{hazardId}")
    //@EnableAuth
    public ResponseEntity<?> createMitigationtransfer(
            @Valid @PathVariable int hazardId
            , @Valid @RequestBody MitigationAssignDto.PUT_Request parameter
    )
    {
        try {
            parameter.setHazardId(hazardId);
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());

            //안전팀인지 확인 필요
            Integer deptId = userInfo.getDeptId();
            String deptCd = userInfo.getDeptCd();
            //부문의 안전팀 리스트
            boolean isExist = avnReportProcessService.isSectorSafetyTeamChecked(deptCd);
            if (!isExist) {
                throw new CustomBusinessException("경감조치 이관 처리가 실패하였습니다.(부문 안전팀 확인)");
            }

            //지정한 부서코드의 부문 체크 필요
            String sector = avnReportMitigationService.selectMitigationDeptSectorInfo(deptId);
            if (sector == null || userInfo.getSector() == null){
                throw new CustomBusinessException("경감조치 이관 처리가 실패하였습니다.(부문 확인)");
            } else {
                if (!userInfo.getSector().equals(sector)) {
                    throw new CustomBusinessException("경감조치 이관 처리가 실패하였습니다.(잘못된 경감조치팀 지정)");
                }
            }
            parameter.setMitigationCenterDeptId(deptId);

            //레포트 상태 조회
            HazardViewlistDto.GET_Request hazardParam = new HazardViewlistDto.GET_Request();
            hazardParam.setGroupId(parameter.getGroupId());
            hazardParam.setHazardId(hazardId);

            List<SmReport> reportStateList = avnReportProcessService.selectReportCurrentStateInfo(hazardParam);
            if (reportStateList.isEmpty()) {
                throw new CustomBusinessException("경감조치 이관 처리가 실패하였습니다.(보고서 확인)");
            } else {
                SmReport reportInfo = reportStateList.get(0);
                if (!deptId.equals(reportInfo.getMitDeptId())) {
                    throw new CustomBusinessException("경감조치 이관 처리가 실패하였습니다.(경감부서 확인)");
                } else {
                    //보고서 상태 확인(mitigation_assign , approved)
                    if (!"mitigation_assign".equals(reportInfo.getPhase()) && !"approved".equals(reportInfo.getStepCode())) {
                        throw new CustomBusinessException("경감조치 이관 처리가 실패하였습니다.(보고서 상태 확인)");
                    }
                }
            }

            //처리
            SmMitigation mitigation = avnReportMitigationService.updateMitigationTransfer(parameter);
            return ResponseUtil.createSuccessResponse(mitigation);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 경감조치 Comment Log 조회", description = "보고서 분석 - 경감조치 Comment Log 조회 API")
    @GetMapping("/srm/analysis/mitigation/commentLog/{hazardId}")
    public ResponseEntity<?> getMyCommentLog(
            @Valid @PathVariable int hazardId) {

        try {
            List<HazardCommentLogVo> commentLog = avnReportProcessService.selectCommentLog(hazardId);
            return ResponseUtil.createSuccessResponse(commentLog);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 경감조치 수락/거절 처리", description = "보고서 분석 - 경감조치 수락/거절 처리 API")
    @PostMapping("/srm/analysis/mitigation/accept/approval/{hazardId}")
    //@EnableAuth(role= {"SA","MIT"})
    public ResponseEntity<?> approvalMitigationAccept(
            @Valid @RequestBody MitigationAcceptDto.POST_Request parameter,
            @Valid @PathVariable int hazardId) {
        try {
            int groupId=parameter.getGroupId();
            parameter.setHazardId(hazardId);
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();

            //todo khw 수락담당자가 팀장이 아닌 경우 팀장에게 알림 메시지 발송 필요

            String approvalType=parameter.getApprovalType();
            String reason = parameter.getReason();
            //1. proccess approval status
            ReportProcessVo proccessVo = new ReportProcessVo()
                    .setGroupId(groupId)
                    .setEmpNo(empNo)
                    .setHazardId(hazardId)
                    .setReason(reason)
                    .setTimezone("Asia/Seoul");

            if(StepType.APPROVE.getCode().equals(approvalType)) {
                proccessVo.setStepType(StepType.APPROVE);
                boolean success = avnReportProcessService.smsHazardProcess(proccessVo);
                if(success) {
                    avnReportMitigationService.updatePlanDueAt(parameter);
                }
            } else if (StepType.REJECT.getCode().equals(approvalType)) {
                //1. 레포트 상태 조회
                HazardViewlistDto.GET_Request hazardParam = new HazardViewlistDto.GET_Request();
                hazardParam.setGroupId(groupId);
                hazardParam.setHazardId(hazardId);

                List<SmReport> reportStateList = avnReportProcessService.selectReportCurrentStateInfo(hazardParam);
                if (reportStateList.isEmpty()) {
                    throw new CustomBusinessException("경감조치 거절 처리가 실패하였습니다.(보고서 확인)");
                } else {
                    SmReport reportInfo = reportStateList.get(0);
                    int mitigationCenterDeptId = reportInfo.getMitigationCenterDeptId();
                    if (mitigationCenterDeptId > 0) {
                        //부문의 안전팀에서 이관된 건의 반려인 경우에는.. 부문의 안전팀으로 반려 처리함..
                        //처리
                        MitigationAssignDto.PUT_Request param = new MitigationAssignDto.PUT_Request();
                        param.setGroupId(groupId);
                        param.setHazardId(hazardId);
                        param.setDeptId(mitigationCenterDeptId);
                        param.setMitigationCenterDeptId(null);

                        List<SmReport> mitigationDeptUserList = avnReportMitigationService.selectMitigationDeptUserList(param);
                        SmReport tempLeaderInfo = mitigationDeptUserList.stream()
                                .filter(h -> !"".equals(h.getMainYn()))
                                .findFirst()
                                .orElseThrow(() -> new IllegalArgumentException());
                        param.setLeaderEmpNo(tempLeaderInfo.getEmpNo());

                        List<SmReport> tempMemberList = mitigationDeptUserList.stream()
                                .filter(h -> "".equals(h.getMainYn()))
                                .collect(Collectors.toList());

                        List<String> memberList = new ArrayList<>();
                        for (SmReport member : tempMemberList) {
                            memberList.add(member.getEmpNo());
                        }
                        param.setMemberEmpNoList(memberList);

                        SmMitigation mitigation = avnReportMitigationService.updateMitigationTransfer(param);
                    } else {
                        proccessVo.setStepType(StepType.REJECT);
                        avnReportProcessService.smsHazardProcess(proccessVo);
                    }
                }
            }else {
                throw new Exception("not allow");
            }
            return ResponseUtil.createSuccessResponse(hazardId);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    // 수행 담당자 조회
    @Operation(summary = "보고서 분석 - 경감조치 수행 담당자 조회", description = "보고서 분석 - 경감조치 수행 담당자 조회 API")
    @GetMapping("/srm/analysis/mitigation/accept/appointer/{hazardId}")
    //@EnableAuth(role= {"SA","MIT"})
    public ResponseEntity<?> assignMitigationAccept(
            @Valid @PathVariable int hazardId) {
        try {
            MitigationAcceptDto.POST_Request_Appointer parameter = new MitigationAcceptDto.POST_Request_Appointer();
            parameter.setId(hazardId);
            parameter.setMitigationEmpType("P");
            List<SmMitigation> mitigation = avnReportMitigationService.selectMitigationEmpNo(parameter);
            return ResponseUtil.createSuccessResponse(mitigation);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    // 수행 담당자 지정 완료 -> 담당자에게 알림 발송
    @Operation(summary = "보고서 분석 - 경감조치 수행 담당자 지정 완료", description = "보고서 분석 - 경감조치 수행 담당자 지정 완료")
    @PostMapping("/srm/analysis/mitigation/accept/appointer/{hazardId}")
    //@EnableAuth(role= {"SA","MIT"})
    public ResponseEntity<?> assignMitigationAccept(
            @Valid @PathVariable int hazardId,
            @Valid @RequestBody MitigationAcceptDto.POST_Request_Appointer parameter)
    {
        try {

            // 기존담당자 제거
            // STEP 1. 수행 담당자empNo를 mitigation 담당자 테이블에 넣는다
            parameter.setMitigationEmpType("P");
            avnReportMitigationService.updateMitigationAppointer(parameter);
            List<String> empNoList = parameter.getEmpList();

            SmReport reportInfo = avnCommonService.selectSmReportByHazardId(hazardId);
            // STEP 2. email과 message를 보낸다.
            // 보내는사람 : 승인자
            String notiType="N0011";
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            String from = empNo;
            String formatTime= DateUtil.toDateFormat(reportInfo.getSubmittedAt().getTime(), "yyyyMMdd");
            String queryParam = "?submitted_at=" +formatTime+ "&doc_no=" + reportInfo.getDocNo();

            //todo khw 링크주소 변경 필요
            //String link=siteUrl + "/" + PortalAppIdStore.MITIGATION.getAppUrl()+queryParam;
            String link= "";
            String href = "<a href=\""+link+" \"target=\"_blank\">"+link+"</a>";
            SmMitigation mitigation= avnReportMitigationService.selectMitigation(hazardId);
            String parsedPlanDueAt = KeUtils.parseUTC(
                    mitigation.getPlanDueAt(),
                    mitigation.getTimezone()
            ).format(DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm"));
            Map<String, String> contentsMap = new HashMap<>();
            contentsMap.put("plan_due_date", parsedPlanDueAt);
            contentsMap.put("static_doc_no", parameter.getDocNo());
            contentsMap.put("doc_no", parameter.getDocNo());
            contentsMap.put("mitigation_page", href);

            //todo khw 메일발송 관련 수정 필요
            //avnReportSysNotiService.sendEmail(from,empNoList,notiType,contentsMap);
            //avnReportSysNotiService.sendSysMsg(empNoList,notiType,link,contentsMap);

            return ResponseUtil.createSuccessResponse(hazardId);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 경감조치 결과 조회(사용안함...........)", description = "보고서 분석 - 경감조치 결과 조회(사용안함...........)")
    @GetMapping("/srm/analysis/mitigation/result/{hazardId}")
    @EnableAuth
    public ResponseEntity<?> getMitigationResult(
            @Valid @PathVariable int hazardId) {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            Integer deptId = userInfo.getDeptId();
            MitigationResultDto.GET_Request parameter= new MitigationResultDto.GET_Request(hazardId,deptId);
            MitigationResultVo detail = avnReportMitigationService.selectMitigationResult(parameter);
            if(detail==null) {
                throw new CustomBusinessException("조회 권한이 없습니다.");
            }
            return ResponseUtil.createSuccessResponse(detail);
        }catch(DataIntegrityViolationException e) {
            throw new CustomBusinessException("조회 권한이 없습니다.");
        }catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 경감조치 결과 PLAN Insert", description = "보고서 분석 - 경감조치 결과 PLAN Insert")
    @PutMapping("/srm/analysis/mitigation/result/plan/{hazardId}")
    //@EnableAuth
    public ResponseEntity<?> putMitigationPlan(
            @Valid @RequestBody MitigationResultDto.PUT_Request parameter,
            @Valid @PathVariable int hazardId,
            @RequestParam(required = true)boolean submit
    ) {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            Integer deptId = userInfo.getDeptId();

            // STEP 1. mitigation result 데이터를 update 한다.
            avnReportMitigationService.updateMitigationResult(parameter);

            // STEP 2. stepcode를 update 한다.
            int groupId = parameter.getDetail().getGroupId();
            if(submit) {
                ReportProcessVo processVo = new ReportProcessVo(groupId, empNo, StepType.SUBMIT, hazardId);
                processVo.setTimezone("Asia/Seoul");
                boolean success = avnReportProcessService.smsHazardProcess(processVo);
                if(success) {
                    //update is_submitted_plan
                    avnReportMitigationService.updateMitigationPlanSubmit(hazardId);
                }
            }else {
                ReportProcessVo processVo = new ReportProcessVo(groupId, empNo, StepType.SAVE, hazardId);
                processVo.setTimezone("Asia/Seoul");
                avnReportProcessService.smsHazardProcess(processVo);
            }
            // 변경된 정보를 받아서 return
            MitigationResultDto.GET_Request mitDetailParam= new MitigationResultDto.GET_Request(hazardId,deptId);
            MitigationResultVo detail= avnReportMitigationService.selectMitigationResult(mitDetailParam);
            return ResponseUtil.createSuccessResponse(detail);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }

    }

    @Operation(summary = "보고서 분석 - 경감조치 결과 RESULT Insert", description = "보고서 분석 - 경감조치 결과 RESULT Insert")
    @PutMapping("/srm/analysis/mitigation/result/{hazardId}")
    //@EnableAuth
    public ResponseEntity<?> putMitigationResult(
            @Valid @RequestBody MitigationResultDto.PUT_Request parameter,
            @Valid @PathVariable int hazardId,
            @RequestParam(required = true)boolean submit
    ) {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            Integer deptId = userInfo.getDeptId();

            // STEP 1. mitigation result 데이터를 update 한다.
            avnReportMitigationService.updateMitigationResult(parameter);

            // STEP 2. stepcode를 update 한다.
            int groupId = parameter.getDetail().getGroupId();
            if(submit) {
                ReportProcessVo processVo = new ReportProcessVo(groupId, empNo, StepType.SUBMIT, hazardId);
                processVo.setTimezone("Asia/Seoul");
                boolean success = avnReportProcessService.smsHazardProcess(processVo);
                if(success) {
                    //update is_submitted_plan
                    avnReportMitigationService.updateMitigationResultSubmit(hazardId);
                }
            }else {
                ReportProcessVo processVo = new ReportProcessVo(groupId, empNo, StepType.SAVE, hazardId);
                processVo.setTimezone("Asia/Seoul");
                avnReportProcessService.smsHazardProcess(processVo);
            }
            // 변경된 정보를 받아서 return
            MitigationResultDto.GET_Request mitDetailParam= new MitigationResultDto.GET_Request(hazardId,deptId);
            MitigationResultVo detail= avnReportMitigationService.selectMitigationResult(mitDetailParam);
            return ResponseUtil.createSuccessResponse(detail);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }

    }

    @Operation(summary = "보고서 분석 - 경감조치 결과 RESULT MSR 삭제 Insert", description = "보고서 분석 - 경감조치 결과 RESULT MSR 삭제 Insert")
    @DeleteMapping("/srm/analysis/mitigation/result/{listId}")
    //@EnableAuth
    public void deleteList(@PathVariable int listId) {
        try {
            avnReportMitigationService.deleteMitigationProgressRateList(listId);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 2차위험평가(lsc) 승인/반려 처리", description = "보고서 분석 - 2차위험평가(lsc) 승인/반려 처리 API")
    @PostMapping("/srm/analysis/second/risk-assessment/approval/{hazardId}")
        //@EnableAuth(role = "LSC")
    ResponseEntity<?> approvalMitigationResult(
            @RequestBody @Valid SecondRiskAssessmentDto.POST_Request parameter,
            @Valid @PathVariable int hazardId)
    {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            int groupId = parameter.getGroupId();
            SmsAuthDto authDto = new SmsAuthDto().setUserInfo(userInfo).setId(groupId).setEmpNo(empNo);
            boolean leader = avnReportRiskAssessmentService.isLscLeader(authDto, true);
            // STEP 1. lsc 리더인지 체크
            if (!(leader)) {
                throw new CustomBusinessException("System Error");
            }
            String approvalType = parameter.getApprovalType();
            ReportProcessVo processVo = parameter.makeProcessVo(empNo);
            processVo.setTimezone("Asia/Seoul");

            if (StepType.APPROVE.getCode().equals(approvalType)) {
                processVo.setStepType(StepType.APPROVE);
                avnReportProcessService.smsHazardProcess(processVo);

            } else if (StepType.REJECT.getCode().equals(approvalType)) {
                processVo.setStepType(StepType.REJECT);
                avnReportProcessService.smsHazardProcess(processVo);
            }
            return ResponseUtil.createSuccessResponse(hazardId);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 2차위험평가(lsc) Insert", description = "보고서 분석 - 2차위험평가(lsc) Insert API")
    @PutMapping("/srm/analysis/second/risk-assessment/{hazardId}")
    //@EnableAuth(role = "LSC")
    ResponseEntity<?> putSecondRiskAssessment(
            @RequestBody @Valid SecondRiskAssessmentDto.PUT_Request parameter,
            @RequestParam(required = true) boolean submit)
    {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            RiskAssessmentVo detail = parameter.getDetail();
            int groupId = detail.getGroupId();
            // 0. check is LSC MEMBER
            SmsAuthDto authDto =new SmsAuthDto().setUserInfo(userInfo).setId(groupId).setEmpNo(empNo);
            boolean isLscMember = avnReportRiskAssessmentService.isLscMember(authDto, true);
            if (!(isLscMember)) {
                throw new CustomBusinessException("System Error");
            }
            // 0-1 현재 hazard의 status를 확인해서 아래 처리르한다.
            SmReportHazardVo reportHazardVo=parameter.getDetail().getReportHazardList().get(0);
            // phase가 2nd_risk 이고  submitted가 아니면 flow를 태움
            // 1. UPDATE REPORT assessmnet info
            avnReportRiskAssessmentService.updateReportAssessment(detail);

            if((Phase.SECOND_RISK.getCode().equals(reportHazardVo.getPhase())
                    && !Step.SUBMITTED.getCode().equals(reportHazardVo.getStepCode()))
                    ||
                    (Phase.HZD_CLOSE.getCode().equals(reportHazardVo.getPhase())
                            && Step.REJECTED_MIT.getCode().equals(reportHazardVo.getStepCode()))

                    //todo khw 2차 SRC 반려 조건 추가 필요..
            ) {
                // 2. UPDATE REPORT HAZARD
                int hazardId=avnReportRiskAssessmentService.updateSecondReportHazard(parameter);
                // 3. UPDATE APPROVAL LOG
                if(submit) {
                    //4. submit시 leader여부를 체크
                    boolean leader = avnReportRiskAssessmentService.isLscLeader(authDto, true);
                    if (!(leader)) {
                        throw new CustomBusinessException("System Error");
                    }
                    ReportProcessVo processVo = new ReportProcessVo(groupId,empNo,StepType.SUBMIT,hazardId);
                    processVo.setTimezone("Asia/Seoul");
                    avnReportProcessService.smsHazardProcess(processVo);
                }else {
                    ReportProcessVo processVo = new ReportProcessVo(groupId,empNo,StepType.SAVE,hazardId);
                    processVo.setTimezone("Asia/Seoul");
                    avnReportProcessService.smsHazardProcess(processVo);
                }
            }
            return ResponseUtil.createSuccessResponse(detail);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }


    @Operation(summary = "보고서 분석 - 2차위험평가(src) insert", description = "보고서 분석 - 2차위험평가(src) insert API")
    @PostMapping("/srm/analysis/second/ssc-review/{hazardId}")
        //@EnableAuth(role= {"SSC"})
    ResponseEntity<?> getSecondRiskAssessment(
            @PathVariable(required = true) Integer hazardId
            , @RequestBody @Valid SSCReveiwDto.POST_Request parameter) {
        try {
            int groupId=parameter.getGroupId();
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            String approvalType=parameter.getApprovalType();
            ReportProcessVo vo =new ReportProcessVo()
                    .setEmpNo(empNo)
                    .setGroupId(groupId)
                    .setHazardId(hazardId)
                    .setTimezone("Asia/Seoul");
            if(StepType.APPROVE.getCode().equals(approvalType)) {
                vo.setStepType(StepType.APPROVE);
            }else if(StepType.REJECT.getCode().equals(approvalType)) {
                String reason = parameter.getReason();
                vo.setStepType(StepType.REJECT).setReason(reason);
            }else {
                throw new Exception("invalid approvalType");
            }

            avnReportProcessService.smsHazardProcess(vo);
            return ResponseUtil.createSuccessResponse(vo);
        }catch(Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    @Operation(summary = "보고서 분석 - 종결 처리", description = "보고서 분석 - 종결 처리 API")
    @PostMapping("/srm/analysis/second/risk-acceptance/approval/{hazardId}")
    //@EnableAuth()
    ResponseEntity<?> updateSecondRiskAssessment(
            @RequestBody @Valid RiskAcceptanceDto.POST_Request parameter,
            @Valid @PathVariable int hazardId) {
        try {
            // TODO API 권한체크

            int groupId=parameter.getGroupId();
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            String approvalType=parameter.getApprovalType();
            String phase="hazard_close";
            String stepCode="";
            String reason = parameter.getReason();
            ReportProcessVo vo =new ReportProcessVo()
                    .setEmpNo(empNo)
                    .setGroupId(groupId)
                    .setHazardId(hazardId)
                    .setReason(reason)
                    .setTimezone("Asia/Seoul");
            if(StepType.APPROVE.getCode().equals(approvalType)) {
                vo.setStepType(StepType.APPROVE);
                stepCode=Step.APPROVED.getCode();
            }else if(StepType.REJECT.getCode().equals(approvalType)) {
                vo.setStepType(StepType.REJECT);
                stepCode=Step.REJECTED.getCode();
            }else if(StepType.CANCEL.getCode().equals(approvalType)){
                vo.setStepType(StepType.CANCEL);
                stepCode=Step.CANCELED.getCode();
            }else {
                throw new Exception("invalid approvalType");
            }
            avnReportProcessService.smsHazardProcess(vo);
            return ResponseUtil.createSuccessResponse(vo);

        }catch(Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }

    

    /**
     * 보고서 분석 - VOID
     *
     * @param Map 예) {"reason": "이건 머지11122333.."}
     * @return
     * @throws Exception the exception
     */
    @Operation(summary = "보고서 분석 - VOID", description = "보고서 분석 - VOID API")
    @PutMapping(value = "/srm/analysis/void/{reportId}")
    public ResponseEntity<?> voidReportInfo(
              @RequestBody Map<String, Object> body
            , @PathVariable(value="reportId", required=true) Integer reportId
    ) {
        try {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String empNo = userInfo.getEmpNo();
            String reason = (String) body.get("reason");

            if(StringUtils.isBlank(reason)) {
                throw new CustomBusinessException("[reason] is required");
            }

            int voided = 0;
            //그룹 정보 조회
            Map<String, Object> reportInfo = avnReportProcessService.selectGroupedValidateReportId(reportId);
            int groupId = Integer.parseInt(reportInfo.get("group_id").toString());
            int cnt = Integer.parseInt(reportInfo.get("cnt").toString());
            if (cnt == 1) {
                //그룹묶인 건이 한 건인 경우 : 해당 건을 Void 처리하고 결재 상태 업데이터 처리해야함..
                ReportVoidVo voidVo = ReportVoidVo.builder()
                        .groupId(groupId)
                        .reportId(reportId)
                        .empNo(empNo)
                        .reason(reason)
                        .build();
                voided = avnReportProcessService.voidReport(voidVo);
            } else if (cnt > 1) {
                //그룹묶인 건이 여러 건인 경우 : 해당 건만 Void 처리하고 끝 && 대표보고서인 경우 다른 보고서를 대표보고서로 업데이트 필요..
                ReportVoidVo voidVo = ReportVoidVo.builder()
                        .groupId(groupId)
                        .reportId(reportId)
                        .empNo(empNo)
                        .reason(reason)
                        .build();
                voided = avnReportProcessService.updateVoidReportId(voidVo);
            } else {
                throw new CustomBusinessException("System Error");
            }

            List<Integer> deleteds = new ArrayList<>();
            deleteds.add(voided);
            //result.setId(deleteds);
            return ResponseEntity.ok(""/*result*/);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error", "2");
        }
    }

    /**
     * 보고서 분석 - NOTIFY : 묶음 하지 않은 건만 처리 가능함
     *
     * @param Map 예) {"id": 0, "docNo": "ASR-104414","reportType": "asr","receptionPage": ""}
     *                 id, receptionPage : 미입력 가능
     * @return
     * @throws Exception the exception
     */
    @Operation(summary = "보고서 분석 - NOTIFY", description = "보고서 분석 - NOTIFY API")
    @GetMapping("/srm/analysis/memberDetail/{groupId}/{reportId}")
    @EnableAuth(role = {"SA", "MMG", "CMG", "GMG", "DMG", "AMG", "HMG", "FMG"}) //TODO khw 추가되는 레포트 정의 필요(권한)
    public ResponseEntity<?> getMemberDetail(
            @Valid @PathVariable int groupId,
            @Valid @PathVariable int reportId,
            @Valid ReceiptMemberDetailDto.GET_Request dto) {
        try {
            //todo kwh. sendNotificationService 이후 수정 필요
            KeNotificationTemplate template = new KeNotificationTemplate();//sendNotificationService.selectNotificationTemplate("N0022");
            String roleCd = AvnStatusCode.RoleByReport.find(dto.getReportType()).getManagerRoleCd();
            List<SmReceptionMember> members = serviceReceipt.selectReceiptMember(roleCd);

            //doc no 클릭시 링크 주소 생성
            String receptionPage = "/srm/analysis";
            dto.setReceptionPage(receptionPage);

            for (SmReceptionMember member : members) {
                String email = avnCommonService.decryptValue(member.getEmail());
                member.setDecryptEmail(email);
            }

            SmReport report = serviceReceipt.selectReportDetail(groupId);
            String reportType = report.getReportType();

            AsrReportSelectDto asrReportSelectDto = asrReportService.findAsrReport(groupId, reportId, reportType);
            SmAsrEvent asrEvent = asrReportSelectDto.getEvent();
            FlightResponseDto flight = asrReportSelectDto.getFlight();
            String queryParam = "?submitted_at=" + report.parseSubmittedAt() + "&doc_no=" + report.getDocNo();

            String flightNo = "";
            String eventAt = "";

            if ( asrEvent == null) {
                dto.setReceptionPage(siteUrl + dto.getReceptionPage()+queryParam);

                ReceiptMemberDetailDto.GET_Response data =
                        ReceiptMemberDetailDto.GET_Response.of(dto, members, template, report, eventAt, flightNo, reportType);
                return ResponseUtil.createSuccessResponse(data);
            }

            if ( asrEvent.getEventAt() != null) {
                eventAt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(asrEvent.getEventAt());
            }

            if ( flight != null ) {
                flightNo = flight.getFlightNo();
            }

            dto.setReceptionPage(siteUrl + dto.getReceptionPage()+queryParam);

            ReceiptMemberDetailDto.GET_Response data =
                    ReceiptMemberDetailDto.GET_Response.of(dto, members, template, report, eventAt, flightNo, reportType);

            return ResponseUtil.createSuccessResponse(data);
        } catch (Exception exception) {
            throw new CustomBusinessException("System Error");
        }
    }



    private int preProcessing(ReceiptVo vo, boolean isCreate) throws Exception {
        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        String empNo = userInfo.getEmpNo();

        int groupId = vo.getGroupId();

        SmReport report = serviceReceipt.selectReportDetail(groupId);
        String phase = report.getPhase();
        // 보고접수 or 리포트 작성완료 ||
        if (!(AvnStatusCode.Phase.RECEPTION.getCode().equals(phase)
                || AvnStatusCode.Phase.REPORTING.getCode().equals(phase)
                || AvnStatusCode.Phase.REPORT_CLOSE.getCode().equals(phase))) {
            throw new Exception();
        }
        vo.setEmpNo(empNo);
        vo.setSmReport(report);
        vo.setCreate(isCreate);

        return groupId;
    }



    @Operation(summary = "보고서 분석 - 보고서 작성 SUBMIT TEST(나중에 삭제 가능)", description = "보고서 분석 - TEST")
    @PostMapping(value = "/srm/analysis/test/{reportId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG"})
    public ResponseEntity<?> insertReceiptInfoTest(
            @PathVariable(value="reportId", required=true) Integer reportId
    ) {
        try {
            ReportProcessVo proccessVo = new ReportProcessVo(0, reportId, "KIM", StepType.SUBMIT);
            boolean success = avnReportProcessService.smsReportProcess(proccessVo);
            return ResponseUtil.createSuccessResponse();

        } catch (Exception e) {
            //throw new MicroServiceException(HttpStatus.INTERNAL_SERVER_ERROR, 500, "System Error");
            throw new CustomBusinessException("System Error", "2");
        }
    }

    @Operation(summary = "보고서 분석 - 부서팀원정보 조회 TEST(나중에 삭제 가능)", description = "보고서 분석 - TEST")
    @GetMapping("/srm/analysis/test/{deptId}")
    //@EnableAuth(role= {"SA","MIT"})
    public ResponseEntity<?> getMitigationTeam(
            @Valid @PathVariable int deptId) {
        try {
            MitigationAssignDto.PUT_Request param = new MitigationAssignDto.PUT_Request();
            param.setDeptId(deptId);
            List<SmReport> mitigationDeptUserList = avnReportMitigationService.selectMitigationDeptUserList(param);

            SmReport deptInfo = mitigationDeptUserList.stream()
                    .filter(h -> !"".equals(h.getMainYn()))
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException());

            List<SmReport> deptList = mitigationDeptUserList.stream()
                    .filter(h -> "".equals(h.getMainYn()))
                    .collect(Collectors.toList());

            param.setLeaderEmpNo(mitigationDeptUserList.get(0).getEmpNo());
            return ResponseUtil.createSuccessResponse(deptId);
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }
}
