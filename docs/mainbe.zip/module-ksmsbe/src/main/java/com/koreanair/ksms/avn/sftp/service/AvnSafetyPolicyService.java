package com.koreanair.ksms.avn.sftp.service;

import com.koreanair.ksms.avn.sftp.dto.TbAvnSafetyPolicyDto;

public interface AvnSafetyPolicyService {
    TbAvnSafetyPolicyDto selectSafetyPolicyImg();
}
