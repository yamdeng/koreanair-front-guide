package com.koreanair.ksms.avn.srm.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class IvRadicalDTO {
    private int hazardId;
    private String hazardType;
    private int consequenceId;
    private String hazardName;
    private String consequenceName;
}
