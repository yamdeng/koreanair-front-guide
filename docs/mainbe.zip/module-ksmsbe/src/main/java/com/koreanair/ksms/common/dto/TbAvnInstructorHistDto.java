package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS_강사_이력")
public class TbAvnInstructorHistDto extends CommonDto {
    
    @Schema(description = "사원번호")
    @NotBlank
    private String empNo;
    
    @Schema(description = "임용일자")
    @NotBlank
    private String emplymentDt;
    
    @Schema(description = "임용유형코드")
    @NotBlank
    private String employmentTypeCd;
    
    @Schema(description = "임용여부")
    @NotBlank
    private String imploymentYn;
    
    @Schema(description = "메모내용")
    private String notesCn;
    
    @Schema(description = "링크그룹SEQ")
    private String linkGroupSeq;
    
    @Schema(description = "파일그룹SEQ")
    private String fileGroupSeq;
}
