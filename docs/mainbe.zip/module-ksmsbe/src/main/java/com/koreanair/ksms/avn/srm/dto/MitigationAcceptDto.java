package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

public class MitigationAcceptDto {

	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class POST_Request {
		@NotNull
		private String approvalType;
		@NotNull
		private int groupId;
		private int hazardId;
		private String reason;
	}
	
	
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class POST_Request_Appointer extends CommonDto {
		@NotNull
		private List<String> empList;
		@NotNull
		private int id;
		@NotNull
		private int groupId;
		@NotNull
		private String docNo;

		private String mitigationEmpType;

		private String realMitigationPerform;
	}
}
