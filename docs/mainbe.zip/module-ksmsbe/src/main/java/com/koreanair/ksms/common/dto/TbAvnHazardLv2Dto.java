package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "위해요인_레벨_2_정보")
public class TbAvnHazardLv2Dto extends CommonDto {
    
    @Schema(description = "위해요인LV2ID")
    @NotBlank
    private String hazardLvtwoId;
    
    @Schema(description = "위해요인LV1ID")
    private String hazardLvoneId;
    
    @Schema(description = "위해요인LV2명")
    @NotBlank
    private String hazardLvtwoNm;
    
    @Schema(description = "메모내용")
    private String notesCn;
    
    @Schema(description = "표시순번")
    @NotBlank
    private String viewSn;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "타임존코드")
    @NotBlank
    private String timezoneCd;
    
    @Schema(description = "삭제자ID")
    private String delUserId;
    
    @Schema(description = "삭제일시")
    private String delDttm;
}
