package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.AsrReportSelectDto;
import com.koreanair.ksms.avn.srm.dto.FlightCrewVo;
import com.koreanair.ksms.avn.srm.dto.ReportWithApprovalStep;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import com.koreanair.ksms.common.utils.FieldTypes;
import com.koreanair.ksms.common.utils.MaskingTypes;
import com.koreanair.ksms.common.utils.MaskingUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AvnAsrReportServiceImpl extends AbstractBaseService implements AvnAsrReportService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService serviceCommon;

    public AsrReportSelectDto findAsrReport(int groupId, int reportId, String reportType) throws Exception {
        Map<String, Object> param = new HashMap<>();
        param.put("groupId", groupId);
        param.put("reportId", reportId);
        AsrReportSelectDto reportDto = commonSql.selectOne("AvnReportAsr.selectAsrReport", param);

        if (reportDto == null) {
            throw new Exception("조회된 보고서가 없습니다.");
        }

        if (!reportType.equals("asr")) {
            return reportDto;
        }

        ReportWithApprovalStep report = reportDto.getReport();
        int flightId = reportDto.getFlight().getId();
        @SuppressWarnings("unchecked")
        List<FlightCrewVo> flightCrews = commonSql.selectList("AvnReportAsr.selectSmFlightCrew", flightId);
        List<FlightCrewVo> maskedCrews = new MaskingUtils().maskingList(flightCrews, MaskingTypes.EMP_NO,
                FieldTypes.CAMEL_CASE);
        reportDto.setFlightCrews(maskedCrews);

        /* 필요없을듯..
        if (Objects.nonNull(reportDto.getWeather())) {
            int weatherId = reportDto.getWeather().getId();
            @SuppressWarnings("unchecked")
            List<WeatherCodeVo> significantWeather = commonSql.selectList("AvnReportAsr.selectSmWeatherKeCodeWeather",
                    weatherId);
            reportDto.setSignificantWeather(significantWeather);
        }
        */
        // Get writer information.
        TbSysUserDto writer =  ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());

        // Modify user information: Decrypt.
        writer.setEmail(serviceCommon.decryptValue(writer.getEmail()));

        String officeTelNo = writer.getOfficeTelNo();
        if (StringUtils.isNotEmpty(officeTelNo) && officeTelNo.length() > 13) {
            officeTelNo = serviceCommon.decryptValue(officeTelNo);
        }
        writer.setOfficeTelNo(officeTelNo);

        //	Modify user information: Masking.
        //	MaskingUtils maskingUtils = new MaskingUtils();
        //	MaskingTypes writerMaskingType = maskingUtils.getMaskingTypeForReport("ASR", session, writerNo, writerNo);
        //	logger.debug("Masking type of writer: {}", writerMaskingType);
        //	reportDto.setWriter(writerMaskingType != null ? maskingUtils.maskingOne(writer, writerMaskingType, FieldTypes.UPPER_SNAKE_CASE)	: writer);

        reportDto.setWriter(writer);
        return reportDto;
    }


}
