package com.koreanair.ksms.system.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@ToString
public class TbSysMenuDto extends CommonDto {

    @NotBlank
    @Size(max=20)
    private String menuId;

    @NotBlank
    @Size(max=1)
    @Pattern(regexp="^[AOS]$") // A, O, S 중의 한 문자만 입력
    private String workScope;

    @NotBlank
    @Size(max=250)
    private String nameKor;

    @NotBlank
    @Size(max=250)
    private String nameEng;

    private String nameChn;
    private String nameJpn;
    private String nameEtc;

    @NotBlank
    @Size(max=1)
    @Pattern(regexp="^[MF]$") // M, F 중의 한 문자만 입력
    private String treeType;

    @NotBlank
    private String upperMenuId;

    private int sortOrder;
    private String menuUrl;
    private String useYn;
    private String remark;
    private int level;
}
