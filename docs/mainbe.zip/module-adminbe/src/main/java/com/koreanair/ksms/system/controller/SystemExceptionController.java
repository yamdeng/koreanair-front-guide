package com.koreanair.ksms.system.controller;

import com.koreanair.ksms.exception.CustomBusinessException;
import com.koreanair.ksms.system.dto.TbSysCodeGroupDto;
import com.koreanair.ksms.system.dto.TbSysMessageDto;
import com.koreanair.ksms.system.service.SystemMessageService;
import com.koreanair.ksms.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 사이트 - Exception 테스트용 클래스
 */
@Tag(name = "SystemException", description = "Exception 테스트용 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/sys")
public class SystemExceptionController {

    @Autowired
    SystemMessageService messageService;

    @Operation(summary = "CustomBusinessException", description = "CustomBusinessException 테스트 API")
    @GetMapping(value = "/tests/custom")
    public ResponseEntity<?> testCustomException() {

        throw new CustomBusinessException("업무 오류가 발생했습니다.");
    }

    @Operation(summary = "ValidationException", description = "ValidationException 테스트 API")
    @PostMapping(value = "/tests/validation")
    public ResponseEntity<?> testValidation(@Valid @RequestBody(required=true) TbSysCodeGroupDto dto) {

        return ResponseUtil.createSuccessResponse(dto);
    }

    @Operation(summary = "PK중복", description = "PK중복 테스트 API")
    @GetMapping(value = "/tests/dupl")
    public ResponseEntity<?> testDupl() {

        TbSysMessageDto dto = new TbSysMessageDto();
        dto.setMsgKey("DUPL");
        dto.setMsgKor("DUPL");
        dto.setMsgEng("DUPL");

        messageService.insertMessage(dto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "NullPointerException", description = "NullPointerException 테스트 API")
    @GetMapping(value = "/tests/nullpointer")
    public ResponseEntity<?> testNullPointer() {

        throw new NullPointerException("Test");
    }
}
