import { useEffect } from 'react';
import Modal from 'react-modal';
import { Viewer } from '@toast-ui/react-editor';
import AppFileAttach from '@/components/common/AppFileAttach';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SafetyAdvModal(props) {
  const { isOpen, closeModal, safetyAdvInfo } = props;

  const {
    id,
    caId,
    recommendNo,
    recommend,
    actionTaken,
    deptCd,
    empNo,
    issueAt,
    dueAt,
    fileGroupSeq,
    regDttm,
    regUserId,
    updDttm,
    updUserId,
  } = safetyAdvInfo;

  useEffect(() => {}, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">안전권고 관리</h3>

        <div className="pop_cont">
          {/*상세 */}
          <div className="editbox">
            <div className="form-table line">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">번호</label>
                        <span className="text-desc-type1">{recommendNo}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">부서</label>
                        <span className="text-desc-type1">{deptCd}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">발행일자</label>
                        <span className="text-desc-type1">{issueAt}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">회신일자</label>
                        <span className="text-desc-type1">{dueAt}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">안전권고</label>
                        <span className="text-desc-type1">{recommend}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">조치사항</label>
                        <span className="text-desc-type1">{actionTaken}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <AppFileAttach
                          label="첨부파일"
                          onlyImageUpload={false}
                          mode="view"
                          fileGroupSeq={fileGroupSeq}
                          workScope={'A'}
                        />
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>
        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            닫기
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>

      {/*style="z-index: 1002; display: block; opacity: 0.5;"*/}
    </Modal>
  );
}
export default SafetyAdvModal;
