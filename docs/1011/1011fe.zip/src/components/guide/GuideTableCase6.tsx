import { produce } from 'immer';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import Config from '@/config/Config';
import CommonUtil from '@/utils/CommonUtil';
import { useState } from 'react';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { create } from 'zustand';

const list = [];

for (let index = 1; index <= 10; index++) {
  list.push({
    msgKey: `key${index}`,
    msgKor: `msgKor${index}`,
    msgEng: `msgEng${index}`,
    msgChn: `msgChn${index}`,
    msgJpn: `msgJpn${index}`,
    msgEtc: `msgEtc${index}`,
    checkedTest: false,
    checkBoxHide: index === 10 || index === 3 ? true : false,
  });
}

const initListData = {
  ...listBaseState,
  listApiPath: 'TODO:목록api패스',
  baseRoutePath: 'TODO:UI라우트패스',
};

/* zustand store 생성 */
const TestListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  list: list,

  toggleCheckbox: (rowIndex) => {
    set(
      produce((state: any) => {
        const beforeChecked = state.list[rowIndex]['checkedTest'];
        state.list[rowIndex]['checkedTest'] = !beforeChecked;
      })
    );
  },

  updateCheckbox: (rowIndex, checked) => {
    set(
      produce((state: any) => {
        state.list[rowIndex]['checkedTest'] = checked;
      })
    );
  },
}));

function CheckBoxComponent(props) {
  const { node } = props;
  const { rowIndex } = node;
  const { list, toggleCheckbox, updateCheckbox } = TestListStore();
  const checked = list[rowIndex].checkedTest;
  const checkBoxHide = list[rowIndex].checkBoxHide;

  const onChange = (checked) => {
    console.log(`toggleCheckbox : ${toggleCheckbox}`);
    console.log(`updateCheckbox : ${updateCheckbox}`);
    console.log(`checked : ${checked}`);
    // toggleCheckbox(rowIndex);
    updateCheckbox(rowIndex, checked);
  };

  return (
    <span style={{ display: !checkBoxHide ? '' : 'none' }}>
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => {
          onChange(event.target.checked);
        }}
      />
    </span>
  );
}

function GuideTableCase6() {
  const { list } = TestListStore();

  const [selectedRowList, setSelectedRowList] = useState([]);

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      {
        field: 'checkedTest',
        headerName: 'boolean test',
        cellRenderer: CheckBoxComponent,
      },
      { field: 'msgKey', headerName: '메시지 키' },
      { field: 'msgKor', headerName: '설명(한국어)' },
      { field: 'msgEng', headerName: '설명(영어)' },
      { field: 'msgChn', headerName: '설명(중국어)' },
      { field: 'msgJpn', headerName: '설명(일본어)' },
      { field: 'msgEtc', headerName: '설명(기타)' },
    ])
  );

  const handleRowSelect = (selectedRowList) => {
    console.log(`selectedInfo : ${selectedRowList}`);
    setSelectedRowList(selectedRowList);
  };

  const confirm1 = () => {
    console.log(`selectedRowList.length : ${selectedRowList.length}`);
  };

  const confirm2 = () => {
    const filterList = list.filter((info) => info.checkedTest);
    console.log(`filterList.length : ${filterList.length}`);
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          2 checkbox
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideTableCase6.tsx`}>
            GuideTableCase6
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="btn-area">
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={confirm1}>
            체크박스 조회1
          </button>
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={confirm2}>
            체크박스 조회2
          </button>
        </div>
      </div>
      <AppTable
        rowData={list}
        setColumns={setColumns}
        columns={columns}
        handleRowSelect={handleRowSelect}
        enableCheckBox
        hideDisabledCheckboxes
      />
    </>
  );
}

export default GuideTableCase6;
