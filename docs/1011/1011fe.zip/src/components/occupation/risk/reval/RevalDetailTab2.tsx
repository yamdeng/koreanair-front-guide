import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
import shareImage from '@/resources/images/share.svg';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppTable from '@/components/common/AppTable';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
// import {
//   useOcuRiskTab2FormStore,
//   useOcuRiskTab2SiteVisitListStore,
// } from '@/stores/occupation/risk/useOcuRiskTab2FormStore';

import useOcuRiskTab2FormStore from '@/stores/occupation/risk/useOcuRiskTab2FormStore';
import CommonUtil from '@/utils/CommonUtil';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalDetailTab2() {
  // const {
  //   getDetail,
  //   formValue,
  //   selectedPlaceIndex,
  //   setSelectedPlaceIndex,
  //   getPlaceColumn,
  //   goFormPage,
  //   getPlace2ndList,
  //   cancel,
  //   clear,
  // } = useOcuRiskTab2FormStore();

  // // 청취조사
  // const listenInfo = useOcuRiskTab2FormStore();
  // // 현장순화
  // const visitInfo = useOcuRiskTab2SiteVisitListStore();

  const {
    detailInfo,
    getDetail,
    formType,
    cancel,
    goFormPage,
    clear,
    search,
    list,
    listenChange,
    formValue,
    selectedPlaceIndex,
    setSelectedPlaceIndex,
    getPlaceColumn,

    selectedItemIndex,
    setSelectedItemIndex,
    getItemColumn,
  } = useOcuRiskTab2FormStore();
  // const {
  //   /* 기본정보 */
  //   // 안전보건 정보 내용
  //   hlthSftyInfoCn,

  //   /* 청취조사 */
  //   // 위험성평가 문서 번호
  //   revalDocNo,

  //   // 근로자 성명
  //   lsurveyEmplNm,
  //   // 대상공정(작업)
  //   lsurveyProcNm,
  //   // 유해,위험요인에 대한 의견
  //   lsurveyHzdOpnn,

  //   /* 현장순회 */

  //   // 순회일자
  //   svisitDt,
  //   // 대상공정(작업)
  //   svisitProcNm,
  //   // 유해,위험요인에 대한 의견
  //   svisitHzdOpnn,
  //   // 사진 첨부
  //   svisitFileId,
  // } = detailInfo;

  // console.log('값2==>', detailInfo);

  console.log('formValue========>', formValue);

  const { detailId } = useParams();

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'lsurveyEmplNm', headerName: '근로자', flex: 1 },
      { field: 'lsurveyProcNm', headerName: '대상공정(작업)', flex: 1 },
      { field: 'lsurveyHzdOpnn', headerName: '유해, 위험요인에 대한 의견', flex: 1 },
    ])
  );

  const [columns2, setColumns2] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'svisitDt', headerName: '순회일자', flex: 1 },
      { field: 'svisitProcNm', headerName: '대상공정(작업)', flex: 1 },
      { field: 'svisitHzdOpnn', headerName: '유해, 위험요인에 대한 의견', flex: 1 },
      //{ field: 'execTeamPosCd', headerName: '삭제', flex: 1 },
      // {
      //   pinned: 'right',
      //   field: 'action',
      //   headerName: '삭제',
      //   // flex: 1,
      //   cellRenderer: 'deleteActionButton',
      //   cellRendererParams: {
      //     onClick: removeByIndex,
      //   },
      //},
    ])
  );

  // 청취자 행 변경
  const handleRowSingleClick = useCallback(
    (selectedInfo) => {
      const { rowIndex } = selectedInfo;

      if (rowIndex !== selectedPlaceIndex) {
        setSelectedPlaceIndex(rowIndex);
      }
    },
    [formValue, selectedPlaceIndex]
  );

  // 현장 순회 행 변경
  const handleRowSingleClick2 = useCallback(
    (selectedInfo) => {
      const { rowIndex } = selectedInfo;

      if (rowIndex !== selectedItemIndex) {
        setSelectedItemIndex(rowIndex);
      }
    },
    [formValue, selectedItemIndex]
  );

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  // 첫번째 행 선택
  useEffect(() => {
    if (formValue?.listenInfoList && formValue.listenInfoList.length > 0 && selectedPlaceIndex === -1) {
      console.log('여기@@@@@@@@@@@@@');
      const firstRow = formValue.listenInfoList[0];
      handleRowSingleClick({ data: firstRow, rowIndex: 0 });
    }
    if (formValue?.visitInfoList && formValue.visitInfoList.length > 0 && selectedItemIndex === -1) {
      const firstRow = formValue.visitInfoList[0];
      handleRowSingleClick2({ data: firstRow, rowIndex: 0 });
    }
  }, [formValue, selectedPlaceIndex, selectedItemIndex]);

  // const init = async () => {
  //   getDetail(detailId);
  //   search();
  // };

  // useEffect(() => {
  //   init();
  //   return clear;
  // }, []);

  // 수정
  const goForm = () => {
    goFormPage(detailId);
  };

  return (
    <>
      {/* <AppNavigation />
      <div className="conts-title">
        <h2>
          위험성평가 상세2
          <span>
            <a href="javascript:void(0);"></a>
          </span>
        </h2>
      </div> */}
      {/*탭 */}
      {/* <div className="menu-tab-nav">
        <div className="menu-tab">
          <a href="javascript:void(0);" className="active" data-label="사전준비">
            사전준비
          </a>
          <a href="javascript:void(0);" data-label="유해 위험요인 파악">
            유해 위험요인 파악
          </a>
          <a href="javascript:void(0);" data-label="위험성 결정">
            위험성 결정
          </a>
          <a href="javascript:void(0);" data-label="첨부문서">
            첨부문서
          </a>
        </div>
      </div> */}
      {/*//탭 */}
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              청취조사<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="ck-edit-box">
                        <div className="ck-list">
                          {/* 그리드영역 */}
                          <AppTable
                            rowData={formValue.listenInfoList || []}
                            columns={columns}
                            setColumns={setColumns}
                            handleRowSingleClick={handleRowSingleClick}
                            hiddenPagination
                          />
                        </div>
                        <div className="ck-edit">
                          <div className="boxForm">
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  {/* <AppTextInput label="근로자" /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">근로자</label>
                                        {/* <span className="text-desc-type1">{lsurveyEmplNm}</span> */}

                                        <span className="text-desc-type1">{getPlaceColumn('lsurveyEmplNm')}</span>

                                        {/* <span className="text-desc-type1">{lsurveyEmplNm}</span> */}
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {/* <AppTextInput label="대상공정(작업)" /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">대상공정(작업)</label>
                                        {/* <span className="text-desc-type1">{lsurveyProcNm}</span> */}
                                        <span className="text-desc-type1">{getPlaceColumn('lsurveyProcNm')}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <textarea
                                          id="testArea1"
                                          className="form-tag custom_textarea"
                                          style={{ width: '100%' }}
                                          name="testArea1"
                                          // value={lsurveyHzdOpnn}
                                          value={getPlaceColumn('lsurveyHzdOpnn')}
                                          // readOnly
                                        />
                                        <label className="f-label" htmlFor="testArea1">
                                          유해,위험요인에 대한 의견
                                        </label>
                                        {/* <span className="text-desc-type1">{lsurveyHzdOpnn}</span> */}
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="btn-area-type01 mg-top">
                              {/* <button type="button" name="button" className="btn_text btn_confirm">
                                저장
                              </button> */}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              현장순회<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="ck-edit-box">
                        <div className="ck-list ck-list-grid">
                          {/* 그리드영역 */}
                          <AppTable
                            rowData={formValue.visitInfoList || []}
                            columns={columns2}
                            setColumns={setColumns2}
                            handleRowSingleClick={handleRowSingleClick2}
                            hiddenPagination
                            // components={{
                            //   deleteActionButton: DeleteActionButton,
                            // }}
                          />
                        </div>
                        <div className="ck-edit">
                          <div className="boxForm">
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  {/* <AppDatePicker label={'순회일자'} /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">순회일자</label>
                                        {/* <span className="text-desc-type1">{svisitDt}</span>
                                         */}

                                        <span className="text-desc-type1">{getItemColumn('svisitDt')}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {/* <AppTextInput label="대상공정(작업)" /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">대상공정(작업)</label>
                                        {/* <span className="text-desc-type1">{svisitProcNm}</span> */}
                                        <span className="text-desc-type1">{getItemColumn('svisitProcNm')}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <textarea
                                          id="testArea1"
                                          className="form-tag custom_textarea"
                                          style={{ width: '100%' }}
                                          name="testArea1"
                                          // value={svisitHzdOpnn}
                                          value={getItemColumn('svisitHzdOpnn')}
                                          readOnly
                                        />
                                        <label className="f-label" htmlFor="testArea1">
                                          유해,위험요인에 대한 의견
                                        </label>
                                        {/* <span className="text-desc-type1">{svisitHzdOpnn}</span> */}
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <h3 className="table-tit mb-10">사진 첨부</h3>
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="view"
                                    // fileGroupSeq={svisitFileId}
                                    fileGroupSeq={getItemColumn('svisitFileId')}
                                    workScope={'O'}
                                    // onlyImageUpload={true}
                                    useDetail
                                    disabled
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="btn-area-type01 mg-top">
                              {/* <button type="button" name="button" className="btn_text btn_confirm">
                                저장
                              </button> */}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              안전보건 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <textarea
                          id="testArea1"
                          className="form-tag custom_textarea"
                          style={{ width: '100%' }}
                          name="testArea1"
                          value={formValue.hlthSftyInfoCn}
                          // {formValue.riskDcsnPsbltVal}

                          readOnly
                        />
                        <label className="f-label" htmlFor="testArea1">
                          내용
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/*//입력영역*/}

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goForm}
          // style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          수정
        </button>
        {/* <button type="button" name="button" className="btn_text btn-del">
          삭제
        </button> */}
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
      </div>
    </>
  );
}
export default RevalDetailTab2;
