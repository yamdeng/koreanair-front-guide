import ApiService from '@/services/ApiService';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppNavigation from '@/components/common/AppNavigation';
import AppSearchInput from '@/components/common/AppSearchInput';
// import AppSelect from '@/components/common/AppSelect';
import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import { useCallback, useEffect, useState } from 'react';
import { create } from 'zustand';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';
import history from '@/utils/history';
import { useNavigate, useHistory } from 'react-router-dom';

// /occupation/notice/{id} : 상세
// /occupation/notice/{id}/edit : 폼(등록/수정)

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/risk/revalData',
  baseRoutePath: '/occupation/risk/revalData',
};

// 현재 연도
const currentYear = new Date().getFullYear().toString();

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 년도
  searchYear: currentYear,
  // 구분
  searchGubun: 'A',
};

/* zustand store 생성 */
const RevalDataListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    // 년도
    searchYear: currentYear,
    // 구분
    searchGubun: 'A',
  },

  search: async () => {
    const { listApiPath, getSearchParam, setTotalCount, listApiMethod, disablePaging } = get();
    const applyListApiMethod = listApiMethod || 'get';
    const apiParam = getSearchParam();
    const apiResult: any = await ApiService[applyListApiMethod](listApiPath, apiParam, { disableLoadingBar: false });
    // const data = apiResult.data;
    const list = disablePaging ? apiResult.data : apiResult.data.list;
    const totalCount = disablePaging && list ? list.length : apiResult.data.total;
    setTotalCount(totalCount);
    set({ list: list || [] });

    const chartList = apiResult.data.list;

    const strInnerHtml = '<canvas  width="700" height="400" id="chart_1"></canvas>';
    const chartElement = document.getElementById('chartMaker');
    chartElement.replaceChildren();
    chartElement.innerHTML = strInnerHtml;

    console.log('apiParam===>', apiParam.searchGubun);

    const canvas = document.getElementById('chart_1');
    const cvs = canvas.id;

    // 위험성 평가 Pie 차트
    if (apiParam.searchGubun === 'A') {
      // const canvas = document.getElementById('chart_1');
      // const cvs = canvas.id;
      const data = {
        colData: [],
        valData: [],
        pctgData: [],
      };
      chartList.map((chartData, targetIndex) => {
        data.colData.push(chartData.sectNm);
        data.valData.push(chartData.revalCnt);
        data.pctgData.push(chartData.revalPctg);
      });
      DxChart.reset(cvs);

      console.log(' data.pctgData===>', data.pctgData);

      const pie = new DxChartPie({
        id: cvs,
        elem: canvas,
        labels: data.colData,
        data: data.valData,
        options: {
          radius: 125,
          margin: {
            Left: 0,
            Right: 0,
            Top: 165,
            Inner: 25,
            Bottom: 162,
          },

          CustomData: data.pctgData,

          tooltips: {
            Data: `%{property:CustomData[%{index}]}<br /> %<span style="font-weight: bold; font-size:13pt"></span>`,
            // Data: `%{property:CustomData[%{index}]}<br /><span color="red"style="font-weight: bold; font-size:13pt">%</span>`,
            FormattedUnitsPost: '%',
            Pointer: false,
            PositionStatic: false,
          },
          variant: { Value: 'donut' },
          line: { Width: 5 },
          exploded: 5,
          colorsStroke: 'rgba(0,0,0,0)',
          shadow: { Use: true },
          labels: {
            Data: data.colData,
            // Data : ['expr:(mon + " (Value:" + DxChart.numberFormat({ number: val})) + ")"'],
            Ingraph: true, // This is set to true when the animation ends
            IngraphFontStyle: 'bold 14px',
            IngraphBounding: false,
            IngraphBoundingFill: 'rgba(255,255,255,0.4)',
            List: false,
            Sticks: true,
            SticksLength: 40,
            SticksLineWidth: 1,
            StickStyle: 'line',
            SticksColors: ['#333333'],
          },
          key: {
            Data: data.colData,
            PositionGraphBoxed: false,
            Position: 'margin',

            PositionY: canvas.offsetHeight - 20 - 12,
          },
        },
      });
      pie.onclick = function (e, shape) {
        alert('index:' + shape.index + ' label:' + shape.label);
        // history.push('reval', 'A');
        history.push({
          pathname: 'reval',
          state: { userCell: '12' },
        });

        // const navigate = useNavigate();
        // navigate(`/occupation/risk/reval`, { state: { keys: '1' } });
      };
      pie.draw();

      // bar and line 차트
    } else {
      const data = {
        // 위험도 구분
        colData: [],
        // 건수
        revalCntData: [],
        // 완료
        revalCompleteData: [],
        // 진행중
        revalProgressData: [],
        // 집행률
        revalPctgData: [],
        // label
        labelData: [],
        // label
        labelData2: [],
        labelData5: [],

        row1: [],
        row2: [],
        row3: [],
        row4: [],

        row11: [],
        row22: [],
        row33: [],
        row44: [],
      };

      const arryData = [];

      const arryData5 = [];

      const arryData3 = {
        revalCntData: [],
        revalCompleteData: [],
        revalProgressData: [],
        revalPctgData: [],
      };
      const arryData2 = {
        linedata: [],
      };

      chartList.map((chartData, targetIndex) => {
        data.labelData.push(chartData.revalNm);

        if (targetIndex == 0) {
          data.row1.push(chartData.revalCnt);
          data.row1.push(chartData.revalComplete);
          data.row1.push(chartData.revalProgress);
          data.row11.push(chartData.revalPctg);
        } else if (targetIndex == 1) {
          data.row2.push(chartData.revalCnt);
          data.row2.push(chartData.revalComplete);
          data.row2.push(chartData.revalProgress);
          data.row11.push(chartData.revalPctg);
        } else if (targetIndex == 2) {
          data.row3.push(chartData.revalCnt);
          data.row3.push(chartData.revalComplete);
          data.row3.push(chartData.revalProgress);
          data.row11.push(chartData.revalPctg);
        } else if (targetIndex == 3) {
          data.row4.push(chartData.revalCnt);
          data.row4.push(chartData.revalComplete);
          data.row4.push(chartData.revalProgress);
          data.row11.push(chartData.revalPctg);
        }
      });

      arryData.push(data.row1);
      arryData.push(data.row2);
      arryData.push(data.row3);
      arryData.push(data.row4);

      arryData5.push(data.row11);

      console.log('data.row1==>', data.row1);
      console.log('arryData막대값@#==>', arryData);
      console.log('처음arryData5@#==>', arryData5);

      DxChart.reset(cvs);

      const bar = new DxChartBar({
        id: cvs,
        elem: canvas,
        // labels: data.colData,
        data: arryData,

        revalCntData: data.revalCntData,
        revalCompleteData: data.revalCompleteData,
        revalProgressData: data.revalProgressData,
        revalPctgData: data.revalPctgData,
        options: {
          margin: {
            Left: 105,
            Right: 105,
            Top: 135,
            Inner: 30,
            Bottom: 82,
          },

          CustomData: data.revalCompleteData,

          tooltips: {
            Data: '%{value_formatted}',
            Effect: 'fade',
            Pointer: false,
            FormattedUnitsPost: '%',
          },

          xaxis: {
            Use: false,
            Labels: data.labelData,
            ScaleZerostart: true,
            Color: '#E2E2E2',
            LabelsOffsetY: 5,
            Tickmarks: false,
          },
          colorsStroke: 'white',
          linewidth: 2,
          shadow: {
            Offsetx: 1,
            Offsety: 0,
            Blur: 1,
          },
          background: { GridVlines: false, GridBorder: false },
          yaxis: {
            Use: false,
            Color: '#E2E2E2',
            LabelsOffsetX: -15,
            Tickmarks: false,
            ScaleMax: 100,
          },
          key: {
            Data: ['건수', '완료', '진행중', '% 증감율'],
            Colors: ['#87CEEB', '#6794DC', '#6666CC', '#FFA500'],
            PositionY: canvas.offsetHeight - 20 - 15,
          },
          // title: { Text: 'barCombinedLine', Y: 73 },
          combinedEffect: 'wave',
          //combinedEffectCallback: function () {$a('Finished the bar effect!')},
          combinedEffectOptions: '{frames: 90}',
        },
      });

      (bar.onclick = function (e, shape) {
        // alert('e:' + e);
        // const json = JSON.stringify(shape);

        alert('index:' + shape.index + ' label:' + shape.label);
        // history.push('reval', 'A');
      }),
        // }).wave();

        console.log('두번째');

      const data5 = {
        // 위험도 구분
        colData: [],
        // 건수
        revalCntData: [],
        // 완료
        revalCompleteData: [],
        // 진행중
        revalProgressData: [],
        // 집행률
        revalPctgData: [],
        // label
        labelData: [],
        // label
        labelData2: [],
        labelData5: [],
      };

      // console.log('arryData5##==>', arryData5);

      // Number(data.labelData2);
      const line = new DxChartLine({
        id: cvs,
        elem: canvas,
        // data: data.colData,
        data: arryData5,
        // labels: data.revalPctgData,
        // data: datas[0],
        options: {
          colors: ['#FFA500'],
          // colors: ['#000080'],
          spline: true,
          tickmarksStyle: 'filledcircle',
          yaxisScaleMax: 40,
          shadow: false,
          xaxis: false,
          yaxis: {
            Position: 'right',
            ScaleMax: 100,
            ScaleDecimals: 1,
            ScaleUnitsPost: '%',
            TickmarksLength: 7,
            Color: '#E2E2E2',
            LabelsOffsetX: 15,
          },
          combinedEffect: 'trace',
          combinedEffectOptions: '{frames: 90}',

          // tooltips: {
          //   Data: '%{value}',
          //   Effect: 'fade',
          //   Pointer: true,
          // },

          tooltips: {
            Data: `%{value}%<span style="font-weight: bold; font-size:13pt"></span>`,
            // Data: `%{property:CustomData[%{index}]}<br /><span color="red"style="font-weight: bold; font-size:13pt">%</span>`,
            // FormattedUnitsPost: '%',
            Pointer: false,
            PositionStatic: false,
          },

          // combinedEffectCallback: function () {$a('Finished the line effect!')},
          // tooltips: {
          //   Data: data.revalCntData,
          //   Effect: 'fade',
          //   Pointer: true,
          // },
        },
      });

      // line.onclick = function (e, shape) {
      //   // alert('e:' + e);
      //   // const json = JSON.stringify(shape);

      //   alert('index:' + shape.index + ' label:' + shape.label);
      //   // history.push('reval', 'A');
      // };

      const combo = new DxChart.CombinedChart(bar, line);
      combo.draw();
      line.set('yaxis', true);
      line.set('yaxisScale', true);
      // pie.onclick = function (e, shape) {
      //   alert('index:' + shape.index + ' label:' + shape.label);
      // };
      // pie.draw();
    }
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function RevalDataList() {
  const state = RevalDataListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      {
        field: 'prtnrREvalSectCd',
        headerName: '부문',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC001',
        },
      },
      { field: 'prtnrREvalEvalYear', headerName: '건수', flex: 1 },
      { field: 'prtnrREvalEvalYear', headerName: '백분율', flex: 1 },
    ])
  );
  const { enterSearch, searchParam, list, goAddPage, changeSearchInput, clear } = state;
  const {
    // 년도
    searchYear,
    // 구분
    searchGubun,
  } = searchParam;

  // 그리드 더블 클릭
  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;

    console.log('data===>', data);

    // id
    // const detailId = data.prtnrREvalId;
    // goDetailPage(detailId);
  }, []);

  useEffect(() => {
    chkSearch();
    return clear;
  }, []);

  // const navigate = useNavigate();
  // navigate(`/occupation/risk/reval`, { state: { keys: '1' } });

  // 년도 필수 체크
  const validCheck = () => {
    // 해당연도 필수 체크
    if (searchParam.searchYear == '' || searchParam.searchYear == null) {
      alert('검색조건 해당연도는 필수 입니다.');
      return false;
    }

    // 해당연도 필수 체크
    if (searchParam.searchGubun == '' || searchParam.searchGubun == null) {
      alert('검색조건 구분은 필수 입니다.');
      return false;
    }

    // 조회
    chkSearch();
  };

  // 조회 체크
  const chkSearch = () => {
    // 조회조건 구분
    const searchGubun = searchParam.searchGubun;

    if (searchGubun === 'A') {
      console.log('위험성평가');
      setColumns(
        CommonUtil.mergeColumnInfosByLocal([
          {
            field: 'sectCd',
            headerName: '부문',
            flex: 1,
            cellRenderer: CodeLabelComponent,
            cellRendererParams: {
              codeGrpId: 'CODE_GRP_OC001',
            },
          },
          { field: 'revalCnt', headerName: '건수', flex: 1 },
          { field: 'revalPctg', headerName: '백분율', flex: 1 },
        ])
      );
    } else {
      console.log('개선진행');
      setColumns(
        CommonUtil.mergeColumnInfosByLocal([
          { field: 'revalScore', headerName: '위험성크기(점수)', flex: 1 },
          { field: 'revalNm', headerName: '위험성크기(명칭)', flex: 1 },
          { field: 'revalCnt', headerName: '건수', flex: 1 },
          { field: 'revalComplete', headerName: '완료', flex: 1 },
          { field: 'revalProgress', headerName: '진행중', flex: 1 },
          { field: 'revalPctg', headerName: '진척률', flex: 1 },
        ])
      );
    }
    enterSearch();
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>중요위험 관리</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        <div id="" className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid-300">
              <div className="form-group wid100">
                <AppDatePicker
                  label={'년도'}
                  pickerType="year"
                  value={searchYear}
                  onChange={(value) => {
                    changeSearchInput('searchYear', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid-300">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'구분'}
                  codeGrpId="CODE_GRP_OC027"
                  value={searchGubun}
                  onChange={(value) => {
                    changeSearchInput('searchGubun', value);
                  }}
                />
              </div>
            </div>
            <div className="btn-area">
              {/* <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}> */}
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={validCheck}>
                조회
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="table-wrap">
        {/*그래프 영역 */}
        <div className="left-table graph" id="chartMaker">
          그래프 영역
        </div>

        {/*그리드영역 */}
        <div className="right-table">
          <h3 className="table-tit">위험성 평가 현황</h3>
          <AppTable
            rowData={list}
            columns={columns}
            setColumns={setColumns}
            store={state}
            handleRowDoubleClick={handleRowDoubleClick}
            hiddenTableHeader
            hiddenPagination
          />
        </div>
      </div>
    </>
  );
}

export default RevalDataList;
