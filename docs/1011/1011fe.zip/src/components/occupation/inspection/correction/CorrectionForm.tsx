import { useEffect } from 'react';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
// import { useStore } from 'zustand';
// import useAppStore from '@/stores/useAppStore';
// import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTextInput from '@/components/common/AppTextInput';
import useOcuCheckContentFormStore from '@/stores/occupation/inspection/useOcuCheckContentFormStore';

function OcuCheckContentForm() {
  const state = useOcuCheckContentFormStore();
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } = state;
  const {
    chkItemNm,
    chkLclsCd,
    chkScls,
    chkContent,
    chkRelLaw,
    chkPohtoId1,
    chkPohtoId2,
    chkFile,
    rightActionYn,
    actionStatusCd,
    actionContent,
    actionAttPhotoId,
    actionAttFileId,
    actionDt,
    actionDeptCd,
    actionEmpno,
    aprvDt,
    aprvDeptCd,
    aprvEmpno,
  } = formValue;

  const { detailId } = useParams();

  //const profile = useStore(useAppStore, (state) => state.profile);
  // 사용자 ID
  //const regUserId = profile.userInfo.userId;
  // 사용자명
  //const nameKor = profile.userInfo.nameKor;
  // 사용자 부서
  //const deptCd = profile.userInfo.deptCd;
  // 오늘일자
  //const toDate = CommonUtil.getToDate();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>통합개선관리</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkItemNm"
                name="chkItemNm"
                label="점검_항목_명"
                value={chkItemNm}
                onChange={(value) => changeInput('chkItemNm', value)}
                errorMessage={errors.chkItemNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkLclsCd"
                name="chkLclsCd"
                label="점검_대분류_코드"
                value={chkLclsCd}
                onChange={(value) => changeInput('chkLclsCd', value)}
                errorMessage={errors.chkLclsCd}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkScls"
                name="chkScls"
                label="점검_소분류_코드"
                value={chkScls}
                onChange={(value) => changeInput('chkScls', value)}
                errorMessage={errors.chkScls}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkContent"
                name="chkContent"
                label="점검_내용"
                value={chkContent}
                onChange={(value) => changeInput('chkContent', value)}
                errorMessage={errors.chkContent}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkRelLaw"
                name="chkRelLaw"
                label="점검_관계법령"
                value={chkRelLaw}
                onChange={(value) => changeInput('chkRelLaw', value)}
                errorMessage={errors.chkRelLaw}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkPohtoId1"
                name="chkPohtoId1"
                label="점검_첨부_사진_ID1"
                value={chkPohtoId1}
                onChange={(value) => changeInput('chkPohtoId1', value)}
                errorMessage={errors.chkPohtoId1}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkPohtoId2"
                name="chkPohtoId2"
                label="점검_첨부_사진_ID2"
                value={chkPohtoId2}
                onChange={(value) => changeInput('chkPohtoId2', value)}
                errorMessage={errors.chkPohtoId2}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormchkFile"
                name="chkFile"
                label="점검_첨부_파일"
                value={chkFile}
                onChange={(value) => changeInput('chkFile', value)}
                errorMessage={errors.chkFile}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormrightActionYn"
                name="rightActionYn"
                label="즉시_조치_여부"
                value={rightActionYn}
                onChange={(value) => changeInput('rightActionYn', value)}
                errorMessage={errors.rightActionYn}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionStatusCd"
                name="actionStatusCd"
                label="조치_상태_코드"
                value={actionStatusCd}
                onChange={(value) => changeInput('actionStatusCd', value)}
                errorMessage={errors.actionStatusCd}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionContent"
                name="actionContent"
                label="조치_내용"
                value={actionContent}
                onChange={(value) => changeInput('actionContent', value)}
                errorMessage={errors.actionContent}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionAttPhotoId"
                name="actionAttPhotoId"
                label="조치_첨부_사진_ID"
                value={actionAttPhotoId}
                onChange={(value) => changeInput('actionAttPhotoId', value)}
                errorMessage={errors.actionAttPhotoId}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionAttFileId"
                name="actionAttFileId"
                label="조치_첨부_파일_ID"
                value={actionAttFileId}
                onChange={(value) => changeInput('actionAttFileId', value)}
                errorMessage={errors.actionAttFileId}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionDt"
                name="actionDt"
                label="조치_일자"
                value={actionDt}
                onChange={(value) => changeInput('actionDt', value)}
                errorMessage={errors.actionDt}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionDeptCd"
                name="actionDeptCd"
                label="조치_부서_코드"
                value={actionDeptCd}
                onChange={(value) => changeInput('actionDeptCd', value)}
                errorMessage={errors.actionDeptCd}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormactionEmpno"
                name="actionEmpno"
                label="조치자_사번"
                value={actionEmpno}
                onChange={(value) => changeInput('actionEmpno', value)}
                errorMessage={errors.actionEmpno}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormaprvDt"
                name="aprvDt"
                label="승인_일자"
                value={aprvDt}
                onChange={(value) => changeInput('aprvDt', value)}
                errorMessage={errors.aprvDt}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormaprvDeptCd"
                name="aprvDeptCd"
                label="승인_부서_코드"
                value={aprvDeptCd}
                onChange={(value) => changeInput('aprvDeptCd', value)}
                errorMessage={errors.aprvDeptCd}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckContentFormaprvEmpno"
                name="aprvEmpno"
                label="승인자_사번"
                value={aprvEmpno}
                onChange={(value) => changeInput('aprvEmpno', value)}
                errorMessage={errors.aprvEmpno}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuCheckContentForm;
