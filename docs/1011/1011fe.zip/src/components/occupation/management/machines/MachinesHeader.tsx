import AppNavigation from '@/components/common/AppNavigation';
import useOcuMachinesManageStore from '@/stores/occupation/management/useOcuMachinesManageStore';
import { useEffect } from 'react';

function MachinesHeader() {
  const { tabIndex, changeTab, clear } = useOcuMachinesManageStore();

  useEffect(() => {
    changeTab(0);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>{tabIndex == 0 ? '위험기계기구 현황' : '위험기계기구 조회'}</h2>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="menu-tab">
          <a
            onClick={() => {
              changeTab(0);
            }}
            className={tabIndex == 0 ? 'active' : ''}
            data-label="현황"
            href={undefined}
          >
            현황
          </a>
          <a onClick={() => changeTab(1)} className={tabIndex == 1 ? 'active' : ''} data-label="조회">
            조회
          </a>
        </div>
      </div>
    </>
  );
}

export default MachinesHeader;
