import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';
import AppTextInput from '@/components/common/AppTextInput';

const formName = 'OcuQsuppEvalTargetForm';

/* yup validation */
const yupFormSchema = yup.object({
  qsuppTargetId: yup.number().required(),
  qsuppId: yup.number().required(),
  evalYear: yup.number().required(),
  evalDeptCd: yup.string().required(),
  regDttm: yup.string().required(),
  regUserId: yup.string().required(),
  updDttm: yup.string().required(),
  updUserId: yup.string().required(),
});

/* form 초기화 */
const initFormValue = {
  qsuppTargetId: null,
  qsuppId: null,
  evalYear: null,
  evalDeptCd: "",
  regDttm: "",
  regUserId: "",
  updDttm: "",
  updUserId: "",
};

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuQsuppEvalTargetFormModal(props) {

  const { isOpen, closeModal, detailInfo, ok } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});
  const [isDirty, setIsDirty] = useState(false);

  const {  qsuppTargetId, qsuppId, evalYear, evalDeptCd, regDttm, regUserId, updDttm, updUserId, } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
    setIsDirty(true);
  };

  const save = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;
    if (success) {
      // TODO : 모달 최종 저장시 액션 정의
      ok(formValue);
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  useEffect(() => {
    // TODO : isOpen일 경우에 상세 api 호출 할지 결정 : if(isOpen)
    if (isOpen) {
      if (detailInfo) {
        setFormValue(detailInfo);
      } else {
        setFormValue({ ...initFormValue });
      }
    }
  }, [isOpen, detailInfo]);

  return (
    <>
      <Modal
        shouldCloseOnOverlayClick={false}
        isOpen={isOpen}
        ariaHideApp={false}
        overlayClassName={'alert-modal-overlay'}
        className={'list-common-modal-content'}
        onRequestClose={() => {
          closeModal();
        }}
      >
        <div className="popup-container">
          <h3 className="pop_title">TODO : 모달 타이틀</h3>
          <div className="pop_full_cont_box">
            <div className="pop_flex_group">
              <div className="pop_cont_form">
                <div className="editbox">
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          inputType="number"
                          id="OcuQsuppEvalTargetFormqsuppTargetId"
                          name="qsuppTargetId"
                          label="적격수급업체_평가대상_ID"
                          value={qsuppTargetId}
                          onChange={(value) => changeInput('qsuppTargetId', value)}
                          errorMessage={errors.qsuppTargetId}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuQsuppEvalTargetFormqsuppId"
                          name="qsuppId"
                          label="적격수급업체_ID"
                          value={qsuppId}
                          onChange={(value) => changeInput('qsuppId', value)}
                          errorMessage={errors.qsuppId}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuQsuppEvalTargetFormevalYear"
                          name="evalYear"
                          label="평가_년도"
                          value={evalYear}
                          onChange={(value) => changeInput('evalYear', value)}
                          errorMessage={errors.evalYear}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuQsuppEvalTargetFormevalDeptCd"
                          name="evalDeptCd"
                          label="평가_부서_코드"
                          value={evalDeptCd}
                          onChange={(value) => changeInput('evalDeptCd', value)}
                          errorMessage={errors.evalDeptCd}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuQsuppEvalTargetFormregDttm"
                          name="regDttm"
                          label="등록_일시"
                          value={regDttm}
                          onChange={(value) => changeInput('regDttm', value)}
                          errorMessage={errors.regDttm}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuQsuppEvalTargetFormregUserId"
                          name="regUserId"
                          label="등록자_ID"
                          value={regUserId}
                          onChange={(value) => changeInput('regUserId', value)}
                          errorMessage={errors.regUserId}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuQsuppEvalTargetFormupdDttm"
                          name="updDttm"
                          label="수정_일시"
                          value={updDttm}
                          onChange={(value) => changeInput('updDttm', value)}
                          errorMessage={errors.updDttm}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuQsuppEvalTargetFormupdUserId"
                          name="updUserId"
                          label="수정자_ID"
                          value={updUserId}
                          onChange={(value) => changeInput('updUserId', value)}
                          errorMessage={errors.updUserId}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                </div>
              </div>
            </div>
          </div>
          {/* 하단 버튼 영역 */}
          <div className="pop_btns">
            <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
              취소
            </button>
            <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
              확인
            </button>
          </div>
          <span className="pop_close" onClick={closeModal}>
            X
          </span>
        </div>
      </Modal>
    </>
  );
}
export default OcuQsuppEvalTargetFormModal;
