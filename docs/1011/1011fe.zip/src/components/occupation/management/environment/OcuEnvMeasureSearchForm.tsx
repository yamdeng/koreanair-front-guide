import AppTable from "@/components/common/AppTable";
import { createListSlice, listBaseState } from "@/stores/slice/listSlice";
import AppTextInput from '@/components/common/AppTextInput';

function OcuEnvMeasureSearchForm() {
  const state = useOcuEnvMeasureListStore();

  const {  msrId, msrYear, halfYearCd, msrClsCd, areaCd, msrStartDt, msrEndDt, msrInstt, msrResult, opnn, resultFileId, chmclFileId, regDttm, regUserId, updDttm, updUserId, } = searchParam;

  return (
    <>
      {/* TODO : 검색 input 영역입니다 */}
      
      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                label="측정_ID"
                value={msrId}
                onChange={(value) => {
                  changeSearchInput('msrId', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="측정_년도"
                value={msrYear}
                onChange={(value) => {
                  changeSearchInput('msrYear', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="반기_코드"
                value={halfYearCd}
                onChange={(value) => {
                  changeSearchInput('halfYearCd', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="측정_구분_코드"
                value={msrClsCd}
                onChange={(value) => {
                  changeSearchInput('msrClsCd', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="권역_코드"
                value={areaCd}
                onChange={(value) => {
                  changeSearchInput('areaCd', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="측정_시작_일자"
                value={msrStartDt}
                onChange={(value) => {
                  changeSearchInput('msrStartDt', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="측정_종료_일자"
                value={msrEndDt}
                onChange={(value) => {
                  changeSearchInput('msrEndDt', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="측정_기관"
                value={msrInstt}
                onChange={(value) => {
                  changeSearchInput('msrInstt', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="측정_결과"
                value={msrResult}
                onChange={(value) => {
                  changeSearchInput('msrResult', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="의견"
                value={opnn}
                onChange={(value) => {
                  changeSearchInput('opnn', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                label="결과_첨부_파일_ID"
                value={resultFileId}
                onChange={(value) => {
                  changeSearchInput('resultFileId', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                label="화학_첨부_파일_ID"
                value={chmclFileId}
                onChange={(value) => {
                  changeSearchInput('chmclFileId', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="등록_일시"
                value={regDttm}
                onChange={(value) => {
                  changeSearchInput('regDttm', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="등록자_ID"
                value={regUserId}
                onChange={(value) => {
                  changeSearchInput('regUserId', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="수정_일시"
                value={updDttm}
                onChange={(value) => {
                  changeSearchInput('updDttm', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="수정자_ID"
                value={updUserId}
                onChange={(value) => {
                  changeSearchInput('updUserId', value);
                }}
              />
            </div>
          </div>             
        </div>     
        <div className="btn-area">
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            조회
          </button>
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            초기화
          </button>
        </div> 
      </div>
            
    </>
  );
}
export default OcuEnvMeasureSearchForm;
