import Modal from 'react-modal';
import Image001 from '@/resources/images/img001.png';
import Image002 from '@/resources/images/img002.png';
import Image003 from '@/resources/images/img003.png';
import Image004 from '@/resources/images/img004.png';
import Image005 from '@/resources/images/img005.png';
import Image006 from '@/resources/images/img006.png';

function WorkPermitDeviceChecklistAttachment(props) {
  const { isOpen, closeModal } = props;

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">첨부파일 안내문</h3>
        <span className="txt-guide">※ 모든 증빙자료는 신청일을 기준으로 유효한 상태여야함</span>
        <div className="pop_cont pb_0">
          <div className="editbox">
            <table className="pop-img-table">
              <tr>
                <td>
                  <ul>
                    <li>
                      <img src={Image001} className="pop-img-size" alt="차량탑재형 고소작업대 (스카이)" />
                    </li>
                    <li className="img-tit">차량탑재형 고소작업대 (스카이)</li>
                  </ul>
                </td>
                <td>
                  <ul>
                    <li>- 자동차등록증</li>
                    <li>- 안전검사합격증명서</li>
                    <li>- 기능기운전기능사 또는 교육기관 교육 이수</li>
                    <li>- 화물운전 종사 자격증</li>
                  </ul>
                </td>
              </tr>

              <tr>
                <td>
                  <ul>
                    <li>
                      <img src={Image002} className="pop-img-size" alt="시저형 고소작업대 (렌탈)" />
                    </li>
                    <li className="img-tit">시저형 고소작업대 (렌탈)</li>
                  </ul>
                </td>
                <td>
                  <ul>
                    <li> - 안전인증서</li>
                  </ul>
                </td>
              </tr>

              <tr>
                <td>
                  <ul>
                    <li>
                      <img src={Image003} className="pop-img-size" alt="이동식 크레인 (카고크레인)" />
                    </li>
                    <li className="img-tit">이동식 크레인 (카고크레인)</li>
                  </ul>
                </td>
                <td>
                  <ul>
                    <li>- 자동차등록증</li>
                    <li>- 안전검사합격증명서</li>
                    <li>- 기능기운전기능사 또는 교육기관 교육 이수</li>
                    <li>- 화물운전 종사 자격증</li>
                  </ul>
                </td>
              </tr>

              <tr>
                <td>
                  <ul>
                    <li>
                      <img src={Image004} className="pop-img-size" alt="기중기 (크레인)" />
                    </li>
                    <li className="img-tit">기중기 (크레인)</li>
                  </ul>
                </td>
                <td rowSpan={3}>
                  <ul>
                    <li>- 건설기계등록증</li>
                    <li>- 건설기계조종사 면허증</li>
                    <li>- 건설기계조종사 안전교육 이수증</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>
                  <ul>
                    <li>
                      <img src={Image005} className="pop-img-size" alt="굴착기 (굴삭기, 포크레인, 백호우)" />
                    </li>
                    <li className="img-tit">굴착기 (굴삭기, 포크레인, 백호우)</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>
                  <ul>
                    <li>
                      <img src={Image006} className="pop-img-size" alt="지게차" />
                    </li>
                    <li className="img-tit">지게차</li>
                  </ul>
                </td>
              </tr>
            </table>
          </div>
        </div>

        <div className="pop_btns mt-20">
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={closeModal}>
            확인
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default WorkPermitDeviceChecklistAttachment;
