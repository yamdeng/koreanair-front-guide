import { create } from "zustand";
import { formBaseState, createFormSliceYup } from "@/stores/slice/formSlice";
import * as yup from "yup";

/* yup validation */
const yupFormSchema = yup.object({
  mgntSprvEvalId: yup.number().required(),
  sectCd: yup.string(),
  deptCd: yup.string(),
  evalYear: yup.string(),
  qrtrYearCd: yup.string(),
  title: yup.string(),
  evalSubjEmpno: yup.string(),
  evalEmpno: yup.string(),
  fileId: yup.number(),
  linkId: yup.number(),
  remark: yup.string(),
  regDttm: yup.string().required(),
  regUserId: yup.string().required(),
  updDttm: yup.string().required(),
  updUserId: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  
  mgntSprvEvalId: null,
  sectCd: "",
  deptCd: "",
  evalYear: "",
  qrtrYearCd: "",
  title: "",
  evalSubjEmpno: "",
  evalEmpno: "",
  fileId: null,
  linkId: null,
  remark: "",
  regDttm: "",
  regUserId: "",
  updDttm: "",
  updUserId: "",
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'TODO : api path',
  baseRoutePath: 'TODO : UI route path',
  formName: 'OcuSprvEvalForm',
  formValue: {
    ...initFormValue,
  }
};

/* zustand store 생성 */
const useOcuSprvEvalFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuSprvEvalFormStore