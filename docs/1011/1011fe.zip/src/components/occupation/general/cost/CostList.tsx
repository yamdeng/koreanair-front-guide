import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDeptListSelectInput from '@/components/common/AppDeptListSelectInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import AppSelect from '@/components/common/AppSelect';
import _ from 'lodash';

import history from '@/utils/history';
/* TODO : store 경로를 변경해주세요. */

const currentYear = new Date().getFullYear().toString();

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/general/cost',
  baseRoutePath: '/occupation/general/costList',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 년도
  planYear: currentYear,
  // Department
  planSectCd: '',
  // Cost Center
  planCostCenter: '',
  // Item
  planItemCd: '',
  // Account Name
  planAcntCd: '',
};

/* zustand store 생성 */
const OcuCostExecListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  // //from 상세 조회
  // goDetailPage: async (keyData) => {
  //   const { baseRoutePath } = get();

  //   const queryParams = CommonUtil.objectToQueryString({
  //     planYear: keyData.planYear,
  //     sectCd: keyData.sectCd,
  //     searchplanCostCenter: keyData.planCostCenter,
  //     planItemCd: keyData.planItemCd,
  //     planAcntCd: keyData.planAcntCd,
  //   });

  //   history.push(`${baseRoutePath}/view${queryParams}`);
  // },

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    // 년도
    planYear: currentYear,
    // Department
    planSectCd: '',
    // Resp Center
    planCostCenter: '',
    // Item
    planItemCd: '',
    // Account Name
    planAcntCd: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  // goAddPage: () => {
  //   const { baseRoutePath } = get();
  //   console.log(`이곳에값==>, ${baseRoutePath}`);
  //   history.push(`${baseRoutePath}/insert`);
  // },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));
function OcuCostExecList() {
  const state = OcuCostExecListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'planYear', headerName: '년도' },
      { field: 'planSectNm', headerName: '본부' },
      { field: 'planCostCenterNm', headerName: '부서' },
      { field: 'planItemNm', headerName: '항목' },
      { field: 'planAcntCd', headerName: '계정' },
      { field: 'planAcntNm', headerName: '계정명' },
      { field: 'planPayTermNm', headerName: '주기' },
      { field: 'planAmt', headerName: '금액', valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'planTotAmt', headerName: '총 금액', valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'planDesc', headerName: '내용' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    //initSearchInput,
    //isExpandDetailSearch,
    //toggleExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;

  // TODO : 검색 파라미터 나열
  const { planYear, planSectCd, planCostCenter, planItemCd, planAcntCd } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;

    console.log('data===>', data);

    // 산업안전보건 관리비 id
    const detailId = data.planYearId;
    goDetailPage(detailId);

    // 년도, 부문, 부서, account, Item
    // const keyData = {
    //   planYear: data.planYear,
    //   sectCd: data.sectCd,
    //   planCostCenter: data.planCostCenter,
    //   planItemCd: data.planItemCd,
    //   planAcntCd: data.planAcntCd,
    // };

    // //const detailId = data.ocuCommitId;
    // goDetailPage(keyData);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  const changeCostTap = () => {
    history.push('costState');
  };

  const changePerformanceTap = () => {
    history.push('costPerformanceList');
  };

  return (
    <>
      {/* <AppNavigation /> */}
      <div className="Breadcrumb">홈 / 안전경영 / 산업안전보건 관리비</div>
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>산업안전보건관리비 계획</h2>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="menu-tab">
          <a href={undefined} data-label="현황" onClick={changeCostTap}>
            현황
          </a>
          <a href={undefined} className="active" data-label="계획">
            계획
          </a>
          <a href={undefined} data-label="실적" onClick={changePerformanceTap}>
            실적
          </a>
        </div>
      </div>
      {/*//탭 */}
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDatePicker
                  label={'년도'}
                  pickerType="year"
                  value={planYear}
                  onChange={(value) => {
                    changeSearchInput('planYear', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="부문"
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC001"
                  value={planSectCd}
                  onChange={(value) => {
                    changeSearchInput('planSectCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSelect
                  label="Cost Center"
                  value={planCostCenter}
                  apiUrl={`ocu/general/lawRegInfo/selectLawDeptList`}
                  labelKey="nameKor"
                  valueKey="deptCd"
                  onChange={(value) => {
                    changeSearchInput('planCostCenter', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="item"
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC017"
                  value={planItemCd}
                  onChange={(value) => {
                    changeSearchInput('planItemCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="Account Name"
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC045"
                  value={planAcntCd}
                  onChange={(value) => {
                    changeSearchInput('planAcntCd', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button type="button" name="button" className="arrow button _control active">
          <span className="hide">접기</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default OcuCostExecList;
