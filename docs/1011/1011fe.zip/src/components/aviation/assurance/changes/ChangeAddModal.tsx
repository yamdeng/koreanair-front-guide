import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppEditor from '@/components/common/AppEditor';
import AppEditorViewer from '@/components/common/AppEditorViewer';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppTextInput from '@/components/common/AppTextInput';
import LinkAttachModal from '@/components/modal/LinkAttachModal';
import { FORM_TYPE_ADD } from '@/config/CommonConstant';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import dayjs from 'dayjs';
import { produce } from 'immer';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import Modal from 'react-modal';
import * as yup from 'yup';
import { create } from 'zustand';

/* yup validation */
const yupFormSchema = yup.object({
  changeMgmtYear: yup.string().required(),
  searchDivisionCdarr: yup.array().nullable('부문은 필수 입력 항목 입니다.'), //부문
  fromDt: yup.string().required(),
  toDt: yup.string().required(),
  changeTxtcn: yup.string().required(),
  subjectNm: yup.string().required(),
  linkGroupSeq: yup.number().nullable(),
  fileGroupSeq: yup.number().nullable(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  changeMgmtYear: '' + dayjs().year(),
  searchDivisionCdarr: [],
  empNo: '',
  fromDt: '',
  toDt: '',
  changeTxtcn: '',
  subjectNm: '',
  changeMgmtStatusCd: '10',
  linkGroupSeq: null,
  fileGroupSeq: null,
  linkAttachList: [],
  isLinkAttachModalOpen: false,
  linkAttachDetailInfo: null,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/assurance/changes',
  baseRoutePath: '/aviation/changes/ChangeManageEdit',
  formName: 'useChangeAddModalStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useChangeAddModalStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  openLinkAttachModal: (detailInfo = null, linkAttachListLindex = -1) => {
    set({ isLinkAttachModalOpen: true, linkAttachDetailInfo: detailInfo, linkAttachListLindex: linkAttachListLindex });
  },

  closeLinkAttachModal: () => {
    set({ isLinkAttachModalOpen: false });
  },

  okLinkAttachModal: (linkAttachFormValue, linkAttachListLindex) => {
    set(
      produce((state: any) => {
        if (linkAttachListLindex != -1) {
          const newFormValue = { ...state.formValue };
          newFormValue.linkAttachList[linkAttachListLindex] = linkAttachFormValue;

          state.formValue = newFormValue;
          state.isLinkAttachModalOpen = false;
        } else {
          const newFormValue = { ...state.formValue };
          newFormValue.linkAttachList.push(linkAttachFormValue);

          state.formValue = newFormValue;
          state.isLinkAttachModalOpen = false;
        }
      })
    );
  },

  removeLinkAttach: (removeIndex) => {
    set(
      produce((state: any) => {
        const newFormValue = { ...state.formValue };
        newFormValue.linkAttachList.splice(removeIndex, 1);
        state.formValue = newFormValue;
      })
    );
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

function ChangeAddModal(props) {
  // 언어 설정
  const { t } = useTranslation();

  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    remove,
    cancel,
    clear,
    getApiParam,
    formDetailId,
    formApiPath,
    validate,
    openLinkAttachModal,
    isLinkAttachModalOpen,
    closeLinkAttachModal,
    linkAttachDetailInfo,
    okLinkAttachModal,
    removeLinkAttach,
    linkAttachListLindex,
    //  isDisabledAction,
    enterSearch,
  } = useChangeAddModalStore();

  const {
    changeMgmtYear,
    searchDivisionCdarr,
    empNo,
    fromDt,
    toDt,
    changeTxtcn,
    subjectNm,
    linkGroupSeq,
    fileGroupSeq,
    changeMgmtStatusCd,
    linkAttachList,
  } = formValue;

  const { isOpen, closeModal, ok, rowData } = props;

  useFormDirtyCheck(isDirty);

  const tempSave = async () => {
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          if (formType === FORM_TYPE_ADD) {
            await ApiService.post(`${formApiPath}`, apiParam);
          } else {
            await ApiService.put(`${formApiPath}/${formDetailId}`, apiParam);
          }
          clear();
          ToastService.success('저장되었습니다.');
          ok();
          closeModal();
        },
      });
    }
  };

  const submit = async () => {
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '제출하시겠습니까?',
        ok: async () => {
          changeInput('changeMgmtStatusCd', '20');
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          if (formType === FORM_TYPE_ADD) {
            await ApiService.post(`${formApiPath}`, apiParam);
          } else {
            await ApiService.put(`${formApiPath}/${formDetailId}`, apiParam);
          }
          clear();
          ToastService.success('제출되었습니다.');
          ok();
          closeModal();
        },
      });
    }
  };

  useEffect(() => {
    console.log('rowData : ', rowData);
    if (isOpen && rowData.changeMgmtId) {
      getDetail(rowData.changeMgmtId);
    }
    return clear;
  }, [isOpen, rowData.changeMgmtId]);
  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">변화관리 {formType === FORM_TYPE_ADD ? '추가' : '수정'}</h3>
        <div className="pop_cont">
          <div className="editbox">
            <div className="form-table ">
              <div className="form-cell wid50">
                <div className="form-group wid30">
                  <AppDatePicker
                    label="연도"
                    value={changeMgmtYear}
                    onChange={(value) => {
                      changeInput('changeMgmtYear', value);
                    }}
                    pickerType="year"
                    disabled={changeMgmtStatusCd === '10' ? false : true}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppCodeSelect
                    id="PSPIReportModalsearchDivisionCdarr"
                    label={'소관부문'}
                    codeGrpId="CODE_GRP_326"
                    value={searchDivisionCdarr}
                    required
                    errorMessage={errors.searchDivisionCdarr}
                    isMultiple={true}
                    disabled={changeMgmtStatusCd === '10' ? false : true}
                    onChange={(value) => {
                      changeInput('searchDivisionCdarr', value);
                    }}
                  />
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppDatePicker
                    label={'변화관리 시작일'}
                    pickerType="date"
                    value={fromDt}
                    onChange={(value) => {
                      changeInput('fromDt', value);
                    }}
                    disabled={changeMgmtStatusCd === '10' ? false : true}
                    required
                  />
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppDatePicker
                    label={'변화관리 종료일'}
                    pickerType="date"
                    value={toDt}
                    onChange={(value) => {
                      changeInput('toDt', value);
                    }}
                    disabled={changeMgmtStatusCd === '10' ? false : true}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    id="AvnNoticesListFormStoresubjectNm"
                    name="subjectKoNm"
                    label="변화관리 주제"
                    value={subjectNm}
                    onChange={(value) => changeInput('subjectNm', value)}
                    errorMessage={errors.subjectNm}
                    disabled={changeMgmtStatusCd === '10' ? false : true}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="group-box-wrap1 wid100 ">
                  {/*내용 */}
                  {changeMgmtStatusCd === '10' ? (
                    <AppEditor
                      label="AppEditor"
                      value={changeTxtcn}
                      viewer={true}
                      onChange={(value) => changeInput('changeTxtcn', value)}
                    />
                  ) : (
                    <AppEditorViewer label="AppEditor" value={changeTxtcn} />
                  )}
                </div>
              </div>
            </div>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* 파일첨부영역 : drag */}
                  <AppFileAttach
                    label={t('ke.safety.Notice.label.00007')}
                    fileGroupSeq={fileGroupSeq}
                    workScope={'A'}
                    mode={changeMgmtStatusCd === '10' ? 'edit' : 'view'}
                    updateFileGroupSeq={(newFileGroupSeq) => {
                      changeInput('fileGroupSeq', newFileGroupSeq);
                    }}
                    errorMessage={errors.fileGroupSeq}
                  />
                </div>
              </div>
            </div>

            <hr className="line dp-n"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="group-box-wrap line wid100">
                  <span className="txt">링크 첨부</span>
                  {/* 링크팝업명: MU1P5detail2Modal */}
                  <button type="button" name="button" className="btn-plus" onClick={() => openLinkAttachModal()}>
                    추가
                  </button>
                  <div className="file-link">
                    {linkAttachList
                      ? linkAttachList.map((linkInfo, linkAttachListLindex) => {
                          const { linkUrl, linkSbj } = linkInfo;
                          return (
                            <div key={linkUrl} className="link-box">
                              <a href={undefined} onClick={() => openLinkAttachModal(linkInfo, linkAttachListLindex)}>
                                {linkSbj}
                              </a>
                              <a href={undefined} onClick={() => removeLinkAttach(linkAttachListLindex)}>
                                <span className="close-btn">close</span>
                              </a>
                            </div>
                          );
                        })
                      : null}
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <LinkAttachModal
              isOpen={isLinkAttachModalOpen}
              closeModal={closeLinkAttachModal}
              ok={okLinkAttachModal}
              detailInfo={linkAttachDetailInfo}
              linkAttachListLindex={linkAttachListLindex}
            />
          </div>
        </div>
        <div className="pop_btns">
          {changeMgmtStatusCd === '10' ? (
            <>
              <button className="btn_text text_color_neutral-10 btn_confirm" onClick={tempSave}>
                저장
              </button>
              <button className="btn_text text_color_neutral-10 btn_confirm" onClick={submit}>
                제출
              </button>
              <button className="btn_text text_color_neutral-90 btn_close" onClick={remove}>
                삭제
              </button>
            </>
          ) : (
            <></>
          )}
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            닫기
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default ChangeAddModal;
