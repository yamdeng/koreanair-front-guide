import AppEditorViewer from '@/components/common/AppEditorViewer';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import dayjs from 'dayjs';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import { create } from 'zustand';

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/assurance/spi-spt/bulletins',
  baseRoutePath: '/aviation/spi-spt/spiBoardList',
};

/* zustand store 생성 */
const AvnSPIBoardDetailFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,
}));

function SPIBoardDetail() {
  //언어설정
  const { t } = useTranslation();

  const navigate = useNavigate();

  /* formStore state input 변수 */
  const { detailInfo, getDetail, cancel, clear } = AvnSPIBoardDetailFormStore();
  const { subjectKoNm, popupFromDt, popupToDt, fileGroupSeq, boardTxtcn } = detailInfo;

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>게시판 상세</h2>
      </div>
      {/*상세페이지*/}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid30">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      제목 <span className="required">*</span>
                    </label>
                    <span className="text-desc-type1">{subjectKoNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      게시기간 <span className="required">*</span>
                    </label>
                    <span className="text-desc-type1">
                      {dayjs(popupFromDt).format('YYYY-MM-DD')} ~ {dayjs(popupToDt).format('YYYY-MM-DD')}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      내용 <span className="required">*</span>
                    </label>
                    <AppEditorViewer value={boardTxtcn} />
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">첨부파일</label>
                    <span className="text-desc-type1">
                      <AppFileAttach mode="view" fileGroupSeq={fileGroupSeq} disabled={true} />
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/*//상세페이지*/}

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text btn_list" onClick={cancel}>
          목록
        </button>
      </div>
      {/*//하단버튼영역*/}
    </>
  );
}

export default SPIBoardDetail;
