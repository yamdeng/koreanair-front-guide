import Modal from 'react-modal';
import { useState, useEffect } from 'react';
import AppTextInput from '@/components/common/AppTextInput';
import AppCheckbox from '@/components/common/AppCheckbox';
import ModalService from '@/services/ModalService';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';

const formName = 'ChapterUpdModal';

/* yup validation */
const yupFormSchema = yup.object({
  chapterName: yup.string().required(),
});

/* form 초기화 */
const initFormValue = {
  chapterName: '',
  revisionUpdate: true,
};

function ChapterUpdModal(props) {
  const { isOpen, detailInfo, closeModal, ok } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});
  //const [checkboxValue, setCheckboxValue] = useState(true);
  const { chapterName, revisionUpdate } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
  };

  const handleClose = () => {
    setErrors({});
    setFormValue({ ...initFormValue });
    closeModal();
  };

  const handleOk = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;
    if (success) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        okLabel: '저장',
        ok: () => {
          ok(formValue);
        },
      });
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  useEffect(() => {
    if (isOpen && detailInfo) {
      const { chapterName } = detailInfo;
      setFormValue({
        chapterName: chapterName,
        revisionUpdate: true,
      });
    } else {
      setErrors({});
    }
  }, [isOpen, detailInfo]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'confirm-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">Chapter 수정</h3>
        <div className="pop_cont">
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    id={formName + 'chapterName'}
                    label="Chapter Title"
                    value={chapterName}
                    onChange={(value) => changeInput('chapterName', value)}
                    errorMessage={errors.chapterName}
                  />
                </div>

                <div className="radio-wrap border-no">
                  <AppCheckbox
                    id={formName + 'revisionUpdate'}
                    label=""
                    checkboxTitle="Revision 업데이트"
                    value={revisionUpdate}
                    //onChange={(value) => setCheckboxValue(value)}
                    onChange={(value) => changeInput('revisionUpdate', value)}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            취소
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleOk}>
            확인
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default ChapterUpdModal;
