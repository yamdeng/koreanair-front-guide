import { useState } from 'react';
import { DatePicker, TimePicker, Select as AntSelect } from 'antd';
import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
import AppTextInput from '@/components/common/AppTextInput';
import AppTextArea from '@/components/common/AppTextArea';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import { Upload } from 'antd';
import CommonUtil from '@/utils/CommonUtil';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppCodeSelect from '@/components/common/AppCodeSelect';

import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';
import useMyAuditCarStore from '@/stores/aviation/audit/myAudit/useMyAuditCarStore';

const { Dragger } = Upload;
const props: any = {
  name: 'file',
  multiple: true,
  defaultFileList: [
    {
      uid: '1',
      name: 'xxx.png',
      // status: 'uploading',
      url: 'http://www.baidu.com/xxx.png',
      percent: 33,
    },
    {
      uid: '2',
      name: 'yyy.png',
      status: 'done',
      url: 'http://www.baidu.com/yyy.png',
    },
    {
      uid: '3',
      name: 'zzz.png',
      status: 'error',
      response: 'Server Error 500',
      // custom error message to show
      url: 'http://www.baidu.com/zzz.png',
    },
  ],
  action: 'https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload',

  onChange(info) {
    const { status } = info.file;
    if (status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (status === 'done') {
      alert(`${info.file.name} file uploaded successfully.`);
    } else if (status === 'error') {
      alert(`${info.file.name} file upload failed.`);
    }
  },

  onRemove(file) {
    return false;
  },

  onPreview(file) {
    return false;
  },

  onDrop(e) {
    console.log('Dropped files', e.dataTransfer.files);
  },
};

// ApprReq (승인요청)
function ApprReqComponent(props) {
  // if (props.data.findingPhaseNm === '개선조치작성') {
  if (props.data.findingPhase === 'C31902') {
    return (
      <div className="Safety-table-cell">
        <span className={`Safety-tag riskLevel level4`}>승인요청</span>
      </div>
    );
  }
}

// Approval (승인)
function ApprovalComponent(props) {
  // if (props.data.findingPhaseNm === '개선조치작성') {
  if (props.data.findingPhase === 'C31905') {
    return (
      <div className="Safety-table-cell">
        <span className={`Safety-tag riskLevel level4`}>승인</span>
        <span className={`Safety-tag riskLevel level2`}>거절</span>
      </div>
    );
  }
}

// Rollback
function RollbackComponent(props) {
  // if (props.data.findingPhaseNm === '개선조치작성') {
  if (props.data.findingPhase === 'C31901') {
    return (
      <div className="Safety-table-cell">
        <span className={`Safety-tag riskLevel level1`}>Rollback</span>
      </div>
    );
  }
}

// CarNo
function CarNoComponent(props) {
  if (props.value != null) {
    return (
      <div>
        <span>
          {/* {String(props.value).toLocaleString()} / {props.data.auditedByNm} */}
          {props.data.findingNo} / {props.data.auditedByNm}
        </span>
      </div>
    );
  }
}

// Risk Level 색상
function RiskLevelComponent(props) {
  if (props.value != null) {
    return (
      <div className="Safety-table-cell">
        <span className={`Safety-tag riskLevel ${props.data.riskLevelColor}`}>
          {String(props.value).toLocaleString()}
        </span>
      </div>
    );
  }
}

// Due Date
function FindingDueAtComponent(props) {
  const { dueAtView, dueAtColor } = props.data;
  const applyStyle: any = {};
  if (dueAtColor) {
    applyStyle.color = dueAtColor;
    // applyStyle.cursor = 'pointer';
  }
  return <span style={applyStyle}>{dueAtView}</span>;
}

function CheckBoxComponent(props) {
  // const { node } = props;
  // const { rowIndex } = node;
  // const { list, toggleCheckbox, updateCheckbox } = TestListStore();
  // const checked = list[rowIndex].checkedTest;
  // const checkBoxHide = list[rowIndex].checkBoxHide;

  // const onChange = (checked) => {
  //   console.log(`toggleCheckbox : ${toggleCheckbox}`);
  //   console.log(`updateCheckbox : ${updateCheckbox}`);
  //   console.log(`checked : ${checked}`);
  //   // toggleCheckbox(rowIndex);
  //   updateCheckbox(rowIndex, checked);
  // };

  const checked = false;

  return (
    // <span style={{ display: !checkBoxHide ? '' : 'none' }}>
    //   <input
    //     type="checkbox"
    //     checked={checked}
    //     onChange={(event) => {
    //       onChange(event.target.checked);
    //     }}
    //   />
    // </span>
    <span style={{ display: '' }}>
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => {
          //onChange(event.target.checked);
        }}
      />
    </span>
  );
}

function MyAuditCar() {
  const [inputValue, setInputValue] = useState('');
  const [Finding, setFinding] = useState(true);
  const [Observation, setObservation] = useState(true);
  const [ActionTaken, setActionTaken] = useState(true);
  const [CorrectiveAction, setCorrectiveAction] = useState(true);

  const customButtons = [
    {
      title: 'ApprReq',
      onClick: () => {
        alert('ApprReq');
      },
    },
    {
      title: 'Approval',
      onClick: () => {
        alert('Approval');
      },
    },
    {
      title: 'Reject',
      onClick: () => {
        alert('Reject');
      },
    },
    {
      title: 'Rollback',
      onClick: () => {
        alert('Rollback');
      },
    },
  ];

  const { auditPhaseLevel, hideCar } = useMyAuditFrameStore();
  const state = useMyAuditCarStore();
  const { dsAuditCarList, findingCntText, formValue, changeInput, errors } = state;

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      //테이블 column 선언
      //{ field: 'auditId', headerName: 'Audit Id', cellStyle: { textAlign: 'center' } },

      {
        width: 120,
        field: 'findingPhaseNm',
        headerName: 'Status',
        cellStyle: { textAlign: 'center' },
        // valueFormatter: (p) => String(p.value).toLocaleString(),
        // cellRenderer: AuditNoComponent,
      },
      {
        width: 230,
        field: 'findingNo',
        headerName: 'CAR No. / CAR By',
        cellStyle: { textAlign: 'left' },
        // valueFormatter: (p) => String(p.value).toLocaleString(),
        cellRenderer: CarNoComponent,
      },
      { width: 120, field: 'findingType', headerName: 'CAR F/O', cellStyle: { textAlign: 'center' } },
      { width: 330, field: 'findingTitle', headerName: 'CAR Title', cellStyle: { textAlign: 'left' } },
      {
        width: 100,
        field: 'riskLevel',
        headerName: 'Risk Level',
        cellStyle: { textAlign: 'center' },
        cellRenderer: RiskLevelComponent,
      },
      {
        width: 180,
        field: 'dueAt',
        headerName: 'Due Date',
        cellStyle: { textAlign: 'center' },
        cellRenderer: FindingDueAtComponent,
      },
      {
        width: 120,
        field: 'checkedTest',
        headerName: 'ApprReq',
        cellStyle: { textAlign: 'center' },
        cellRenderer: ApprReqComponent,
      },
      {
        width: 160,
        field: 'checkedTest',
        headerName: 'Approval',
        cellStyle: { textAlign: 'center' },
        cellRenderer: ApprovalComponent,
      },
      {
        width: 120,
        field: 'checkedTest',
        headerName: 'Rollback',
        cellStyle: { textAlign: 'center' },
        cellRenderer: RollbackComponent,
      },
      // {
      //   width: 220,
      //   field: 'mitigatedAt',
      //   headerName: 'Accept Date',
      //   cellStyle: { textAlign: 'center' },
      //   //cellRenderer: FindingTitleComponent,
      // },
    ])
  );

  return (
    <>
      {/* <div id="area-CAR" className={`myaudit-contents ${hideCar}`}> */}
      <div id="area-CAR" className="myaudit-contents">
        <h3 className="audit-tit">CAR</h3>
        {/* <h3 className="audit-tit">{findingCntText}</h3> */}
        {/*그리드영역 */}

        <div className="mt-10 mb-20">
          {/* <AppTable rowData={rowData} columns={columns} customButtons={customButtons} hiddenPagination /> */}
          <AppTable
            rowData={dsAuditCarList}
            columns={columns}
            setColumns={setColumns}
            store={state}
            //customButtons={customButtons}
            hiddenPagination
            tableHeight={270}
            // enableCheckBox
            // hideDisabledCheckboxes
            //handleRowDoubleClick={handleRowDoubleClick}
          />
        </div>
        {/*//그리드영역 */}
        <div className="info-wrap toggle">
          {dsAuditCarList.map((findingInfo, findingIndex) => {
            const {
              findingId,
              findingNo,
              auditId,
              questionId,
              chapterId,
              checklistId,
              findingType,
              findingPhase,
              findingPhaseNm,
              dueAt,
              lastestDueAt,
              auditedBy,
              auditedByNm,
              flightPhaseOy,
              flightPhaseUf,
              findingTitle,
              riskLevel,
              riskLevelHm,
              categoryId,
              hazardLevel3,
              riskRegister,
              potentialConsequence,
              descr,
              isSpecialAudit,
              timezone,
              isCaConfirmed,
              comment,
              isMitCompleted,
              useYn,
              mitigationAt,
              mitigatedAt,
              // 체크리스트 정보
              checklistNm,
              chapterNm,
              questionContent,
              questionRefManual,
              priority,
              probability,
              severity,
              priorityNm,
              probabilityNm,
              severityNm,
              priorityColor,
              probabilityColor,
              severityColor,
              mitigationInfo, // 경감조치 목록
              rootCauseInfo, // root cause 목록
            } = findingInfo;
            return (
              <dl key={findingId} className="{firstExpaned ? 'tg-item active' : 'tg-item'}">
                {/* 비행정보 */}
                {/* toggle 선택되면  열어지면 active붙임*/}
                <dt>
                  <button className="btn-tg">{findingType}</button>
                </dt>
                <dd className="tg-conts" style={{ display: Finding ? '' : 'none' }}>
                  {/* 상세페이지 */}
                  <div className="editbox bg-gray">
                    <div className="form-table line">
                      <div className="form-cell wid100">
                        <div className="form-group wid100">
                          <div className="df">
                            <div className="type9 mt10">
                              <h3 className="audit-car-tit">
                                {checklistNm} <span>CAR No. {findingNo}</span>
                              </h3>
                              {/* <div className="text-desc-type1">{chapterNm}</div>
                              <div className="text-desc-type1">{questionContent}</div>
                              <div className="form-table">
                                <div className="form-cell wid100">
                                  <div className="form-group wid100">
                                    <span className="text-desc-type1">{questionRefManual}</span>
                                  </div>
                                </div>
                              </div> */}
                              <ul className="audit-carconts">
                                <li>{chapterNm}</li>
                                <li>{questionContent}</li>
                                <li>{questionRefManual}</li>
                              </ul>
                            </div>
                            <div className="type10">
                              <div className="form-table">
                                <div className="form-cell">
                                  <div className="form-group wid100">
                                    <div className="group-box-wrap wid100">
                                      <span className="txt">Priority</span>
                                      <div className="editarea-box view">
                                        <div className="label-box bwid50">
                                          <span className={priorityColor}>{priorityNm}</span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="form-table">
                                <div className="form-cell wid50">
                                  <div className="form-group wid100">
                                    <div className="group-box-wrap wid100">
                                      <span className="txt">Probability</span>
                                      <div className="editarea-box view">
                                        <div className="label-box wid50">
                                          <span className={probabilityColor}>{probabilityNm}</span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="form-table">
                                <div className="form-cell wid50">
                                  <div className="form-group wid100">
                                    <div className="group-box-wrap wid100">
                                      <span className="txt">Severity</span>
                                      <div className="editarea-box view">
                                        <div className="label-box wid50">
                                          <span className={severityColor}>{severityNm}</span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* <div className="form-table ta-r">
                      <div className="form-cell wid50">
                        <div className="group-box-wrap wid100">
                          <div className="radio-wrap border-no">
                            <label>
                              <input type="radio" />
                              <span>Finding</span>
                            </label>
                            <label>
                              <input type="radio" />
                              <span>Observation</span>
                            </label>
                            <label>
                              <input type="radio" />
                              <span>N/A</span>
                            </label>
                            <label>
                              <input type="radio" />
                              <span>Yes</span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div> */}
                    <hr className="line"></hr>
                  </div>
                  {/*//상세페이지*/}

                  <div className="edit-area border-no">
                    <div className="detailForm">
                      <div className="detailForm-detail-box list-group">
                        <div className="detailForm-detail-2deps rbox list-group">
                          <div className="list bx-toggle">
                            <dl className="tg-item rbox01 ">
                              <dt onClick={() => setCorrectiveAction(!CorrectiveAction)}>
                                <button type="button" className="tg-btn">
                                  Corrective Action
                                  <span className={CorrectiveAction ? 'active' : ''}></span>
                                </button>
                              </dt>
                              <dd className="tg-conts" style={{ display: CorrectiveAction ? 'none' : '' }}>
                                <div className="edit-toggle">
                                  <div className="editbox b-t-0">
                                    <div className="form-table">
                                      <div className="form-cell wid100">
                                        <div className="form-group wid-300">
                                          <AppDatePicker
                                            label="Response Due"
                                            id="auditAt"
                                            name="auditAt"
                                            value={dueAt}
                                            onChange={(value) => changeInput('dueAt', value)}
                                            //errorMessage={errors['dueAt']}
                                            //showTime
                                            //excludeSecondsTime
                                            required
                                          />
                                        </div>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <AppSelect label={'Audited By'} value={auditedBy} required />
                                        </div>
                                      </div>
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <AppCodeSelect
                                            codeGrpId="CODE_GRP_321"
                                            required
                                            label="Flight Phase"
                                            value={flightPhaseOy}
                                            // isMultiple
                                            // onChange={(value) => {
                                            //   changeSearchInput('divSearchList', value);
                                            // }}
                                            // disabled
                                          />
                                        </div>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <AppTextInput
                                            label="Finding Title"
                                            id="InvestigationReportreportTitle"
                                            name="findingTitle"
                                            value={findingTitle}
                                            onChange={(value) => changeInput('findingTitle', value)}
                                            required
                                            //errorMessage={errors.findingTitle}
                                            // disabled={formType === FORM_TYPE_UPDATE}
                                          />
                                        </div>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <div className="btn-tit">
                                            <h3>
                                              Risk Level <span className="required">*</span>
                                            </h3>
                                          </div>
                                          <button className="btn-select">Select</button>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <div className="btn-tit">
                                            <h3>
                                              Finding Category <span className="required">*</span>
                                            </h3>
                                          </div>
                                          <button className="btn-select">Select</button>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <div className="btn-tit">
                                            <h3>Hazard LVL3</h3>
                                          </div>
                                          <button className="btn-select">Select</button>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid50">
                                        <div className="group-box-wrap wid100">
                                          <span className="txt">Risk Register</span>
                                          <div className="radio-wrap">
                                            <label>
                                              <input type="radio" />
                                              <span>Yes</span>
                                            </label>
                                            <label>
                                              <input type="radio" />
                                              <span>No</span>
                                            </label>
                                          </div>
                                          {/*<span className="errorText">error</span>*/}
                                        </div>
                                      </div>
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <AppTextInput label="Potential Consequence" />
                                        </div>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <div className="btn-tit">
                                            <h3>
                                              Assign to <span className="required">*</span>
                                            </h3>
                                          </div>
                                          <button className="btn-select">Select</button>
                                        </div>
                                      </div>
                                    </div>
                                    <h3 className="table-tit mt-10">
                                      Root Cause <span className="required">*</span>
                                    </h3>
                                    <div className="form-table">
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <AppTextInput label="Step 1" />
                                        </div>
                                      </div>
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <AppTextInput label="Step 2" />
                                        </div>
                                      </div>
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <AppTextInput label="Step 3" />
                                        </div>
                                      </div>
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100">
                                          <AppTextInput label="Step 4" />
                                        </div>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid50">
                                        <div className="form-group wid100 mr5">
                                          <textarea
                                            id="descr"
                                            className="form-tag"
                                            style={{ height: '100px' }}
                                            name="descr"
                                            value={descr}
                                            onChange={(event) => {
                                              setInputValue(event.target.value);
                                            }}
                                          />
                                          <label className="f-label" htmlFor="testArea1">
                                            Description <span className="required">*</span>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="btn-area">
                                      <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                                        Confirm
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </div>

                      <div className="detailForm-detail-box list-group">
                        <div className="detailForm-detail-2deps rbox list-group">
                          <div className="list bx-toggle">
                            <dl className="tg-item rbox01 ">
                              <dt onClick={() => setActionTaken(!ActionTaken)}>
                                <button type="button" className="tg-btn">
                                  Action Taken
                                  <span className={ActionTaken ? 'active' : ''}></span>
                                </button>
                              </dt>
                              <dd className="tg-conts" style={{ display: ActionTaken ? 'none' : '' }}>
                                <div className="edit-toggle">
                                  <div className="edit-tab">
                                    <ul className="tab-list">
                                      <li className="active">Assign to 1</li>
                                      <li>Assign to 2</li>
                                    </ul>
                                  </div>
                                  <div className="editbox b-t-0">
                                    <div className="form-table">
                                      <div className="form-cell wid100">
                                        <div className="form-group wid-300">
                                          <AppTextInput label="Reporter" />
                                        </div>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid100">
                                        <div className="form-group wid100">
                                          <textarea
                                            id="testArea1"
                                            className="form-tag"
                                            style={{ width: '100%' }}
                                            name="testArea1"
                                            value={inputValue}
                                            onChange={(event) => {
                                              setInputValue(event.target.value);
                                            }}
                                          />
                                          <label className="f-label" htmlFor="testArea1">
                                            Plan & Result
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    {/* 파일첨부영역 : drag */}
                                    <div className="form-cell wid100  mt-15">
                                      <div className="form-group wid100">
                                        {/* 파일첨부영역 : drag */}
                                        <div className="filebox error">
                                          <Dragger {...props}>
                                            <p className="ant-upload-text ">
                                              + 이 곳을 클릭하거나 마우스로 업로드할 파일을 끌어서 놓으세요.
                                            </p>
                                          </Dragger>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                        <span className="errorText">fileerror</span>
                                      </div>
                                    </div>
                                    <div className="form-table">
                                      <div className="form-cell wid100">
                                        <div className="form-group wid100">
                                          <textarea
                                            id="testArea1"
                                            className="form-tag"
                                            style={{ width: '100%' }}
                                            name="testArea1"
                                            value={inputValue}
                                            onChange={(event) => {
                                              setInputValue(event.target.value);
                                            }}
                                          />
                                          <label className="f-label" htmlFor="testArea1">
                                            Plan & Result
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    {/* 파일첨부영역 : drag */}
                                    <div className="form-cell wid100 mt-15">
                                      <div className="form-group wid100">
                                        {/* 파일첨부영역 : drag */}
                                        <div className="filebox error">
                                          <Dragger {...props}>
                                            <p className="ant-upload-text ">
                                              + 이 곳을 클릭하거나 마우스로 업로드할 파일을 끌어서 놓으세요.
                                            </p>
                                          </Dragger>
                                          <label htmlFor="file" className="file-label">
                                            첨부파일 <span className="required">*</span>
                                          </label>
                                        </div>
                                        <span className="errorText">fileerror</span>
                                      </div>
                                    </div>
                                    <div className="btn-area">
                                      <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                                        Accept
                                      </button>
                                      <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                                        Reject
                                      </button>
                                      <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                                        Edit
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/*//입력영역*/}
                </dd>
              </dl>
            );
          })}
          {/*추가버튼*/}
          <div className="btn-area mt-15 mb-10 ta-c">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
              + Add Questionnaire
            </button>
          </div>
          {/*//추가버튼*/}
          <div className="editbox edit-audit-bg mt-15 hide">
            <h3 className="audit-car-tit">Additional Audit Checklist</h3>
            <div className="edit-toggle">
              <div className="editbox b-t-0">
                <h4 className="s-tit mt-15">Additional Chapter</h4>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <textarea
                        id="testArea1"
                        className="form-tag"
                        style={{ width: '100%' }}
                        name="testArea1"
                        value={inputValue}
                        onChange={(event) => {
                          setInputValue(event.target.value);
                        }}
                      />
                      <label className="f-label" htmlFor="testArea1">
                        Content
                      </label>
                    </div>
                  </div>
                </div>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="Reference Manual" />
                    </div>
                  </div>
                </div>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="Input Comment" />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="group-box-wrap wid100">
                      <div className="radio-wrap border-no">
                        <label>
                          <input type="radio" />
                          <span>Finding</span>
                        </label>
                        <label>
                          <input type="radio" />
                          <span>Observation</span>
                        </label>
                        <label>
                          <input type="radio" />
                          <span>N/A</span>
                        </label>
                        <label>
                          <input type="radio" />
                          <span>Yes</span>
                        </label>
                      </div>
                      {/*<span className="errorText">error</span>*/}
                    </div>
                  </div>
                </div>
                <div className="btn-area">
                  <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                    Cancel
                  </button>
                  <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="editbox edit-audit-bg mt-15 hide">
            <h3 className="audit-car-tit">
              Additional Audit Checklist <span>CAR No. 24-LSA-0407-BE03</span>
            </h3>
            <ul className="audit-carconts">
              <li>Additional Chapter</li>
              <li>
                체크리스트에 존재하지 않는 잠재적인 위험을 감지했습니다. CAR 발행 후 개선조치 부탁드립니다. reference
                manual 입니다.
              </li>
              <li>
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap border-no ta-r">
                    <label>
                      <input type="radio" checked />
                      <span>Finding</span>
                    </label>
                    <label>
                      <input type="radio" />
                      <span>Observation</span>
                    </label>
                    <label>
                      <input type="radio" />
                      <span>N/A</span>
                    </label>
                    <label>
                      <input type="radio" />
                      <span>Yes</span>
                    </label>
                  </div>
                </div>
              </li>
              <li>
                <div className="form-cell wid100">
                  <div className="form-group wid100">
                    <textarea
                      id="testArea1"
                      className="form-tag"
                      style={{ width: '100%' }}
                      name="testArea1"
                      value={inputValue}
                      onChange={(event) => {
                        setInputValue(event.target.value);
                      }}
                    />
                  </div>
                </div>
              </li>
            </ul>
            <div className="btn-area">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                Delete
              </button>
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                Edit
              </button>
            </div>
          </div>
        </div>
        {/* 하단버튼영역 */}
        <div className={auditPhaseLevel > 3 ? 'contents-btns hide' : 'contents-btns'}>
          <button className="btn_text text_color_neutral-10 btn_confirm ">Delete</button>
          <button className="btn_text btn_list" onClick={() => alert('작업중입니다.')}>
            Save
          </button>
          <button disabled className="btn_text btn-disabled">
            Rollback
          </button>
          <button
            type="button"
            name="button"
            className="btn_text text_color_neutral-10 btn_confirm"
            onClick={() => alert('작업중입니다.')}
          >
            Next
          </button>
        </div>
        {/*//하단버튼영역*/}
      </div>
    </>
  );
}

export default MyAuditCar;
