import { useState } from 'react';
import { DatePicker, TimePicker, Select as AntSelect } from 'antd';
import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
import AppTextInput from '@/components/common/AppTextInput';
import AppTextArea from '@/components/common/AppTextArea';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import { Upload } from 'antd';
import CommonUtil from '@/utils/CommonUtil';

import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';
import useMyAuditCloseStore from '@/stores/aviation/audit/myAudit/useMyAuditCloseStore';

// CarNo
function CarNoComponent(props) {
  if (props.value != null) {
    return (
      <div>
        <span>
          {/* {String(props.value).toLocaleString()} / {props.data.auditedByNm} */}
          {props.data.findingId} / {props.data.auditedByNm}
        </span>
      </div>
    );
  }
}

// Risk Level 색상
function RiskLevelComponent(props) {
  if (props.value != null) {
    return (
      <div className="Safety-table-cell">
        <span className={`Safety-tag riskLevel ${props.data.riskLevelColor}`}>
          {String(props.value).toLocaleString()}
        </span>
      </div>
    );
  }
}

// Due Date
function FindingDueAtComponent(props) {
  const { dueAtView, dueAtColor } = props.data;
  const applyStyle: any = {};
  if (dueAtColor) {
    applyStyle.color = dueAtColor;
    // applyStyle.cursor = 'pointer';
  }
  return <span style={applyStyle}>{dueAtView}</span>;
}

function MyAuditClose() {
  const { hideClose } = useMyAuditFrameStore();
  const state = useMyAuditCloseStore();
  const { dsAuditCarList, formValue, changeInput, errors } = state;

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      //테이블 column 선언
      //{ field: 'auditId', headerName: 'Audit Id', cellStyle: { textAlign: 'center' } },
      {
        width: 180,
        field: 'findingNo',
        headerName: 'CAR No. / CAR By',
        cellStyle: { textAlign: 'left' },
        // valueFormatter: (p) => String(p.value).toLocaleString(),
        cellRenderer: CarNoComponent,
      },
      { width: 120, field: 'findingType', headerName: 'CAR F/O', cellStyle: { textAlign: 'center' } },
      { width: 400, field: 'findingTitle', headerName: 'CAR Title', cellStyle: { textAlign: 'left' } },
      {
        width: 100,
        field: 'riskLevel',
        headerName: 'Risk Level',
        cellStyle: { textAlign: 'center' },
        cellRenderer: RiskLevelComponent,
      },
      {
        width: 180,
        field: 'dueAt',
        headerName: 'Due Date',
        cellStyle: { textAlign: 'center' },
        cellRenderer: FindingDueAtComponent,
      },
      // {
      //   width: 220,
      //   field: 'mitigatedAt',
      //   headerName: 'Accept Date',
      //   cellStyle: { textAlign: 'center' },
      //   //cellRenderer: FindingTitleComponent,
      // },
    ])
  );

  return (
    <>
      {/* <div id="area-CLOSE" className={`myaudit-contents ${hideClose}`}> */}
      <div id="area-CLOSE" className="myaudit-contents">
        <h3 className="audit-tit">Close</h3>
        {/*그리드영역 */}
        <br />
        <h3 className="audit-tit">Audit 결과공유</h3>
        <div className="mt-10 mb-20">
          {/* <AppTable rowData={rowData} columns={columns} customButtons={customButtons} hiddenPagination /> */}
          <AppTable
            rowData={dsAuditCarList}
            columns={columns}
            setColumns={setColumns}
            store={state}
            //customButtons={customButtons}
            hiddenPagination
            tableHeight={270}
            enableCheckBox
            hideDisabledCheckboxes
            //handleRowDoubleClick={handleRowDoubleClick}
          />
        </div>
        {/*//그리드영역 */}
        <hr className="line"></hr>
        <br />
        <h3 className="audit-tit">공유 대상</h3>
      </div>
    </>
  );
}

export default MyAuditClose;
