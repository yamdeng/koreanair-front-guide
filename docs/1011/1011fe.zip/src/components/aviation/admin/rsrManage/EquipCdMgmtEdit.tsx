import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { useTranslation } from 'react-i18next';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import AppSelect from '@/components/common/AppSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import dayjs from 'dayjs';

/* yup validation */
const yupFormSchema = yup.object({
  equipCd: yup.string().required(),
  equipNm: yup.string().required(),
  modelNm: yup.string(),
  companyTypeCd: yup.string().required(),
  divisionCd: yup.string(),
  companyNm: yup.string(),
  productionDt: yup.string().required(),
  useYn: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  equipCd: '',
  equipNm: '',
  modelNm: '',
  companyTypeCd: '',
  divisionCd: '',
  companyNm: '',
  productionDt: dayjs().format('YYYY-MM-DD'),
  useYn: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/rsr/equipments',
  baseRoutePath: '/aviation/rsrManage/EquipCodeMgmt',
  formName: 'AvnEquipCodeMgmtForm',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useAvnEquipCodeMgmtFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function EquipCdMgmtEdit() {
  const { t } = useTranslation();
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    useAvnEquipCodeMgmtFormStore();

  const { equipCd, equipNm, modelNm, companyTypeCd, divisionCd, companyNm, productionDt, useYn } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>장비코드 {formType === FORM_TYPE_ADD ? '신규' : '수정'}</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnEquipCodeMgmtFormequipCd"
                name="equipCd"
                label="장비코드"
                value={equipCd}
                onChange={(value) => changeInput('equipCd', value)}
                errorMessage={errors.equipCd}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnEquipCodeMgmtFormequipNm"
                name="equipNm"
                label="장비명"
                value={equipNm}
                onChange={(value) => changeInput('equipNm', value)}
                errorMessage={errors.equipNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnEquipCodeMgmtFormmodelNm"
                name="modelNm"
                label="모델명"
                value={modelNm}
                onChange={(value) => changeInput('modelNm', value)}
                errorMessage={errors.modelNm}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid30">
              <AppSelect
                id="AvnEquipCodeMgmtFormcompanyTypeCd"
                name="companyTypeCd"
                label="자사구분"
                value={companyTypeCd}
                options={[
                  { label: '자사', value: '1' },
                  { label: '타사', value: '2' },
                ]}
                onChange={(value) => changeInput('companyTypeCd', value)}
                errorMessage={errors.companyTypeCd}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid30">
              <AppCodeSelect
                codeGrpId="CODE_GRP_170"
                id="AvnEquipCodeMgmtFormdivisionCd"
                name="divisionCd"
                label="부서"
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={divisionCd}
                onChange={(value) => changeInput('divisionCd', value)}
                errorMessage={errors.divisionCd}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnEquipCodeMgmtFormcompanyNm"
                name="companyNm"
                label="업체명"
                value={companyNm}
                onChange={(value) => changeInput('companyNm', value)}
                errorMessage={errors.companyNm}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid30">
              <AppDatePicker
                id="AvnEquipCodeMgmtFormproductionDt"
                name="productionDt"
                label="제작일자"
                value={productionDt}
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                onChange={(value) => changeInput('productionDt', value)}
                errorMessage={errors.productionDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid30">
              <AppCodeSelect
                codeGrpId="CODE_GRP_146"
                id="AvnBannerManageFormStoreuseYn"
                name="useYn"
                label="사용여부"
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={useYn}
                onChange={(value) => changeInput('useYn', value)}
                errorMessage={errors['useYn']}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
    </>
  );
}
export default EquipCdMgmtEdit;
