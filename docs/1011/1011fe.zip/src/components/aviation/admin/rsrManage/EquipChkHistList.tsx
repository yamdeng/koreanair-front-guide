import { current, produce } from 'immer';
import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useCallback, useEffect, useState } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import { useTranslation } from 'react-i18next';
import AppSelect from '@/components/common/AppSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppTextArea from '@/components/common/AppTextArea';
import AppDatePicker from '@/components/common/AppDatePicker';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object().shape({
  list: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        checkDt: yup.string().required(),
        checkResultYn: yup.string().required(),
      })
    ),
});

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/rsr/equipments',
  baseRoutePath: '/aviation/rsrManage/EquipChkHist',
  formValue: {
    list: [],
  },
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  equipCd: '', // 장비코드
  equipNm: '', // 장비명
  modelNm: '', // 모델명
  companyTypeCd: '', // 자사구분
  divisionCd: '', // 부서
  companyNm: '', // 업체명
};

/* zustand store 생성 */
const AvnEquipCheckHistListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,
  yupFormSchema: yupFormSchema,

  historyUpdateMode: 'view', // 수정중이면 'update'

  checkHistoryList: [],

  currentHistoryIndex: -1,

  changeCurrentHistoryIndex: (currentHistoryIndex) => {
    set({ currentHistoryIndex: currentHistoryIndex });
  },

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    equipCd: '', // 장비코드
    equipNm: '', // 장비명
    modelNm: '', // 모델명
    companyTypeCd: '', // 자사구분
    divisionCd: '', // 부서
    companyNm: '', // 업체명
  },

  // TODO: 초기화,

  changeCheckHistoryList: (list) => {
    const { changeStateProps } = get();
    changeStateProps('checkHistoryList', list);
    // TODO: 이력 수정모드를 원복해야 함. 또는 수정중인지 확인
  },

  addHistory: () => {
    set(
      produce((state: any) => {
        const beforeCheckHistoryList = state.checkHistoryList;
        state.historyUpdateMode = 'update';
        state.checkHistoryList.push({
          number: beforeCheckHistoryList.length + 1,
          checkDate: '',
          checkResult: '',
          regUserName: '',
          regDate: '',
          updateUserName: '',
          updateDate: '',
        });
      })
    );
  },

  // [수정] 버튼 클릭시 input을 입력할 수 있게끔 mode 수정
  updateHistory: () => {
    set({ historyUpdateMode: 'update' });
  },

  // [삭제] 버튼
  deleteHistory: () => {
    // TODO : 삭제 api call 하고 checkHistoryList: [] 초기화 시키고 좌측 테이블 refresh
  },

  // 수정된 input 적용
  applyHistory: () => {
    set({ historyUpdateMode: 'view' });
  },

  // 이력 최종 저장
  saveHistory: () => {
    // TODO : 저장 api call 하고 checkHistoryList: [] 초기화 시키고 좌측 테이블 refresh
  },

  changeHistoryInput: (listIndex, inputName, value) => {
    if (listIndex !== -1) {
      set(
        produce((state: any) => {
          state.checkHistoryList[listIndex][inputName] = value;
        })
      );
    }
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function EquipChkHistList() {
  const { t } = useTranslation();
  const state = AvnEquipCheckHistListStore();

  const {
    changeStateProps,
    currentHistoryIndex,
    checkHistoryList,
    changeCheckHistoryList,
    changeCurrentHistoryIndex,
    addHistory,
    historyUpdateMode,
    updateHistory,
    deleteHistory,
    applyHistory,
    saveHistory,
    changeHistoryInput,
  } = state;

  const [columnsMain, setColumnsMain] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호' },
      { field: 'equipCd', headerName: '장비코드' },
      { field: 'equipNm', headerName: '장비명' },
      { field: 'modelNm', headerName: '모델명' },
      { field: 'companyTypeCd', headerName: '자사구분' },
      { field: 'divisionCd', headerName: '부서' },
      { field: 'companyNm', headerName: '업체명' },
      { field: 'productionDt', headerName: '제작일자' },
    ])
  );

  const [columnsSub, setColumnsSub] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번' },
      { field: 'checkDt', headerName: '점검일자' },
      { field: 'checkResultYn', headerName: '점검결과' },
      { field: 'regUserId', headerName: '작성자' },
      { field: 'regDttm', headerName: '작성일자' },
      { field: 'updUserId', headerName: '수정자' },
      { field: 'updDttm', headerName: '수정일자' },
    ])
  );

  const { enterSearch, searchParam, list, changeSearchInput, initSearchInput, formType, clear, save, remove } = state;

  const { equipCd, equipNm, modelNm, companyTypeCd, divisionCd, companyNm } = searchParam;

  const handleRowSingleClickLeft = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    const { checkHistoryList, etc } = data;
    const testCheckHistoryList = [
      {
        number: '1',
        checkDate: '2024-01-01',
        checkResult: 'S',
        regUserName: '김항공',
        regDate: '2024-01-01',
        updateUserName: '김항공2',
        updateDate: '2024-12-01',
        etc: 'aaa',
      },
      {
        number: '2',
        checkDate: '2024-01-01',
        checkResult: 'S',
        regUserName: '김항공',
        regDate: '2024-01-01',
        updateUserName: '김항공2',
        updateDate: '2024-12-01',
        etc: 'bbb',
      },
    ];
    // changeStateProps('checkHistoryList', checkHistoryList);
    changeStateProps('checkHistoryList', testCheckHistoryList);
  }, []);

  const handleRowSingleClickRight = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    const keyData = {
      equipCd: data.equipCd, // 장비코드
      equipNm: data.equipNm, // 장비명
      companyTypeCd: data.companyTypeCd, // 자사구분
      checkHistId: data.checkHistId, // 점검이력ID
    };
  }, []);

  useEffect(() => {
    // enterSearch();
    state.search('C');
    return clear;
  }, []);

  // TODO : 'view' mode일 경우 클릭 했을때에도 currentIndex 반영
  // TODO : 'update' mode일 경우 클릭했을때 + changeInput 이 변경되어있을 경우 모두 반영

  let etc = '';

  if (checkHistoryList && currentHistoryIndex !== -1) {
    etc = checkHistoryList[currentHistoryIndex].etc;
  }

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>장비점검 관리</h2>
      </div>

      {/*검색영역 */}
      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppSearchInput
                label="장비코드"
                value={equipCd}
                onChange={(value) => {
                  changeSearchInput('equipCd', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppSearchInput
                label="장비명"
                value={equipNm}
                onChange={(value) => {
                  changeSearchInput('equipNm', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppSearchInput
                label="모델명"
                value={modelNm}
                onChange={(value) => {
                  changeSearchInput('modelNm', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppSelect
                label="자사구분"
                value={companyTypeCd}
                options={[
                  { label: '자사', value: '1' },
                  { label: '타사', value: '2' },
                ]}
                onChange={(value) => {
                  changeSearchInput('companyTypeCd', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_170"
                label="부서"
                value={divisionCd}
                onChange={(value) => {
                  changeSearchInput('divisionCd', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppSearchInput
                label="업체명"
                value={companyNm}
                onChange={(value) => {
                  changeSearchInput('companyNm', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="btn-area">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                {t('ke.safety.common.label.00002')}
              </button>
              <button
                type="button"
                name="button"
                className="btn-sm btn_text btn-darkblue-line"
                onClick={initSearchInput}
              >
                {t('ke.safety.common.label.00003')}
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* //검색영역 */}

      <div className="equipbox">
        {/*그리드영역 */}
        <div className="left-box">
          <AppTable
            rowData={list}
            columns={columnsMain}
            setColumns={setColumnsMain}
            store={state} // store 생성예정
            handleRowSingleClick={handleRowSingleClickLeft}
          />
        </div>
        {/*그리드영역 */}
        <div className="right-box">
          <div className="list-view">
            <div className="">
              <h3>
                점검이력 목록
                <button style={{ display: historyUpdateMode === 'update' ? '' : 'none' }} onClick={addHistory}>
                  신규
                </button>
                <button style={{ display: historyUpdateMode === 'view' ? '' : 'none' }} onClick={updateHistory}>
                  수정
                </button>
                <button style={{ display: historyUpdateMode === 'update' ? '' : 'none' }} onClick={applyHistory}>
                  저장
                </button>
              </h3>
              <div>
                <table className="equip-table">
                  <thead>
                    <tr>
                      <th>번호</th>
                      <th>점검일자</th>
                      <th>점검결과</th>
                      <th>작성자</th>
                      <th>작성일자</th>
                      <th>수정자</th>
                      <th>수정일자</th>
                    </tr>
                  </thead>
                  <tbody>
                    {checkHistoryList.map((historyInfo, index) => {
                      const { number, checkDate, checkResult, regUserName, regDate, updateUserName, updateDate } =
                        historyInfo;

                      let historyTrComponent = (
                        <tr
                          key={index}
                          style={{ backgroundColor: currentHistoryIndex === index ? '#c7c7df' : '' }}
                          onClick={() => changeCurrentHistoryIndex(index)}
                        >
                          <td>{number}</td>
                          <td>{checkDate}</td>
                          <td>{checkResult}</td>
                          <td>{regUserName}</td>
                          <td>{regDate}</td>
                          <td>{updateUserName}</td>
                          <td>{updateDate}</td>
                        </tr>
                      );
                      if (historyUpdateMode === 'update') {
                        historyTrComponent = (
                          <tr
                            key={index}
                            style={{ backgroundColor: currentHistoryIndex === index ? '#c7c7df' : '' }}
                            onClick={() => changeCurrentHistoryIndex(index)}
                          >
                            <td>{number}</td>
                            <td>
                              <AppDatePicker
                                value={checkDate}
                                onChange={(value) => changeHistoryInput(index, 'checkDate', value)}
                              />
                            </td>
                            <td>
                              <AppCodeSelect value={checkDate} />
                            </td>
                            <td>{regUserName}</td>
                            <td>{regDate}</td>
                            <td>{updateUserName}</td>
                            <td>{updateDate}</td>
                          </tr>
                        );
                      }
                      return historyTrComponent;
                    })}
                    {/* {array.map((element, index) => {
                      // 커스텀해줄것 있으면 return 전에 실행
                      return (
                        <tr key={index}>
                          <td>1</td>
                          <td>2024-12-31</td>
                          <td>책임자</td>
                          <td>작성자1</td>
                          <td>2024-12-31</td>
                          <td>작성자1</td>
                          <td>2024-12-31</td>
                        </tr>
                      );
                    })} */}
                    {/* <AppTable
                      rowData={list}
                      columns={columnsSub}
                      setColumns={setColumnsSub}
                      store={state} // store 생성예정
                      handleRowSingleClick={handleRowSingleClickRight}
                    /> */}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="list-dtail">
              <h3></h3>
              <div className="form-table">
                <div className="form-cell">
                  <div className="form-group wid100">
                    <div className="type7">
                      <AppTextArea
                        label="비고"
                        style={{ width: '100%', height: 200 }}
                        errorMessage=""
                        value={etc}
                        onChange={(value) => changeHistoryInput(currentHistoryIndex, 'etc', value)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/*//그리드영역 */}
          <div className="contents-btns">
            <button
              className="btn_text text_color_darkblue-100 btn_close"
              onClick={remove}
              style={{ display: formType !== 'add' ? '' : 'none' }}
            >
              {t('ke.safety.common.label.00008')}
            </button>
            {/* TODO : 저장 후 재조회 시 index를 -1로 초기화 */}
            <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
              {t('ke.safety.common.label.00004')}
            </button>
          </div>
        </div>
      </div>
      {/*//그리드영역 */}
    </>
  );
}

export default EquipChkHistList;
