import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/educations',
  baseRoutePath: '/aviation/trainingManage/Educations',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  fromDate: dayjs().format('YYYY-MM-DD'), // 교육일자 From
  toDate: dayjs().format('YYYY-MM-DD'), // 교육일자 To
  educationCd: '', // 교육구분 (전사/ERP)
  subjectNm: '', // 제목
  useYn: '', // 사용여부
};

/* zustand store 생성 */
const AvnEducationListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    fromDate: dayjs().format('YYYY-MM-DD'), // 교육일자 From
    toDate: dayjs().format('YYYY-MM-DD'), // 교육일자 To
    educationCd: '', // 교육구분 (전사/ERP)
    subjectNm: '', // 제목
    useYn: '', // 사용여부
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function EducationList() {
  const { t } = useTranslation();
  const state = AvnEducationListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번' },
      { field: 'educationDt', headerName: '교육일자' },
      { field: 'educationCd', headerName: '교육구분' },
      { field: 'subjectNm', headerName: '제목' },
      { field: 'useYn', headerName: '사용여부' },
      { field: 'regUserId', headerName: '등록자' },
      { field: 'regDttm', headerName: '등록일시' },
      { field: 'updUserId', headerName: '수정자' },
      { field: 'updDttm', headerName: '수정일시' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    clear,
    goDetailPage,
    search,
  } = state;
  // 검색 파라미터
  const { fromDate, toDate, educationCd, subjectNm, useYn } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.boardId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>교육관리</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid20">
              <div className="form-group wid100">
                <div className="form-group form-glow">
                  <div className="df">
                    <div className="date1">
                      <AppDatePicker
                        label={t('ke_change_mgmt_label_00556')}
                        pickerType="date"
                        value={fromDate}
                        onChange={(value) => {
                          changeSearchInput('fromDate', value);
                        }}
                        required
                      />
                    </div>
                    <span className="unt">~</span>
                    <div className="date2">
                      <AppDatePicker
                        label={t('ke_report_label_00203')}
                        pickerType="date"
                        value={toDate}
                        onChange={(value) => {
                          changeSearchInput('toDate', value);
                        }}
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="form-cell wid0">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_180"
                  applyAllSelect
                  label={'교육구분'}
                  value={educationCd}
                  onChange={(value) => {
                    changeSearchInput('educationCd', value);
                  }}
                  required
                  search={educationCd}
                />
              </div>
            </div>

            <div className="form-cell wid20">
              <div className="form-group wid100">
                <AppSearchInput
                  label={t('ke.safety.policy.label.00002')}
                  value={subjectNm}
                  onChange={(value) => {
                    changeSearchInput('subjectNm', value);
                  }}
                  search={search}
                />
              </div>
            </div>

            <div className="form-cell wid0">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_146"
                  applyAllSelect
                  label={'사용여부'}
                  value={useYn}
                  onChange={(value) => {
                    changeSearchInput('useYn', value);
                  }}
                  search={useYn}
                />
              </div>
            </div>

            <div className="btn-area df">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                {t('ke.safety.common.label.00002')}
              </button>
              <button
                type="button"
                name="button"
                className="btn-sm btn_text btn-darkblue-line"
                onClick={initSearchInput}
              >
                {t('ke.safety.common.label.00003')}
              </button>
            </div>
          </div>
        </div>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
    </>
  );
}

export default EducationList;
