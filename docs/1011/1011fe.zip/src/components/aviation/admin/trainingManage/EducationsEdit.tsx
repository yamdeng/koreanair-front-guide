import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { useTranslation } from 'react-i18next';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import AppDatePicker from '@/components/common/AppDatePicker';
import { Editor } from '@toast-ui/react-editor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppCodeSelect from '@/components/common/AppCodeSelect';
// import AppTextArea from '@/components/common/AppTextArea';

/* yup validation */
const yupFormSchema = yup.object({
  educationDt: yup.string().required(),
  educationCd: yup.string().required(),
  subjectNm: yup.string().required(),
  educationCn: yup.string(),
  linkGroupSeq: yup.number().nullable(),
  fileGroupSeq: yup.number().nullable(),
  // useYn: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  educationDt: '',
  educationCd: '',
  subjectNm: '',
  educationCn: '',
  linkGroupSeq: null,
  fileGroupSeq: null,
  // useYn: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/educations',
  baseRoutePath: '/aviation/trainingManage/Educations',
  formName: 'AvnEducationFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const AvnEducationFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function EducationEdit() {
  // 언어 설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    AvnEducationFormStore();

  const { educationDt, educationCd, subjectNm, educationCn, /*linkGroupSeq,*/ fileGroupSeq /*, useYn*/ } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>교육관리 {formType === FORM_TYPE_ADD ? '신규' : '수정'}</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDatePicker
                id="AvnEducationFormeducationDt"
                name="educationDt"
                label="교육일자"
                value={educationDt}
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                onChange={(value) => changeInput('educationDt', value)}
                errorMessage={errors.educationDt}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_180"
                id="AvnEducationFormeducationCd"
                name="educationCd"
                label="교육구분"
                value={educationCd}
                onChange={(value) => changeInput('educationCd', value)}
                errorMessage={errors.educationCd}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnEducationFormsubjectNm"
                name="subjectNm"
                label="제목"
                value={subjectNm}
                onChange={(value) => changeInput('subjectNm', value)}
                errorMessage={errors.subjectNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100 mr5">
              <Editor
                id="AvnEducationFormeducationCn"
                name="educationCn"
                label={t('ke.safety.Notice.label.00009')}
                value={educationCn}
                onChange={(value) => changeInput('educationCn', value)}
                errorMessage={errors.content}
                hideModeSwitch={true}
                initialEditType="wysiwyg"
                previewStyle="vertical"
                // initialValue={initValue}
                height={'500px'}
                // onChange={() => {}}
                usageStatistics={false}
                customHTMLSanitizer={(html) => {
                  return html;
                }}
                viewer={true}
                autofocus={false}
                customHTMLRenderer={{
                  htmlBlock: {
                    table(node) {
                      return [
                        { type: 'openTag', tagName: 'table', outerNewLine: true, attributes: node.attrs },
                        { type: 'html', content: node.childrenHTML },
                        { type: 'closeTag', tagName: 'table', outerNewLine: true },
                      ];
                    },
                  },
                }}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid80">
            <div className="group-box-wrap line wid100">
              <span className="txt">Link{/*<span className="required">*</span>*/}</span>
              <button type="button" name="button" className="btn-plus">
                추가
              </button>
              <div className="file-link">
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link첨부Link첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* 파일첨부영역 : drag */}
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              {/* 파일첨부영역 : drag */}
              <AppFileAttach
                label={t('ke.safety.Notice.label.00007')}
                fileGroupSeq={fileGroupSeq}
                workScope={'A'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileGroupSeq', newFileGroupSeq);
                }}
                errorMessage={errors.fileGroupSeq}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_146"
                id="useSafetyBoardFormStoreuseYn"
                name="useYn"
                label={t('ke.safety.manual.label.00008')}
                value={useYn}
                onChange={(value) => changeInput('useYn', value)}
                errorMessage={errors.useYn}
                required
              />
            </div>
          </div>
        </div> */}
      </div>
      {/* <hr className="line dp-n"></hr> */}
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
    </>
  );
}
export default EducationEdit;
