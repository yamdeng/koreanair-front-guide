import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';
import AppTextInput from '@/components/common/AppTextInput';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import Code from '@/config/Code';
import AppNavigation from '@/components/common/AppNavigation';
import { useTranslation } from 'react-i18next';
import AppSearchInput from '@/components/common/AppSearchInput';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/criteria/taxonomies',
  baseRoutePath: '/aviation/criteriaManage/taxonomy',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  hazardLvoneNm: '', // Level1
  hazardLvtwoNm: '', // Level2
  hazardLvthreeNm: '', // Level3
  hazardCn: '', // 위해요인내용
  sourcesCn: '', // 출처
  consequenceCn: '', // 잠재결과
  useYn: '', // 사용여부
  // notes: '', // 비고
};

/* zustand store 생성 */
const HazardTaxonomyListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    hazardLvoneNm: '', // Level1
    hazardLvtwoNm: '', // Level2
    hazardLvthreeNm: '', // Level3
    hazardCn: '', // 위해요인내용
    sourcesCn: '', // 출처
    consequenceCn: '', // 잠재결과
    useYn: '', // 사용여부
    // notes: '', // 비고
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

// Taxonomy component
function TaxonomyList() {
  const { t } = useTranslation();
  const state = HazardTaxonomyListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번' },
      { field: 'hazardLvoneNm', headerName: 'Level 1' },
      { field: 'hazardLvtwoNm', headerName: 'Level 2' },
      { field: 'hazardLvthreeNm', headerName: 'Level 3' },
      { field: 'hazardCn', headerName: '위해요인내용' },
      { field: 'sourcesCn', headerName: '출처' },
      { field: 'consequenceCn', headerName: '잠재결과' },
      { field: 'useYn', headerName: '사용여부' },
      // { field: 'notes', headerName: '비고' },
      { field: 'regUserId', headerName: '등록자' },
      { field: 'regDttm', headerName: '등록일' },
      { field: 'updUserId', headerName: '수정자' },
      { field: 'updDttm', headerName: '수정일' },
    ])
  );
  // HazardTaxonomyListStore 에서 정의된 메소드 사용 시 이곳에서 분해할당
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    goDetailPage,
    initSearchInput,
    search,
  } = state;
  // 검색 파라미터 나열
  const { hazardLvoneNm, hazardLvtwoNm, hazardLvthreeNm, hazardCn, sourcesCn, consequenceCn, useYn } = searchParam;

  // 더블클릭시 상세 페이지 또는 모달 페이지 오픈
  const handleRowDoubleClick = useCallback((selectedInfo) => {
    console.log(selectedInfo);
    const data = selectedInfo.data;
    // Lv3가 메인??
    const detailId = data.hazardLv3Id;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/*헤더영역 */}
      <div className="conts-title">
        <h2>Taxonomy 관리</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        <div id="" className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="Level1"
                  value={hazardLvoneNm}
                  onChange={(value) => {
                    changeSearchInput('hazardLvoneNm', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/* TODO : lv2 확인 */}
                <AppSearchInput
                  label="Level2"
                  value={hazardLvtwoNm}
                  onChange={(value) => {
                    changeSearchInput('hazardLvtwoNm', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/* TODO : lv3 확인 */}
                <AppSearchInput
                  label="Level3"
                  value={hazardLvthreeNm}
                  onChange={(value) => {
                    changeSearchInput('hazardLvthreeNm', value);
                  }}
                  search={search}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell ">
              <div className="form-group wid100">
                <AppTextInput
                  label={'위해요인내용'}
                  value={hazardCn}
                  onChange={(value) => {
                    changeSearchInput('hazardCn', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={'출처'}
                  value={sourcesCn}
                  onChange={(value) => {
                    changeSearchInput('sourcesCn', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={'잠재결과'}
                  value={consequenceCn}
                  onChange={(value) => {
                    changeSearchInput('consequenceCn', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSelect
                  label={'사용여부'}
                  options={Code.useYn}
                  value={useYn}
                  onChange={(value) => {
                    changeSearchInput('useYn', value);
                  }}
                />
              </div>
            </div>
            {/* <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={'비고'}
                  value={notes}
                  onChange={(value) => {
                    changeSearchInput('notes', value);
                  }}
                />
              </div>
            </div> */}
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              {t('ke.safety.common.label.00002')}
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              {t('ke.safety.common.label.00003')}
            </button>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
        />
      </div>
      {/*//그리드영역 */}

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
      {/*//하단버튼영역*/}
    </>
  );
}

export default TaxonomyList;
