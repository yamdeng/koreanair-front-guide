import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppTextInput from '@/components/common/AppTextInput';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import * as yup from 'yup';
import { create } from 'zustand';
import { useTranslation } from 'react-i18next';

/* yup validation */
const yupFormSchema = yup.object({
  reportTypeCd: yup.string().required(),
  eventNm: yup.string().required(),
  useYn: yup.string().required(),
  notesCn: yup.string(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  reportTypeCd: '',
  eventNm: '',
  useYn: '',
  notesCn: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/criteria/event-types',
  baseRoutePath: '/aviation/criteriaManage/event-types',
  formName: 'EventTypeEditStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const EventTypeEditStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function EventTypeEdit() {
  const { t } = useTranslation();
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    EventTypeEditStore();
  const { reportTypeCd, eventNm, useYn, notesCn } = formValue;
  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>EVENT TYPE {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_148"
                id="EventTypeFormreportTypeCd"
                name="reportTypeCd"
                label="리포트 구분"
                labelKey="codeNameKor"
                valueKey="codeId"
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={reportTypeCd}
                onChange={(value) => changeInput('reportTypeCd', value)}
                errorMessage={errors.reportTypeCd}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="EventTypeFormeventNm"
                name="eventNm"
                label="이벤트명"
                value={eventNm}
                onChange={(value) => changeInput('eventNm', value)}
                errorMessage={errors.eventNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_146"
                id="useSafetyBoardFormStoreuseYn"
                name="useYn"
                label="사용여부"
                labelKey="codeNameKor"
                valueKey="codeId"
                value={useYn}
                onChange={(value) => changeInput('useYn', value)}
                errorMessage={errors.useYn}
                required
              />
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="EventTypeFormnotesCn"
                name="notesCn"
                label="비고"
                value={notesCn}
                onChange={(value) => changeInput('notesCn', value)}
                errorMessage={errors.notesCn}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
    </>
  );
}
export default EventTypeEdit;
