import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import AppSelect from '@/components/common/AppSelect';
import Code from '@/config/Code';
import { useTranslation } from 'react-i18next';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import AppEditor from '@/components/common/AppEditor';
import AppAutoComplete from '@/components/common/AppAutoComplete';

/* yup validation */
const yupFormSchema = yup.object({
  hazardLvoneNm: yup.string().required('Level1은 필수 값 입니다.'),
  hazardLvtwoNm: yup.string().required('Level2는 필수 값 입니다.'),
  hazardLvthreeNm: yup.string().required('Level3는 필수 값 입니다.'),
  hazardCn: yup.string(),
  sourcesCn: yup.string(),
  consequenceCn: yup.string(),
  useYn: yup.string().required('사용여부는 필수 값 입니다.'),
  // notes: yup.string(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  hazardLvoneNm: '', // Level1
  hazardLvtwoNm: '', // Level2
  hazardLvthreeNm: '', // Level3
  hazardCn: '', // 위해요인내용
  sourcesCn: '', // 출처
  consequenceCn: '', // 잠재결과
  useYn: '', // 사용여부
  // notes: '', // 비고
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/criteria/taxonomies',
  baseRoutePath: '/aviation/criteriaManage/taxonomy',
  formName: 'HazardTaxonomyEditStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const HazardTaxonomyEditStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...initFormData,
  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function TaxonomyEdit() {
  const { t } = useTranslation();
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    HazardTaxonomyEditStore();
  const { hazardLvoneNm, hazardLvtwoNm, hazardLvthreeNm, hazardCn, sourcesCn, consequenceCn, useYn } = formValue;
  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>Taxonomy {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppSelect
                id="HazardTaxonomyEditStorehazardLvoneNm"
                name="lvThazardLvoneNmext1"
                label={'Level 1'}
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                //options={}
                value={hazardLvoneNm}
                onChange={(value) => {
                  changeInput('hazardLvoneNm', value);
                }}
                errorMessage={errors.hazardLvoneNm}
                required
              />
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput label="Level 1" value={hazardLvoneNm} disabled />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppAutoComplete
                id="HazardTaxonomyEditStorehazardLvtwoNm"
                name="hazardLvtwoNm"
                label={'Level 2'}
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                //options={}
                value={hazardLvtwoNm}
                onChange={(value) => {
                  changeInput('hazardLvtwoNm', value);
                }}
                isMultiple={false}
                errorMessage={errors.hazardLvtwoNm}
                required
              />
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput label="Level 2" value={hazardLvtwoNm} disabled />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="HazardTaxonomyEditStorehazardLvthreeNm"
                name="hazardLvthreeNm"
                label={'Level 3'}
                value={hazardLvthreeNm}
                onChange={(value) => {
                  changeInput('hazardLvthreeNm', value);
                }}
                errorMessage={errors.hazardLvthreeNm}
                required
              />
            </div>
          </div>
        </div>

        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppEditor
                id="HazardTaxonomyEditStorehazardCn"
                name="hazardCn"
                label={'위해요인 내용'}
                value={hazardCn}
                onChange={(value) => changeInput('hazardCn', value)}
                errorMessage={errors.hazardCn}
              />
            </div>
          </div>
        </div>

        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="HazardTaxonomyEditStoresourcesCn"
                name="sourcesCn"
                label={'출처'}
                value={sourcesCn}
                onchange={(value) => {
                  changeInput('sourcesCn', value);
                }}
                errorMessage={errors.sourcesCn}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="HazardTaxonomyEditStoreconsequenceCn"
                name="consequenceCn"
                label={'잠재결과'}
                value={consequenceCn}
                onchange={(value) => {
                  changeInput('consequenceCn', value);
                }}
                errorMessage={errors.consequenceCn}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppSelect
                id="HazardTaxonomyEditStoreuseYn"
                name="useYn"
                label={'사용여부'}
                options={Code.useYn}
                value={useYn}
                onchange={(value) => {
                  changeInput('useYn', value);
                }}
                errorMessage={errors.useYn}
              />
            </div>
          </div>
          {/* <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="HazardTaxonomyEditStorenotes"
                name="notes"
                label={'비고'}
                value={notes}
                onchange={(value) => changeInput('notes', value)}
                errorMessage={errors.notes}
              />
            </div>
          </div> */}
        </div>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
    </>
  );
}
export default TaxonomyEdit;
