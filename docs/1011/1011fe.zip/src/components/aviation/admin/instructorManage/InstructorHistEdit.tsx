import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { useEffect, useState } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import AppDatePicker from '@/components/common/AppDatePicker';
//import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useTranslation } from 'react-i18next';
import AvnReportUserSelect from '../../common/AvnReportUserSelect';
import { useImmer } from 'use-immer';
import AppUserSelectInput from '@/components/common/AppUserSelectInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';

/* yup validation */
const yupFormSchema = yup.object({
  emplymentDt: yup.string().required(),
  nameKor: yup.string().required(),
  employmentTypeCd: yup.string().required(),
  imploymentYn: yup.string().required(),
  notesCn: yup.string(),
  linkGroupSeq: yup.number().nullable(),
  fileGroupSeq: yup.number().nullable(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  emplymentDt: '',
  nameKor: '',
  employmentTypeCd: '',
  imploymentYn: '',
  notesCn: '',
  linkGroupSeq: null,
  fileGroupSeq: null,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/instructors',
  baseRoutePath: '/aviation/instructorsManage/instructors',
  formName: 'AvnInstructorHistFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const AvnInstructorHistFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function InstructorHistEdit() {
  // 언어 설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    AvnInstructorHistFormStore();

  const { /*nameKor,*/ emplymentDt, employmentTypeCd, imploymentYn, notesCn, /*linkGroupSeq,*/ fileGroupSeq } =
    formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  const [userList, setUserList] = useImmer([]);

  const onSelect = (selectedValue) => {
    console.log(selectedValue);
    setUserList((beforeUserList) => {
      if (!beforeUserList.find((info) => info.empNo === selectedValue.empNo)) {
        beforeUserList.push(selectedValue);
      }
    });
  };

  const deleteUser = (removeIndex) => {
    setUserList((beforeUserList) => {
      beforeUserList.splice(removeIndex, 1);
    });
  };

  // 사용자선택 테스트
  const [userSelectValue, setUserSelectValue] = useState('23312');

  const handleUserSelectInput = (selectedValue) => {
    // console.log(selectedValue);
    setUserSelectValue(selectedValue);
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>강사이력관리 {formType === FORM_TYPE_ADD ? '신규' : '수정'}</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppDatePicker
                id="AvnInstructorHistFormemplymentDt"
                name="emplymentDt"
                label="임용일자"
                value={emplymentDt}
                onChange={(value) => changeInput('emplymentDt', value)}
                errorMessage={errors.emplymentDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AvnReportUserSelect
                id="AvnInstructorHistFormnameKor"
                label="강사명"
                userList={userList}
                onSelect={onSelect}
                deleteUser={deleteUser}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppUserSelectInput
                withOrgTree={false}
                label="강사명"
                value={userSelectValue}
                onChange={(value) => {
                  handleUserSelectInput(value);
                }}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_175"
                id="AvnInstructorHistFormemploymentTypeCd"
                name="employmentTypeCd"
                label="임용구분"
                value={employmentTypeCd}
                onChange={(value) => changeInput('employmentTypeCd', value)}
                errorMessage={errors.employmentTypeCd}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_176"
                id="AvnInstructorHistFormimploymentYn"
                name="imploymentYn"
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                label="임용여부"
                value={imploymentYn}
                onChange={(value) => changeInput('imploymentYn', value)}
                errorMessage={errors.imploymentYn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnInstructorHistFormnotesCn"
                name="notesCn"
                label="메모내용"
                value={notesCn}
                onChange={(value) => changeInput('notesCn', value)}
                errorMessage={errors.notesCn}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid80">
            <div className="group-box-wrap line wid100">
              <span className="txt">Link{/*<span className="required">*</span>*/}</span>
              <button type="button" name="button" className="btn-plus">
                추가
              </button>
              <div className="file-link">
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link첨부Link첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* 파일첨부영역 : drag */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* 파일첨부영역 : drag */}
              <AppFileAttach
                label={t('ke.safety.Notice.label.00007')}
                fileGroupSeq={fileGroupSeq}
                workScope={'A'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileGroupSeq', newFileGroupSeq);
                }}
                errorMessage={errors.fileGroupSeq}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
      {/*//하단 버튼 영역 */}
    </>
  );
}
export default InstructorHistEdit;
