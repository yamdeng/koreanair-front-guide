import ReportViewStore from '@/stores/aviation/report/view/ReportViewStore';
import ReportViewSecondRiskReviewStore from '@/stores/aviation/report/view/ReportViewSecondRiskReviewStore';

/* 보고서상세 > 보고서 분석 > 2차 위험도 평가 > SRC리뷰 */
function ReportViewSecondRiskReview() {
  const toggleAccordionExpanded = ReportViewStore((state) => state.toggleAccordionExpanded);
  const secondRiskReviewExpanded = ReportViewStore((state) => state.secondRiskReviewExpanded);

  return (
    <div className="detailForm-detail-3deps list-group" id="secondrisk_review">
      <div className="list bx-toggle">
        <dl className="tg-item rbox01 ">
          <dt onClick={() => toggleAccordionExpanded('secondRiskReviewExpanded')}>
            <button type="button" className="tg-btn">
              SRC리뷰<span className={secondRiskReviewExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: secondRiskReviewExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="listtable">
                <table className="info-board">
                  <colgroup>
                    <col width="25%" />
                    <col width="18%" />
                    <col width="8%" />
                    <col width="8%" />
                    <col width="14%" />
                    <col width="10%" />
                    <col width="8%" />
                    <col width="9%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>Hazard</th>
                      <th>Potential Consequence</th>
                      <th>Risk Level 1</th>
                      <th>Team</th>
                      <th>Mitigation Result</th>
                      <th>Risk Level 2</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="tl">Lightning strike Environmental/Weather</td>
                      <td className="tl">Aircraft Change</td>
                      <td>
                        <div className="Safety-table-cell">
                          <span className="Safety-tag riskLevel level1">3A</span>
                        </div>
                      </td>
                      <td className="fix vm">운항지원팀</td>
                      <td className="tl">LSC김리더(LeaderKim)</td>
                      <td>
                        <div className="Safety-table-cell">
                          <span className="Safety-tag riskLevel level4">1A</span>
                        </div>
                      </td>
                      <td>대기</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td className="tl">Sandstorm Environmental/Weather</td>
                      <td className="tl">Escape slide deployment</td>
                      <td>
                        <div className="Safety-table-cell">
                          <span className="Safety-tag riskLevel level3">2B</span>
                        </div>
                      </td>
                      <td className="fix vm">정비안전보건팀 </td>
                      <td className="tl">LSC김리더(LeaderKim)</td>
                      <td>
                        <div className="Safety-table-cell">
                          <span className="Safety-tag riskLevel level4">1B</span>
                        </div>
                      </td>
                      <td>대기</td>
                      <td></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* 버튼*/}
              <div className="contents-btns">
                <button type="button" name="button" className="btn_text btn_list">
                  목록
                </button>
              </div>
              {/* //버튼*/}
            </div>
          </dd>
        </dl>
      </div>
    </div>
  );
}

export default ReportViewSecondRiskReview;
