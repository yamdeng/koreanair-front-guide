import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { produce } from 'immer';
import AppRangeDatePicker from '@/components/common/AppRangeDatePicker';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import { getUserLabelByLocale } from '@/services/i18n';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import CommonUtil from '@/utils/CommonUtil';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppSelect from '@/components/common/AppSelect';
import ApiService from '@/services/ApiService';
import AppCheckbox from '@/components/common/AppCheckbox';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import { useTranslation } from 'react-i18next';
import { create } from 'zustand';
import _ from 'lodash';
import history from '@/utils/history';
import AviationUtil from '@/utils/AviationUtil';

const StepList = [
  {
    stepCode: 'pg_search_reception',
    stepId: 'receipt',
    stepNumber: 1,
    stepTitle: '접수',
  },
  {
    stepCode: 'pg_search_1st',
    stepId: '1stRiskAssessment',
    stepNumber: 2,
    stepTitle: '1차위험평가',
  },
  {
    stepCode: 'pg_search_mitigation',
    stepId: 'mitigation',
    stepNumber: 3,
    stepTitle: '경감조치',
  },
  {
    stepCode: 'pg_search_2st',
    stepId: '2ndRiskAssessment',
    stepNumber: 4,
    stepTitle: '2차위험평가',
  },
  {
    stepCode: 'pg_search_close',
    stepId: 'riskAcceptanceApproval',
    stepNumber: 5,
    stepTitle: '종결',
  },
];

function getDate(cnt) {
  const today = new Date();
  if (cnt > 0) {
    today.setMonth(today.getMonth() - cnt);
  }
  const year = today.getFullYear(); // 년도
  const month = today.getMonth() + 1; // 월
  const date = today.getDate(); // 날짜

  let monthString = '';
  let dateString = '';
  if (month < 10) {
    monthString = '0' + month;
  } else {
    monthString = month.toString();
  }

  if (date < 10) {
    dateString = '0' + date;
  } else {
    dateString = date.toString();
  }
  return year + '-' + monthString + '-' + dateString;
}

const fromDate = getDate(1);
const toDate = getDate(0);

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/srm/analysis',
  baseRoutePath: '/aviation/reportList',
  disableLoadingBar: true,
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  p_subject: '',
  p_reportedBy: '',
  p_dateType: 'submit',
  p_startDate: fromDate,
  p_endDate: toDate,
  p_fleet: '',
  p_regNo: '',
  p_sector: '',
  p_phase: 'receipt',
  p_myTurn: 'N',
  p_workPhase: '',
  p_workStepCode: '',
  p_reportTypeCd: '',
};

/* zustand store 생성 */
const ReportListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  //초기 step 선언
  currentStepCode: 'pg_search_reception',

  //상태 버튼 array
  statusList: [],

  //발생단계
  Phase: [],

  //range날짜에 필요한 초기 값
  rangeDt: [fromDate, toDate],

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    p_subject: '',
    p_reportedBy: '',
    p_dateType: 'submit',
    p_startDate: fromDate,
    p_endDate: toDate,
    p_fleet: '',
    p_regNo: '',
    p_sector: '',
    p_phase: 'receipt',
    p_myTurn: 'N',
    p_workPhase: '',
    p_workStepCode: '',
    p_reportTypeCd: '',
  },

  changeStep: async (stepCode, stepId) => {
    set({ currentStepCode: stepCode });
    const apiResult = await ApiService.get(`avn/common/page_code/${stepCode}/state`);
    const data = apiResult.data || [];
    set({ statusList: data });

    const { searchParam, enterSearch } = get();
    searchParam['p_phase'] = stepId;
    searchParam['p_workPhase'] = '';
    searchParam['p_workStepCode'] = '';
    set({ searchParam: searchParam });
    enterSearch();
  },

  //상세 결재 단계 클릭 시 조회
  searchStepCode: (phase, stepCode) => {
    const { searchParam, enterSearch } = get();
    searchParam['p_workPhase'] = phase;
    searchParam['p_workStepCode'] = stepCode;
    set({ searchParam: searchParam });
    enterSearch();
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
      rangeDt: [fromDate, toDate],
      currentStepCode: 'pg_search_reception',
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },

  expanded: true,

  toggleRepresentReport: (index, expanded) => {
    set(
      produce((state: any) => {
        const list = state.list;
        const children = list[index].subReportList || [];
        const applyChildren = _.cloneDeep(children);
        if (expanded) {
          list.splice(index + 1, 0, ...applyChildren);
        } else {
          list.splice(index + 1, applyChildren.length);
        }
        list[index].expanded = expanded;
        state.list = list;
      })
    );
  },

  toggleExpand: () => {
    const { expanded } = get();
    set({ expanded: !expanded });
  },
}));

function HasChildrenCheckComponent(props) {
  const { store, node } = props;
  const { rowIndex } = node;
  const { toggleRepresentReport } = store;
  const { value, data } = props;
  const { isChild, expanded } = data;

  // +, -, ''
  const expandedComponent = <span></span>;
  // 묶음 하위 보고서인 경우
  if (isChild) {
    return <span>ㄴ</span>;
  } else if (value) {
    // 자식이 존재하는 경우
    // 펼쳐져 있을 경우
    if (expanded) {
      return <span onClick={() => toggleRepresentReport(rowIndex, false)}>-</span>;
    } else {
      return <span onClick={() => toggleRepresentReport(rowIndex, true)}>+</span>;
    }
  }
  return <span>{expandedComponent}</span>;
}

function ReportList() {
  const { t } = useTranslation();

  const state = ReportListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      {
        field: 'hasChildren',
        headerName: '묶음',
        cellRenderer: HasChildrenCheckComponent,
        cellRendererParams: {
          store: state,
        },
      },
      { field: 'docNo', headerName: 'Doc No.', cellStyle: { textAlign: 'center' } },
      { field: 'subject', headerName: 'Subject', cellStyle: { textAlign: 'left' } },
      { field: 'flightNo', headerName: 'Fleet', cellStyle: { textAlign: 'center' } },
      { field: 'registrationNo', headerName: 'Reg No.', cellStyle: { textAlign: 'center' } },
      /* { field: 'phase', headerName: 'Step', cellStyle: { textAlign: 'center' } }, */
      { field: 'statusKo', headerName: 'Status', cellStyle: { textAlign: 'center' } },
      { field: 'submittedAt', headerName: 'Submit Date', cellStyle: { textAlign: 'center' } },
      { field: 'receiptedAt', headerName: 'Receipt Date', cellStyle: { textAlign: 'center' } },
      { field: 'reportedByUserNameKo', headerName: 'Submitted By', cellStyle: { textAlign: 'center' } },
      { field: 'receiptedByUserNameKo', headerName: 'Received By', cellStyle: { textAlign: 'center' } },
      { field: 'nameKo', headerName: 'Event Type', cellStyle: { textAlign: 'left' } },
      { field: 'lv3Name', headerName: 'Hazard', cellStyle: { textAlign: 'left' } },
      { field: 'consequenceKo', headerName: 'Potential Consequence', cellStyle: { textAlign: 'left' } },
      { field: 'riskLevel1', headerName: '1st Risk Assessment', cellStyle: { textAlign: 'center' } },
      { field: 'firstScore', headerName: '1st Risk Assessment\n(Score)', cellStyle: { textAlign: 'center' } },
      { field: 'mitigationDeptNameKo', headerName: 'Team', cellStyle: { textAlign: 'left' } },
      { field: 'riskLevel2', headerName: '2st Risk Assessment', cellStyle: { textAlign: 'center' } },
      { field: 'secondScore', headerName: '2st Risk Assessment\n(Score)', cellStyle: { textAlign: 'center' } },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    rangeDt,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    display,
    search,
    currentStepCode,
    statusList,
    changeStep,
    searchStepCode,
    changeStateProps,
    goDetailPage,
    onSelect,
    ...rest
  } = state;

  // TODO : 검색 파라미터 나열
  const {
    p_subject,
    p_reportedBy,
    p_dateType,
    p_startDate,
    p_endDate,
    p_fleet,
    p_regNo,
    p_sector,
    p_phase,
    p_myTurn,
    p_myTurnYn,
    p_workPhase,
    p_workStepCode,
    p_reportTypeCd,
  } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    //debugger;
    const data = selectedInfo.data;
    AviationUtil.moveReportViewPage(data);
  }, []);

  useEffect(() => {
    enterSearch();
    changeStep('pg_search_reception', 'receipt');
    return clear;
  }, []);

  const [selectedRowList, setSelectedRowList] = useState([]);
  const handleRowSelect = (selectedRowList) => {
    console.log(`selectedInfo : ${selectedRowList}`);
    setSelectedRowList(selectedRowList);
  };

  const customButtons = [];
  if (p_phase === 'receipt') {
    while (customButtons.length > 0) {
      customButtons.pop();
    }
    customButtons.push({
      title: '보고서묶음',
      onClick: () => {
        //openFormModal(null);
      },
    });
  }

  const profile = useStore(useAppStore, (state) => state.profile);
  if (p_phase === '1stRiskAssessment') {
    while (customButtons.length > 0) {
      customButtons.pop();
    }
    //SRC 권한이 있을 경우에만 생성함
    const result = profile.groupInfo.find((elem) => {
      return elem.groupCd === 'SSC';
    });
    if (result != null) {
      customButtons.push({
        title: 'SRC승인',
        onClick: () => {
          //debugger;
          alert(`selectedRowList.length : ${selectedRowList.length}`);
        },
      });
      customButtons.push({
        title: 'SRC반려',
        onClick: () => {
          //openFormModal(null);
        },
      });
    }
  }

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>보고서분석</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label={t('ke_common_label_00021')}
                  value={p_subject}
                  onChange={(value) => {
                    changeSearchInput('p_subject', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="form-cell wid40">
              <div className="form-group wid100">
                <AppAutoComplete
                  label={t('ke.report.reportList.label.00001')}
                  id="p_reportedBy"
                  name="p_reportedBy"
                  apiUrl="avn/common/users"
                  labelKey="customLabel"
                  valueKey="empNo"
                  dataKey="data.list"
                  onChange={(value) => {
                    changeSearchInput('p_reportedBy', value);
                  }}
                  isMultiple={false}
                  isValueString
                  required
                />
              </div>
            </div>
            <div className="form-cell wid10">
              <div className="chk-wrap">
                <AppCheckbox
                  label={t('ke.report.reportList.label.00002')}
                  checkboxTitle=""
                  value={p_myTurnYn}
                  onChange={(value) => {
                    if (value) {
                      changeSearchInput('p_myTurn', 'Y');
                      changeSearchInput('p_myTurnYn', true);
                    } else {
                      changeSearchInput('p_myTurn', 'N');
                      changeSearchInput('p_myTurnYn', false);
                    }
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSelect
                  options={[
                    { label: 'Submit Date', value: 'submit' },
                    { label: 'Receipt Date', value: 'receipt' },
                    { label: 'Departure Date', value: 'departure' },
                  ]}
                  label={''}
                  value={p_dateType}
                  onChange={(value) => {
                    changeSearchInput('p_dateType', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <AppRangeDatePicker
                label2={t('ke.safetyRiskMgmt.investigationReport.label.00003')}
                label=""
                onChange={(value) => {
                  changeSearchInput('p_startDate', value[0]);
                  changeSearchInput('p_endDate', value[1]);
                  changeStateProps('rangeDt', value);
                }}
                value={rangeDt}
                showNow
                placeholder={['시작일', '종료일']}
              />
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={t('보고서구분')}
                  codeGrpId="CODE_GRP_092"
                  applyAllSelect
                  value={p_reportTypeCd}
                  onChange={(value) => {
                    changeSearchInput('p_reportTypeCd', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label={t('ke.report.reportList.label.00003')}
                  value={p_fleet}
                  onChange={(value) => {
                    changeSearchInput('p_fleet', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label={t('ke.report.reportList.label.00004')}
                  value={p_regNo}
                  onChange={(value) => {
                    changeSearchInput('p_regNo', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={t('ke.safety.conference.label.00001')}
                  codeGrpId="CODE_GRP_326"
                  applyAllSelect
                  value={p_sector}
                  onChange={(value) => {
                    changeSearchInput('p_sector', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              {t('ke.safety.common.label.00002')}
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              {t('ke.safety.common.label.00003')}
            </button>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>
      {/* //검색영역 */}
      {/* 리포트 프로세스 */}
      <div className="c-step-wrap">
        <ol className="c-step-list-type-5">
          {/* 선택된 class명에 active */}
          {StepList.map((stepInfo) => {
            const { stepCode, stepId, stepNumber, stepTitle } = stepInfo;
            return (
              <li key={stepNumber} className={currentStepCode === stepCode ? 'active' : ''}>
                <a
                  href="javascript:void(0);"
                  data-label={stepTitle}
                  onClick={() => {
                    changeStep(stepCode, stepId);
                  }}
                >
                  <p className={currentStepCode === stepCode ? 'info-title active' : 'info-title'}>
                    {/* 선택된 class명에 active */}
                    <span className="hide">{stepNumber}단계</span>
                    {stepTitle}
                  </p>
                </a>
                <span className="after-arrow"></span>
              </li>
            );
          })}
        </ol>
      </div>
      {/* 업무관련 버튼 */}
      <div className="process-btns">
        <button
          type="button"
          className="btn-sm btn_text btn-blue"
          onClick={() => {
            searchStepCode('', '');
          }}
        >
          전체
        </button>
        {statusList.map((statusInfo) => {
          // textAdminEn
          const { textAdminKo, phase, stepCode } = statusInfo;
          return (
            <button
              key={textAdminKo}
              type="button"
              className="btn-sm btn_text btn-blue"
              onClick={() => {
                searchStepCode(phase, stepCode);
              }}
            >
              {textAdminKo}
            </button>
          );
        })}
      </div>

      {/*그리드영역 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
          handleRowSelect={handleRowSelect}
          useColumnDynamicSetting
          enableCheckBox
          hideDisabledCheckboxes
          isRowSelectable={(rowNode) => (rowNode.data.isChild ? false : true)}
          customButtons={customButtons}
        />
      </div>
      {/*//그리드영역 */}

      {/* 하단버튼영역 */}
      {/*//하단버튼영역*/}
    </>
  );
}

export default ReportList;
