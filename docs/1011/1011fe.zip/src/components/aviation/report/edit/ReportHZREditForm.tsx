import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import AppEditor from '@/components/common/AppEditor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import AppSelect from '@/components/common/AppSelect';
import AppTextInput from '@/components/common/AppTextInput';
import Code from '@/config/Code';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import useHzrFormStore from '@/stores/aviation/report/useHzrFormStore';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';

function ReportHZREditForm() {
  const formStore = useHzrFormStore();
  const {
    errors,
    changeInput,
    changeFeedbackYn,
    getDetail,
    formValue,
    tempSave,
    save,
    print,
    isDirty,
    clear,
    formType,
    detailInfo,
  } = formStore;

  const { report = {} } = detailInfo || {};

  const { event } = formValue;

  const { detailId } = useParams();

  const { anonyYn, kairsYn, feedbackYn, emailAddr, subjectNm, descriptionTxtcn, fileGroupSeq } = event;

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      clear();
    }
  }, [detailId]);

  useEffect(() => {
    return clear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['HZR']} />

      <div className="info-wrap toggle">
        {/* 이벤트 */}
        <dl className={'tg-item'}>
          <dt>
            <button type="button" className="btn-tg">
              비밀보장/처리 결과 회신 지정
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSelect
                          label="비밀보장"
                          options={Code.reportUseYn}
                          value={anonyYn}
                          onChange={(value) => {
                            changeInput('event.anonyYn', value);
                          }}
                          required
                          errorMessage={errors['event.kairsYn']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSelect
                          label="KAIRS 제출 동의"
                          options={Code.reportUseYn}
                          value={kairsYn}
                          onChange={(value) => {
                            changeInput('event.kairsYn', value);
                          }}
                          required
                          errorMessage={errors['event.kairsYn']}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppSelect
                          label="처리결과 회신"
                          options={Code.reportUseYn}
                          value={feedbackYn}
                          onChange={(value) => {
                            changeFeedbackYn(value);
                          }}
                          required
                          errorMessage={errors['event.feedbackYn']}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="개인 이메일"
                          value={emailAddr}
                          onChange={(value) => {
                            changeInput('event.emailAddr', value);
                          }}
                          required={feedbackYn && feedbackYn === 'Y'}
                          errorMessage={errors['event.emailAddr']}
                          disabled={!feedbackYn || feedbackYn !== 'Y'}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="제목"
                          value={subjectNm}
                          onChange={(value) => {
                            changeInput('event.subjectNm', value);
                          }}
                          required
                          errorMessage={errors['event.subjectNm']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <AppEditor
                        label="AppEditor"
                        value={descriptionTxtcn}
                        onChange={(value, byPassIsDirty) => {
                          changeInput('event.descriptionTxtcn', value, byPassIsDirty);
                        }}
                        required
                        errorMessage={errors['event.descriptionTxtcn']}
                      />
                    </div>
                  </div>
                  {/* 파일첨부영역 : drag */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* 파일첨부영역 : drag */}
                        <AppFileAttach
                          label={'첨부파일'}
                          fileGroupSeq={fileGroupSeq}
                          workScope={'A'}
                          updateFileGroupSeq={(newFileGroupSeq) => {
                            changeInput('event.fileGroupSeq', newFileGroupSeq);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      {/* 하단버튼영역 */}
      <ReportEditBottomButton
        formType={formType}
        finalSubmittedYn={report.finalSubmittedYn}
        print={print}
        tempSave={tempSave}
        save={save}
      />
    </>
  );
}
export default ReportHZREditForm;
