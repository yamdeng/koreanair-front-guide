import AppTextInput from '@/components/common/AppTextInput';

function MsrDeviceList({ store = {} }) {
  const {
    deviceListCurrentChangingIndex,
    formValue,
    deviceListCurrentEditFormValue,
    changeDeviceFormInput,
    saveDeviceList,
    cancelDeviceList,
    deleteDeviceList,
    updateDeviceList,
  } = store as any;

  const { deviceList } = formValue;

  return (
    <div className="form-table">
      <div className="form-cell Add wid100">
        <div className="form-group wid100">
          <div className="box-view-list">
            <ul className="view-list">
              <li className="accumlate-list">
                <span className="text-desc-type1">
                  <div className="info-box ">
                    <table className="notice-board Air2">
                      <colgroup>
                        <col width="28%" />
                        <col width="28%" />
                        <col width="28%" />
                        <col width="16%" />
                      </colgroup>
                      <tr>
                        <th>명명법</th>
                        <th>부품번호</th>
                        <th>일련번호</th>
                        <th>Action</th>
                      </tr>
                      {deviceList.map((deviceInfo, deviceListIndex) => {
                        const { nomenclatureNm, partNm, serialnoNm } = deviceInfo;
                        let deviceTrComponent = (
                          <tr>
                            <td className="left Sel">{nomenclatureNm}</td>
                            <td className="left Sel">{partNm}</td>
                            <td className="left Sel">{serialnoNm}</td>
                            <td className="btns">
                              <a
                                href={undefined}
                                className="btn-modify"
                                style={{
                                  display: deviceListCurrentChangingIndex === -1 ? '' : 'none',
                                }}
                                onClick={() => updateDeviceList(deviceListIndex, deviceInfo)}
                              >
                                수정
                              </a>
                              <a
                                href={undefined}
                                className="btn-delete"
                                style={{
                                  display: deviceListCurrentChangingIndex === -1 ? '' : 'none',
                                }}
                                onClick={() => deleteDeviceList(deviceListIndex)}
                              >
                                삭제
                              </a>
                            </td>
                          </tr>
                        );
                        if (
                          deviceListCurrentChangingIndex !== -1 &&
                          deviceListIndex === deviceListCurrentChangingIndex
                        ) {
                          deviceTrComponent = (
                            <tr>
                              <td className="Sel">
                                <AppTextInput
                                  value={deviceListCurrentEditFormValue.nomenclatureNm}
                                  onChange={(value) => changeDeviceFormInput('nomenclatureNm', value)}
                                />
                              </td>
                              <td className="Sel">
                                <AppTextInput
                                  value={deviceListCurrentEditFormValue.partNm}
                                  onChange={(value) => changeDeviceFormInput('partNm', value)}
                                />
                              </td>
                              <td className="Sel">
                                <AppTextInput
                                  value={deviceListCurrentEditFormValue.serialnoNm}
                                  onChange={(value) => changeDeviceFormInput('serialnoNm', value)}
                                />
                              </td>
                              <td className="btns">
                                <a href={undefined} className="btn-modify" onClick={() => saveDeviceList()}>
                                  저장{' '}
                                </a>
                                <a href={undefined} className="btn-delete" onClick={() => cancelDeviceList()}>
                                  취소{' '}
                                </a>
                              </td>
                            </tr>
                          );
                        }
                        return deviceTrComponent;
                      })}
                    </table>
                  </div>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MsrDeviceList;
