package com.koreanair.ksms.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {

        String[] allowedOrigins = {
                "http://localhost:8082",
                "http://ksms-maius.koreanair.com:8082",
                "http://localhost:5174",
                "https://apidev.koreanair.com",
                "https://apistg.koreanair.com",
                "https://api.koreanair.com",
                "https://appl.koreanair.com"
        };

        registry.addMapping("/**")
                .allowedOriginPatterns(allowedOrigins)
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowCredentials(true);
    }
}