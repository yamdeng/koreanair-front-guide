package com.koreanair.ksms.utils;

import com.koreanair.ksms.constants.CommonConstants;
import com.koreanair.ksms.constants.ResponseHeaderCode;
import com.koreanair.ksms.constants.StatusCodeConstants;
import com.koreanair.ksms.system.dto.ResponseDto;
import lombok.experimental.UtilityClass;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@UtilityClass
public class ResponseUtil {

    public static <T> ResponseEntity<ResponseDto<T>> createSuccessResponse() {
        return createSuccessResponseData(StatusCodeConstants.SUCCESS, null, HttpStatus.OK);
    }

    public static <T> ResponseEntity<ResponseDto<T>> createSuccessResponse(ResponseDto<T> response) {
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    public static <T> ResponseEntity<ResponseDto<T>> createSuccessResponse(T data) {
        return createSuccessResponse(StatusCodeConstants.SUCCESS, data);
    }

    public static <T> ResponseEntity<ResponseDto<T>> createSuccessResponse(String statusCode, T data) {
        return createSuccessResponse(statusCode, data, HttpStatus.OK);
    }

    public static <T> ResponseEntity<ResponseDto<T>> createSuccessResponse(
            String statusCode, T data, HttpStatus httpStatus) {
        return createSuccessResponseData(statusCode, data, httpStatus);
    }

    private static <T> ResponseEntity<ResponseDto<T>> createSuccessResponseData(
            String statusCode, T data, HttpStatus httpStatus) {

        return new ResponseEntity<>(
                ResponseDto.<T>builder()
                        .successOrNot(CommonConstants.YES_FLAG)
                        .statusCode(statusCode)
                        .headerMsg(ResponseHeaderCode.SUCCESS.getHeaderMessage())
                        .headerCd(ResponseHeaderCode.SUCCESS)
                        .itemCount(
                                data instanceof List<?>
                                        ? ((List<?>) data).size()
                                        : (data instanceof Integer ? (int) data : 0))
                        .data(data)
                        .build(),
                httpStatus);
    }

    public static <T> ResponseEntity<ResponseDto<T>> createFailResponse() {
        return createFailResponse(HttpStatus.OK);
    }

    public static <T> ResponseEntity<ResponseDto<T>> createFailResponse(HttpStatus httpStatus) {
        return createFailResponse(StatusCodeConstants.FAIL, null, httpStatus, ResponseHeaderCode.UNAVAILABLE_SERVICE);
    }

    public static <T> ResponseEntity<ResponseDto<T>> createFailResponse(
            String statusCode, ResponseHeaderCode headerCode) {
        return createFailResponse(statusCode, null, HttpStatus.OK, headerCode);
    }

    public static <T> ResponseEntity<ResponseDto<T>> createFailResponse(
            String statusCode, T message, HttpStatus httpStatus, ResponseHeaderCode headerCode) {
        return new ResponseEntity<>(createFailResponseData(statusCode, message, headerCode), httpStatus);
    }

    public static <T> ResponseEntity<ResponseDto<T>> createFailResponse(
            String statusCode,
            T message,
            HttpHeaders httpHeaders,
            HttpStatus httpStatus,
            ResponseHeaderCode headerCode) {
        return new ResponseEntity<>(createFailResponseData(statusCode, message, headerCode), httpHeaders, httpStatus);
    }

    private static <T> ResponseDto<T> createFailResponseData(
            String statusCode, T message, ResponseHeaderCode headerCode) {
        return ResponseDto.<T>builder()
                .successOrNot(CommonConstants.NO_FLAG)
                .statusCode(statusCode)
                .data(message)
                .headerCd(headerCode)
                .headerMsg(headerCode.getHeaderMessage())
                .errorCode(statusCode)
                .errorMessage(statusCode)
                .errorActor("kalksms")
                .build();
    }

}