package com.koreanair.ksms.system.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.TbSysMessageDto;
import com.koreanair.ksms.system.service.SystemMessageService;
import com.koreanair.ksms.utils.ExcelUtil;
import com.koreanair.ksms.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 관리자 사이트 - 다국어 메시지 관리
 */
@Tag(name = "SystemMessage", description = "시스템 메시지관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/sys")
public class SystemMessageController {

    @Autowired
    SystemMessageService service;

    /**
     * Gets list.
     *
     * @param searchWord the search word
     * @return the list
     */
    @Operation(summary = "다국어 메시지 목록조회(전체목록)", description = "다국어 메시지 전체목록조회 API")
    @GetMapping(value = "/all-messages")
    public ResponseEntity<?> getList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        List<TbSysMessageDto> resultList = service.selectMessageList(searchWord);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    /**
     * Gets excel.
     *
     * @param searchWord the search word
     * @return the Excel
     */
    @Operation(summary = "다국어 메시지 엑셀 다운로드", description = "다국어 메시지 엑셀 다운로드 API")
    @GetMapping(value = "/all-messages/excel")
    public ResponseEntity<?> getExcel(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        List<TbSysMessageDto> resultList = service.selectMessageList(searchWord);

        // 엑셀 다운로드
        String excelFileName = "다국어_메시지";
        Map<String, String> excelFields = new LinkedHashMap<String, String>();
        excelFields.put("msgKey", "메시지 키");
        excelFields.put("msgKor", "한국어 메시지");
        excelFields.put("msgEng", "영어 메시지");

        return ExcelUtil.downloadExcel(
                resultList,
                excelFields,
                excelFileName
        );
    }

    @Operation(summary = "다국어 메시지 목록조회(페이지)", description = "다국어 메시지 페이지 목록조회 API")
    @GetMapping(value = "/messages")
    public ResponseEntity<?> getPageList(
             @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="searchWord", required=false) String searchWord) {

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbSysMessageDto> pageList = service.selectMessageListPage(searchWord);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "다국어 메시지 1건 조회", description = "다국어 메시지 1건 조회 API")
    @GetMapping(value = "/messages/{messageId}")
    public ResponseEntity<?> getDetailInfo(@PathVariable(value="messageId") String messageId) {

        TbSysMessageDto result = service.selectMessage(messageId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "다국어 메시지 insert", description = "다국어 메시지 insert API")
    @PostMapping(value = "/messages")
    public ResponseEntity<?> saveInfo(@Valid @RequestBody() TbSysMessageDto dto) {

        service.insertMessage(dto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "다국어 메시지 update", description = "다국어 메시지 update API")
    @PutMapping(value = "/messages/{messageId}")
    public ResponseEntity<?> updateInfo(
            @PathVariable(value="messageId") String messageId,
            @Valid @RequestBody() TbSysMessageDto dto) {

        dto.setMsgKey(messageId);

        service.updateMessage(dto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "다국어 메시지 delete", description = "다국어 메시지 delete API")
    @DeleteMapping(value = "/messages/{messageId}")
    public ResponseEntity<?> deleteInfo(@PathVariable(value="messageId") String messageId) {

        service.deleteMessage(messageId);
        return ResponseUtil.createSuccessResponse();
    }
}
