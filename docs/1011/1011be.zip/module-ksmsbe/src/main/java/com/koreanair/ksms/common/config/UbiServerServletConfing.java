package com.koreanair.ksms.common.config;


import com.koreanair.ksms.common.controller.UbiHtmlController;
import com.koreanair.ksms.common.service.CommonLoginService;
import com.koreanair.ksms.common.utils.JwtUtil;
import com.ubireport.server.UbiServer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UbiServerServletConfing {

	@Bean
	public ServletRegistrationBean<UbiServer4> getServletRegistrationBean() {
		ServletRegistrationBean<UbiServer4> registrationBean = new ServletRegistrationBean<>(new UbiServer4());

		String path = "C:/workspace/ksms-be/module-ksmsbe/UbiService";

		//ubiserver.xml 위치 지정 : 절대경로 사용
		registrationBean.addInitParameter("isAbsolutePath", "true");
		registrationBean.addInitParameter("propertyPath", path);

		//ubiserver.xml 위치 지정 : 상대경로 사용
		//registrationBean.addInitParameter("isAbsolutePath", "false");
		//registrationBean.addInitParameter("propertyPath", "/");

		registrationBean.addUrlMappings("/api/v1/UbiServer");
	
		return registrationBean;
	}
	
	/* UbiHTML Viewer */
	@Bean
	public ServletRegistrationBean<UbiHtmlController> getServletRegistrationBeanHtml() {
		ServletRegistrationBean<UbiHtmlController> registrationBean = new ServletRegistrationBean<>(new UbiHtmlController());
		registrationBean.addUrlMappings("/api/v1/ubihtml");
	
		return registrationBean;
	}
	
	/* WS(activeX) Viewer
	@Bean
	public ServletRegistrationBean<ubiplugin> getServletRegistrationBeanPlugin() {
		ServletRegistrationBean<ubiplugin> registrationBean = new ServletRegistrationBean<>(new ubiplugin());
		registrationBean.addUrlMappings("/ubiplugin");
	
		return registrationBean;
	}
	*/
	
	/* 서버에 파일 저장하는 Lib Sample
	@Bean
	public ServletRegistrationBean<ubiexport> getServletRegistrationBeanExport() {
		ServletRegistrationBean<ubiexport> registrationBean = new ServletRegistrationBean<>(new ubiexport());
		registrationBean.addUrlMappings("/ubiexport");
	
		return registrationBean;
	}
	*/
}
