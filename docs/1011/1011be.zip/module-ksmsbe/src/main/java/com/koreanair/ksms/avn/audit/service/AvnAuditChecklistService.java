package com.koreanair.ksms.avn.audit.service;

import com.koreanair.ksms.avn.audit.dto.*;
import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;

import java.util.List;

public interface AvnAuditChecklistService {

    // Checklist 목록 조회 (with Chapter)
    List<TBAuditChecklistChapterDto> selectAuditChecklist(TBAuditChecklistDto searchDto);

    // Question 목록 조회
    List<TBAuditQuestionDto> selectAuditQuestionList(TBAuditQuestionDto searchDto);

    // Checklist 등록
    Integer insertAuditChecklist(TBAuditChecklistDto tbAuditChecklistDto);

    // Checklist 수정 (chapter,question CUD 포함)
    TBAuditQuestionPostDto updateAuditChecklist(TBAuditQuestionPostDto tbQuestionsDto);

    // Checklist 삭제
    void deleteAuditChecklist(TBAuditChecklistDto tbAuditChecklistDto);

    // Chapter 등록
    TBAuditChapterDto insertAuditChapter(TBAuditChapterDto tbAuditChapterDto);

    // Chapter 수정
    TBAuditChapterDto updateAuditChapter(TBAuditChapterDto tbAuditChapterDto);

    // chapter 삭제
    TBAuditChapterDto deleteAuditChapter(TBAuditChapterDto tbAuditChapterDto);
}
