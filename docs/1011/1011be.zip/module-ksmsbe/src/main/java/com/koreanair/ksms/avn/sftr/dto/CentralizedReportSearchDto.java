package com.koreanair.ksms.avn.sftr.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class CentralizedReportSearchDto extends CommonDto {

    @Schema(description = "페이지 번호")
    private int pageNum;

    @Schema(description = "페이지 사이즈")
    private int pageSize;

    @Schema(description = "제목명")
    private String subjectNm;

    @Schema(description = "시작일자")
    private String fromDate;

    @Schema(description = "종료일자")
    private String toDate;

    @Schema(description = "편명")
    private String flightNo;

    @Schema(description = "기종")
    private String regNo;

    @Schema(description = "관리번호")
    private String groupNo;

    @Builder
    public CentralizedReportSearchDto(
            Integer pageNum,
            Integer pageSize,
            String subjectNm,
            String fromDate,
            String toDate,
            String flightNo,
            String regNo,
            String groupNo
            ) {
        this.pageNum = pageNum == null ? 1 : pageNum;
        this.pageSize = pageSize == null ? 10 : pageSize;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.flightNo = flightNo;
        this.regNo = regNo;
        this.groupNo = groupNo;
        this.subjectNm = subjectNm;

    }
}
