package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import io.vertx.core.json.JsonArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AvnReportFirstAssessmentServiceImpl extends AbstractBaseService implements AvnReportFirstAssessmentService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnReportRiskAssessmentService avnReportRiskAssessmentService;

    @Override
    public RiskAssessmentVo selectReportFirstAssessment(ReportInfoDto.GET_Request dto) {

        int groupId = dto.getP_groupId();
        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        String empNo = userInfo.getEmpNo();
        RiskAssessmentDto parameter = new RiskAssessmentDto().setGroupId(groupId).setView(true);

        RiskAssessmentVo detail = avnReportRiskAssessmentService.selectReportRiskAssessment(parameter, userInfo);
        if (detail == null) {
            return null;
        }
        // lsc 담당자(리더) 여부를 체크하여 flag를 넣어줌
        SmsAuthDto authDto = new SmsAuthDto(userInfo)
                .setId(groupId)
                .setEmpNo(empNo);
        boolean leader = avnReportRiskAssessmentService.isLscLeader(authDto, false);
        detail.setLeader(leader);

        // lsc 담당자(멤버) 여부를 체크하여 flag를 넣어줌
        if (!leader) {
            boolean member = avnReportRiskAssessmentService.isLscMember(authDto, false);
            detail.setMember(member);
        }
        return detail;
    }
}
