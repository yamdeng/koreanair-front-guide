package com.koreanair.ksms.avn.sftr.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sftr.dto.CentralizedGroupDto;
import com.koreanair.ksms.avn.sftr.dto.CentralizedReportDto;
import com.koreanair.ksms.avn.sftr.dto.CentralizedReportSearchDto;
import com.koreanair.ksms.avn.sftr.service.AvnCentralizedReportService;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 안전보고서 - Centralized Report
 */
@Tag(name = "AvnCentralizedReport", description = "안전보고서 - Centralized Report API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnCentralizedReportController {

    @Autowired
    AvnCentralizedReportService avnCentralizedReportService;

    /**
     * 마스터 조회
     *
     * @param paramMap the search Map
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "마스터 조회", description = "마스터 조회 API")
    @GetMapping(value = "/report/centralized")
    public ResponseEntity<?> getCentralizedReportList(@RequestParam Map<String, Object> paramMap) {
        CentralizedReportSearchDto reportSearchDto =
                CentralizedReportSearchDto.builder()
                        .pageNum( Integer.parseInt(paramMap.get("pageNum").toString()))
                        .pageSize( Integer.parseInt(paramMap.get("pageSize").toString()))
                        .flightNo( paramMap.get("flightNo") != null ? paramMap.get("flightNo").toString() : "")
                        .regNo( paramMap.get("regNo") != null ? paramMap.get("regNo").toString() : "")
                        .subjectNm( paramMap.get("subjectNm") != null ? paramMap.get("subjectNm").toString() : "")
                        .fromDate( paramMap.get("fromDate") != null ? paramMap.get("fromDate").toString() : "")
                        .toDate( paramMap.get("toDate") != null ? paramMap.get("toDate").toString() : "")
                        .build();

        // Page 조회
        PageHelper.startPage(reportSearchDto.getPageNum(), reportSearchDto.getPageSize());
        PageInfo<CentralizedGroupDto> pageList = avnCentralizedReportService.selectCentralizedGroupList(reportSearchDto);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    /**
     * 마스터 수정 저장
     *
     * @param dto the CentralizedGroupDto
     * @return success
     */
    @Operation(summary = "마스터 수정 저장", description = "마스터 수정 저장 API")
    @PutMapping(value = "/report/centralized")
    public ResponseEntity<?> updateCentralizedGroup(
              @Valid @RequestBody(required=true) CentralizedGroupDto dto)
    {
        avnCentralizedReportService.updateCentralizedGroup(dto);
        return ResponseUtil.createSuccessResponse(dto);
    }

    /**
     * 마스터 상세 조회
     *
     * @param Integer the groupId
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "마스터 상세 조회", description = "마스터 상세 조회 API")
    @GetMapping(value = "/report/centralized/{groupId}")
    public ResponseEntity<?> getCentralizedGroupReportInfo(
            @PathVariable(value="groupId", required=true) Integer groupId)
    {
        CentralizedGroupDto dto = new CentralizedGroupDto();
        dto.setGroupId(groupId);
        CentralizedGroupDto groupReportInfo = avnCentralizedReportService.selectCentralizedGroupReportInfo(dto);
        return ResponseUtil.createSuccessResponse(groupReportInfo);
    }

    /**
     * 디테일 조회
     *
     * @param Integer the groupId
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "디테일 조회", description = "디테일 조회 API")
    @GetMapping(value = "/report/centralized/detail/{groupId}")
    public ResponseEntity<?> getCentralizedReportList(
            @PathVariable(value="groupId", required=true) Integer groupId)
    {
        CentralizedGroupDto dto = new CentralizedGroupDto();
        dto.setGroupId(groupId);
        List<CentralizedReportDto> reportList = avnCentralizedReportService.selectCentralizedReportList(dto);
        return ResponseUtil.createSuccessResponse(reportList);
    }

    /**
     * 디테일 신규 저장
     *
     * @param reportId the report id
     * @param groupId the group id
     * @return success
     */
    @Operation(summary = "디테일 신규 저장", description = "디테일 신규 저장 API")
    @PostMapping(value = "/report/centralized/detail/{groupId}")
    public ResponseEntity<?> insertCentralizedReport(
              @Valid @RequestBody(required=true) CentralizedGroupDto dto
            , @PathVariable(value="groupId", required=true) Integer groupId)
    {
        dto.setGroupId(groupId);
        avnCentralizedReportService.insertCentralizedReport(dto);
        return ResponseUtil.createSuccessResponse(dto);
    }

    @Operation(summary = "디테일 삭제", description = "디테일 삭제 API")
    @DeleteMapping(value = "/report/centralized/detail/{groupId}/{id}")
    ResponseEntity<?> deleteCentralizedReport(
            @PathVariable(value="groupId", required=true) Integer groupId,
            @PathVariable(value="id", required=true) Integer id)
    {
        CentralizedGroupDto dto = new CentralizedGroupDto();
        dto.setId(id);
        dto.setGroupId(groupId);
        avnCentralizedReportService.deleteCentralizedReport(dto);
        return ResponseUtil.createSuccessResponse(dto);
    }










    @Operation(summary = "센트럴 레포트 Batch TEST(나중에 삭제 가능)", description = "센트럴 레포트 - Batch TEST")
    @GetMapping("/report/test/centralized")
    public ResponseEntity<?> getCentralizedReport()
    {
        try {
            avnCentralizedReportService.insertBatchCentralizedReport();
            return ResponseUtil.createSuccessResponse();
        } catch (Exception e) {
            throw new CustomBusinessException("System Error");
        }
    }
}
