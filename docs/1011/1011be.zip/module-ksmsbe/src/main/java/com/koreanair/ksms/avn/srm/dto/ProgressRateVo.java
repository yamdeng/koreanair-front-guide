package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;

import com.koreanair.ksms.common.dto.CommonDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ProgressRateVo extends CommonDto {

    private int rateId;

    private int rateMitigationId;

    private String contents;

    private Timestamp startDateAt;

    private Timestamp endDateAt;

    private int percent;


}
