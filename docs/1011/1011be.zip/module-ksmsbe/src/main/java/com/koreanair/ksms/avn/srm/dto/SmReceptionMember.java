package com.koreanair.ksms.avn.srm.dto;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class SmReceptionMember {
	
	private String roleCd;
	
	private int userId;
	
	private int deptId;
	
	private String empNo;
	
	private String nameKor;
	
	private String nameEng;
	
	private String email;
	
	private String deptNameKor;
	
	private String deptNameEng;
	
	private String rankId;
	
	private String rankNameKor;
	
	private String rankNameEng;
	
	public void setDecryptEmail(String decryptEmail) {
		this.email = decryptEmail;
	}

}
