package com.koreanair.ksms.avn.srm.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.dto.TbAvnSysUserDto;
import com.koreanair.ksms.common.dto.AvnIvReportApproval;
import com.koreanair.ksms.common.dto.AvnIvReportApprovalGroup;
import com.koreanair.ksms.common.dto.AvnIvReportApprovalGroupMember;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.service.AvnSafetyInvestigationService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 안전위험관리 - 안전조사
 */
@Tag(name = "AvnSafetyInvestigation", description = "안전위험관리 - 안전조사 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyInvestigationController {

    @Autowired
    AvnSafetyInvestigationService service;

    /**
     * 조사보고서 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "조사보고서 목록 조회", description = "조사보고서 목록 조회 API")
    @GetMapping(value = "/srm/investigations")
    public ResponseEntity<?> getInvestigationList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "조사보고서 상세정보 조회", description = "조사보고서 상세정보 조회 API")
    @GetMapping(value = "/srm/investigations/{investigationId}")
    public ResponseEntity<?> getInvestigationInfo(@PathVariable(value="investigationId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 조사보고서 등록", description = "신규 조사보고서 등록 API")
    @PostMapping(value = "/srm/investigations")
    public ResponseEntity<?> insertInvestigation(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "조사보고서 정보 수정", description = "조사보고서 정보 수정 API")
    @PutMapping(value = "/srm/investigations/{investigationId}")
    public ResponseEntity<?> updateInvestigation(
            @PathVariable(value="investigationId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "조사보고서 삭제", description = "조사보고서 삭제 API")
    @DeleteMapping(value = "/srm/investigations/{investigationId}")
    public ResponseEntity<?> deleteInvestigation(@PathVariable(value="investigationId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 안전조사 리포트 목록 조회
     *
     * @param avnSafetyInvestigationDto the AvnSafetyInvestigationDto
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전조사 리포트 목록 조회", description = "안전조사 리포트 목록 조회 API")
    @GetMapping(value = "/srm/investigation/reports")
    public ResponseEntity<?> getInveReportList(AvnSafetyInvestigationDto avnSafetyInvestigationDto)
    {

        PageHelper.startPage(avnSafetyInvestigationDto.getPageNum(), avnSafetyInvestigationDto.getPageSize());
        PageInfo<AvnSafetyInvestigationDto> pageList = service.selectInveReportList(avnSafetyInvestigationDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "안전조사 리포트 상세정보 조회", description = "안전조사 리포트 상세정보 조회 API")
    @GetMapping(value = "/srm/investigation/reports/{reportId}")
    public ResponseEntity<?> getInveReportInfo(@PathVariable(value="reportId", required=true) int id) {

        AvnSafetyInvestigationDetailDto resultData = service.selectIvReportDetail(id);

        return ResponseUtil.createSuccessResponse(resultData);
    }

    @Operation(summary = "신규 안전조사 리포트 등록", description = "신규 안전조사 리포트 등록 API")
    @PostMapping(value = "/srm/investigation/reports")
    public ResponseEntity<?> insertInveReport(@Valid @RequestBody(required=true) AvnSafetyInvestigationFormDto avnSafetyInvestigationFormDto) {

        service.insertInvestigation(avnSafetyInvestigationFormDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전조사 리포트 정보 수정", description = "안전조사 리포트 정보 수정 API")
    @PutMapping(value = "/srm/investigation/reports/{reportId}")
    public ResponseEntity<?> updateInveReport(
            @PathVariable(value="reportId", required=true) int reportId,
            @Valid @RequestBody(required=true) AvnSafetyInvestigationUpdateFormDto avnSafetyInvestigationUpdateFormDto) {

        avnSafetyInvestigationUpdateFormDto.setId(reportId);

        service.updateInvestigation(avnSafetyInvestigationUpdateFormDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전조사 리포트 경감조치 상세정보 조회", description = "안전조사 리포트 경감조치 상세정보 조회 API")
    @GetMapping(value = "/srm/investigation/reports/mitigation/{reportId}")
    public ResponseEntity<?> getInveReportMitigationInfo(@PathVariable(value="reportId", required=true) int id) {

        AvnSafetyInvestigationMitigationDetailDto resultData = service.selectIvReportMitigationDetail(id);

        return ResponseUtil.createSuccessResponse(resultData);
    }

    @Operation(summary = "안전조사 리포트 경감조치 정보 수정", description = "안전조사 리포트 경감조치 정보 수정 API")
    @PutMapping(value = "/srm/investigation/reports/mitigation/{reportId}")
    public ResponseEntity<?> updateInveReportMitigation(
            @PathVariable(value="reportId", required=true) int reportId,
            @Valid @RequestBody(required=true) AvnSafetyInvestigationMitigationUpdateFormDto avnSafetyInvestigationMitigationUpdateFormDto) {

        avnSafetyInvestigationMitigationUpdateFormDto.setId(reportId);

        service.updateInvestigationMitigation(avnSafetyInvestigationMitigationUpdateFormDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "조사보고서 CA 삭제", description = "조사보고서 CA 삭제 API")
    @DeleteMapping(value = "/srm/investigation/reports/recommend/{reportId}/{caId}")
    public ResponseEntity<?> deleteInveReportCa(
            @PathVariable(value = "reportId", required = true) int reportId,
            @PathVariable(value = "caId", required = true) int caId
    ){
        TbAvnIvCaDto tbAvnIvCaDto = new TbAvnIvCaDto();
        tbAvnIvCaDto.setReportId(reportId);
        tbAvnIvCaDto.setId(caId);
        service.deleteInveReportCa(tbAvnIvCaDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전조사 리포트 삭제", description = "안전조사 리포트 삭제 API")
    @DeleteMapping(value = "/srm/investigation/reports/{reportId}")
    public ResponseEntity<?> deleteInveReport(@PathVariable(value="reportId", required=true) int reportId) {

        service.deleteInvestigation(reportId);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 안전조사 이벤트 Type 목록 조회
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전조사 eventType 목록 조회", description = "안전조사 eventType 목록 조회 API")
    @GetMapping(value = "/srm/investigation/eventTypeASR")
    public ResponseEntity<?> getEventTypeASRList()
    {
        
        List<AvnSafetyInvestigationEventTypeDto> eventTypeList = service.selectEventTypeASRList();
        return ResponseUtil.createSuccessResponse(eventTypeList);
    }

    /**
     * 안전조사 Potential consequence 목록 조회
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전조사 Potential consequence 목록 조회", description = "안전조사 Potential consequence 목록 조회 API")
    @GetMapping(value = "/srm/investigation/consequence")
    public ResponseEntity<?> getConsequenceList()
    {
        List<AvnSafetyInvestifationConsequenceDto> consequenceList = service.selectConsequenceList();
        return ResponseUtil.createSuccessResponse(consequenceList);
    }

    /**
     * 안전조사 Hazard 목록 조회
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전조사 Hazard 목록 조회", description = "안전조사 Hazard 목록 조회 API")
    @GetMapping(value = "/srm/investigation/hazard")
    public ResponseEntity<?> getHazardList()
    {
        List<AvnSafetyInvestifationHazardDto> hazardList = service.selectHazardList();
        return ResponseUtil.createSuccessResponse(hazardList);
    }

    /**
     * 대시보드 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "대시보드 목록 조회", description = "대시보드 목록 조회 API")
    @GetMapping(value = "/srm/investigation/dashboards")
    public ResponseEntity<?> getDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 결재 그룹 목록 조회
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전조사 조사보고서 결재 그룹 목록 조회", description = "안전조사 조사보고서 결재 그룹 목록 조회 API")
    @GetMapping(value = "/srm/investigation/approvalGroupList")
    public ResponseEntity<?> getApprovalGroupList()
    {
        List<AvnIvReportApprovalGroup> approvalGroupList = service.selectApprovalGroupList();
        return ResponseUtil.createSuccessResponse(approvalGroupList);
    }

    /**
     * 결재 그룹 멤버 목록 조회
     * @param groupId the group id
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전조사 조사보고서 결재 그룹 멤버 목록 조회", description = "안전조사 조사보고서 결재 그룹 멤버 목록 조회 API")
    @GetMapping(value = "/srm/investigation/approvalGroupMemberList")
    public ResponseEntity<?> getApprovalGroupMemberList(@RequestParam(value="groupId", required=false) Integer groupId)
    {
        List<AvnIvReportApprovalGroupMember> approvalGroupMemberList = service.selectApprovalGroupMemberList(groupId);
        List<TbAvnSysUserDto> userList = new ArrayList<>();
        for(AvnIvReportApprovalGroupMember memberInfo : approvalGroupMemberList){
            TbAvnSysUserDto userData = service.searchEmpNoUserInfo(memberInfo);
            userList.add(userData);
        }

        HashMap<String,Object> resultData = new HashMap<String, Object>();

        resultData.put("approvalGroupMember",approvalGroupMemberList);
        resultData.put("GroupMemberInfo",userList);

        return ResponseUtil.createSuccessResponse(resultData);
    }

    @Operation(summary = "조사보고서 결재 그룹 등록", description = "조사보고서 결재 그룹 등록 API")
    @PostMapping(value = "/srm/investigation/approval")
    public ResponseEntity<?> insertIvApprovalGroup(@Valid @RequestBody(required=true) AvnIvReportApproval avnIvReportApproval) {

        service.insertIvApprovalGroup(avnIvReportApproval);
        return ResponseUtil.createSuccessResponse();
    }


}
