package com.koreanair.ksms.common.dto;

import java.sql.Timestamp;

import org.springframework.security.core.context.SecurityContextHolder;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CommonDto {
    private String regUserId = SecurityContextHolder.getContext().getAuthentication().getName();
    private String regUserNm;
    private String regDttm;
    private String updUserId = SecurityContextHolder.getContext().getAuthentication().getName();
    private String updUserNm;
    private String updDttm;
}
