package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode
public class RiskRegisterVo {
	private Integer id;
	private Integer reportId;
	private String docNo;
	private String hazardNo;
	private String reportType;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "Asia/Seoul")
	private Timestamp submittedAt;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "Asia/Seoul")
	private Timestamp receiptedAt;
	private Timestamp departureAt;
	private String regNo;
	private String flightNo;
	private String fromAirport;
	private String toAirport;
	private String aircraftType;
	private Integer fleetId;
	private String fleetCode;
	private Integer eventId;
	private String eventNameKo;
	private String eventNameEn;
	private String ataAdapterType;
	private String ataChapterNameKo;
	private String ataChapterNameEn;
	private Integer hazardId;
	private String lv1Name;
	private String lv2Name;
	private String lv3Name;
	private Integer consequenceId;
	private String potentialConsequenceKo;
	private String potentialConsequenceEn;
	private String newPotentialConsequenceKo;
	private String newPotentialConsequenceEn;
	private String severityDescrKo1;
	private String severityDescrEn1;
	private String severityCode1;
	private String probabilityCode1;
	private String probabilityDescrKo1;
	private String probabilityDescrEn1;
	private String riskLevel1;
	private int firstScore;
	private String controlDeptType;
	private String controlDeptNameKo;
	private String controlDeptNameEn;
	private String classificationNameKo;
	private String classificationNameEn;
	private String mitigation;
	private Integer deptId;
	private String deptNameKo;
	private String deptNameEn;
	private String mitigationPlan;
	private String mitigationResult;
	private String riskLevel2;
	private int secondScore;
	private String severityCode2;
	private String probabilityCode2;
	private String severityDescrKo2;
	private String severityDescrEn2;
	private String probabilityDescrKo2;
	private String probabilityDescrEn2;
	private String hazardState;
	private String statusKo;
	private String statusEn;
	private Timestamp closedAt;
	private String reportedBy;
	private String subject;
	private String eventSummary;
	private String isHf;
	private Integer percent;
	private String newEventType;
	private String newPotentialConsequence;
	private String isSpi;
	private String proposalType;
	private String contents;
	private String category;
}
