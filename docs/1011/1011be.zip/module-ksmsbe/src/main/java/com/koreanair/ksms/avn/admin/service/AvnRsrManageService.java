package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnEquipCodeMgmtDto;

public interface AvnRsrManageService {

    // EquipCd 목록 조회
    PageInfo<TbAvnEquipCodeMgmtDto> selectEquipCdList(TbAvnEquipCodeMgmtDto tbAvnEquipCodeMgmtDto);

    // EquipCd 신규 등록
    void insertEquipCd(TbAvnEquipCodeMgmtDto tbAvnEquipCodeMgmtDto);

    // EquipCd 상세
    TbAvnEquipCodeMgmtDto selectEquipCdDetail(String equipCd);

    // EquipCd 수정
    void updateEquipCd(TbAvnEquipCodeMgmtDto tbAvnEquipCodeMgmtDto);

    // EquipCd 삭제
    void deleteEquipCd(String equipCd);
}
