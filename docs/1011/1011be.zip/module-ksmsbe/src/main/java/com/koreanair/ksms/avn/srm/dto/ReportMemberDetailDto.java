package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

public class ReportMemberDetailDto {

    @Getter
    @Setter
    public static class GET_Request {

        @NotNull
        private int id;
        @NotNull
        private String docNo;
        @NotNull
        private String reportType;
        @NotNull
        private String receptionPage;

        private Boolean isFeedback;
    }

    @Getter
    @Setter
    @Builder
    public static class GET_Response {

        private ReportMemberDto dataSource;

        private String titleKo;

        private String titleEn;

        private String contentKo;

        private String contentEn;

        public static GET_Response of(
                GET_Request dto,
                TbSysUserDto member,
                KeNotificationTemplate template) {

            String docNo = dto.getDocNo();
            String receptionPage = dto.getReceptionPage();

            String titleKo = template.getSubjectEmailKo()
                    .replace("${static_doc_no}", docNo);
            String titleEn = template.getSubjectEmailEn()
                    .replace("${static_doc_no}", docNo);
            String contentKo = template.getContentEmailKo()
                    .replace("${reception_page}", receptionPage)
                    .replace("${doc_no}", docNo);
            String contentEn = template.getContentEmailEn()
                    .replace("${reception_page}", receptionPage)
                    .replace("${doc_no}", docNo);

            return GET_Response.builder()
                    .dataSource(ReportMemberDto.of(member))
                    .titleKo(titleKo)
                    .titleEn(titleEn)
                    .contentKo(contentKo)
                    .contentEn(contentEn)
                    .build();
        }

    }

    @Getter
    @Setter
    @Builder
    public static class ReportMemberDto {

        @JsonProperty("USER_ID")
        private String userId;

        @JsonProperty("DEPT_ID")
        private int deptId;

        @JsonProperty("EMP_NO")
        private String empNo;

        @JsonProperty("NAME_KOR")
        private String nameKor;

        @JsonProperty("NAME_ENG")
        private String nameEng;

        @JsonProperty("EMAIL")
        private String email;

        @JsonProperty("DEPT_NAME_KOR")
        private String deptNameKor;

        @JsonProperty("DEPT_NAME_ENG")
        private String deptNameEng;

        @JsonProperty("RANK_ID")
        private String rankId;

        @JsonProperty("RANK_NAME_KOR")
        private String rankNameKor;

        @JsonProperty("RANK_NAME_ENG")
        private String rankNameEng;

        public static ReportMemberDto of(TbSysUserDto entity) {
            return ReportMemberDto.builder()
                    .userId(entity.getUserId())
                    .deptId(entity.getDeptId())
                    .empNo(entity.getEmpNo())
                    .nameKor(entity.getNameKor())
                    .nameEng(entity.getNameEng())
                    .email(entity.getEmail())
                    .deptNameKor(entity.getDeptNmKor())
                    .deptNameEng(entity.getDeptNmEng())
                    .rankId(String.valueOf(entity.getRankCd()))
                    .rankNameKor(entity.getRankNmKor())
                    .rankNameEng(entity.getRankNmEng())
                    .build();
        }
    }

}
