package com.koreanair.ksms.avn.srm.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class MitigationVo extends SmMitigation{
	
	private String nameKor;
	private String nameEng;
	private String deptNameKor;
	private String deptNameEng;
	private String rankNameKor;
	private String rankNameEng;
	
}
