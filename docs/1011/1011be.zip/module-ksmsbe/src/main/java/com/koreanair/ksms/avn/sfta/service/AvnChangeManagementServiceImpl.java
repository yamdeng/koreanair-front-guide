package com.koreanair.ksms.avn.sfta.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnChangeMgmtDto;
import com.koreanair.ksms.common.dto.TbAvnReportDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnChangeManagementServiceImpl extends AbstractBaseService implements AvnChangeManagementService {

    @Override
    public PageInfo<TbAvnChangeMgmtDto> getChangeList(TbAvnChangeMgmtDto param) {
        List<TbAvnChangeMgmtDto> resultList = commonSql.selectList("AvnChangeManagement.selectChangeList", param);
        return PageInfo.of(resultList);
    }

    @Override
    public TbAvnChangeMgmtDto getChangeDetail(TbAvnChangeMgmtDto param) {
        TbAvnChangeMgmtDto resultList = commonSql.selectOne("AvnChangeManagement.selectChangeList", param);
        return resultList;
    }

    @Override
    public void insertChangeMgmt(TbAvnChangeMgmtDto param) {
        commonSql.insert("AvnChangeManagement.insertChangeMgmt", param);
        return ;
    }

    @Override
    public void updateChangeMgmt(TbAvnChangeMgmtDto param) {
        commonSql.update("AvnChangeManagement.updateChangeMgmt", param);
        return ;
    }

    @Override
    public void deleteChangeMgmt(int param) {
        commonSql.delete("AvnChangeManagement.deleteChangeMgmt", param);
        return ;
    }

    @Override
    public int insertReport(TbAvnChangeMgmtDto param) {

        int reportId = commonSql.selectOne("AvnSafetyReport.selectMaxReportId");

        TbAvnReportDto tbAvnReportDto = new TbAvnReportDto();
        tbAvnReportDto.setReportId(reportId);
        tbAvnReportDto.setReportTypeCd("chr");
        tbAvnReportDto.setReportPhaseCd("reporting");
        tbAvnReportDto.setReportStatusCd("Draft");
        
        tbAvnReportDto.setSubjectNm(param.getSubjectNm());
        tbAvnReportDto.setFileGroupSeq(param.getFileGroupSeq());
        tbAvnReportDto.setDescriptionTxtcn(param.getChangeTxtcn());
        tbAvnReportDto.setChangeMgmtId(param.getChangeMgmtId());
        commonSql.delete("AvnSafetyReport.insertReport", tbAvnReportDto);
        
        return reportId;
    }
}
