package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.dto.TbAvnInstructorHistDto;

public interface AvnInstructorManageService {

    // 관리자 > SMS교육 > 강사이력관리 목록 조회
    PageInfo<TbAvnInstructorHistDto> selectInstructorManage(TbAvnInstructorHistDto tbAvnInstructorHistDto);

    // 관리자 > SMS교육 > 강사이력관리 신규 등록
    void inserInstructorManage(TbAvnInstructorHistDto tbAvnInstructorHistDto);

    // 관리자 > SMS교육 > 강사이력관리 상세
    TbAvnInstructorHistDto selectInstructorManageDetail(String empNo);

    // 관리자 > SMS교육 > 강사이력관리 수정
    void updateInstructorManage(TbAvnInstructorHistDto tbAvnInstructorHistDto);

    // 관리자 > SMS교육 > 강사이력관리 삭제
    void deleteInstructorManage(String empNo);
}
