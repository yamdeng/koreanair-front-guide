package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.RiskRegisterDto;
import com.koreanair.ksms.avn.srm.dto.RiskRegisterVo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class AvnRiskRegisterServiceImpl extends AbstractBaseService implements AvnRiskRegisterService {

    @SuppressWarnings("unchecked")
    @Override
    public List<RiskRegisterVo> selectRiskRegisterViewlist(RiskRegisterDto parameter) {
        try {
            logger.debug("test{}",parameter);
            return commonSql.selectList("AvnRiskRegister.selectRiskRegisterViewlist", parameter);
        } catch (Exception e) {

        }
        return Collections.emptyList();
    };

}
