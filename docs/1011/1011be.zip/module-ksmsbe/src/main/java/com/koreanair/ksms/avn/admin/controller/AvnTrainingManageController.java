package com.koreanair.ksms.avn.admin.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.service.AvnTrainingManageService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnEducationDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 - 교육관리
 */
@Tag(name = "AvnTrainingManage", description = "관리자 - 교육관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnTrainingManageController {

    @Autowired
    AvnTrainingManageService service;

    /**
     * 교육관리 목록 조회
     *
     * @param pageNum the search word
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "교육관리 목록 조회", description = "교육관리 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호")
            , @Parameter(name = "pageSize", description = "페이지 목록 개수")
            , @Parameter(name = "educationId", description = "교육ID")
            , @Parameter(name = "educationDt", description = "교육일자")
            , @Parameter(name = "educationCd", description = "교육구분")
            , @Parameter(name = "subjectNm", description = "제목")
            , @Parameter(name = "useYn", description = "사용여부")
    })
    @GetMapping(value = "/admin/educations")
    public ResponseEntity<?> getTrainingManageList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            , @RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            , @RequestParam(value="educationDt", required = false) String educationDt
            , @RequestParam(value="educationCd", required = false) String educationCd
            , @RequestParam(value="subjectNm", required = false) String subjectNm
            , @RequestParam(value="useYn", required = false, defaultValue = "ALL") String useYn) {

        // 조회조건 parameter
        TbAvnEducationDto tbAvnEducationDto = new TbAvnEducationDto();

        tbAvnEducationDto.setEducationDt(educationDt);  // 교육일자
        tbAvnEducationDto.setEducationCd(educationCd);  // 교육구분
        tbAvnEducationDto.setSubjectNm(subjectNm);      // 제목
        tbAvnEducationDto.setUseYn(useYn);              // 사용여부

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnEducationDto> pageList = service.selectAvnEducationMgmt(tbAvnEducationDto);
        // 전체 조회
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "교육관리 상세정보 조회", description = "교육관리 상세정보 조회 API")
    @GetMapping(value = "/admin/educations/{educationId}")
    public ResponseEntity<?> getTrainingManageInfo(@PathVariable(value="educationId", required=true) int educationId) {

        TbAvnEducationDto result = service.selectAvnEducationMgmtDetail(educationId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 교육관리 등록", description = "신규 교육관리 등록 API")
    @PostMapping(value = "/admin/educations")
    public ResponseEntity<?> insertTrainingManage(@Valid @RequestBody(required=true) TbAvnEducationDto tbAvnEducationDto) {

        service.insertAvnEducationMgmt(tbAvnEducationDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "교육관리 정보 수정", description = "교육관리 정보 수정 API")
    @PutMapping(value = "/admin/educations/{educationId}")
    public ResponseEntity<?> updateTrainingManage(
            @PathVariable(value="educationId", required=true) int educationId,
            @Valid @RequestBody(required=true) TbAvnEducationDto tbAvnEducationDto) {

        tbAvnEducationDto.setEducationId(educationId);
        service.updateAvnEducationMgmt(tbAvnEducationDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "교육관리 삭제", description = "교육관리 삭제 API")
    @DeleteMapping(value = "/admin/educations/{educationId}")
    public ResponseEntity<?> deleteTrainingManage(@PathVariable(value="educationId", required=true) int educationId) {

        service.deleteAvnEducationMgmt(educationId);
        return ResponseUtil.createSuccessResponse();
    }
}
