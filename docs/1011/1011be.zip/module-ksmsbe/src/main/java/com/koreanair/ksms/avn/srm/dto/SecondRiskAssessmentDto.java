package com.koreanair.ksms.avn.srm.dto;


import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

public class SecondRiskAssessmentDto {
	
	@Getter
	@Setter
	@AllArgsConstructor
	@ToString
	public static class GET_Request {
		private int id; // hazard id;
	}

	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class POST_Request {
		@NotNull
		private int id;	// hazard id
		@NotNull
		private int groupId;	//group id
		@NotNull
		private String approvalType;
		private String reason;
		public ReportProcessVo makeProcessVo(String empNo) {
			ReportProcessVo proccessVo = new ReportProcessVo()
					.setEmpNo(empNo).
					setHazardId(this.id)
					.setGroupId(this.groupId)
					.setReason(this.reason);
			return proccessVo;
		}
	}

	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class PUT_Request {
		@NotNull
		private RiskAssessmentVo detail;
		private String empNo ;
	}

}
