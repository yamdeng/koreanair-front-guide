package com.koreanair.ksms.avn.sfta.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.utils.DateUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class AvnSafetyAssuranceServiceImpl extends AbstractBaseService implements AvnSafetyAssuranceService {

    @Transactional
   	@Override
    public void batchSafetyAssurance() throws Exception {
        logger.debug("[START] INESRT SAFETY ASSURANCE LIST", DateUtil.now("yyyy-MM-dd HH:mm:ss"));
        //경감조치유효성 평가 대상 목록 조회
        List<Map<String, Object>> list = commonSql.selectList("AvnSafetyAssurance.assuranceList");
        logger.debug("SAFETY ASSURANCE LIST COUNT: {}", list.size());

        if(list.size() > 0) {
            //경감조치유효성 평가 대상 목록에 이미 존재 할경우 중복 노출 방지 처리
            //updateOldAssurance(list);

            //경감조치유효성 평가 대상 등록
            int insertCount = 0;
            for (Map<String, Object> param : list) {
                int cnt = insertSafetyAssuranceList(param);
                insertCount = insertCount + cnt;
            }

            //경감조치유효성 평가 대상에 등록이된 Hazard 의 is_mitigation_validation 값을 "Y" 로 변경 / 다음 대상 조회시 제외처리용
            int updateCount = updateMitigationValidation(list);

            if(insertCount != updateCount) {
                throw new RuntimeException("insertCount and updateCount are different");
            }
        }
        logger.debug("[END] INESRT SAFETY ASSURANCE LIST", DateUtil.now("yyyy-MM-dd HH:mm:ss"));
    }

    @Transactional
   	public int insertSafetyAssuranceList(Map<String, Object> param) throws Exception {
   		return commonSql.insert("AvnSafetyAssurance.insertAssuranceList", param);
   	}

   	@Transactional
   	public int updateMitigationValidation(List<Map<String, Object>> list) throws Exception {
   		return commonSql.update("AvnSafetyAssurance.updateMitigationValidation", list);
   	}
}
