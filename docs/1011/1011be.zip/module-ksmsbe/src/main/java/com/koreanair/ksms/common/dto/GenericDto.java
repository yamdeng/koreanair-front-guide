package com.koreanair.ksms.common.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class GenericDto extends CommonDto {

    private String key;
    private String field1;
    private String field2;
    private String field3;
}
