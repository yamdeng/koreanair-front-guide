package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SmReceptionFoqa {
	@NotNull
	private int id;
	
	@NotNull
	private int receptionId;

	private String foqaUsa;

	private String foqaValid;

	private String foqaGoAround;

	@NotNull
	private String foqaMetar;


}
