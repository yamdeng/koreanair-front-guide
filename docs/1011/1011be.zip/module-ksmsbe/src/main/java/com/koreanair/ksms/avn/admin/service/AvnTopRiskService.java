package com.koreanair.ksms.avn.admin.service;

import java.util.List;
import java.util.Map;

import com.koreanair.ksms.avn.admin.dto.TopRiskDto;

public interface AvnTopRiskService {
    List<TopRiskDto> selectTotalTopRiskList(Map<String, Object> param);
    List<TopRiskDto> selectOutlierRemoveList(Map<String, Object> param);
    List<TopRiskDto> selectOutlierList(Map<String, Object> param);
}
