package com.koreanair.ksms.avn.audit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
@Schema(description = "Audit / Audit 마스터")
@JsonIgnoreProperties(value = {"handler"})
public class TBAuditDto extends CommonDto {
    @Schema(description = "auditId")
    @NotNull
    private int auditId;
    private String auditNo;
    private String title;
    private String division;
    private String urlPlan;
    private String urlResult;
    private String isFinding;
    private String phase;
    private int phaseLevel;
    private String state;
    private String timezone;
    private Timestamp auditAt;
    private String isRemote;
    private String airlineCategory;
    private String auditTypeCode;
    private String isSubmmited;
    private Timestamp submittedAt;
    private String notes;
    private String approvedBy;
    private int planFileGroupSeq;
    private int resultFileGroupSeq;
    private int preFileGroupSeq;
    private String useYn;
    private String airport;

    // Auditee 정보
    private TBAuditeeDto auditeeInfo;

    // Auditor 정보
    private List<TBAuditorDto> auditorInfo;

    // Checklist 정보 (Chapter, Question 포함)
    private List<TBAuditChecklistDto> checklistInfo;

    // Finding 정보 (RootCause, Mitigation, Mitigation User 포함)
    private List<TBAuditFindingDto> findingInfo;

}
