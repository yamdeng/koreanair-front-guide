package com.koreanair.ksms.avn.sfta.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SPT / SPI 지표별 현황")
public class SpiStatusDto extends CommonDto {
    
    @Schema(description = "연도")
    private String year;
    private String spiYear;
    
    @Schema(description = "지표코드")
    private String spiCd;
    private String value;
    
    @Schema(description = "지표명")
    private String spiNm;
    private String label;
    
    @Schema(description = "지표구분")
    private String spiTypeCd;
    
    @Schema(description = "지표분류")
    private String spiTaxonomyCd;
    
    @Schema(description = "산출기준")
    private String outputStndCd;
    
    @Schema(description = "지표정의")
    private String spiDescrCn;
    
    @Schema(description = "소스")
    private String dataSourcesCd;
    
    @Schema(description = "주의 점수")
    private double spiCautionScore;
    
    @Schema(description = "경계 점수")
    private double spiWarnScore;
    
    @Schema(description = "심각 점수")
    private double spiCriticalScore;
    
    @Schema(description = "목표치")
    private double spiTargetScore;
    
    @Schema(description = "사용여부")
    private String useYn;
    
    @Schema(description = "표시순서, -1은 표시하지 않음. 0부터 시작")
    private String viewSn;


    @Schema(description = "당해년도 1월 ~12월 건수")
    private int stnd01Cnt;
    private int stnd02Cnt;
    private int stnd03Cnt;
    private int stnd04Cnt;
    private int stnd05Cnt;
    private int stnd06Cnt;
    private int stnd07Cnt;
    private int stnd08Cnt;
    private int stnd09Cnt;
    private int stnd10Cnt;
    private int stnd11Cnt;
    private int stnd12Cnt;

    @Schema(description = "전년도 1월 ~12월 건수")
    private int bf01Cnt;
    private int bf02Cnt;
    private int bf03Cnt;
    private int bf04Cnt;
    private int bf05Cnt;
    private int bf06Cnt;
    private int bf07Cnt;
    private int bf08Cnt;
    private int bf09Cnt;
    private int bf10Cnt;
    private int bf11Cnt;
    private int bf12Cnt;

    @Schema(description = "당해년도 1월 ~ 12월 발생율")
    private double spiOcc01;
    private double spiOcc02;
    private double spiOcc03;
    private double spiOcc04;
    private double spiOcc05;
    private double spiOcc06;
    private double spiOcc07;
    private double spiOcc08;
    private double spiOcc09;
    private double spiOcc10;
    private double spiOcc11;
    private double spiOcc12;
    
}
