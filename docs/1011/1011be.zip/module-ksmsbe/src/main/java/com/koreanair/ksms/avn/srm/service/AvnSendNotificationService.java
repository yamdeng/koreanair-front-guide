package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.KeNotificationEmail;
import com.koreanair.ksms.avn.srm.dto.KeNotificationTemplate;
import com.koreanair.ksms.avn.srm.dto.RiskRegisterDto;
import com.koreanair.ksms.avn.srm.dto.RiskRegisterVo;
import com.koreanair.ksms.common.dto.MailDto;
import io.vertx.core.json.JsonObject;

import java.util.List;
import java.util.Map;

public interface AvnSendNotificationService {
    boolean sendEmail(String sendEmpNo, List<String> recvEmpNoList, String notiType, Map<String, String> contentsMap);
    boolean sendEmail(List<MailDto> mailList, int templateId, String sendEmpNo, String recipientsEmpno);
    KeNotificationTemplate selectNotificationTemplate(String notiType) throws Exception;
    int insertNotificationLog(KeNotificationEmail notiEmail) throws Exception;
    boolean sendSysMsg(List<String> recvEmpNoList, String notiType, String link, Map<String, String> contentsMap);
    boolean sendSysMsg(JsonObject targetJsonObject, String notiType, String link, Map<String, String> contentsMap);
}
