package com.koreanair.ksms.avn.admin.controller;

import com.koreanair.ksms.avn.admin.service.AvnDeadlineManageService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 - 보고서 기한 관리
 */
@Tag(name = "AvnDeadlineManage", description = "관리자 - 보고서 기한 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnDeadlineManageController {

    @Autowired
    AvnDeadlineManageService service;

    /**
     * 보고서기한관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "보고서기한관리 목록 조회", description = "보고서기한관리 목록 조회 API")
    @GetMapping(value = "/admin/report-limits")
    public ResponseEntity<?> getDeadlineManageList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "보고서기한관리 상세정보 조회", description = "보고서기한관리 상세정보 조회 API")
    @GetMapping(value = "/admin/report-limits/{reportLimitId}")
    public ResponseEntity<?> getDeadlineManageInfo(@PathVariable(value="reportLimitId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 보고서기한관리 등록", description = "신규 보고서기한관리 등록 API")
    @PostMapping(value = "/admin/report-limits")
    public ResponseEntity<?> insertDeadlineManage(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "보고서기한관리 정보 수정", description = "보고서기한관리 정보 수정 API")
    @PutMapping(value = "/admin/report-limits/{reportLimitId}")
    public ResponseEntity<?> updateDeadlineManage(
            @PathVariable(value="reportLimitId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "보고서기한관리 삭제", description = "보고서기한관리 삭제 API")
    @DeleteMapping(value = "/admin/report-limits/{reportLimitId}")
    public ResponseEntity<?> deleteDeadlineManage(@PathVariable(value="reportLimitId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
