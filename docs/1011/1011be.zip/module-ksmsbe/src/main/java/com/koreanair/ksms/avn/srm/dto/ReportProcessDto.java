package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.utils.DateUtil;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.Objects;

@Getter
@Setter
@ToString
public class ReportProcessDto {

    private Integer id;

    private String docNo;

    private String reportType;

    private String empNo;

    private String managerEmpNo;

    private String isSpi;

    private String subject;

    private String timeZone;

    private Timestamp createdAt;

    private Timestamp updatedAt;

    private Timestamp deletedAt;

    private String isSubmitted;

    private Timestamp submittedAt;

    private int logId;

    private String state; // = "draft";

    private String phase; // = "reporting";

    private String stepCode; // = "draft";

    private String approvalEmpNo;

    private String approvalReason;

    private String approvalTimezone;

    private Timestamp approvalCreatedAt;

    private String flightNo;

    private Timestamp eventAt;

    public String getSubmittedAt() {
        if (Objects.isNull(this.submittedAt)) {
            return null;
        }
        return DateUtil.toDateFormat(this.submittedAt.getTime(), "yyyyMMdd");
    }

}
