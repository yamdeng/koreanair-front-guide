package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonInclude;

import com.koreanair.ksms.common.dto.CommonDto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SmReportHazard extends CommonDto {

    @NotNull
    private int id;

    @NotNull
    private int groupId;

    //@NotNull
    private int reportId;

    @NotNull
    private int hazardId;

    @NotNull
    private int consequenceId;

    @NotBlank
    private String empNo;

    @NotBlank
    private String riskLevel1;

    private String riskLevel1Color;

    private String isMitigation;

    @NotNull
    private int viewOrder;

    @NotBlank
    private String phase;

    @NotBlank
    private String stateType;

    @NotBlank
    private String stepCode;

    @NotBlank
    private String timeZone;

    @NotNull
    private Timestamp createdAt;

    @NotNull
    private Timestamp updatedAt;

    private Timestamp deletedAt;

    private String isMitigationValidation;

    private String riskLevel2;
    private String riskLevel2Color;

    private Integer assuranceMonth;

    private String hazardNo;

    public SmReportHazard(int groupId, int reportId, int hazardId, String state, String phase, String stepCode) {
        this.reportId = reportId;
        this.groupId = groupId;
        this.id = hazardId;
        this.stateType = state;
        this.phase = phase;
        this.stepCode = stepCode;
    }
}
