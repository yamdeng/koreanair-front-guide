package com.koreanair.ksms.avn.sfta.controller;

import com.koreanair.ksms.avn.sfta.service.AvnSafetyAssuranceService;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.jexl2.UnifiedJEXL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 안전보증 - 유효성평가관리
 */
@Tag(name = "AvnSafetyAssurance", description = "안전보증 - 유효성평가관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyAssuranceController {

    @Autowired
    AvnSafetyAssuranceService avnSafetyAssuranceService;

    /**
     * 유효성평가관리 배치 처리
     *
     * @return the list
     * @throws UnifiedJEXL.Exception the exception
     */
    @Operation(summary = "유효성평가관리 배치 처리", description = "유효성평가관리 배치 처리 - TEST")
    @PostMapping(value = "/assurance/safetyAssurance/batch")
    public void batchSafetyAssurance() {
        try {
            avnSafetyAssuranceService.batchSafetyAssurance();
        } catch (Exception e) {
            //throw new MicroServiceException(HttpStatus.INTERNAL_SERVER_ERROR, 500, "System Error");
            throw new CustomBusinessException("System Error", "2");
        }
    }
}
