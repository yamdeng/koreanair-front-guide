package com.koreanair.ksms.avn.main.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnMainServiceImpl extends AbstractBaseService implements AvnMainService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    @Override
    public List<Map<String, Object>> getTopRiskList() {

        List<Map<String, Object>> resultList = commonSql.selectList("AvnMain.selectTopRiskList");

        return resultList;
    }

    @Override
    public List<Map<String, Object>> getReportProcessList(String userId) {

        List<Map<String, Object>> resultList = commonSql.selectList("AvnMain.selectReportProcessList", userId);

        return resultList;
    }

    @Override
    public List<Map<String, Object>> getToDoList(String userId) {
        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());

        Map<String,Object> param = new HashMap<>();
        param.put("empNo", userInfo.getEmpNo());
        param.put("mitDeptId", userInfo.getDeptId());

        //사용자 보고서 권한(ROLE)조회
        List<String> authParam = new ArrayList<>();

        //접수권한 체크
        param.put("isAcceptanceAuth", "N");
        param.put("receptionReportTypeList", new ArrayList<>());
        authParam.add("report_acceptance");
        List<String> receptionReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (receptionReportTypeList != null) {
            if (!receptionReportTypeList.isEmpty()) {
                param.put("isAcceptanceAuth", "Y");

                if (receptionReportTypeList.contains("chr")) {
                    receptionReportTypeList.remove("chr");
                    param.put("division", userInfo.getSectorId());
                }
                if (receptionReportTypeList.isEmpty()) {
                    receptionReportTypeList.add("XXX");
                }
                param.put("receptionReportTypeList", receptionReportTypeList);
            }
        }

        //todo khw. 변화관리 보고서인 경우 : 부문 체크 필요




        //lsc 권한 체크
        param.put("isAssessmentAuth", "N");
        authParam = new ArrayList<>();
        authParam.add("risk_assessment");
        List<String> assessmentReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (assessmentReportTypeList != null) {
            if (!assessmentReportTypeList.isEmpty()) {
                if (assessmentReportTypeList.contains("assigned_report")) {
                    param.put("isAssessmentAuth", "Y");
                }
            }
        }

        //src 권한 체크
        param.put("isRiskAcceptanceAuth", "N");
        authParam = new ArrayList<>();
        authParam.add("ssc_review");
        List<String> riskAcceptanceReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (riskAcceptanceReportTypeList != null) {
            if (!riskAcceptanceReportTypeList.isEmpty()) {
                if (riskAcceptanceReportTypeList.contains("assigned_report")) {
                    param.put("isRiskAcceptanceAuth", "Y");
                }
            }
        }

        //로그인자의 결재 권한(직책) 체크
        boolean isDeptTeamLeader = false;
        if (userInfo.getPostDeptCd() != null) {
            if (!userInfo.getPostDeptCd().isEmpty()) {
                isDeptTeamLeader = true;
            }
        }
        //결재 권한 체크
        param.put("isApporovalAuth", "N");
        param.put("approvalReportTypeList", new ArrayList<>());
        authParam = new ArrayList<>();
        authParam.add("approval");
        List<String> approvalReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (approvalReportTypeList != null) {
            if (!approvalReportTypeList.isEmpty() && isDeptTeamLeader) {
                param.put("isApporovalAuth", "Y");

                if (approvalReportTypeList.contains("chr")) {
                    approvalReportTypeList.remove("chr");
                    param.put("division", userInfo.getSectorId());
                }
                if (approvalReportTypeList.isEmpty()) {
                    approvalReportTypeList.add("XXX");
                }
                param.put("approvalReportTypeList", approvalReportTypeList);
            }
        }


        //경감 권한 체크
        param.put("isMitigationAuth", "N");
        authParam = new ArrayList<>();
        authParam.add("mitigation");
        List<String> mitigationReportTypeList = avnCommonService.getAuthReportList(authParam, false);
        if (mitigationReportTypeList != null) {
            if (!mitigationReportTypeList.isEmpty()) {
                if (mitigationReportTypeList.contains("assigned_hazard")) {
                    param.put("isMitigationAuth", "Y");
                }
            }
        }


        //FOQA 권한 체크
        param.put("isFoqaXAuth", "N");
        List<String> roleList = avnCommonService.selectRoleList();
        if (roleList.contains("FVG")) {
            //열람권한
            param.put("isFoqaXAuth", "Y");
        }
        List<Map<String, Object>> todoList = commonSql.selectList("AvnMain.selectToDoList", param);
        return todoList;
    }

    @Override
    public List<TbAvnBoardDto> getBannerList() {
        BoardSearchDto boardSearchDto = BoardSearchDto.builder().viewYn("Y").boardType("60").useYn("Y").build();
        
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnMain.selectBoardList", boardSearchDto);

        return resultList;
    }

    @Override
    public List<TbAvnBoardDto> getNoticeList() {
        BoardSearchDto boardSearchDto = 
            BoardSearchDto.builder()
                            .viewYn("Y")
                            .boardType("70")
                            .useYn("Y")
                            .build();
        
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnMain.selectBoardList", boardSearchDto);

        return resultList;
    }

    @Override
    public List<Map<String, Object>> getAccidentList() {

        List<Map<String, Object>> resultList = commonSql.selectList("AvnMain.selectAccidentList");

        return resultList;
    }
}
