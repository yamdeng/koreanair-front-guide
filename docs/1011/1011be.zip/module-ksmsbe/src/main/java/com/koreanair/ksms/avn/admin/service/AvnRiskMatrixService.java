package com.koreanair.ksms.avn.admin.service;

import java.util.List;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.koreanair.ksms.common.dto.TbAvnRiskLevelMatrixDto;
import com.koreanair.ksms.common.dto.TbSysCodeDto;

public interface AvnRiskMatrixService {
    List<TbAvnRiskLevelMatrixDto> selectRiskMatrixList();
    void updateRiskMatrixList(ObjectNode saveObj);
    List<TbSysCodeDto> selectCodeList(String codeGrpId);
    
}
