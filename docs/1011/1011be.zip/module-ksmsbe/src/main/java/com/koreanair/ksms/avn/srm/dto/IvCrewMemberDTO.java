package com.koreanair.ksms.avn.srm.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class IvCrewMemberDTO {
    private String regUserId;
    private String regUserNm;
    private String regDttm;
    private String updUserId;
    private String updUserNm;
    private String updDttm;
    private String userId;
    private String empNo;
    private String nameKor;
    private String nameEng;
    private String nameChn;
    private String nameJpn;
    private String namaEtc;
    private String email;
    private String statusCd;
    private String deptCd;
    private String pstnCd;
    private String dutyCd;
    private String rankCd;
    private String photo;
    private int sortOrder;
    private String officeTelNo;
    private String mobileTelNo;
    private String compCd;
    private String subEmpNo;
    private String subCompCd;
    private String subEmail;
    private String empType;
    private String dsptYn;
    private String jobCd;
    private String bareaCd;
    private String eaiYn;
    private String classCd;
    private String className;
    private int groupId;
    private String groupCd;
    private String groupAdminYn;
    private String deptNmKor;
    private String deptNmEng;
    private String rankNmKor;
    private String rankNmEng;
    private String customLabel;
}
