package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.KeNotificationEmail;
import com.koreanair.ksms.avn.srm.dto.KeNotificationTemplate;
import com.koreanair.ksms.common.dto.MailDto;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import com.koreanair.ksms.common.utils.MailSender;
import io.micrometer.common.util.StringUtils;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import lombok.RequiredArgsConstructor;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Service
public class AvnSendNotificationServiceImpl extends AbstractBaseService implements AvnSendNotificationService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    private final MailSender mailSender;

	@Value("${spring.profiles.active}")
 	private String profile;

    @SuppressWarnings("unchecked")
   	@Transactional(propagation = Propagation.NOT_SUPPORTED)
   	@Override
   	public boolean sendEmail(String sendEmpNo, List<String> recvEmpNoList, String notiType, Map<String, String> contentsMap) {
		try {
			TbSysUserDto sendUserVo = new TbSysUserDto();
			// 사번으로 이메일정보 찾기
			if (StringUtils.isNotBlank(sendEmpNo)) {
				sendUserVo = ksmsCommonService.selectUserEmpNo(sendEmpNo);
				if (StringUtils.isNotBlank(sendUserVo.getEmail())) {
					String decryptEmail = avnCommonService.decryptValue(sendUserVo.getEmail());
					sendUserVo.setEmail(decryptEmail);
				}
			}
			if (StringUtils.isBlank(sendEmpNo) || StringUtils.isBlank(sendUserVo.getEmail())) {
				sendUserVo.setEmpNo("SYSTEM");
				sendUserVo.setEmail("safenet@koreanair.com");
				sendUserVo.setNameKor("SMS IT SYSTEM");
				sendUserVo.setNameEng("SMS IT SYSTEM");
			}

			// 메시지 템플릿 조회
			KeNotificationTemplate template = selectNotificationTemplate(notiType); // 템플릿이 없을경우 nullpoint exception
			if (template.getState().equalsIgnoreCase("INACTIVE") || template.getSendEmail().equalsIgnoreCase("N")) { // 비활성화된 메시지일 경우
				return true;
			}

			StringSubstitutor sub = new StringSubstitutor(contentsMap, "${", "}");

			String subjectKo = sub.replace(template.getSubjectEmailKo());
			String contentKo = sub.replace(template.getContentEmailKo());
			String subjectEn = sub.replace(template.getSubjectEmailEn());
			String contentEn = sub.replace(template.getContentEmailEn());

			String escapeHtmlContentKo = StringEscapeUtils.escapeHtml4(contentKo);
			String escapeHtmlContentEn = StringEscapeUtils.escapeHtml4(contentEn);

			List<TbSysUserDto> recvUserVoList = avnCommonService.selectUserEmpNoMultiList(recvEmpNoList);

			if (recvUserVoList.isEmpty()) {
				// 전달받을 사람이 없는 경우 - 로그 저장
				KeNotificationEmail notiEmail = new KeNotificationEmail(template.getId(), sendUserVo.getEmpNo(),
						"Recipient unknown", subjectKo, contentKo, "Y", "Recipient unknown, not actually sent.");
				insertNotificationLog(notiEmail);
				return true;
			}

			List<MailDto> koMailList = new ArrayList<>();
			List<MailDto> enMailList = new ArrayList<MailDto>();
			// 발송자 그룹을 2개로 분리 KO / EN
			List<String> koRecipientsEmpnoList = new ArrayList<String>();
			List<String> enRecipientsEmpnoList = new ArrayList<String>();
			// 영문 설정 사용자 목록
			List<String> userIdList = recvUserVoList.stream().map(TbSysUserDto::getUserId).collect(Collectors.toList());
			List<Integer> engLangUserIdList = commonSql.selectList("AvnSendNotification.selectEngLangUserIdList", userIdList);
			for (TbSysUserDto recvUserVo : recvUserVoList) {
				String decryptEmail = avnCommonService.decryptValue(recvUserVo.getEmail());

				/* todo khw. 원본....
				if (engLangUserIdList.contains(recvUserVo.getUserId())) { // 영문 메일 발송자
					enMailList.add(new MailDto(decryptEmail, recvUserVo.getNameEng(), subjectEn, escapeHtmlContentEn,
							sendUserVo.getEmail(), sendUserVo.getNameEng()));
					enRecipientsEmpnoList.add(recvUserVo.getEmpNo());
				} else { // 국문(한글) 메일 발송자
					koMailList.add(new MailDto(decryptEmail, recvUserVo.getNameKor(), subjectKo, escapeHtmlContentKo,
							sendUserVo.getEmail(), sendUserVo.getNameKor()));
					koRecipientsEmpnoList.add(recvUserVo.getEmpNo());
				}
				*/

				if (engLangUserIdList.contains(recvUserVo.getUserId())) { // 영문 메일 발송자
					enMailList.add(new MailDto("pj.reangel@kalmate.net", recvUserVo.getNameEng(), subjectEn, escapeHtmlContentEn,
							"pj.reangel@kalmate.net", sendUserVo.getNameEng()));
					enRecipientsEmpnoList.add(recvUserVo.getEmpNo());
				} else { // 국문(한글) 메일 발송자
					koMailList.add(new MailDto("pj.reangel@kalmate.net", recvUserVo.getNameKor(), subjectKo, escapeHtmlContentKo,
							"pj.reangel@kalmate.net", sendUserVo.getNameKor()));
					koRecipientsEmpnoList.add(recvUserVo.getEmpNo());
				}
			}

			// 1000자리 넘어가면 자르기 + 잘린 리스트 갯수 정보 포함하기
			int empLimit = 1000;
			String koRecipients = String.join(",", koRecipientsEmpnoList);
			String enRecipients = String.join(",", enRecipientsEmpnoList);
			if (koRecipients.length() > empLimit) {
				int lastIndex = koRecipients.substring(0, empLimit - 30).lastIndexOf(",");
				koRecipients = koRecipients.substring(0, lastIndex);
				koRecipients += " (...Total: " + String.format("%,d", koRecipientsEmpnoList.size()) + ")";
			}
			if (enRecipients.length() > empLimit) {
				int lastIndex = enRecipients.substring(0, empLimit - 30).lastIndexOf(",");
				enRecipients = enRecipients.substring(0, lastIndex);
				enRecipients += " (...Total: " + String.format("%,d", enRecipientsEmpnoList.size()) + ")";
			}

			return sendEmail(koMailList, template.getId(), sendUserVo.getEmpNo(), koRecipients)
					&& sendEmail(enMailList, template.getId(), sendUserVo.getEmpNo(), enRecipients);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

    @Override
   	public KeNotificationTemplate selectNotificationTemplate(String notiType) throws Exception {
   		return commonSql.selectOne("AvnSendNotification.selectNotificationTemplate", notiType);
   	}

    @Override
   	public int insertNotificationLog(KeNotificationEmail notiEmail) throws Exception {
   		// 메일 발송 이력 저장 ke.ke_notification
   		return commonSql.insert("AvnSendNotification.insertNotificationEmail", notiEmail);
   	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	@Override
	public boolean sendSysMsg(List<String> recvEmpNoList, String notiType, String link, Map<String, String> contentsMap) {

		// 수신자
		JsonObject targetJsonObject = new JsonObject();
		JsonArray empNoJsonArray = new JsonArray(recvEmpNoList);
		targetJsonObject.put("empNo", empNoJsonArray);

		return sendSysMsg(targetJsonObject, notiType, link, contentsMap);
	}

	@SuppressWarnings("unchecked")
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	@Override
	public boolean sendEmail(List<MailDto> mailList, int templateId, String sendEmpNo, String recipientsEmpno) {

		if(mailList.isEmpty()) {
			return true;
		}

		boolean result = false;
		String bodyString = "";
		try {
			if("prod".equals(profile)) {
				Map<String, Object> res = mailSender.send(mailList);

				ResponseEntity<String> response = (ResponseEntity<String>) res.get("response");

				bodyString = response.getBody();

				// parse result xml
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder;
				builder = factory.newDocumentBuilder();

				Document doc = builder.parse(new InputSource(new StringReader(bodyString)));
				NodeList nodelist = doc.getElementsByTagName("result");

				result = nodelist.item(0).getTextContent().equalsIgnoreCase("success");

			} else {
				result = true;
				bodyString = "For testing purposes, not actually sent.";
			}

			String isSuccess = result ? "Y" : "N";

			MailDto mail = mailList.get(0);
			KeNotificationEmail notiEmail = new KeNotificationEmail(templateId, sendEmpNo,
					recipientsEmpno, mail.getTitle(), StringEscapeUtils.unescapeHtml4(mail.getMsg()), isSuccess, bodyString);
			insertNotificationLog(notiEmail);

			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	@Override
	public boolean sendSysMsg(JsonObject targetJsonObject, String notiType, String link, Map<String, String> contentsMap) {
		try {
			//Locale locale = Locale.KOREAN;

			// 시스템메시지 발송설정
			JsonObject notiJsonObject = new JsonObject();
			notiJsonObject.put("APP_ID", 0);
			notiJsonObject.put("SITE_ID", 1);
			notiJsonObject.put("COMPANY_CD", "1000");

			// 수신자
			notiJsonObject.put("target", targetJsonObject);

			// 메시지 템플릿 조회
			KeNotificationTemplate template = selectNotificationTemplate(notiType);
			if (template.getState().equalsIgnoreCase("INACTIVE") || template.getSendAlarm().equalsIgnoreCase("N")) { // 비활성화된 메시지일 경우
				return true;
			}
			StringSubstitutor sub = new StringSubstitutor(contentsMap, "${", "}");

			String subjectKo = sub.replace(template.getSubjectAlarmKo());
			String contentKo = sub.replace(template.getContentAlarmKo());
			String subjectEn = sub.replace(template.getSubjectAlarmEn());
			String contentEn = sub.replace(template.getContentAlarmEn());
			JsonObject msgJsonObject = new JsonObject();
			msgJsonObject.put("TITLE_KOR", subjectKo);
			msgJsonObject.put("CONTENT_KOR", contentKo);
			msgJsonObject.put("TITLE_ENG", subjectEn);
			msgJsonObject.put("CONTENT_ENG", contentEn);
			//msgJsonObject.put("type", "success"); //success, info, warning, error (default info);

			notiJsonObject.put("message", msgJsonObject);

			// 링크 URL
			JsonObject linkJsonObject = new JsonObject();
			if(StringUtils.isNotEmpty(link)) {
				linkJsonObject.put("url", link);
			}
			notiJsonObject.put("link", linkJsonObject);

			/* todo khw 확인 필요
			long result = AbstractRedisClient.NOTIFY_ADD(notiJsonObject);

			return (result > 0L);

			 */
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
