package com.koreanair.ksms.avn.admin.service;

public interface AvnDeadlineManageService {
}
