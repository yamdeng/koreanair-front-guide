package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.constants.AvnStatusCode;

import java.util.List;
import java.util.Map;

public interface AvnReportSysNotiService {

    boolean sendSysMsg(List<String> to, String notiType, String link, Map<String, String> contentsMap);

    boolean sendMail(String from, List<String> to, String notiType, Map<String, String> contentsMap);

    void sendNoti(ReportProcessVo processVo, AvnStatusCode.ReportStatus stat);

    ReportProcessDto selectReportStatus(int id) throws Exception;
    HazardProcessDto selectHazardStatus(int id) throws Exception;

    MitigationMemberDto selectMitigationMember(int hazardId) throws Exception;
    List<LscMemberDto> selectLscMember(int reportId) throws Exception;
    List<ManagerMemberDto> selectManagerMember(boolean isIncludeSA, String ...reportType) throws Exception;
}
