package com.koreanair.ksms.avn.admin.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.service.AvnRsrManageService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnConsequenceDto;
import com.koreanair.ksms.common.dto.TbAvnEquipCodeMgmtDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 - RSR 관리
 */
@Tag(name = "AvnRsrManage", description = "관리자 - RSR 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnRsrManageController {

    @Autowired
    AvnRsrManageService service;

    /**
     * 보유 장비 관리 목록 조회
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "보유 장비 관리 목록 조회", description = "보유 장비 관리 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "equipCd", description = "장비코드"),
            @Parameter(name = "equipNm", description = "장비명"),
            @Parameter(name = "modelNm", description = "모델명"),
            @Parameter(name = "companyTypeCd", description = "자사구분"),
            @Parameter(name = "divisionCd", description = "부서"),
            @Parameter(name = "companyNm", description = "업체명"),
            @Parameter(name = "useYn", description = "사용여부"),
    })
    @GetMapping(value = "/admin/rsr/equipments")
    public ResponseEntity<?> getGroundEquipmentList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="equipCd", required=false) String equipCd
            ,@RequestParam(value="equipNm", required=false) String equipNm
            ,@RequestParam(value="modelNm", required=false) String modelNm
            ,@RequestParam(value="companyTypeCd", required=false) String companyTypeCd
            ,@RequestParam(value="divisionCd", required=false) String divisionCd
            ,@RequestParam(value="companyNm", required=false) String companyNm
            ,@RequestParam(value="useYn", required=false) String useYn){

        // 조회조건 parameter
        TbAvnEquipCodeMgmtDto tbAvnEquipCodeMgmtDto = new TbAvnEquipCodeMgmtDto();

        tbAvnEquipCodeMgmtDto.setEquipCd(equipCd);
        tbAvnEquipCodeMgmtDto.setEquipNm(equipNm);
        tbAvnEquipCodeMgmtDto.setModelNm(modelNm);
        tbAvnEquipCodeMgmtDto.setCompanyTypeCd(companyTypeCd);
        tbAvnEquipCodeMgmtDto.setDivisionCd(divisionCd);
        tbAvnEquipCodeMgmtDto.setCompanyNm(companyNm);
        tbAvnEquipCodeMgmtDto.setUseYn(useYn);

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnEquipCodeMgmtDto> pageList = service.selectEquipCdList(tbAvnEquipCodeMgmtDto);

        // 전체 조회
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "보유 장비 관리 상세정보 조회", description = "보유 장비 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/rsr/equipments/{equipmentId}")
    public ResponseEntity<?> getGroundEquipmentInfo(@PathVariable(value="equipmentId", required=true) String equipCd) {

        TbAvnEquipCodeMgmtDto result = service.selectEquipCdDetail(equipCd);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 보유 장비 관리 등록", description = "신규 보유 장비 관리 등록 API")
    @PostMapping(value = "/admin/rsr/equipments")
    public ResponseEntity<?> insertGroundEquipment(@Valid @RequestBody(required=true) TbAvnEquipCodeMgmtDto tbAvnEquipCodeMgmtDto) {

        service.insertEquipCd(tbAvnEquipCodeMgmtDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "보유 장비 관리 정보 수정", description = "보유 장비 관리 정보 수정 API")
    @PutMapping(value = "/admin/rsr/equipments/{equipmentId}")
    public ResponseEntity<?> updateGroundEquipment(
            @PathVariable(value="equipmentId", required=true) String equipCd,
            @Valid @RequestBody(required=true) TbAvnEquipCodeMgmtDto tbAvnEquipCodeMgmtDto) {

        tbAvnEquipCodeMgmtDto.setEquipCd(equipCd);
        service.updateEquipCd(tbAvnEquipCodeMgmtDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "보유 장비 관리 삭제", description = "보유 장비 관리 삭제 API")
    @DeleteMapping(value = "/admin/rsr/equipments/{equipmentId}")
    public ResponseEntity<?> deleteGroundEquipment(@PathVariable(value="equipmentId", required=true) String equipCd) {

        service.deleteEquipCd(equipCd);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Subject 항목 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Subject 항목 관리 목록 조회", description = "Subject 항목 관리 목록 조회 API")
    @GetMapping(value = "/admin/rsr/subjects")
    public ResponseEntity<?> getSubjectContentsList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Subject 항목 관리 상세정보 조회", description = "Subject 항목 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/rsr/subjects/{rsrSubjectId}")
    public ResponseEntity<?> getSubjectContentsInfo(@PathVariable(value="rsrSubjectId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Subject 항목 관리 등록", description = "신규 Subject 항목 관리 등록 API")
    @PostMapping(value = "/admin/rsr/subjects")
    public ResponseEntity<?> insertSubjectContents(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Subject 항목 관리 정보 수정", description = "Subject 항목 관리 정보 수정 API")
    @PutMapping(value = "/admin/rsr/subjects/{rsrSubjectId}")
    public ResponseEntity<?> updateSubjectContents(
            @PathVariable(value="rsrSubjectId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Subject 항목 관리 삭제", description = "Subject 항목 관리 삭제 API")
    @DeleteMapping(value = "/admin/rsr/subjects/{rsrSubjectId}")
    public ResponseEntity<?> deleteSubjectContents(@PathVariable(value="rsrSubjectId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 대시보드 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "대시보드 관리 목록 조회", description = "대시보드 관리 목록 조회 API")
    @GetMapping(value = "/admin/rsr/dashboards")
    public ResponseEntity<?> getRsrDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "대시보드 관리 상세정보 조회", description = "대시보드 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/rsr/dashboards/{dashboardId}")
    public ResponseEntity<?> getRsrDashboardInfo(@PathVariable(value="dashboardId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 대시보드 관리 등록", description = "신규 대시보드 관리 등록 API")
    @PostMapping(value = "/admin/rsr/dashboards")
    public ResponseEntity<?> insertRsrDashboard(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "대시보드 관리 정보 수정", description = "대시보드 관리 정보 수정 API")
    @PutMapping(value = "/admin/rsr/dashboards/{dashboardId}")
    public ResponseEntity<?> updateRsrDashboard(
            @PathVariable(value="dashboardId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "대시보드 관리 삭제", description = "대시보드 관리 삭제 API")
    @DeleteMapping(value = "/admin/rsr/dashboards/{dashboardId}")
    public ResponseEntity<?> deleteRsrDashboard(@PathVariable(value="dashboardId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
