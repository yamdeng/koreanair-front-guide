package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.util.List;

@Getter
@Setter
@ToString
@Accessors(chain = true)
@Schema(description = "보고서 접수 상세 데이터")
public class ReportInfoVo {

    //보고서 Step >> 삭제대기
    //private Integer step;

    //보고서 현재 상태
    ReportStateInfoVo reportStateInfo;

    //대표보고서 VO

    @Schema(description = "FOQA 권한 : 일반(열람) VW | 담당 MG ")
    private String foqaRoleType;

    @Schema(description = "FOQA 직책 : SELOYI, SELOY, SELDO ")
    private String foqaUserPosition;


    @Schema(description = "FOQA-X Comments VO")
    private List<FoqaxCommentsVo> foqaxCommentsVo;

    @Schema(description = "접수 VO")
    private ReceiptVo receiptVo;

    @Schema(description = "1차위험평가(lsc) VO")
    private RiskAssessmentVo firstRiskAssessmentVo;

    @Schema(description = "1차위험평가(src) VO")
    private List<HazardViewlistVo> firstRiskAcceptanceVo;

    @Schema(description = "경감조치-지정 VO")
    private List<HazardViewlistVo> mitigationAssignVo;

    @Schema(description = "경감조치-계획 VO")
    private List<HazardViewlistVo> mitigationAcceptVo;

    @Schema(description = "경감조치-수행 VO")
    private List<HazardViewlistVo> mitigationResultVo;

    @Schema(description = "2차위험평가(lsc) VO")
    private List<HazardViewlistVo> secondRiskAssessmentVo;

    @Schema(description = "2차위험평가(src) VO")
    private List<HazardViewlistVo> secondRiskAcceptanceVo;

    @Schema(description = "종결 VO")
    private List<HazardViewlistVo> riskAcceptanceApprovalVo;


}
