package com.koreanair.ksms.avn.sfta.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveHzdTopRiskDto;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveSearchDto;
import com.koreanair.ksms.avn.sfta.service.AvnSmsComprehensiveService;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

/**
 * 안전보증 - SMS종합분석현황
 */
@Tag(name = "AvnSmsComprehensive", description = "안전보증 - SMS종합분석현황 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSmsComprehensiveController {

    @Autowired
    AvnSmsComprehensiveService service;

    /**
     * SMS 종합분석현황 Hazard 탭 1번 그리드 조회
     *
     * @param division the Combo
     * @param reportType the Combo
     * @param fromDate the Date
     * @param toDate the Date
     * @return the Map
     * @throws Exception the exception
     */
    @Operation(summary = "SMS 종합분석현황 Hazard 탭 1번 그리드 조회", description = "SMS 종합분석현황 Hazard 탭 1번 그리드 목록 조회 API")
    @GetMapping(value = "/assurance/sms-analysis/hzdTab")
    @Parameters({
            @Parameter(name = "division", description = "부문"),
            @Parameter(name = "reportType", description = "보고서구분"),
            @Parameter(name = "fromDate", description = "시작일자"),
            @Parameter(name = "toDate", description = "종료일자"),
    })
    public ResponseEntity<?> getSmsAnalysisHzdTabGrdList(@RequestParam Map<String, Object> paramMap) {
        SmsComprehensiveSearchDto smsComprehensiveSearchDto =
                SmsComprehensiveSearchDto
                    .builder()
                    .pageNum( Integer.parseInt(paramMap.get("pageNum").toString()))
                    .pageSize( Integer.parseInt(paramMap.get("pageSize").toString()))
                    .division( paramMap.get("division") != null ? paramMap.get("division").toString() : "")
                    .reportType( paramMap.get("reportType") != null ? paramMap.get("reportType").toString() : "")
                    .fromDate( paramMap.get("fromDate") != null ? paramMap.get("fromDate").toString() : "")
                    .toDate( paramMap.get("toDate") != null ? paramMap.get("toDate").toString() : "")
                    .grd( paramMap.get("grd") != null ? paramMap.get("grd").toString() : "")
                    .gubun( paramMap.get("gubun") != null ? paramMap.get("gubun").toString() : "")
                    .build();

        // Page 조회
        PageHelper.startPage(smsComprehensiveSearchDto.getPageNum(), smsComprehensiveSearchDto.getPageSize());
        PageInfo<SmsComprehensiveHzdTopRiskDto> pageList = service.selectSMSComprehensiveHzdList(smsComprehensiveSearchDto);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    /**
     * SMS 종합분석현황 Top Event 분석 현황
     *
     * @param division the Combo
     * @param reportType the Combo
     * @param fromDate the Date
     * @param toDate the Date
     * @return the Map
     * @throws Exception the exception
     */
    @Operation(summary = "SMS 종합분석현황 Top Event 분석 현황 조회", description = "SMS 종합분석현황 Top Event 분석 현황 목록 조회 API")
    @GetMapping(value = "/assurance/sms-analysis/eventTab")
    @Parameters({
            @Parameter(name = "division", description = "부문"),
            @Parameter(name = "fromDate", description = "시작일자"),
            @Parameter(name = "toDate", description = "종료일자"),
    })
    public ResponseEntity<?> getSmsAnalysisEventTabList(@RequestParam Map<String, Object> paramMap) {
        SmsComprehensiveSearchDto smsComprehensiveSearchDto =
                SmsComprehensiveSearchDto
                    .builder()
                    .pageNum( Integer.parseInt(paramMap.get("pageNum").toString()))
                    .pageSize( Integer.parseInt(paramMap.get("pageSize").toString()))
                    .division( paramMap.get("division") != null ? paramMap.get("division").toString() : "")
                    .reportType( paramMap.get("reportType") != null ? paramMap.get("reportType").toString() : "")
                    .fromDate( paramMap.get("fromDate") != null ? paramMap.get("fromDate").toString() : "")
                    .toDate( paramMap.get("toDate") != null ? paramMap.get("toDate").toString() : "")
                    .grd( paramMap.get("grd") != null ? paramMap.get("grd").toString() : "")
                    .gubun( paramMap.get("gubun") != null ? paramMap.get("gubun").toString() : "")
                    .build();

        // Page 조회
        PageHelper.startPage(smsComprehensiveSearchDto.getPageNum(), smsComprehensiveSearchDto.getPageSize());
        PageInfo<SmsComprehensiveHzdTopRiskDto> pageList = service.selectSMSComprehensiveEventList(smsComprehensiveSearchDto);

        return ResponseUtil.createSuccessResponse(pageList);
    }
    
    /**
     * SMS 종합분석현황 보고서 상세조회
     *
     * @param gubun the 구분값
     * @param code the 코드값
     * @return the Map
     * @throws Exception the exception
     */
    @Operation(summary = "SMS 종합분석현황 보고서 상세조회", description = "SMS 종합분석현황 보고서 상세조회 API")
    @GetMapping(value = "/assurance/sms-analysis/reportDetail")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 순번"),
            @Parameter(name = "gubun", description = "gubun / Hazard or Event"),
            @Parameter(name = "code", description = "Hazard or Event 의 코드 값"),
    })
    public ResponseEntity<?> getSmsAnalysisReportDetailList(
        @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum,
        @RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize,
        @RequestParam(value="gubun", required=false) String gubun,
        @RequestParam(value="code", required=false) String code
    
    ) {
        SmsComprehensiveSearchDto smsComprehensiveSearchDto 
        = SmsComprehensiveSearchDto.builder().gubun(gubun).code(code).build();


        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<SmsComprehensiveHzdTopRiskDto> pageList = service.selectReportDetailList(smsComprehensiveSearchDto);

        return ResponseUtil.createSuccessResponse(pageList);
    }
}
