package com.koreanair.ksms.common.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class FoqaLimitationDto {
	private int pageNum = 1;
    private int pageSize = 10;

	private Integer id;

	private String eventTypeId;

	private String fleetCode;
}
