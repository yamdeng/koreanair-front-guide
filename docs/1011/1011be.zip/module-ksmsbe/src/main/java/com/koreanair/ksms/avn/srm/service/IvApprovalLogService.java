package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.IvApprovalLog;

public interface IvApprovalLogService {
    IvApprovalLog insertApprovalLog(IvApprovalLog log);

    IvApprovalLog findLastLogByReportId(int reportId);
}
