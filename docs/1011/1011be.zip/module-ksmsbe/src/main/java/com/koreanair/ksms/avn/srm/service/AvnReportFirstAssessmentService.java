package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;

public interface AvnReportFirstAssessmentService {

    RiskAssessmentVo selectReportFirstAssessment(ReportInfoDto.GET_Request dto);

    //접수 Insert
    //Integer insertReceiptDetail(ReceiptVo parameter) throws Exception;

    //접수 Update
    //void updateReceiptDetail(@Valid ReceiptDto.PUT_Request parameter, @RequestAttribute("sessionInfo") JsonObject sessionInfo) throws Exception;

    //void updateReceiptAt(int receiptId) throws Exception;

    //void editReceiptDetail (@Valid ReceiptDto.PATCH_Request parameter, @RequestAttribute("sessionInfo") JsonObject sessionInfo) throws Exception;
}
