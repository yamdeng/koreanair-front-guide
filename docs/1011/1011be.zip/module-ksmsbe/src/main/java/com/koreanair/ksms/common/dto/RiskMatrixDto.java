package com.koreanair.ksms.common.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RiskMatrixDto {
    private int cnt;
    private int eventId;
    private String reportTypeCd;
    private String eventNm;
    private String eventNmStr;

    private int hazardLvthreeId;
    private String hazardLvthreeNm;
    private String hazardLvthreeNmStr;
    private int consequenceId;
    private String consequenceKoNm;
    private String consequenceKoNmStr;
    private String consequenceEnNm;
}
