package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.dto.TbSysCodeDto;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import com.koreanair.ksms.common.utils.MaskingUtils;
import org.postgresql.translation.messages_sr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class AvnReportReceiptServiceImpl extends AbstractBaseService implements AvnReportReceiptService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    //@Autowired
    public SmReport selectReportDetail(int id) {
        return commonSql.selectOne("AvnReportReceipt.selectReportDetail", id);
    }

    public SmReport selectReportDraftDetail(int id) {
        return commonSql.selectOne("AvnReportReceipt.selectReportDraftDetail", id);
    }

    @Override
    public ReceiptVo selectReportReceipt(ReportInfoDto.GET_Request dto) {

        ReceiptVo resultInfo = commonSql.selectOne("AvnReportReceipt.selectReportReceipt", dto);
        if(resultInfo==null) {
            throw new NullPointerException();
        }

        //접수 데이터
        int id = resultInfo.getId();// 접수 id
        int groupId = resultInfo.getGroupId();
        int reportId = resultInfo.getReportId();
        List<ReceiptLscVo> lscList = getLscList(id);
        List<ReceiptAsrVo> receiptAsrList= getReceiptAsrList(id);
        List<PoFileVo> attachment = getReceiptAttachment(id);

        if(resultInfo.getSmReport().getReportType().equals("msr")){
            MsrReportResponseDto certification = getMsrCertification(groupId);
            String MsrCategory = certification.getEvent().getCategory();
            resultInfo.setCertification(MsrCategory);

            //MSR 이메일정보
            List<MsrEmailVo> msrEmailInfo = getMsrEmailInfo(id);
            resultInfo.setMsrEmailInfo(msrEmailInfo);
        }
        resultInfo.setLscList(lscList);
        resultInfo.setReceiptAsr(receiptAsrList);
        resultInfo.setAttachment(attachment);

        //묶음 보고서 리스트
        List<ReceiptGroupListVo> receiptGroupReport = getReceiptGroupReportList(groupId);
        resultInfo.setReceiptGroupList(receiptGroupReport);

        //todo khw. 묶음 보고서 상세 정보 조회
        
        

        SmReport report = resultInfo.getSmReport();
        int userId = Integer.parseInt(SecurityContextHolder.getContext().getAuthentication().getName());

        MaskingUtils maskingUtils = new MaskingUtils();
        String empNo = Optional.ofNullable(dto.getP_empNo()).orElseGet(String::new);
        String eventSummary = resultInfo.getEventSummary();
        String createdBy = report.getCreatedBy();
        boolean isMine = empNo.equals(createdBy);
        boolean foundLscMember = false;

        for (ReceiptLscVo item : lscList) {
            if (item.getEmpNo().equals(empNo)) {
                foundLscMember = true;
                break;
            }
        }

        // ASR 보고서 조회 시 본인, LSC멤버, ASR 담당자를 제외하고 eventSummary 마스킹처리
        if (!isMine && !foundLscMember && !dto.getP_roleList().contains("AMG")) {
            resultInfo.setEventSummary(maskingUtils.maskingAll(eventSummary).substring(0, Math.min(eventSummary.length(), 20)));
        }

        if (report.getReportType().equals("asr")) {
            if (!dto.getP_roleList().contains("AVG") && !dto.getP_roleList().contains("AMG") && !dto.getP_roleList().contains("SSC") && !isLscMember(resultInfo, userId)) {
                resultInfo.setLscList(new ArrayList<>());
            }
        }

        if (report.getReportType().equals("hzr")) {
            if (!dto.getP_roleList().contains("HMG") && !dto.getP_roleList().contains("SSC") && !isLscMember(resultInfo, userId)) {
                resultInfo.setLscList(new ArrayList<>());
            }
        }

        return resultInfo;
    }

    @SuppressWarnings("unchecked")
    private List<ReceiptAsrVo> getReceiptAsrList(int id){
        return commonSql.selectList("AvnReportReceipt.selectReceiptAsrList", id);
    }

    @SuppressWarnings("unchecked")
    private List<PoFileVo> getReceiptAttachment(int id) {
        return commonSql.selectList("AvnReportReceipt.selectReceiptAttachment", id);

    }

    // MSR Certification(AOC/AMO)
    private MsrReportResponseDto getMsrCertification(int id){
        return commonSql.selectOne("AvnReportAnalysis.selectMsrReport", id);
    }

    // MSR Email 정보
    private List<MsrEmailVo> getMsrEmailInfo(int id){
        return commonSql.selectList("AvnReportAnalysis.selectMsrEmailInfo", id);
    }

    private List<ReceiptGroupListVo> getReceiptGroupReportList(int id){
        return commonSql.selectList("AvnReportReceipt.selectGroupReportList", id);
    }

    @Override
    @Transactional
    public void insertReceiptDetail(ReceiptVo receiptVo) throws Exception {

        String timezone = receiptVo.getTimezone();
        receiptVo.setTimezone(timezone);
        logger.debug("\r hash{}",receiptVo);

        // 1. sm_reception테이블 insert
        commonSql.insert("AvnReportReceipt.insertReception", receiptVo);

        // insert 된 이후 generate된다.
        int receptionId = receiptVo.getId();

        // 2. sm_reception_ke_event 테이블에 insert or update
        KeEvent keEvent = receiptVo.getKeEvent();
        SmReceptionKeEvent receptionEvent = new SmReceptionKeEvent(receptionId, keEvent.getId());
        mergeReceptionEvent(receptionEvent);

        // 3. 보고서 타입별 addon 테이블 처리
        mergeReceptionAddon(receiptVo,receptionId);

        // 4. attachment insert(삭제 가능) TODO . KHW .. 나중에 삭제 필요
        //this.mergeReceptionAttachment(receiptVo,receptionId);

        // 5. lsc insert
        ArrayList<ReceiptLscVo> lscList = new ArrayList<ReceiptLscVo>(receiptVo.getLscList());
        List<ReceiptLscVo> oldLscList = new ArrayList<>();
        mergeLscList(receptionId, lscList, timezone, oldLscList);

        // 6. msr인 경우 이메일 수신자 insert
        if ("msr".equals(receiptVo.getSmReport().getReportType())) {
            List<MsrEmailVo> msrEmailList = receiptVo.getMsrEmailInfo();
            if (!msrEmailList.isEmpty()) {
                for (MsrEmailVo item : msrEmailList) {
                    item.setReceptionId(receptionId);
                    commonSql.insert("AvnReportAnalysis.insertMsrEmailInfo", item);
                }
            }
        }

        //7. hazard 보고서인 경우
        if ("hzr".equals(receiptVo.getSmReport().getReportType())) {
            commonSql.update("AvnReportReceipt.updateGroupHzd", receiptVo);
        }
    }

    @Override
    @Transactional
    public void updateReceiptDetail(ReceiptVo receiptVo) throws Exception {
        String timezone = receiptVo.getTimezone();
        int receptionId = receiptVo.getId();
        // 1. sm_reception테이블 update
        commonSql.update("AvnReportReceipt.updateReception", receiptVo);
        KeEvent keEvent = receiptVo.getKeEvent();
        SmReceptionKeEvent receptionEvent = new SmReceptionKeEvent(receptionId,keEvent.getId());

        // 2. sm_reception_ke_event 테이블에 insert or update
        mergeReceptionEvent(receptionEvent);

        // 3. 보고서 타입별 JOIN 테이블 처리
        mergeReceptionAddon(receiptVo,receptionId);

        // 4. attachment insert : 해당 로직 삭제..
        //mergeReceptionAttachment(receiptVo,receptionId);

        // 5. lsc insert
        ArrayList<ReceiptLscVo> lscList = new ArrayList<ReceiptLscVo>(receiptVo.getLscList());
        List<ReceiptLscVo> oldLscList = new ArrayList<>();
        mergeLscList(receptionId, lscList, timezone, oldLscList);

        // 6. msr인 경우 이메일 수신자 insert
        if ("msr".equals(receiptVo.getSmReport().getReportType())) {
            List<MsrEmailVo> msrEmailList = receiptVo.getMsrEmailInfo();
            if (!msrEmailList.isEmpty()) {
                for (MsrEmailVo item : msrEmailList) {
                    item.setReceptionId(receptionId);
                    commonSql.insert("AvnReportAnalysis.insertMsrEmailInfo", item);
                }
            }
        }

        //7. hazard 보고서인 경우
        if ("hzr".equals(receiptVo.getSmReport().getReportType())) {
            commonSql.update("AvnReportReceipt.updateGroupHzd", receiptVo);
        }
    }

    private void mergeReceptionAddon(ReceiptVo receiptVo,int receptionId) {

        String reportType = receiptVo.getSmReport().getReportType();
        if ("asr".equals(reportType)) {
            ArrayList<SmReceptionAsr> receiptAsr= new ArrayList<SmReceptionAsr>(receiptVo.getReceiptAsr());
            // remove before inserted value
            commonSql.delete("AvnReportReceipt.deleteSmReceptionAsr",receptionId);
            for (SmReceptionAsr item : receiptAsr) {
                item.setReceptionId(receptionId);
                commonSql.insert("AvnReportReceipt.insertReceptionAsr", item);
            }

        } else if ("foqa".equals(reportType)) {
            SmReceptionFoqa receiptFoqa= receiptVo.getReceiptFoqa();
            receiptFoqa.setReceptionId(receptionId);
            commonSql.update("AvnReportReceipt.mergeReceiptFoqa", receiptFoqa);

        } else if ("hzr".equals(reportType)) {
            SmReceptionHzr receiptHzr = receiptVo.getReceiptHzr();
            int id=receiptHzr.getHazardBenefitId();
            receiptHzr.setReceptionId(receptionId);
            commonSql.update("AvnReportReceipt.mergeReceiptHzr", receiptHzr);
        }

    }

    private void mergeReceptionEvent(SmReceptionKeEvent receptionEvent) {
        int eventId = receptionEvent.getEventId();
        if (eventId == 0) return;
        commonSql.update("AvnReportReceipt.mergeReceptionEvent", receptionEvent);
    }

    private void mergeLscList(int receptionId, ArrayList<ReceiptLscVo> lscList, String timezone, List<ReceiptLscVo> outputOldLscList) {

        // LSC멤버 추가하기 전의 LSC멤버 LIST를 GET함
        List<ReceiptLscVo> oldLscList = this.getLscList(receptionId);
        outputOldLscList.addAll(oldLscList);
        // remove before inserted value
        commonSql.update("AvnReportReceipt.deleteSmLsc",receptionId);
        // convert masking empNo to noMasking
        for (ReceiptLscVo item : lscList) {
            int userId = item.getUserId();
            TbSysUserDto userInfo = ksmsCommonService.selectUser(String.valueOf(userId));
            String memberType = item.getMemberType();
            String empNo = userInfo.getEmpNo();
            SmLsc smLsc = new SmLsc()
                    .setMemberType(memberType)
                    .setReceptionId(receptionId)
                    .setEmpNo(empNo)
                    .setTimezone(timezone);
            commonSql.update("AvnReportReceipt.mergeSmLsc", smLsc);
        }
    }

    @SuppressWarnings("unchecked")
    private List<ReceiptLscVo> getLscList(int id) {

        // id가 0인경우 기본정보를세팅해줘야함
        if (id == 0) {
            TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            ReceiptLscVo receiptLscVo = new ReceiptLscVo();
            receiptLscVo.setDefaultValue(userInfo);
            ArrayList<ReceiptLscVo> list = new ArrayList<ReceiptLscVo>();
            list.add(receiptLscVo);
            return list;
        }
        return commonSql.selectList("AvnReportReceipt.selectLscList", id);
    }

    @Override
    public void updateReceiptAt(int receiptId) throws Exception {
        commonSql.update("AvnReportReceipt.updateReceiptAt", receiptId);
    }

    private boolean isLscMember(ReceiptVo receipt, int userId) {
        List<ReceiptLscVo> lscList = receipt.getLscList();
        for (ReceiptLscVo member : lscList) {
            if (member.getUserId() == userId) {
                return true;
            }
        }
        return false;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<SmReceptionMember> selectReceiptMember(String roleCd) throws Exception {
        return commonSql.selectList("AvnReportReceipt.selectReceiptMember", roleCd);
    }
}
