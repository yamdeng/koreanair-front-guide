package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AsrReportSelectDto {

	private int id;

	private ReportWithApprovalStep report;

	private FlightResponseDto flight;

	private SmAsrEvent event;

	private BirdStrikeVo birdStrike;

	private SmWeather weather;

	private List<FlightCrewVo> flightCrews;

	private List<WeatherCodeVo> significantWeather;

	private TbSysUserDto writer;
	
	//@Override
	public void hideFlightInfo() {
		this.flight.setDepartureAt(null).setFlightNo(null).setRegistrationNo(null);
		this.flightCrews = null;
	}
	
	//@Override
	public void removeFlightInfo() {
		this.flight = null;
		this.flightCrews = null;
	}

}
