package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class KeNotificationEmail {

	private int id;

	private int notificationTemplateId;

	private String senderEmpno;

	private String isSuccess;

	private Timestamp createdAt;

	private String recipientsEmpno;

	private String subjectEmail;

	private String contentEmail;

	private String umsResponse;

	// 발신 언어?

	public KeNotificationEmail(int notificationTemplateId, String senderEmpno, String recipientsEmpno,
			String subjectEmail, String contentEmail, String isSuccess, String umsResponse) {
		this.notificationTemplateId = notificationTemplateId;
		this.senderEmpno = senderEmpno;
		this.recipientsEmpno = recipientsEmpno;
		this.subjectEmail = subjectEmail;
		this.contentEmail = contentEmail;
		this.isSuccess = isSuccess;
		this.umsResponse = umsResponse;
	}


}
