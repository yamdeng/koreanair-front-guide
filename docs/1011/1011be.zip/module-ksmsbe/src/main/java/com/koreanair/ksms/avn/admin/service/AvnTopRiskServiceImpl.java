package com.koreanair.ksms.avn.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.koreanair.ksms.avn.admin.dto.TopRiskDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnTopRiskServiceImpl extends AbstractBaseService implements AvnTopRiskService {

    @Override
    public List<TopRiskDto> selectTotalTopRiskList(Map<String, Object> param) {
        List<TopRiskDto> resultList = commonSql.selectList("AvnTopRisk.selectTotalTopRiskList",param);
        return resultList;
    }

    @Override
    public List<TopRiskDto> selectOutlierRemoveList(Map<String, Object> param) {
        List<TopRiskDto> resultList = commonSql.selectList("AvnTopRisk.selectOutlierRemoveList",param);
        return resultList;
    }

    @Override
    public List<TopRiskDto> selectOutlierList(Map<String, Object> param) {
        List<TopRiskDto> resultList = commonSql.selectList("AvnTopRisk.selectOutlierList",param);
        return resultList;
    }

}
