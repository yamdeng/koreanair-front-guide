package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbAvnIvHazard extends CommonDto {
    private int id; //위험평가ID
    private int reportId; //조사보고서ID
    private String hazardType; //위해요소 유형(추정원인/부수요인)
    private int hazardId; //위해요소 유형ID, ke_hazard ID
    private String hazardName;
    private int consequenceId; //잠재결과 유형ID, ke_consequence ID
    private String consequenceName;
    private String riskLevel1; //1차 위험도, Risk Level Matrix
    private String riskLevel1Color; //1차 위험도, Risk Level Matrix 색상
    private String riskLevel2; //2차 위험도, Risk Level Matrix
    private String riskLevel2Color; //2차 위험도, Risk Level Matrix 색상
    private String hazardNo; //Report Hazard No. 고유번호 [리포트번호]-[sequnce]
    private String investigationId; //조사보고서 No.


}