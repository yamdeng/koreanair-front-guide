package com.koreanair.ksms.avn.sfta.service;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnChangeMgmtDto;

public interface AvnChangeManagementService {

    //변화관리 등록 리스트
    PageInfo<TbAvnChangeMgmtDto> getChangeList(TbAvnChangeMgmtDto param);
    TbAvnChangeMgmtDto getChangeDetail(TbAvnChangeMgmtDto param);

    
    void insertChangeMgmt (TbAvnChangeMgmtDto param);
    void updateChangeMgmt (TbAvnChangeMgmtDto param);
    void deleteChangeMgmt (int param);

    int insertReport(TbAvnChangeMgmtDto param);
}
