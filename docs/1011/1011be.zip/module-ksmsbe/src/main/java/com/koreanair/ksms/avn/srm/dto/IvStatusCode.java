package com.koreanair.ksms.avn.srm.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class IvStatusCode {
    @Getter
    @AllArgsConstructor
    public enum State {
        DRAFT("draft"),
        OPEN("open"),
        CLOSE("close");

        private String code;
    }

    @Getter
    @AllArgsConstructor
    public enum Phase {
        REPORTING("reporting"),
        RECEPTION("reception"),
        MITIGATION("mitigation"),
        REPORT_CLOSE("report_close");

        private String code;

        private static final Map<String, Phase> mapper = Collections.unmodifiableMap(Stream.of(values())
                .collect(Collectors.toMap(Phase::getCode, Function.identity())));

        public static Phase find(String phase) {
            return mapper.get(phase);
        }

        public static Phase findNextPhase(String phase) {
            switch(phase) {
                case "reporting":
                    return RECEPTION;
                case "reception":
                    return MITIGATION;
                case "mitigation":
                    return REPORT_CLOSE;
                default:
                    return REPORTING;
            }
        }
    }

    @Getter
    @AllArgsConstructor
    public enum Step {
        DRAFT("draft"),
        SUBMITTED("submitted"),
        APPROVED("approved"),
        REJECTED("rejected");

        private String code;

        private static final Map<String, Step> mapper = Collections.unmodifiableMap(Stream.of(values())
                .collect(Collectors.toMap(Step::getCode, Function.identity())));

        public static Step find(String step) {
            return mapper.get(step);
        }

    }

    @Getter
    @AllArgsConstructor
    public enum Action {
        UPDATE_INVESTIGATION("updateInvestigation"),
        SEND_NOTI("sendNoti");

        private String type;
    }

    @Getter
    @AllArgsConstructor
    public enum Status {
        REPORTING_DRAFT(State.DRAFT, Phase.REPORTING, Step.DRAFT, Arrays.asList(Action.UPDATE_INVESTIGATION)),
        REPORTING_SUBMITTED(State.OPEN, Phase.REPORTING, Step.SUBMITTED, Arrays.asList(Action.UPDATE_INVESTIGATION, Action.SEND_NOTI)),
        RECEPTION_APPROVED(State.OPEN, Phase.RECEPTION, Step.APPROVED, Arrays.asList(Action.UPDATE_INVESTIGATION, Action.SEND_NOTI)),
        RECEPTION_REJECTED(State.OPEN, Phase.RECEPTION, Step.REJECTED, Arrays.asList(Action.UPDATE_INVESTIGATION, Action.SEND_NOTI)),
        MITIGATION_DRAFT(State.OPEN, Phase.MITIGATION, Step.DRAFT, Arrays.asList(Action.UPDATE_INVESTIGATION)),
        MITIGATION_SUBMITTED(State.OPEN, Phase.MITIGATION, Step.SUBMITTED, Arrays.asList(Action.UPDATE_INVESTIGATION, Action.SEND_NOTI)),
        REPORT_CLOSE_APPROVED(State.CLOSE, Phase.REPORT_CLOSE, Step.APPROVED, Arrays.asList(Action.UPDATE_INVESTIGATION, Action.SEND_NOTI)),
        REPORT_CLOSE_REJECTED(State.CLOSE, Phase.REPORT_CLOSE, Step.REJECTED, Arrays.asList(Action.UPDATE_INVESTIGATION, Action.SEND_NOTI));

        private State state;

        private Phase phase;

        private Step step;

        private List<Action> actions;

        public static Status find(String phase, String step) {
            return Arrays.stream(values())
                    .filter(status ->
                            status.phase.code.equalsIgnoreCase(phase) &&
                                    status.step.code.equalsIgnoreCase(step))
                    .findFirst()
                    .orElse(null);
        }
    }

    @Getter
    @AllArgsConstructor
    public enum Process {

        REPORTING_DRAFT(Status.REPORTING_DRAFT, Arrays.asList(Status.REPORTING_DRAFT, Status.REPORTING_SUBMITTED)),
        REPORTING_SUBMITTED(Status.REPORTING_SUBMITTED, Arrays.asList(Status.RECEPTION_APPROVED, Status.RECEPTION_REJECTED)),
        RECEPTION_APPROVED(Status.RECEPTION_APPROVED, Arrays.asList(Status.RECEPTION_APPROVED, Status.MITIGATION_DRAFT, Status.MITIGATION_SUBMITTED)),
        RECEPTION_REJECTED(Status.RECEPTION_REJECTED, Arrays.asList(Status.REPORTING_DRAFT, Status.REPORTING_SUBMITTED)),
        MITIGATION_DRAFT(Status.MITIGATION_DRAFT, Arrays.asList(Status.MITIGATION_DRAFT, Status.MITIGATION_SUBMITTED, Status.RECEPTION_APPROVED)),
        MITIGATION_SUBMITTED(Status.MITIGATION_SUBMITTED, Arrays.asList(Status.MITIGATION_SUBMITTED, Status.REPORT_CLOSE_APPROVED, Status.REPORT_CLOSE_REJECTED, Status.RECEPTION_APPROVED)),
        REPORT_CLOSE_APPROVED(Status.REPORT_CLOSE_APPROVED, Arrays.asList(Status.REPORT_CLOSE_APPROVED, Status.RECEPTION_APPROVED)),
        REPORT_CLOSE_REJECTED(Status.REPORT_CLOSE_REJECTED, Arrays.asList(Status.MITIGATION_DRAFT, Status.MITIGATION_SUBMITTED, Status.RECEPTION_APPROVED));

        private Status current; // 현재 상태

        private List<Status> next; // 다음 상태

        public static Process findCurrentProcess(String phase, String step) {
            Status target = Status.find(phase, step);
            return Arrays.stream(values())
                    .filter(process -> process.current == target)
                    .findFirst()
                    .orElse(null);
        }

        public Status findNextProcess(Status nextStatus) {
            return next.stream()
                    .filter(process -> process == nextStatus)
                    .findFirst()
                    .orElse(null);
        }
    }
}
