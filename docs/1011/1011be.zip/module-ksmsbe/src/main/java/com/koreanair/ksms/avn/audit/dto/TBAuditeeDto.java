package com.koreanair.ksms.avn.audit.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "Audit / Auditee")
public class TBAuditeeDto {
	@Schema(description = "auditeeId")
	@NotNull
	private int auditeeId;
	private int auditId;
	private String area;
	private String division;
	private String legFromAirport;
	private String legToAirport;
	private String auditeeType;
	private String airport;
	private String companyName;
	private String lineSafetyYn;
	private Timestamp departureAt;
	private String flightNo;
	private String fromAirport;
	private String toAirport;
	private String route;
	private String fleet;
	private String registrationSign;
	private String acType;
	private String acVersion;
	private String dutyPurser;
	private String qualification;
	private String rank;
	private String numberSeats;
	private String occupant;
}
