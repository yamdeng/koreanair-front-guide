package com.koreanair.ksms.avn.admin.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.avn.admin.service.AvnInstructorManageService;
import com.koreanair.ksms.avn.audit.dto.TBAuditChecklistChapterDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditChecklistDto;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.dto.TbAvnInstructorHistDto;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 관리자 - 강사이력관리
 */
@Tag(name = "AvnInstructorManage", description = "관리자 - 강사이력관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnInstructorManageController {

    @Autowired
    AvnInstructorManageService service;

    /**
     * 강사이력관리 목록 조회
     *
     * @param pageNum the pageNum
     * @param pageSize the pageSize
     * @param emplymentDt the emplymentDt
     * @param nameKor the nameKor
     * @param imploymentYn the imploymentYn
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "강사이력관리 목록 조회", description = "강사이력관리 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호")
            , @Parameter(name = "pageSize", description = "페이지 목록 개수")
            , @Parameter(name = "emplymentDt", description = "임용일자")
            , @Parameter(name = "empNo", description = "사원번호")
            , @Parameter(name = "nameKor", description = "강사명")
            , @Parameter(name = "imploymentYn", description = "임용여부")
    })
    @GetMapping(value = "/admin/instructors")
    public ResponseEntity<?> getInstructorManageList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            , @RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            , @RequestParam(value="emplymentDt", required = false) String emplymentDt
            , @RequestParam(value="empNo", required = false) String empNo
            , @RequestParam(value="nameKor", required = false) String nameKor
            , @RequestParam(value="imploymentYn", required = false, defaultValue = "ALL") String imploymentYn) {

        // 조회조건 parameter
        TbAvnInstructorHistDto tbAvnInstructorHistDto = new TbAvnInstructorHistDto();

        tbAvnInstructorHistDto.setEmplymentDt(emplymentDt);     // 임용일자
        tbAvnInstructorHistDto.setEmpNo(empNo);                 // 사원번호
        tbAvnInstructorHistDto.setNameKor(nameKor);             // 강사명
        tbAvnInstructorHistDto.setImploymentYn(imploymentYn);   // 임용여부

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnInstructorHistDto> pageList = service.selectInstructorManage(tbAvnInstructorHistDto);

        // 전체 조회
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "강사이력관리 상세정보 조회", description = "강사이력관리 상세정보 조회 API")
    @GetMapping(value = "/admin/instructors/{instructorId}")
    public ResponseEntity<?> getInstructorManageInfo(@PathVariable(value="instructorId", required=true) String empNo) {

        TbAvnInstructorHistDto result =  service.selectInstructorManageDetail(empNo);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 강사이력관리 등록", description = "신규 강사이력관리 등록 API")
    @PostMapping(value = "/admin/instructors")
    public ResponseEntity<?> insertInstructorManage(@Valid @RequestBody(required=true) TbAvnInstructorHistDto tbAvnInstructorHistDto) {

        service.inserInstructorManage(tbAvnInstructorHistDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "강사이력관리 정보 수정", description = "강사이력관리 정보 수정 API")
    @PutMapping(value = "/admin/instructors/{instructorId}")
    public ResponseEntity<?> updateInstructorManage(
            @PathVariable(value="instructorId", required=true) String empNo,
            @Valid @RequestBody(required=true) TbAvnInstructorHistDto tbAvnInstructorHistDto) {

        tbAvnInstructorHistDto.setEmpNo(empNo);
        service.updateInstructorManage(tbAvnInstructorHistDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "강사이력관리 삭제", description = "강사이력관리 삭제 API")
    @DeleteMapping(value = "/admin/instructors/{instructorId}")
    public ResponseEntity<?> deleteInstructorManage(@PathVariable(value="instructorId", required=true) String empNo) {

        service.deleteInstructorManage(empNo);
        return ResponseUtil.createSuccessResponse();
    }
}
