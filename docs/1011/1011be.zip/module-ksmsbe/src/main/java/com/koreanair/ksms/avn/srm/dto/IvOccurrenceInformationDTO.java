package com.koreanair.ksms.avn.srm.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class IvOccurrenceInformationDTO {
    private String eventAt;
    private String eventAtTz;
    private String classification;
    private String classificationNameKor;
    private String classificationNameEng;
    private String eventId;
    private String eventNm;
    private String airport;
    private String flightPhase;
    private String flightPhaseNameKor;
    private String flightPhaseNameEng;
    private String weatherText;
    private String isSpi;
    private String spiFileGroupSeq;
    private String locationText;
}
