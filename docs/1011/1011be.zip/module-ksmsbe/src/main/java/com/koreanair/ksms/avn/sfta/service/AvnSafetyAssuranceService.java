package com.koreanair.ksms.avn.sfta.service;

public interface AvnSafetyAssuranceService {



    void batchSafetyAssurance() throws Exception;
}
