package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
public class TbAvnIvReportDTO extends CommonDto {
    private int id;
    private String reportNo;
    private String reportTitle;
    private String departureAt;
    private String flightNo;
    private String aircraftTypeText;
    private String fromAirport;
    private String toAirport;
    private String registrationNo;
    private String supply;
    private String checkIn;
    private String locationText;
    private String airport;
    private String flightPhase;
    private String flightPhaseNameKor;
    private String flightPhaseNameEng;
    private String empNo;
    private String eventAt;
    private String isSpi;
    private String classification;
    private String classificationNameKor;
    private String classificationNameEng;
    private String deletedAt;
    private String weatherText;
    private String eventAtTz;
    private String divertAirport;
    private String isSubmitted;
    private String submittedAt;
    private String investigateBy;
    private String submittedBy;
    private String approvedId;
    private String eventId;
    private String eventNm;
    private String reportFileGroupSeq;
    private String spiFileGroupSeq;
}
