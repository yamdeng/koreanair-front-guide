package com.koreanair.ksms.avn.audit.controller;

import com.koreanair.ksms.avn.audit.service.AvnAuditCAService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * AUDIT - 개선조치(Corrective Action)
 */
@Tag(name = "AvnAuditCA", description = "AUDIT - 개선조치(Corrective Action) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnAuditCAController {

    @Autowired
    AvnAuditCAService service;

    /**
     * 개선조치 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "개선조치 목록 조회", description = "개선조치 목록 조회 API")
    @GetMapping(value = "/audit/cars")
    public ResponseEntity<?> getAuditCarList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 개선조치 상세보기
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "개선조치 상세보기", description = "개선조치 상세보기 API")
    @GetMapping(value = "/audit/cars/caId")
    public ResponseEntity<?> getAuditCarInfo(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Finding 상세 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Finding 상세 조회", description = "Finding 상세 조회 API")
    @GetMapping(value = "/audit/cars/findings")
    public ResponseEntity<?> getAuditFindingInfo(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Observation 상세 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Observation 상세 조회", description = "Observation 상세 조회 API")
    @GetMapping(value = "/audit/cars/observations")
    public ResponseEntity<?> getAuditObservationInfo(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 개선조치 등록
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "개선조치 등록", description = "개선조치 등록 API")
    @PostMapping(value = "/audit/cars")
    public ResponseEntity<?> insertAuditCars(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }
}
