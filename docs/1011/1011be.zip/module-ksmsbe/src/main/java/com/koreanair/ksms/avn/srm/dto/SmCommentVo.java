package com.koreanair.ksms.avn.srm.dto;



import com.koreanair.ksms.common.dto.TbSysUserDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class SmCommentVo extends SmComment{

	private TbSysUserDto userInfo;
}
