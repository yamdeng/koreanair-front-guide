package com.koreanair.ksms.avn.audit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
@Schema(description = "Audit / Mitigation")
@JsonIgnoreProperties(value = {"handler"})
public class TBAuditMitigationDto {
    @Schema(description = "mitigationId")
    @NotNull
    private int mitigationId;
    private int findingId;
    private int acntId;
    private String empNo;
    private String auditorReview;
    private String isMitigated;
    private String mitigatedAt;
    private String submittedAt;
    private String acntType;
    private String phase;
    private String state;
    private String leaderEmpNo;
    private String memberEmpNoList;
    private int auditeeFileGroupSeq;
    private int auditorFileGroupSeq;

    // mitigation User 정보
    private List<TBAuditMitigationUserDto> mitigationUserInfo;
}
