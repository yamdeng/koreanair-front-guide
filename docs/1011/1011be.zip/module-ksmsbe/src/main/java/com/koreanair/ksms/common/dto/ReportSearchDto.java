package com.koreanair.ksms.common.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.koreanair.ksms.common.utils.KeUtils;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Date;
import java.util.List;

public class ReportSearchDto {
	
	@Getter
	@Setter
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class GET_Request {
		private int pageNum = 1;
		private int pageSize = 10;

		private List<String> multipleValue;
		
		private String oneValue; //그룹보고서 조회 시 사용(report Type)

		private String dateType;

		//@DateTimeFormat(pattern = "yyyyMMddHHmmssSSS")
		//private Date startDate;
		
		//@DateTimeFormat(pattern = "yyyyMMddHHmmssSSS")
		//private Date endDate;

		private String startDate;

		private String endDate;

		private String keyword;
		
		private boolean searchASR;
		
		private boolean useReception;

		private boolean searchInvestigation;

		private String flightNo;

		private String regNo;

		public SearchReportConditionVo toEntity(List<String> reportEvents) {
			return SearchReportConditionVo.builder()
					.conditions(multipleValue)
					.reportEvents(reportEvents)
					.searchASR(searchASR)
					.dateType(dateType)
					.from(startDate)
					.to(endDate)
					.keyword(keyword)
					.flightNo(flightNo)
					.regNo(regNo)
					.build();
		}

		public SearchReportConditionVo toEntity(String reportType) {
			return SearchReportConditionVo.builder()
					.reportType(oneValue)
					.dateType(dateType)
					.from(startDate)
					.to(endDate)
					.keyword(keyword)
					.build();
		}
	}

	@Builder
	@Getter
	public static class ReportDto {
		private int id;

		private String docNo;

		private String reportType;

		private String reportedBy;

		private String subject;
		
		private String timeZone;
		
		private String phase;

		private String state;
		
		private Instant submittedAt;

		private String assessmentNotes;
		
		private int flightId;
		
		private String departureAt;

		private String flightNo;

		private String regNo;
		
		private String aircraftType;
		
		@JsonProperty("from")
		private String fromAirport;

		@JsonProperty("to")
		private String toAirport;

		private String divertAirport;
		
		private String stdTime;
		
		private String staTime;
		
		private String atdTime;
		
		private String ataTime;
		
		private int delayHour;
		
		private String supply;
		
		private String checkIn;
		
		private String airport;


		public static ReportDto of (SmSearchReport entity, String timezone) {
			
			Timestamp submittedAt = entity.getSubmittedAt();
			
			Instant parseUTCSubmittedAt = submittedAt != null ? 
					KeUtils.parseUTC(submittedAt, timezone).toInstant() : null;
			
			return ReportDto.builder()
					.id(entity.getId())
					.docNo(entity.getDocNo())
					.reportType(entity.getReportType())
					.reportedBy(entity.getReportedBy())
					.subject(entity.getSubject())
					.timeZone(entity.getTimeZone())
					.phase(entity.getPhase())
					.state(entity.getState())
					.submittedAt(parseUTCSubmittedAt)
					.assessmentNotes(entity.getAssessmentNotes())
					.flightId(entity.getFlightId())
					.departureAt(entity.getDepartureAt())
					.flightNo(entity.getFlightNo())
					.regNo(entity.getRegNo())
					.aircraftType(entity.getAircraftType())
					.fromAirport(entity.getFromAirport())
					.toAirport(entity.getToAirport())
					.divertAirport(entity.getDivertAirport())
					.stdTime(entity.getStdTime())
					.staTime(entity.getStaTime())
					.atdTime(entity.getAtdTime())
					.ataTime(entity.getAtaTime())
					.delayHour(entity.getDelayHour())
					.supply(entity.getSupply())
					.checkIn(entity.getCheckIn())
					.airport(entity.getAirport())
					.build();
		}
	}

}
