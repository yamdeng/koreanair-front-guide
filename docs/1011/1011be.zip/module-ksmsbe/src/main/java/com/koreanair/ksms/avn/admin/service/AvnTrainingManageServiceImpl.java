package com.koreanair.ksms.avn.admin.service;

import D.T;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnEducationDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnTrainingManageServiceImpl extends AbstractBaseService implements AvnTrainingManageService {

    // 교육관리 목록 조회
    @Override
    public PageInfo<TbAvnEducationDto> selectAvnEducationMgmt(TbAvnEducationDto tbAvnEducationDto) {
        List<TbAvnEducationDto> resultList = commonSql.selectList("AvnTrainingManage.selectAvnEducationMgmt", tbAvnEducationDto);
        return PageInfo.of(resultList);
    }

    // 교육관리 신규 등록
    @Override
    public void insertAvnEducationMgmt(TbAvnEducationDto tbAvnEducationDto) {

        String DtFormatChange = tbAvnEducationDto.getEducationDt();
        DtFormatChange = DtFormatChange.replace("-", "");
        DtFormatChange = DtFormatChange.substring(0,8);

        tbAvnEducationDto.setEducationDt(DtFormatChange);

        commonSql.insert("AvnTrainingManage.insertAvnEducationMgmt", tbAvnEducationDto);
    }

    // 교육관리 상세
    @Override
    public TbAvnEducationDto selectAvnEducationMgmtDetail(int educationId) {
        return commonSql.selectOne("AvnTrainingManage.selectAvnEducationMgmtDetail", educationId);
    }

    // 교육관리 수정
    @Override
    public void updateAvnEducationMgmt(TbAvnEducationDto tbAvnEducationDto) {
        commonSql.update("AvnTrainingManage.updateAvnEducationMgmt", tbAvnEducationDto);
    }

    // 교육관리 삭제
    @Override
    public void deleteAvnEducationMgmt(int educationId) {
        commonSql.delete("AvnTrainingManage.deleteAvnEducationMgmt", educationId);
    }
}
