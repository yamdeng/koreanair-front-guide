import ModalService from '@/services/ModalService';
import useAppStore from '@/stores/useAppStore';
import LoadingBar from '@/utils/LoadingBar';
import axios from 'axios';
import CommonUtil from './CommonUtil';

/*

  ajax 구현체 중복 처리 구현
   -disableLoadingBar
   -applyOriginalResponse
   -byPassError

*/

const requestIdList = [];

const enableApiLog = import.meta.env.VITE_ENABLE_API_LOG && import.meta.env.VITE_ENABLE_API_LOG === 'true';

const Api = axios.create({
  headers: { 'Content-Type': 'application/json' },
  disableLoadingBar: false,
  applyOriginalResponse: false,
  byPassError: false,
} as any);

Api.defaults.timeout = 1000 * 30;
Api.defaults.headers.post['Content-Type'] = 'application/json';

// 요청 인터셉터
Api.interceptors.request.use(
  function (config: any) {
    const requestId = CommonUtil.getUUID();
    config.requestId = requestId;
    requestIdList.push(requestId);
    const { accessToken, refreshToken } = useAppStore.getState();
    if (!config.disableLoadingBar) {
      LoadingBar.show();
    }
    const AuthorizationValue = `Bearer ${accessToken}`;
    config.headers['Authorization'] = AuthorizationValue;
    config.headers['Refresh-token'] = refreshToken;
    if (enableApiLog) {
      const { url, params, data } = config;
      console.log(`api requset url : ${url}`);
      if (params) {
        console.log(`api requset params : ${JSON.stringify(params)}`);
      }
      if (config.data) {
        console.log(`api requset data : ${JSON.stringify(data)}`);
      }
    }
    return config;
  },
  function (error) {
    const { config } = error;
    if (config && config.requestId) {
      // requestId 삭제
      const deleteIndex = requestIdList.indexOf(config.requestId);
      if (deleteIndex !== -1) {
        requestIdList.splice(deleteIndex, 1);
      }
    }
    LoadingBar.hide();
    return Promise.reject(error);
  }
);

// 응답 인터셉터
Api.interceptors.response.use(
  (response: any) => {
    if (response.config && response.config.requestId) {
      // requestId 삭제
      const deleteIndex = requestIdList.indexOf(response.config.requestId);
      if (deleteIndex !== -1) {
        requestIdList.splice(deleteIndex, 1);
      }
    }
    const { setAccessToken } = useAppStore.getState();
    const responseData = response.data;
    const responseHeader = response.headers;
    if (!response.config.byPassError && responseData.successOrNot !== 'Y') {
      ModalService.alert({ body: responseData.HeaderMsg });
      return Promise.reject({ errorType: 'api', message: responseData.HeaderMsg, config: response.config });
    }
    if (response.config.applyOriginalResponse) {
      return response;
    }
    if (responseHeader.newtoken) {
      setAccessToken(responseHeader.newtoken);
    }
    if (enableApiLog) {
      const { url } = response.config;
      console.log(`api response url : ${url}`);
      console.log(`api requset data : ${JSON.stringify(response.data)}`);
    }
    if (!requestIdList.length) {
      LoadingBar.hide();
    }
    return response.data;
  },
  (error) => {
    const { config } = error;
    if (config && config.requestId) {
      // requestId 삭제
      const deleteIndex = requestIdList.indexOf(config.requestId);
      if (deleteIndex !== -1) {
        requestIdList.splice(deleteIndex, 1);
      }
    }
    const { handleUnauthorizedError } = useAppStore.getState();
    const errorResponse = error.response || {};
    const status = errorResponse.status;
    if (error && error.response) {
      if (status === 401) {
        handleUnauthorizedError(error);
      }
    }
    if (!requestIdList.length) {
      LoadingBar.hide();
    }
    return Promise.reject(error);
  }
);

export default Api;
