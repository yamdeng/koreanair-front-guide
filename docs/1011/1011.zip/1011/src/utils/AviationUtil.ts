import history from '@/utils/history';
import {
  REPORT_TYPE_ASR,
  REPORT_TYPE_CSR,
  REPORT_TYPE_DSR,
  REPORT_TYPE_GSR,
  REPORT_TYPE_HZR,
  REPORT_TYPE_MSR,
  REPORT_TYPE_RSR,
} from '@/config/ReportFormConstant';

// -- ASR : ReportASREditForm : report-form/ASR/:detailId

// -- CSR > 수검(CSR_03) :ReportCSREditFormInspection : report-form/CSR/inspection/:detailId
// -- CSR > 승객하기(CSR_03) :ReportCSREditFormPaxDeplane : report-form/CSR/paxdeplane/:detailId
// -- CSR > 승객환자(CSR_05) :ReportCSREditFormPaxPatient : report-form/CSR/paxpatient/:detailId
// -- CSR > 승객부상(CSR_01) :ReportCSREditFormPaxInjury : report-form/CSR/paxinjury/:detailId
// -- CSR > 승무원환자(CSR_07) :ReportCSREditFormCrewPatient : report-form/CSR/crewpatient/:detailId
// -- CSR > 승무원부상(CSR_06) :ReportCSREditFormCrewInjury : report-form/CSR/crewinjury/:detailId
// -- CSR > 불법방해행위(CSR_10) :ReportCSREditFormUnlawful : report-form/CSR/unlawful/:detailId
// -- CSR > 흡연(CSR_09) :ReportCSREditFormSmoking : report-form/CSR/smoking/:detailId
// -- CSR > 설비장비(CSR_04) :ReportCSREditFormMaintenance : report-form/CSR/maintenance/:detailId
// -- CSR > 기타 보고항목(CSR_08) :ReportCSREditFormOther : report-form/CSR/other/:detailId

// -- GSR > Damage(GSR_01) : ReportGSREditFormDamage : report-form/GSR/damage/:detailId
// -- GSR > Inspection(GSR_02) : ReportGSREditFormInspection : report-form/GSR/inspection/:detailId
// -- GSR > PAX Handling IRR(GSR_03) : ReportGSREditFormPaxIrr : report-form/GSR/paxirr/:detailId
// -- GSR > Cargo Handling IRR(GSR_04) : ReportGSREditFormCargoIrr : report-form/GSR/cargoirr/:detailId

// -- MSR > AOC(MSR_01) : ReportMSREditFormAOC : report-form/MSR/aoc/:detailId
// -- MSR > AMO(MSR_02) : ReportMSREditFormAMO : report-form/MSR/amo/:detailId

// -- DSR : ReportDSREditForm : report-form/DSR/:detailId
// -- RSR : ReportRSREditForm : report-form/RSR/:detailId
// -- HZR : ReportHZREditForm : report-form/HZR/:detailId

// 작성 페이지로 이동시키는 로직
// moveReportEditPage({ reportId: 'add', reportTypeCd: REPORT_TYPE_CSR, reportDtlTypeCd: 'CSR_03' });

const moveReportEditPage = function (reportInfo) {
  const { reportId, reportTypeCd, reportDtlTypeCd } = reportInfo;

  const prefixUrl = `/aviation/report-form/${reportTypeCd.toUpperCase()}`;
  let reportEditUrl = '';
  if (
    reportTypeCd === REPORT_TYPE_ASR ||
    reportTypeCd === REPORT_TYPE_DSR ||
    reportTypeCd === REPORT_TYPE_HZR ||
    reportTypeCd === REPORT_TYPE_RSR
  ) {
    reportEditUrl = `${prefixUrl}/${reportId}`;
  } else if (reportTypeCd === REPORT_TYPE_CSR) {
    // CSR
    let csrKindName = 'inspection';

    // CSR 2차 분류
    if (reportDtlTypeCd === 'CSR_03') {
      // 수검
      csrKindName = 'inspection';
    } else if (reportDtlTypeCd === 'CSR_02') {
      // 승객하기
      csrKindName = 'paxdeplane';
    } else if (reportDtlTypeCd === 'CSR_05') {
      // 승객환자
      csrKindName = 'paxpatient';
    } else if (reportDtlTypeCd === 'CSR_01') {
      // 승객부상
      csrKindName = 'paxinjury';
    } else if (reportDtlTypeCd === 'CSR_07') {
      // 승무원환자
      csrKindName = 'crewpatient';
    } else if (reportDtlTypeCd === 'CSR_06') {
      // 승무원부상
      csrKindName = 'crewinjury';
    } else if (reportDtlTypeCd === 'CSR_10') {
      // 불법방해행위
      csrKindName = 'unlawful';
    } else if (reportDtlTypeCd === 'CSR_09') {
      // 흡연
      csrKindName = 'smoking';
    } else if (reportDtlTypeCd === 'CSR_04') {
      // 설비장비
      csrKindName = 'maintenance';
    } else if (reportDtlTypeCd === 'CSR_08') {
      // 기타보고항목
      csrKindName = 'other';
    }

    reportEditUrl = `${prefixUrl}/${csrKindName}/${reportId}`;
  } else if (reportTypeCd === REPORT_TYPE_MSR) {
    // MSR
    let msrKindName = 'aoc';

    // MSR 2차 분류
    if (reportDtlTypeCd === 'MSR_01') {
      // aoc
      msrKindName = 'aoc';
    } else if (reportDtlTypeCd === 'MSR_02') {
      // amo
      msrKindName = 'amo';
    }
    reportEditUrl = `${prefixUrl}/${msrKindName}/${reportId}`;
  } else if (reportTypeCd === REPORT_TYPE_GSR) {
    // GSR
    let gsrKindName = 'damage';

    // GSR 2차 분류
    if (reportDtlTypeCd === 'GSR_01') {
      // Damage
      gsrKindName = 'damage';
    } else if (reportDtlTypeCd === 'GSR_02') {
      // Inspection
      gsrKindName = 'inspection';
    } else if (reportDtlTypeCd === 'GSR_03') {
      // PAX Handling IRR
      gsrKindName = 'paxirr';
    } else if (reportDtlTypeCd === 'GSR_04') {
      // Cargo Handling IRR
      gsrKindName = 'cargoirr';
    }
    reportEditUrl = `${prefixUrl}/${gsrKindName}/${reportId}`;
  }

  if (reportEditUrl) {
    history.push(`${reportEditUrl}`);
  }
};

const moveReportViewPage = function (reportInfo) {
  const { reportId, hazardId } = reportInfo;
  let reportViewUrl = `/aviation/reportList/${reportId}`;
  if (hazardId) {
    reportViewUrl = reportViewUrl + `/${hazardId}`;
  }
  history.push(`${reportViewUrl}`);
};

export default {
  moveReportEditPage,
  moveReportViewPage,
};
