import * as yup from 'yup';

// <AppEditor /> 필수값 yup 공통
const editorRequiredYupSchema = yup.string().test('nhn-editor-required-validation', '필수값입니다.', (value) => {
  if (!value) {
    return false;
  }
  if (value === '<p><br></p>' || value === '<p><br/></p>') {
    return false;
  }

  return true;
});

export default {
  editorRequiredYupSchema,
};
