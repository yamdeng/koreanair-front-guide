import { create } from 'zustand';

/* 보고서상세 > 보고서 분석 > 1차 위험도 평가 > 위험평가 */
const ReportViewFirstRiskAssessmentStore = create<any>((set, get) => ({
  clear: () => {
    console.log(set);
    console.log(get);
  },
}));

export default ReportViewFirstRiskAssessmentStore;
