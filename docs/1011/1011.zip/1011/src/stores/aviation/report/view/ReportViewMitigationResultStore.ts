import { create } from 'zustand';

/* 보고서상세 > 보고서 분석 > 경감조치 > 경감실행 */
const ReportViewMitigationResultStore = create<any>((set, get) => ({
  clear: () => {
    console.log(set);
    console.log(get);
  },
}));

export default ReportViewMitigationResultStore;
