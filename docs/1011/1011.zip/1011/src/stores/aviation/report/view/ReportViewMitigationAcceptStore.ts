import { create } from 'zustand';

/* 보고서상세 > 보고서 분석 > 경감조치 > 경감계획 */
const ReportViewMitigationAcceptStore = create<any>((set, get) => ({
  clear: () => {
    console.log(set);
    console.log(get);
  },
}));

export default ReportViewMitigationAcceptStore;
