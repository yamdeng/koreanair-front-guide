import { create } from 'zustand';

/* 보고서상세 > 보고서 내용보기 */
const ReportViewContainerStore = create<any>((set, get) => ({
  clear: () => {
    console.log(set);
    console.log(get);
  },
}));

export default ReportViewContainerStore;
