import { FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { REPORT_TYPE_GSR } from '@/config/ReportFormConstant';
import ApiService from '@/services/ApiService';
import ToastService from '@/services/ToastService';
import { formBaseState } from '@/stores/slice/formSlice';
import CommonYupSchema from '@/utils/CommonYupSchema';
import { produce } from 'immer';
import _ from 'lodash';
import * as yup from 'yup';
import { create } from 'zustand';
import { flighBaseValue } from './reportFormBaseValue';
import { gsrFlightYupSchema } from './reportFormYupSchema';
import { createReportEditForm } from './useEditFormStore';

/* 보고서 작성 GSR : Damage */

const damageListYupSchema = yup.array().of(
  yup.object().shape({
    aircraftDamageAreaCd: yup.string(),
    aircraftDamageCn: yup.string(),
  })
);

const equipListYupSchema = yup.array().of(
  yup.object().shape({
    relEquipCd: yup.string(),
    regNoNm: yup.string(),
    mntcHistNm: yup.string(),
    relGspCd: yup.string(),
    chargeDeptCd: yup.string(),
    gsrCn: yup.string(),
  })
);

const findNotifyCdRequiredCaseSchema = yup.string().when('findNotifyCd', {
  is: '20',
  then: (schema) => schema.required(),
  otherwise: (schema) => schema,
});

/* yup validation */
const yupFormSchema = yup.object().shape({
  flight: gsrFlightYupSchema,
  event: yup.object().shape({
    findNotifyCd: yup.string().required(),
    findTypeCd: yup.string().when('findNotifyCd', {
      is: '10',
      then: (schema) => schema.required(),
      otherwise: (schema) => schema,
    }),
    occurAirportCd: findNotifyCdRequiredCaseSchema,
    occurDttm: findNotifyCdRequiredCaseSchema,
    occurTimezoneCd: findNotifyCdRequiredCaseSchema,
    occurLocationCd: findNotifyCdRequiredCaseSchema,
    operationPhaseCd: yup.string(),
    rampHandlingCd: findNotifyCdRequiredCaseSchema,
    aircraftDamageCauseCd: findNotifyCdRequiredCaseSchema,
    rampStatusCd: findNotifyCdRequiredCaseSchema,
    weatherCodeList: yup.array().when('findNotifyCd', {
      is: '20',
      then: (schema) => schema.required().min(1),
      otherwise: (schema) => schema.required(),
    }),

    aircraftDamageAreaCd: yup.string().required(),
    aircraftDamageCn: yup.string(),

    relEquipCd: yup.string().required(),
    regNoNm: yup.string(),
    mntcHistNm: yup.string(),
    relGspCd: yup.string(),
    chargeDeptCd: yup.string(),
    gsrCn: yup.string(),

    injuryYn: yup.string().required(),
    injuryCn: yup.string(),
    carCn: yup.string(),
    subjectNm: yup.string().label('제목').required(),
    descriptionTxtcn: CommonYupSchema.editorRequiredYupSchema,
  }),
  damageList: damageListYupSchema,
  equipList: equipListYupSchema,
});

const initFormValue = {
  flight: { ...flighBaseValue },
  flightCrew: [],
  event: {
    findNotifyCd: '10', // 기본 '발견'으로 반영
    findTypeCd: '',
    occurAirportCd: '',
    occurDttm: '',
    occurTimezoneCd: 'utc',
    occurLocationCd: '',
    operationPhaseCd: '',
    rampHandlingCd: '',
    aircraftDamageCauseCd: '',
    rampStatusCd: '',
    weatherCodeList: [],

    aircraftDamageAreaCd: '',
    aircraftDamageCn: '',

    relEquipCd: '',
    regNoNm: '',
    mntcHistNm: '',
    relGspCd: '',
    chargeDeptCd: '',
    gsrCn: '',

    injuryYn: '',
    injuryCn: 'N',
    carCn: '',

    subjectNm: '',
    descriptionTxtcn: '',
    fileGroupSeq: null,
    cgoYn: 'N',
    selftAuthYn: 'N',
  },
  damageList: [],
  equipList: [],
};

/* form 초기화 */
const initFormData = {
  formName: '',
  ...formBaseState,
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useGsrDamageFormStore = create<any>((set, get) => ({
  ...createReportEditForm(set, get),

  reportTypeCd: REPORT_TYPE_GSR,

  initFormValue: _.cloneDeep(initFormValue),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  editFormPath: '/aviation/report-form/GSR/damage',

  filghtExpanded: true,
  eventExpanded: true,

  // 장비 목록에서 현재 수정중인 form value
  damageListCurrentEditFormValue: {
    aircraftDamageAreaCd: '',
    aircraftDamageCn: '',
    contentExpaned: false,
  },

  // 장비 목록에서 현재 수정중인 form value
  equipListCurrentEditFormValue: {
    relEquipCd: '',
    regNoNm: '',
    mntcHistNm: '',
    relGspCd: '',
    chargeDeptCd: '',
    gsrCn: '',
    contentExpaned: false,
  },

  // 손상정보 목록이 현재 변경중인지 여부 체크하기 위한
  damageListCurrentChangingIndex: -1,

  // 장비 목록이 현재 변경중인지 여부 체크하기 위한
  equipListCurrentChangingIndex: -1,

  // 발견/신고 radio 수정
  changeCheckKindRadio: (value) => {
    // '발견'인 경우 : 발견 유형외의 날씨까지 초기화
    set(
      produce((state: any) => {
        state.formValue.event.findNotifyCd = value;
        state.formValue.event.findTypeCd = '';
        state.formValue.event.occurAirportCd = '';
        state.formValue.event.occurDttm = '';
        // '발견'인 경우 타임존 utc로 초기화
        if (value === '10') {
          state.formValue.event.occurTimezoneCd = 'utc';
        }
        state.formValue.event.occurLocationCd = '';
        state.formValue.event.operationPhaseCd = '';
        state.formValue.event.rampHandlingCd = '';
        state.formValue.event.aircraftDamageCauseCd = '';
        state.formValue.event.rampStatusCd = '';
        state.formValue.event.weatherCodeList = [];
        state.errors = {};
      })
    );
  },

  /* 손상정보 테이블 관련 로직 start */
  // 손상정보 항목 추가
  addDamageList: () => {
    const { damageListCurrentChangingIndex } = get();
    if (damageListCurrentChangingIndex !== -1) {
      ToastService.warn('현재 수정중인 손상 목록이 존재합니다.');
      return;
    }
    set(
      produce((state: any) => {
        state.formValue.damageList.push({
          nomenclatureNm: '',
          partNm: '',
          serialnoNm: '',
        });
        state.damageListCurrentChangingIndex = state.formValue.damageList.length - 1;
        state.damageListCurrentEditFormValue = {
          aircraftDamageAreaCd: '',
          aircraftDamageCn: '',
          contentExpaned: false,
        };
      })
    );
  },

  // 손상정보 목록 저장 : edit form에 저장된 정보로 반영
  saveDamageList: () => {
    const { damageListCurrentEditFormValue, damageListCurrentChangingIndex } = get();
    set(
      produce((state: any) => {
        state.formValue.damageList[damageListCurrentChangingIndex] = { ...damageListCurrentEditFormValue };
        state.damageListCurrentChangingIndex = -1;
        state.damageListCurrentEditFormValue = {
          aircraftDamageAreaCd: '',
          aircraftDamageCn: '',
          contentExpaned: false,
        };
      })
    );
  },

  // 손상정보 목록 취소
  cancelDamageList: () => {
    set({
      damageListCurrentChangingIndex: -1,
      damageListCurrentEditFormValue: { aircraftDamageAreaCd: '', aircraftDamageCn: '', contentExpaned: false },
    });
  },

  // 손상정보 목록 삭제
  deleteDamageList: (removeIndex) => {
    const { damageListCurrentChangingIndex } = get();
    if (damageListCurrentChangingIndex !== -1) {
      ToastService.warn('현재 수정중인 손상 목록이 존재합니다.');
      return;
    }
    set(
      produce((state: any) => {
        state.formValue.damageList.splice(removeIndex, 1);
      })
    );
  },

  // 손상정보 목록 수정 : edit form으로 수정
  updateDamageList: (damageListIndex, damageListInfo) => {
    const { damageListCurrentChangingIndex } = get();
    if (damageListCurrentChangingIndex !== -1) {
      ToastService.warn('현재 수정중인 손상 목록이 존재합니다.');
      return;
    }
    set({
      damageListCurrentEditFormValue: { ...damageListInfo },
      damageListCurrentChangingIndex: damageListIndex,
    });
  },

  // 손상정보 내용 영역 펼치기
  toggleDamageContentExpaned: (damageListIndex, beforeContentExpaned) => {
    set(
      produce((state: any) => {
        state.formValue.damageList[damageListIndex].contentExpaned = !beforeContentExpaned;
      })
    );
  },

  /* 손상정보 테이블 관련 로직 end */

  /* 장비정보 테이블 관련 로직 start */
  // 정비항목 추가
  addEquipList: () => {
    const { equipListCurrentChangingIndex } = get();
    if (equipListCurrentChangingIndex !== -1) {
      ToastService.warn('현재 수정중인 장비 목록이 존재합니다.');
      return;
    }
    set(
      produce((state: any) => {
        state.formValue.equipList.push({
          nomenclatureNm: '',
          partNm: '',
          serialnoNm: '',
        });
        state.equipListCurrentChangingIndex = state.formValue.equipList.length - 1;
        state.equipListCurrentEditFormValue = {
          relEquipCd: '',
          regNoNm: '',
          mntcHistNm: '',
          relGspCd: '',
          chargeDeptCd: '',
          gsrCn: '',
          contentExpaned: false,
        };
      })
    );
  },

  // 정비 목록 저장 : edit form에 저장된 정보로 반영
  saveEquipList: () => {
    const { equipListCurrentEditFormValue, equipListCurrentChangingIndex } = get();
    set(
      produce((state: any) => {
        state.formValue.equipList[equipListCurrentChangingIndex] = { ...equipListCurrentEditFormValue };
        state.equipListCurrentChangingIndex = -1;
        state.equipListCurrentEditFormValue = {
          relEquipCd: '',
          regNoNm: '',
          mntcHistNm: '',
          relGspCd: '',
          chargeDeptCd: '',
          gsrCn: '',
          contentExpaned: false,
        };
      })
    );
  },

  // 정비 목록 취소
  cancelEquipList: () => {
    set({
      equipListCurrentChangingIndex: -1,
      equipListCurrentEditFormValue: {
        relEquipCd: '',
        regNoNm: '',
        mntcHistNm: '',
        relGspCd: '',
        chargeDeptCd: '',
        gsrCn: '',
        contentExpaned: false,
      },
    });
  },

  // 정비 목록 삭제
  deleteEquipList: (removeIndex) => {
    const { equipListCurrentChangingIndex } = get();
    if (equipListCurrentChangingIndex !== -1) {
      ToastService.warn('현재 수정중인 장비 목록이 존재합니다.');
      return;
    }
    set(
      produce((state: any) => {
        state.formValue.equipList.splice(removeIndex, 1);
      })
    );
  },

  // 정비 목록 수정 : edit form으로 수정
  updateEquipList: (equipListIndex, equipListInfo) => {
    const { equipListCurrentChangingIndex } = get();
    if (equipListCurrentChangingIndex !== -1) {
      ToastService.warn('현재 수정중인 장비 목록이 존재합니다.');
      return;
    }
    set({
      equipListCurrentEditFormValue: { ...equipListInfo },
      equipListCurrentChangingIndex: equipListIndex,
    });
  },

  // 손상정보 내용 영역 펼치기
  toggleEquipContentExpaned: (equipListIndex, beforeContentExpaned) => {
    set(
      produce((state: any) => {
        state.formValue.equipList[equipListIndex].contentExpaned = !beforeContentExpaned;
      })
    );
  },

  /* 장비정보 테이블 관련 로직 end */

  getDetail: async (id) => {
    const response: any = await ApiService.get(`avn/report/my-reports/${id}`);
    const detailInfo = response.data;
    const { report, reportGsr, flight, reportDtl } = detailInfo;

    // 'report' api에서 event 정보 추출
    const applyEvent = _.pick(report, [
      'occurAirportCd',
      'occurDttm',
      'occurTimezoneCd',
      'subjectNm',
      'descriptionTxtcn',
      'fileGroupSeq',
    ]);

    // 'reportGsr' api에서 event 정보 추출
    const applyEvent2 = _.pick(reportGsr, [
      'findNotifyCd',
      'findTypeCd',
      'occurLocationCd',
      'operationPhaseCd',
      'rampHandlingCd',
      'aircraftDamageCauseCd',
      'rampStatusCd',
      'injuryYn',
      'injuryCn',
      'carCn',
      'cgoYn',
      'selftAuthYn',
    ]);

    // 'reportDtl'을 ui 변수에 맞게끔 변환
    let damageList = [{ aircraftDamageAreaCd: '', aircraftDamageCn: '' }];
    let equipList = [{ relEquipCd: '', regNoNm: '', mntcHistNm: '', relGspCd: '', chargeDeptCd: '', gsrCn: '' }];

    if (reportDtl && reportDtl.length) {
      const gsr01List = reportDtl.filter((info) => info.reportDtlInfoTypeCd === 'GSR_01');
      const gsr02List = reportDtl.filter((info) => info.reportDtlInfoTypeCd === 'GSR_02');
      if (gsr01List && gsr01List.length) {
        damageList = gsr01List;
      }
      if (gsr02List && gsr02List.length) {
        equipList = gsr02List;
      }
    }

    // 첫번재 요소를 추출해서 formValue에 셋팅
    const damageFormValueInfo = _.pick(damageList[0], ['aircraftDamageAreaCd', 'aircraftDamageCn']);
    const equipFormValueInfo = _.pick(equipList[0], [
      'relEquipCd',
      'regNoNm',
      'mntcHistNm',
      'relGspCd',
      'chargeDeptCd',
      'gsrCn',
    ]);

    // 첫번째 요소를 제외하고 list에 반영
    damageList.shift();
    equipList.shift();

    // AppCodeSelect : isMultiple
    const weatherCodeList = reportGsr.weatherCdarr ? reportGsr.weatherCdarr.split(',') : [];

    const applyFormValue = {
      flight: flight,
      event: {
        ...applyEvent,
        ...applyEvent2,
        ...damageFormValueInfo,
        ...equipFormValueInfo,
        weatherCodeList: weatherCodeList,
      },
      damageList: damageList,
      equipList: equipList,
    };

    set({
      detailInfo: detailInfo,
      formValue: applyFormValue,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  getApiParam: () => {
    const { formValue, formDetailId, detailInfo, reportTypeCd } = get();
    const { flight, event, damageList, equipList } = formValue;
    const { report, reportGsr } = detailInfo || {};

    // 'report'
    const serverReportParam = {
      ...report,
      reportId: formDetailId ? formDetailId : null,
      reportTypeCd: reportTypeCd,
      ...event,
    };

    // 'reportDtl'
    const serveReportDetailListParam = [];

    // 손상정보 반영
    const damageFirstInfo = _.pick(event, ['aircraftDamageAreaCd', 'aircraftDamageCn']);
    serveReportDetailListParam.push({ ...damageFirstInfo, reportDtlInfoTypeCd: 'GSR_01' });
    damageList.forEach((damageInfo) => {
      serveReportDetailListParam.push({ ...damageInfo, reportDtlInfoTypeCd: 'GSR_01' });
    });

    // 장비정보 반영
    const equipFirstInfo = _.pick(event, ['relEquipCd', 'regNoNm', 'mntcHistNm', 'relGspCd', 'chargeDeptCd', 'gsrCn']);
    serveReportDetailListParam.push({ ...equipFirstInfo, reportDtlInfoTypeCd: 'GSR_02' });
    equipList.forEach((damageInfo) => {
      serveReportDetailListParam.push({ ...damageInfo, reportDtlInfoTypeCd: 'GSR_02' });
    });

    // 'reportGsr'
    const serverGsrReportParam = {
      reportId: formDetailId ? formDetailId : null,
      reportDtlTypeCd: 'GSR_01',
      ...reportGsr,
      findNotifyCd: event.findNotifyCd,
      findTypeCd: event.findTypeCd,
      occurDttm: event.occurDttm,
      occurLocationCd: event.occurLocationCd,
      operationPhaseCd: event.operationPhaseCd,
      rampHandlingCd: event.rampHandlingCd,
      aircraftDamageCauseCd: event.aircraftDamageCauseCd,
      rampStatusCd: event.rampStatusCd,
      weatherCdarr: event.weatherCodeList ? event.weatherCodeList.join(',') : '',
      injuryYn: event.injuryYn,
      injuryCn: event.injuryCn,
      carCn: event.carCn,
      cgoYn: event.cgoYn,
      selftAuthYn: event.selftAuthYn,
    };

    // 최종 적용
    const reportApiParam = {
      flight: { ...flight, reportId: formDetailId ? formDetailId : null },
      report: serverReportParam,
      reportGsr: serverGsrReportParam,
      reportDtl: serveReportDetailListParam,
    };
    return reportApiParam;
  },

  // gsr Damage form 페이지의 formValue 값 외의 변수 clear
  gsrDamageFormPageClear: () => {
    const { clear } = get();
    set({
      damageListCurrentEditFormValue: {
        aircraftDamageAreaCd: '',
        aircraftDamageCn: '',
      },
      equipListCurrentEditFormValue: {
        relEquipCd: '',
        regNoNm: '',
        mntcHistNm: '',
        relGspCd: '',
        chargeDeptCd: '',
        gsrCn: '',
      },
      damageListCurrentChangingIndex: -1,
      equipListCurrentChangingIndex: -1,
    });
    clear();
  },
}));

export default useGsrDamageFormStore;
