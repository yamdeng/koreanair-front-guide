import { FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import ApiService from '@/services/ApiService';
import { formBaseState } from '@/stores/slice/formSlice';
import _ from 'lodash';
import * as yup from 'yup';
import { create } from 'zustand';
import { flighBaseValue } from './reportFormBaseValue';
import { msrFlightYupSchema, msrDeviceListYupSchema } from './reportFormYupSchema';
import { createMsrReportEditForm, createReportEditForm } from './useEditFormStore';
import CommonYupSchema from '@/utils/CommonYupSchema';

/* 보고서 작성 MSR : AOC */

/* yup validation */
const yupFormSchema = yup.object().shape({
  flight: msrFlightYupSchema,
  event: yup.object().shape({
    occurPlaceNm: yup.string(),
    occurAirportCd: yup.string(),
    subjectNm: yup.string().label('제목').required(),
    descriptionTxtcn: CommonYupSchema.editorRequiredYupSchema,
    msrEventTypeCd: yup.string(),
  }),
  deviceList: msrDeviceListYupSchema,
});

const initFormValue = {
  maintenanceChecked: false,
  flight: { ...flighBaseValue },
  flightCrew: [],
  event: {
    occurPlaceNm: '',
    occurAirportCd: '',
    subjectNm: '',
    descriptionTxtcn: '',
    fileGroupSeq: null,
    msrEventTypeCd: '',
  },
  deviceList: [],
};

/* form 초기화 */
const initFormData = {
  formName: '',
  ...formBaseState,
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useMsrAocFormStore = create<any>((set, get) => ({
  ...createReportEditForm(set, get),
  ...createMsrReportEditForm(set, get),

  initFormValue: _.cloneDeep(initFormValue),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  editFormPath: '/aviation/report-form/MSR/aoc',

  // Heavy Maintenance checked 변경
  changeMaintenanceChecked: (checked) => {
    const { changeInput } = get();
    changeInput('maintenanceChecked', checked);
    // TODO : ui 수정(disabled 처리등등)
  },

  getDetail: async (id) => {
    const response: any = await ApiService.get(`avn/report/my-reports/${id}`);
    const detailInfo = response.data;
    const { report, reportMsr, flight, reportDtl } = detailInfo;

    // 'report' api에서 event 정보 추출
    const applyEvent = _.pick(report, [
      'occurAirportCd',
      'occurPlaceNm',
      'subjectNm',
      'descriptionTxtcn',
      'fileGroupSeq',
    ]);

    // 'reportMsr' api에서 event 정보 추출
    const applyEvent2 = _.pick(reportMsr, ['msrEventTypeCd']);

    // 'reportDtl'을 ui 변수에 맞게끔 변환
    let deviceList = [];

    if (reportDtl && reportDtl.length) {
      deviceList = reportDtl;
    }

    const applyFormValue = {
      flight: flight,
      event: {
        ...applyEvent,
        ...applyEvent2,
      },
      deviceList: deviceList,
      maintenanceChecked: reportMsr.msrTypeCd === 'maintenance' ? true : false,
    };

    set({
      detailInfo: detailInfo,
      formValue: applyFormValue,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  getApiParam: () => {
    const { formValue, formDetailId, detailInfo, reportTypeCd } = get();
    const { flight, event, deviceList, maintenanceChecked } = formValue;
    const { report, reportMsr } = detailInfo || {};

    // 'report'
    const serverReportParam = {
      ...report,
      reportId: formDetailId ? formDetailId : null,
      reportTypeCd: reportTypeCd,
      ...event,
    };

    // 'reportDtl'
    const serveReportDetailListParam = [];

    deviceList.forEach((deviceInfo) => {
      serveReportDetailListParam.push({ ...deviceInfo, reportDtlInfoTypeCd: 'MSR_01' });
    });

    // 'reportMsr'
    const serverMsrReportParam = {
      reportId: formDetailId ? formDetailId : null,
      reportDtlTypeCd: 'MSR_01',
      ...reportMsr,
      msrTypeCd: maintenanceChecked ? 'maintenance' : 'flight',
      msrEventTypeCd: event.msrEventTypeCd,
    };

    // 최종 적용
    const reportApiParam = {
      flight: { ...flight, reportId: formDetailId ? formDetailId : null },
      report: serverReportParam,
      reportMsr: serverMsrReportParam,
      reportDtl: serveReportDetailListParam,
    };
    return reportApiParam;
  },
}));

export default useMsrAocFormStore;
