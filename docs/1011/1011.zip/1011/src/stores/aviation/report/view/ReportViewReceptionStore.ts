import { create } from 'zustand';

/* 보고서상세 > 보고서 분석 > 접수 */
const ReportViewReceptionStore = create<any>((set, get) => ({
  clear: () => {
    console.log(set);
    console.log(get);
  },
}));

export default ReportViewReceptionStore;
