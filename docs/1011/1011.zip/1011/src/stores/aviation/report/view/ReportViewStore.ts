import { create } from 'zustand';

const stepDomIdMappingInfo = {
  1: 'view-reception-content',
  2: 'view-firstrisk-assessment',
  3: 'view-firstrisk-review',
  4: 'view-mitigation_assign',
  5: 'view-mitigation_accept',
  6: 'view-mitigation_result',
  7: 'view-secondrisk_assessment',
  8: 'view-secondrisk_review',
  9: 'view-hazard_close',
};

/* 보고서상세 최상위 manage store */
const ReportViewStore = create<any>((set, get) => ({
  // 보고서 유형
  reportTypeCd: '',

  // 아코디언 expanded 변수 : root
  contentExpanded: true, // 내용
  analysExpanded: true, // 분석

  // 아코디언 expanded 변수 : 5가지 분류 및 하위(순서대로)
  receptionExpanded: false, // 접수
  receptionDetailExpanded: false, // 접수 > 보고서접수

  firstRiskExpanded: false, // 1차 위험도 평가
  firstRiskAssessmentExpanded: false, // 1차 위험도 평가 > 위험평가
  firstRiskReviewExpanded: false, // 1차 위험도 평가 > SRC리뷰

  mitigationExpanded: false, // 경감조치
  mitigationAssignExpanded: false, // 겸감조치 > 경감지정
  mitigationAcceptExpanded: false, // 겸감조치 > 경감계획
  mitigationResultExpanded: false, // 겸감조치 > 경감실행

  secondRiskExpanded: false, // 2차 위험도 평가
  secondRiskAssessmentExpanded: false, // 2차 위험도 평가 > 위험평가
  secondRiskReviewExpanded: false, // 2차 위험도 평가 > SRC리뷰

  hazardCloseExpanded: false, // 종결

  hazardCloseProcessExpanded: false, // 종결 > 종료처리
  hazardCloseValidationExpanded: false, // 종결 > 유효성평가

  // 아코디언 toggle
  toggleAccordionExpanded: (accordionExapndedName) => {
    const state = get();
    const expaned = !state[accordionExapndedName];
    set({ [accordionExapndedName]: expaned });
  },

  // 상단 단계 클릭
  clickStep: (step) => {
    // TODO
    if (step === 1) {
      //
    }
  },

  // 보고서 상세정보
  reportDetailInfo: {},

  getDetail: () => {
    // TODO : api 호출해서 각 store에 convert 작업 수행
  },

  clear: () => {
    console.log(set);
    console.log(get);

    set({
      reportTypeCd: '',
      contentExpanded: true,
      analysExpanded: true,

      receptionExpanded: false,
      receptionDetailExpanded: false,

      firstRiskExpanded: false,
      firstRiskAssessmentExpanded: false,
      firstRiskReviewExpanded: false,

      mitigationExpanded: false,
      mitigationAssignExpanded: false,
      mitigationAcceptExpanded: false,
      mitigationResultExpanded: false,

      secondRiskExpanded: false,
      secondRiskAssessmentExpanded: false,
      secondRiskReviewExpanded: false,

      hazardCloseExpanded: false,

      hazardCloseProcessExpanded: false,
      hazardCloseValidationExpanded: false,
    });
  },
}));

export default ReportViewStore;
