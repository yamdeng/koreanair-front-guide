import { create } from 'zustand';

/* 보고서상세 > 보고서 분석 > 종결 */
const ReportViewHazardCloseStore = create<any>((set, get) => ({
  clear: () => {
    console.log(set);
    console.log(get);
  },
}));

export default ReportViewHazardCloseStore;
