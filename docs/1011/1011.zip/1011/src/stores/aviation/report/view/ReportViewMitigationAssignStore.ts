import { create } from 'zustand';

/* 보고서상세 > 보고서 분석 > 경감조치 > 경감지정 */
const ReportViewMitigationAssignStore = create<any>((set, get) => ({
  clear: () => {
    console.log(set);
    console.log(get);
  },
}));

export default ReportViewMitigationAssignStore;
