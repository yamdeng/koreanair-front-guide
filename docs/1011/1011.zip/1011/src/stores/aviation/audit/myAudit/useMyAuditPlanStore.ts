import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { produce } from 'immer';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';
import ModalService from '@/services/ModalService';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
// import _ from 'lodash';
// import history from '@/utils/history';
import { useEffect, useState } from 'react';

import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';
import { de } from '@faker-js/faker';

/* yup validation */
const yupFormSchema = yup.object({
  isRemote: yup.string().required(),
  airlineCategory: yup.string().required(),
  title: yup.string().required(),
  division: yup.string().required(),
  auditAt: yup.string().required(),
  auditTypeCode: yup.string().required(),
  checklistInfo: yup.array().required().min(1),
  auditorInfo: yup.array().required().min(1),
  auditeeInfo: yup.object().shape({
    airport: yup.string().required(),
    area: yup.string().required(),
  }),
});

const initFormValue = {
  /* Audit */
  auditId: '',
  auditNo: '',
  title: '',
  division: '',
  urlPlan: '',
  urlResult: '',
  isFinding: '',
  phase: '',
  phaseLevel: '',
  state: '',
  timezone: '',
  auditAt: '',
  isRemote: 'N', // 초기값 : on-site
  airlineCategory: 'C31701', // 초기값 : 대한항공
  auditTypeCode: '',
  isSubmmited: '',
  submittedAt: '',
  notes: '',
  approvedBy: '',
  planFileGroupSeq: '',
  resultFileGroupSeq: '',
  preFileGroupSeq: '',
  useYn: '',
  // Checklist 정보
  checklistInfo: [],
  // Auditor 정보
  auditorInfo: [],
  // Auditee 정보
  auditeeInfo: {
    auditeeId: '',
    auditId: '',
    area: '',
    auditeeDivision: '',
    legFromAirport: '',
    legToAirport: '',
    auditeeType: '',
    airport: '',
    companyName: '',
    lineSafetyYn: '',
    departureAt: '',
    flightNo: '',
    fromAirport: '',
    toAirport: '',
    route: '',
    fleet: '',
    registrationSign: '',
    acType: '',
    acVersion: '',
    dutyPurser: '',
    qualification: '',
    rank: '',
    numberSeats: '',
    occupant: '',
  },
};

/* form 초기화 */
const formName = 'AuditPlanFormStore';
const initFormData = {
  ...formBaseState,
  //formValue: initFormValue,
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useMyAuditPlanStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...initFormData,
  yupFormSchema: yupFormSchema,

  setErrors: (error) => set({ errors: error }),

  dsAuditPlanInfo: [],

  // Auditor 목록의 유형
  userSelectKind: '',

  // Audit Plan 정보 세팅
  setAuditPlanInfo: async (auditInfo) => {
    set({ dsAuditPlanInfo: auditInfo });
    const { dsAuditPlanInfo, changeDivision } = get();

    // 부문 선택 이벤트 발생 (Audit Type, Checklist 설정)
    changeDivision(dsAuditPlanInfo.division);

    // 폼 바인딩
    const serverChecklistInfo = dsAuditPlanInfo.checklistInfo;
    // object > array
    dsAuditPlanInfo.checklistInfo = serverChecklistInfo.map((info) => info.checklistId);
    set({ formValue: dsAuditPlanInfo });
  },

  // 선택한 부문의 Audit유형, 체크리스트 조회
  divisionAuditTypeGrpCd: '',
  divisionChecklist: [],
  changeDivision: (division) => {
    // Audit Type 설정
    //const tempAuditTypeArr = [];
    set({ divisionAuditTypeGrpCd: '' });
    switch (division) {
      case 'SELOYE': // 총괄 품질
        //tempAuditTypeArr.push('CODE_GRP_303');
        set({ divisionAuditTypeGrpCd: 'CODE_GRP_303' });
        break;
      case 'SELOYA': // 보안 부문
        set({ divisionAuditTypeGrpCd: 'CODE_GRP_304' });
        break;
      case 'SELOC': // 종합 통제
        set({ divisionAuditTypeGrpCd: 'CODE_GRP_305' });
        break;
      case 'SELFT': // 화물 운송
        set({ divisionAuditTypeGrpCd: 'CODE_GRP_306' });
        break;
      case 'SELCTPN': // 여객 운송
        set({ divisionAuditTypeGrpCd: 'CODE_GRP_307' });
        break;
      case 'SELOQA': // 운항 부문
        set({ divisionAuditTypeGrpCd: 'CODE_GRP_308' });
        break;
      case 'SELUFQA': // 객실 부문
        set({ divisionAuditTypeGrpCd: 'CODE_GRP_309' });
        break;
      case 'SELQAP': // 정비 부문
        set({ divisionAuditTypeGrpCd: 'CODE_GRP_310' });
        break;
      default:
        break;
    }

    // 부문별 체크리스트 조회
    ApiService.get(`avn/audit/my-audit/1/audit/checklist/${division}`).then((apiResult) => {
      set({ divisionChecklist: apiResult.data || [] });
    });
  },

  // AuditTypeCode 변경시
  changeAuditTypeCode: (auditTypeCode) => {
    const { formValue } = get();
    // Line Safety Audit 일 경우 체크
    if (auditTypeCode === '200001026') {
      formValue.auditeeInfo.lineSafetyYn = 'true';
    } else {
      formValue.auditeeInfo.lineSafetyYn = '';
    }
  },

  // Auditor 선택
  onSelectAuditorList: (selectedValue) => {
    const { formValue, userSelectKind } = get();
    const tempList = formValue.auditorInfo;
    if (!tempList.find((info) => info.auditorType === 'lead') && userSelectKind !== 'lead') {
      ModalService.alert({
        body: 'Lead Auditor를 먼저 선택해 주십시오.',
      });
      return;
    }

    if (tempList.find((info) => info.auditorType === 'lead' && userSelectKind === 'lead')) {
      ModalService.alert({
        body: 'Lead Auditor는 한명만 지정 가능합니다.',
      });
      return;
    }

    set(
      produce((state: any) => {
        const auditorList = state.formValue.auditorInfo;
        if (!auditorList.find((info) => info.empNo === selectedValue.empNo)) {
          auditorList.push({ ...selectedValue, auditorType: userSelectKind });
        }
      })
    );
  },

  // Auditor 삭제
  deleteAuditorList: (removeIndex) => {
    set(
      produce((state: any) => {
        state.formValue.auditorInfo.splice(removeIndex, 1);
      })
    );
  },

  // Airport 선택시 region 조회
  airportRegions: [],
  changeAirportRegion: (airportCode) => {
    const { formValue } = get();
    formValue.auditeeInfo.area = '';
    ApiService.get(`avn/audit/my-audit/1/audit/airport/${airportCode}`).then((apiResult) => {
      set({ airportRegions: apiResult.data || {} });
      const { airportRegions } = get();
      if (airportRegions.length === 1) {
        formValue.auditeeInfo.area = airportRegions[0].airportarea;
      }
    });
  },

  //비행편명 검색
  searchFligh: async () => {
    const { formValue } = get();
    // const { flight } = formValue;
    // const { flightNo } = flight;
    const { flightNo } = formValue.auditeeInfo;
    if (!flightNo) {
      ToastService.warn('비행편명을 입력해주세요.');
      return;
    }

    const apiResult = await ApiService.get('com/flight', { departureDate: '', fltNo: flightNo });
    const data = apiResult.data || [];
    const searchInfo = data.length ? data[0] : null;

    if (searchInfo) {
      set(
        produce((state: any) => {
          //const flight = state.formValue.flight; //비행정보
          // flight.registrationNo = searchInfo.registrationNo; //등록기호
          // flight.aircraftTypeText = searchInfo.aircraftType; //항공기 형식
          // flight.toAirport = searchInfo.to; //도착공항
          // flight.fromAirport = searchInfo.from; //출발공항
          // flight.divertAirport = searchInfo.from; //회항공항
          // flight.supply = searchInfo.supply; //좌석수
          // flight.checkIn = searchInfo.checkIn; //탑승자

          //debugger;

          state.formValue.auditeeInfo.fromAirport = searchInfo.from; //출발공항
          state.formValue.auditeeInfo.toAirport = searchInfo.to; //도착공항

          state.formValue.auditeeInfo.acType = searchInfo.aircraftType; //항공기 형식
          state.formValue.auditeeInfo.acVersion = '';
          state.formValue.auditeeInfo.fleet = searchInfo.fleetCode;
          state.formValue.auditeeInfo.registrationSign = searchInfo.registrationNo; //등록기호

          state.formValue.auditeeInfo.qualification = ''; //qualification
          state.formValue.auditeeInfo.rank = ''; //rank
          state.formValue.auditeeInfo.numberSeats = searchInfo.supply; //좌석수
          state.formValue.auditeeInfo.occupant = searchInfo.checkIn; //탑승자
        })
      );
    } else {
      ToastService.warn('비행정보가 존재하지 않습니다.');
    }
  },

  deleteAudit: () => {
    alert('삭제 작업중입니다. (미저장시 보이지않도록 처리)');
  },

  // Audit Plan 저장
  saveAuditPlan: async (savePhase) => {
    const { formValue } = get();

    const tempList = formValue.auditorInfo;
    if (!tempList.find((info) => info.auditorType === 'lead')) {
      ModalService.alert({
        body: 'Lead Auditor가 지정되지 않았습니다.',
      });
      return;
    }

    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;
    if (success) {
      // Checklist 배열형태로 변환
      const objectChecklist = { ...formValue.checklistInfo };
      const newChecklist = [];
      Object.values(objectChecklist).map((value) => {
        newChecklist.push({ checklistId: value });
      });
      formValue.checklistInfo = newChecklist;

      // 단계설정 : PLAN or CONDUCT
      formValue.phase = savePhase;

      const apiParam = {
        ...formValue,
      };

      //debugger;

      await ApiService.post('avn/audit/my-audit/1/plan', apiParam).then((apiResult) => {
        //const returnAuditId = apiResult.data;
        const returnAuditId = apiResult.ItemCount;
        //if (returnAuditId) {
        //  ToastService.error(returnAuditId);
        //} else {
        ToastService.success('Audit 정보가 저장되었습니다.');
        if (savePhase === 'CONDUCT') {
          // Audit 재설정
          const { getAuditInfo } = useMyAuditFrameStore.getState();
          getAuditInfo(returnAuditId);
        }
        //}
      });
    } else {
      const { setErrors } = get();
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  },
}));

export default useMyAuditPlanStore;
