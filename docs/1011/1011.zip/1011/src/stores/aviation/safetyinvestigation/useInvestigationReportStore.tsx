import ApiService from '@/services/ApiService';
import ToastService from '@/services/ToastService';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { create } from 'zustand';
import { produce } from 'immer';
import ModalService from '@/services/ModalService';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';

//오늘 날짜 만들기
const today = new Date();
const year = today.getFullYear(); // 년도
const month = today.getMonth() + 1; // 월
const date = today.getDate(); // 날짜
const nowHours = today.getHours(); //시
const nowMins = today.getMinutes(); //분
let monthString = '';
let dateString = '';
if (month < 10) {
  monthString = '0' + month;
} else {
  monthString = month.toString();
}
if (date < 10) {
  dateString = '0' + date;
} else {
  dateString = date.toString();
}
const todayString = year + '-' + monthString + '-' + dateString + ' ' + nowHours + ':' + nowMins;

/* yup validation */
const yupFormSchema = yup.object({
  reportTitle: yup.string().required('subject는 필수 입력 항목입니다.'),
  occurrenceInformation: yup.object().shape({
    eventAt: yup.string().required('발생일/시간(UTC)는 필수 입력 항목입니다.'), //발생일
    classification: yup.string().required('Event Class는 필수 입력 항목입니다.'), //Event Class
    eventId: yup.string().required('Event Type은 필수 입력 항목입니다.'), //Event Type
    airport: yup.string().required('발생공항은 필수 입력 항목입니다.'), //발생 공항
    flightPhase: yup.string().required('발생단계는 필수 입력 항목입니다.'), //발생 단계
    isSpi: yup.string().required('SPI 여부는 필수 입력 항목입니다.'), //SPI여부
  }),
  investigationReport: yup.object().shape({
    postContents: yup.string().required('개요는 필수 입력 항목입니다.'), //조사보고서 내용(개요)
    investigateBy: yup.string().required('Investigator는 필수 입력 항목입니다.'), //조사관
  }),
  // hazardList: yup.array(), //위해요인 리스트
  assumptionList: yup.array().nullable('추정원인은 필수 입력 항목입니다.'), //추정원인 목록
  radicalList: yup.array().nullable('부수요인은 필수 입력 항목입니다.'), //부수요인 목록
  approvalGroupID: yup.string().required('결재 Group명은 필수 입력 항목입니다.'), //결재 ID
  approvalMemberList: yup.array().nullable('결재 인원은 필수 입력 항목입니다.'),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  //보고서 번호
  reportNo: '', //보고서 번호
  reportTitle: '', //리포트 subject
  //보고서 번호 끝
  //발생정보
  occurrenceInformation: {
    eventAt: todayString, //발생일
    eventAtTz: '', //발생일 TimeZone
    classification: '', //Event Class
    eventId: '', //Event Type
    airport: '', //발생 공항
    flightPhase: '', //발생 단계
    weatherText: '', //기상조건
    isSpi: 'N', //SPI여부
    spiFileGroupSeq: null, //SPI첨부파일
    locationText: '', //발생 장소
  },
  //발생정보 끝
  //비행정보
  flight: {
    departureAt: todayString, //출발일자
    flightNo: '', //비행편명
    registrationNo: '', //등록기호
    aircraftTypeText: '', //항공기 형식
    fromAirport: '', //출발항공
    toAirport: '', //도착공항
    divertAirport: '', //회항공항
    supply: '', //좌석수
    checkIn: '', //탑승자
  },
  crewMemberList: [], //승무원
  //비행정보 끝
  investigationReport: {
    postContents: '', //조사보고서 내용
    reportFileGroupSeq: null, //조사보고서 첨부파일
    investigateBy: '', //조사관
  },
  //위험평가
  hazardList: [], //위해요인 리스트
  hazardId: '', //hazard
  hazardType: 'ast', //원인구분
  consequenceId: '', //potential Consequence
  assumptionList: [], //추정원인 목록
  radicalList: [], //부수요인 목록
  //위험평가 끝
  approvalGroupID: '', //결재 ID
  approvalGroupList: [], //결재그룹목록
  //사용자 정보 리스트
  memberList: [],
  //결재 멤버 정보 리스트
  approvalMemberList: [],
  //참고문서 번호
  reportDocument: [],

  empNo: '', //최초 작성자 사원번호
  isSubmitted: 'N', //제출여부
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/srm/investigation/reports',
  baseRoutePath: '/aviation/safety-risk-mgmt/investigation-report',
  formName: 'InvestigationReport',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useInvestigationReportFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  //그룹 멤버 삭제 확인(confirm)창 modal open/close
  isDeleteConfirmModal: false,

  //회원삭제viewSn(정렬번호)
  memberRemoveIndex: null,

  //asr 이벤트 목록 가져오기
  eventListData: [],
  // hazard 목록 가져오기
  hazardListData: [],
  //consequence 목록 가져오기
  consequenceListData: [],

  //spi 여부에 따라 보여주기
  isSPIDisplayStatus: 'hide',

  //저장 버튼 클릭 시 validation 체크
  customSave: async () => {
    const { validate, getApiParam, formType, formDetailId, formApiPath, cancel, formValue } = get();
    const { occurrenceInformation, investigationReport, assumptionList, radicalList } = formValue;
    const { isSpi, spiFileGroupSeq } = occurrenceInformation;
    const { postContents } = investigationReport;
    console.log(postContents);

    const isValid = await validate();
    if (isValid) {
      if (isSpi == 'Y') {
        if (spiFileGroupSeq == null || spiFileGroupSeq == '') {
          document.getElementById('InvestigationReportEditspiFileGroupSeq').focus();
          ToastService.error("SPI 여부가 '예' 일 경우 첨부파일은 필수 입력 항목입니다.");
          return;
        }
      }
      if (postContents == '<p><br></p>') {
        ToastService.error('개요는 필수 입력 항목입니다.');
        return;
      }
      if (assumptionList.length <= 0) {
        ToastService.error('추정원인은 필수 입력 항목입니다.');
        return;
      } else if (radicalList.length <= 0) {
        ToastService.error('부수요인은 필수 입력 항목입니다.');
        return;
      }
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          if (formType === FORM_TYPE_ADD) {
            await ApiService.post(`${formApiPath}`, apiParam);
          } else {
            await ApiService.put(`${formApiPath}/${formDetailId}`, apiParam);
          }
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    }
  },

  //초기화
  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue }, isSPIDisplayStatus: 'hide' });
  },

  //첨부파일 존재 여부에 따라 보여주기
  displayStatus: () => {
    const { formValue } = get();
    const { occurrenceInformation } = formValue;
    const spiFileSeq = occurrenceInformation.spiFileGroupSeq;

    if (spiFileSeq == '' || spiFileSeq == null) {
      set({ isSPIDisplayStatus: 'hide' });
    } else {
      set({ isSPIDisplayStatus: 'show' });
    }
  },

  changeDisplayStatus: (value) => {
    set({ isSPIDisplayStatus: value });
  },

  //그룹멤버 삭제 팝업창 닫기
  isDeleteConfirmModalClose: () => {
    set({ isDeleteConfirmModal: false, memberRemoveIndex: null });
  },
  isDeleteConfirmModalOpen: (removeIndex) => {
    set({ isDeleteConfirmModal: true, memberRemoveIndex: removeIndex });
  },
  //그룹멤버 삭제 확인 버튼 클릭 시
  deleteConfirmModalOk: async () => {
    const { memberRemoveIndex, formValue } = get();
    set({ isDeleteConfirmModal: false });
    const deleteTarget = formValue.approvalMemberList[memberRemoveIndex];
    const groupId = deleteTarget.groupId;
    const memberEmpNo = deleteTarget.empNo;
    set(
      produce((state: any) => {
        const memberList = state.formValue.memberList;
        memberList.splice(memberRemoveIndex, 1);
      })
    );
    const result = await ApiService.delete(`avn/common/approval/group/member/delete/${groupId}/${memberEmpNo}`);
    if (result) {
      ToastService.success('삭제되었습니다.');
    }
  },

  //참고문서 삭제
  deleteDocument: (index) => {
    ToastService.success('삭제되었습니다.');
    set(
      produce((state: any) => {
        const documentList = state.formValue.reportDocument;
        documentList.splice(index, 1);
      })
    );
  },

  //비행편명 검색
  searchFligh: async () => {
    const { formValue } = get();
    const { flight } = formValue;
    const { flightNo } = flight;
    if (!flightNo) {
      ToastService.warn('비행편명을 입력해주세요.');
      return;
    }

    const apiResult = await ApiService.get('com/flight', { departureDate: '', fltNo: flightNo });
    const data = apiResult.data || [];
    const searchInfo = data.length ? data[0] : null;

    if (searchInfo) {
      set(
        produce((state: any) => {
          const flight = state.formValue.flight; //비행정보
          flight.registrationNo = searchInfo.registrationNo; //등록기호
          flight.aircraftTypeText = searchInfo.aircraftType; //항공기 형식
          flight.toAirport = searchInfo.to; //도착공항
          flight.fromAirport = searchInfo.from; //출발공항
          flight.divertAirport = searchInfo.from; //회항공항
          flight.supply = searchInfo.supply; //좌석수
          flight.checkIn = searchInfo.checkIn; //탑승자
        })
      );
    } else {
      ToastService.warn('비행정보가 존재하지 않습니다.');
    }
  },

  // 비행승무원 선택
  onSelectFlightCrewList: (selectedValue) => {
    set(
      produce((state: any) => {
        const crewMemberList = state.formValue.crewMemberList;
        if (!crewMemberList.find((info) => info.empNo === selectedValue.empNo)) {
          crewMemberList.push({ ...selectedValue });
        }
      })
    );
  },

  // 비행승무원 삭제
  deleteFlightCrewList: (removeIndex) => {
    set(
      produce((state: any) => {
        const crewMemberList = state.formValue.crewMemberList;
        crewMemberList.splice(removeIndex, 1);
      })
    );
  },

  // 결재 그룹 선택
  onSelectapprovalGroupList: (selectedValue) => {
    set(
      produce((state: any) => {
        const memberList = state.formValue.memberList;
        const approvalMemberList = state.formValue.approvalMemberList;
        const approvalGroupID = state.formValue.approvalGroupID;
        if (!memberList.find((info) => info.empNo === selectedValue.empNo)) {
          memberList.push({ ...selectedValue });
          const newIndex = memberList.length;
          approvalMemberList.push({
            groupId: approvalGroupID,
            empNo: selectedValue.empNo,
            viewSn: newIndex - 1,
          });
        }
      })
    );
  },

  // 결재 그룹 정렬(위)
  up: (listIndex) => {
    set(
      produce((state: any) => {
        if (listIndex > 0) {
          const beforeInfo = state.formValue.memberList[listIndex];
          const nextInfo = state.formValue.memberList[listIndex - 1];
          state.formValue.memberList[listIndex - 1] = beforeInfo;
          state.formValue.memberList[listIndex] = nextInfo;

          const beforeListInfo = state.formValue.approvalMemberList[listIndex];
          beforeListInfo.viewSn = listIndex - 1;
          const nextListInfo = state.formValue.approvalMemberList[listIndex - 1];
          nextListInfo.viewSn = listIndex;

          state.formValue.approvalMemberList[listIndex - 1] = beforeListInfo;
          state.formValue.approvalMemberList[listIndex] = nextListInfo;
        }
      })
    );
  },

  // 결재 그룹 정렬(아래)
  down: (listIndex) => {
    set(
      produce((state: any) => {
        if (listIndex < state.formValue.memberList.length - 1) {
          const beforeInfo = state.formValue.memberList[listIndex];
          const nextInfo = state.formValue.memberList[listIndex + 1];
          state.formValue.memberList[listIndex + 1] = beforeInfo;
          state.formValue.memberList[listIndex] = nextInfo;

          const beforeListInfo = state.formValue.approvalMemberList[listIndex];
          beforeListInfo.viewSn = listIndex + 1;
          const nextListInfo = state.formValue.approvalMemberList[listIndex + 1];
          nextListInfo.viewSn = listIndex;

          state.formValue.approvalMemberList[listIndex + 1] = beforeListInfo;
          state.formValue.approvalMemberList[listIndex] = nextListInfo;
        }
      })
    );
  },

  //이벤트 타입 가져오기
  getEventTypeList: async () => {
    const eventList = await ApiService.get('avn/srm/investigation/eventTypeASR');

    set({ eventListData: eventList });
  },

  //Hazard 목록 가져오기
  getHazardList: async () => {
    const hazardList = await ApiService.get('avn/srm/investigation/hazard');

    set({ hazardListData: hazardList });
  },

  //Consequence 목록 가져오기
  getConsequenceList: async () => {
    const consequenceList = await ApiService.get('avn/srm/investigation/consequence');

    set({ consequenceListData: consequenceList });
  },

  //조사관 세팅
  getInvestigatior: async (profile) => {
    const { formValue } = get();
    const { investigationReport } = formValue;

    investigationReport['investigateBy'] = profile.userInfo.empNo;
    //최초 작성자 사원번호 같이 등록
    formValue['empNo'] = profile.userInfo.empNo;
    set({ formValue: formValue });
  },

  //결재그룹 목록 가져오기
  getApprovalGroup: async () => {
    const { formValue } = get();
    const approvalGroupList = await ApiService.get('avn/common/approvalGroupList');
    const groupData = approvalGroupList.data;
    formValue['approvalGroupList'] = groupData;
    set({ formValue: formValue });
  },

  //결재그룹에 소속된 멤버 목록 조회
  getMember: async (groupId) => {
    const { formValue } = get();
    const params = { groupId: groupId };
    const dataList = await ApiService.get('avn/common/approvalGroupMemberList', params);
    if (dataList.data.approvalGroupMember.length > 0) {
      const groupMemberData = dataList.data;
      formValue['memberList'] = groupMemberData.GroupMemberInfo;
      formValue['approvalMemberList'] = groupMemberData.approvalGroupMember;
    } else {
      formValue['memberList'] = [];
      formValue['approvalMemberList'] = [];
    }
    set({ formValue: formValue });
  },

  // 추청원인 삭제
  deleteAssumption: async (removeIndex) => {
    const { formValue } = get();
    const { assumptionList, hazardList } = formValue;
    const assumptionListHazardId = assumptionList[removeIndex].hazardId;
    const assumptionListConsequenceId = assumptionList[removeIndex].consequenceId;
    ToastService.success('추정원인을 삭제하였습니다.');
    set(
      produce((state: any) => {
        const assumptionList = state.formValue.assumptionList;
        const beforeHazardList = state.formValue.hazardList;
        assumptionList.splice(removeIndex, 1);
        hazardList.forEach((el, index) => {
          if (el.hazardId == assumptionListHazardId && el.consequenceId == assumptionListConsequenceId) {
            beforeHazardList.splice(index, 1);
          }
        });
      })
    );
  },

  // 부수요인 삭제
  deleteRadical: async (removeIndex) => {
    const { formValue } = get();
    const { radicalList, hazardList } = formValue;
    const assumptionListHazardId = radicalList[removeIndex].hazardId;
    const assumptionListConsequenceId = radicalList[removeIndex].consequenceId;
    ToastService.success('부수요인을 삭제하였습니다.');
    set(
      produce((state: any) => {
        const radicalList = state.formValue.radicalList;
        const beforeHazardList = state.formValue.hazardList;
        radicalList.splice(removeIndex, 1);
        hazardList.forEach((el, index) => {
          if (el.hazardId == assumptionListHazardId && el.consequenceId == assumptionListConsequenceId) {
            beforeHazardList.splice(index, 1);
          }
        });
      })
    );
  },

  //Risk Assessment
  addRiskAssessment: () => {
    const { formValue, hazardListData, consequenceListData } = get();
    //중복체크 플래그
    let addFlag = false;

    if (formValue.hazardId == '') {
      ToastService.error('Hazard를 선택해주세요');
      document.getElementById('InvestigationReportEditHazard').focus();
      return;
    } else if (formValue.consequenceId == '') {
      ToastService.error('Potential Consequence를 선택해주세요');
      document.getElementById('InvestigationReportEditpotentialConsequence').focus();
      return;
    } else if (formValue.hazardType == '') {
      ToastService.error('원인구분을 선택해주세요');
      document.getElementById('InvestigationReportEditpotentialhazardType').focus();
    } else {
      //위험평가 중복체크
      if (formValue.hazardList.length > 0) {
        formValue.hazardList.forEach((el) => {
          if (el.hazardId == formValue.hazardId && el.consequenceId == formValue.consequenceId) {
            addFlag = true;
            if (el.hazardType == 'ast') {
              ToastService.error('추정원인에 이미 등록된 위험평가 입니다.\n확인 후 다시 진행해주세요');
              return;
            } else {
              ToastService.error('부수요인에 이미 등록된 위험평가 입니다.\n확인 후 다시 진행해주세요');
              return;
            }
          }
        });
      }

      //중복된 위험평가가 있을 시 진행하지 않음
      if (addFlag) return;

      //Risk Assessment 만들어주기
      const riskAssessment = {};
      // 값 저장
      riskAssessment['riskAssessmentId'] = null;
      riskAssessment['hazardId'] = formValue.hazardId;
      riskAssessment['hazardType'] = formValue.hazardType;
      riskAssessment['consequenceId'] = formValue.consequenceId;
      //hazard 이름 가져오기
      hazardListData.data.some((data) => {
        if (data.lv3Id == formValue.hazardId) {
          riskAssessment['hazardName'] = data.lv3Name;
        }
      });
      //consequence이름가져오기
      consequenceListData.data.some((data) => {
        if (data.consequenceId == formValue.consequenceId) {
          riskAssessment['consequenceName'] = data.consequenceKoNm;
        }
      });
      //추정원인일 경우
      if (formValue.hazardType == 'ast') {
        //formValue에 추정원인 넣기
        const { assumptionList } = formValue;
        const arrayData = [];
        arrayData.push(riskAssessment);
        const updatedCrewResult = [...assumptionList, ...arrayData];
        formValue['assumptionList'] = updatedCrewResult;
        //부수요인일 경우
      } else {
        //formValue에 부수요인 넣기
        const { radicalList } = formValue;
        const arrayData = [];
        arrayData.push(riskAssessment);
        const updatedCrewResult = [...radicalList, ...arrayData];
        formValue['radicalList'] = updatedCrewResult;
      }
      //최종 두개 합본
      formValue['hazardList'] = [...formValue['assumptionList'], ...formValue['radicalList']];
      set({ formValue: formValue });
    }
  },
}));

export default useInvestigationReportFormStore;
