import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import _ from 'lodash';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';

/* yup validation */
const yupFormSchema = yup.object({
  prtnrNm: yup.string().required(),
  bizNo: yup.string().required().max(10, '10자 이내로 작성해주세요.'),
  rprsn: yup.string().required(),
  bizIndst: yup.string().required(),
  bizType: yup.string().required(),
  placeList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        bizPlaceClsCd: yup.string().required(),
        useSectCd: yup.string().required(),
        mgntDeptCd: yup.string().required(),
        staffNm1: yup.string().required(),
        staffContactNo1: yup.string().required(),
        staffEmail1: yup.string().required(),
        staffWork1: yup.string().required(),
        staffContactNo2: yup.string().nullable(),
        staffEmail2: yup.string().nullable(),
        staffWork2: yup.string().nullable(),
        majorWorkCn: yup.string(),
        place2ndInfoList: yup.array().of(
          yup.object().shape({
            companyNm: yup.string(),
            majorWorkCn: yup.string(),
            staffNm: yup.string(),
            staffContactNo: yup.string(),
          })
        ),
      })
    ),
});

/* formValue 초기값 */
const initFormValue = {
  prtnrNm: '',
  bizNo: '',
  rprsn: '',
  bizIndst: '',
  bizType: '',
  placeList: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/partner',
  baseRoutePath: '/occupation/management/partner',
  formName: 'OcuPartnerInfoForm',
  formValue: {
    ...initFormValue,
  },

  selectedPlaceIndex: -1,
  selectedPlace2ndInfoIndex: -1,
};

/* zustand store 생성 */
const useOcuPartnerInfoFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...createCommonDataset(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  setFormStatus: (status: any) => {
    const { CommonDS } = get();
    return CommonDS.setStatus('formValue', null, status);
  },

  setFormValue: (field: string, value: any) => {
    const { CommonDS } = get();
    return CommonDS.setColumn('formValue', null, field, value);
  },

  getPlacePath: () => {
    return `formValue.placeList`;
  },

  setSelectedPlaceIndex: (index: number) => {
    set({ selectedPlaceIndex: index });
  },

  getPlaceError: (field: string) => {
    const { errors, selectedPlaceIndex } = get();
    const path = `placeList[${selectedPlaceIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getPlaceColumn: (field: string) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.getColumn(getPlacePath(), selectedPlaceIndex, field);
  },

  setPlaceColumn: (field: string, value: any) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.setColumn(getPlacePath(), selectedPlaceIndex, field, value);
  },

  addPlaceRow: () => {
    const { CommonDS, getPlacePath, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.addRow(getPlacePath());
    setSelectedPlaceIndex(rowIdx);
  },

  delPlaceRow: (rowIndex) => {
    const { CommonDS, getPlacePath, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.deleteRow(getPlacePath(), rowIndex);
    setSelectedPlaceIndex(rowIdx);
  },

  getPlace2ndInfoPath: () => {
    const { selectedPlaceIndex } = get();
    return `formValue.placeList[${selectedPlaceIndex}].place2ndInfoList`;
  },

  setSelectedPlace2ndInfoIndex: (index: number) => {
    set({ selectedPlace2ndInfoIndex: index });
  },

  getPlace2ndList: () => {
    const { CommonDS, getPlace2ndInfoPath } = get();
    return CommonDS.getList(getPlace2ndInfoPath());
  },

  getPlace2ndError: (field: string) => {
    const { errors, selectedPlace2ndInfoIndex } = get();
    const path = `placeList[${selectedPlace2ndInfoIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getPlace2ndColumn: (field) => {
    const { CommonDS, getPlace2ndInfoPath, selectedPlace2ndInfoIndex } = get();
    return CommonDS.getColumn(getPlace2ndInfoPath(), selectedPlace2ndInfoIndex, field);
  },

  setPlace2ndColumn: (field: string, value: any) => {
    const { CommonDS, getPlace2ndInfoPath, selectedPlace2ndInfoIndex } = get();
    return CommonDS.setColumn(getPlace2ndInfoPath(), selectedPlace2ndInfoIndex, field, value);
  },

  addPlace2ndInfo: () => {
    const { CommonDS, getPlace2ndInfoPath, setSelectedPlace2ndInfoIndex } = get();
    const rowIdx = CommonDS.addRow(getPlace2ndInfoPath());
    setSelectedPlace2ndInfoIndex(rowIdx);
  },

  delPlace2ndInfo: () => {
    const { CommonDS, getPlace2ndInfoPath, selectedPlace2ndInfoIndex, setSelectedPlace2ndInfoIndex } = get();
    const rowIdx = CommonDS.deleteRow(getPlace2ndInfoPath(), selectedPlace2ndInfoIndex);
    setSelectedPlace2ndInfoIndex(rowIdx);
  },

  openPlace2ndModal: () => {
    set({ isPlace2ndFormModalOpen: true });
  },

  closePlace2ndModal: () => {
    set({ isPlace2ndFormModalOpen: false });
  },

  saveAll: async () => {
    const { validate, getApiParam, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          await ApiService.post(`${formApiPath}`, apiParam);
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    } else {
      const { CommonDS, errors } = get();
      CommonDS.setValidateList('formValue', errors);
    }
  },

  // form 전체 초기화
  clear: () => {
    set({
      ...formBaseState,
      formValue: { ...initFormValue },
      selectedPlace: null,
      selectedPlaceIndex: -1,
      selectedPlace2ndInfoIndex: -1,
    });
  },
}));

export default useOcuPartnerInfoFormStore;
