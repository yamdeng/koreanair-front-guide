import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import { produce } from 'immer';
import * as yup from 'yup';
import { create } from 'zustand';

/* yup validation */
const yupFormSchema = yup.object({
  // 외주작업
  // 공사ID
  cntrId: yup.number(),

  // 외주작업 반입장비
  // 반입장비 ID
  imprtEqpmId: yup.number(),
  // 공사 작업 코드
  cntrWrkCd: yup.string(),
  // 반입 장비 코드
  imprtEqpmCd: yup.string(),
  // 반입 장비 수기 입력
  importEqpmNm: yup.string(),
  // 첨부파일 ID
  fileId: yup.number(),
  // regDttm: yup.string().required(),
  // regUserId: yup.string().required(),
  // updDttm: yup.string().required(),
  // updUserId: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  equipmentCheckList: [
    {
      cntrWrkCd: '', // 공사작업코드
      imprtEqpmCd: '', // 반입장비코드
      importEqpmNm: '', // 반입장비_수기_입력
      fileId: null, // 첨부파일 ID
    },
  ],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits/locations',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitDeviceChecklistFormStore',
  formValue: {
    ...initFormValue,
  },
};

// equipmentCheckList

/* zustand store 생성 */
const useOcuWorkPermitDeviceChecklistFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  selectedWork: {
    S: false, // confinedSpace
    E: false, // electrical
    F: false, // fireRisk
    H: false, // highPlace
    R: false, // hanging
    C: false, // constructionMachine
  },

  selectedDevice: {
    S: {
      S1: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
    },
    E: {
      E1: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
    },
    F: {
      F1: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
      F2: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
      F3: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
    },
    H: {
      H1: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
      H2: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
      H3: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
      H4: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
    },
    R: {
      R1: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
      R2: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
    },
    C: {
      C1: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
      C2: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
      C3: {
        checked: false,
        fileId: null,
        importEqpmNm: '',
      },
    },
  },
  formValue: {
    equipmentCheckList: [],
  },
  setFormValue: (updateFn) =>
    set((state) => ({
      formValue: updateFn(state.formValue),
    })),

  setSelectedWork: (name, checked) => {
    set((state) => {
      const newState = {
        selectedWork: { ...state.selectedWork, [name]: checked },
      };

      return newState;
    });
  },

  // selectedWork, selectedDevice
  // 부모 체크박스 변경
  changeSelectedWork: (selectedWorkName, checked) => {
    set(
      produce((state: any) => {
        state.selectedWork[selectedWorkName] = checked;
        if (!checked) {
          // 자식을 바꾸면됨
          if (selectedWorkName === 'E') {
            state.selectedDevice.E.E1.checked = false;
          } else if (selectedWorkName === 'F') {
            state.selectedDevice.F.F1.checked = false;
            state.selectedDevice.F.F2.checked = false;
            state.selectedDevice.F.F3.checked = false;
          } else if (selectedWorkName === 'H') {
            state.selectedDevice.H.H1.checked = false;
            state.selectedDevice.H.H2.checked = false;
            state.selectedDevice.H.H3.checked = false;
            state.selectedDevice.H.H3.fileId = null;
            state.selectedDevice.H.H4.checked = false;
            state.selectedDevice.H.H4.fileId = null;
          } else if (selectedWorkName === 'R') {
            state.selectedDevice.R.R1.checked = false;
            state.selectedDevice.R.R1.fileId = null;
            state.selectedDevice.R.R2.checked = false;
            state.selectedDevice.R.R2.fileId = null;
          } else if (selectedWorkName === 'C') {
            state.selectedDevice.C.C1.checked = false;
            state.selectedDevice.C.C1.fileId = null;
            state.selectedDevice.C.C2.checked = false;
            state.selectedDevice.C.C2.fileId = null;
            state.selectedDevice.C.C3.checked = false;
            state.selectedDevice.C.C3.checked = false;
            state.selectedDevice.C.C3.importEqpmNm = '';
          }
        }
      })
    );
  },

  // 자식 체크박스 변경
  changeSelectedDevice: (selectedDeviceName, childCheckBoxCd, checked) => {
    set((state) =>
      produce(state, (draft) => {
        draft.selectedDevice[selectedDeviceName][childCheckBoxCd] = {
          ...draft.selectedDevice[selectedDeviceName][childCheckBoxCd],
          checked,
        };
      })
    );
  },

  // fileId 입력하기
  updateFileId: (workCd, deviceCd, fileId) => {
    set((state) => ({
      selectedDevice: {
        ...state.selectedDevice,
        [workCd]: {
          ...state.selectedDevice[workCd], // workCd에 대한 하위 객체
          [deviceCd]: {
            ...state.selectedDevice[workCd][deviceCd], // deviceCd에 대한 하위 객체
            fileId, // fileId 업데이트
          },
        },
      },
    }));
  },

  //importEqpmNm 입력하기
  updateImportEqpmNm: (workCd, deviceCd, importEqpmNm) => {
    set((state) => ({
      selectedDevice: {
        ...state.selectedDevice,
        [workCd]: {
          ...state.selectedDevice[workCd],
          [deviceCd]: {
            ...state.selectedDevice[workCd][deviceCd],
            importEqpmNm,
          },
        },
      },
    }));
  },

  // Update equipmentList based on selectedDevice state
  updatedCheckList: (category, item) => {
    const selectedDevice = get().selectedDevice;

    if (selectedDevice[category][item] === true) {
      set((state) => ({
        formValue: [...state.formValue, { category, item }],
      }));
    } else {
      set((state) => ({
        formValue: state.formValue.filter((v) => v.item !== item),
      }));
    }
    console.log('updatedCheckList : ', get().formValue);
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuWorkPermitDeviceChecklistFormStore;
