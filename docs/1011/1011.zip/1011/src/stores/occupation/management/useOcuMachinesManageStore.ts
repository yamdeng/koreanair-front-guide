import { create } from 'zustand';
import useOcuMachinesFormStore from './useOcuMachineFormStore';

/* zustand store 생성 */
const useOcuMachinesManageStore = create<any>((set) => ({
  tabIndex: 0,

  changeTab: (tabIndex) => {
    set({ tabIndex: tabIndex });
    console.log(`changeTab : ${tabIndex}`);
    // TODO : 탭이 바뀔때 마다 해당 탭의 데이터를 조회할지 여부 판단
    if (tabIndex === 0) {
      // 현황 탭일때 초기화
      // useOcuMachinesStatusStore.getState().init();
    } else {
      // 조회 탭일때 초기화
      // useOcuMachinesFormStore.getState().init();
    }
  },

  clear: () => {
    // TODO : clear
    // set({ tabIndex: 0 });
  },
}));

export default useOcuMachinesManageStore;
