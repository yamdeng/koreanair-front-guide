import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';
import ModalService from '@/services/ModalService';
import ApiService from '@/services/ApiService';
import { FORM_TYPE_ADD } from '@/config/CommonConstant';
import ToastService from '@/services/ToastService';
import { produce } from 'immer';
import useOcuWorkPermitDeviceChecklistFormStore from './useOcuWorkPermitDeviceChecklistStore';
import _ from 'lodash';

const selectedWorkMap = {
  confinedSpace: 'S',
  electrical: 'E',
  fireRisk: 'F',
  highPlace: 'H',
  hanging: 'R',
  constructionMachine: 'C',
};

/* yup validation */
const yupFormSchema = yup.object({
  // 외주작업
  // 공사ID
  cntrId: yup.number(),
  // 공사명
  cntrNm: yup.string(),
  // 사용부문코드
  sectCd: yup.string(),
  // 관리부서코드
  deptCd: yup.string(),
  // 공사분야코드
  cntrAreaCd: yup.string(),
  // 특별교육대상여부 - when user doesn't save anything, it should be chnaged to 'N'
  spclEduTargetYn: yup.string(),
  // 시공사
  cnstCmpny: yup.string(),
  // 담당자
  staff: yup.string(),
  // 연락처
  contactNo: yup.string(),
  // 공사장소ID - 공사장소명
  cntrSiteid: yup.number(),
  // 공사 위치명
  cntrPositionNm: yup.string(),
  // 공사 인원 수
  cntrPrsnCnt: yup.number(),
  // 공사 신청 시작 일시
  cntrApplyStartDttm: yup.string(),
  // 공사 신청 종료 일시
  cntrApplyEndDttm: yup.string(),
  // 사전동의 여부
  preConsentYn: yup.string(),
  // 신청자 사번
  applyEmpno: yup.string(),

  // 등록 일시
  regDttm: yup.string(),
  // 등록자 ID
  regUserId: yup.string(),
  // 수정 일시
  updDttm: yup.string(),
  // 수정자 ID
  updUserId: yup.string(),
  // 첨부서류 첨부 파일 ID
  reportFileId: yup.number(),
  // 기타 첨부서류 첨부파일 ID
  etcReportFileId: yup.number().nullable(),
  // 작업종료 첨부파일 ID
  wrkEndFileId: yup.number(),

  // 외주작업 공사장소
  // 공사장소 ID
  cnstrSiteId: yup.number(),
  // 공사 장소 명
  cntrLocationNm: yup.string(),
  // 사용 여부
  useYn: yup.string(),

  // 특별교육 모달 선택 리스트
  eduChoiceList: yup.array().of(
    yup.object().shape({
      // 외주작업 특별교육 선택
      // 특별교육 항목 코드
      spclEduItemCd: yup.string(),
      // 선택 여부
      chcYn: yup.string(),
      // 첨부파일 ID
      fileId: yup.number(),
    })
  ),
  // 작업구분 반입장비 체크리스트
  equipmentList: yup.array().of(
    yup.object().shape({
      // 외주작업 반입장비
      // 반입장비 ID
      imprtEqpmId: yup.number(),
      // 공사 작업 코드
      cntrWrkCd: yup.string(),
      // 반입 장비 코드
      imprtEqpmCd: yup.string(),
      // 첨부파일 ID
      fileId: yup.number(),
    })
  ),
});

/* formValue 초기값 */
const initFormValue = {
  cntrNm: '',
  sectCd: '',
  deptCd: '',
  cntrAreaNm: '',
  spclEduTargetYn: '',
  cnstCmpny: '',
  staff: '',
  contactNo: '',
  cntrSiteId: '',
  cntrPositionNm: '',
  cntrPrsnCnt: '',
  cntrApplyStartDttm: '',
  cntrApplyEndDttm: '',
  reportFileId: '',
  etcReportFileId: '',
  eduChoiceList: [],
  equipmentList: [], // server will take this using this name
  preConsentYn: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuWorkPermitFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...createCommonDataset(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  formValue: {
    equipmentList: [],
  },

  getTest: () => {
    const { selectedWork, selectedDevice } = useOcuWorkPermitDeviceChecklistFormStore.getState();
    const selectedWorkKeys = _.keys(selectedWork);
    const applySelectedWorkKeys = [];
    selectedWorkKeys.forEach((keyName) => {
      if (selectedWork[keyName]) {
        applySelectedWorkKeys.push(keyName);
      }
    });

    const childEquipmentList = [];

    // 1.대분류 체크박스 키 추출
    selectedWorkKeys.forEach((selectedWorkKey) => {
      // 2.중분류 체크박스중 선택되어있는 정보 추출
      const selectedDeviceInfo = selectedDevice[selectedWorkKey];
      const selectedDeviceInfoKeys = _.keys(selectedDeviceInfo);

      // checked가 된 필드 추출
      const applySelectedDeviceKeys = [];
      selectedDeviceInfoKeys.forEach((selectedDeviceKeyName) => {
        if (selectedDevice[selectedDeviceKeyName].checked) {
          applySelectedDeviceKeys.push(selectedDeviceKeyName);
        }
      });

      applySelectedDeviceKeys.forEach((applyDeviceKeyName) => {
        childEquipmentList.push({
          cntrWrkCd: selectedWorkMap[selectedWorkKey],
          imprtEqpmCd: applyDeviceKeyName,
          importEqpmNm: selectedDevice[selectedWorkKey][applyDeviceKeyName].importEqpmNm || '',
          fileId: selectedDevice[selectedWorkKey][applyDeviceKeyName].fileId,
        });
      });
    });
  },

  setEquipmentList: (newEquipmentList) =>
    set((state) => ({
      formValue: {
        ...state.formValue,
        equipmentList: newEquipmentList,
      },
    })),

  setFormValue: (updater) =>
    set((state) => ({
      formValue: typeof updater === 'function' ? updater(state.formValue) : updater,
    })),

  validLocationList: [],
  getAllLocationNames: async () => {
    try {
      const apiResult = await ApiService.get('ocu/management/permits/locationNames');
      set({ validLocationList: apiResult.data || [] });
    } catch (error) {
      console.error('Failed to fetch valid locations: ', error);
      set({ validLocationList: [] });
    }
  },

  isEduChoiceModalOpen: false,

  openEduChoiceModal: (detailInfo = null) => {
    set({ isEduChoiceModalOpen: true, eduChoiceModalInfo: detailInfo });
  },

  closeEduChoiceModal: () => {
    set({ isEduChoiceModalOpen: false });
  },

  // 모달에서 가져온 선택값 넣기
  saveEduChoiceModal: (eduModalData) => {
    set((state) => {
      const updatedEduChoiceList = [...state.formValue.eduChoiceList, ...eduModalData];
      return {
        formValue: {
          ...state.formValue,
          eduChoiceList: updatedEduChoiceList,
        },
      };
    });
    console.log('Final eduChoiceList Checking in workPermitStore: ', get().formValue.eduChoiceList);
  },

  // 전체 초기화
  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },

  submitWorkPermit: async () => {
    const { validate, getApiParam, formType, formDetailId, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '제출하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`제출 apiParam : ${JSON.stringify(apiParam)}`);
          if (formType === FORM_TYPE_ADD) {
            await ApiService.post(`${formApiPath}`, apiParam);
          } else {
            await ApiService.put(`${formApiPath}/${formDetailId}`, apiParam);
          }
          await set({ isDirty: false });
          ToastService.success('제출이 완료되었습니다.');
          await cancel();
        },
      });
    }
  },

  saveWorkPermit: async () => {
    const { validate, getApiParam, formType, formDetailId, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          if (formType === FORM_TYPE_ADD) {
            await ApiService.post(`${formApiPath}`, apiParam);
          } else {
            await ApiService.put(`${formApiPath}/${formDetailId}`, apiParam);
          }
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    }
  },
}));

export default useOcuWorkPermitFormStore;
