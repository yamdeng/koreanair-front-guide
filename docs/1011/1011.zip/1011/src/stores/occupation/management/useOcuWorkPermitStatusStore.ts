import { create } from 'zustand';
import CommonUtil from '@/utils/CommonUtil';
import { DATE_PICKER_TYPE_MONTH } from '@/config/CommonConstant';
import { createFormSliceYup } from '@/stores/slice/formSlice';
import { formBaseState } from '@/stores/slice/formListSlice';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import axios from 'axios';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/permits/calendar',
  baseRoutePath: '/occupation/management/permits',
};

const initSearchParam = {};

/* formValue 초기값 */
const initFormValue = {
  cntrNm: '',
  spclEduTargetYn: '',
  cntrLocationCd: '',
  cntrPositionNm: '',
  cntrApplyStartDttm: '',
  cntrApplyEndDttm: '',
  preConsentYn: '',
  applyEmpno: '',
  aprvEmpno: '',
  aprvDeptOpnn: '',
  applyStatusCd: '',
  wrkStatusCd: '',
  wrkStartDt: '',
  wrkStartRemark: '',
  wrkEndDt: '',
  wrkEndRemark: '',
  regDttm: '',
  regUserId: '',
  updDttm: '',
  updUserId: '',
  cntrLocationNm: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits/calendar',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitStatusFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuWorkPermitStatusStore = create<any>((set, get) => ({
  ...createListSlice(set, get),
  ...createFormSliceYup(set, get),
  ...initFormData,
  ...initListData,
  // 월 선택 초기 false
  monthDatePickerOpen: false,
  // 월 검색
  searchMonth: CommonUtil.getNowMonthString(),
  // 클릭된 날짜 0으로 초기화
  selectedDate: 0,
  // 달력 안의 날짜 array
  calendarDateList: [],
  // 월에 대한 작업정보 array
  scheduleList: [],
  // 선택된 날짜의 작업 목록
  dateScheduleList: [],

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  // 달력의 열림상태 업데이트 할꺼임
  setMonthDatePickerOpen: (openStatus) => {
    set({ monthDatePickerOpen: openStatus });
  },

  prevMonth: () => {
    const { searchMonth, changeSearchMonth } = get();
    const applyMonth = CommonUtil.calculateDate(searchMonth, 'YYYY-MM', DATE_PICKER_TYPE_MONTH, -1);
    changeSearchMonth(applyMonth);
  },

  nextMonth: () => {
    const { searchMonth, changeSearchMonth } = get();
    const applyMonth = CommonUtil.calculateDate(searchMonth, 'YYYY-MM', DATE_PICKER_TYPE_MONTH, 1);
    changeSearchMonth(applyMonth);
  },

  changeSearchMonth: async (month) => {
    const calendarDateList = CommonUtil.convertWeekDayList(CommonUtil.getDateListByMonth(month));
    set({ searchMonth: month, calendarDateList: calendarDateList, monthDatePickerOpen: false });

    // 한 달간의 작업 목록을 가져오는 API 호출
    await get().fetchScheduleList(month);
  },

  fetchScheduleList: async (month) => {
    try {
      const { listApiPath } = get();
      const response = await axios.get(`${listApiPath}?searchMonth=${month}`);

      console.log('API Response:', response.data); // 응답 데이터 확인

      // 현재 날짜 가져오기
      const today = new Date();

      // 작업 목록에 대해 workStatus 설정
      const updatedScheduleList = response.data.map((item) => {
        const startDate = new Date(item.cntrApplyStartDttm);
        const endDate = new Date(item.cntrApplyEndDttm);

        let workStatus;
        if (today >= startDate && today <= endDate) {
          workStatus = '작업중';
        } else if (today > endDate) {
          workStatus = '작업종료';
        } else {
          workStatus = '작업예정';
        }

        return {
          ...item,
          workStatus, // 새로운 workStatus 추가
        };
      });

      // API로부터 받은 데이터를 상태에 저장
      set({ scheduleList: updatedScheduleList });
    } catch (error) {
      if (error.response) {
        // 서버가 응답을 했지만 상태 코드가 2xx가 아닌 경우
        console.error('API Error Response:', error.response.data);
        console.error('Error Status Code:', error.response.status);
      } else if (error.request) {
        // 요청이 이루어졌지만 응답을 받지 못한 경우
        console.error('No response received:', error.request);
      } else {
        // 다른 오류가 발생한 경우
        console.error('Error Message:', error.message);
      }
      // alert('일정 목록을 가져오는 데 실패했습니다.');
    }
  },

  // 1 ~ 31
  changeSelectedDate: (date) => {
    // 선택한 날짜를 상태에 저장
    set({ selectedDate: date });

    // 이미 가져온 작업 목록에서 날짜별로 필터링
    const { scheduleList } = get(); // 기존 작업 목록 가져오기
    const filteredList = scheduleList.filter((item) => {
      // item의 시작일과 종료일을 가져옵니다.
      const startDate = new Date(item.cntrApplyStartDttm).toISOString().split('T')[0];
      const endDate = new Date(item.cntrApplyEndDttm).toISOString().split('T')[0];

      // 선택한 날짜가 시작일과 종료일 사이에 있는지 확인
      return startDate <= date && endDate >= date;
    });

    // 필터링된 목록을 상태에 저장
    set({ dateScheduleList: filteredList });
  },

  init: () => {
    const { changeSearchMonth } = get();
    const currentMonth = CommonUtil.getNowMonthString();
    changeSearchMonth(currentMonth);
  },

  changeTab: (tabIndex) => {
    set({ tabIndex: tabIndex });
    // TODO : 탭이 바뀔때 마다 해당 탭의 데이터를 조회할지 여부 판단
    // NEED TO CHECK : The previous data should be remained or not?
  },

  clear: () => {
    // TODO : clear
    set({ tabIndex: 0 });
  },
}));

export default useOcuWorkPermitStatusStore;
