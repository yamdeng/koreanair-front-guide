import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import history from '@/utils/history';
import { el } from '@faker-js/faker';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';

/* yup validation */
const yupFormSchema = yup.object({
  // 공정명
  procNm: yup.string(),
  // 세부 작업명
  detailWrkNm: yup.string(),

  // 위험분류
  riskClsNm: yup.string(),
  // 위험요인
  riskFactorCd: yup.string(),
  // 위험발생 상황 및 결과
  riskOcurStatRes: yup.string(),
  // 현재의 안전보건 조치
  currHlthSftyAction: yup.string(),
  // 가능성
  riskDcsnPsbltVal: yup.string(),
  // 중대성
  riskDcsnImprtVal: yup.string(),
  // 위험도
  riskDcsnRiskVal: yup.string(),
  // 위험성 결정
  riskDcsnCd: yup.string(),
  // 감소대책 수립
  rdcmsrCd: yup.string(),

  // 개선 예정 일자
  befImprSchdDt: yup.string().required(),

  // // 개선내용
  // aftImprContent: yup.string().required(),

  rdcmsrOpnnInfoList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        rdcmsrEmplNm: yup.string().required().max(300, '300자 이내로 작성해주세요.'),
        rdcmsrOpnnCn: yup.string().required(),
      })
    ),
});

/* yup validation */
const yupFormSchema2 = yup.object({
  // 공정명
  procNm: yup.string(),
  // 세부 작업명
  detailWrkNm: yup.string(),

  // 위험분류
  riskClsNm: yup.string(),
  // 위험요인
  riskFactorCd: yup.string(),
  // 위험발생 상황 및 결과
  riskOcurStatRes: yup.string(),
  // 현재의 안전보건 조치
  currHlthSftyAction: yup.string(),
  // 가능성
  riskDcsnPsbltVal: yup.string(),
  // 중대성
  riskDcsnImprtVal: yup.string(),
  // 위험도
  riskDcsnRiskVal: yup.string(),
  // 위험성 결정
  riskDcsnCd: yup.string(),
  // 감소대책 수립
  rdcmsrCd: yup.string(),

  //개선 예정 일자
  befImprSchdDt: yup.string().required(),

  // 개선 완료 일자
  aftImprCmpltDt: yup.string().required(),
  // 개선 내용
  aftImprContent: yup.string().required(),
  // 가능성
  aftImprPsbltVal: yup.string().required(),
  // 중대성
  aftImprImprtVal: yup.string().required(),
  // 위험도
  aftImprRiskVal: yup.string().required(),

  // // 개선내용
  // aftImprContent: yup.string().required(),

  rdcmsrOpnnInfoList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        rdcmsrEmplNm: yup.string().required(),
        rdcmsrOpnnCn: yup.string().required(),
      })
    ),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  /* 위험성정보 */

  // 공정명
  procNm: '',
  // 세부 작업명
  detailWrkNm: '',

  // 위험분류
  riskClsNm: '',
  // 위험요인
  riskFactorCd: '',
  // 위험발생 상황 및 결과
  riskOcurStatRes: '',
  // 현재의 안전보건 조치
  currHlthSftyAction: '',
  // 가능성
  riskDcsnPsbltVal: '',
  // 중대성
  riskDcsnImprtVal: '',
  // 위험도
  riskDcsnRiskVal: '',
  // 위험성 결정
  riskDcsnCd: '',
  // 감소대책 수립
  rdcmsrCd: '',

  // 개선 완료일자 수립
  aftImprCmpltDt: '',
  // 개선 내용
  aftImprContent: '',

  rdcmsrOpnnInfoList: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/risk/rdcmsr',
  baseRoutePath: '/occupation/risk/rdcmsr',
  formName: 'useOcuRdcmsrFormStore',
  formValue: {
    ...initFormValue,
  },

  selectedPlaceIndex: -1,
  selectedPlace2ndInfoIndex: -1,
};

//  store
const useOcuRdcmsrFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createCommonDataset(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  // 근로자 의견 정보 삭제 list
  deleteRdcmsrOpnnInfoList: [],

  yupFormSchema: yupFormSchema,
  yupFormSchema2: yupFormSchema2,

  setSelectedPlaceIndex: (index: number) => {
    console.log('인덱스===>', index);
    set({ selectedPlaceIndex: index });
  },

  getPlacePath: () => {
    return `formValue.rdcmsrOpnnInfoList`;
  },

  // setSelectedPlace2ndInfoIndex: (index: number) => {
  //   set({ selectedPlace2ndInfoIndex: index });
  // },

  // getPlace2ndInfoPath: () => {
  //   const { selectedPlaceIndex } = get();
  //   return `formValue.rdcmsrOpnnInfoList[${selectedPlaceIndex}].place2ndInfoList`;
  // },

  // 오류 메시지 가져오기
  getPlaceError: (field: string) => {
    const { errors, selectedPlaceIndex } = get();
    const path = `rdcmsrOpnnInfoList[${selectedPlaceIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getPlaceColumn: (field) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.getColumn(getPlacePath(), selectedPlaceIndex, field);
  },

  setPlaceColumn: (field: string, value: any) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.setColumn(getPlacePath(), selectedPlaceIndex, field, value);
  },

  addPlaceRow: () => {
    const { CommonDS, getPlacePath, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.addRow(getPlacePath());
    setSelectedPlaceIndex(rowIdx);
  },

  delPlaceRow: () => {
    const { CommonDS, getPlacePath, selectedPlaceIndex, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.deleteRow(getPlacePath(), selectedPlaceIndex);
    setSelectedPlaceIndex(rowIdx);
  },

  // getPlace2ndList: () => {
  //   const { CommonDS, getPlace2ndInfoPath } = get();
  //   return CommonDS.getList(getPlace2ndInfoPath());
  // },

  // addPlace2ndInfo: () => {
  //   const { CommonDS, getPlace2ndInfoPath, setSelectedPlace2ndInfoIndex } = get();
  //   const rowIdx = CommonDS.addRow(getPlace2ndInfoPath());
  //   setSelectedPlace2ndInfoIndex(rowIdx);
  // },

  // delPlace2ndInfo: () => {
  //   const { CommonDS, getPlace2ndInfoPath, selectedPlace2ndInfoIndex, setSelectedPlace2ndInfoIndex } = get();
  //   const rowIdx = CommonDS.deleteRow(getPlace2ndInfoPath(), selectedPlace2ndInfoIndex);
  //   setSelectedPlace2ndInfoIndex(rowIdx);
  // },

  validate: async () => {
    let success = true;
    const errors = {};

    const { yupFormSchema, getFormValue, formName } = get();
    const formValue = getFormValue();
    let firstErrorFieldKey = '';

    try {
      if (formValue.rdcmsrStatCd === 'B') {
        await yupFormSchema.validate(formValue, { abortEarly: false });
      } else {
        await yupFormSchema2.validate(formValue, { abortEarly: false });
      }

      await yupFormSchema.validate(formValue, { abortEarly: false });
    } catch (error: any) {
      success = false;
      console.log(error.errors);
      const yupErrors = error.inner;
      firstErrorFieldKey = yupErrors[0].path;
      const groupErrorInfo = _.groupBy(yupErrors, 'path');
      const errorKeys = Object.keys(groupErrorInfo);
      errorKeys.forEach((errorKey) => {
        errors[errorKey] = groupErrorInfo[errorKey][0].message;
      });
    }

    if (firstErrorFieldKey) {
      success = false;
      const applyFormName = formName ? formName : '';
      const applyFirstErrorFieldKey = applyFormName + firstErrorFieldKey;
      try {
        if (document.getElementById(applyFirstErrorFieldKey)) {
          document.getElementById(applyFirstErrorFieldKey).focus();
        }
      } catch (e) {
        // 로그를 찍을 필요가 없는 에러 catch
      }
    }

    set({
      isDirty: true,
      isValid: success,
      errors: errors,
    });
    return success;
  },

  saveAll: async () => {
    const { validate, getApiParam, formValue, formType, formDetailId, search, baseRoutePath, formApiPath, cancel } =
      get();

    // const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);

    // let isValid = '';

    const isValid = await validate(yupFormSchema);

    // if (formValue.rdcmsrStatCd === 'B') {
    //   console.log('진행중');
    //   isValid = await validate(yupFormSchema);
    // } else {
    //   console.log('완료');
    //   isValid = await validate(yupFormSchema2);
    // }
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);

          await ApiService.post(`${formApiPath}/saveRdcMsr`, apiParam);

          search();
          history.push(`${baseRoutePath}`);

          // await ApiService.post(`${formApiPath}`, apiParam);
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    } else {
      const { CommonDS, errors } = get();
      CommonDS.setValidateList('formValue', errors);
    }
  },

  // form 전체 초기화
  clear: () => {
    set({
      ...formBaseState,
      formValue: { ...initFormValue },
      selectedPlace: null,
      selectedPlaceIndex: -1,
      // selectedPlace2ndInfoIndex: -1,
    });
  },
}));

export default useOcuRdcmsrFormStore;
