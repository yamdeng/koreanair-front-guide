import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import history from '@/utils/history';
import { el } from '@faker-js/faker';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';
import useOcuRiskTab1FormStore from './useOcuRiskTab1FormStore';

/* yup validation */
const yupFormSchema = yup.object({
  /* 위험성정보 */

  // // 공정명
  // procNm: yup.string().required(),
  // // 세부 작업명
  // detailWrkNm: yup.string().required(),

  // // 위험분류
  // riskClsNm: yup.string().required(),
  // // 위험요인
  // riskFactorCd: yup.string().required(),
  // // 위험발생 상황 및 결과
  // riskOcurStatRes: yup.string().required(),
  // // 현재의 안전보건 조치
  // currHlthSftyAction: yup.string().required(),
  // // 가능성
  // riskDcsnPsbltVal: yup.string().required(),
  // // 중대성
  // riskDcsnImprtVal: yup.string().required(),
  // // 위험도
  // riskDcsnRiskVal: yup.string().required(),
  // // 위험성 결정
  // riskDcsnCd: yup.string().required(),
  // // 감소대책 수립
  // rdcmsrCd: yup.string().required(),

  // 가능성: riskDcsnPsbltVal
  // 중대성: riskDcsnImprtVal
  // 위험도: riskDcsnRiskVal
  processInfoList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        // rdcmsrEmplNm: yup.string().required(),
        // rdcmsrOpnnCn: yup.string().required(),

        procNm: yup.string().required(),
        detailWrkNm: yup.string().required().max(300, '300자 이내로 작성해주세요.'),
        riskClsCd: yup.string().required(),
        riskFactorCd: yup.string().required(),
        riskOcurStatRes: yup.string().required(),
        currHlthSftyAction: yup.string().required(),
        riskDcsnPsbltVal: yup.number().required(),
        riskDcsnImprtVal: yup.number().required(),
        riskDcsnRiskVal: yup.number().required(),
        riskDcsnCd: yup.string().required(),
        rdcmsrCd: yup.string().required(),

        // place2ndInfoList: yup.array().of(
        //   yup.object().shape({
        //     companyNm: yup.string().required(),
        //     majorWorkCn: yup.string().required(),
        //     staffNm: yup.string().required(),
        //     staffContactNo: yup.string().required(),
        //   })
        // ),
      })
    ),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  /* 위험성정보 */

  // 공정명
  procNm: '',
  // 세부 작업명
  detailWrkNm: '',

  // 위험분류
  riskClsNm: '',
  // 위험요인
  riskFactorCd: '',
  // 위험발생 상황 및 결과
  riskOcurStatRes: '',
  // 현재의 안전보건 조치
  currHlthSftyAction: '',
  // 가능성
  riskDcsnPsbltVal: '',
  // 중대성
  riskDcsnImprtVal: '',
  // 위험도
  riskDcsnRiskVal: '',
  // 위험성 결정
  riskDcsnCd: '',
  // 감소대책 수립
  rdcmsrCd: '',

  processInfoList: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/risk/reval',
  baseRoutePath: '/occupation/risk/reval',
  formName: 'useOcuRiskTab3FormStore',
  formValue: {
    ...initFormValue,
  },

  selectedPlaceIndex: -1,
  selectedPlace2ndInfoIndex: -1,
};

//  store
const useOcuRiskTab3FormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createCommonDataset(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  // 위험성 정보 삭제 list
  deleteProcGridList: [],

  yupFormSchema: yupFormSchema,

  // 가능성 모달 팝업
  openFormModal: () => {
    set({ isCodeFormModalOpen: true });
  },
  closeFormModal: () => {
    set({ isCodeFormModalOpen: false });
  },

  // 중대성 모달 팝업
  openFormModal2: () => {
    set({ isCodeFormModalOpen2: true });
  },
  closeFormModal2: () => {
    set({ isCodeFormModalOpen2: false });
  },

  // 위험도 모달 팝업
  openFormModal3: () => {
    set({ isCodeFormModalOpen3: true });
  },
  closeFormModal3: () => {
    set({ isCodeFormModalOpen3: false });
  },

  // list
  setSelectedPlaceIndex: (index: number) => {
    console.log('인덱스===>', index);
    set({ selectedPlaceIndex: index });
  },

  getPlacePath: () => {
    return `formValue.processInfoList`;
  },

  // 오류 메시지 가져오기
  getPlaceError: (field: string) => {
    const { errors, selectedPlaceIndex } = get();
    const path = `processInfoList[${selectedPlaceIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getPlaceColumn: (field) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.getColumn(getPlacePath(), selectedPlaceIndex, field);
  },

  setPlaceColumn: (field: string, value: any) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.setColumn(getPlacePath(), selectedPlaceIndex, field, value);
  },

  addPlaceRow: () => {
    const { CommonDS, getPlacePath, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.addRow(getPlacePath());
    setSelectedPlaceIndex(rowIdx);
  },

  delPlaceRow: () => {
    const { CommonDS, getPlacePath, selectedPlaceIndex, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.deleteRow(getPlacePath(), selectedPlaceIndex);
    setSelectedPlaceIndex(rowIdx);
  },

  getDetail: async (id) => {
    // 복사 여부
    const copyChk = useOcuRiskTab1FormStore.getState().tab1CopyChk;

    console.log('copyChk===>', copyChk);

    let formApiPath = 'ocu/risk/reval/selectTab3';

    // 복사인경우
    if (copyChk == 'Y') {
      formApiPath = 'ocu/risk/reval/selectCopyTab3';
    }

    const response: any = await ApiService.get(`${formApiPath}/${id}`);

    const detailInfo = response.data;
    set({
      detailInfo: detailInfo,
      formValue: detailInfo,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  saveAll: async () => {
    // 복사 여부
    const copyChk = useOcuRiskTab1FormStore.getState().tab1CopyChk;

    // 복사인경우
    if (copyChk == 'Y') {
      alert('사전준비 저장 후 저장 가능합니다.');
      return false;
    }
    const { validate, getApiParam, formValue, formType, formDetailId, search, baseRoutePath, formApiPath, cancel } =
      get();
    const isValid = await validate();

    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);

          await ApiService.post(`${formApiPath}/${formValue.revalDocNo}/saveRiskTab3`, apiParam);

          // await ApiService.post(`${formApiPath}/saveRdcMsr`, apiParam);

          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          // search();
          // history.push(`${baseRoutePath}`);
          // await cancel();
        },
      });
    } else {
      const { CommonDS, errors } = get();
      CommonDS.setValidateList('formValue', errors);
    }
  },

  // // from 상세 조회
  // getDetail: async (id) => {
  //   const { setList, setTotalCount, procChange } = get();

  //   //const { formApiPath } = get();
  //   const formApiPath = 'ocu/risk/reval/selectTab3';
  //   const response: any = await ApiService.get(`${formApiPath}/${id}`);
  //   const detailInfo = response.data;

  //   console.log('조회값=====>', detailInfo);
  //   // set({
  //   //   // 위험성 결정 폼 정보
  //   //   detailInfo: detailInfo.revalProcess[0],
  //   //   formValue: detailInfo.revalProcess[0],
  //   //   formType: FORM_TYPE_UPDATE,
  //   // });

  //   // 위험성 결정 정보
  //   setTotalCount(detailInfo.revalProcess.length);
  //   setList(detailInfo.revalProcess);
  //   set({ rEvalDocNo: id });

  //   const { list } = get();
  //   // 상태값 N 추가
  //   list.map((info) => {
  //     info.procGubun = 'N';
  //   });

  //   // set({ originExecDeptlist: detailInfo.revalExecDept });
  //   console.log(' 리스트==>', list);

  //   // 위험성 결정 조회 정보
  //   procChange(detailInfo.revalProcess[0], 0);
  // },
  // // 위험성 결정 저장
  // procSaveStrore: (procData) => {
  //   const { procRow, list } = get();

  //   let procGubun = '';
  //   if (list[procRow].revalProcessId) {
  //     // 구분
  //     procGubun = 'U';
  //   } else {
  //     // 구분
  //     procGubun = 'I';
  //   }

  //   console.log('list[procRow]==>', list[procRow]);
  //   console.log('저장값==>', procData);

  //   const data = {
  //     // 저장 구분(N: 기본 ,I: 신규,U:수정)
  //     procGubun: (list[procRow].procGubun = procGubun),
  //     // 공정명
  //     procNm: (list[procRow].procNm = procData.procNm),
  //     // 세부 작업명
  //     detailWrkNm: (list[procRow].detailWrkNm = procData.detailWrkNm),
  //     // 위험분류
  //     riskClsCd: (list[procRow].riskClsCd = procData.riskClsNm),
  //     // 위험요인
  //     riskFactorCd: (list[procRow].riskFactorCd = procData.riskFactorCd),
  //     // 위험발생 상황 및 결과
  //     riskOcurStatRes: (list[procRow].riskOcurStatRes = procData.riskOcurStatRes),
  //     // 현재의 안전보건 조치
  //     currHlthSftyAction: (list[procRow].currHlthSftyAction = procData.currHlthSftyAction),
  //     // 가능성
  //     riskDcsnPsbltVal: (list[procRow].riskDcsnPsbltVal = Number(procData.riskDcsnPsbltVal)),
  //     // 중대성
  //     riskDcsnImprtVal: (list[procRow].riskDcsnImprtVal = Number(procData.riskDcsnImprtVal)),
  //     // 위험도
  //     riskDcsnRiskVal: (list[procRow].riskDcsnRiskVal = procData.riskDcsnRiskVal),
  //     // 위험성 결정
  //     riskDcsnCd: (list[procRow].riskDcsnCd = procData.riskDcsnCd),
  //     // 감소대책 수립
  //     rdcmsrCd: (list[procRow].rdcmsrCd = procData.rdcmsrCd),
  //   };

  //   // 추진팀 저장 list
  //   //originExecDeptlist.push(data);

  //   console.log('저장 후 LIST값==>', list);
  // },

  // // 위험성 결정삭제
  // deleteProcList: (delProcData) => {
  //   const { deleteProcGridList } = get();

  //   // 삭제 row 추가
  //   if (delProcData.data.revalProcessId) {
  //     deleteProcGridList.push(delProcData.data);
  //   }

  //   console.log('삭제후 위험성 결정  리스트==>', deleteProcGridList);
  // },

  // // 위험성 결정 행 추가
  // procAddRowStore: () => {
  //   const { procRow, list, formValue, setList } = get();

  //   console.log('로우 추가::', list);
  //   //console.log('newItem::', newItem);
  //   // console.log('clearNewItem::', clearNewItem);

  //   const newItem = {
  //     // 구분 값
  //     procGubun: 'I',
  //     // 공정명
  //     procNm: '',
  //     // 세부 작업명
  //     detailWrkNm: '',
  //     // 위험분류
  //     riskClsCd: '',

  //     // 위험분류명
  //     riskClsNm: '',
  //     // 위험요인
  //     riskFactorCd: '',
  //     // 위험발생 상황 및 결과
  //     riskOcurStatRes: '',
  //     // 현재의 안전보건 조치
  //     currHlthSftyAction: '',
  //     // 가능성
  //     riskDcsnPsbltVal: null,
  //     // 중대성
  //     riskDcsnImprtVal: null,
  //     // 위험도
  //     riskDcsnRiskVal: null,
  //     // 위험성 결정
  //     riskDcsnCd: '',
  //     // 감소대책 수립
  //     rdcmsrCd: '',
  //   };

  //   setList([...list, newItem]);
  //   // 위험성 결정 행
  //   set({ procRow: list.length });
  // },

  // // 위험성 결정 row 변경
  // procChange: (data, rowIndex) => {
  //   const { detailInfo, formValue, list } = get();

  //   console.log('data===>', data);

  //   // 공정명
  //   detailInfo.procNm = data.procNm;
  //   // 세부 작업명
  //   detailInfo.detailWrkNm = data.detailWrkNm;
  //   // 위험분류명
  //   detailInfo.riskClsCd = data.riskClsCd;
  //   // 위험분류명
  //   detailInfo.riskClsNm = data.riskClsNm;
  //   // 위험요인
  //   detailInfo.riskFactorCd = data.riskFactorCd;
  //   // 위험발생 상황 및 결과
  //   detailInfo.riskOcurStatRes = data.riskOcurStatRes;
  //   // 현재의 안전보건 조치
  //   detailInfo.currHlthSftyAction = data.currHlthSftyAction;
  //   // 가능성
  //   detailInfo.riskDcsnPsbltVal = data.riskDcsnPsbltVal;
  //   // 중대성
  //   detailInfo.riskDcsnImprtVal = data.riskDcsnImprtVal;
  //   // 위험도
  //   detailInfo.riskDcsnRiskVal = data.riskDcsnRiskVal;
  //   // 위험성 결정
  //   detailInfo.riskDcsnCd = data.riskDcsnCd;
  //   // 위험성 결정 명
  //   detailInfo.riskDcsnNm = data.riskDcsnNm;

  //   // 감소대책 수립
  //   detailInfo.rdcmsrCd = data.rdcmsrCd;
  //   // 감소대책 수립명
  //   detailInfo.rdcmsrNm = data.rdcmsrNm;

  //   // console.log('청취자행::', rowIndex);

  //   // 위험성 결정 행
  //   // set({ procRow: rowIndex });
  //   set({ procRow: rowIndex, formValue: detailInfo });
  // },

  // goFormPage: (id) => {
  //   const { baseRoutePath } = get();
  //   history.push(`${baseRoutePath}/${id}/edit`);
  // },

  // // 위험성평가 위험성 결정 탭 저장
  // saveUseOcuRiskTab3: async () => {
  //   const { list, formDetailId, formApiPath, search, formValue, baseRoutePath, deleteProcGridList, rEvalDocNo } = get();

  //   //const { list, formDetailId, formApiPath, search, formValue, baseRoutePath } = get();

  //   //useOcuRiskTab1ProcessListStore.getState().list;
  //   const apiList = _.cloneDeep(list);

  //   console.log('위험성결정===>', apiList);
  //   console.log('위험성결정 삭제 ===>', deleteProcGridList);

  //   // 상태 변경 안된 항목 빼고 위험성 결정 List 재구성
  //   const procInfoList = apiList.filter((item) => item.procGubun !== 'N');

  //   console.log('위험성결정===>', procInfoList);

  //   ModalService.confirm({
  //     body: '저장하시겠습니까?',
  //     ok: async () => {
  //       const formParam = formValue;
  //       const apiParam = {
  //         // 위험성 결정
  //         processInfoList: procInfoList,
  //         // 위험성 결정 삭제 리스트
  //         deleteProcList: deleteProcGridList,
  //       };

  //       console.log('보내는 저장값===>', apiParam);

  //       await ApiService.post(`${formApiPath}/${rEvalDocNo}/saveRiskTab3`, apiParam);
  //       // await ApiService.post(`${formApiPath}/${formDetailId}`, apiParam);
  //       search();
  //       //history.push(`${baseRoutePath}`);
  //       ToastService.success('저장되었습니다.');
  //     },
  //   });
  // },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuRiskTab3FormStore;
