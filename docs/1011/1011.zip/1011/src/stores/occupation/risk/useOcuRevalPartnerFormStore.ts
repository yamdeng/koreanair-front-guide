import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';

// import { FORM_TYPE_ADD } from '@/config/CommonConstant';
// import ModalService from '@/services/ModalService';
// import ApiService from '@/services/ApiService';

/* yup validation */
const yupFormSchema = yup.object({
  // 부문
  // prtnrREvalSectCd: yup.string().required(),
  // 부서
  // prtnrREvalDeptCd: yup.string().required(),
  // 작성자
  // regUserId: yup.string().required(),
  // 작성일자
  // regDttm: yup.string().required(),
  // 평가년도
  prtnrREvalEvalYear: yup.string().required(),
  // 평가시기
  prtnrREvalClsCd: yup.string().required(),
  // 협력업체
  prtnrId: yup.string().required(),
  // 사업장
  bizPlaceClsCd: yup.string().required(),
  // 제목
  prtnrREvalTitle: yup.string().required().max(300, '300자 이내로 작성해주세요.'),
  // 파일첨부
  prtnrREvalFileId: yup.number().nullable(),

  // 부문 코드
  // sectCd: yup.string().required(),
  // // 등록자
  // // regUserId: yup.string().required(),
  // // 등록일자
  // //regDttm: yup.string().required(),
  // // 공지사항 구분
  // noticeCls: yup.string().required(),
  // // 상위 표출 여부
  // upViewYn: yup.string().required(),
  // // 제목
  // noticeTitle: yup.string().required(),
  // // 내용
  // noticeContent: yup.string().required(),
  // 첨부파일 ID
  // fileId: yup.number().nullable(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  // 부문
  prtnrREvalSectCd: '',
  // 부서
  prtnrREvalDeptCd: '',
  // 작성자
  // regUserId: '',
  // 작성일자
  regDttm: '',
  // 평가년도
  prtnrREvalEvalYear: '',
  // 평가시기
  prtnrREvalClsCd: '',
  // 협력업체
  prtnrId: '',
  // 사업장
  bizPlaceClsCd: '',
  // 제목
  prtnrREvalTitle: '',
  // 파일첨부
  prtnrREvalFileId: null,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/risk/partner',
  baseRoutePath: '/occupation/risk/partner',
  formName: 'useOcuRevalPartnerFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuRevalPartnerFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuRevalPartnerFormStore;
