import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import history from '@/utils/history';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';
import useOcuRiskTab1FormStore from './useOcuRiskTab1FormStore';
import { el } from '@faker-js/faker';

/* yup validation */
const yupFormSchema = yup.object({
  // 안전 보건 정보
  hlthSftyInfoCn: yup.string().required(),
  /* 청취조사 */

  // // 근로자 성명
  // lSurveyEmplNm: yup.string().required(),
  // // 대상공정(작업)
  // lSurveyProcNm: yup.string().required(),
  // // 유해, 위험요인에 대한 의견
  // lSurveyHzdOpnn: yup.string().required(),

  // /* 현장순회 */

  // // 순회일자
  // sVisitDt: yup.string().required(),
  // // 대상공정(작업)
  // sVisitProcNm: yup.string().required(),
  // // 유해,위험요인에 대한 의견
  // sVisitHzdOpnn: yup.string().required(),
  // // 사진 첨부
  // sVisitFileId: yup.string().required(),

  /* 청취조사 */
  listenInfoList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        // 근로자
        lsurveyEmplNm: yup.string().required().max(20, '20자 이내로 작성해주세요.'),
        // 대상공정
        lsurveyProcNm: yup.string().required().max(300, '300자 이내로 작성해주세요.'),
        // 유해,위험요인 의견
        lsurveyHzdOpnn: yup.string().required(),
      })
    ),

  /* 현장순회 */
  visitInfoList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        // 순회일자
        svisitDt: yup.string().required(),
        // 대상공정(작업)
        svisitProcNm: yup.string().required().max(300, '300자 이내로 작성해주세요.'),
        // 유해,위험요인에 대한 의견
        svisitHzdOpnn: yup.string().required(),
        // 사진 첨부
        // svisitFileId: yup.string().required(),
      })
    ),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  hlthSftyInfoCn: '',
  /* 청취조사 */
  listenInfoList: [],
  /* 현장순회 */
  visitInfoList: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/risk/reval',
  baseRoutePath: '/occupation/risk/reval',
  formName: 'useOcuRiskTab2FormStore',
  formValue: {
    ...initFormValue,
  },

  selectedPlaceIndex: -1,
  selectedItemIndex: -1,
};

// 최상위 store()
export const useOcuRiskTab2FormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createCommonDataset(set, get),

  // ...createListSlice(set, get),

  ...initFormData,

  // 청취조사 삭제 list
  deleteListenGridList: [],

  yupFormSchema: yupFormSchema,

  getDetail: async (id) => {
    // 복사 여부
    const copyChk = useOcuRiskTab1FormStore.getState().tab1CopyChk;

    console.log('copyChk===>', copyChk);

    if (copyChk != 'Y') {
      const formApiPath = 'ocu/risk/reval/selectTab2';

      const response: any = await ApiService.get(`${formApiPath}/${id}`);

      const detailInfo = response.data;
      set({
        detailInfo: detailInfo,
        formValue: detailInfo,
        formDetailId: id,
        formType: FORM_TYPE_UPDATE,
      });
    }
  },

  saveAll: async () => {
    const {
      validate,
      getApiParam,
      formValue,
      formType,
      formDetailId,
      search,
      baseRoutePath,
      formApiPath,
      cancel,
      rEvalDocNo,
    } = get();

    console.log('formValue===>', formValue);

    // 복사 여부
    const copyChk = useOcuRiskTab1FormStore.getState().tab1CopyChk;

    // 복사인경우
    if (copyChk == 'Y') {
      alert('사전준비 저장 후 저장 가능합니다.');
      return false;
    }

    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);

          await ApiService.post(`${formApiPath}/${rEvalDocNo}/saveRiskTab2`, apiParam);

          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          // await cancel();
          // search();
          // history.push(`${baseRoutePath}`);

          // await ApiService.post(`${formApiPath}`, apiParam);
        },
      });
    } else {
      const { CommonDS, errors } = get();
      CommonDS.setValidateList('formValue', errors);
    }
  },

  // list
  getPlacePath: () => {
    return `formValue.listenInfoList`;
  },

  getItemPath: () => {
    return `formValue.visitInfoList`;
  },

  setSelectedPlaceIndex: (index: number) => {
    console.log('인덱스===>', index);
    set({ selectedPlaceIndex: index });
  },

  setSelectedItemIndex: (index: number) => {
    set({ selectedItemIndex: index });
  },

  // 청취자
  // 오류 메시지 가져오기
  getPlaceError: (field: string) => {
    const { errors, selectedPlaceIndex } = get();
    const path = `listenInfoList[${selectedPlaceIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getPlaceColumn: (field) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.getColumn(getPlacePath(), selectedPlaceIndex, field);
  },

  setPlaceColumn: (field: string, value: any) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.setColumn(getPlacePath(), selectedPlaceIndex, field, value);
  },

  addPlaceRow: () => {
    const { CommonDS, getPlacePath, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.addRow(getPlacePath());
    setSelectedPlaceIndex(rowIdx);
  },

  delPlaceRow: (selectedPlaceIndex: number) => {
    const { CommonDS, getPlacePath, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.deleteRow(getPlacePath(), selectedPlaceIndex);
    setSelectedPlaceIndex(rowIdx);
  },

  // 현장순회
  getItemError: (field: string) => {
    const { errors, selectedItemIndex } = get();
    const path = `visitInfoList[${selectedItemIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getItemColumn: (field) => {
    const { CommonDS, getItemPath, selectedItemIndex } = get();
    return CommonDS.getColumn(getItemPath(), selectedItemIndex, field);
  },

  setItemColumn: (field: string, value: any) => {
    const { CommonDS, getItemPath, selectedItemIndex } = get();
    return CommonDS.setColumn(getItemPath(), selectedItemIndex, field, value);
  },

  addItemRow: () => {
    const { CommonDS, getItemPath, setSelectedItemIndex } = get();
    const rowIdx = CommonDS.addRow(getItemPath());
    setSelectedItemIndex(rowIdx);

    // return CommonDS.addRow(getItemPath());
  },

  delItemRow: (selectedItemIndex: number) => {
    const { CommonDS, getItemPath, setSelectedItemIndex } = get();

    const rowIdx = CommonDS.deleteRow(getItemPath(), selectedItemIndex);
    setSelectedItemIndex(rowIdx);

    // return CommonDS.deleteRow(getItemPath(), selectedItemIndex);
  },

  openFormModal: () => {
    // const { detailInfo } = get();
    // const { setFormValue } = useOcuZeroHzdGoalModalFormStore.getState();
    //setFormValue(detailInfo);
    set({ isCodeFormModalOpen: true });
  },

  closeFormModal: () => {
    set({ isCodeFormModalOpen: false });
  },

  //   // from 상세 조회
  //   getDetail: async (id) => {
  //     const { setList, disablePaging, originExecDeptlist, setTotalCount, listenChange } = get();

  //     //const { formApiPath } = get();
  //     const formApiPath = 'ocu/risk/reval/selectTab2';
  //     const response: any = await ApiService.get(`${formApiPath}/${id}`);
  //     const detailInfo = response.data;

  //     console.log('조회값=====>', detailInfo);
  //     set({
  //       // 위험성 평가 기본 정보
  //       detailInfo: detailInfo.revalBase,
  //       formValue: detailInfo.revalBase,
  //       formType: FORM_TYPE_UPDATE,
  //     });

  //     // 청취조사 조회
  //     setTotalCount(detailInfo.revalListen.length);
  //     setList(detailInfo.revalListen);

  //     const { list } = get();
  //     // 상태값 N 추가
  //     list.map((info) => {
  //       info.listenGubun = 'N';
  //     });

  //     // set({ originExecDeptlist: detailInfo.revalExecDept });
  //     console.log(' 리스트==>', list);

  //     // 현장순회 조회 정보
  //     useOcuRiskTab2SiteVisitListStore.getState().getDetail(detailInfo.revalVisit);
  //     listenChange(detailInfo.revalListen[0], 0);
  //   },
  //   // 청취 조사 저장
  //   listenSaveStrore: (listenData) => {
  //     const { listenRow, list } = get();

  //     let listenGubun = '';
  //     if (list[listenRow].lsurveyId) {
  //       // 구분
  //       listenGubun = 'U';
  //     } else {
  //       // 구분
  //       listenGubun = 'I';
  //     }

  //     const data = {
  //       // 저장 구분(N: 기본 ,I: 신규,U:수정)
  //       listenGubun: (list[listenRow].listenGubun = listenGubun),
  //       // 근로자 성명
  //       lsurveyEmplNm: (list[listenRow].lsurveyEmplNm = listenData.lsurveyEmplNm),
  //       // 대상공정(작업)
  //       lsurveyProcNm: (list[listenRow].lsurveyProcNm = listenData.lsurveyProcNm),
  //       // 유해, 위험요인에 대한 의견
  //       lsurveyHzdOpnn: (list[listenRow].lsurveyHzdOpnn = listenData.lsurveyHzdOpnn),
  //     };

  //     // 추진팀 저장 list
  //     //originExecDeptlist.push(data);

  //     console.log('저장 후 LIST값==>', list);
  //   },

  //   // 청취 조사 삭제
  //   deleteListenList: (delListenData) => {
  //     const { deleteListenGridList } = get();

  //     // 삭제 row 추가
  //     if (delListenData.data.lsurveyId) {
  //       deleteListenGridList.push(delListenData.data);
  //     }

  //     console.log('삭제후 청취 조사  리스트==>', deleteListenGridList);
  //   },

  //   // 청취조사 행 추가
  //   listenAddRowStore: () => {
  //     const { listenRow, list, formValue, setList } = get();

  //     console.log('로우 추가::', list);
  //     //console.log('newItem::', newItem);
  //     // console.log('clearNewItem::', clearNewItem);

  //     const newItem = {
  //       // 구분 값
  //       listenGubun: 'I',
  //       lsurveyId: '',
  //       lsurveyEmplNm: '',
  //       lsurveyProcNm: '',
  //       lsurveyHzdOpnn: '',
  //     };

  //     setList([...list, newItem]);
  //     // 청취조사 행
  //     set({ listenRow: list.length });
  //   },

  //   // 청취자 row 변경
  //   listenChange: (data, rowIndex) => {
  //     const { detailInfo, formValue, list } = get();

  //     // 근로자
  //     detailInfo.lsurveyEmplNm = data.lsurveyEmplNm;
  //     // 대상공정(작업)
  //     detailInfo.lsurveyProcNm = data.lsurveyProcNm;
  //     // 유해,위험요인에 대한 의견
  //     detailInfo.lsurveyHzdOpnn = data.lsurveyHzdOpnn;

  //     // 근로자
  //     detailInfo.lsurveyEmplNm = data.lsurveyEmplNm;
  //     // 대상공정(작업)
  //     detailInfo.lsurveyProcNm = data.lsurveyProcNm;
  //     // 유해,위험요인에 대한 의견
  //     detailInfo.lsurveyHzdOpnn = data.lsurveyHzdOpnn;

  //     console.log('청취자행::', rowIndex);

  //     // 청취조사 행
  //     set({ listenRow: rowIndex, formValue: detailInfo });
  //   },

  //   goFormPage: (id) => {
  //     const { baseRoutePath } = get();
  //     history.push(`${baseRoutePath}/${id}/edit`);
  //   },

  //   // 위험성평가 유해 위험요인 파악 탭 저장
  //   saveUseOcuRiskTab2: async () => {
  //     const { list, formDetailId, formApiPath, search, formValue, baseRoutePath, deleteListenGridList } = get();

  //     //const { list, formDetailId, formApiPath, search, formValue, baseRoutePath } = get();

  //     //useOcuRiskTab1ProcessListStore.getState().list;
  //     const apiList = _.cloneDeep(list);

  //     console.log('기본정보===>', formValue);
  //     console.log('청취조사===>', apiList);
  //     console.log('청취조사 삭제 ===>', deleteListenGridList);
  //     console.log('현장순회===>', useOcuRiskTab2SiteVisitListStore.getState().list);
  //     console.log('현장순회 삭제===>', useOcuRiskTab2SiteVisitListStore.getState().deleteVisitGridList);

  //     // 상태 변경 안된 항목 빼고 청취조사 List 재구성
  //     const listenInfoList = apiList.filter((item) => item.listenGubun !== 'N');
  //     // 상태 변경 안된 항목 빼고 현장순회 List 재구성
  //     const visitInfoList = useOcuRiskTab2SiteVisitListStore.getState().list.filter((item) => item.visitGubun !== 'N');

  //     console.log('추진팀스===>', listenInfoList);
  //     console.log('공정스===>', visitInfoList);

  //     ModalService.confirm({
  //       body: '저장하시겠습니까?',
  //       ok: async () => {
  //         const formParam = formValue;
  //         const apiParam = {
  //           // 기본정보
  //           form: formParam,
  //           // 청취조사
  //           listenInfoList: listenInfoList,
  //           // 청취조사 삭제 리스트
  //           deleteListenInfoList: deleteListenGridList,
  //           // 현장순회 정보
  //           visitInfoList: visitInfoList,
  //           // 현장순회 정보 삭제 리스트
  //           deleteVisitInfoList: useOcuRiskTab2SiteVisitListStore.getState().deleteVisitGridList,
  //         };

  //         console.log('보내는 저장값===>', apiParam);

  //         await ApiService.post(`${formApiPath}/${formValue.revalDocNo}/saveRiskTab2`, apiParam);
  //         // await ApiService.post(`${formApiPath}/${formDetailId}`, apiParam);
  //         search();
  //         //history.push(`${baseRoutePath}`);
  //         ToastService.success('저장되었습니다.');
  //       },
  //     });
  //   },

  //   clear: () => {
  //     set({ ...formBaseState, formValue: { ...initFormValue } });
  //   },
  // }));

  // // 현장순회 store
  // export const useOcuRiskTab2SiteVisitListStore = create<any>((set, get) => ({
  //   ...createFormSliceYup(set, get),

  //   ...createListSlice(set, get),

  //   ...initFormData,

  //   // 현장순회 정보 삭제 list
  //   deleteVisitGridList: [],

  //   yupFormSchema: yupFormSchema,
  //   // from 상세 조회
  //   getDetail: async (revalVisit) => {
  //     const { setList, disablePaging, setTotalCount, visitChange } = get();

  //     setTotalCount(revalVisit.length);
  //     setList(revalVisit);

  //     const { list } = get();
  //     // 상태값 N 추가
  //     list.map((info) => {
  //       info.visitGubun = 'N';
  //     });

  //     visitChange(revalVisit[0], 0);
  //   },

  //   // 현장순회 행 추가
  //   visitAddRowStore: () => {
  //     const { list, setList } = get();

  //     console.log('로우 추가::', list);

  //     const newItem = {
  //       // 구분 값
  //       visitGubun: 'I',
  //       svisitId: '',
  //       svisitDt: '',
  //       svisitProcNm: '',
  //       svisitHzdOpnn: '',
  //       svisitFileId: '',
  //     };

  //     setList([...list, newItem]);
  //     // 현장순회 행
  //     set({ visitRow: list.length });
  //   },

  //   // 현장순회 삭제
  //   deleteVisitList: (delVisitData) => {
  //     const { deleteVisitGridList } = get();
  //     // 삭제 row 추가
  //     if (delVisitData.data.svisitId) {
  //       deleteVisitGridList.push(delVisitData.data);
  //     }
  //     console.log('삭제후 현장순회 리스트==>', deleteVisitGridList);
  //   },

  //   // 현장순회 row 변경
  //   visitChange: (data, rowIndex) => {
  //     const { detailInfo, formValue, list } = get();

  //     console.log('formValue::', formValue);
  //     console.log('데이터::', data);
  //     console.log('detailInfo::', useOcuRiskTab2FormStore.getState().detailInfo);
  //     // 순회일자
  //     useOcuRiskTab2FormStore.getState().detailInfo.svisitDt = data.svisitDt;
  //     // 대상공정(작업)
  //     useOcuRiskTab2FormStore.getState().detailInfo.svisitProcNm = data.svisitProcNm;
  //     // 유해,위험요인에대한 의견
  //     useOcuRiskTab2FormStore.getState().detailInfo.svisitHzdOpnn = data.svisitHzdOpnn;

  //     // 사진첨부..
  //     useOcuRiskTab2FormStore.getState().detailInfo.svisitFileId = data.svisitFileId;

  //     // set({ detailInfo: useOcuRiskTab2FormStore.getState().detailInfo });

  //     const { setFormValue } = useOcuRiskTab2FormStore.getState();
  //     setFormValue(useOcuRiskTab2FormStore.getState().detailInfo);

  //     // 청취 방문 행
  //     set({ visitRow: rowIndex });
  //   },

  //   // 현장순회 저장
  //   visitSaveStrore: (visitData) => {
  //     const { visitRow, list } = get();

  //     console.log('현장순회 저장 행:', visitRow);
  //     console.log('현장순회 데이터::', visitData);
  //     console.log('list[listenRow]::저장 리스트', list[visitRow]);

  //     let visitGubun = '';
  //     if (list[visitRow].svisitId) {
  //       // 구분
  //       visitGubun = 'U';
  //     } else {
  //       // 구분
  //       visitGubun = 'I';
  //     }

  //     const data = {
  //       // 구분
  //       visitGubun: (list[visitRow].visitGubun = visitGubun),
  //       svisitDt: (list[visitRow].svisitDt = visitData.svisitDt),
  //       svisitProcNm: (list[visitRow].svisitProcNm = visitData.svisitProcNm),
  //       svisitHzdOpnn: (list[visitRow].svisitHzdOpnn = visitData.svisitHzdOpnn),
  //       svisitFileId: (list[visitRow].svisitFileId = visitData.svisitFileId),
  //     };

  //     // 추진팀 저장 list
  //     //originExecDeptlist.push(data);

  //     console.log('저장 후 LIST값==>', list);
  //   },
  clear: () => {
    set({
      ...formBaseState,
      formValue: { ...initFormValue },
      selectedPlace: null,
      selectedItem: null,
      selectedPlaceIndex: -1,
      selectedItemIndex: -1,
    });
  },
}));

export default useOcuRiskTab2FormStore;
