import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { create } from 'zustand';

import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';

import history from '@/utils/history';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  zeroHzdDeptCd: yup.string().required(),
  completGoalMltp: yup.number().required().min(1, '1 이상으로 작성해주세요.'),
  mgntTotGoalDays: yup.number().required().min(1, '1 이상으로 작성해주세요.'),
  mgntStdGoalDays: yup.number().required().min(1, '1 이상으로 작성해주세요.'),
  mgntCurrGoalDays: yup.number().required().min(1, '1 이상으로 작성해주세요.'),
  mgntglStartDt: yup.string().required(),
  mgntglCompletGoalDt: yup.string().required(),
});

const modalYupFormSchema = yup.object({
  // 부서
  zeroHzdDeptCd: yup.string().required(),
  // 달성 목표 배수
  completGoalMltp: yup.string().required().min(1, '1 이상으로 작성해주세요.'),
  // 총 목표일수
  mgntTotGoalDays: yup.string().required().min(1, '1 이상으로 작성해주세요.'),
  // 기준 목표일수
  mgntStdGoalDays: yup.string().required().min(1, '1 이상으로 작성해주세요.'),
  // 현 목표일수
  mgntCurrGoalDays: yup.string().required().min(1, '1 이상으로 작성해주세요.'),
  // 개시일
  mgntglStartDt: yup.string().required(),
  // 달성 목표일
  mgntglCompletGoalDt: yup.string().required(),
  // 배수
  statMltp: yup.string().required().min(1, '1 이상으로 작성해주세요.'),
  // 개시일
  statStartDt: yup.string().required(),
  // 달성 목표일
  statCmpltGoalDt: yup.string().required(),
  // 현 배수 목표일
  currMltpGoalDt: yup.string().required().min(1, '1 이상으로 작성해주세요.'),
  // 총 목표일수
  statTotGoalDays: yup.string().required().min(1, '1 이상으로 작성해주세요.'),
  // 실패일
  statFailDt: yup.string(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  // 부서
  zeroHzdDeptCd: '',
  // 달성 목표 배수
  completGoalMltp: null,
  // 총 목표일수
  mgntTotGoalDays: null,
  // 기준 목표일수
  mgntStdGoalDays: null,
  // 현 목표일수
  mgntCurrGoalDays: null,
  // 개시일
  mgntglStartDt: '',
  // 달성 목표일
  mgntglCompletGoalDt: '',
};

const modalFormInitFormValue = {
  // 부서
  zeroHzdDeptCd: '',
  // 달성 목표 배수
  completGoalMltp: '',
  // 총 목표일수
  mgntTotGoalDays: '',
  // 기준 목표일수
  mgntStdGoalDays: '',
  // 현 목표일수
  mgntCurrGoalDays: '',
  // 개시일
  mgntglStartDt: '',
  // 달성 목표일
  mgntglCompletGoalDt: '',

  // 배수
  statMltp: null,
  // 개시일
  statStartDt: '',
  // 달성 목표일
  statCmpltGoalDt: '',
  // 현 배수 목표일
  currMltpGoalDt: '',
  // 총 목표일수
  statTotGoalDays: null,
  // 실패일
  statFailDt: '',
  // 비고
  statRemark: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/general/zeroHzdGoal',
  baseRoutePath: '/occupation/general/zeroHzdGoal',
  formName: 'useOcuZeroHzdFormStore',
  formValue: {
    ...initFormValue,
  },
};

// modal store
export const useOcuZeroHzdGoalModalFormStore = create<any>((set, get) => ({
  ...formBaseState,

  formName: 'ZeroHzdGoalFormModal',

  formValue: {
    ...modalFormInitFormValue,
  },

  yupFormSchema: modalYupFormSchema,

  ...createFormSliceYup(set, get),

  save: async () => {
    const { validate, formValue } = get();
    const isValid = await validate();
    if (isValid) {
      useOcuZeroHzdGoalFormStore.getState().okModal(formValue);
    }
  },
}));

/* zustand store 생성 */
const useOcuZeroHzdGoalFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  search: async () => {
    const { formDetailId, setList } = get();

    const apiResult = await ApiService.get(`ocu/general/selectZeroHzdList/${formDetailId}`);
    const data = apiResult.data;
    console.log('data====>', data);
    setList(data);

    //   // 첫번째 방법
    //   const sd = get();
    //   sd.changeStateProps();

    //  // 두번째 방법
    //  const { changeStateProps } = get();
  },

  saveCodeDetail: async () => {
    const { list, formDetailId, formApiPath, search, formValue, baseRoutePath, validate } = get();
    const apiList = _.cloneDeep(list);

    const isValid = await validate();

    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const listParam = apiList
            ? apiList.map((info) => {
                info.zeroHzdId = formDetailId;
                return info;
              })
            : [];
          const formParam = formValue;
          const apiParam = {
            list: listParam,
            form: formParam,
          };

          console.log('apiParam===>', apiParam);
          await ApiService.post(`${formApiPath}/${formDetailId}/update`, apiParam);
          // await ApiService.post(`${formApiPath}/${formDetailId}`, apiParam);
          search();
          history.push(`${baseRoutePath}`);
          ToastService.success('저장되었습니다.');
        },
      });
    }
  },

  openFormModal: () => {
    const { detailInfo } = get();
    console.log('이곳에값===>', detailInfo);
    const { setFormValue } = useOcuZeroHzdGoalModalFormStore.getState();
    setFormValue(detailInfo);
    set({ isCodeFormModalOpen: true });
  },

  closeFormModal: () => {
    set({ isCodeFormModalOpen: false });
  },

  okModal: async (formValue) => {
    const { formDetailId, getDetail, search } = get();
    const formApiPath = 'ocu/general/zeroHzdGoal/saveZeroHzdGoalStatus';
    ModalService.confirm({
      body: '저장하시겠습니까?',
      ok: async () => {
        await ApiService['post'](formApiPath, formValue, { disableLoadingBar: true });
        set({ isCodeFormModalOpen: false });
        ToastService.success('저장되었습니다.');
        await getDetail(formDetailId);
        search();
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: {} });
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuZeroHzdGoalFormStore;
