import { create } from 'zustand';
import { produce } from 'immer';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
//import history from '@/utils/history';

/* yup validation */
const yupFormSchema = yup.object({
  // ID
  //advCmitId: yup.number().required(),
  // 부문
  advCmitSectCd: yup.string().required(),
  // 부서
  advCmitDeptCd: yup.string().required(),
  // 실시 연월
  advCmitImplmYm: yup.string().required(),
  // 제목
  advCmitTitle: yup.string().required().max(300, '300자 이내로 작성해주세요.'),
  // 내용
  advCmitRemark: yup.string().required(),
  // 회의록
  prcdnFileId: yup.string(),
  // 회의자료
  meetDocFileId: yup.string(),
  // 보고문서
  reportDocLinkId: yup.string(),
  // 작성자
  //regUserId: yup.string().required(),
  // 작성일자
  //regDttm: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  advCmitId: '',
  // 현재 본부
  advCmitSectCd: '',
  // 현재 부서
  advCmitDeptCd: '',
  advCmitImplmYm: '',
  advCmitTitle: '',
  advCmitRemark: '',
  prcdnFileId: '',
  meetDocFileId: '',
  reportDocLinkId: '',
  // 현재날짜
  regDttm: '',
  // 현재 사용자 ID
  // regUserId: '',
  // 첨부링크 리스트
  linkAttachList: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/general/hsCommittee',
  baseRoutePath: '/occupation/general/hsCommittee',
  formName: 'useOcuHsCommitteeFormStore',
  formValue: {
    ...initFormValue,
  },
};

console.log('formValue==>', initFormData);

/* zustand store 생성 */
const useOcuHsCommitteeFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  getDetail: async (id) => {
    const { formApiPath } = get();
    const response: any = await ApiService.get(`${formApiPath}/${id}`);
    const detailInfo = response.data;
    console.log('detailInfo.dataResult===>', detailInfo.dataResult);
    console.log('detailInfo.linkResult===>', detailInfo.linkResult);
    set({
      detailInfo: { ...detailInfo.dataResult, linkAttachList: detailInfo.linkResult },
      formValue: { ...detailInfo.dataResult, linkAttachList: detailInfo.linkResult },
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  save: async () => {
    const { validate, getApiParam, formType, formValue, formDetailId, formApiPath, cancel } = get();
    const isValid = await validate();

    console.log('저장@@@');

    console.log('봐야하는값===> ', formValue.linkAttachList);

    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          // const apiParam = getApiParam();

          const apiParam = {
            list: formValue.linkAttachList,
            form: getApiParam(),
          };

          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          if (formType === FORM_TYPE_ADD) {
            await ApiService.post(`${formApiPath}`, apiParam);
          } else {
            await ApiService.put(`${formApiPath}/${formDetailId}`, apiParam);
          }
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    }
  },

  okLinkAttachModal: (linkAttachFormValue, linkAttachListLindex) => {
    console.log('이곳에옴@@::', linkAttachFormValue);
    console.log('linkAttachListLindex@@::', linkAttachListLindex);
    set(
      produce((state: any) => {
        if (linkAttachListLindex != -1) {
          const newFormValue = { ...state.formValue };
          newFormValue.linkAttachList[linkAttachListLindex] = linkAttachFormValue;

          state.formValue = newFormValue;
          state.isLinkAttachModalOpen = false;
        } else {
          const newFormValue = { ...state.formValue };
          newFormValue.linkAttachList.push(linkAttachFormValue);

          state.formValue = newFormValue;
          state.isLinkAttachModalOpen = false;
        }
      })
    );
  },

  openLinkAttachModal: (detailInfo = null, linkAttachListLindex = -1) => {
    set({ isLinkAttachModalOpen: true, linkAttachDetailInfo: detailInfo, linkAttachListLindex: linkAttachListLindex });
  },

  closeLinkAttachModal: () => {
    set({ isLinkAttachModalOpen: false });
  },

  removeLinkAttach: (removeIndex) => {
    set(
      produce((state: any) => {
        const newFormValue = { ...state.formValue };
        newFormValue.linkAttachList.splice(removeIndex, 1);
        state.formValue = newFormValue;
      })
    );
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuHsCommitteeFormStore;
