import { create } from 'zustand';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';

import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';
import _ from 'lodash';

import history from '@/utils/history';
import * as yup from 'yup';

// 현재 연도
const currentYear = new Date().getFullYear().toString();

/* yup validation */
const yupFormSchema = yup.object({
  //periodNm: yup.string().required(),
  planYear: yup.string().required(),
  planSectCd: yup.string().required(),
  planCostCenter: yup.string().required(),
  planAcntCd: yup.string().required(),
  planAcntNm: yup.string().required(),
  planItemCd: yup.string().required(),
  planPayTermCd: yup.string().required(),

  planFrMm: yup.string().required(),
  planToMm: yup.string().required(),

  planAmt: yup.number().required(),
  planTotAmt: yup.number().required(),

  planDesc: yup.string().required().max(300, '300자 이내로 작성해주세요.'),
});
/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  planYear: '',
  planSectCd: '',
  planCostCenter: '',
  planAcntCd: '',
  planAcntNm: '',
  planItemCd: '',
  planPayTermCd: '',
  planFrMm: '',
  planToMm: '',
  planAmt: null,
  planTotAmt: null,
  planDesc: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/general/cost',
  baseRoutePath: '/occupation/general/costList',
  formName: 'useOcuCostFormStore',
  formValue: {
    ...initFormValue,
  },
};

const monthList = [
  {
    periodNm: '',
    glDt: '',
  },
];

// const monthList = [
//   {
//     planMonth: '',
//     planMonAmt: '',
//   },
// ];

// modal store
// export const useOcuCostModalFormStore = create<any>((set, get) => ({
//   ...formBaseState,

//   formName: 'CostExecFormModal',

//   formValue: {
//     ...modalFormInitFormValue,
//   },

//   yupFormSchema: modalYupFormSchema,

//   ...createFormSliceYup(set, get),

//   // 실적 저장
//   save: async () => {
//     const { validate, formValue } = get();
//     const isValid = await validate();
//     if (isValid) {
//       useOcuCostFormStore.getState().okModal(formValue);
//     }
//   },
// }));

/* zustand store 생성 */
const useOcuCostFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  list2: [],

  yupFormSchema: yupFormSchema,

  // 월 항목 변경 (구분필드, 주기, 시작월, 종료월, 총 금액, 금액)
  monthListChange: (gubun, payTerm, frMm, toMm, totAmt, planAmt) => {
    const { createMonthList } = get();

    const { setList, list } = get();
    console.log(`월 변경///  구분값: ${gubun} `);
    console.log(`월 변경///  payTerm: ${payTerm} `);
    console.log(`월 변경///  frMm: ${frMm} `);
    console.log(`월 변경///  toMm: ${toMm} `);
    console.log(`월 변경///  totAmt: ${totAmt} `);
    console.log(`월 변경///  totplanAmtAmt: ${planAmt} `);

    // 주기
    const planPayTermCdValue = payTerm;
    // 시작 월
    const planFrMmValue = frMm;
    // 종료 월
    const planToMmValue = toMm;
    // 총 금액
    const planTotAmtValue = totAmt;
    // 금액
    const planAmtValue = planAmt;

    // 주기, 시작 월, 종료 월, 총 금액, 금액이 있는 경우
    if (!payTerm || !frMm || !toMm || !totAmt || !planAmtValue) {
      console.log('없다');
      // 없는 경우
      setList(monthList);
    } else {
      console.log('있다');
      setList(list);

      // 주기
      if (gubun == 'planPayTermCd') {
        createMonthList(gubun, payTerm, frMm, toMm, totAmt, planAmt);
        // 시작 월
      } else if (gubun == 'planFrMm') {
        createMonthList(gubun, payTerm, frMm, toMm, totAmt, planAmt);
        // 종료 월
      } else if (gubun == 'planToMm') {
        createMonthList(gubun, payTerm, frMm, toMm, totAmt, planAmt);
        // 총 금액
      } else if (gubun == 'planTotAmt') {
        createMonthList(gubun, payTerm, frMm, toMm, totAmt, planAmt);
      }
    }

    // setList(monthList);
  },

  // 월 List 생성 함수
  createMonthList: (gubun, payTerm, frMm, toMm, totAmt, planAmt) => {
    const { monthList, setList } = get();

    let listData = [];

    // Annual
    if (payTerm == 'A') {
      // createMonthList(gubun, payTerm, frMm, toMm, totAmt, planAmt);
      listData = [
        {
          planMonth: frMm,
          planMonAmt: totAmt,
        },
      ];
      setList(listData);

      // Semi-Annual
    } else if (payTerm == 'B') {
      for (let i = 0; i < 2; i++) {
        // const month = i == 0 ? frMm : toMm;

        let month = '';

        if (i == 0) {
          month = '01';
        } else if (i == 1) {
          month = '07';
        }

        const data = {
          planMonth: month,
          planMonAmt: planAmt,
        };

        listData.push(data);
      }

      setList(listData);

      // Quarterly
    } else if (payTerm == 'C') {
      let month = '';
      for (let i = 0; i < 4; i++) {
        if (i == 0) {
          month = '01';
        } else if (i == 1) {
          month = '04';
        } else if (i == 2) {
          month = '08';
        } else if (i == 3) {
          month = '12';
        }

        const data = {
          planMonth: month,
          planMonAmt: planAmt,
        };

        listData.push(data);
      }

      setList(listData);

      // Monthly
    } else if (payTerm == 'D') {
      const frMmToMm = toMm - frMm + 1;

      for (let i = 0; i < frMmToMm; i++) {
        const toMmSum = Number(frMm) + i;
        const data = {
          planMonth: String(toMmSum).padStart(2, '0'),
          planMonAmt: planAmt,
        };

        listData.push(data);
      }

      console.log('listData===>', listData);

      setList(listData);
    }
  },

  // 계획 저장
  save: async () => {
    const { validate, list, getApiParam, formType, formValue, formDetailId, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      // const apiParam = getApiParam();
      const formParam = formValue;

      const apiParam = {
        form: formParam,
        list: list,
      };

      console.log('보내는값-===>', apiParam);

      // 중복 체크

      // const apiResult: any =

      const dupChk: any = await ApiService.post(`ocu/general/cost/selectCostPlanDupChk`, apiParam);

      console.log('값==>', dupChk.ItemCount);

      if (dupChk.ItemCount == '0') {
        ModalService.confirm({
          body: '저장하시겠습니까?',
          ok: async () => {
            const apiParam = {
              form: formParam,
              list: list,
            };

            console.log('apiParam===>', apiParam);

            //const apiParam = getApiParam();
            console.log(`apiParam : ${JSON.stringify(apiParam)}`);
            if (formType === FORM_TYPE_ADD) {
              // 입력
              await ApiService.post(`${formApiPath}/insertCost`, apiParam);
            } else {
              // 수정
              await ApiService.post(`${formApiPath}/saveCost`, apiParam);
            }
            await set({ isDirty: false });
            ToastService.success('저장되었습니다.');
            await cancel();
          },
        });
      } else {
        alert('해당연월에 이미 등록된 부서별 계정 및 항목입니다.');
      }
    }
  },

  // // from 상세 조회
  getDetail: async (planYearId) => {
    const { setList } = get();

    // const apiParam = {
    //   planYear,
    //   sectCd,
    //   searchRespCenter,
    //   itemCd,
    //   searchAcntCd,
    // };

    const response: any = await ApiService.get(`ocu/general/costDetail/${planYearId}`);
    const detailInfo = response.data;

    // console.log("조호")

    // planCostYearInfo

    // planCostMonthInfo

    set({
      detailInfo: detailInfo.planCostYearInfo,
      formValue: detailInfo.planCostYearInfo,
      formDetailId: planYearId,
      formType: FORM_TYPE_UPDATE,
    });

    setList(detailInfo.planCostMonthInfo);
  },

  // goFormPage: () => {
  //   const { baseRoutePath, formValue } = get();

  //   const queryParams = CommonUtil.objectToQueryString({
  //     planYear: formValue.planYear,
  //     sectCd: formValue.sectCd,
  //     searchRespCenter: formValue.respCenter,
  //     itemCd: formValue.itemCd,
  //     acntCd: formValue.acntCd,
  //   });

  //   history.push(`${baseRoutePath}/edit/view${queryParams}`);
  // },

  remove: async () => {
    const { formDetailId, formApiPath, baseRoutePath, getApiParam } = get();
    ModalService.confirm({
      body: '삭제하시겠습니까?',
      ok: async () => {
        const apiParam = getApiParam();
        // console.log('${formApiPath}===>', `${formApiPath}`);
        //console.log('apiParam===>', apiParam);
        //console.log(`apiParam : ${JSON.stringify(apiParam)}`);
        await ApiService.post(`${formApiPath}/delete`, apiParam);
        //await ApiService.post(`${formApiPath}`, apiParam);
        ModalService.alert({
          body: '삭제되었습니다.',
          ok: async () => {
            history.replace(`${baseRoutePath}`);
          },
        });
      },
    });
  },

  // openFormModal: (saveGubun, data) => {
  //   // 등록
  //   if (saveGubun === 'I') {
  //     const { detailInfo } = get();
  //     detailInfo.saveGubun = saveGubun;
  //     detailInfo.execClsCd = 'B';
  //     const { setFormValue } = useOcuCostModalFormStore.getState();
  //     setFormValue(detailInfo);
  //     set({ isCodeFormModalOpen: true });
  //     // 수정
  //   } else if (saveGubun === 'U') {
  //     const { detailInfo } = get();
  //     detailInfo.saveGubun = saveGubun;
  //     const { setFormValue } = useOcuCostModalFormStore.getState();

  //     // 년도
  //     data.planYear = data.execYear;
  //     // Department
  //     //data.respCenter = data.respCenter;
  //     // Description
  //     data.execLineDesc = data.lineDesc;
  //     // saveGubun
  //     data.saveGubun = saveGubun;

  //     setFormValue(data);
  //     set({ isCodeFormModalOpen: true });
  //   }
  // },

  // closeFormModal: () => {
  //   set({ isCodeFormModalOpen: false });
  // },

  // okModal: async (formValue) => {
  //   const { formDetailId, getDetail, search } = get();

  //   const formApiPath = 'ocu/general/cost/saveCostExec';
  //   ModalService.confirm({
  //     body: '저장하시겠습니까?',
  //     ok: async () => {
  //       await ApiService['post'](formApiPath, formValue, { disableLoadingBar: true });
  //       set({ isCodeFormModalOpen: false });
  //       ToastService.success('저장되었습니다.');
  //       await getDetail(formValue.planYear, formValue.sectCd, formValue.respCenter, formValue.itemCd, formValue.acntCd);
  //       search();
  //     },
  //   });
  // },

  gridChangeStatus: (costData, event) => {
    const { list, list2 } = get();
    // 삭제 list
    list2.push(costData.data);
    console.log('list2@@::', list2);

    //set({ list2: { ...list } });
    //set({ list2: list });
    //list[costData.rowIndex].status = 'D';
  },

  // 산업안전보건 관리비 계획, 실적 저장
  costSave: async () => {
    const { list, list2, formDetailId, formApiPath, search, formValue, baseRoutePath, validate } = get();
    const apiList = _.cloneDeep(list2);

    const isValid = await validate();

    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const formParam = formValue;
          const prcPlanAmt = formParam.mainPlanAmt.toString();
          const prcTotAmt = formParam.mainTotAmt.toString();

          formParam.mainPlanAmt = prcPlanAmt.replace(/,/g, '');
          formParam.mainTotAmt = prcTotAmt.replace(/,/g, '');

          const apiParam = {
            //list: listParam,
            list: apiList,
            form: formParam,
          };

          await ApiService.post(`${formApiPath}/saveCost`, apiParam);
          search();
          history.push(`${baseRoutePath}`);
          ToastService.success('저장되었습니다.');
        },
      });
    }
  },

  clear: () => {
    //    set({ ...listBaseState, searchParam: {} });
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuCostFormStore;
