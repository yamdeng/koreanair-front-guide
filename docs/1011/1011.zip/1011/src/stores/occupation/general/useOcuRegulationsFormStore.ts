import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import { FORM_TYPE_UPDATE } from '@/config/CommonConstant';

/* yup validation */
const yupFormSchema = yup.object({
  // 부문
  sectCd: yup.string().required(),
  // 등록자
  //regUserId: yup.string().required(),
  // 구분
  formCls: yup.string().required(),
  // 개정 번호
  revisionNo: yup.string().required(),
  // 제정 일자
  enactedDt: yup.string().required(),
  // 개정 일자 (추후 오늘 날짜 넣기)
  revisionDt: yup.string(),
  // 첨부 링크 ID
  linkId: yup.string(),
  // 제목
  revisionTitle: yup.string().required().max(300, '300자 이내로 작성해주세요.'),
  // 개정내용
  majorRevisionCn: yup.string().required(),
  // 첨부 파일 ID
  fileId: yup.string(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  sectCd: 'DM',
  formCls: '',
  revisionNo: '',
  enactedDt: '',
  revisionDt: '',
  revisionTitle: '',
  majorRevisionCn: '',
  fileId: '',
  linkId: '',
  // regUserId: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  searchRevisionNo: null,

  formApiPath: 'ocu/general/regulations',
  baseRoutePath: '/occupation/general/regulations',
  formName: 'useOcuRegulationsFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuRegulationsFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  // 규정/지침/매뉴얼/양식 조회
  getDetail: async (id) => {
    const { formApiPath } = get();
    const response: any = await ApiService.get(`${formApiPath}/${id}`);
    const detailInfo = response.data;
    set({
      detailInfo: detailInfo,
      formValue: detailInfo,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
      searchRevisionNo: detailInfo.revisionNo,
    });
  },

  // 개정번호 변경 시 조회
  getDetailNo: async (id, no) => {
    const { formApiPath, getApiParam, formValue, setFormValue, getFormValue } = get();

    console.log('처음 formValue', formValue);

    setFormValue({ ...formValue, revisionNo: no });

    console.log('두번쨰 formValue', getFormValue);
    const apiParam = getApiParam();
    console.log(`apiParam : ${JSON.stringify(apiParam)}`);

    const response: any = await ApiService.post(`ocu/general/getRegulationInfoNo`, apiParam);

    // await ApiService.post(`${formApiPath}`, apiParam);

    const detailInfo = response.data;
    set({
      detailInfo: detailInfo,
      formValue: detailInfo,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
      searchRevisionNo: detailInfo.revisionNo,
    });
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuRegulationsFormStore;
