import { create } from 'zustand';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';

import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';
import _ from 'lodash';
import LoadingBar from '@/utils/LoadingBar';
import history from '@/utils/history';
import * as yup from 'yup';

const currentYear = new Date().getFullYear().toString();

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 실시 년도
  costYear: currentYear,
  // 부문
  sectCd: 'DC',
  // Cost Center
  costCenter: 'CJUKK',
  // Accout
  acntCd: '',
};

const modalFormInitFormValue = {
  periodNm: '',
  sectCd: 'DM',
  deptCd: 'SELDM',
  glDt: '',
  currencyCd: '',
  respCenter: '',
  costCenter: '',
  costCenterNm: '',
  acntCd: '',
  acntNm: '',
  drAmt: '',
  crAmt: '',
  lineDesc: '',
  invoiceNo: '',
  vendorNm: '',
  execClsCd: 'B',
  saveGubun: '',
};

const modalYupFormSchema = yup.object({
  //periodNm: yup.string().required(),
  glDt: yup.string().required(),
  //currencyCd: yup.string().required(),
  //respCenter: yup.string().required(),
  costCenter: yup.string().required(),
  acntCd: yup.string().required(),
  acntNm: yup.string().required(),
  //drAmt: yup.number().required(),
  drAmt: yup.number().required().min(-99999999999),
  //crAmt: yup.string().required(),
  //execLineDesc: yup.string().required(),
  //invoiceNo: yup.string().required(),
  //vendorNm: yup.string().required(),
  //execClsCd: yup.string().required(),
});

// modal store
export const useOcuCostModalFormStore = create<any>((set, get) => ({
  ...formBaseState,

  formName: 'CostExecFormModal',

  formValue: {
    ...modalFormInitFormValue,
  },

  yupFormSchema: modalYupFormSchema,

  ...createFormSliceYup(set, get),

  // 실적 저장
  save: async () => {
    const { validate, formValue } = get();
    const isValid = await validate();
    if (isValid) {
      useOcuCostPerformanceListStore.getState().okModal(formValue);
    }
  },

  // 실적 저장
  execDelete: async () => {
    const { validate, formValue } = get();
    const isValid = await validate();
    if (isValid) {
      useOcuCostPerformanceListStore.getState().deleteModal(formValue);
    }
  },
}));

// 최상위 store
export const useOcuCostPerformanceListStore = create<any>((set, get) => ({
  // 조회
  search: () => {
    //LoadingBar.show();

    const { searchParam } = get();

    // 년도 필수 체크
    if (!searchParam.costYear) {
      alert('검색조건 해당연도는 필수 입니다.');
      return false;
    } else {
      console.log('searchParam===>', searchParam);
      // 부문
      stateAcntTotStore.getState().search(searchParam);
    }
  },

  getSearchParam: () => {
    // const { grd, hazardName, getPageParam } = get();
    // const baseSearchParam = useHzrTopRiskListStore.getState().getSearchParam();
    // const apiParam = { ...baseSearchParam, ...getPageParam() };
    // apiParam.grd = grd;
    // apiParam.hazardName = hazardName;
    // return apiParam;
  },

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    // 실시 년도
    costYear: currentYear,
    // 부문
    sectCd: 'DC',
    // Cost Center
    costCenter: 'CJUKK',
    // Accout
    acntCd: '',
  },

  changeSearchInput: (inputName, inputValue) => {
    const { searchParam } = get();
    searchParam[inputName] = inputValue;
    set({ searchParam: searchParam });
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  openFormModal: (saveGubun, data) => {
    console.log('save구분값==>', saveGubun);
    // 등록
    if (saveGubun === 'I') {
      const { detailInfo } = get();
      const { setFormValue } = useOcuCostModalFormStore.getState();

      console.log('detailInfo=====>', detailInfo);

      setFormValue(modalFormInitFormValue);
      set({ isCodeFormModalOpen: true });
      // 수정
    } else if (saveGubun === 'U') {
      const { formValue } = useOcuCostModalFormStore.getState();
      // detailInfo.saveGubun = saveGubun;
      const { setFormValue } = useOcuCostModalFormStore.getState();

      // 년도
      // data.planYear = data.execYear;
      // // Department
      // //data.respCenter = data.respCenter;
      // // Description
      // data.execLineDesc = data.lineDesc;
      // // saveGubun
      // data.saveGubun = saveGubun;

      console.log('data===>', data);

      setFormValue(data);

      set({ isCodeFormModalOpen: true });
    }
  },

  closeFormModal: () => {
    set({ isCodeFormModalOpen: false });
  },

  okModal: async (formValue) => {
    const { formDetailId, getDetail, search } = get();

    const formApiPath = 'ocu/general/cost/saveCostExec';
    ModalService.confirm({
      body: '저장하시겠습니까?',
      ok: async () => {
        await ApiService['post'](formApiPath, formValue, { disableLoadingBar: true });
        set({ isCodeFormModalOpen: false });
        ToastService.success('저장되었습니다.');
        // await getDetail(formValue.planYear, formValue.sectCd, formValue.respCenter, formValue.itemCd, formValue.acntCd);
        search();
      },
    });
  },

  deleteModal: async (formValue) => {
    const { formDetailId, getDetail, search } = get();

    const formApiPath = 'ocu/general/cost/deleteCostExec';
    ModalService.confirm({
      body: '삭제하시겠습니까?',
      ok: async () => {
        await ApiService['post'](formApiPath, formValue, { disableLoadingBar: true });
        set({ isCodeFormModalOpen: false });
        ToastService.success('삭제되었습니다.');
        // await getDetail(formValue.planYear, formValue.sectCd, formValue.respCenter, formValue.itemCd, formValue.acntCd);
        search();
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

// 계정별 실적비 List
export const stateAcntTotStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  selectedUserInfo: {},

  search: async (searchData, gubun) => {
    console.log('조회@@@@@@@@@@@@@@@@@');

    const { listApiPath, getSearchParam, setTotalCount, listApiMethod, disablePaging, searchParam } = get();
    const applyListApiMethod = listApiMethod || 'get';

    const apiResult: any = await ApiService[applyListApiMethod](`ocu/general/cost/selectAcntTotList`, searchData, {
      disableLoadingBar: true,
    });

    console.log('disablePaging==>', disablePaging);
    //console.log('data==>', data.list);
    // 부문별 조회
    const data = apiResult.data;
    console.log('data==>', data);
    console.log('datalist==>', data.list);
    const list = disablePaging ? data : data.list;
    const totalCount = disablePaging && list ? list.length : data.total;

    let selectedUserInfo = {};

    console.log('list===>', list);
    console.log('gubun===>', gubun);

    // 행 클릭시
    if (gubun == 'C') {
      // 사용자 첫번째행
      if (list && list.length) {
        console.log('첫번쨰행:::', list[0].planSectCd);

        selectedUserInfo = {
          // 년도
          costYear: list[0].costYear,
          // 부문
          sectCd: list[0].sectCd,
          // Resp Center
          // planCostCenter: list[0].planCostCenter,
          // // Account
          // acntCd: list[0].acntCd,
        };
      }
      // 조회 버튼 클릭시
    } else {
      if (list && list.length) {
        selectedUserInfo = {
          // 년도
          costYear: list[0].costYear,
          // 부문
          sectCd: list[0].sectCd,
          // Resp Center
          deptGubun: list[0].deptGubun,
          // Account
          acntCd: list[0].acntCd,
        };
      }
    }
    // 아22

    console.log('selectedUserInfo==>', selectedUserInfo);

    setTotalCount(totalCount);
    set({ list: list || [] });

    stateAcntListStore.getState().search(selectedUserInfo, gubun);

    //stateExecStore.getState().search();
  },

  // getSearchParam: () => {
  //   console.log('서치파람');

  //   const { grd, hazardName, getPageParam } = get();
  //   const baseSearchParam = useOcuCostListStore.getState().getSearchParam();
  //   const apiParam = { ...baseSearchParam, ...getPageParam() };
  //   apiParam.grd = grd;
  //   apiParam.hazardName = hazardName;
  //   return apiParam;
  // },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

// 계정 항목 List
export const stateAcntListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'ocu/general/cost/costState',
  grd: 'grd2',
  hazardName: '',

  search: async (searchData, gubun) => {
    const { listApiPath, getSearchParam, setTotalCount, listApiMethod, disablePaging } = get();
    const applyListApiMethod = listApiMethod || 'get';

    const apiParam = getSearchParam();

    console.log('2번째 apiParam@@$$===>', apiParam);
    console.log('2번째 서치데이터값@@$$===>', searchData);

    const apiResult: any = await ApiService[applyListApiMethod](`ocu/general/cost/selectAcntList`, searchData, {
      disableLoadingBar: true,
    });

    console.log('Resp center별 apiResult===>', apiResult);

    // 부문별 조회
    const data = apiResult.data;
    const list = disablePaging ? data : data.list;
    const totalCount = disablePaging && list ? list.length : data.total;

    let selectedUserInfo = {};

    if (list && list.length) {
      selectedUserInfo = {
        // 년도
        costYear: list[0].costYear,
        // 부문
        sectCd: list[0].sectCd,
        // Cost Center
        deptGubun: list[0].deptGubun,
        // Account
        //acntCd: list[0].acntCd,
      };
    }

    // // 행 클릭시
    // if (gubun == 'C') {
    //   // 사용자 첫번째행
    //   if (list && list.length) {
    //     selectedUserInfo = {
    //       // 년도
    //       planYear: list[0].planYear,
    //       // 부문
    //       sectCd: list[0].sectCd,
    //       // Resp Center
    //       respCenter: list[0].respCenter,
    //       // Account
    //       acntCd: list[0].acntCd,
    //     };
    //   }
    //   // 조회 버튼 클릭시
    // } else {
    //   console.log('온다');

    //   selectedUserInfo = {
    //     // 년도
    //     planYear: list[0].planYear,
    //     // 부문
    //     sectCd: list[0].sectCd,
    //     // Resp Center
    //     respCenter: list[0].respCenter,
    //     // Account
    //     acntCd: list[0].acntCd,
    //   };
    // }

    console.log('selectedUserInfo==>', selectedUserInfo);

    setTotalCount(totalCount);
    set({ list: list || [] });

    // 실적 조회
    //stateExecStore.getState().search(selectedUserInfo, gubun);
  },

  // changeSummaryRowInfo: (value) => {
  //   const { enterSearch } = get();
  //   set({ hazardName: value });
  //   enterSearch();
  // },

  // getSearchParam: () => {
  //   const { grd, hazardName, getPageParam } = get();
  //   const baseSearchParam = useOcuCostListStore.getState().getSearchParam();
  //   const apiParam = { ...baseSearchParam, ...getPageParam() };
  //   apiParam.grd = grd;
  //   apiParam.hazardName = hazardName;
  //   return apiParam;
  // },
}));
