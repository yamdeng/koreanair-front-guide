import { create } from 'zustand';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';

import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';
import _ from 'lodash';
import LoadingBar from '@/utils/LoadingBar';
import history from '@/utils/history';
import * as yup from 'yup';

const currentYear = new Date().getFullYear().toString();

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 실시 년도
  planYear: currentYear,
  // 부문
  sectCd: '',
  // Resp Center
  respCenter: '',
  // Accout
  acntCd: '',
};

// 최상위 store
export const useOcuCostListStore = create<any>((set, get) => ({
  // 조회
  search: (gubun) => {
    //LoadingBar.show();

    const { searchParam } = get();

    // 년도 필수 체크
    if (!searchParam.planYear) {
      alert('검색조건 해당연도는 필수 입니다.');
      return false;
    } else {
      // 부문
      stateSectStore.getState().search(searchParam, gubun);
    }
  },

  getSearchParam: () => {
    // const { grd, hazardName, getPageParam } = get();
    // const baseSearchParam = useHzrTopRiskListStore.getState().getSearchParam();
    // const apiParam = { ...baseSearchParam, ...getPageParam() };
    // apiParam.grd = grd;
    // apiParam.hazardName = hazardName;
    // return apiParam;
  },

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    // 실시 년도
    planYear: currentYear,
    // 부문
    sectCd: '',
    // Resp Center
    respCenter: '',
    // Accout
    acntCd: '',
  },

  changeSearchInput: (inputName, inputValue) => {
    const { searchParam } = get();
    searchParam[inputName] = inputValue;
    set({ searchParam: searchParam });
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

// 부문별 List
export const stateSectStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  selectedUserInfo: {},

  search: async (searchData, gubun) => {
    const { listApiPath, getSearchParam, setTotalCount, listApiMethod, disablePaging, searchParam } = get();
    const applyListApiMethod = listApiMethod || 'get';

    const apiResult: any = await ApiService[applyListApiMethod](`ocu/general/cost/cosStateSectList`, searchData, {
      disableLoadingBar: true,
    });

    console.log('disablePaging==>', disablePaging);
    //console.log('data==>', data.list);
    // 부문별 조회
    const data = apiResult.data;
    console.log('data==>', data);
    console.log('datalist==>', data.list);
    const list = disablePaging ? data : data.list;
    const totalCount = disablePaging && list ? list.length : data.total;

    let selectedUserInfo = {};

    console.log('list===>', list);
    console.log('gubun===>', gubun);

    // 행 클릭시
    if (gubun == 'C') {
      // 사용자 첫번째행
      if (list && list.length) {
        console.log('첫번쨰행:::', list[0].planSectCd);

        selectedUserInfo = {
          // 년도
          planYear: list[0].planYear,
          // 부문
          planSectCd: list[0].planSectCd,
          // Resp Center
          // planCostCenter: list[0].planCostCenter,
          // // Account
          // acntCd: list[0].acntCd,
        };
      }
      // 조회 버튼 클릭시
    } else {
      if (list && list.length) {
        selectedUserInfo = {
          // 년도
          planYear: list[0].planYear,
          // 부문
          sectCd: list[0].sectCd,
          // Resp Center
          respCenter: searchData.respCenter,
          // Account
          acntCd: searchData.acntCd,
        };
      }
    }

    console.log('selectedUserInfo==>', selectedUserInfo);

    setTotalCount(totalCount);
    set({ list: list || [] });

    stateRespCenterStore.getState().search(selectedUserInfo, gubun);

    //stateExecStore.getState().search();
  },

  // getSearchParam: () => {
  //   console.log('서치파람');

  //   const { grd, hazardName, getPageParam } = get();
  //   const baseSearchParam = useOcuCostListStore.getState().getSearchParam();
  //   const apiParam = { ...baseSearchParam, ...getPageParam() };
  //   apiParam.grd = grd;
  //   apiParam.hazardName = hazardName;
  //   return apiParam;
  // },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

// Cost Center별 List
export const stateRespCenterStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'ocu/general/cost/costState',
  grd: 'grd2',
  hazardName: '',

  search: async (searchData, gubun) => {
    const { listApiPath, getSearchParam, setTotalCount, listApiMethod, disablePaging } = get();
    const applyListApiMethod = listApiMethod || 'get';

    const apiParam = getSearchParam();

    console.log('2번째 apiParam@@$$===>', apiParam);
    console.log('2번째 서치데이터값@@$$===>', searchData);

    const apiResult: any = await ApiService[applyListApiMethod](
      `ocu/general/cost/costStateRespCenterList`,
      searchData,
      {
        disableLoadingBar: true,
      }
    );

    console.log('Resp center별 apiResult===>', apiResult);

    // 부문별 조회
    const data = apiResult.data;
    const list = disablePaging ? data : data.list;
    const totalCount = disablePaging && list ? list.length : data.total;

    let selectedUserInfo = {};

    if (list && list.length) {
      selectedUserInfo = {
        // 년도
        planYear: list[0].planYear,
        // 부문
        planSectCd: list[0].planSectCd,
        // Cost Center
        costCenter: list[0].costCenter,
        // Account
        //acntCd: list[0].acntCd,
      };
    }

    // // 행 클릭시
    // if (gubun == 'C') {
    //   // 사용자 첫번째행
    //   if (list && list.length) {
    //     selectedUserInfo = {
    //       // 년도
    //       planYear: list[0].planYear,
    //       // 부문
    //       sectCd: list[0].sectCd,
    //       // Resp Center
    //       respCenter: list[0].respCenter,
    //       // Account
    //       acntCd: list[0].acntCd,
    //     };
    //   }
    //   // 조회 버튼 클릭시
    // } else {
    //   console.log('온다');

    //   selectedUserInfo = {
    //     // 년도
    //     planYear: list[0].planYear,
    //     // 부문
    //     sectCd: list[0].sectCd,
    //     // Resp Center
    //     respCenter: list[0].respCenter,
    //     // Account
    //     acntCd: list[0].acntCd,
    //   };
    // }

    console.log('selectedUserInfo==>', selectedUserInfo);

    setTotalCount(totalCount);
    set({ list: list || [] });

    // 실적 조회
    stateExecStore.getState().search(selectedUserInfo, gubun);
  },

  // changeSummaryRowInfo: (value) => {
  //   const { enterSearch } = get();
  //   set({ hazardName: value });
  //   enterSearch();
  // },

  // getSearchParam: () => {
  //   const { grd, hazardName, getPageParam } = get();
  //   const baseSearchParam = useOcuCostListStore.getState().getSearchParam();
  //   const apiParam = { ...baseSearchParam, ...getPageParam() };
  //   apiParam.grd = grd;
  //   apiParam.hazardName = hazardName;
  //   return apiParam;
  // },
}));

// 실적 List
export const stateExecStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  listApiPath: 'ocu/general/cost/costState',
  grd: 'grd3',
  hazardName: '',

  search: async (searchData, gubun) => {
    const { listApiPath, getSearchParam, setTotalCount, listApiMethod, disablePaging } = get();
    const applyListApiMethod = listApiMethod || 'get';

    const apiParam = getSearchParam();

    console.log('3번쨰 apiParam@@===>', apiParam);
    console.log('3번쨰 서치데이터값@@===>', searchData);

    if (searchData.acntCd) {
      console.log('널아님');
      const apiResult: any = await ApiService[applyListApiMethod](`ocu/general/cost/costStateExecList`, searchData, {
        disableLoadingBar: true,
      });

      console.log('실적별 apiResult===>', apiResult);

      // 부문별 조회
      const data = apiResult.data;
      const list = disablePaging ? data : data.list;
      const totalCount = disablePaging && list ? list.length : data.total;
      setTotalCount(totalCount);
      set({ list: list || [] });
    } else {
      setTotalCount(0);
      set({ list: [] });
    }
    // const apiResult: any = await ApiService[applyListApiMethod](`ocu/general/cost/costStateExecList`, searchData, {
    //   disableLoadingBar: true,
    // });

    // console.log('실적별 apiResult===>', apiResult);

    // // 부문별 조회
    // const data = apiResult.data;
    // const list = disablePaging ? data : data.list;
    // const totalCount = disablePaging && list ? list.length : data.total;
    // setTotalCount(totalCount);
    // set({ list: list || [] });

    // if (!list && list.length) {
    //   LoadingBar.hide();
    // }
  },

  // changeSummaryRowInfo: (value) => {
  //   const { enterSearch } = get();
  //   set({ hazardName: value });
  //   enterSearch();
  // },

  // getSearchParam: () => {
  //   const { grd, hazardName, getPageParam } = get();
  //   const baseSearchParam = useOcuCostListStore.getState().getSearchParam();
  //   const apiParam = { ...baseSearchParam, ...getPageParam() };
  //   apiParam.grd = grd;
  //   apiParam.hazardName = hazardName;
  //   return apiParam;
  // },
}));
