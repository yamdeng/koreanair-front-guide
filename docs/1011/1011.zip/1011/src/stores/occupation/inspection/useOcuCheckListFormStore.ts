import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import * as yup from 'yup';
import _ from 'lodash';

/* yup validation */
const yupFormSchema = yup.object({
  useSectCd: yup.string().required(),
  useDeptCd: yup.string().required(),
  chkListTitle: yup.string().required(),
  placeList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        prtnrNm: yup.string().required(),
        bizPlaceNm: yup.string().required(),
        useSectNm: yup.string().required(),
      })
    ),
  itemList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        chkClsNm: yup.string().required(),
        chkItemNm: yup.string().required(),
      })
    ),
});

/* searchParam 초기화 */
const initSearchParam = {
  sectCd: '',
  deptCd: '',
  chkListTitle: '',
  fromRegDttm: '',
  toRegDttm: '',
};

/* formValue 초기값 */
const initFormValue = {
  _status: 'A',
  useSectCd: '',
  useDeptCd: '',
  chkListClsCd: 'A', //점검표_구분_코드
  chkListTitle: '', //점검표_제목
  regDttm: '', //등록_일시
  regUserId: '', //등록자_ID
  updDttm: '', //수정_일시
  updUserId: '', //수정자_ID
  placeList: [],
  itemList: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/inspection/checklist',
  baseRoutePath: '/occupation/inspection/checklist',
  formName: 'OcuCheckListForm',
  formValue: {
    ...initFormValue,
  },

  selectedPlaceIndex: -1,
  selectedItemIndex: -1,
};

/* zustand store 생성 */
const useOcuCheckListFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...createCommonDataset(set, get),

  ...initFormData,

  searchParam: {
    ...initSearchParam,
  },

  yupFormSchema: yupFormSchema,

  initSearchInput: () => {
    set({
      searchParam: {
        useSectCd: '',
        useDeptCd: '',
        chkListTitle: '',
        fromRegDttm: '',
        toRegDttm: '',
      },
    });
  },

  setFormStatus: (status: any) => {
    const { CommonDS } = get();
    return CommonDS.setStatus('formValue', null, status);
  },

  setFormValue: (field: string, value: any) => {
    const { CommonDS } = get();
    return CommonDS.setColumn('formValue', null, field, value);
  },

  getPlacePath: () => {
    return `formValue.placeList`;
  },

  getItemPath: () => {
    return `formValue.itemList`;
  },

  openItemModal: () => {
    set({ isItemFormModalOpen: true });
  },

  closeItemModal: () => {
    set({ isItemFormModalOpen: false });
  },

  setSelectedItemIndex: (index: number) => {
    set({ selectedItemIndex: index });
  },

  openPartnerModal: () => {
    set({ isPartnerModalOpen: true });
  },

  closePartnerModal: () => {
    set({ isPartnerModalOpen: false });
  },

  selectPartnerModal: (params) => {
    const { CommonDS, getPlacePath } = get();
    const newData = {
      prtnrId: params.prtnrId,
      prtnrNm: params.prtnrNm,
      bizPlaceId: params.bizPlaceId,
      bizPlaceNm: params.bizPlaceNm,
      useSectNm: params.useSectNm,
    };
    CommonDS.addRow(getPlacePath(), newData);
  },

  // 오류 메시지 가져오기
  getPlaceError: (field: string) => {
    const { errors, selectedPlaceIndex } = get();
    const path = `placeList[${selectedPlaceIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getPlaceColumn: (field) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.getColumn(getPlacePath(), selectedPlaceIndex, field);
  },

  setPlaceColumn: (field: string, value: any) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.setColumn(getPlacePath(), selectedPlaceIndex, field, value);
  },

  addPlaceRow: () => {
    const { CommonDS, getPlacePath } = get();
    return CommonDS.addRow(getPlacePath());
  },

  delPlaceRow: (selectedPlaceIndex: number) => {
    const { CommonDS, getPlacePath } = get();
    return CommonDS.deleteRow(getPlacePath(), selectedPlaceIndex);
  },

  getPlaceList: () => {
    const { CommonDS, getPlacePath } = get();
    return CommonDS.getList(getPlacePath());
  },

  getItemError: (field: string) => {
    const { errors, selectedItemIndex } = get();
    const path = `itemList[${selectedItemIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getItemColumn: (field) => {
    const { CommonDS, getItemPath, selectedItemIndex } = get();
    return CommonDS.getColumn(getItemPath(), selectedItemIndex, field);
  },

  setItemColumn: (field: string, value: any) => {
    const { CommonDS, getItemPath, selectedItemIndex } = get();
    return CommonDS.setColumn(getItemPath(), selectedItemIndex, field, value);
  },

  addItemRow: () => {
    const { CommonDS, getItemPath } = get();
    return CommonDS.addRow(getItemPath());
  },

  delItemRow: (selectedItemIndex: number) => {
    const { CommonDS, getItemPath } = get();
    return CommonDS.deleteRow(getItemPath(), selectedItemIndex);
  },

  getItemList: () => {
    const { CommonDS, getItemPath } = get();
    return CommonDS.getList(getItemPath());
  },

  saveAll: async () => {
    const { validate, getApiParam, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          await ApiService.post(`${formApiPath}`, apiParam);
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    } else {
      const { CommonDS, errors } = get();
      CommonDS.setValidateList('formValue', errors);
    }
  },

  // form 전체 초기화
  clear: () => {
    set({
      ...formBaseState,
      formValue: { ...initFormValue },
      selectedPlace: null,
      selectedItem: null,
      selectedPlaceIndex: -1,
      selectedItemIndex: -1,
    });
  },
}));

export default useOcuCheckListFormStore;
