import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';
import _ from 'lodash';

/* yup validation */
const yupFormSchema = yup.object({
  chkCls: yup.string().required(),
  chkTitle: yup.string().required(),
  chkYear: yup.string().required(),
  chkPeriodCd: yup.string().required(),
  chkRegDt: yup.string().required(),
  chkEmpno: yup.string().required(),
  remark: yup.string(),
  pohtoId1: yup.number().nullable(),
  pohtoId2: yup.number().nullable(),
  fileId: yup.number().nullable(),
  targetList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        bizPlaceId: yup.string().required(),
        prtnrId: yup.string().required(),
        regUserDept: yup.string().required(),
        chkDt: yup.string().required(), //점검_일자
        chkEmpno: yup.string().required(), //점검자_사번
        remark: yup.string().required(), //비고
        contentList: yup
          .array()
          .min(1, '목록은 최소 하나여야 합니다.')
          .of(
            yup.object().shape({
              chkClsCd: yup.string().required(),
              chkItemNm: yup.string().required(),
              chkResultCd: yup.string().required(),
              chkScls: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && !val ? false : true)),
              chkContent: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && !val ? false : true)),
              chkRelLaw: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && !val ? false : true)),
              rightActionYn: yup.string().required(),
              actionContent: yup.string().test((val, obj) => (obj.parent.rightActionYn === 'Y' && !val ? false : true)),
              actionDeptCd: yup.string().test((val, obj) => (obj.parent.rightActionYn === 'Y' && !val ? false : true)),
              aprvDeptCd: yup.string().test((val, obj) => (obj.parent.rightActionYn === 'Y' && !val ? false : true)),
            })
          ),
      })
    ),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  chkCls: '',
  chkTitle: '',
  chkYear: '',
  chkPeriodCd: '',
  chkRegDt: '',
  chkEmpno: '',
  remark: '',
  pohtoId1: null,
  pohtoId2: null,
  fileId: null,
  regDttm: '',
  regUserId: '',
  targetList: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/inspection/periodic',
  baseRoutePath: '/occupation/inspection/joint',
  formName: 'OcuCheckInfoForm',
  formValue: {
    ...initFormValue,
  },

  selectedContentIndex: -1,
};

/* zustand store 생성 */
const useOcuCheckInfoFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...createCommonDataset(set, get),
  ...initFormData,

  yupFormSchema: yupFormSchema,

  getContentPath: () => {
    return `formValue.contentList`;
  },

  getContentError: (field: string) => {
    const { errors, getContentPath, selectedContentIndex } = get();
    const path = getContentPath`[${selectedContentIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getContentList: () => {
    const { CommonDS, getContentPath } = get();

    return CommonDS.getList(getContentPath());
  },

  setSelectedContentIndex: (index: number) => {
    set({ selectedContentIndex: index });
  },

  getContentColumn: (field) => {
    const { CommonDS, getContentPath, selectedContentIndex } = get();
    return CommonDS.getColumn(getContentPath(), selectedContentIndex, field);
  },

  setContentColumn: (field: string, value: any) => {
    const { CommonDS, getContentPath, selectedContentIndex } = get();
    return CommonDS.setColumn(getContentPath(), selectedContentIndex, field, value);
  },

  addContentRow: () => {
    const { CommonDS, getContentPath } = get();
    return CommonDS.addRow(getContentPath());
  },

  delContentRow: (selectedContentIndex: number) => {
    const { CommonDS, getContentPath } = get();
    return CommonDS.deleteRow(getContentPath(), selectedContentIndex);
  },

  saveAll: async () => {
    const { validate, getApiParam, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          await ApiService.post(`${formApiPath}`, apiParam);
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    } else {
      const { CommonDS, errors } = get();
      CommonDS.setValidateList('formValue', errors);
      const { formValue } = get();
      console.log(JSON.stringify(formValue));
      console.log(JSON.stringify(errors));
    }
  },

  // form 전체 초기화
  clear: () => {
    set({
      ...formBaseState,
      formValue: { ...initFormValue },
      selectedContent: null,
      selectedContentIndex: -1,
    });
  },
}));

export default useOcuCheckInfoFormStore;
