import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';
import _ from 'lodash';

/* yup validation */
const yupFormSchema = yup.object().shape({
  chkListClsCd: yup.string().required(),
  chkTitle: yup.string().required(),
  chkRegStartDt: yup.string().required(),
  chkRegEndDt: yup.string().required(),
  targetList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        bizPlaceId: yup.string().required(),
        prtnrId: yup.string().required(),
        regUserDept: yup.string().required(),
        chkDt: yup.string().required(), //점검_일자
        chkEmpno: yup.string().required(), //점검자_사번
        remark: yup.string().required(), //비고
        contentList: yup
          .array()
          .min(1, '목록은 최소 하나여야 합니다.')
          .of(
            yup.object().shape({
              chkClsCd: yup.string().required(),
              chkItemNm: yup.string().required(),
              chkResultCd: yup.string().required(),
              chkScls: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && !val ? false : true)),
              chkContent: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && !val ? false : true)),
              chkRelLaw: yup.string().test((val, obj) => (obj.parent.chkResultCd === 'X' && !val ? false : true)),
              rightActionYn: yup.string().required(),
              actionContent: yup.string().test((val, obj) => (obj.parent.rightActionYn === 'Y' && !val ? false : true)),
              actionDeptCd: yup.string().test((val, obj) => (obj.parent.rightActionYn === 'Y' && !val ? false : true)),
              aprvDeptCd: yup.string().test((val, obj) => (obj.parent.rightActionYn === 'Y' && !val ? false : true)),
            })
          ),
      })
    ),
});

/* formValue 초기값 */
const initFormValue = {
  chkListId: '',
  chkListClsCd: '',
  chkTitle: '',
  chkRegStartDt: '',
  chkRegEndDt: '',
  targetList: [
    // {
    //   prtnrId: '', //협력업체
    //   bizPlaceId: '', //사업장
    //   chkId: '', //점검_ID
    //   chkDt: '', //점검_일자
    //   chkEmpno: '', //점검자_사번
    //   remark: '', //비고
    //   contentList: [
    //     {
    //       chkId: '', //점검_ID
    //       bizPlaceId: '', //사업장_ID
    //       prtnrId: '', //협력업체_ID
    //       chkItemId: '', //점검항목_ID
    //       chkItemNm: '', //점검항목명
    //       chkListId: '', //점검표_ID
    //       chkResultCd: 'O', //점검_결과_코드
    //       chkLclsCd: '', //점검_대분류_코드
    //       chkScls: '', //점검_소분류_코드
    //       chkContent: '', //점검_내용
    //       chkRelLaw: '', //점검_관계_법령
    //       chkPohtoId1: '', //점검_첨부_사진_ID1
    //       chkPohtoId2: '', //점검_첨부_사진_ID2
    //       chkFile: '', //점검_첨부_파일
    //       rightActionYn: 'N', //즉시_조치_여부
    //       actionStatusCd: '', //조치_상태_코드
    //       actionContent: '', //조치_내용
    //       actionAttPhotoId: '', //조치_첨부_사진_ID
    //       actionAttFileId: '', //조치_첨부_파일_ID
    //       actionDt: '', //조치_일자
    //       actionDeptCd: '', //조치_부서_코드
    //       actionEmpno: '', //조치자_사번
    //       aprvDt: '', //승인_일자
    //       aprvDeptCd: '', //승인_부서_코드
    //       aprvEmpno: '', //승인자_사번
    //     },
    //   ],
    // },
  ],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/inspection/walkAround',
  baseRoutePath: '/occupation/inspection/walkAround',
  formName: 'OcuSvisitCheckForm',
  formValue: {
    ...initFormValue,
  },

  selectedTargetIndex: -1,
  selectedContentIndex: -1,
};

/* zustand store 생성 */
export const useOcuSvisitCheckFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...createCommonDataset(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  getTargetPath: () => {
    return `formValue.targetList`;
  },

  getContentPath: () => {
    const { selectedTargetIndex } = get();
    return `formValue.targetList[${selectedTargetIndex}].contentList`;
  },

  openChecklistModal: () => {
    set({ isChecklistModalOpen: true });
  },

  closeChecklistModal: () => {
    set({ isChecklistModalOpen: false });
  },

  selectChecklistModal: (params) => {
    const { CommonDS, setSelectedTargetIndex } = get();
    const newList = params.placeList.map((item) => ({
      prtnrId: item.prtnrId,
      bizPlaceId: item.bizPlaceId,
      contentList: [],
    }));
    const newDetailList = params.itemList.map((item) => ({
      bizPlaceId: item.bizPlaceId,
      prtnrId: item.prtnrId,
      chkItemId: item.chkItemId,
      chkItemNm: item.chkItemNm,
      chkClsCd: item.chkClsCd,
      chkResultCd: 'O',
      rightActionYn: 'N',
    }));

    newList.forEach(function (place) {
      place.contentList = newDetailList;
    });
    CommonDS.setColumn('formValue', null, `targetList`, newList);
    setSelectedTargetIndex(0);
  },

  getTargetError: (field: string) => {
    const { errors, selectedTargetIndex } = get();
    const path = `TargetList[${selectedTargetIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getTargetColumn: (field) => {
    const { CommonDS, getTargetPath, selectedTargetIndex } = get();
    return CommonDS.getColumn(getTargetPath(), selectedTargetIndex, field);
  },

  setTargetColumn: (field: string, value: any) => {
    const { CommonDS, getTargetPath, selectedTargetIndex } = get();
    return CommonDS.setColumn(getTargetPath(), selectedTargetIndex, field, value);
  },

  getContentError: (field: string) => {
    const { errors, getContentPath, selectedContentIndex } = get();
    const path = getContentPath`[${selectedContentIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getContentList: () => {
    const { CommonDS, getContentPath } = get();

    return CommonDS.getList(getContentPath());
  },

  openContentModal: () => {
    set({ isContentModalOpen: true });
  },

  closeContentModal: () => {
    set({ isContentModalOpen: false });
  },

  setSelectedTargetIndex: (index: number) => {
    set({ selectedTargetIndex: index });
  },

  setSelectedContentIndex: (index: number) => {
    set({ selectedContentIndex: index });
  },

  getContentColumn: (field) => {
    const { CommonDS, getContentPath, selectedContentIndex } = get();
    return CommonDS.getColumn(getContentPath(), selectedContentIndex, field);
  },

  setContentColumn: (field: string, value: any) => {
    const { CommonDS, getContentPath, selectedContentIndex } = get();
    return CommonDS.setColumn(getContentPath(), selectedContentIndex, field, value);
  },

  saveAll: async () => {
    const { validate, getApiParam, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          await ApiService.post(`${formApiPath}`, apiParam);
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    } else {
      const { CommonDS, errors } = get();
      CommonDS.setValidateList('formValue', errors);
      const { formValue } = get();
      console.log(JSON.stringify(formValue));
      console.log(JSON.stringify(errors));
    }
  },

  // form 전체 초기화
  clear: () => {
    set({
      ...formBaseState,
      formValue: { ...initFormValue },
      selectedTarget: null,
      selectedContent: null,
      selectedTargetIndex: -1,
      selectedContentIndex: -1,
    });
  },
}));
