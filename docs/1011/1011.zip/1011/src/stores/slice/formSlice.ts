import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import history from '@/utils/history';
import _ from 'lodash';
import { produce } from 'immer';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import i18n from '@/services/i18n';

/*

  기본 form slice

*/

export const formBaseState = {
  detailInfo: {},
  errors: {},
  isDirty: false,
  isValid: false,
  formDetailId: null,
  formType: FORM_TYPE_ADD,
  formValue: {},
};

// yup 연동 공통 slice : 가능하면 yup를 사용하는 방법으로 통일합니다
export const createFormSliceYup = (set, get) => ({
  changeStateProps: (propsName, propsValue) => {
    set({ [propsName]: propsValue });
  },

  changeInput: (inputName, inputValue, byPassIsDirty = false) => {
    set(
      produce((state: any) => {
        const formValue = state.formValue;
        _.set(formValue, inputName, inputValue);
        if (!byPassIsDirty) {
          state.isDirty = true;
        }
        state.formValue = formValue;
      })
    );
  },

  changeInputByFormName: (formName, inputName, inputValue, byPassIsDirty = false) => {
    set(
      produce((state: any) => {
        const formValue = state[formName];
        _.set(formValue, inputName, inputValue);
        if (!byPassIsDirty) {
          state.isDirty = true;
        }
        state[formName] = formValue;
      })
    );
  },

  getApiParam: () => {
    const { formValue, excludeApiKeys } = get();
    const apiParam = { ...formValue };
    if (excludeApiKeys && excludeApiKeys.length) {
      excludeApiKeys.forEach((keyName) => {
        if (apiParam[keyName]) {
          delete apiParam[keyName];
        }
      });
    }
    return apiParam;
  },

  getFormValue: () => {
    const { formValue } = get();
    return _.cloneDeep({ ...formValue });
  },

  validate: async () => {
    let success = true;
    const errors = {};
    const { yupFormSchema, getFormValue, formName, disableValidateToast = false } = get();
    const formValue = getFormValue();
    let firstErrorFieldKey = '';
    let firstErrorMessage = '';
    let firstErrorLabel = '';

    try {
      await yupFormSchema.validate(formValue, { abortEarly: false });
    } catch (error: any) {
      success = false;
      console.log(error.errors);
      const yupErrors = error.inner;
      firstErrorFieldKey = yupErrors[0].path;
      const groupErrorInfo = _.groupBy(yupErrors, 'path');
      const errorKeys = Object.keys(groupErrorInfo);
      errorKeys.forEach((errorKey, index) => {
        const groupErrorInfoDetail = groupErrorInfo[errorKey][0];
        const { message, params } = groupErrorInfoDetail;
        const { label } = params;
        if (index === 0) {
          firstErrorMessage = message;
          firstErrorLabel = label || '';
        }
        errors[errorKey] = message;
      });
    }

    if (firstErrorMessage && !disableValidateToast) {
      ToastService.warn(i18n.t(firstErrorMessage, { label: i18n.t(firstErrorLabel) }));
    }

    if (firstErrorFieldKey) {
      success = false;
      const applyFormName = formName ? formName : '';
      const applyFirstErrorFieldKey = applyFormName + firstErrorFieldKey;
      try {
        if (document.getElementById(applyFirstErrorFieldKey)) {
          document.getElementById(applyFirstErrorFieldKey).focus();
        }
      } catch (e) {
        // 로그를 찍을 필요가 없는 에러 catch
      }
    }

    set({
      isDirty: true,
      isValid: success,
      errors: errors,
    });
    return success;
  },

  save: async () => {
    const { validate, getApiParam, formType, formDetailId, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          if (formType === FORM_TYPE_ADD) {
            await ApiService.post(`${formApiPath}`, apiParam);
          } else {
            await ApiService.put(`${formApiPath}/${formDetailId}`, apiParam);
          }
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    }
  },

  remove: async () => {
    const { formDetailId, formApiPath, removeAfterNavigation } = get();
    // ModalService.alert({ body: '삭제하시겠습니까?' });
    ModalService.confirm({
      body: '삭제하시겠습니까?',
      ok: async () => {
        await ApiService.delete(`${formApiPath}/${formDetailId}`);
        ModalService.alert({
          body: '삭제되었습니다.',
          ok: async () => {
            removeAfterNavigation();
          },
        });
      },
    });
  },

  getDetail: async (id) => {
    const { formApiPath } = get();
    const response: any = await ApiService.get(`${formApiPath}/${id}`);
    const detailInfo = response.data;
    set({
      detailInfo: detailInfo,
      formValue: detailInfo,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  // 모달 전용으로 formData를 set할때 사용
  setFormValue: (detailInfo, id = '') => {
    const copyDetailInfo = detailInfo ? _.cloneDeep(detailInfo) : null;
    set({
      detailInfo: copyDetailInfo,
      formValue: copyDetailInfo,
      formDetailId: id,
      formType: id ? FORM_TYPE_UPDATE : FORM_TYPE_ADD,
    });
  },

  goFormPage: () => {
    const { formDetailId, baseRoutePath } = get();
    history.push(`${baseRoutePath}/${formDetailId}/edit`);
  },

  setErrors: (newErrors) => {
    if (newErrors) {
      set({ errors: newErrors });
    }
  },

  changeErrors: (errorKey, errorMessage) => {
    const { errors } = get();
    const newErrors = { ...errors };
    newErrors[errorKey] = errorMessage;
    set({ errors: newErrors });
  },

  removeAfterNavigation: () => {
    const { baseRoutePath } = get();
    history.replace(`${baseRoutePath}`);
  },

  cancel: () => {
    const { baseRoutePath } = get();
    history.push(`${baseRoutePath}`);
  },
});
