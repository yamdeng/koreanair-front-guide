import { create } from 'zustand';

const videoIntervalMsSecond = 8000;
const useHomePortalStore = create<any>((set, get) => ({
  videoIntervalId: null,
  videoIndex: 0,

  init: () => {
    const { repeatVideo } = get();
    const videoIntervalId = setInterval(() => {
      repeatVideo();
    }, videoIntervalMsSecond);
    set({ videoIntervalId: videoIntervalId });
    const video01: any = document.getElementById('video01');
    video01.src = '/video/001.mp4';
    video01.playbackRate = 0.7;
  },

  repeatVideo: () => {
    const { videoIndex } = get();
    if (videoIndex === 0) {
      set({ videoIndex: 1 });
      const video02: any = document.getElementById('video02');
      video02.src = '/video/002.mp4';
      video02.playbackRate = 0.7;
    } else if (videoIndex === 1) {
      set({ videoIndex: 2 });
      const video03: any = document.getElementById('video03');
      video03.src = '/video/003.mp4';
      video03.playbackRate = 0.7;
    } else {
      set({ videoIndex: 0 });
      const video01: any = document.getElementById('video01');
      video01.src = '/video/001.mp4';
      video01.playbackRate = 0.7;
    }
  },

  clear: () => {
    const { videoIntervalId } = get();
    if (videoIntervalId) {
      clearInterval(videoIntervalId);
    }
  },
}));

export default useHomePortalStore;
