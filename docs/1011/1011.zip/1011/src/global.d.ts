export {};

declare global {
  interface Window {
    fullpage_api: any;
  }
}
