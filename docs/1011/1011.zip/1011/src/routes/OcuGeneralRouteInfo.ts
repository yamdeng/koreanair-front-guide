import NoticeList from '@/components/occupation/general/notice/NoticeList';
import NoticeForm from '@/components/occupation/general/notice/NoticeForm';
import NoticeDetail from '@/components/occupation/general/notice/NoticeDetail';
import CommitteeList from '@/components/occupation/general/committee/CommitteeList';
import CommitteeForm from '@/components/occupation/general/committee/CommitteeForm';
import CommitteeDetail from '@/components/occupation/general/committee/CommitteeDetail';

import RegulationsList from '@/components/occupation/general/regulations/RegulationsList';
import RegulationsForm from '@/components/occupation/general/regulations/RegulationsForm';
import RegulationsDetail from '@/components/occupation/general/regulations/RegulationsDetail';

import HsCommitteeList from '@/components/occupation/general/hsCommittee/HsCommitteeList';

import HsCommitteeForm from '@/components/occupation/general/hsCommittee/HsCommitteeForm';

import HsCommitteeDetail from '@/components/occupation/general/hsCommittee/HsCommitteeDetail';

import ZeroHzdGoalList from '@/components/occupation/general/zeroHzdGoal/ZeroHzdGoalList';

import ZeroHzdGoalDetail from '@/components/occupation/general/zeroHzdGoal/ZeroHzdGoalDetail';

import ZeroHzdGoalForm from '@/components/occupation/general/zeroHzdGoal/ZeroHzdGoalForm';

import ZeroHzdGoalInsert from '@/components/occupation/general/zeroHzdGoal/ZeroHzdGoalInsert';

import LawRegStdList from '@/components/occupation/general/lawRegStd/LawRegStdList';
import LawRegStdForm from '@/components/occupation/general/lawRegStd/LawRegStdForm';
import LawRegStdDetail from '@/components/occupation/general/lawRegStd/LawRegStdDetail';

import LawRegInfoList from '@/components/occupation/general/lawRegInfo/LawRegInfoList';
import LawRegInfoForm from '@/components/occupation/general/lawRegInfo/LawRegInfoForm';
import LawRegInfoDetail from '@/components/occupation/general/lawRegInfo/LawRegInfoDetail';

import OrganizationForm from '@/components/occupation/general/organization/OrganizationForm';

import CostList from '@/components/occupation/general/cost/CostList';
import CostState from '@/components/occupation/general/cost/CostState';
import CostForm from '@/components/occupation/general/cost/CostForm';
import CostDetail from '@/components/occupation/general/cost/CostDetail';
import CostInsert from '@/components/occupation/general/cost/CostInsert';
import CostPerformanceList from '@/components/occupation/general/cost/CostPerformanceList';
//import CostState from '@/components/occupation/general/cost/CostState';

const RouteInfo: any = { rootPath: 'general/' };

RouteInfo.list = [
  // 공지사항 목록
  {
    Component: NoticeList,
    path: 'notice',
  },
  // 공지사항 상세
  {
    Component: NoticeDetail,
    path: 'notice/:detailId',
  },
  // 공지사항 입력,수정
  {
    Component: NoticeForm,
    path: 'notice/:detailId/edit',
  },
  /**  산업안전보건위원회 **/

  // 산업안전보건위원회 목록
  {
    Component: CommitteeList,
    path: 'committee',
  },

  // 산업안전보건위원회 상세
  {
    Component: CommitteeDetail,
    path: 'committee/:detailId',
  },

  // 산업안전보건위원회 입력,수정
  {
    Component: CommitteeForm,
    path: 'committee/:detailId/edit',
  },

  /** 규정/지침/매뉴얼/양식 **/

  // 규정/지침/매뉴얼/양식 목록
  {
    Component: RegulationsList,
    path: 'regulations',
  },

  // 규정/지침/매뉴얼/양식 상세
  {
    Component: RegulationsDetail,
    path: 'regulations/:detailId',
  },

  // 규정/지침/매뉴얼/양식 입력,수정
  {
    Component: RegulationsForm,
    path: 'regulations/:detailId/edit',
  },

  /** 안전보건협의체 **/

  // 안전보건협의체 목록
  {
    Component: HsCommitteeList,
    path: 'hsCommittee',
  },

  // 안전보건협의체 상세
  {
    Component: HsCommitteeDetail,
    path: 'hsCommittee/:detailId',
  },

  // 안전보건협의체 입력/수정
  {
    Component: HsCommitteeForm,
    path: 'hsCommittee/:detailId/edit',
  },

  /** 무재해운동 **/

  // 무재해운동 목록
  {
    Component: ZeroHzdGoalList,
    path: 'zeroHzdGoal',
  },

  // 무재해운동 목표 등록
  {
    Component: ZeroHzdGoalInsert,
    path: 'zeroHzdGoal/insert',
  },

  // 무재해운동 상세
  {
    Component: ZeroHzdGoalDetail,
    path: 'zeroHzdGoal/:detailId',
  },

  // 무재해운동 입력/수정
  {
    Component: ZeroHzdGoalForm,
    path: 'zeroHzdGoal/:detailId/edit',
  },

  //** 법규등록대장 기준 정보 **/

  // 법규등록대장 기준 정보 목록
  {
    Component: LawRegStdList,
    path: 'lawRegStd',
  },

  // 법규등록대장 기준 정보 상세
  {
    Component: LawRegStdDetail,
    path: 'lawRegStd/:detailId',
  },

  // 법규등록대장 기준 정보 입력,수정
  {
    Component: LawRegStdForm,
    path: 'lawRegStd/:detailId/edit',
  },

  //** 법규등록대장  **/

  // 법규등록대장 목록
  {
    Component: LawRegInfoList,
    path: 'lawRegInfo',
  },

  // 법규등록대장 상세
  {
    Component: LawRegInfoDetail,
    path: 'lawRegInfo/:detailId',
  },

  // 법규등록대장 입력,수정
  {
    Component: LawRegInfoForm,
    path: 'lawRegInfo/:detailId/edit',
  },

  // 조직도 화면
  {
    Component: OrganizationForm,
    path: 'Organization',
  },

  //** 산업안전보건 관리비 **/

  // 산업안전보건 현황
  {
    Component: CostState,
    path: 'costState',
  },

  //산업안전보건 목록
  {
    Component: CostList,
    path: 'costList',
  },

  //산업안전보건 실적
  {
    Component: CostPerformanceList,
    path: 'costPerformanceList',
  },

  // 산업안전보건 상세
  {
    Component: CostDetail,
    path: 'costList/:detailId',
  },

  // 산업안전보건 등록
  {
    Component: CostInsert,
    path: 'costList/insert',
  },

  // 산업안전보건 입력,수정
  {
    Component: CostForm,
    path: 'costList/:detailId/edit',
  },
];

export default RouteInfo;
