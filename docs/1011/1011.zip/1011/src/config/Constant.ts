const Constant = {
  USER_TYPE_NORMAL: 'U',
  USER_TYPE_ADMIN: 'A',
};

export default Constant;
