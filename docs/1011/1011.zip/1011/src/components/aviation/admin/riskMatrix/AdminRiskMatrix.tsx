import AppNavigation from '@/components/common/AppNavigation';
import ApiService from '@/services/ApiService';
import { createListSlice } from '@/stores/slice/listSlice';
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { create } from 'zustand';

/* zustand store 생성 */
const useAdminRiskMatrixStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {},

  riskMatrixList: [],
  riskInfo: [],
  riskPbbtList: [],
  riskSvrtList: [],
  lastUpdateDttm: '',

  initInfoSearch: async () => {
    const apiParam = {};
    const apiResult = await ApiService.get(`avn/admin/risk-matrix`, apiParam);

    set({ riskMatrixList: apiResult.data.riskMatrix });
    set({ riskPbbtList: apiResult.data.riskPbbt.body.data });
    set({ riskSvrtList: apiResult.data.riskSvrt.body.data });
    set({ lastUpdateDttm: apiResult.data.riskMatrix[0].regDttmInfo });

    const { riskMatrixList } = get();
    const rtnArr = [];
    let arr = [];
    riskMatrixList.map((info, index) => {
      arr.push(
        <td id={info.riskLevelCd} className={info.colorCd} key={'td' + index}>
          {info.riskLevelCd + ' '}
          <div className="flag-tag ">
            <span className="icon-flag txt">{'(' + info.scoreCo + ')'}</span>
          </div>
        </td>
      );
      if (index % 5 === 4 || index === riskMatrixList.length - 1) {
        const thElement = <th key={'th' + index}>{5 - Math.floor(index / 5)}</th>;
        rtnArr.push(React.createElement('tr', { key: 'risk' + index }, [thElement, ...arr]));
        arr = [];
      }
    });
    set({ riskInfo: rtnArr });
  },
}));

function AdminRiskMATRIX() {
  const state = useAdminRiskMatrixStore();
  const navigate = useNavigate();

  const { changeStateProps, changeSearchInput, lastUpdateDttm, initInfoSearch, riskInfo, riskPbbtList, riskSvrtList } =
    state;

  const goEditPage = () => {
    navigate(`/aviation/risk-matrix/edit`);
  };
  useEffect(() => {
    initInfoSearch();
    return;
  }, []);
  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>Risk Matrix 관리</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        <div className="form-table RiskMatrix">
          <div className="form-cell wid50">
            <div className="form-group form-glow">
              <span className="info-txt">마지막 업데이트 일시 : {lastUpdateDttm}</span>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={goEditPage}>
              수정
            </button>
          </div>
        </div>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <div className="RiskLevel-Wrap">
        <div className="RiskLevel-Left">
          <div className="h4-tit">발생가능성</div>
          <div className="tableTop">
            <table className="RiskLevelTable left">
              <caption></caption>
              <colgroup></colgroup>
              <thead>
                <tr>
                  <th>구분</th>
                  <th>발생가능성</th>
                  <th>정성적 평가</th>
                  <th>정량적 평가</th>
                </tr>
              </thead>
              <tbody>
                {riskPbbtList.map((info, index) => {
                  const { codeNameKor, codeField1, codeField2 } = info;
                  return (
                    <tr key={'Pbbt' + index}>
                      <th>{riskPbbtList.length - index}</th>
                      <td className="">{codeNameKor}</td>
                      <td className="tl">{codeField1}</td>
                      <td>{codeField2}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        <div className="RiskLevel-Right">
          <div className="h4-tit">RISK</div>
          <div className="">
            <table className="RiskLevelTable Risk">
              <caption></caption>
              <colgroup></colgroup>
              <thead>
                <tr>
                  <th rowSpan={2}>
                    발생
                    <br />
                    가능성
                  </th>
                  <th colSpan={5}>심각도</th>
                </tr>
                <tr>
                  <th>LevelA</th>
                  <th>LevelB</th>
                  <th>LevelC</th>
                  <th>LevelD</th>
                  <th>LevelE</th>
                </tr>
              </thead>
              <tbody id="riskTable">{riskInfo}</tbody>
            </table>
          </div>
        </div>
      </div>
      <div className="RiskLevel-bottom">
        <p className="h4-tit">심각도</p>
        <div className="tableTop">
          <table className="RiskLevelTable severity">
            <caption></caption>
            <colgroup></colgroup>
            <thead>
              <tr>
                <th>순번</th>
                <th>심각도구분</th>
                <th>매우심각</th>
                <th>위험</th>
                <th>중요</th>
                <th>경미</th>
                <th>매우경미</th>
              </tr>
            </thead>
            <tbody>
              {riskSvrtList.map((info, index) => {
                const { codeNameKor, codeField1, codeField2, codeField3, codeField4, codeField5 } = info;
                return (
                  <tr key={'Svrt' + index}>
                    <th>{index + 1}</th>
                    <td className="">{codeNameKor}</td>
                    <td className="">{codeField1}</td>
                    <td className="">{codeField2}</td>
                    <td className="">{codeField3}</td>
                    <td className="">{codeField4}</td>
                    <td className="">{codeField5}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      {/*//그리드영역 */}
    </>
  );
}

export default AdminRiskMATRIX;
