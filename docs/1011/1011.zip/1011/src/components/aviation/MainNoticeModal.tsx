import CommonUtil from '@/utils/CommonUtil';
import { Upload } from 'antd';
import dayjs from 'dayjs';
import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import AppEditorViewer from '../common/AppEditorViewer';
import AppFileAttach from '../common/AppFileAttach';

const { Dragger } = Upload;
const props: any = {
  name: 'file',
  multiple: true,
  defaultFileList: [
    {
      uid: '1',
      name: 'xxx.png',
      // status: 'uploading',
      url: 'http://www.baidu.com/xxx.png',
      percent: 33,
    },
    {
      uid: '2',
      name: 'yyy.png',
      status: 'done',
      url: 'http://www.baidu.com/yyy.png',
    },
    {
      uid: '3',
      name: 'zzz.png',
      status: 'error',
      response: 'Server Error 500',
      // custom error message to show
      url: 'http://www.baidu.com/zzz.png',
    },
  ],
  action: 'https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload',

  onChange(info) {
    const { status } = info.file;
    if (status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (status === 'done') {
      alert(`${info.file.name} file uploaded successfully.`);
    } else if (status === 'error') {
      alert(`${info.file.name} file upload failed.`);
    }
  },

  onRemove(file) {
    return false;
  },

  onPreview(file) {
    return false;
  },

  onDrop(e) {
    console.log('Dropped files', e.dataTransfer.files);
  },
};
function MainNoticeModal(props) {
  const { isOpen, closeModal, params } = props;
  console.log('params', params);
  const [noticeList, setNoticeList] = useState([]);
  // const [noticeInfo, setNoticeInfo] = useState({ subjectKoNm: null, boardTxtcn: null });
  const [noticeIndex, setNoticeIndex] = useState(0);

  const noticeInfo =
    noticeList && noticeList.length
      ? noticeList[noticeIndex]
      : { fileGroupSeq: 0, subjectKoNm: null, boardTxtcn: null };
  console.log(noticeInfo);
  const noticeMove = (move) => {
    if (move === 'next' && noticeIndex !== params.length - 1) {
      setNoticeIndex(noticeIndex + 1);
    }
    if (move === 'prev' && noticeIndex !== 0) {
      setNoticeIndex(noticeIndex - 1);
    }
  };

  const noticeDisabled = () => {
    CommonUtil.saveNoticeExpireInfo('notice', dayjs().format('YYYY-MM-DD'), 1);
    closeModal();
  };

  useEffect(() => {
    if (isOpen) {
      setNoticeList(params);
      setNoticeIndex(0);
    }

    return;
  }, [isOpen, params]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">{noticeInfo.subjectKoNm}</h3>
        <div className="pop_cont notice">
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="group-box-wrap1 wid100 ">
                  <AppEditorViewer value={noticeInfo.boardTxtcn} />
                  {/* <div dangerouslySetInnerHTML={{ __html: noticeInfo.boardTxtcn }}></div> */}
                </div>
              </div>
            </div>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* 파일첨부영역 : drag */}
                  <AppFileAttach label="첨부파일" mode="view" fileGroupSeq={noticeInfo.fileGroupSeq} workScope={'A'} />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={noticeDisabled}>
            오늘 하루 팝업 안보기
          </button>
          <button
            className={`btn_text ${noticeIndex === 0 ? 'text_color_neutral-90 btn_close' : 'text_color_neutral-10 btn_confirm'}`}
            onClick={() => noticeMove('prev')}
          >
            이전
          </button>
          <button
            className={`btn_text ${noticeIndex === params.length - 1 ? 'text_color_neutral-90 btn_close' : 'text_color_neutral-10 btn_confirm'}`}
            onClick={() => noticeMove('next')}
          >
            다음
          </button>
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            닫기
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default MainNoticeModal;
