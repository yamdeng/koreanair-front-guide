import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';
import shareImage from '@/resources/images/share.svg';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useLocation } from 'react-router-dom';
import { Viewer } from '@toast-ui/react-editor';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';

import AppSearchInput from '@/components/common/AppSearchInput';

import useOcuRiskMasterStore from '@/stores/occupation/risk/useOcuRiskMasterStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalHeader() {
  const { tabIndex, changeTab, clear } = useOcuRiskMasterStore();

  useEffect(() => {
    changeTab(0);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          위험성평가
          <span>
            <a href="javascript:void(0);"></a>
          </span>
        </h2>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="menu-tab">
          <a
            onClick={() => {
              changeTab(0);
            }}
            className={tabIndex == 0 ? 'active' : ''}
            data-label="사전준비"
            href={undefined}
          >
            사전준비
          </a>
          <a
            onClick={() => {
              changeTab(1);
            }}
            className={tabIndex == 1 ? 'active' : ''}
            data-label="유해 위험요인 파악"
            href={undefined}
          >
            유해 위험요인 파악
          </a>
          <a
            onClick={() => {
              changeTab(2);
            }}
            className={tabIndex == 2 ? 'active' : ''}
            data-label="위험성 결정"
            href={undefined}
          >
            위험성 결정
          </a>
          <a
            onClick={() => {
              changeTab(3);
            }}
            className={tabIndex == 3 ? 'active' : ''}
            data-label="첨부문서"
            href={undefined}
          >
            첨부문서
          </a>
          {/* <a href="javascript:void(0);" className="active" data-label="사전준비">
            사전준비
          </a>
          <a href="javascript:void(0);" data-label="유해 위험요인 파악">
            유해 위험요인 파악
          </a>
          <a href="javascript:void(0);" data-label="위험성 결정">
            위험성 결정3
          </a>
          <a href="javascript:void(0);" data-label="첨부문서">
            첨부문서
          </a> */}
        </div>
      </div>
    </>
  );
}
export default RevalHeader;
