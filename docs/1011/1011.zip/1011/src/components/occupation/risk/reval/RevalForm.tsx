import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';
import shareImage from '@/resources/images/share.svg';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useLocation } from 'react-router-dom';
import { Viewer } from '@toast-ui/react-editor';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';

import AppSearchInput from '@/components/common/AppSearchInput';

import RevalFormTab1 from './RevalFormTab1';
import RevalFormTab2 from './RevalFormTab2';
import RevalFormTab3 from './RevalFormTab3';
import RevalFormTab4 from './RevalFormTab4';
import RevalHeader from './RevalHeader';

import useOcuRiskMasterStore from '@/stores/occupation/risk/useOcuRiskMasterStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalDetail() {
  const { tabIndex, changeTab, clear } = useOcuRiskMasterStore();

  useEffect(() => {
    //tabIndex = 0;

    console.log('이곳에옴::', tabIndex);

    changeTab(0);
    return clear;
  }, []);

  return (
    <>
      {/* 위험성평가 탭 상단 */}
      <RevalHeader />
      {/* 사전준비 */}
      {tabIndex == 0 ? <RevalFormTab1 /> : <></>}
      {/* 유해 위험요인 파악 */}
      {tabIndex == 1 ? <RevalFormTab2 /> : <></>}
      {/* 위험성결정 */}
      {tabIndex == 2 ? <RevalFormTab3 /> : <></>}
      {/* 첨부문서 */}
      {tabIndex == 3 ? <RevalFormTab4 /> : <></>}
    </>
  );

  // /* formStore state input 변수 */
  // const { detailInfo, getDetail, formType, cancel, goFormPage, clear, search, list } = useOcuRiskTab1FormStore();
  // const {
  //   /* 기본 정보 */

  //   // 위험성평가 문서 번호
  //   revalDocNo,
  //   // 부문
  //   authorSectCd,
  //   // 부서
  //   authorDeptCd,
  //   // 위험성평가 년도
  //   revalYear,
  //   // 위험성평가 시기
  //   revalPeriod,
  //   // 평가 시작일자
  //   evalStartDt,
  //   // 평가 종료일자
  //   evalEndDt,
  //   // 위험성평가 제목
  //   revalTitle,
  //   // 재해발생보고서 문서 번호
  //   dssReportDocNo,
  //   // 근로자_수
  //   emplCnt,
  //   // 근무형태
  //   workForm,
  //   // 위험성평가 1번 문항
  //   revalItem1,
  //   // 위험성평가 2번 문항
  //   revalItem2,
  //   // 위험성평가 3번 문항
  //   revalItem3,
  //   // 위험성평가 4번 문항
  //   revalItem4,
  //   // 안전보건_정보_내용
  //   hlthSftyInfoCn,
  //   // 준비_관련_첨부_파일_ID
  //   prepareRelFileId,
  //   /* 추진팀 정보 */

  //   // 추진팀 구분 코드
  //   execTeamClsCd,
  //   // 추진팀 성명
  //   execTeamNm,
  //   // 추진팀 사번
  //   execTeamEmpno,
  //   // 추진팀 부문 코드
  //   execTeamSectCd,
  //   // 추진팀 부서 코드
  //   execTeamDeptCd,
  //   //  추진팀 업체명
  //   execTeamCompNm,
  //   // 추진팀 직책 코드
  //   execTeamPosCd,
  //   /* 공정 정보 */

  //   // 공정 명
  //   procNm,

  //   regDttm,
  //   regUserId,
  // } = detailInfo;

  // console.log('값2==>', detailInfo);

  // const { detailId } = useParams();

  // const [columns, setColumns] = useState(
  //   CommonUtil.mergeColumnInfosByLocal([
  //     { field: 'execTeamId', headerName: '구분', flex: 1 },
  //     { field: 'execTeamClsCd', headerName: '이름', flex: 1 },
  //     { field: 'execTeamPosCd', headerName: '직책', flex: 1 },
  //     { field: 'execTeamDeptCd', headerName: '부서', flex: 1 },
  //     { field: 'execTeamCompNm', headerName: '업체', flex: 1 },
  //   ])
  // );

  // const init = async () => {
  //   getDetail(detailId);
  //   search();
  // };

  // useEffect(() => {
  //   init();
  //   return clear;
  // }, []);

  // // useEffect(() => {
  // //   getDetail(detailId);
  // //   return clear;
  // // }, []);

  // return (
  //   <>
  //     <AppNavigation />
  //     <div className="conts-title">
  //       <h2>
  //         위험성평가 상세
  //         <span>
  //           <a href="javascript:void(0);"></a>
  //         </span>
  //       </h2>
  //     </div>
  //     {/*탭 */}
  //     <div className="menu-tab-nav">
  //       <div className="menu-tab">
  //         <a href="javascript:void(0);" className="active" data-label="사전준비">
  //           사전준비
  //         </a>
  //         <a href="javascript:void(0);" data-label="유해 위험요인 파악">
  //           유해 위험요인 파악
  //         </a>
  //         <a href="javascript:void(0);" data-label="위험성 결정">
  //           위험성 결정
  //         </a>
  //         <a href="javascript:void(0);" data-label="첨부문서">
  //           첨부문서
  //         </a>
  //       </div>
  //     </div>
  //     {/*//탭 */}
  //     {/* 입력영역 */}
  //     <div className="info-wrap toggle">
  //       <dl className="tg-item active">
  //         {/* toggle 선택되면  열어지면 active붙임*/}
  //         <dt>
  //           <button type="button" className="btn-tg">
  //             기본 사항<span className="active"></span>
  //             {/*평가시기 - 팝업 */}
  //             <div className="tag-info-wrap-end">
  //               <div className="tip">
  //                 <div>
  //                   <a href="javascript:void(0);" className="txt">
  //                     평가시기
  //                   </a>
  //                 </div>
  //               </div>
  //             </div>
  //           </button>
  //         </dt>
  //         <dd className="tg-conts">
  //           <div className="edit-area">
  //             <div className="detail-form">
  //               <div className="detail-list">
  //                 <div className="form-table">
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             {/* <AppTextInput label="작성자" disabled /> */}
  //                             <label className="t-label">작성자</label>
  //                             <span className="text-desc-type1">{}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="작성일자" disabled /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">작성일자</label>
  //                             <span className="text-desc-type1">{}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="부문" disabled /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">부문</label>
  //                             <span className="text-desc-type1">{authorSectCd}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">부서</label>
  //                             <span className="text-desc-type1">{authorDeptCd}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                       {/* <AppTextInput label="부서" disabled /> */}
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="팀" disabled /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">팀</label>
  //                             <span className="text-desc-type1">{}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="그룹" disabled /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">그룹</label>
  //                             <span className="text-desc-type1">{}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                 </div>
  //                 <div className="form-table">
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="반/섹션" disabled /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">반/섹션</label>
  //                             <span className="text-desc-type1">{}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="평가년도" /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">평가년도</label>
  //                             <span className="text-desc-type1">{revalYear}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppCodeSelect label="평가시기" required /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">평가시기</label>
  //                             <span className="text-desc-type1">{revalPeriod}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>

  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppSearchInput label="재해발생보고서" /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">재해발생보고서</label>
  //                             <span className="text-desc-type1">{dssReportDocNo}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppDatePicker label="평가시작일" /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">평가시작일</label>
  //                             <span className="text-desc-type1">{evalStartDt}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppDatePicker label="평가종료일" /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">평가종료일</label>
  //                             <span className="text-desc-type1">{evalEndDt}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                 </div>
  //                 <div className="form-table">
  //                   <div className="form-cell wid70">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="제목" required /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">제목</label>
  //                             <span className="text-desc-type1">{revalTitle}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid30">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="문서번호" disabled /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">문서번호</label>
  //                             <span className="text-desc-type1">{revalDocNo}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                 </div>
  //                 <div className="form-table">
  //                   <div className="form-cell wid50">
  //                     <div className="ck-edit-box">
  //                       <div className="ck-list">
  //                         <h3 className="table-tit">추진팀 구성</h3>
  //                         {/* 그리드영역 */}
  //                         <AppTable rowData={list} columns={columns} setColumns={setColumns} />
  //                       </div>
  //                       <div className="ck-edit">
  //                         <div className="boxForm">
  //                           <div className="form-table">
  //                             <div className="form-cell wid100">
  //                               <div className="form-group wid100">
  //                                 {/* <AppCodeSelect label="구분" /> */}
  //                                 <div className="box-view-list">
  //                                   <ul className="view-list">
  //                                     <li className="accumlate-list">
  //                                       <label className="t-label">작성일자</label>
  //                                       <span className="text-desc-type1">{}</span>
  //                                     </li>
  //                                   </ul>
  //                                 </div>
  //                               </div>
  //                             </div>
  //                           </div>
  //                           <div className="form-table">
  //                             <div className="form-cell wid50">
  //                               <div className="form-group wid100">
  //                                 {/* <AppSearchInput label="이름" disabled /> */}
  //                                 <div className="box-view-list">
  //                                   <ul className="view-list">
  //                                     <li className="accumlate-list">
  //                                       <label className="t-label">이름</label>
  //                                       <span className="text-desc-type1">{}</span>
  //                                     </li>
  //                                   </ul>
  //                                 </div>
  //                               </div>
  //                             </div>
  //                           </div>
  //                           <div className="form-table">
  //                             <div className="form-cell wid50">
  //                               <div className="form-group wid100">
  //                                 {/* <AppSearchInput label="사번" disabled /> */}
  //                                 <div className="box-view-list">
  //                                   <ul className="view-list">
  //                                     <li className="accumlate-list">
  //                                       <label className="t-label">사번</label>
  //                                       <span className="text-desc-type1">{}</span>
  //                                     </li>
  //                                   </ul>
  //                                 </div>
  //                               </div>
  //                             </div>
  //                           </div>
  //                           <div className="form-table">
  //                             <div className="form-cell wid50">
  //                               <div className="form-group wid100">
  //                                 {/* <AppSearchInput label="부문" disabled /> */}
  //                                 <div className="box-view-list">
  //                                   <ul className="view-list">
  //                                     <li className="accumlate-list">
  //                                       <label className="t-label">부문</label>
  //                                       <span className="text-desc-type1">{}</span>
  //                                     </li>
  //                                   </ul>
  //                                 </div>
  //                               </div>
  //                             </div>
  //                           </div>
  //                           <div className="form-table">
  //                             <div className="form-cell wid50">
  //                               <div className="form-group wid100">
  //                                 {/* <AppSearchInput label="부서" disabled /> */}
  //                                 <div className="box-view-list">
  //                                   <ul className="view-list">
  //                                     <li className="accumlate-list">
  //                                       <label className="t-label">부서</label>
  //                                       <span className="text-desc-type1">{}</span>
  //                                     </li>
  //                                   </ul>
  //                                 </div>
  //                               </div>
  //                             </div>
  //                           </div>
  //                           <div className="form-table">
  //                             <div className="form-cell wid50">
  //                               <div className="form-group wid100">
  //                                 {/* <AppSearchInput label="업체" disabled /> */}
  //                                 <div className="box-view-list">
  //                                   <ul className="view-list">
  //                                     <li className="accumlate-list">
  //                                       <label className="t-label">업체</label>
  //                                       <span className="text-desc-type1">{}</span>
  //                                     </li>
  //                                   </ul>
  //                                 </div>
  //                               </div>
  //                             </div>
  //                           </div>
  //                           <div className="form-table">
  //                             <div className="form-cell wid50">
  //                               <div className="form-group wid100">
  //                                 {/* <AppCodeSelect label="직책" /> */}
  //                                 <div className="box-view-list">
  //                                   <ul className="view-list">
  //                                     <li className="accumlate-list">
  //                                       <label className="t-label">직책</label>
  //                                       <span className="text-desc-type1">{}</span>
  //                                     </li>
  //                                   </ul>
  //                                 </div>
  //                               </div>
  //                             </div>
  //                           </div>
  //                           <div className="btn-area-type01 mg-top">
  //                             <button type="button" name="button" className="btn_text btn_confirm">
  //                               저장
  //                             </button>
  //                           </div>
  //                         </div>
  //                       </div>
  //                     </div>
  //                   </div>
  //                 </div>
  //               </div>
  //             </div>
  //           </div>
  //         </dd>
  //         <dt>
  //           <button type="button" className="btn-tg">
  //             안전보건 정보 수집<span className="active"></span>
  //           </button>
  //         </dt>
  //         <dd className="tg-conts">
  //           <div className="edit-area">
  //             <div className="detail-form">
  //               <div className="detail-list">
  //                 <div className="form-table">
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="근로자수" /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">근로자수</label>
  //                             <span className="text-desc-type1">{}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                   <div className="form-cell wid50">
  //                     <div className="form-group wid100">
  //                       {/* <AppTextInput label="근무형태" /> */}
  //                       <div className="box-view-list">
  //                         <ul className="view-list">
  //                           <li className="accumlate-list">
  //                             <label className="t-label">근무형태</label>
  //                             <span className="text-desc-type1">{}</span>
  //                           </li>
  //                         </ul>
  //                       </div>
  //                     </div>
  //                   </div>
  //                 </div>
  //                 <div className="form-table">
  //                   <div className="form-cell wid50">
  //                     <h3>다음 각 호의 사항을 조사하여 위험성평가에 활용한다.</h3>
  //                     <div>
  //                       <ul className="list-input-box">
  //                         <li>
  //                           <span className="list-tit">1. 산업재해 및 아차사고 발생 사례 (5개년 이상)</span>
  //                           <AppSearchInput disabled label="" placeholder="19년 랜딩기어 손가락 협착" />
  //                         </li>
  //                         <li>
  //                           <span className="list-tit">2. 설비, 기계, 기구 보유 현황</span>
  //                           <AppSearchInput disabled label="" />
  //                         </li>
  //                         <li>
  //                           <span className="list-tit">3. 작업표준서, 작업절차</span>
  //                           <AppSearchInput disabled label="" />
  //                         </li>
  //                         <li>
  //                           <span className="list-tit">4. 협력사 혼재작업 시 위험성 및 작업상황 정보</span>
  //                           <AppSearchInput disabled label="" />
  //                         </li>
  //                       </ul>
  //                     </div>
  //                   </div>
  //                 </div>
  //                 <div className="form-table">
  //                   <div className="form-cell wid50">
  //                     <div className="ck-edit-box">
  //                       <div className="ck-list">
  //                         <h3 className="table-tit">평가항목 선정</h3>
  //                         그리드영역
  //                       </div>
  //                     </div>
  //                   </div>
  //                 </div>
  //                 <div className="form-table">
  //                   <div className="form-cell wid50">
  //                     <h3 className="table-tit">참여자 교육</h3>
  //                     <span>다음 각 호의 사항을 조사하여 위험성평가에 활용한다.</span>
  //                     <ul className="guide-list">
  //                       <li>1. 위험성평가 대상 공정 선정 및 Process에 관한 사항</li>
  //                       <li>2. 역할별 임무 안내(책임자, 관리감독자, 작업자, 안전보건조직 등)</li>
  //                       <li>3. 위험성평가 방법 안내(유해위험요인파악, 감소대책 수립 및 참여 방법 등)</li>
  //                       <li>4. 안전보건정보 수집 및 활용 방법</li>
  //                     </ul>
  //                   </div>
  //                 </div>
  //                 {/* 파일첨부영역 : button */}
  //                 <div className="form-table">
  //                   <div className="form-cell wid50">
  //                     <h3 className="table-tit mb-10">준비관련 첨부 문서</h3>
  //                     <div className="form-group wid100">
  //                       <AppFileAttach
  //                         mode="view"
  //                         // fileGroupSeq={prepareRelFileId}
  //                         workScope={'O'}
  //                         // onlyImageUpload={true}
  //                         useDetail
  //                         disabled
  //                       />
  //                       {/* <div className="filebox "> */}
  //                       {/* <Upload {...props}>
  //                           <div className="btn-area">
  //                             <button type="button" name="button" className="btn-big btn_text btn-darkblue-line mg-n">
  //                               + Upload
  //                             </button>
  //                           </div>
  //                         </Upload>
  //                         <label htmlFor="file" className="file-label">
  //                           파일 첨부 <span className="required">*</span>
  //                         </label> */}
  //                       {/* </div> */}
  //                       {/*<span className="errorText">fileerror</span>*/}
  //                     </div>
  //                   </div>
  //                 </div>
  //               </div>
  //             </div>
  //           </div>
  //         </dd>
  //       </dl>
  //     </div>

  //     {/* 하단 버튼 영역 */}
  //     <div className="contents-btns">
  //       <button type="button" name="button" className="btn_text btn-share">
  //         <img src={shareImage} />
  //         {/* onClick={() => handleCopyClipBoard(`${baseUrl}${location.pathname}`)} */}
  //         {/* baseurl 추가해야함 */}
  //         {/* <span onClick={() => handleCopy(`${location.pathname}`)}>공유</span> */}
  //       </button>
  //       <button
  //         className="btn_text text_color_darkblue-100 btn_close"
  //         onClick={goFormPage}
  //         style={{ display: formType !== 'add' ? '' : 'none' }}
  //       >
  //         수정
  //       </button>
  //       {/* <button type="button" name="button" className="btn_text btn-del">
  //         삭제
  //       </button> */}
  //       <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
  //         목록으로
  //       </button>
  //     </div>
  //   </>
  // );
}
export default RevalDetail;
