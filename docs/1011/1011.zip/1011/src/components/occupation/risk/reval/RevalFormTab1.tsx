import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
//import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';
import shareImage from '@/resources/images/share.svg';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useLocation } from 'react-router-dom';
import { Viewer } from '@toast-ui/react-editor';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppSelect from '@/components/common/AppSelect';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';

import useOcuRiskMasterStore from '@/stores/occupation/risk/useOcuRiskMasterStore';
import AppTextInput from '@/components/common/AppTextInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppUserSelectInput from '@/components/common/AppUserSelectInput';
import RiskHelpPeriodModal from '@/components/modal/occupation/RiskHelpPeriodModal';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';

// import {
//   useOcuRiskTab1FormStore,
//   useOcuRiskTab1ProcessListStore,
// } from '@/stores/occupation/risk/useOcuRiskTab1FormStore';

import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalFormTab1() {
  /* formStore state input 변수 */
  // const { detailInfo, getDetail, formType, cancel, goFormPage, clear, search, list } = useOcuRiskTab1FormStore();

  const { tabIndex, changeTab } = useOcuRiskMasterStore();

  // // 기존정보, 추진팀 정보
  // const baseInfo = useOcuRiskTab1FormStore();

  // // 공정 정보
  // const proc = useOcuRiskTab1ProcessListStore();

  const profile = useStore(useAppStore, (state) => state.profile);

  console.log('profile===>', profile);

  // 사용자명
  const nameKor = profile.userInfo.nameKor;
  // 사용자 부서
  const deptCd = profile.userInfo.deptCd;
  // deptCd = 'ICNMCD391';

  // 부문
  const sectCd = profile.userInfo.sectCd;
  // 부서
  const deptLevel2 = profile.userInfo.deptLevel2;
  // 팀
  const deptLevel3 = profile.userInfo.deptLevel3;
  // 그룹
  const deptLevel4 = profile.userInfo.deptLevel4;
  // 반/섹션
  const deptLevel5 = profile.userInfo.deptLevel5;

  // 오늘 날짜
  const toDate = CommonUtil.getToDate();

  const {
    detailInfo,
    formValue,
    getDetail,
    formType,
    cancel,
    goFormPage,
    clear,
    search,
    removeByIndex,
    execDeptChange,
    //goForm,
    changeInput,
    errors,
    // 추진팀
    execDeptSaveStrore,
    execDeptAddRowStore,
    deleteExecDeptList,
    // 공정
    deleteProcList,
    procChange,
    procAddRowStore,
    procSaveStrore,
    saveUseOcuRiskTab1,
    openFormModal,
    isCodeFormModalOpen,
    closeFormModal,
    okModal,
    isDirty,
    initAddChk,

    saveAll,

    // 청취조사 list
    setSelectedPlaceIndex,
    selectedPlaceIndex,
    getPlaceColumn,
    setPlaceColumn,
    getPlaceError,
    addPlaceRow,
    delPlaceRow,

    // 현장조사 list
    setSelectedItemIndex,
    selectedItemIndex,
    getItemColumn,
    setItemColumn,
    getItemError,
    addItemRow,
    delItemRow,
  } = useOcuRiskTab1FormStore();

  const { detailId } = useParams();

  const copyChk = useOcuRiskTab1FormStore.getState().tab1CopyChk;

  // 입력 및 복사인 경우
  if (detailId === 'add' || copyChk == 'Y') {
    // 작성자
    // formValue.regUserId = nameKor;

    // 작성자
    formValue.regUserNm = nameKor;

    // 작성일자
    formValue.regDttm = toDate;
    // 작성자 부문 코드
    formValue.authorSectCd = sectCd;
    // 작성자 부서 코드
    formValue.authorDeptDeptCd = deptLevel2;
    // 작성자 팀 코드
    formValue.authorDeptTeamCd = deptLevel3;
    // 작성자 그룹 코드
    formValue.authorDeptGroupCd = deptLevel4;
    // 작성자 반/섹션 코드
    formValue.authorDeptClassCd = deptLevel5;
    // 작성자 그룹 코드
    formValue.authorDeptCd = deptCd;
    // formValue.authorDeptCd = deptCd;
  }

  // useFormDirtyCheck(isDirty);

  // 추진팀 구성 행 삭제
  const DeleteActionButton = (props) => {
    const { node, onClick } = props;
    const { rowIndex } = node;

    const handleClick = (event) => {
      // 추진팀 구성 삭제 list전달
      event.stopPropagation();
      event.preventDefault();
      event.nativeEvent.stopPropagation();
      onClick(rowIndex);
    };
    return <div onClick={handleClick}>삭제</div>;
  };

  // 공정 행 삭제
  const DeleteActionButton2 = (props) => {
    const { node, onClick } = props;
    const { rowIndex } = node;

    const handleClick2 = (event) => {
      // 공정 삭제 list전달
      event.stopPropagation();
      event.preventDefault();
      event.nativeEvent.stopPropagation();
      onClick(rowIndex);
    };
    return <div onClick={handleClick2}>삭제</div>;
  };

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      // { field: 'execTeamClsNm', headerName: '구분', flex: 1 },
      { field: '_status', headerName: '상태', editable: true, flex: 1 },
      {
        field: 'execTeamClsCd',
        headerName: '구분',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC020',
        },
      },

      { field: 'execTeamNm', headerName: '이름', flex: 1 },
      // { field: 'execTeamPosCd', headerName: '직책', flex: 1 },
      {
        field: 'execTeamPosCd',
        headerName: '직책',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC021',
        },
      },
      //  추후에 따로 부서 조회
      { field: 'execTeamDeptCd', headerName: '부서', flex: 1 },

      { field: 'execTeamCompNm', headerName: '업체', flex: 1 },
      {
        pinned: 'right',
        field: 'action',
        headerName: '',
        //flex: 1,
        // flex: 1,
        cellRenderer: 'deleteActionButton',
        cellRendererParams: {
          onClick: delPlaceRow,
        },
      },
    ])
  );

  const [columns2, setColumns2] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: '_status', headerName: '상태', editable: true, flex: 1 },
      { field: 'procNm', headerName: '공정명', flex: 1 },
      {
        pinned: 'right',
        field: 'action',
        headerName: '',
        //flex: 1,
        flex: 1,
        cellRenderer: 'deleteActionButton2',
        cellRendererParams: {
          onClick: delItemRow,
        },
      },
      //{ field: 'execTeamPosCd', headerName: '삭제', flex: 1 },
      // {
      //   pinned: 'right',
      //   field: 'action',
      //   headerName: '삭제',
      //   // flex: 1,
      //   cellRenderer: 'deleteActionButton',
      //   cellRendererParams: {
      //     onClick: removeByIndex,
      //   },
      //},
    ])
  );

  // 추진팀 구성 버튼
  const customButtons1 = [
    {
      title: '추가',
      onClick: () => {
        addPlaceRow();
      },
    },
  ];

  // 공정 정보 버튼
  const customButtons2 = [
    {
      title: '추가',
      onClick: () => {
        addItemRow();
      },
    },
  ];

  // // 추진팀 행 추가
  // const execDeptAddRow = () => {
  //   console.log('로우 추가');
  //   setColumns((prevColumns) => [...prevColumns]);

  //   // 구분
  //   formValue.execTeamClsCd = '';
  //   // 이름
  //   formValue.execTeamNm = '';
  //   // 사번
  //   formValue.execTeamEmpno = '';
  //   // 부문
  //   formValue.execTeamSectCd = '';
  //   // 부서
  //   formValue.execTeamDeptCd = '';
  //   // 업체
  //   formValue.execTeamCompNm = '';
  //   // 직책
  //   formValue.execTeamPosCd = '';

  //   execDeptAddRowStore();
  // };

  // // 공정 행 추가
  // const procAddRow = () => {
  //   console.log('로우 추가');
  //   setColumns((prevColumns) => [...prevColumns]);

  //   // 공정명
  //   formValue.procNm = '';

  //   proc.procAddRowStore();
  // };

  // const init = async () => {
  //   // baseInfo.list = null;
  //   // proc.list = null;

  //   getDetail(detailId);
  //   search();
  // };

  const addChk = async () => {
    initAddChk();
  };

  const init = async () => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else {
      addChk();
    }
    // search();
  };

  useEffect(() => {
    init();
    return clear;
  }, []);

  // 첫번째 행 선택
  useEffect(() => {
    if (formValue?.execDeptInfoList && formValue.execDeptInfoList.length > 0 && selectedPlaceIndex === -1) {
      const firstRow = formValue.execDeptInfoList[0];
      handleRowSingleClick({ data: firstRow, rowIndex: 0 });
    }

    if (formValue?.processInfoList && formValue.processInfoList.length > 0 && selectedItemIndex === -1) {
      const firstRow = formValue.processInfoList[0];
      handleRowSingleClick2({ data: firstRow, rowIndex: 0 });
    }
  }, [formValue, selectedPlaceIndex, selectedItemIndex]);

  const handleRowSingleClick = useCallback(
    (selectedInfo) => {
      setSelectedPlaceIndex(selectedInfo.rowIndex);
    },
    [selectedPlaceIndex]
  );

  const handleRowSingleClick2 = useCallback(
    (selectedInfo) => {
      console.log('selectedInfo==>', selectedInfo);
      setSelectedItemIndex(selectedInfo.rowIndex);
    },
    [selectedItemIndex]
  );

  // // 추진팀 구분 값 변경
  // const changeExecClsCd = (v, data) => {
  //   // 초기화
  //   setColumns((prevColumns) => [...prevColumns]);

  //   // 이름
  //   formValue.execTeamNm = '';
  //   // 사번
  //   formValue.execTeamEmpno = '';
  //   // 부문
  //   formValue.execTeamSectCd = '';
  //   // 부서
  //   formValue.execTeamDeptCd = '';
  //   // 부서
  //   formValue.execTeamDeptNm = '';
  //   // 업체
  //   formValue.execTeamCompNm = '';
  //   // 직책
  //   formValue.execTeamPosCd = '';
  //   // 직책명
  //   formValue.execTeamPosNm = '';

  //   formValue.execTeamClsNm = data.label;

  //   // changeInput('execTeamDeptCd', '');
  //   changeInput('execTeamClsCd', v);
  // };

  // // 추진팀 직책 값 변경
  // const changeExecTeamPosCd = (v, data) => {
  //   formValue.execTeamPosNm = data.label;
  //   changeInput('execTeamPosCd', v);
  // };

  // // 추진팀 구성 행 변경
  // const handleRowSingleClick = useCallback((selectedInfo) => {
  //   // const { rowIndex } = props;

  //   console.log('selectedInfo==>', selectedInfo);

  //   setColumns((prevColumns) => [...prevColumns]);
  //   execDeptChange(selectedInfo.data, selectedInfo.rowIndex);
  // }, []);

  // // 공정 행 변경
  // const handleRowSingleClick2 = useCallback((selectedInfo) => {
  //   // const { rowIndex } = props;

  //   console.log('selectedInfo==>', selectedInfo);

  //   setColumns((prevColumns) => [...prevColumns]);
  //   proc.procChange(selectedInfo.data, selectedInfo.rowIndex);
  // }, []);

  // // 추진팀 구성 저장
  // const execDeptSave = () => {
  //   setColumns((prevColumns) => [...prevColumns]);

  //   const execData = {
  //     // 구분
  //     execTeamClsCd: execTeamClsCd,

  //     // 구분명
  //     execTeamClsNm: execTeamClsNm,
  //     // 이름
  //     execTeamNm: execTeamNm,
  //     // 사번
  //     execTeamEmpno: execTeamEmpno,
  //     // 부문
  //     execTeamSectCd: execTeamSectCd,

  //     // 부서
  //     execTeamDeptCd: execTeamDeptCd,
  //     // 업체
  //     execTeamCompNm: execTeamCompNm,
  //     // 직책
  //     execTeamPosCd: execTeamPosCd,
  //     // 직책명
  //     execTeamPosNm: execTeamPosNm,
  //   };

  //   execDeptSaveStrore(execData);
  // };

  // // 공정 저장
  // const procSave = () => {
  //   setColumns((prevColumns) => [...prevColumns]);

  //   const procData = {
  //     // 공정
  //     procNm: procNm,
  //   };

  //   proc.procSaveStrore(procData);
  // };

  // 추진팀 구성 성명 변경 시 대입
  const changeExecTeamNm = (v, data) => {
    console.log('대입:', data);

    // setColumns((prevColumns) => [...prevColumns]);

    // // 사번
    // formValue.execTeamEmpno = data.empNo;
    // // 부문
    // formValue.execTeamSectCd = data.sectCd;
    // // 부서
    // formValue.execTeamDeptCd = data.deptCd;

    // console.log('데이터값===> ', data.sectCd);

    // changeInput('execTeamEmpno', data.empNo);
    // changeInput('execTeamSectCd', data.sectCd);
    // changeInput('execTeamDeptCd', data.deptCd);
    // changeInput('execTeamNm', v);

    setPlaceColumn('execTeamEmpno', data.empNo);
    setPlaceColumn('execTeamSectCd', data.sectCd);
    setPlaceColumn('execTeamDeptCd', data.deptCd);
    setPlaceColumn('execTeamNm', v);

    // changeInput('execTeamNm', v);
  };

  // 평가 시기 도움말 팝업
  const helpPeriod = () => {
    openFormModal(null);
  };

  useFormDirtyCheck(isDirty);

  // // 복사하기
  // const copyReval = () => {
  //   console.log('복사하기');
  // };
  return (
    <>
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              기본 사항<span className="active"></span>
              {/*평가시기 - 팝업 */}
              <div className="tag-info-wrap-end">
                {/* <button
                  type="button"
                  name="button"
                  className="btn_text text_color_neutral-10 btn_confirm"
                  onClick={copyReval}
                >
                  복사하기 */}
                {/* </button> */}
                <div className="tip" onClick={helpPeriod}>
                  <div>
                    <a href="javascript:test(0);" className="txt" onClick={helpPeriod}>
                      평가시기
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="작성자"
                          disabled
                          value={formValue.regUserNm}
                          onChange={(value) => changeInput('regUserNm', value)}
                          errorMessage={errors.regUserNm}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="작성일자"
                          disabled
                          value={formValue.regDttm}
                          onChange={(value) => changeInput('regDttm', value)}
                          required
                          // value={regDttm}
                          // onChange={(value) => changeInput('regDttm', value)}
                          // errorMessage={errors.regDttm}
                          errorMessage={errors.regDttm}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="부문"
                          codeGrpId="CODE_GRP_OC001"
                          value={formValue.authorSectCd}
                          onChange={(value) => changeInput('authorSectCd', value)}
                          errorMessage={errors.authorSectCd}
                          disabled
                          // value={detailId === 'add' ? sectCd : formValue.authorSectCd}
                          // onChange={(value) => changeInput(detailId === 'add' ? 'sectCd' : 'authorSectCd', value)}
                          // errorMessage={detailId === 'add' ? errors.sectCd : errors.authorSectCd}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput */}
                        <AppDeptSelectInput
                          label="부서"
                          value={formValue.authorDeptDeptCd}
                          onChange={(value) => changeInput('authorDeptDeptCd', value)}
                          disabled

                          // value={detailId === 'add' ? deptLevel2 : formValue.authorDeptCd}
                          // onChange={(value) => changeInput(detailId === 'add' ? 'deptLevel2' : 'authorDeptCd', value)}
                          // disabled
                          // errorMessage={detailId === 'add' ? errors.deptLevel2 : errors.authorDeptCd}
                          // disabled={formType !== 'add' ? true : false}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="팀" disabled /> */}
                        <AppDeptSelectInput
                          label="팀"
                          value={formValue.authorDeptTeamCd}
                          onChange={(value) => changeInput('authorDeptTeamCd', value)}
                          disabled
                          // errorMessage={detailId === 'add' ? errors.deptLevel3 : errors.execTeamDeptCd}
                          // disabled={formType !== 'add' ? true : false}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDeptSelectInput
                          label="그룹"
                          value={formValue.authorDeptGroupCd}
                          onChange={(value) => changeInput('authorDeptGroupCd', value)}
                          // errorMessage={detailId === 'add' ? errors.deptLevel4 : errors.execTeamDeptCd}
                          disabled
                          // disabled={formType !== 'add' ? true : false}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDeptSelectInput
                          label="반/섹션"
                          value={formValue.authorDeptClassCd}
                          onChange={(value) => changeInput('authorDeptClassCd', value)}
                          // errorMessage={detailId === 'add' ? errors.deptLevel5 : errors.execTeamDeptCd}
                          disabled
                          // disabled={formType !== 'add' ? true : false}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label="평가년도"
                          id="rEvalYear"
                          // id={`${formName}advCmitImplmYm`}
                          pickerType="year"
                          value={formValue.revalYear}
                          onChange={(value) => {
                            changeInput('revalYear', value);
                          }}
                          required
                          errorMessage={errors.revalYear}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="평가시기"
                          codeGrpId="CODE_GRP_OC019"
                          value={formValue.revalPeriod}
                          id="revalPeriod"
                          onChange={(value) => changeInput('revalPeriod', value)}
                          required
                          errorMessage={errors.revalPeriod}
                        />
                      </div>
                    </div>

                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSearchInput
                          label="재해발생보고서"
                          disabled={formValue.revalPeriod !== 'C' ? true : false}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label="평가시작일"
                          id="evalStartDt"
                          value={formValue.evalStartDt}
                          onChange={(value) => changeInput('evalStartDt', value)}
                          required
                          errorMessage={errors.evalStartDt}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label="평가종료일"
                          id="evalEndDt"
                          value={formValue.evalEndDt}
                          onChange={(value) => changeInput('evalEndDt', value)}
                          required
                          errorMessage={errors.evalEndDt}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid70">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="제목"
                          id="revalTitle"
                          value={formValue.revalTitle}
                          onChange={(value) => {
                            changeInput('revalTitle', value);
                          }}
                          required
                          errorMessage={errors.revalTitle}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid30">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="문서번호"
                          id="revalDocNo"
                          value={formValue.revalDocNo}
                          onChange={(value) => {
                            changeInput('revalDocNo', value);
                          }}
                          required
                          disabled
                          errorMessage={errors.revalDocNo}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="ck-edit-box">
                        <div className="ck-list">
                          <h3 className="table-tit">추진팀 구성</h3>
                          {/* 그리드영역 */}
                          <AppTable
                            // rowData={baseInfo.list}
                            rowData={formValue.execDeptInfoList || []}
                            columns={columns}
                            setColumns={setColumns}
                            handleRowSingleClick={handleRowSingleClick}
                            customButtons={customButtons1}
                            hiddenPagination
                            components={{
                              deleteActionButton: DeleteActionButton,
                            }}
                            getRowStyle={(params) => {
                              const { data, rowIndex } = params;
                              if (rowIndex === selectedPlaceIndex) {
                                return { background: '#d6d9eb' };
                              } else if (data._isError) {
                                return { background: '#ebb2b2' };
                              }
                            }}
                          />
                        </div>
                        <div className="ck-edit">
                          <div className="boxForm">
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  <AppCodeSelect
                                    label="구분"
                                    codeGrpId="CODE_GRP_OC020"
                                    // value={execTeamClsCd}
                                    // onChange={(value, data) => changeExecClsCd(value, data)}
                                    // changeInput('execTeamClsCd', value)}
                                    value={getPlaceColumn('execTeamClsCd')}
                                    onChange={(value) => setPlaceColumn('execTeamClsCd', value)}
                                    errorMessage={getPlaceError('execTeamClsCd')}
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {getPlaceColumn('execTeamClsCd') === 'A' ? (
                                    <AppUserSelectInput
                                      label="이름"
                                      // value={execTeamNm}
                                      onChange={
                                        (value, data) => changeExecTeamNm(value, data)
                                        // changeInput('execTeamNm', value)
                                      }
                                      value={getPlaceColumn('execTeamNm')}
                                      // onChange={(value) => setPlaceColumn('execTeamNm', value)}
                                      errorMessage={getPlaceError('execTeamNm')}
                                      disabled
                                      required
                                    />
                                  ) : (
                                    <AppSearchInput
                                      label="이름"
                                      value={getPlaceColumn('execTeamNm')}
                                      onChange={(value) => setPlaceColumn('execTeamNm', value)}
                                      errorMessage={getPlaceError('execTeamNm')}
                                      required
                                      // value={formValue.execTeamNm}
                                      // onChange={(value) => changeInput('execTeamNm', value)}
                                    />
                                  )}
                                  {/* <AppUserSelectInput
                                    label="이름"
                                    value={execTeamNm}
                                    onChange={(value) => changeInput('execTeamNm', value)}
                                    disabled
                                    errorMessage={errors.execTeamNm}
                                  /> */}
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  <AppSearchInput
                                    label="사번"
                                    // value={execTeamEmpno}
                                    // onChange={(value) => {
                                    //   changeInput('execTeamEmpno', value);
                                    // }}
                                    value={getPlaceColumn('execTeamEmpno')}
                                    onChange={(value) => setPlaceColumn('execTeamEmpno', value)}
                                    errorMessage={getPlaceError('execTeamEmpno')}
                                    disabled
                                    required
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  <AppCodeSelect
                                    label="부문"
                                    codeGrpId="CODE_GRP_OC001"
                                    // value={execTeamSectCd}
                                    // onChange={(value) => {
                                    //   changeInput('execTeamSectCd', value);
                                    // }}

                                    value={getPlaceColumn('execTeamSectCd')}
                                    onChange={(value) => setPlaceColumn('execTeamSectCd', value)}
                                    errorMessage={getPlaceError('execTeamSectCd')}
                                    disabled
                                    required
                                    // disabled={execTeamClsCd === 'A' ? true : false}
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {/* <AppDeptSelectInput */}
                                  <AppSearchInput
                                    label="부서"
                                    // value={execTeamDeptCd}
                                    // onChange={(value) => {
                                    //   changeInput('execTeamDeptCd', value);
                                    // }}

                                    value={getPlaceColumn('execTeamDeptCd')}
                                    onChange={(value) => setPlaceColumn('execTeamDeptCd', value)}
                                    errorMessage={getPlaceError('execTeamDeptCd')}
                                    disabled
                                    required
                                    //readonly={execTeamClsCd !== 'A' ? true : false}
                                    // disabled={execTeamClsCd === 'A' ? true : false}
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  <AppSearchInput
                                    label="업체"
                                    // value={execTeamCompNm}
                                    // onChange={(value) => {
                                    //   changeInput('execTeamCompNm', value);
                                    // }}

                                    value={getPlaceColumn('execTeamCompNm')}
                                    onChange={(value) => setPlaceColumn('execTeamCompNm', value)}
                                    errorMessage={getPlaceError('execTeamCompNm')}
                                    // disabled={execTeamClsCd === 'A' ? true : false}
                                    disabled={getPlaceColumn('execTeamClsCd') === 'A' ? true : false}
                                    required
                                    //disabled
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  <AppCodeSelect
                                    label="직책"
                                    codeGrpId="CODE_GRP_OC021"
                                    // value={execTeamPosCd}
                                    // onChange={(value, data) => changeExecTeamPosCd(value, data)}

                                    value={getPlaceColumn('execTeamPosCd')}
                                    onChange={(value) => setPlaceColumn('execTeamPosCd', value)}
                                    errorMessage={getPlaceError('execTeamPosCd')}
                                    required
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="btn-area-type01 mg-top">
                              {/* <button
                                type="button"
                                name="button"
                                className="btn_text btn_confirm"
                                // onClick={execDeptSave}
                              >
                                저장
                              </button> */}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              안전보건 정보 수집<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="근로자수"
                          inputType="number"
                          value={formValue.emplCnt}
                          onChange={(value) => {
                            changeInput('emplCnt', value);
                          }}
                          errorMessage={errors.emplCnt}
                          // value={getItemColumn('emplCnt')}
                          // onChange={(value) => setItemColumn('emplCnt', value)}
                          // errorMessage={getItemError('emplCnt')}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="근무형태"
                          value={formValue.workForm}
                          onChange={(value) => {
                            changeInput('workForm', value);
                          }}
                          errorMessage={errors.workForm}
                          // value={getItemColumn('workForm')}
                          // onChange={(value) => setItemColumn('workForm', value)}
                          // errorMessage={getItemError('workForm')}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <h3>다음 각 호의 사항을 조사하여 위험성평가에 활용한다.</h3>
                      <div>
                        <ul className="list-input-box">
                          <li>
                            <span className="list-tit">1. 산업재해 및 아차사고 발생 사례 (5개년 이상)</span>
                            <AppTextInput
                              label=""
                              value={formValue.revalItem1}
                              onChange={(value) => {
                                changeInput('revalItem1', value);
                              }}
                              // errorMessage={errors.revalItem1}
                            />
                          </li>
                          <li>
                            <span className="list-tit">2. 설비, 기계, 기구 보유 현황</span>
                            <AppTextInput
                              label=""
                              value={formValue.revalItem2}
                              onChange={(value) => {
                                changeInput('revalItem2', value);
                              }}
                              // errorMessage={errors.revalItem2}
                            />
                          </li>
                          <li>
                            <span className="list-tit">3. 작업표준서, 작업절차</span>
                            <AppTextInput
                              label=""
                              value={formValue.revalItem3}
                              onChange={(value) => {
                                changeInput('revalItem3', value);
                              }}
                              // errorMessage={errors.revalItem3}
                            />
                          </li>
                          <li>
                            <span className="list-tit">4. 협력사 혼재작업 시 위험성 및 작업상황 정보</span>
                            <AppTextInput
                              label=""
                              value={formValue.revalItem4}
                              onChange={(value) => {
                                changeInput('revalItem4', value);
                              }}
                              // errorMessage={errors.revalItem4}
                            />
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="ck-edit-box">
                        <div className="ck-list">
                          <h3 className="table-tit">평가항목 선정</h3>
                          {/* 그리드영역 */}
                          <AppTable
                            // rowData={proc.list}
                            rowData={formValue.processInfoList || []}
                            columns={columns2}
                            setColumns={setColumns2}
                            handleRowSingleClick={handleRowSingleClick2}
                            // store={proc}
                            customButtons={customButtons2}
                            hiddenPagination
                            components={{
                              deleteActionButton2: DeleteActionButton2,
                            }}
                            getRowStyle={(params) => {
                              const { data, rowIndex } = params;
                              if (rowIndex === selectedPlaceIndex) {
                                return { background: '#d6d9eb' };
                              } else if (data._isError) {
                                return { background: '#ebb2b2' };
                              }
                            }}
                          />
                        </div>
                        <div className="ck-edit">
                          <div className="boxForm">
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  <AppSearchInput
                                    label="공정명"
                                    value={getItemColumn('procNm')}
                                    onChange={(value) => setItemColumn('procNm', value)}
                                    errorMessage={getItemError('procNm')}
                                    // value={procNm}
                                    // onChange={(value) => {
                                    //   changeInput('procNm', value);
                                    // }}
                                    // errorMessage={errors.procNm}
                                  />
                                </div>
                              </div>
                            </div>

                            <div className="btn-area-type01 mg-top">
                              {/* <button type="button" name="button" className="btn_text btn_confirm">
                                저장
                              </button> */}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="ck-edit-box">
                        <div className="ck-list">
                          <h3 className="table-tit">평가항목 선정</h3>
                          {/* 그리드영역 */}
                  {/* <AppTable
                            rowData={execDept.list}
                            columns={columns2}
                            setColumns={setColumns2}
                            store={execDept}
                            customButtons={customButtons2}
                            hiddenPagination
                            components={{
                              deleteActionButton2: DeleteActionButton2,
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </div> */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <h3 className="table-tit">참여자 교육</h3>
                      <span>다음 각 호의 사항을 조사하여 위험성평가에 활용한다.</span>
                      <ul className="guide-list">
                        <li>1. 위험성평가 대상 공정 선정 및 Process에 관한 사항</li>
                        <li>2. 역할별 임무 안내(책임자, 관리감독자, 작업자, 안전보건조직 등)</li>
                        <li>3. 위험성평가 방법 안내(유해위험요인파악, 감소대책 수립 및 참여 방법 등)</li>
                        <li>4. 안전보건정보 수집 및 활용 방법</li>
                      </ul>
                    </div>
                  </div>
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <h3 className="table-tit mb-10">준비관련 첨부 문서</h3>
                      <div className="form-group wid100">
                        <AppFileAttach
                          mode="edit"
                          label="파일첨부"
                          // fileGroupSeq={prepareRelFileId}
                          fileGroupSeq={getItemColumn('prepareRelFileId')}
                          workScope={'O'}
                          updateFileGroupSeq={(newFileGroupSeq) => {
                            // changeInput('prepareRelFileId', newFileGroupSeq);
                            setItemColumn('prepareRelFileId', newFileGroupSeq);
                          }}
                        />

                        {/* <AppFileAttach
                          mode="view"
                          // fileGroupSeq={prepareRelFileId}
                          workScope={'O'}
                          // onlyImageUpload={true}
                          useDetail
                          disabled
                        /> */}
                        {/* <div className="filebox "> */}
                        {/* <Upload {...props}>
                            <div className="btn-area">
                              <button type="button" name="button" className="btn-big btn_text btn-darkblue-line mg-n">
                                + Upload
                              </button>
                            </div>
                          </Upload>
                          <label htmlFor="file" className="file-label">
                            파일 첨부 <span className="required">*</span>
                          </label> */}
                        {/* </div> */}
                        {/*<span className="errorText">fileerror</span>*/}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      <RiskHelpPeriodModal isOpen={isCodeFormModalOpen} closeModal={closeFormModal} ok={okModal} />
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        {/* <button className="btn_text text_color_darkblue-100 btn_close">
          복사하기

        </button> */}
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={saveAll}
          // style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          저장
        </button>
        {/* <button type="button" name="button" className="btn_text btn-del">
          삭제
        </button> */}
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
      </div>
    </>
  );
}
export default RevalFormTab1;
