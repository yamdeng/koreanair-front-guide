import { useEffect, useState } from 'react';
import AppEditor from '@/components/common/AppEditor';
import AppTextInput from '@/components/common/AppTextInput';
import { useParams } from 'react-router-dom';
//import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppCodeSelect from '@/components/common/AppCodeSelect';
/* TODO : store 경로를 변경해주세요. */
import useOcuHsCommitteeFormStore from '@/stores/occupation/general/useOcuHsCommitteeFormStore';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import LinkAttachModal from '@/components/modal/LinkAttachModal';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';

const formName = 'HsCommitteeForm';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuHsCommitteeForm() {
  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    formValue,
    getDetail,
    formType,
    cancel,
    save,
    remove,
    clear,
    isDirty,
    openLinkAttachModal,
    isLinkAttachModalOpen,
    closeLinkAttachModal,
    linkAttachDetailInfo,
    okLinkAttachModal,
    removeLinkAttach,
    linkAttachListLindex,
  } = useOcuHsCommitteeFormStore();
  const {
    // 본부
    advCmitSectCd,
    // 부서
    advCmitDeptCd,
    // 팀
    advCmitTeamCd,
    // 그룹
    advCmitGroupCd,
    // 작성자
    regUserNm,
    // 작성일자
    regDttm,
    // 해당연월
    advCmitImplmYm,
    // 제목
    advCmitTitle,
    // 내용
    advCmitRemark,

    // 회의록
    prcdnFileId,
    // 회의자료
    meetDocFileId,
    // 보고문서
    //reportDocLinkId,
    // 링크 첨부 리스트
    linkAttachList,

    advCmitDeptCdView,

    // advCmitId,
  } = formValue;
  const { detailId } = useParams();

  const profile = useStore(useAppStore, (state) => state.profile);
  // 사용자명
  const nameKor = profile.userInfo.nameKor;

  // 부문
  const sectCd = profile.userInfo.sectCd;

  // 부서
  const deptCd = profile.userInfo.deptCd;

  // 부서
  const deptLevel2 = profile.userInfo.deptLevel2;
  // 팀
  const deptLevel3 = profile.userInfo.deptLevel3;
  // 그룹
  const deptLevel4 = profile.userInfo.deptLevel4;
  // 반/섹션
  const deptLevel5 = profile.userInfo.deptLevel5;

  console.log('deptLevel2===>', deptLevel2);
  console.log('deptLevel3===>', deptLevel3);
  console.log('advCmitDeptCdView===>', advCmitDeptCdView);

  // 오늘 날짜
  const toDate = CommonUtil.getToDate();

  const [isOrgSelectModalopen, setIsOrgSelectModalopen] = useState(false);

  const handleOrgSelectModal = (selectedValue) => {
    console.log(selectedValue);
    setIsOrgSelectModalopen(false);
  };

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  // useFormDirtyCheck(isDirty);

  // 입력인 경우
  if (detailId === 'add') {
    // 작성자
    formValue.regUserId = nameKor;
    // 작성일자
    formValue.regDttm = toDate;
    // 작성자 부문 코드
    formValue.advCmitSectCd = sectCd;
    // 작성자 실제 부서 코드
    formValue.advCmitDeptCd = deptCd;

    // 작성자 부서 코드
    formValue.advCmitDeptCdView = deptLevel2;
    // 작성자 팀 코드
    formValue.advCmitTeamCd = deptLevel3;
    // 작성자 그룹 코드
    formValue.advCmitGroupCd = deptLevel4;
  }

  console.log('detailId==>', detailId);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>안전보건협의체</h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'부문'}
                codeGrpId="CODE_GRP_OC001"
                value={advCmitSectCd}
                onChange={(value) => changeInput('advCmitSectCd', value)}
                required
                disabled
                errorMessage={errors.advCmitSectCd}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDeptSelectInput
                label={'부서'}
                value={advCmitDeptCdView}
                onChange={(value) => changeInput('advCmitDeptCdView', value)}
                required
                disabled
                errorMessage={errors.advCmitDeptCdView}
              />

              {/* <OrgTreeSelectModal
                label={'부서'}
                isOpen={isOrgSelectModalopen}
                closeModal={() => setIsOrgSelectModalopen(false)}
                isMultiple={false}
                ok={handleOrgSelectModal}
              /> */}
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDeptSelectInput
                label={'팀'}
                value={advCmitTeamCd}
                onChange={(value) => changeInput('advCmitTeamCd', value)}
                required
                disabled
                errorMessage={errors.advCmitTeamCd}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDeptSelectInput
                label={'그룹'}
                value={advCmitGroupCd}
                onChange={(value) => changeInput('advCmitGroupCd', value)}
                required
                disabled
                errorMessage={errors.advCmitGroupCd}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="작성자"
                //value= {regUserId}
                value={detailId === 'add' ? nameKor : regUserNm}
                //onChange={(value) => changeInput('regUserId', value)}
                onChange={(value) => changeInput(detailId === 'add' ? 'nameKor' : 'regUserNm', value)}
                required
                disabled="false"
                // errorMessage={errors.regUserId}
                errorMessage={detailId === 'add' ? errors.nameKor : errors.regUserNm}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                disabled
                label="작성일자"
                // value={regDttm}
                value={detailId === 'add' ? toDate : regDttm}
                // onChange={(value) => changeInput('regDttm', value)}
                onChange={(value) => changeInput(detailId === 'add' ? 'toDate' : 'regDttm', value)}
                required
                // errorMessage={errors.regDttm}
                errorMessage={detailId === 'add' ? errors.toDate : errors.regDttm}
              />
            </div>
          </div>

          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDatePicker
                id={`${formName}advCmitImplmYm`}
                label={'해당연월'}
                pickerType="month"
                value={advCmitImplmYm}
                onChange={(value) => {
                  changeInput('advCmitImplmYm', value);
                }}
                required
                errorMessage={errors.advCmitImplmYm}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id={`${formName}advCmitTitle`}
                label="제목"
                value={advCmitTitle}
                onChange={(value) => changeInput('advCmitTitle', value)}
                required
                errorMessage={errors.advCmitTitle}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppEditor
                placeholder="입력해주세요."
                value={advCmitRemark}
                onChange={(value) => changeInput('advCmitRemark', value)}
                required
                errorMessage={errors.advCmitRemark}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppFileAttach
                mode="edit"
                label="회의록 업로드(pdf, 그림파일)"
                fileGroupSeq={prcdnFileId}
                workScope={'O'}
                maxCount={1}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('prcdnFileId', newFileGroupSeq);
                }}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppFileAttach
                mode="edit"
                label="회의자료 업로드(ppt)"
                fileGroupSeq={meetDocFileId}
                workScope={'O'}
                onlyImageUpload={false}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('meetDocFileId', newFileGroupSeq);
                }}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="group-box-wrap line wid100">
              <span className="txt">보고문서 Link</span>

              {/* 링크팝업명: MU1P5detail2Modal */}
              <button type="button" name="button" className="btn-plus" onClick={() => openLinkAttachModal()}>
                추가
              </button>
              <div className="file-link">
                {linkAttachList
                  ? linkAttachList.map((linkInfo, linkAttachListLindex) => {
                      const { linkUrl, linkSbj } = linkInfo;
                      return (
                        <div key={linkUrl} className="link-box">
                          <a href={undefined} onClick={() => openLinkAttachModal(linkInfo, linkAttachListLindex)}>
                            {linkSbj}
                          </a>
                          <a href={undefined} onClick={() => removeLinkAttach(linkAttachListLindex)}>
                            <span className="close-btn">close</span>
                          </a>
                        </div>
                      );
                    })
                  : null}
              </div>

              {/* <button type="button" name="button" className="btn-plus">
                추가
              </button>
              <div className="file-link">
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link첨부Link첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
              </div> */}
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <LinkAttachModal
          isOpen={isLinkAttachModalOpen}
          closeModal={closeLinkAttachModal}
          ok={okLinkAttachModal}
          detailInfo={linkAttachDetailInfo}
          linkAttachListLindex={linkAttachListLindex}
        />
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuHsCommitteeForm;
