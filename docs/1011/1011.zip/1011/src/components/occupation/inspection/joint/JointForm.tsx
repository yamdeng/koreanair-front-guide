import { useState, useEffect, useCallback } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import CommonUtil from '@/utils/CommonUtil';
import AppTextInput from '@/components/common/AppTextInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppTable from '@/components/common/AppTable';
import AppTextArea from '@/components/common/AppTextArea';
import useOcuCheckInfoFormStore from '@/stores/occupation/inspection/useOcuCheckInfoFormStore';
import { Image, Upload } from 'antd';
import { PlusOutlined } from '@ant-design/icons';

const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const props: any = {
  name: 'file',
  multiple: true,
  defaultFileList: [
    {
      uid: '1',
      name: 'xxx.png',
      // status: 'uploading',
      url: 'http://www.baidu.com/xxx.png',
      percent: 33,
    },
    {
      uid: '2',
      name: 'yyy.png',
      status: 'done',
      url: 'http://www.baidu.com/yyy.png',
    },
  ],
  action: 'https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload',

  onChange(info) {
    const { status } = info.file;
    if (status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (status === 'done') {
      alert(`${info.file.name} file uploaded successfully.`);
    } else if (status === 'error') {
      alert(`${info.file.name} file upload failed.`);
    }
  },

  onDrop(e) {
    console.log('Dropped files', e.dataTransfer.files);
  },
};

const DeleteActionButton = (props) => {
  const { node, onClick } = props;
  const { rowIndex } = node;
  const handleClick = (event) => {
    event.stopPropagation();
    event.preventDefault();
    event.nativeEvent.stopPropagation();
    onClick(rowIndex);
  };
  return <div onClick={handleClick}>삭제</div>;
};

function OcuCheckInfoForm() {
  const state = useOcuCheckInfoFormStore();
  const {
    selectedContentIndex,
    setSelectedContentIndex,
    setContentColumn,
    getContentColumn,
    getContentError,
    addContentRow,
    delContentRow,
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    save,
    remove,
    cancel,
    clear,
  } = state;
  const { detailId } = useParams();
  const [OcuCheckInfoContentColumns, setOcuCheckInfokContentColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'status', headerName: 'status' },
      { field: 'chkClsCd', headerName: '점검분류' },
      { field: 'chkItemNm', headerName: '점검항목' },
      { field: 'chkResultCd', headerName: '점검결과' },
      { field: 'chkLclsCd', headerName: '대분류' },
      { field: 'chkScls', headerName: '소분류' },
      {
        field: 'action',
        headerName: '삭제',
        cellRenderer: 'deleteActionButton',
        cellRendererParams: {
          onClick: delContentRow,
        },
      },
    ])
  );

  useFormDirtyCheck(isDirty);

  const handleRowDoubleClick_OcuCheckInfokContentColumns = useCallback(
    (selectedInfo) => {
      const { rowIndex } = selectedInfo;

      if (rowIndex !== selectedContentIndex) {
        setSelectedContentIndex(rowIndex);
      }
    },
    [formValue, selectedContentIndex]
  );

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  const [inputValue, setInputValue] = useState('');
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [fileList, setFileList] = useState<any>([
    {
      uid: '-1',
      name: 'image.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
  ]);
  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };
  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
  const uploadButton = (
    <button
      style={{
        border: 0,
        background: 'none',
      }}
      type="button"
    >
      <PlusOutlined />
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </button>
  );

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>합동 안전 보건 점검</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'부문'}
                codeGrpId="CODE_GRP_OC001"
                value={formValue.sectCd !== undefined ? formValue.sectCd : 'DX'}
                disabled
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDeptSelectInput label={'부서'} value={formValue.deptCd} disabled />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput label={'점검자'} value={formValue.chkEmpno} disabled />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_OC038"
                id="OcuCheckInfoFormchkCls"
                name="chkCls"
                label="점검 구분"
                value={formValue.chkCls}
                errorMessage={errors.chkCls}
                disabled
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'시기'}
                codeGrpId="CODE_GRP_OC042"
                value={formValue.chkPeriodCd}
                onChange={(value) => changeInput('chkPeriodCd', value)}
                errorMessage={errors.chkPeriodCd}
                disabled
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'연도'}
                codeGrpId="CODE_GRP_OC042"
                value={formValue.chkYear}
                errorMessage={errors.chkYear}
                disabled
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDatePicker
                id="OcuCheckInfoFormchkRegDt"
                name="chkRegDt"
                label="점검일자"
                value={formValue.chkRegDt}
                errorMessage={errors.chkRegDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormchkTitle"
                name="chkTitle"
                label="점검_제목"
                value={formValue.chkTitle}
                errorMessage={errors.chkTitle}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckInfoFormremark"
                name="remark"
                label="비고"
                value={formValue.remark}
                onChange={(value) => changeInput('remark', value)}
                errorMessage={errors.remark}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* 사진첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="filebox error">
                <Upload
                  action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
                  listType="picture-card"
                  fileList={fileList}
                  onPreview={handlePreview}
                  onChange={handleChange}
                >
                  {fileList.length >= 2 ? null : uploadButton}
                </Upload>
                <label htmlFor="file" className="file-label">
                  사진첨부{/*<span className="required">*</span>*/}
                </label>
              </div>
              <span className="errorText">fileerror</span>
            </div>
            {previewImage && (
              <Image
                wrapperStyle={{
                  display: 'none',
                }}
                preview={{
                  visible: previewOpen,
                  onVisibleChange: (visible) => setPreviewOpen(visible),
                  afterOpenChange: (visible) => !visible && setPreviewImage(''),
                }}
                src={previewImage}
              />
            )}
          </div>
        </div>
        <hr className="line"></hr>

        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <Upload {...props}>
                <div className="btn-area">
                  <button type="button" name="button" className="btn-big btn_text btn-darkblue-line">
                    + Upload
                  </button>
                </div>
              </Upload>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/*//점검항목영역*/}
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="ck-edit-box pd-t0">
              <div className="ck-list">
                <span className="stit-btn">
                  <h3>점검항목</h3>
                </span>
                <AppTable
                  rowData={formValue.contentList || []}
                  columns={OcuCheckInfoContentColumns}
                  setColumns={setOcuCheckInfokContentColumns}
                  handleRowDoubleClick={handleRowDoubleClick_OcuCheckInfokContentColumns}
                  getRowStyle={(params) => {
                    const { data, rowIndex } = params;
                    if (rowIndex === selectedContentIndex) {
                      return { background: '#d6d9eb' };
                    } else if (data._isError) {
                      return { background: '#ebb2b2' };
                    }
                  }}
                  customButtons={[
                    {
                      title: '행 추가',
                      onClick: () => {
                        addContentRow();
                      },
                    },
                  ]}
                  components={{
                    deleteActionButton: DeleteActionButton,
                  }}
                  hiddenPagination
                />
              </div>
              <div className="ck-edit">
                <div className="boxForm">
                  <h3 className="table-tit mt-10">부적합 사항</h3>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="점검항목"
                          name="chkItemNm"
                          value={selectedContentIndex === -1 ? '' : getContentColumn('chkItemNm')}
                          onChange={(value) => setContentColumn(`chkItemNm`, value)}
                          errorMessage={getContentError('chkItemNm')}
                          disabled={selectedContentIndex === -1}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          codeGrpId="CODE_GRP_OC039"
                          label="대분류"
                          name="chkLclsCd"
                          value={getContentColumn('chkLclsCd')}
                          onChange={(value) => {
                            setContentColumn('chkLclsCd', value);
                          }}
                          errorMessage={getContentError('chkLclsCd')}
                          disabled={selectedContentIndex === -1}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="소분류"
                          codeGrpId="CODE_GRP_OC040"
                          name="chkScls"
                          value={getContentColumn('chkScls')}
                          onChange={(value) => {
                            setContentColumn('chkScls', value);
                          }}
                          errorMessage={getContentError('chkScls')}
                          disabled={selectedContentIndex === -1}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextArea
                          label="내용"
                          name="chkContent"
                          className="form-tag custom_textarea"
                          style={{ width: '100%' }}
                          value={getContentColumn('chkContent')}
                          onChange={(value) => {
                            setContentColumn('chkContent', value);
                          }}
                          errorMessage={getContentError('chkContent')}
                          disabled={selectedContentIndex === -1}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <textarea
                          id="testArea1"
                          className="form-tag custom_textarea"
                          style={{ width: '100%' }}
                          name="testArea1"
                          value={inputValue}
                          onChange={(event) => {
                            setInputValue(event.target.value);
                          }}
                        />
                        <label className="f-label" htmlFor="testArea1">
                          관계법령
                        </label>
                      </div>
                    </div>
                  </div>
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="filebox error">
                          <Upload
                            action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
                            listType="picture-card"
                            fileList={fileList}
                            onPreview={handlePreview}
                            onChange={handleChange}
                          >
                            {fileList.length >= 2 ? null : uploadButton}
                          </Upload>
                          <label htmlFor="file" className="file-label">
                            사진첨부{/*<span className="required">*</span>*/}
                          </label>
                        </div>
                        <span className="errorText">fileerror</span>
                      </div>
                      {previewImage && (
                        <Image
                          wrapperStyle={{
                            display: 'none',
                          }}
                          preview={{
                            visible: previewOpen,
                            onVisibleChange: (visible) => setPreviewOpen(visible),
                            afterOpenChange: (visible) => !visible && setPreviewImage(''),
                          }}
                          src={previewImage}
                        />
                      )}
                    </div>
                  </div>
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <Upload {...props}>
                          <div className="btn-area">
                            <button type="button" name="button" className="btn-big btn_text btn-darkblue-line">
                              + Upload
                            </button>
                          </div>
                        </Upload>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <span className="txt">즉시조치</span>
                        <div className="radio-wrap">
                          <label>
                            <input type="radio" />
                            <span>예</span>
                          </label>
                          <label>
                            <input type="radio" />
                            <span>아니오</span>
                          </label>
                        </div>
                      </div>
                    </div>

                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDeptSelectInput label="조치부서" />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDeptSelectInput label="승인부서" />
                      </div>
                    </div>
                  </div>
                  <h3 className="table-tit mt-10">조치사항</h3>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <textarea
                          id="testArea1"
                          className="form-tag custom_textarea"
                          style={{ width: '100%' }}
                          name="testArea1"
                          value={inputValue}
                          onChange={(event) => {
                            setInputValue(event.target.value);
                          }}
                        />
                        <label className="f-label" htmlFor="testArea1">
                          조치내용
                        </label>
                      </div>
                    </div>
                  </div>
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="filebox error">
                          <Upload
                            action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
                            listType="picture-card"
                            fileList={fileList}
                            onPreview={handlePreview}
                            onChange={handleChange}
                          >
                            {fileList.length >= 2 ? null : uploadButton}
                          </Upload>
                          <label htmlFor="file" className="file-label">
                            사진첨부{/*<span className="required">*</span>*/}
                          </label>
                        </div>
                        <span className="errorText">fileerror</span>
                      </div>
                      {previewImage && (
                        <Image
                          wrapperStyle={{
                            display: 'none',
                          }}
                          preview={{
                            visible: previewOpen,
                            onVisibleChange: (visible) => setPreviewOpen(visible),
                            afterOpenChange: (visible) => !visible && setPreviewImage(''),
                          }}
                          src={previewImage}
                        />
                      )}
                    </div>
                  </div>
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <Upload {...props}>
                          <div className="btn-area">
                            <button type="button" name="button" className="btn-big btn_text btn-darkblue-line">
                              + Upload
                            </button>
                          </div>
                        </Upload>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuCheckInfoForm;
