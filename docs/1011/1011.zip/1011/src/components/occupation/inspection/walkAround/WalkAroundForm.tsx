import { useState, useEffect, useCallback } from 'react';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import { useOcuSvisitCheckFormStore } from '@/stores/occupation/inspection/useOcuSvisitCheckFormStore';
import { Image, Upload } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { FORM_TYPE_ADD } from '@/config/CommonConstant';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppTextInput from '@/components/common/AppTextInput';
import AppUserReadOnlyInput from '@/components/common/AppUserReadOnlyInput';
import AppUserSelectInput from '@/components/common/AppUserSelectInput';
import AppTextArea from '@/components/common/AppTextArea';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppFileAttach from '@/components/common/AppFileAttach';
import CheckListModal from '@/components/occupation/inspection/checklist/CheckListModal';
import Modal from 'react-modal';

function OcuSvisitCheckForm() {
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    selectedTargetIndex,
    selectedContentIndex,
    setSelectedTargetIndex,
    setSelectedContentIndex,
    setTargetColumn,
    getTargetColumn,
    getTargetError,
    setContentColumn,
    getContentColumn,
    getContentError,
    isDirty,
    saveAll,
    remove,
    cancel,
    clear,
    isChecklistModalOpen,
    openChecklistModal,
    closeChecklistModal,
    selectChecklistModal,
    isContentModalOpen,
    openContentModal,
    closeContentModal,
    getContentList,
  } = useOcuSvisitCheckFormStore();

  const { sectCd, deptCd, chkTitle, chkRegStartDt, chkRegEndDt, regUserId } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [fileList, setFileList] = useState<any>([]);

  const [ocuSvisitCheckTargetColumns, setOcuSvisitCheckTargetColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'status', headerName: 'status' },
      { field: 'prtnrNm', headerName: '협력업체' },
      { field: 'bizPlaceNm', headerName: '사업장' },
      { field: 'regUserDept', headerName: '사용부문' },
    ])
  );

  const [ocuSvisitCheckContentColumns, setOcuSvisitCheckContentColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'status', headerName: 'status' },
      { field: 'chkClsCd', headerName: '점검분류' },
      { field: 'chkItemNm', headerName: '점검항목' },
      { field: 'chkResultCd', headerName: '점검결과' },
      { field: 'chkLclsCd', headerName: '대분류' },
      { field: 'chkScls', headerName: '소분류' },
    ])
  );

  const handleRowSingleClick_OcuSvisitCheckTargetColumns = useCallback(
    (selectedInfo) => {
      const { rowIndex } = selectedInfo;

      if (rowIndex !== selectedTargetIndex) {
        setSelectedTargetIndex(rowIndex);
      }
    },
    [formValue, selectedTargetIndex]
  );

  const handleRowDoubleClick_OcuSvisitCheckContentColumns = useCallback(
    (selectedInfo) => {
      const { rowIndex } = selectedInfo;

      if (rowIndex !== selectedContentIndex) {
        setSelectedContentIndex(rowIndex);
        openContentModal();
      }
    },
    [formValue, selectedContentIndex]
  );

  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };
  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
  const uploadButton = (
    <button
      style={{
        border: 0,
        background: 'none',
      }}
      type="button"
    >
      <PlusOutlined />
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </button>
  );

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }

    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>작업장순회점검</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect label={'부문'} codeGrpId="CODE_GRP_OC001" value={sectCd} disabled />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDeptSelectInput label={'부서'} value={deptCd} disabled />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppUserReadOnlyInput label="작성자" value={regUserId} disabled />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group form-glow">
              <div className="df">
                <div className="date1">
                  <AppDatePicker
                    label={'점검기간'}
                    value={chkRegStartDt}
                    onChange={(value) => {
                      changeInput('chkRegStartDt', value);
                    }}
                  />
                </div>
                <span className="unt">~</span>
                <div className="date2">
                  <AppDatePicker
                    label={'점검기간'}
                    value={chkRegEndDt}
                    onChange={(value) => {
                      changeInput('chkRegEndDt', value);
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSvisitCheckFormchkTitle"
                name="chkTitle"
                label="점검_제목"
                value={chkTitle}
                onChange={(value) => changeInput('chkTitle', value)}
                errorMessage={errors.chkTitle}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid50">
            <div className="ck-edit-box">
              <div className="ck-list">
                <span className="stit-btn  mt-10">
                  <h3 className="table-tit">점검대상</h3>
                  <button
                    onClick={openChecklistModal}
                    style={{ display: formType == FORM_TYPE_ADD ? 'inline-block' : 'none' }}
                  >
                    점검표 검색
                  </button>
                </span>
                <div className="ck-list-grid ">
                  <AppTable
                    rowData={formValue.targetList || []}
                    columns={ocuSvisitCheckTargetColumns}
                    setColumns={setOcuSvisitCheckTargetColumns}
                    handleRowSingleClick={handleRowSingleClick_OcuSvisitCheckTargetColumns}
                    getRowStyle={(params) => {
                      const { data, rowIndex } = params;
                      if (rowIndex === selectedTargetIndex) {
                        return { background: '#d6d9eb' };
                      } else if (data._isError) {
                        return { background: '#ebb2b2' };
                      }
                    }}
                    hiddenPagination
                  />
                </div>
              </div>
              <div className="ck-edit">
                <div className="boxForm">
                  <span className="stit-btn mt-10">
                    <h3>점검내용</h3>
                  </span>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="협력업체"
                          value={selectedTargetIndex === -1 ? '' : getTargetColumn('prtnrId')}
                          onChange={(value) => setTargetColumn(`prtnrId`, value)}
                          errorMessage={getTargetError('prtnrId')}
                          disabled={selectedTargetIndex === -1}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="사업장"
                          value={selectedTargetIndex === -1 ? '' : getTargetColumn('bizPlaceId')}
                          onChange={(value) => setTargetColumn(`bizPlaceId`, value)}
                          errorMessage={getTargetError('bizPlaceId')}
                          disabled={selectedTargetIndex === -1}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="사용부문"
                          value={selectedTargetIndex === -1 ? '' : getTargetColumn('regUserDept')}
                          onChange={(value) => setTargetColumn(`regUserDept`, value)}
                          errorMessage={getTargetError('regUserDept')}
                          disabled={selectedTargetIndex === -1}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label="점검일자"
                          required
                          value={selectedTargetIndex === -1 ? '' : getTargetColumn('chkDt')}
                          onChange={(value) => setTargetColumn(`chkDt`, value)}
                          errorMessage={getTargetError('chkDt')}
                          disabled={selectedTargetIndex === -1}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppUserSelectInput
                          label="점검자"
                          id="OcuSvisitCheckFormChkEmpno"
                          value={selectedTargetIndex === -1 ? '' : getTargetColumn('chkEmpno')}
                          onChange={(value) => setTargetColumn(`chkEmpno`, value)}
                          errorMessage={getTargetError('chkEmpno')}
                          disabled={selectedTargetIndex === -1}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="비고"
                          value={selectedTargetIndex === -1 ? '' : getTargetColumn('remark')}
                          onChange={(value) => setTargetColumn(`remark`, value)}
                          disabled={selectedTargetIndex === -1}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <span className="stit-btn">
                          <h3>점검항목</h3>
                          <button>점검표 출력</button>
                        </span>
                        <AppTable
                          rowData={getContentList()}
                          columns={ocuSvisitCheckContentColumns}
                          setColumns={setOcuSvisitCheckContentColumns}
                          handleRowDoubleClick={handleRowDoubleClick_OcuSvisitCheckContentColumns}
                          getRowStyle={(params) => {
                            const { data, rowIndex } = params;
                            if (rowIndex === selectedContentIndex) {
                              return { background: '#d6d9eb' };
                            } else if (data._isError) {
                              return { background: '#ebb2b2' };
                            }
                          }}
                          hiddenPagination
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
      </div>
      <CheckListModal
        isOpen={isChecklistModalOpen}
        closeModal={closeChecklistModal}
        selectModal={selectChecklistModal}
      />
      <Modal
        shouldCloseOnOverlayClick={false}
        isOpen={isContentModalOpen}
        ariaHideApp={false}
        overlayClassName={'alert-modal-overlay'}
        className={'list-common-modal-content'}
        onRequestClose={() => {
          closeContentModal();
        }}
      >
        <div className="popup-container">
          <h3 className="pop_title">점검항목</h3>
          <div className="pop_cont">
            <div className="editbox">
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      label="점검항목"
                      name="chkItemNm"
                      value={getContentColumn('chkItemNm')}
                      onChange={(value) => {
                        setContentColumn('chkItemNm', value);
                      }}
                      disabled
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppCodeSelect
                      label="점검결과"
                      codeGrpId="CODE_GRP_OC051"
                      name="chkResultCd"
                      value={getContentColumn('chkResultCd')}
                      onChange={(value) => {
                        setContentColumn('chkResultCd', value);
                      }}
                      errorMessage={getContentError('chkResultCd')}
                      required
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              {/* 부적합 사항 */}
              <div>
                <h3 className="input-box-tit">부적합 사항</h3>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        label="대분류"
                        codeGrpId="CODE_GRP_OC039"
                        name="chkLclsCd"
                        value={getContentColumn('chkLclsCd')}
                        onChange={(value) => {
                          setContentColumn('chkLclsCd', value);
                        }}
                        errorMessage={getContentError('chkLclsCd')}
                        disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                      />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        label="소분류"
                        codeGrpId="CODE_GRP_OC040"
                        name="chkScls"
                        value={getContentColumn('chkScls')}
                        onChange={(value) => {
                          setContentColumn('chkScls', value);
                        }}
                        errorMessage={getContentError('chkScls')}
                        disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextArea
                        label="내용"
                        name="chkContent"
                        className="form-tag custom_textarea"
                        style={{ width: '100%' }}
                        value={getContentColumn('chkContent')}
                        onChange={(value) => {
                          setContentColumn('chkContent', value);
                        }}
                        errorMessage={getContentError('chkContent')}
                        disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextArea
                        label="관련법령"
                        id="chkRelLaw"
                        name="chkRelLaw"
                        className="form-tag custom_textarea"
                        style={{ width: '100%' }}
                        value={getContentColumn('chkRelLaw')}
                        onChange={(value) => {
                          setContentColumn('chkRelLaw', value);
                        }}
                        disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <div className="filebox">
                        <label htmlFor="file" className="file-label">
                          사진첨부
                        </label>
                        <Upload
                          listType="picture-card"
                          fileList={fileList}
                          disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                          onPreview={handlePreview}
                          onChange={handleChange}
                        >
                          {fileList.length >= 2 ? null : uploadButton}
                        </Upload>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        //fileGroupSeq={meetDocFileId}
                        workScope={'O'}
                        onlyImageUpload={false}
                        disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                        // updateFileGroupSeq={(newFileGroupSeq) => {
                        //   changeInput('meetDocFileId', newFileGroupSeq);
                        // }}
                      />
                      {/* <Upload {...props}>
                        <div className="btn-area pd-t0">
                          <button
                            type="button"
                            name="button"
                            className="btn-big btn_text btn-darkblue-line mgn-0"
                            disabled={detailFormValue.chkResultCd === 'O' ? true : false}
                          >
                            + Upload
                          </button>
                        </div>
                      </Upload> */}
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table line">
                  <div className="form-cell wid50">
                    <div className="group-box-wrap wid100">
                      <AppRadioGroup
                        label="즉시조치"
                        options={[
                          {
                            label: '예',
                            value: 'Y',
                          },
                          {
                            label: '아니오',
                            value: 'N',
                          },
                        ]}
                        value={getContentColumn('rightActionYn')}
                        onChange={(value) => {
                          setContentColumn('rightActionYn', value);
                        }}
                        disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                      />
                    </div>
                  </div>

                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDeptSelectInput
                        label="조치부서"
                        name="actionDeptCd"
                        value={getContentColumn('actionDeptCd')}
                        onChange={(value) => {
                          setContentColumn('actionDeptCd', value);
                        }}
                        errorMessage={getContentError('actionDeptCd')}
                        disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                      />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDeptSelectInput
                        label="승인부서"
                        name="aprvDeptCd"
                        value={getContentColumn('aprvDeptCd')}
                        onChange={(value) => {
                          setContentColumn('aprvDeptCd', value);
                        }}
                        errorMessage={getContentError('aprvDeptCd')}
                        disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line dp-n"></hr>
              </div>
              {/* 조치 사항 */}
              <div style={{ display: getContentColumn('rightActionYn') === 'N' ? 'none' : 'block' }}>
                <h3 className="table-tit mt-10">조치 사항</h3>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextArea
                        label="조치내용"
                        id="actionContent"
                        name="actionContent"
                        className="form-tag custom_textarea"
                        style={{ width: '100%' }}
                        value={getContentColumn('actionContent')}
                        onChange={(value) => {
                          setContentColumn('actionContent', value);
                        }}
                        disabled={getContentColumn('rightActionYn') === 'N' ? true : false}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <div className="filebox error">
                        <Upload
                          action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
                          listType="picture-card"
                          fileList={fileList}
                          onPreview={handlePreview}
                          onChange={handleChange}
                          disabled={getContentColumn('rightActionYn') === 'N' ? true : false}
                        >
                          {fileList.length >= 8 ? null : uploadButton}
                        </Upload>
                        <label htmlFor="file" className="file-label">
                          사진첨부{/*<span className="required">*</span>*/}
                        </label>
                      </div>
                      <span className="errorText">fileerror</span>
                    </div>
                    {previewImage && (
                      <Image
                        wrapperStyle={{
                          display: 'none',
                        }}
                        preview={{
                          visible: previewOpen,
                          onVisibleChange: (visible) => setPreviewOpen(visible),
                          afterOpenChange: (visible) => !visible && setPreviewImage(''),
                        }}
                        src={previewImage}
                      />
                    )}
                  </div>
                </div>
                <hr className="line"></hr>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        //fileGroupSeq={meetDocFileId}
                        workScope={'O'}
                        onlyImageUpload={false}
                        disabled={getContentColumn('chkResultCd') === 'O' ? true : false}
                        // updateFileGroupSeq={(newFileGroupSeq) => {
                        //   changeInput('meetDocFileId', newFileGroupSeq);
                        // }}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
              </div>
            </div>
          </div>

          <div className="pop_btns">
            <button className="btn_text text_color_neutral-10 btn_confirm" onClick={closeContentModal}>
              확인
            </button>
          </div>
          <span className="pop_close" onClick={closeContentModal}>
            X
          </span>
        </div>
      </Modal>

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={saveAll}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}

const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

export default OcuSvisitCheckForm;
