import { useEffect, useState } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useParams } from 'react-router-dom';
import { Upload } from 'antd';
import CommonUtil from '@/utils/CommonUtil';
import useOcuWorkPermitFormStore from '@/stores/occupation/management/useOcuWorkPermitFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function WorkPermitDetail() {
  // const [detailInfo, setDetailInfo] = useState<any>({});
  const { detailInfo, getDetail, cancel, goFormPage, clear } = useOcuWorkPermitFormStore();

  const {
    // 부문명
    //sectNm,
    // 공사 ID
    cntrId,
    // 공사명
    cntrNm,
    cntrAreaCd,
    spclEduTargetYn,
    cnstCmpny,
    staff,
    contactNo,
    cnstrSiteId,
    cntrPositionNm,
    cntrPrsnCnt,
    cntrApplyStartDttm,
    cntrApplyEndDttm,
    preConsentYn,
    applyEmpno,
    aprvEmpno,
    aprvDeptOpnn,
    applyStatusCd,
    wrkStatusCd,
    wrkStartDt,
    wrkStartRemark,
    wrkStartPhoto1Id,
    wrkStartPhoto2Id,
    eduJrnlFileId,
    etcFileId,
    wrkEndDt,
    wrkEndRemark,
    regDttm,
    regUserId,
    updDttm,
    updUserId,
    sectNm,
    sectCd,
    deptCd,
  } = detailInfo;

  const { detailId } = useParams();

  // const cancel = () => {
  //   // TODO : [목록으로] 버튼 처리
  // };

  // const goFormPage = () => {
  //   // TODO : [수정] 버튼 처리
  // };

  function getDataPortion(dateString) {
    try {
      return dateString.split(' ')[0];
    } catch (error) {
      console.error('Invalid Date format: ', dateString);
      return dateString;
    }
  }

  const now = CommonUtil.getNowByServerTime();
  console.log('now : ', now);

  const formattedDate = getDataPortion(now);
  console.log('바꼈쥬?헿 : ', formattedDate);

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>외주작업허가</h2>
      </div>
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              신청자 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">부문</label>
                              <span className="text-desc-type1">{sectNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">부서</label>
                              <span className="text-desc-type1">{deptCd}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">이름</label>
                              <span className="text-desc-type1">{regUserId}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">연락처</label>
                              <span className="text-desc-type1">{contactNo}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>

          <dt>
            <button type="button" className="btn-tg">
              승인자 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">부문</label>
                              <span className="text-desc-type1">{sectCd}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">부서</label>
                              <span className="text-desc-type1">{aprvDeptOpnn}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">이름</label>
                              <span className="text-desc-type1">{aprvEmpno}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">연락처</label>
                              <span className="text-desc-type1">{}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>

          <dt>
            <button type="button" className="btn-tg">
              공사 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공사명</label>
                              <span className="text-desc-type1">{cntrNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <span className="txt">공사 분야</span>
                        <div className="radio-wrap">
                          <label>
                            <input type="checkbox" checked />
                            <span>건축</span>
                          </label>
                          <label>
                            <input type="checkbox" />
                            <span>기계</span>
                          </label>
                          <label>
                            <input type="checkbox" />
                            <span>전기</span>
                          </label>
                          <label>
                            <input type="checkbox" />
                            <span>소방</span>
                          </label>
                          <label>
                            <input type="checkbox" />
                            <span>이외</span>
                          </label>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <span className="txt">특별교육 대상</span>
                        <div className="radio-wrap">
                          <label>
                            <input type="radio" checked />
                            <span>예</span>
                          </label>
                          <button className="radio-btn">교육내용</button>
                          <label>
                            <input type="radio" />
                            <span>아니오</span>
                          </label>
                        </div>
                        {/*<span className="errorText">error</span>*/}
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">시공사</label>
                              <span className="text-desc-type1">{cnstCmpny}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">담당자</label>
                              <span className="text-desc-type1">{staff}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">연락처</label>
                              <span className="text-desc-type1">{contactNo}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공사장소</label>
                              <span className="text-desc-type1">{cnstrSiteId}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공사위치</label>
                              <span className="text-desc-type1">{cntrPositionNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공사인원</label>
                              <span className="text-desc-type1">{cntrPrsnCnt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공사시작일시</label>
                              <span className="text-desc-type1">{cntrApplyStartDttm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공사 시작시간</label>
                              <span className="text-desc-type1">{cntrApplyStartDttm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공사 종료일시</label>
                              <span className="text-desc-type1">{cntrApplyEndDttm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공사 종료시간</label>
                              <span className="text-desc-type1">{cntrApplyEndDttm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <h3 className="table-tit">
                          공사구분 <span className="required">*</span>
                        </h3>
                        <div className="work-group">
                          <table className="work-table">
                            <thead>
                              <tr>
                                <th>작업</th>
                                <th>반입장비</th>
                                <th>파일첨부</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">공통(일반)</span>
                                    </label>
                                  </div>
                                </td>
                                <td></td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="box-view-list">
                                          <ul className="view-list">
                                            <li className="accumlate-list">
                                              <label className="t-label">첨부파일</label>
                                              <span className="text-desc-type1">
                                                <div className="filebox view">
                                                  <Upload>
                                                    <div className="btn-area" style={{ display: 'none' }}>
                                                      <button
                                                        type="button"
                                                        name="button"
                                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                                      >
                                                        + Upload
                                                      </button>
                                                    </div>
                                                  </Upload>
                                                </div>
                                              </span>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">화재위험작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">가스 용접·용단</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">전기·용접</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">연삭기</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="box-view-list">
                                          <ul className="view-list">
                                            <li className="accumlate-list">
                                              <label className="t-label">첨부파일</label>
                                              <span className="text-desc-type1">
                                                <div className="filebox view">
                                                  <Upload>
                                                    <div className="btn-area" style={{ display: 'none' }}>
                                                      <button
                                                        type="button"
                                                        name="button"
                                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                                      >
                                                        + Upload
                                                      </button>
                                                    </div>
                                                  </Upload>
                                                </div>
                                              </span>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">전기작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">이동식 사다리</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">달비계</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">시저형 고소작업대(렌탈)</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">차량탑재형 고소작업대(스카이차)</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="box-view-list">
                                          <ul className="view-list">
                                            <li className="accumlate-list">
                                              <label className="t-label">첨부파일</label>
                                              <span className="text-desc-type1">
                                                <div className="filebox view">
                                                  <Upload>
                                                    <div className="btn-area" style={{ display: 'none' }}>
                                                      <button
                                                        type="button"
                                                        name="button"
                                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                                      >
                                                        + Upload
                                                      </button>
                                                    </div>
                                                  </Upload>
                                                </div>
                                              </span>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">고소작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td></td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="box-view-list">
                                          <ul className="view-list">
                                            <li className="accumlate-list">
                                              <label className="t-label">첨부파일</label>
                                              <span className="text-desc-type1">
                                                <div className="filebox view">
                                                  <Upload>
                                                    <div className="btn-area" style={{ display: 'none' }}>
                                                      <button
                                                        type="button"
                                                        name="button"
                                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                                      >
                                                        + Upload
                                                      </button>
                                                    </div>
                                                  </Upload>
                                                </div>
                                              </span>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">전기작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">이동식 사다리</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">달비계</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">시저형 고소작업대(렌탈)</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">차량탑재형 고소작업대(스카이차)</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="box-view-list">
                                          <ul className="view-list">
                                            <li className="accumlate-list">
                                              <label className="t-label">첨부파일</label>
                                              <span className="text-desc-type1">
                                                <div className="filebox view">
                                                  <Upload>
                                                    <div className="btn-area" style={{ display: 'none' }}>
                                                      <button
                                                        type="button"
                                                        name="button"
                                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                                      >
                                                        + Upload
                                                      </button>
                                                    </div>
                                                  </Upload>
                                                </div>
                                              </span>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">줄걸이작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">기중기(건설기계)</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">차량탑재형 이동식 크레인(카고크레인)</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="box-view-list">
                                          <ul className="view-list">
                                            <li className="accumlate-list">
                                              <label className="t-label">첨부파일</label>
                                              <span className="text-desc-type1">
                                                <div className="filebox view">
                                                  <Upload>
                                                    <div className="btn-area" style={{ display: 'none' }}>
                                                      <button
                                                        type="button"
                                                        name="button"
                                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                                      >
                                                        + Upload
                                                      </button>
                                                    </div>
                                                  </Upload>
                                                </div>
                                              </span>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">건설기계 사용작업</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">굴착기</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">지게차</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">덤프트럭</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">콘크리트믹서트럭</span>
                                    </label>
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">이 외</span>
                                    </label>
                                  </div>
                                </td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="box-view-list">
                                          <ul className="view-list">
                                            <li className="accumlate-list">
                                              <label className="t-label">첨부파일</label>
                                              <span className="text-desc-type1">
                                                <div className="filebox view">
                                                  <Upload>
                                                    <div className="btn-area" style={{ display: 'none' }}>
                                                      <button
                                                        type="button"
                                                        name="button"
                                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                                      >
                                                        + Upload
                                                      </button>
                                                    </div>
                                                  </Upload>
                                                </div>
                                              </span>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                  <div className="radio-wrap-type02">
                                    <label className="type02">
                                      <input type="checkbox" />
                                      <span className="type02">밀폐공간</span>
                                    </label>
                                  </div>
                                </td>
                                <td></td>
                                <td>
                                  {/* 파일첨부영역 : button */}
                                  <div className="form-table">
                                    <div className="form-cell wid50 border-b-no">
                                      <div className="form-group wid100">
                                        <div className="box-view-list">
                                          <ul className="view-list">
                                            <li className="accumlate-list">
                                              <label className="t-label">첨부파일</label>
                                              <span className="text-desc-type1">
                                                <div className="filebox view">
                                                  <Upload>
                                                    <div className="btn-area" style={{ display: 'none' }}>
                                                      <button
                                                        type="button"
                                                        name="button"
                                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                                      >
                                                        + Upload
                                                      </button>
                                                    </div>
                                                  </Upload>
                                                </div>
                                              </span>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>

          <dt>
            <button type="button" className="btn-tg" value={preConsentYn}>
              사전동의<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <ul className="agree">
                          <li>1. 8시간 이상 진행되는 작업의 경우 작업 종료 후 재시작 시 현장 안전점검 실시</li>
                          <li>2. 현장점검 시 작업에 해당되는 점검표를 활용하여 점검 실시</li>
                          <li>3. 기계⋅전기⋅가스 등의 정지⋅차단 조치가 필요한 경우 Lock-Out, Tag-Out 실시</li>
                          <li>
                            4. 작업종료 후 외주업체 안전교육일지 및 작업 후 조치현황을 작업종료 후 2일 이내 승인부서에
                            통보 할 것
                          </li>
                          <li>5. 현장에서 안전조치 미흡/위반 사례 적발 시 즉시 작업중지 조치 예정</li>
                        </ul>
                        <div className="radio-wrap border-no pd-style">
                          <label>
                            <input type="checkbox" checked />
                            <span>위 사항에 대해 충분히 이해하고 입력한 정보로 작업허가를 신청합니다.</span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              작업 시작<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid-300">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">실제시작일</label>
                              <span className="text-desc-type1">{wrkStartDt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">교육일지</label>
                              <span className="text-desc-type1">
                                <div className="filebox view">
                                  <Upload>
                                    <div className="btn-area" style={{ display: 'none' }}>
                                      <button
                                        type="button"
                                        name="button"
                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                      >
                                        + Upload
                                      </button>
                                      {eduJrnlFileId}
                                    </div>
                                  </Upload>
                                </div>
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">기타첨부</label>
                              <span className="text-desc-type1">
                                <div className="filebox view">
                                  <Upload>
                                    <div className="btn-area" style={{ display: 'none' }}>
                                      <button
                                        type="button"
                                        name="button"
                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                      >
                                        + Upload
                                      </button>
                                      {etcFileId}
                                    </div>
                                  </Upload>
                                </div>
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <h3 className="table-tit">체크리스트</h3>
                        <div className="ck-list-tabel">
                          <table>
                            <thead>
                              <tr>
                                <th>작업</th>
                                <th>반입장비</th>
                                <th>체크리스트</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>공통(일반)</td>
                                <td></td>
                                <td>작성 완료</td>
                              </tr>
                              <tr>
                                <td>화기작업</td>
                                <td>가스 용접·용단, 연삭기</td>
                                <td>작성 완료</td>
                              </tr>
                              <tr>
                                <td>공통(일반)</td>
                                <td></td>
                                <td>작성 완료</td>
                              </tr>
                              <tr>
                                <td>공통(일반)</td>
                                <td></td>
                                <td>작성 완료</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">비고</label>
                              <span className="text-desc-type1">비고</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">사진첨부</label>
                              <span className="text-desc-type1">
                                <div className="filebox view">
                                  <Upload listType="picture-card">
                                    <div className="btn-area" style={{ display: 'none' }}>
                                      <button
                                        type="button"
                                        name="button"
                                        className="btn-big btn_text btn-darkblue-line mg-n"
                                      >
                                        + Upload
                                      </button>
                                    </div>
                                  </Upload>
                                </div>
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              작업 종료<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid-300">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">실제 종료일</label>
                              <span className="text-desc-type1">{wrkEndDt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">특이사항</label>
                              <span className="text-desc-type1">특이사항</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <h3 className="table-tit">공사연장 이력</h3>
                        <div className="ck-list-tabel">
                          <table>
                            <thead>
                              <tr className="type01">
                                <th>연장 전 종료 일자</th>
                                <th>연장 요청 일자</th>
                                <th>연장 요청 사유</th>
                                <th>연장 승인 일자</th>
                                <th>승인부서 의견</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr className="type01">
                                <td>2024.07.16</td>
                                <td>2024.07.18</td>
                                <td>폭우로 인한 공사 연장</td>
                                <td>2024.07.18</td>
                                <td></td>
                              </tr>
                              <tr className="type01">
                                <td>2024.07.16</td>
                                <td>2024.07.18</td>
                                <td>폭우로 인한 공사 연장</td>
                                <td>2024.07.18</td>
                                <td></td>
                              </tr>
                              <tr className="type01">
                                <td>2024.07.16</td>
                                <td>2024.07.18</td>
                                <td>폭우로 인한 공사 연장</td>
                                <td>2024.07.18</td>
                                <td></td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              승인부서 의견<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">의견</label>
                              <span className="text-desc-type1">{aprvDeptOpnn}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
          제출
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_conblue">
          수정
        </button>
        <button type="button" name="button" className="btn_text btn-del">
          취소
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
          결재
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_conblue">
          반려
        </button>
        <button type="button" name="button" className="btn_text btn-del">
          취소
        </button>
      </div>
      {/*//하단버튼영역*/}
    </>
  );
}
export default WorkPermitDetail;
