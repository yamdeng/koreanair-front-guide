import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSelect from '@/components/common/AppSelect';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppTextInput from '@/components/common/AppTextInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppRangeDatePicker from '@/components/common/AppRangeDatePicker';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/permits',
  baseRoutePath: '/occupation/management/permits',
};

// 오늘날짜 설정하기
const currentDate = CommonUtil.getToDate();

// 검색 초기값 설정
const initSearchParam = {
  // 부문
  sectCd: '',
  // 부서
  deptCd: '',
  // 신청자
  regUserId: '',
  // 기간 - 작업시작일자
  wrkStartDt: '',
  // 기간 - 작업종료일자
  wrkEndDt: '',
  // 신청상태
  applyStatusCd: '',
  // 공사분야
  cntrAreaCd: '',
  // 공사장소
  cntrLocationNm: '',
  // 작업상태
  // 공사명
  searchWord: '',
};

/* zustand store 생성 */
const OcuOutSourcingListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  // 날짜검색용 초기 값
  duration: ['', ''],

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    sectCd: '',
    deptCd: '',
    regUserId: '',
    cntrLocationNm: '',
    cntrSiteId: '',
    searchWord: '',
    wrkStartDt: currentDate,
    wrkEndDt: '',
    applyStatusCd: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
    // 기간 검색용 날짜 추가 for AppRangeDatePicker
    set({ duration: [currentDate, currentDate] });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function WorkPermitList() {
  const state = OcuOutSourcingListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'sectNm', headerName: '부문', flex: 1 },
      { field: 'deptNm', headerName: '부서', flex: 1 },
      { field: 'regUserId', headerName: '신청자', flex: 1 },
      { field: 'cntrLocationNm', headerName: '공사장소', flex: 1 },
      { field: 'cntrPositionNm', headerName: '공사위치', flex: 1 },
      { field: 'cntrNm', headerName: '공사명', flex: 1 },
      { field: 'cntrAreaNm', headerName: '공사분야', flex: 1 },
      { field: 'cnstCmpny', headerName: '작업구분', flex: 1 },
      {
        field: 'cntrApplyStartDttm',
        headerName: '공사기간',
        valueGetter: (p) => p.data.cntrApplyStartDttm + ' ~ ' + p.data.cntrApplyEndDttm,
      },
      { field: 'applyStatusNm', headerName: '신청상태' },
      { field: 'wrkStatusNm', headerName: '작업상태' },
      // NEED TO ADD LATER - Attachment
      { field: 'fileId', headerName: '작업신청서' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    changeStateProps,
    initSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    duration,
    goDetailPage,
  } = state;
  // 검색 파라미터 나열
  const {
    // 부문
    sectCd,
    // 부서
    deptCd,
    // 신청자
    regUserId,
    // 기간 - 시작일
    wrkStartDt,
    // 기간 - 종료일
    wrkEndDt,
    // 신청상태
    applyStatusCd,
    // 공사분야
    cntrAreaCd,
    // 공사장소코드
    cntrSiteId,
    // 작업상태
    wrkStatusCd,
    // 공사명
    cntrNm,
    //searchWord,
  } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.cntrId;
    goDetailPage(detailId);
    console.log('여기데이터있어유!!!!!!! : ', data);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  const customButtons = [
    {
      title: '다운로드',
      onClick: () => {
        // alert('다운로드 not ready yet');
      },
    },
    {
      title: '등록',
      onClick: () => {
        // alert('등록 STILL WORKING ON IT.');
        goAddPage();
      },
    },
  ];

  console.log(`duration : ${duration}`);

  return (
    <>
      {/* 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'부문'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC001"
                  value={sectCd}
                  onChange={(value) => {
                    changeSearchInput('sectCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100 mr5">
                <AppAutoComplete
                  label={'부서'}
                  value={deptCd}
                  onChange={(value) => {
                    changeSearchInput('deptCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppAutoComplete
                  label={'신청자'}
                  value={regUserId}
                  onChange={(value) => {
                    changeSearchInput('regUserId', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group form-glow">
                <div className="date1">
                  <AppRangeDatePicker
                    label="기간"
                    onChange={(value) => {
                      changeSearchInput('wrkStartDt', value[0]);
                      changeSearchInput('wrkEndDt', value[1]);
                      changeStateProps('duration', value);
                    }}
                    value={duration}
                    showNow
                    placeholder={['시작일', '종료일']}
                  />
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'신청상태'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC041"
                  value={applyStatusCd}
                  onChange={(value) => {
                    changeSearchInput('applyStatusCd', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'공사분야'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC030"
                  value={cntrAreaCd}
                  onChange={(value) => {
                    changeSearchInput('cntrAreaCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSelect
                  label={'공사장소'}
                  value={cntrSiteId}
                  onChange={(value) => {
                    changeSearchInput('cntrSiteId', value);
                  }}
                />
                {/* 등록창에 있는 공사장소 이름이랑 같이 사용할 것 */}
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'작업상태'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC046"
                  value={wrkStatusCd}
                  onChange={(value) => {
                    changeSearchInput('wrkStatusCd', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={'공사명'}
                  value={cntrNm}
                  onChange={(value) => {
                    changeSearchInput('cntrNm', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              초기화
            </button>
          </div>
        </div>
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
        customButtons={customButtons}
      />
    </>
  );
}

export default WorkPermitList;
