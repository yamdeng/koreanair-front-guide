import AppTable from "@/components/common/AppTable";
import { createListSlice, listBaseState } from "@/stores/slice/listSlice";
import AppTextInput from '@/components/common/AppTextInput';

function OcuQsuppEvalTargetSearchForm() {
  const state = useOcuQsuppEvalTargetListStore();

  const {  qsuppTargetId, qsuppId, evalYear, evalDeptCd, regDttm, regUserId, updDttm, updUserId, } = searchParam;

  return (
    <>
      {/* TODO : 검색 input 영역입니다 */}
      
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  inputType="number"
                  label="적격수급업체_평가대상_ID"
                  value={qsuppTargetId}
                  onChange={(value) => {
                    changeSearchInput('qsuppTargetId', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="적격수급업체_ID"
                  value={qsuppId}
                  onChange={(value) => {
                    changeSearchInput('qsuppId', value);
                  }}
                />
              </div>
            </div>              
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="평가_년도"
                  value={evalYear}
                  onChange={(value) => {
                    changeSearchInput('evalYear', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="평가_부서_코드"
                  value={evalDeptCd}
                  onChange={(value) => {
                    changeSearchInput('evalDeptCd', value);
                  }}
                />
              </div>
            </div>              
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="등록_일시"
                  value={regDttm}
                  onChange={(value) => {
                    changeSearchInput('regDttm', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="등록자_ID"
                  value={regUserId}
                  onChange={(value) => {
                    changeSearchInput('regUserId', value);
                  }}
                />
              </div>
            </div>              
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="수정_일시"
                  value={updDttm}
                  onChange={(value) => {
                    changeSearchInput('updDttm', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="수정자_ID"
                  value={updUserId}
                  onChange={(value) => {
                    changeSearchInput('updUserId', value);
                  }}
                />
              </div>
            </div>              
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
              조회
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
              초기화
            </button>
          </div>      
        </div>
        <button
            type="button"
            name="button"
            className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
            onClick={toggleExpandDetailSearch}
          >
          <span className="hide">접기</span>
        </button>
      </div>
            
    </>
  );
}
export default OcuQsuppEvalTargetSearchForm;
