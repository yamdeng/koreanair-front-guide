import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { create } from "zustand";
import { formBaseState, createFormSliceYup } from "@/stores/slice/formSlice";
import * as yup from "yup"; 

/* yup validation */
const yupFormSchema = yup.object({
  msrId: yup.number().required(),
  msrYear: yup.string().required(),
  halfYearCd: yup.string().required(),
  msrClsCd: yup.string().required(),
  areaCd: yup.string().required(),
  msrStartDt: yup.string().required(),
  msrEndDt: yup.string().required(),
  msrInstt: yup.string().required(),
  msrResult: yup.string().required(),
  opnn: yup.string(),
  resultFileId: yup.number(),
  chmclFileId: yup.number(),
  regDttm: yup.string().required(),
  regUserId: yup.string().required(),
  updDttm: yup.string().required(),
  updUserId: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  msrId: null,
  msrYear: "",
  halfYearCd: "",
  msrClsCd: "",
  areaCd: "",
  msrStartDt: "",
  msrEndDt: "",
  msrInstt: "",
  msrResult: "",
  opnn: "",
  resultFileId: null,
  chmclFileId: null,
  regDttm: "",
  regUserId: "",
  updDttm: "",
  updUserId: "",
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'TODO : api path',
  baseRoutePath: 'TODO : UI route path',
  formName: 'OcuEnvMeasureForm',
  formValue: {
    ...initFormValue,
  }
};

/* zustand store 생성 */
const useOcuEnvMeasureFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuEnvMeasureForm() {

  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    save,
    remove,
    cancel,
    clear } =
    useOcuEnvMeasureFormStore();

  const {  msrId, msrYear, halfYearCd, msrClsCd, areaCd, msrStartDt, msrEndDt, msrInstt, msrResult, opnn, resultFileId, chmclFileId, regDttm, regUserId, updDttm, updUserId, } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>TODO : 헤더 타이틀</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                id="OcuEnvMeasureFormmsrId"
                name="msrId"
                label="측정_ID"
                value={msrId}
                onChange={(value) => changeInput('msrId', value)}
                errorMessage={errors.msrId}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormmsrYear"
                name="msrYear"
                label="측정_년도"
                value={msrYear}
                onChange={(value) => changeInput('msrYear', value)}
                errorMessage={errors.msrYear}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormhalfYearCd"
                name="halfYearCd"
                label="반기_코드"
                value={halfYearCd}
                onChange={(value) => changeInput('halfYearCd', value)}
                errorMessage={errors.halfYearCd}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormmsrClsCd"
                name="msrClsCd"
                label="측정_구분_코드"
                value={msrClsCd}
                onChange={(value) => changeInput('msrClsCd', value)}
                errorMessage={errors.msrClsCd}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormareaCd"
                name="areaCd"
                label="권역_코드"
                value={areaCd}
                onChange={(value) => changeInput('areaCd', value)}
                errorMessage={errors.areaCd}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormmsrStartDt"
                name="msrStartDt"
                label="측정_시작_일자"
                value={msrStartDt}
                onChange={(value) => changeInput('msrStartDt', value)}
                errorMessage={errors.msrStartDt}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormmsrEndDt"
                name="msrEndDt"
                label="측정_종료_일자"
                value={msrEndDt}
                onChange={(value) => changeInput('msrEndDt', value)}
                errorMessage={errors.msrEndDt}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormmsrInstt"
                name="msrInstt"
                label="측정_기관"
                value={msrInstt}
                onChange={(value) => changeInput('msrInstt', value)}
                errorMessage={errors.msrInstt}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormmsrResult"
                name="msrResult"
                label="측정_결과"
                value={msrResult}
                onChange={(value) => changeInput('msrResult', value)}
                errorMessage={errors.msrResult}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormopnn"
                name="opnn"
                label="의견"
                value={opnn}
                onChange={(value) => changeInput('opnn', value)}
                errorMessage={errors.opnn}
                
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                id="OcuEnvMeasureFormresultFileId"
                name="resultFileId"
                label="결과_첨부_파일_ID"
                value={resultFileId}
                onChange={(value) => changeInput('resultFileId', value)}
                errorMessage={errors.resultFileId}
                
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                id="OcuEnvMeasureFormchmclFileId"
                name="chmclFileId"
                label="화학_첨부_파일_ID"
                value={chmclFileId}
                onChange={(value) => changeInput('chmclFileId', value)}
                errorMessage={errors.chmclFileId}
                
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormregDttm"
                name="regDttm"
                label="등록_일시"
                value={regDttm}
                onChange={(value) => changeInput('regDttm', value)}
                errorMessage={errors.regDttm}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormregUserId"
                name="regUserId"
                label="등록자_ID"
                value={regUserId}
                onChange={(value) => changeInput('regUserId', value)}
                errorMessage={errors.regUserId}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormupdDttm"
                name="updDttm"
                label="수정_일시"
                value={updDttm}
                onChange={(value) => changeInput('updDttm', value)}
                errorMessage={errors.updDttm}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuEnvMeasureFormupdUserId"
                name="updUserId"
                label="수정자_ID"
                value={updUserId}
                onChange={(value) => changeInput('updUserId', value)}
                errorMessage={errors.updUserId}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuEnvMeasureForm;
