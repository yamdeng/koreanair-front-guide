import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { create } from "zustand";
import { formBaseState, createFormSliceYup } from "@/stores/slice/formSlice";
import * as yup from "yup"; 

/* yup validation */
const yupFormSchema = yup.object({
  mgntSprvEvalId: yup.number().required(),
  sectCd: yup.string(),
  deptCd: yup.string(),
  evalYear: yup.string(),
  qrtrYearCd: yup.string(),
  title: yup.string(),
  evalSubjEmpno: yup.string(),
  evalEmpno: yup.string(),
  fileId: yup.number(),
  linkId: yup.number(),
  remark: yup.string(),
  regDttm: yup.string().required(),
  regUserId: yup.string().required(),
  updDttm: yup.string().required(),
  updUserId: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  mgntSprvEvalId: null,
  sectCd: "",
  deptCd: "",
  evalYear: "",
  qrtrYearCd: "",
  title: "",
  evalSubjEmpno: "",
  evalEmpno: "",
  fileId: null,
  linkId: null,
  remark: "",
  regDttm: "",
  regUserId: "",
  updDttm: "",
  updUserId: "",
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'TODO : api path',
  baseRoutePath: 'TODO : UI route path',
  formName: 'OcuSprvEvalForm',
  formValue: {
    ...initFormValue,
  }
};

/* zustand store 생성 */
const useOcuSprvEvalFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuSprvEvalForm() {

  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    save,
    remove,
    cancel,
    clear } =
    useOcuSprvEvalFormStore();

  const {  mgntSprvEvalId, sectCd, deptCd, evalYear, qrtrYearCd, title, evalSubjEmpno, evalEmpno, fileId, linkId, remark, regDttm, regUserId, updDttm, updUserId, } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>TODO : 헤더 타이틀</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                id="OcuSprvEvalFormmgntSprvEvalId"
                name="mgntSprvEvalId"
                label="관리감독자평가_ID"
                value={mgntSprvEvalId}
                onChange={(value) => changeInput('mgntSprvEvalId', value)}
                errorMessage={errors.mgntSprvEvalId}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormsectCd"
                name="sectCd"
                label="부문_코드"
                value={sectCd}
                onChange={(value) => changeInput('sectCd', value)}
                errorMessage={errors.sectCd}
                
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormdeptCd"
                name="deptCd"
                label="부서_코드"
                value={deptCd}
                onChange={(value) => changeInput('deptCd', value)}
                errorMessage={errors.deptCd}
                
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormevalYear"
                name="evalYear"
                label="평가년도"
                value={evalYear}
                onChange={(value) => changeInput('evalYear', value)}
                errorMessage={errors.evalYear}
                
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormqrtrYearCd"
                name="qrtrYearCd"
                label="분기_코드"
                value={qrtrYearCd}
                onChange={(value) => changeInput('qrtrYearCd', value)}
                errorMessage={errors.qrtrYearCd}
                
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormtitle"
                name="title"
                label="제목"
                value={title}
                onChange={(value) => changeInput('title', value)}
                errorMessage={errors.title}
                
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormevalSubjEmpno"
                name="evalSubjEmpno"
                label="피평가자_사번"
                value={evalSubjEmpno}
                onChange={(value) => changeInput('evalSubjEmpno', value)}
                errorMessage={errors.evalSubjEmpno}
                
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormevalEmpno"
                name="evalEmpno"
                label="평가자_사번"
                value={evalEmpno}
                onChange={(value) => changeInput('evalEmpno', value)}
                errorMessage={errors.evalEmpno}
                
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                id="OcuSprvEvalFormfileId"
                name="fileId"
                label="첨부_파일_ID"
                value={fileId}
                onChange={(value) => changeInput('fileId', value)}
                errorMessage={errors.fileId}
                
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                id="OcuSprvEvalFormlinkId"
                name="linkId"
                label="첨부_링크_ID"
                value={linkId}
                onChange={(value) => changeInput('linkId', value)}
                errorMessage={errors.linkId}
                
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormremark"
                name="remark"
                label="비고"
                value={remark}
                onChange={(value) => changeInput('remark', value)}
                errorMessage={errors.remark}
                
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormregDttm"
                name="regDttm"
                label="등록_일시"
                value={regDttm}
                onChange={(value) => changeInput('regDttm', value)}
                errorMessage={errors.regDttm}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormregUserId"
                name="regUserId"
                label="등록자_ID"
                value={regUserId}
                onChange={(value) => changeInput('regUserId', value)}
                errorMessage={errors.regUserId}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormupdDttm"
                name="updDttm"
                label="수정_일시"
                value={updDttm}
                onChange={(value) => changeInput('updDttm', value)}
                errorMessage={errors.updDttm}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table">          
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSprvEvalFormupdUserId"
                name="updUserId"
                label="수정자_ID"
                value={updUserId}
                onChange={(value) => changeInput('updUserId', value)}
                errorMessage={errors.updUserId}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuSprvEvalForm;
