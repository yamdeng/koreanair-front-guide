import Modal from 'react-modal';
import { useEffect, useState, useCallback } from 'react';
import OcuWorkPermitLocationRegisterModalStore from '@/stores/occupation/management/useOcuWorkPermitLocationRegisterModalStore';
import AppTable from '@/components/common/AppTable';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppTextInput from '@/components/common/AppTextInput';
import AppSearchInput from '@/components/common/AppSearchInput';
import CommonUtil from '@/utils/CommonUtil';

/**The difference is I should've take the values from the original list. */

function WorkPermitLocationRegisterModal(props) {
  // Grid Column  - 공사장소 관리
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: '_status', headerName: 'status' },
      { field: 'cntrLocationNm', headerName: '공사장소명' },
      { field: 'useYn', headerName: '사용여부' },
    ])
  );

  const { isOpen, closeModal, ok } = props;

  const state = OcuWorkPermitLocationRegisterModalStore();

  const {
    selectedIndex,
    setSelectedIndex,
    changeSearchInput,
    enterSearch,
    CommonDS,
    setColumn,
    clear,
    getList,
    validate,
    formValue,
    searchParam,
    getColumn,
    saveLocationRegister,
    initSearchInput,
  } = state; // state에 assgin해서 state.으로 접근하지 않아도 됨

  useEffect(() => {
    getList();

    return clear;
  }, []);

  const {
    //공사장소명
    cntrLocationNm,
    //사용여부
    useYn,
  } = searchParam;

  const customButtons = [
    {
      title: '추가',
      onClick: () => {
        const rowIdx = CommonDS.addRow('formValue.list');

        setSelectedIndex(rowIdx);
      },
    },
  ];

  const handleRowDoubleClick = useCallback(
    (row) => {
      // 선택된 행의 인덱스 설정하기
      const index = row.rowIndex;
      setSelectedIndex(index); // 선택된 인덱스를 설정합니다.

      // 현재 선택된 행의 _status 값을 가져오기
      const currentStatus = getColumn('_status'); // 현재 _status 값을 가져옵니다.

      // _status가 'A'가 아닐 때만 변경
      if (currentStatus !== 'A') {
        setColumn(index, '_status', 'U'); // 선택된 인덱스의 _status 필드를 'U'로 업데이트합니다.
      }
    },
    [setColumn, getColumn]
  );

  const handleCancel = () => {
    alert('선택이 취소되었습니다');
    setSelectedIndex(null);
    getList();
  };

  const handleClose = () => {
    // alert('Closing Modal');
    closeModal();
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">공사장소 관리</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form pb_0">
              {/*검색영역 */}
              <div className="boxForm">
                {/*area-detail명 옆에 active  */}
                <div id="" className="area-detail active">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSearchInput
                          label="공사명"
                          value={cntrLocationNm}
                          onChange={(value) => {
                            changeSearchInput('cntrLocationNm', value);
                          }}
                          search={enterSearch}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label={'사용여부'}
                          applyAllSelect="true"
                          codeGrpId="CODE_GRP_OC047"
                          value={useYn}
                          onChange={(value) => {
                            changeSearchInput('useYn', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="btn-area wid50 mb-10">
                      <button
                        type="button"
                        name="button"
                        className="btn-sm btn_text btn-darkblue-line"
                        onClick={getList}
                      >
                        조회
                      </button>
                      <button
                        type="button"
                        name="button"
                        className="btn-sm btn_text btn-darkblue-line"
                        onClick={initSearchInput}
                      >
                        초기화
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              {/* //검색영역 */}
              <div className="modal-group-box">
                {/* 공사장소 조회 그리드영역 */}
                <div className="left-group">
                  <h3 className="table-tit">공사장소 조회</h3>
                  <AppTable
                    rowData={formValue.list}
                    columns={columns}
                    handleRowDoubleClick={handleRowDoubleClick}
                    customButtons={customButtons}
                    getRowStyle={(params) => {
                      const { data, rowIndex } = params;
                      if (rowIndex === selectedIndex) {
                        return { background: '#d6d9eb' };
                      } else if (data._isError) {
                        return { background: '#ebb2b2' };
                      }
                    }}
                  />
                </div>
                <div className="right-group">
                  <div className="group-box mb-20">
                    <div className="ck-edit-box">
                      <div className="ck-edit">
                        <div className="boxForm">
                          <h3 className="table-tit mt-10">
                            공사장소{' '}
                            {getColumn('_status') === 'A'
                              ? '등록'
                              : getColumn('_status') === 'U'
                                ? '수정'
                                : '등록 및 수정'}
                          </h3>
                          <div className="form-table">
                            <div className="form-cell wid50">
                              <div className="form-group wid100">
                                <AppTextInput
                                  label="공사장소명"
                                  name="cntrLocationNm"
                                  value={getColumn('cntrLocationNm')}
                                  onChange={(value) => setColumn('cntrLocationNm', value)}
                                  disabled={getColumn('_status') === 'U'} // 수정 상태일 때 비활성화
                                />
                              </div>
                            </div>
                          </div>
                          <div className="form-table">
                            <div className="form-cell wid50">
                              <div className="form-group wid100">
                                <AppCodeSelect
                                  label={'사용여부'}
                                  codeGrpId="CODE_GRP_OC047"
                                  value={getColumn('useYn')}
                                  onChange={(value) => setColumn('useYn', value)}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="btn-area-type01 mb-10 mt-10">
                            <button
                              type="button"
                              name="button"
                              className="btn_confirm text_color_neutral-10"
                              onClick={saveLocationRegister}
                            >
                              저장
                            </button>
                            <button type="button" name="button" className="btn_close" onClick={handleCancel}>
                              취소
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}
export default WorkPermitLocationRegisterModal;
