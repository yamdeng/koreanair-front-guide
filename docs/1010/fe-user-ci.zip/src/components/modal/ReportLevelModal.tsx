import AppSelect from '@/components/common/AppSelect';
import ApiService from '@/services/ApiService';
import { createListSlice } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import dayjs from 'dayjs';
import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import Modal from 'react-modal';
import { create } from 'zustand';
import AppDatePicker from '../common/AppDatePicker';

// TODO : 검색 초기값 설정
const initSearchParam = {
  selectEventId: '',
  selectHazardId: '',
  selectConsequenceId: '',
  selectEventYn: 'Y',
  selectHazardYn: 'Y',
  selectConsequenceYn: 'Y',
  secondSelect: false,
  eventChkNm: '',
  hazardChkNm: '',
  consequenceChkNm: '',
  eventCnt: 0,
  hazardCnt: 0,
  consequenceCnt: 0,
  rtnRiskCode: { riskLevelCd: '', colorCd: '' },
  selectDate: 'searchDate1year',
  fromDt: dayjs().add(-1, 'year').format('YYYY-MM-DD'),
  toDt: dayjs().format('YYYY-MM-DD'),
  searchDateFromDisabled: true,
  searchDateToDisabled: true,
};

/* zustand store 생성 */
const usePSPIReportModalStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    paramEventId: '',
    selectEventId: '',
    selectHazardId: '',
    selectConsequenceId: '',
    selectEventYn: 'Y',
    selectHazardYn: 'Y',
    selectConsequenceYn: 'Y',
    secondSelect: false,
    eventChkNm: '',
    hazardChkNm: '',
    consequenceChkNm: '',
    eventCnt: 0,
    hazardCnt: 0,
    consequenceCnt: 0,
    rtnRiskCode: { riskLevelCd: '', colorCd: '' },
    selectDate: 'searchDate1year',
    fromDt: dayjs().add(-1, 'year').format('YYYY-MM-DD'),
    toDt: dayjs().format('YYYY-MM-DD'),
    searchDateFromDisabled: true,
    searchDateToDisabled: true,
  },

  eventList: [],
  eventInitList: [],
  hazardList: [],
  hazardInitList: [],
  consequenceList: [],
  consequenceInitList: [],
  riskMatrixList: [],
  riskInfo: [],
  riskPbbtInitList: [],
  riskPbbtList: [],
  riskSvrtInitList: [],
  riskSvrtList: [],

  initInfoSearch: async (paramEventId) => {
    const { searchParam, scrollProcess } = get();
    const { fromDt, toDt } = searchParam;

    const apiParam = {
      eventId: paramEventId,
      reportType: null,
      consequenceId: null,
      hazardId: null,
      fromDt: fromDt,
      toDt: toDt,
    };
    const apiResult = await ApiService.get(`avn/common/risk-matrix-info`, apiParam);

    set({ eventList: apiResult.data.event });
    set({ eventInitList: apiResult.data.event });
    set({ hazardList: apiResult.data.hazard });
    set({ hazardInitList: apiResult.data.hazard });
    set({ consequenceList: apiResult.data.consequence });
    set({ consequenceInitList: apiResult.data.consequence });

    set({ riskMatrixList: apiResult.data.riskMatrix });
    set({ riskPbbtInitList: apiResult.data.riskPbbt });
    set({ riskPbbtList: apiResult.data.riskPbbt });
    set({ riskSvrtInitList: apiResult.data.riskSvrt });
    set({ riskSvrtList: apiResult.data.riskSvrt });

    const { changeSearchInput, changeRisk } = get();
    changeSearchInput(
      'eventCnt',
      apiResult.data.event.reduce((prev, cur) => {
        return (prev += cur.cnt);
      }, 0)
    );
    changeSearchInput(
      'hazardCnt',
      apiResult.data.hazard.reduce((prev, cur) => {
        return (prev += cur.cnt);
      }, 0)
    );
    changeSearchInput(
      'consequenceCnt',
      apiResult.data.consequence.reduce((prev, cur) => {
        return (prev += cur.cnt);
      }, 0)
    );

    if (paramEventId) {
      scrollProcess('event', paramEventId);
    }

    changeRisk();
  },
  scrollProcess: (gubun, id) => {
    try {
      const openImmeditlyEventDom = document.getElementById(gubun + id);
      if (openImmeditlyEventDom) {
        openImmeditlyEventDom.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'nearest' });
      }
    } catch (e) {
      //
    }
  },
  changeRisk: () => {
    const { riskMatrixList, selectRisk } = get();
    const rtnArr = [];
    let arr = [];
    riskMatrixList.map((info, index) => {
      arr.push(
        <td
          id={info.riskLevelCd}
          className={info.colorCd}
          onClick={(e) => {
            selectRisk(e, info.riskLevelCd, info.colorCd);
          }}
        >
          {info.riskLevelCd}
          {/* 툴팁 */}
          <div className="flag-tag tooltip">
            <span className="icon-flag txt">{CommonUtil.convertNumberFormat(info.cnt)}</span>
            <div>
              <span className="tooltiptext1 tooltip-right">
                <ul>
                  <li>해당기간동안 평가된 횟수</li>
                </ul>
              </span>
            </div>
          </div>
          {info.rnk < 4 ? (
            <div className="IcoTags">
              <span className="ico-tag">추천</span>
            </div>
          ) : (
            <></>
          )}
        </td>
      );
      if (index % 5 === 4 || index === riskMatrixList.length - 1) {
        const thElement = <th>{5 - Math.floor(index / 5)}</th>;
        rtnArr.push(React.createElement('tr', { key: 'risk' + index }, [thElement, ...arr]));
        arr = [];
      }
    });
    set({ riskInfo: rtnArr });
  },
  selectRisk: (e, id, color) => {
    const { searchParam, changeSearchInput } = get();
    const { selectEventId, hazardId, consequenceId } = searchParam;
    const riskNodes = document.querySelector('#riskTable');
    const selected = riskNodes.querySelector('.selected');
    if (selected) selected.classList.remove('selected');

    e.target.classList.add('selected');
    changeSearchInput('rtnRiskCode', {
      riskLevelCd: id,
      colorCd: color,
      eventId: selectEventId,
      hazardId: hazardId,
      consequenceId: consequenceId,
    });
  },
  initSearchInput: () => {
    const { searchParam } = get();
    const { preEventId } = searchParam;

    set({
      searchParam: {
        ...initSearchParam,
        selectEventId: preEventId,
      },
    });
  },
  enterSearch: () => {
    const { changeRisk, searchParam } = get();
    const {
      selectEventYn,
      selectHazardYn,
      selectConsequenceYn,
      selectEventId,
      selectHazardId,
      selectConsequenceId,
      reportType,
      fromDt,
      toDt,
    } = searchParam;

    const apiParam = {
      selectEventYn: selectEventYn,
      selectHazardYn: selectHazardYn,
      selectConsequenceYn: selectConsequenceYn,
      eventId: selectEventId,
      reportType: reportType,
      hazardId: selectHazardId,
      consequenceId: selectConsequenceId,
      fromDt: fromDt,
      toDt: toDt,
    };

    ApiService.get(`avn/common/risk-matrix-change`, apiParam).then((apiResult) => {
      const detailInfo = apiResult.data || {};
      console.log(detailInfo);

      set({ eventList: detailInfo.event });
      set({ hazardList: detailInfo.hazard });
      set({ consequenceList: detailInfo.consequence });
      set({ riskMatrixList: detailInfo.riskMatrix });

      const { changeSearchInput } = get();
      changeSearchInput(
        'eventCnt',
        detailInfo.event.reduce((prev, cur) => {
          return (prev += cur.cnt);
        }, 0)
      );
      changeSearchInput(
        'hazardCnt',
        detailInfo.hazard.reduce((prev, cur) => {
          return (prev += cur.cnt);
        }, 0)
      );
      changeSearchInput(
        'consequenceCnt',
        detailInfo.consequence.reduce((prev, cur) => {
          return (prev += cur.cnt);
        }, 0)
      );

      changeRisk();
    });
  },
  clear: () => {
    const {
      changeSearchInput,
      riskPbbtInitList,
      riskSvrtInitList,
      eventInitList,
      hazardInitList,
      consequenceInitList,
    } = get();
    set({
      searchParam: { ...initSearchParam },
      riskPbbtList: riskPbbtInitList,
      riskSvrtList: riskSvrtInitList,

      consequenceList: consequenceInitList,
      hazardList: hazardInitList,
      eventList: eventInitList,
    });

    const riskNodes = document.querySelectorAll('.df li');
    riskNodes.forEach((item, index) => {
      item.classList.remove('active');
    });
    changeSearchInput(
      'eventCnt',
      eventInitList.reduce((prev, cur) => {
        return (prev += cur.cnt);
      }, 0)
    );
    changeSearchInput(
      'hazardCnt',
      hazardInitList.reduce((prev, cur) => {
        return (prev += cur.cnt);
      }, 0)
    );
    changeSearchInput(
      'consequenceCnt',
      consequenceInitList.reduce((prev, cur) => {
        return (prev += cur.cnt);
      }, 0)
    );
  },
}));

function ReportLevelModal(props) {
  const state = usePSPIReportModalStore();
  const { t } = useTranslation();

  const {
    searchParam,
    changeSearchInput,
    initInfoSearch,
    scrollProcess,
    eventList,
    hazardList,
    consequenceList,
    riskInfo,
    riskPbbtList,
    riskSvrtList,
    enterSearch,
    clear,
  } = state;

  // input value에 넣기 위한 분리 선언
  const {
    selectEventId,
    selectHazardId,
    selectConsequenceId,
    selectEventYn,
    selectHazardYn,
    selectConsequenceYn,
    eventCnt,
    hazardCnt,
    consequenceCnt,
    rtnRiskCode,
    selectDate,
    fromDt,
    toDt,
    searchDateFromDisabled,
    searchDateToDisabled,
  } = searchParam;

  const { isOpen, closeModal, selectRisk, params } = props;

  const eventUl = useRef();
  const hazardUl = useRef();
  const consequenceUl = useRef();

  const activeControlClick = async (targetGubun, selectGubun, value, name) => {
    if (selectGubun == 'select') scrollProcess(targetGubun, value);

    if (targetGubun == 'consequence') {
      changeSearchInput('selectConsequenceId', value);
    } else if (targetGubun == 'hazard') {
      changeSearchInput('selectHazardId', value);
    } else if (targetGubun == 'event') {
      changeSearchInput('selectEventId', value);
    }

    enterSearch();
  };

  const searchDateChange = (e) => {
    changeSearchInput('selectDate', e.target.id);
    let inputFromDate = dayjs().format('YYYY-MM-DD');
    let inputToDate = dayjs().format('YYYY-MM-DD');
    let searchYn = true;
    changeSearchInput('searchDateFromDisabled', true);
    changeSearchInput('searchDateToDisabled', true);

    if (e.target.id === 'searchDateSelect') {
      inputFromDate = dayjs().format('YYYY-MM-DD');
      inputToDate = dayjs().format('YYYY-MM-DD');
      changeSearchInput('searchDateFromDisabled', false);
      changeSearchInput('searchDateToDisabled', false);
      searchYn = false;
    } else if (e.target.id === 'searchDateTotal') {
      inputFromDate = dayjs('2000-01-01').format('YYYY-MM-DD');
      inputToDate = dayjs('9999-12-31').format('YYYY-MM-DD');
    } else if (e.target.id === 'searchDate3year') {
      inputFromDate = dayjs().add(-3, 'year').format('YYYY-MM-DD');
      inputToDate = dayjs().format('YYYY-MM-DD');
    } else if (e.target.id === 'searchDate1year') {
      inputFromDate = dayjs().add(-1, 'year').format('YYYY-MM-DD');
      inputToDate = dayjs().format('YYYY-MM-DD');
    } else if (e.target.id === 'searchDate6month') {
      inputFromDate = dayjs().add(-6, 'month').format('YYYY-MM-DD');
      inputToDate = dayjs().format('YYYY-MM-DD');
    }

    changeSearchInput('fromDt', inputFromDate);
    changeSearchInput('toDt', inputToDate);
    if (searchYn) enterSearch();
  };

  useEffect(() => {
    if (params.paramEventId) changeSearchInput('selectEventId', Number(params.paramEventId));
    if (isOpen) initInfoSearch(params.paramEventId);

    return clear;
  }, [isOpen, params]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'risk-level-search-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">위험레벨 조회</h3>
        <div className="pop_full_cont_box">
          <div className="RiskLevel-searchbox">
            {/*검색영역*/}
            <div className="search-area">
              <div className="form-table">
                <div className="form-area">
                  <div className="flag-tag1">
                    <span
                      id="searchDateSelect"
                      className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDateSelect' ? 'active' : ''}`}
                      onClick={(e) => {
                        searchDateChange(e);
                      }}
                    >
                      기간선택
                    </span>
                    <span
                      id="searchDateTotal"
                      className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDateTotal' ? 'active' : ''}`}
                      onClick={(e) => {
                        searchDateChange(e);
                      }}
                    >
                      전체
                    </span>
                    <span
                      id="searchDate3year"
                      className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDate3year' ? 'active' : ''}`}
                      onClick={(e) => {
                        searchDateChange(e);
                      }}
                    >
                      최근3년
                    </span>
                    <span
                      id="searchDate1year"
                      className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDate1year' ? 'active' : ''}`}
                      onClick={(e) => {
                        searchDateChange(e);
                      }}
                    >
                      1년
                    </span>
                    <span
                      id="searchDate6month"
                      className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDate6month' ? 'active' : ''}`}
                      onClick={(e) => {
                        searchDateChange(e);
                      }}
                    >
                      6개월
                    </span>
                    {/* 선택되는 부분은 class명에 active 표시*/}
                  </div>
                  <div className="form-cell">
                    <div className="form-group">
                      <div className="df">
                        <div className="date1">
                          <AppDatePicker
                            id="searchDateFrom"
                            label={t('ke_change_mgmt_label_00556')}
                            pickerType="date"
                            value={fromDt}
                            onChange={(value) => {
                              changeSearchInput('fromDt', value);
                            }}
                            disabled={searchDateFromDisabled}
                            required
                          />
                        </div>
                        <span className="unt">~</span>
                        <div className="date2">
                          <AppDatePicker
                            id="searchDateTo"
                            label={t('ke_report_label_00203')}
                            pickerType="date"
                            value={toDt}
                            onChange={(value) => {
                              changeSearchInput('toDt', value);
                            }}
                            disabled={searchDateToDisabled}
                            required
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pop_btns_">
                  <button className="btn_text text_color_neutral-10 btn_confirm" onClick={enterSearch}>
                    조회
                  </button>
                  <button className="btn_text text_color_neutral-10 btn_confirm" onClick={clear}>
                    초기화
                  </button>
                </div>
              </div>
            </div>
            {/*//검색영역*/}
          </div>
          <div className="RiskLevel-box">
            <div className="RiskLevel-list">
              <div className="df">
                <div className="list-box-a">
                  <div className="chk-wrap">
                    <label>
                      <input
                        type="checkbox"
                        checked={selectEventYn === 'Y' ? true : false}
                        onChange={(e) => {
                          changeSearchInput('selectEventYn', e.target.checked ? 'Y' : 'N');
                          enterSearch();
                        }}
                      />
                      <span>
                        Event Type :
                        <span className="txt">
                          <em>{CommonUtil.convertNumberFormat(eventCnt)}</em>건
                        </span>
                      </span>
                    </label>
                  </div>
                  <div className="form-table">
                    <div className="form-cell">
                      <div className="form-group wid100">
                        <AppSelect
                          id="eventSelect"
                          name="eventSelect"
                          labelKey="eventNm"
                          valueKey="eventId"
                          options={eventList}
                          value={selectEventId}
                          onChange={(value, info) => activeControlClick('event', 'select', value, info.eventNm)}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="box-list">
                    <ul className="list" id="eventUl" ref={eventUl}>
                      {eventList.map((info, index) => {
                        const { eventId, reportTypeCd, eventNm, eventNmStr } = info;
                        return (
                          <li
                            key={'event' + eventId}
                            id={'event' + eventId}
                            className={selectEventId === eventId ? 'active' : ''}
                            onClick={(e) => activeControlClick('event', 'list', eventId, eventNm)}
                          >
                            <a href={undefined}>{eventNmStr}</a>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>
                <div className="list-box-b">
                  <div className="chk-wrap">
                    <label>
                      <input
                        type="checkbox"
                        checked={selectHazardYn === 'Y' ? true : false}
                        onChange={(e) => {
                          changeSearchInput('selectHazardYn', e.target.checked ? 'Y' : 'N');
                          enterSearch();
                        }}
                      />
                      <span>
                        Hazard Taxonomy :
                        <span className="txt">
                          <em>{CommonUtil.convertNumberFormat(hazardCnt)}</em>건
                        </span>
                      </span>
                    </label>
                  </div>
                  <div className="form-table">
                    <div className="form-cell">
                      <div className="form-group wid100">
                        <AppSelect
                          id="hazardSelect"
                          name="hazardSelect"
                          labelKey="hazardLvthreeNm"
                          valueKey="hazardLvthreeId"
                          options={hazardList}
                          value={selectHazardId}
                          onChange={(value, info) =>
                            activeControlClick('hazard', 'select', value, info.hazardLvthreeNm)
                          }
                        />
                      </div>
                    </div>
                  </div>
                  <div className="box-list">
                    <ul className="list" id="hazardUl" ref={hazardUl}>
                      {hazardList.map((info, index) => {
                        const { hazardLvthreeId, hazardLvthreeNm, hazardLvthreeNmStr } = info;
                        return (
                          <li
                            key={'hazard' + hazardLvthreeId}
                            id={'hazard' + hazardLvthreeId}
                            className={selectHazardId === hazardLvthreeId ? 'active' : ''}
                            onClick={(e) => activeControlClick('hazard', 'list', hazardLvthreeId, hazardLvthreeNm)}
                          >
                            <a href={undefined}>{hazardLvthreeNmStr}</a>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>
                <div className="list-box-c">
                  <div className="chk-wrap">
                    <label>
                      <input
                        type="checkbox"
                        checked={selectConsequenceYn === 'Y' ? true : false}
                        onChange={(e) => {
                          changeSearchInput('selectConsequenceYn', e.target.checked ? 'Y' : 'N');
                          enterSearch();
                        }}
                      />
                      <span>
                        Potential Consequence :
                        <span className="txt">
                          <em>{CommonUtil.convertNumberFormat(consequenceCnt)}</em>건
                        </span>
                      </span>
                    </label>
                  </div>
                  <div className="form-table">
                    <div className="form-cell">
                      <div className="form-group wid100">
                        <AppSelect
                          id="consequenceSelect"
                          name="consequenceSelect"
                          labelKey="consequenceKoNm"
                          valueKey="consequenceId"
                          options={consequenceList}
                          value={selectConsequenceId}
                          onChange={(value, info) =>
                            activeControlClick('consequence', 'select', value, info.consequenceKoNm)
                          }
                        />
                      </div>
                    </div>
                  </div>
                  <div className="box-list">
                    <ul className="list" id="consequenceUl" ref={consequenceUl}>
                      {consequenceList.map((info, index) => {
                        const { consequenceId, consequenceKoNm, consequenceKoNmStr } = info;
                        return (
                          <li
                            key={'consequence' + consequenceId}
                            id={'consequence' + consequenceId}
                            className={selectConsequenceId === consequenceId ? 'active' : ''}
                            onClick={(e) => activeControlClick('consequence', 'list', consequenceId, consequenceKoNm)}
                          >
                            <a href={undefined}>{consequenceKoNmStr}</a>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="RiskLevel-area">
              <div className="Level-area">
                <div className="LevelTop">
                  <div className="flex-box">
                    <div className="h5-tit">Risk</div>
                  </div>
                  <div className="">
                    <table className="RiskLevelTable Risk">
                      <caption></caption>
                      <colgroup></colgroup>
                      <thead>
                        <tr>
                          <th rowSpan={2}>
                            발생
                            <br />
                            가능성
                          </th>
                          <th colSpan={5}>심각도</th>
                        </tr>
                        <tr>
                          <th>LevelA</th>
                          <th>LevelB</th>
                          <th>LevelC</th>
                          <th>LevelD</th>
                          <th>LevelE</th>
                        </tr>
                      </thead>
                      <tbody id="riskTable">{riskInfo}</tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div className="LevelInfo mt10">
                <p className="h5-tit">발생 가능성</p>
                <div className="tableTop">
                  <table className="RiskLevelTable left">
                    <caption></caption>
                    <colgroup></colgroup>
                    <thead>
                      <tr>
                        <th>구분</th>
                        <th>발생가능성</th>
                        <th>정성적평가</th>
                        <th>정량적평가</th>
                      </tr>
                    </thead>
                    <tbody>
                      {riskPbbtList.map((info, index) => {
                        const { codeNameKor, codeField1, codeField2 } = info;
                        return (
                          <tr key={'Pbbt' + index}>
                            <th>{riskPbbtList.length - index}</th>
                            <td className="">{codeNameKor}</td>
                            <td className="tl">{codeField1}</td>
                            <td className="tl">{codeField2}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="Level-area-bottom">
                <p className="h5-tit">심각도</p>
                <div className="tableTop">
                  <table className="RiskLevelTable severity">
                    <caption></caption>
                    <colgroup></colgroup>
                    <thead>
                      <tr>
                        <th>순번</th>
                        <th>심각도구분</th>
                        <th>매우심각</th>
                        <th>위험</th>
                        <th>중요</th>
                        <th>경이</th>
                        <th>매우경미</th>
                      </tr>
                    </thead>
                    <tbody>
                      {riskSvrtList.map((info, index) => {
                        const { codeNameKor, codeField1, codeField2, codeField3, codeField4, codeField5 } = info;
                        return (
                          <tr key={'Svrt' + index}>
                            <th>{index + 1}</th>
                            <td className="">{codeNameKor}</td>
                            <td className="">{codeField1}</td>
                            <td className="">{codeField2}</td>
                            <td className="">{codeField3}</td>
                            <td className="">{codeField4}</td>
                            <td className="">{codeField5}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="pop_btns">
          <button
            className="btn_text text_color_neutral-90 btn_close"
            onClick={() => {
              clear();
              closeModal();
            }}
          >
            닫기
          </button>
          <button
            className="btn_text text_color_neutral-10 btn_confirm"
            onClick={() => {
              if (rtnRiskCode.riskLevelCd) {
                selectRisk(rtnRiskCode);
                clear();
                closeModal();
              } else {
                alert('선택된 리스크가 없습니다.');
              }
            }}
          >
            선택
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default ReportLevelModal;
