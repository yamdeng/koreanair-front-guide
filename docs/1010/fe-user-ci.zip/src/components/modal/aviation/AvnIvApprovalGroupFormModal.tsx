import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';
import AppTextInput from '@/components/common/AppTextInput';
import AppSelect from '@/components/common/AppSelect';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import ApiService from '@/services/ApiService';
import ToastService from '@/services/ToastService';
import ConfirmModal from '@/components/modal/ConfirmModal';
import AvnReportUserSelect from '@/components/aviation/common/AvnReportUserSelect';
import { el, HelpersModule } from '@faker-js/faker';

const formName = 'AvnIvApprovalGroupFormModal';

/* yup validation */
const yupFormGroupSchema = yup.object({
  group: yup.object().shape({
    groupName: yup.string().required('결재 Group명은 필수 입력 항목입니다.'),
  }),
});

const yupFormGroupMemberSchema = yup.object({
  memberInfo: yup.object().shape({
    groupId: yup.number().required('결재 그룹명을 선택해주세요'),
  }),
});

/* form 초기화 */
const initFormValue = {
  group: {
    groupName: '', //그룹명
    insertGroupFlag: 'N',
  },
  member: [],
  memberList: [],
  memberInfo: {
    groupId: null, //그룹ID
    viewSn: null, //멤버순번
    empNo: '', //소속 사원 번호
  },
};

function AvnIvApprovalGroupFormModal(props) {
  //결재그룹정보 설정 팝업
  const { isOpen, closeModal, getGroupIvReportEdit } = props;
  //결재그룹신규 팝업
  const [isLayerPopup, setIsLayerPopup] = useState('hide');
  //초기데이터
  const [formValueModal, setFormValueModal] = useImmer({ ...initFormValue });
  //error
  const [errors, setErrors] = useState<any>({});
  //입력시 페이지 이동 확인 팝업
  const [isDirty, setIsDirty] = useState(false);
  //결재 그룹 리스트
  const [groupList, setGroupList] = useState([]);
  //결재 그룹 확인 팝업창 설정
  const [isConfirm, setIsConfirm] = useState(false);
  //결재 그룹 삭제 팝업창 설정
  const [isDeleteConfirm, setIsDeleteConfirm] = useState(false);
  // //결재 그룹 삭제 ID
  // const [removeGroupId, setRemoveGroupId] = useState(null);
  //결재 멤버 삭제 번호
  const [removeIndex, setRemoveIndex] = useState(null);

  const { group, memberInfo, member } = formValueModal;
  const { groupName, insertGroupFlag } = group;
  const { groupId, viewSn, empNo } = memberInfo;

  //확인 팝업창
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);

  //삭제 확인 팝업창
  const [isDeleteConfirmModalOpen, setIsDeleteConfirmModalOpen] = useState(false);

  //초기화 확인 팝업창
  const [isInitConfirmModalOpen, setIsInitConfirmModalOpen] = useState(false);

  //결재그룹 신규 확인 모달 확인 버튼 클릭 시
  const groupConfirmModalOk = () => {
    setIsConfirmModalOpen(false);
    saveGroup();
  };
  //결재그룹 신규  확인 모달 취소 버튼 클릭 시
  const groupConfirmModalCancel = async () => {
    setIsConfirmModalOpen(false);
  };
  //확인모달 끝

  //결재그룹정보 설정 확인 모달 확인 버튼 클릭 시
  const groupMemberConfirmModalOk = () => {
    setIsConfirmModalOpen(false);
    changeInputGroupModal('insertGroupFlag', 'N');
    saveGroupMember();
  };
  //결재그룹정보 설정 취소 버튼 클릭 시
  const groupMemberConfirmModalCancel = async () => {
    setIsConfirmModalOpen(false);
    changeInputGroupModal('insertGroupFlag', 'Y');
  };

  //결재 그룹 삭제 확인 버튼 클릭 시
  const deleteGroupConfrimModalOk = async () => {
    setIsDeleteConfirmModalOpen(false);
    const groupId = formValueModal.memberInfo.groupId;
    const result = await ApiService.delete(`avn/common/approval/group/delete/${groupId}`);
    if (result) {
      setIsLayerPopup('hide');
      ToastService.success('삭제되었습니다.');
      getGroup();
      setIsDeleteConfirm(false);
      memberListClear();
    }
  };

  const deleteGroupConfrimModalCancle = () => {
    setIsDeleteConfirm(false);
    setIsDeleteConfirmModalOpen(false);
  };

  //결재 그룹 삭제 확인 버튼 클릭 시
  const initGroupMemberConfrimModalOk = async () => {
    setIsInitConfirmModalOpen(false);
    const groupId = formValueModal.memberInfo.groupId;
    const result = await ApiService.delete(`avn/common/approval/group/member/init/${groupId}`);
    if (result) {
      setIsLayerPopup('hide');
      ToastService.success('초기화되었습니다.');
      getGroup();
      memberListClear();
    }
  };

  const initGroupMemberConfrimModalCancle = () => {
    setIsInitConfirmModalOpen(false);
  };

  //결재 그룹멤버 삭제 확인 버튼 클릭 시
  const deleteMemberConfirmModalOk = async () => {
    setIsDeleteConfirmModalOpen(false);
    const deleteTarget = formValueModal.memberList[removeIndex];
    const groupId = deleteTarget.groupId;
    const memberEmpNo = deleteTarget.empNo;
    setFormValueModal((formValueModal) => {
      formValueModal.member.splice(removeIndex, 1);
      formValueModal.memberList.splice(removeIndex, 1);
    });

    const result = await ApiService.delete(`avn/common/approval/group/member/delete/${groupId}/${memberEmpNo}`);
    if (result) {
      setIsLayerPopup('hide');
      ToastService.success('삭제되었습니다.');
      setIsDeleteConfirm(false);
    }
  };
  //결재 그룹멤버 삭제 취소 버튼 클릭 시
  const deleteMemberConfirmModalCancle = () => {
    setIsDeleteConfirmModalOpen(false);
    setRemoveIndex(null);
  };
  //확인모달 끝

  //결재그룹정보 > 결재 그룹명 선택 시
  const changeInputGroupMemberModal = (inputName, inputValue) => {
    setFormValueModal((formValueModal) => {
      formValueModal.memberInfo[inputName] = inputValue;
    });

    setIsDirty(true);
  };

  //결재Group명 신규 등록
  const changeInputGroupModal = (inputName, inputValue) => {
    setFormValueModal((formValueModal) => {
      formValueModal.group[inputName] = inputValue;
    });
    setIsDirty(true);
  };

  //결재그룹 불러오기
  const getGroup = async () => {
    const dataList = await ApiService.get('avn/common/approvalGroupList');
    const groupData = dataList.data;
    setGroupList(groupData);
  };

  //결재그룹에 소속된 멤버 목록 조회
  const getMember = async (groupId) => {
    const params = { groupId: groupId };
    const dataList = await ApiService.get('avn/common/approvalGroupMemberList', params);
    if (dataList.data.approvalGroupMember.length > 0) {
      const groupMemberData = dataList.data;
      setFormValueModal((formValueModal) => {
        const groupMemberList = formValueModal.member;
        const approvalGroupMemberList = formValueModal.memberList;
        approvalGroupMemberList.push(...groupMemberData.approvalGroupMember);
        groupMemberList.push(...groupMemberData.GroupMemberInfo);
      });
    }
  };

  //결재그룹 신규 등록
  const saveGroup = async () => {
    //결재그룹생성API
    const result = await ApiService.post(`avn/common/approval`, formValueModal);
    if (result) {
      setIsLayerPopup('hide');
      ToastService.success('저장되었습니다.');
      getGroup();
      getGroupIvReportEdit();
    }
  };

  //결재 Group Member 선택 시
  const onSelectMember = (selectedValue) => {
    setFormValueModal((formValueModal) => {
      const approvalGroupMemberList = formValueModal.member;
      if (!approvalGroupMemberList.find((target) => target.empNo == selectedValue.empNo)) {
        formValueModal.member.push({ ...selectedValue });
        const newIndex = formValueModal.memberList.length;
        formValueModal.memberList.push({
          groupId: formValueModal.memberInfo.groupId,
          empNo: selectedValue.empNo,
          viewSn: newIndex,
        });
      }
    });
  };

  //결재 Group 삭제 버튼 클릭 시
  const deleteGroup = () => {
    setIsDeleteConfirm(true);
    setIsDeleteConfirmModalOpen(true);
  };

  //결재 Group Member 삭제 버튼 클릭 시
  const deleteMember = (removeIndex) => {
    setIsDeleteConfirm(false);
    setRemoveIndex(removeIndex);
    setIsDeleteConfirmModalOpen(true);
  };

  //결재 그룹 멤버 순번 Up
  const memberUp = (listIndex) => {
    setFormValueModal((formValueModal) => {
      if (listIndex > 0) {
        const beforeInfo = formValueModal.member[listIndex];
        const nextInfo = formValueModal.member[listIndex - 1];
        formValueModal.member[listIndex - 1] = beforeInfo;
        formValueModal.member[listIndex] = nextInfo;

        const beforeListInfo = formValueModal.memberList[listIndex];
        beforeListInfo.viewSn = listIndex - 1;
        const nextListInfo = formValueModal.memberList[listIndex - 1];
        nextListInfo.viewSn = listIndex;

        formValueModal.memberList[listIndex - 1] = beforeListInfo;
        formValueModal.memberList[listIndex] = nextListInfo;
      }
    });
  };

  //결재 그룹 멤버 순번 Down
  const memberDown = (listIndex) => {
    setFormValueModal((formValueModal) => {
      if (listIndex < formValueModal.member.length - 1) {
        const beforeInfo = formValueModal.member[listIndex];
        const nextInfo = formValueModal.member[listIndex + 1];
        formValueModal.member[listIndex + 1] = beforeInfo;
        formValueModal.member[listIndex] = nextInfo;

        const beforeListInfo = formValueModal.memberList[listIndex];
        beforeListInfo.viewSn = listIndex + 1;
        const nextListInfo = formValueModal.memberList[listIndex + 1];
        nextListInfo.viewSn = listIndex;

        formValueModal.memberList[listIndex + 1] = beforeListInfo;
        formValueModal.memberList[listIndex] = nextListInfo;
      }
    });
  };

  // 결재 그룹 멤버 초기화
  const memberListClear = () => {
    setFormValueModal((formValueModal) => {
      formValueModal.member = [];
      formValueModal.memberList = [];
      formValueModal.group = { ...initFormValue.group };
      formValueModal.memberInfo = { ...initFormValue.memberInfo };
    });
  };

  //결재그룹 멤버 신규 등록 or 수정
  const saveGroupMember = async () => {
    //결재그룹멤버생성API
    const result = await ApiService.post(`avn/common/approval`, formValueModal);

    if (result) {
      setIsLayerPopup('hide');
      ToastService.success('저장되었습니다.');
      getGroup();
      closeModal();
    }
  };

  //

  useEffect(() => {
    // TODO : isOpen일 경우에 상세 api 호출 할지 결정 : if(isOpen)
    if (isOpen) {
      memberListClear();
      getGroup();
    }
  }, [isOpen]); //isOpen, detailInfo

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'alert-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">결재그룹정보 설정</h3>
        <div className="pop_lg_cont_box">
          <div className="pop_flex_group">
            <div className="editbox">
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppSelect
                      id="AvnIvApprovalGroupSelectFormgroupName"
                      label={'결재Group 명'}
                      value={groupId}
                      onChange={(value) => {
                        memberListClear();
                        changeInputGroupMemberModal('groupId', value);
                        getMember(value);
                      }}
                      options={groupList}
                      labelKey="groupName"
                      valueKey="id"
                      required
                      errorMessage={errors['memberInfo.groupId']}
                    />
                  </div>
                  <div className="btn-area inbtn">
                    <button
                      type="button"
                      name="button"
                      className="btn-x-sm btn_text btn-darkblue-line"
                      onClick={() => {
                        setIsLayerPopup('show');
                        changeInputGroupModal('groupName', '');
                      }}
                    >
                      신규
                    </button>
                    <button
                      type="button"
                      name="button"
                      className="ml3 btn-x-sm btn_text btn-darkgray-line"
                      onClick={async () => {
                        if (groupId == null) {
                          const validateResult = await CommonUtil.validateYupForm(
                            yupFormGroupMemberSchema,
                            formValueModal
                          );
                          const { errors } = validateResult;
                          setErrors(errors);
                          document.getElementById('AvnIvApprovalGroupSelectFormgroupName').focus();
                        } else {
                          deleteGroup();
                        }
                      }}
                    >
                      삭제
                    </button>
                  </div>
                </div>
              </div>

              <hr className="line"></hr>

              <div className="form-table">
                <div className="form-cell">
                  <div className="form-group wid100">
                    <div className="UserChicebox">
                      <div className="form-group wid100">
                        <AvnReportUserSelect
                          label="결재Group Member"
                          displaySort
                          userList={member}
                          onSelect={onSelectMember}
                          deleteUser={deleteMember}
                          up={memberUp}
                          down={memberDown}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="btn-area">
                    <button
                      type="button"
                      name="button"
                      className="btn-x-sm btn_text btn-darkblue-line"
                      onClick={async () => {
                        if (groupId == null) {
                          const validateResult = await CommonUtil.validateYupForm(
                            yupFormGroupMemberSchema,
                            formValueModal
                          );
                          const { errors } = validateResult;
                          setErrors(errors);
                          document.getElementById('AvnIvApprovalGroupSelectFormgroupName').focus();
                        } else {
                          setIsInitConfirmModalOpen(true);
                        }
                      }}
                    >
                      초기화
                    </button>
                  </div>
                </div>
              </div>

              <hr className="line"></hr>
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button
            className="btn_text text_color_neutral-10 btn_confirm"
            onClick={async () => {
              if (groupId == null) {
                const validateResult = await CommonUtil.validateYupForm(yupFormGroupMemberSchema, formValueModal);
                const { errors } = validateResult;
                setErrors(errors);
                document.getElementById('AvnIvApprovalGroupSelectFormgroupName').focus();
              } else {
                setIsConfirm(false);
                setIsConfirmModalOpen(true);
              }
            }}
          >
            저장
          </button>
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            취소
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>

        {/*레이어팝업 */}
        <div className={`modal-overlay ${isLayerPopup}`}></div>
        <div className={`modal ${isLayerPopup}`}>
          <div className="pop_lg_cont_box">
            <div className="pop_flex_group">
              <div className="editbox">
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="AvnIvApprovalGroupFormgroupName"
                        name="groupName"
                        label={'결재Group 명'}
                        value={groupName}
                        onChange={(value) => {
                          changeInputGroupModal('insertGroupFlag', 'Y');
                          changeInputGroupModal('groupName', value);
                        }}
                        errorMessage={errors['group.groupName']}
                        required
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
              </div>
            </div>
          </div>
          <div className="pop_btns">
            <button
              className="btn_text text_color_neutral-10 btn_confirm"
              onClick={async () => {
                if (groupName == '') {
                  const validateResult = await CommonUtil.validateYupForm(yupFormGroupSchema, formValueModal);
                  const { errors } = validateResult;
                  setErrors(errors);
                  document.getElementById('AvnIvApprovalGroupFormgroupName').focus();
                } else {
                  setIsConfirm(true);
                  setIsConfirmModalOpen(true);
                }
              }}
            >
              저장
            </button>
            <button
              // disabled
              className="btn_text text_color_neutral-90 btn_close"
              onClick={() => {
                setIsLayerPopup('hide');
              }}
            >
              취소
            </button>
          </div>
        </div>
      </div>
      {/* 확인 팝업창 */}
      <ConfirmModal
        title={'저장하시겠습니까?'}
        body=""
        okLabel="저장"
        cancelLabel="닫기"
        isOpen={isConfirmModalOpen}
        closeModal={() => setIsConfirmModalOpen(false)}
        cancel={isConfirm == false ? groupMemberConfirmModalCancel : groupConfirmModalCancel}
        ok={isConfirm == false ? groupMemberConfirmModalOk : groupConfirmModalOk}
      />
      {/* 삭제 확인 팝업창 */}
      <ConfirmModal
        title={'삭제하시겠습니까?'}
        body=""
        okLabel="삭제"
        cancelLabel="닫기"
        isOpen={isDeleteConfirmModalOpen}
        closeModal={() => setIsDeleteConfirmModalOpen(false)}
        cancel={isDeleteConfirm == false ? deleteMemberConfirmModalCancle : deleteGroupConfrimModalCancle}
        ok={isDeleteConfirm == false ? deleteMemberConfirmModalOk : deleteGroupConfrimModalOk}
      />
      {/* 초기화 확인 팝업창 */}
      <ConfirmModal
        title={'등록된 멤버를 초기화 하시겠습니까?'}
        body=""
        okLabel="초기화"
        cancelLabel="닫기"
        isOpen={isInitConfirmModalOpen}
        closeModal={() => setIsInitConfirmModalOpen(false)}
        cancel={initGroupMemberConfrimModalCancle}
        ok={initGroupMemberConfrimModalOk}
      />
    </Modal>
  );
}

export default AvnIvApprovalGroupFormModal;
