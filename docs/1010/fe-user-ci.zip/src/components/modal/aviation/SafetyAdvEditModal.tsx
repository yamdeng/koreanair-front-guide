import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';
import AppTextInput from '@/components/common/AppTextInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppTextArea from '@/components/common/AppTextArea';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import ConfirmModal from '@/components/modal/ConfirmModal';

//오늘 날짜 만들기
const today = new Date();
const year = today.getFullYear(); // 년도
const month = today.getMonth() + 1; // 월
const date = today.getDate(); // 날짜
// const nowHours = today.getHours(); //시
// const nowMins = today.getMinutes(); //분
let monthString = '';
let dateString = '';
if (month < 10) {
  monthString = '0' + month;
} else {
  monthString = month.toString();
}
if (date < 10) {
  dateString = '0' + date;
} else {
  dateString = date.toString();
}
const todayString = year + '-' + monthString + '-' + dateString;

const formName = 'SafetyAdvEditModal';

/* form 초기화 */
const initsafetyAdvFormValue = {
  id: null,
  caId: null,
  recommendNo: '',
  recommend: '',
  actionTaken: '',
  deptCd: '',
  empNo: '',
  issueAt: todayString,
  dueAt: todayString,
  fileGroupSeq: null,
};

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SafetyAdvEditModalModal(props) {
  const profile = useStore(useAppStore, (state) => state.profile);
  const { isOpen, closeModal, safetyAdvList, editIndex, editType, safetyAdvEditSave, deleteCarecommendOk, reportId } =
    props;
  const [safetyAdvFormValue, setsafetyAdvFormValue] = useImmer({ ...initsafetyAdvFormValue });
  const [errors, setErrors] = useState<any>({});
  const [isDirty, setIsDirty] = useState(false);

  //삭제 확인 팝업화면
  const [isDeleteCa, setIsDeleteCA] = useState(false);
  const isDeleteCaClose = () => {
    setIsDeleteCA(false);
  };

  const { id, caId, recommendNo, recommend, actionTaken, deptCd, empNo, issueAt, dueAt, fileGroupSeq } =
    safetyAdvFormValue;

  const changeInput = async (inputName, inputValue) => {
    await setsafetyAdvFormValue((safetyAdvFormValue) => {
      safetyAdvFormValue[inputName] = inputValue;
    });
    setIsDirty(true);
  };

  const deleteCa = () => {
    setIsDeleteCA(true);
  };

  useEffect(() => {
    // TODO : isOpen일 경우에 상세 api 호출 할지 결정 : if(isOpen)
    if (isOpen) {
      if (editType == 'edit') {
        setsafetyAdvFormValue(safetyAdvList[editIndex]);
      }
    } else {
      setsafetyAdvFormValue(initsafetyAdvFormValue);
      changeInput('empNo', profile.userInfo.empNo);
    }
  }, [isOpen]);

  return (
    <>
      <Modal
        shouldCloseOnOverlayClick={false}
        isOpen={isOpen}
        ariaHideApp={false}
        overlayClassName={'alert-modal-overlay'}
        className={'list-common-modal-content'}
        onRequestClose={() => {
          closeModal();
        }}
      >
        <div className="popup-container">
          <h3 className="pop_title">안전권고 관리</h3>

          <div className="pop_cont">
            {/*등록 */}
            <div className="editbox">
              <div className="form-table">
                <div className="form-table line">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="SafetyAdvEditModalRecommendNo"
                        name="recommendNo"
                        label="번호"
                        value={recommendNo}
                        disabled
                      />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="SafetyAdvEditModalDeptCd"
                        name="deptCd"
                        label="부서"
                        value={deptCd}
                        onChange={(value) => changeInput('deptCd', value)}
                        errorMessage={errors.deptCd}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
              <div className="form-table line">
                <div className="form-cell wid50">
                  <div className="form-group wid50">
                    <AppDatePicker
                      id="SafetyAdvEditModalissueAt"
                      name="issueAt"
                      label={'발행일자'}
                      value={issueAt}
                      onChange={(value) => changeInput('issueAt', value)}
                      errorMessage={errors.issueAt}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid50">
                    <AppDatePicker
                      id="SafetyAdvEditModalissueAt"
                      name="dueAt"
                      label={'회신일자'}
                      value={dueAt}
                      onChange={(value) => changeInput('dueAt', value)}
                      errorMessage={errors.issueAt}
                    />
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
              <div className="form-table line">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextArea
                      id="SafetyAdvEditModalrecommend"
                      name="recommend"
                      label="안전권고"
                      value={recommend}
                      onChange={(value) => changeInput('recommend', value)}
                      style={{ width: '100%', height: 145 }}
                      errorMessage={errors.recommend}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextArea
                      id="SafetyAdvEditModalactionTaken"
                      name="actionTaken"
                      label="조치사항"
                      value={actionTaken}
                      onChange={(value) => changeInput('actionTaken', value)}
                      errorMessage={errors.actionTaken}
                      style={{ width: '100%', height: 145 }}
                    />
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
              <div className="form-table line">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    {/* 파일첨부영역 : drag */}
                    <AppFileAttach
                      id="SafetyAdvEditModalfileGroupSeq"
                      name="fileGroupSeq"
                      label="첨부파일"
                      fileGroupSeq={fileGroupSeq}
                      workScope={'A'}
                      updateFileGroupSeq={(newFileGroupSeq) => {
                        // TODO : newFileGroupSeq를 handle
                        changeInput('fileGroupSeq', newFileGroupSeq);
                      }}
                      errorMessage={errors.fileGroupSeq}
                    />
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
            </div>
            {/*//등록 */}
          </div>
          <div className="pop_btns">
            <button className="btn_text text_color_neutral-90 btn_close" onClick={deleteCa}>
              삭제
            </button>
            <button
              className="btn_text text_color_neutral-10 btn_confirm"
              onClick={() => {
                safetyAdvEditSave(safetyAdvFormValue, editIndex, editType);
                closeModal();
              }}
            >
              임시저장
            </button>
            <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
              닫기
            </button>
          </div>
          <span className="pop_close" onClick={closeModal}>
            X
          </span>
        </div>

        {/*style="z-index: 1002; display: block; opacity: 0.5;"*/}
      </Modal>
      <ConfirmModal
        title={'삭제 하시겠습니까?'}
        body=""
        okLabel="확인"
        cancelLabel="취소"
        isOpen={isDeleteCa}
        closeModal={() => isDeleteCaClose()}
        cancel={isDeleteCaClose}
        ok={() => deleteCarecommendOk(reportId, editIndex, closeModal, isDeleteCaClose)}
      />
    </>
  );
}
export default SafetyAdvEditModalModal;
