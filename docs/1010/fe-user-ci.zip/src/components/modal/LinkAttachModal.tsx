import AppTextInput from '@/components/common/AppTextInput';
import CommonUtil from '@/utils/CommonUtil';
import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import { useImmer } from 'use-immer';
import * as yup from 'yup';

const formName = 'useSysMessageForm';

/* yup validation */
const yupFormSchema = yup.object({
  linkSbj: yup.string().required(),
  linkUrl: yup.string().required(),
});

/* form 초기화 */
const initFormValue = {
  linkSbj: '',
  linkUrl: '',
};

function LinkAttachModal(props) {
  const { isOpen, closeModal, ok, detailInfo, linkAttachListLindex } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});

  const { linkUrl, linkSbj } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
  };

  const handleClose = () => {
    closeModal();
  };

  const save = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;
    if (success) {
      ok(formValue, linkAttachListLindex);
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  useEffect(() => {
    if (isOpen) {
      if (detailInfo) {
        const { linkUrl, linkSbj } = detailInfo;
        setFormValue({
          linkUrl: linkUrl,
          linkSbj: linkSbj,
        });
      } else {
        setFormValue({
          linkUrl: '',
          linkSbj: '',
        });
      }
    }
  }, [isOpen, detailInfo]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'confirm-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">첨부 Link</h3>
        <div className="pop_cont">
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    id="useSysMessageFormlinkSbj"
                    label="주제"
                    value={linkSbj}
                    onChange={(value) => changeInput('linkSbj', value)}
                    required
                    errorMessage={errors.linkSbj}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    id="useSysMessageFormlinkUrl"
                    label="URL"
                    value={linkUrl}
                    onChange={(value) => changeInput('linkUrl', value)}
                    required
                    errorMessage={errors.linkUrl}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            닫기
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
            저장
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default LinkAttachModal;
