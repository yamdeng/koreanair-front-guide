import AppTextInput from '@/components/common/AppTextInput';
//import useSysCodeFormStore from '@/stores/admin/useSysCodeFormStore';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppSelect from '@/components/common/AppSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';

import { useOcuCostModalFormStore } from '@/stores/occupation/general/useOcuCostPerformanceListStore';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDeptListSelectInput from '@/components/common/AppDeptListSelectInput';
import AppTextArea from '@/components/common/AppTextArea';
import { useEffect, useState, useCallback } from 'react';
//import useOcuCostFormStore from '@/stores/occupation/general/useOcuCostFormStore';

import Modal from 'react-modal';

function CostExecFormModal(props) {
  const { isOpen, closeModal, ok } = props;

  const { formValue, errors, changeInput, save, execDelete } = useOcuCostModalFormStore();

  const {
    // 부문명
    sectNm,
    // Resp Center
    respCenter,
    // Cost Center
    costCenter,
    // Cost Center 명
    costCenterNm,
    // Account Name
    acntNm,
    // Account Cd
    acntCd,
    // Invoice Date
    invoiceDt,
    // Invoice Number
    invoiceNo,
    // Amount
    drAmt,
    // Supplier
    vendorNm,
    // GL Date
    glDt,
    // Description
    lineDesc,
    // 실적 구분 값
    execClsCd,
    // 부문 코드
    sectCd,
    // 부문에 따른 검색조건 부서
    deptCd,
  } = formValue;

  console.log('최종 모달값==??>', formValue);

  // Account 변경
  const changeAccount = (gubun, v) => {
    console.log('어카운트==>', v);
    // // 부문
    // if (formValue.sectCd != null) {
    //   formValue.sectCd = deptInfo.sectCd;
    // }

    formValue.acntCd = v;
    changeInput(gubun, v);
  };

  // costCenter;

  // 부문 변경
  const changeSectCd = (gubun, v) => {
    console.log('부문==>', v);
    // 정비
    if (v == 'DM') {
      formValue.deptCd = 'SELDM';
      // 화물
    } else if (v == 'DF') {
      formValue.deptCd = 'SELDF';
      // 객실
    } else if (v == 'DU') {
      formValue.deptCd = 'SELDU';
      // 여객
    } else if (v == 'DC') {
      formValue.deptCd = 'SELDC';
      // 테크센터
    } else if (v == 'DB') {
      formValue.deptCd = 'SELDB';
      // 기타
    } else if (v == 'DX') {
      formValue.deptCd = 'SELDX';
    }

    changeInput(gubun, v);
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'middle-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">산업안전보건 관리비 실적</h3>
        <div className="pop_lg_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              {/*등록 */}
              <div className="editbox">
                <div className="form-table line">
                  {/* <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker
                        label={'년도'}
                        pickerType="year"
                        value={costCenter}
                        onChange={(value) => changeInput('costCenter', value)}
                        required
                        // disabled
                        errorMessage={errors.costCenter}
                      />
                    </div>
                  </div> */}

                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        label="구분"
                        value={execClsCd}
                        codeGrpId="CODE_GRP_OC049"
                        onChange={(value) => changeInput('execClsCd', value)}
                        required
                        disabled
                        errorMessage={errors.execClsCd}
                      />
                    </div>
                  </div>

                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker
                        label={'일자'}
                        value={invoiceDt}
                        onChange={(value) => changeInput('invoiceDt', value)}
                        required
                        //disabled
                        errorMessage={errors.invoiceDt}
                        disabled={!formValue.costSeq ? false : true}

                        //disabled={formValue.execClsCd === 'B' ? false : true}
                      />
                    </div>
                  </div>

                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        label="본부"
                        value={sectCd}
                        codeGrpId="CODE_GRP_OC001"
                        onChange={(value) => changeSectCd('sectCd', value)}
                        required
                        // disabled
                        errorMessage={errors.sectCd}
                        disabled={!formValue.costSeq ? false : true}
                      />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      {!formValue.costSeq ? (
                        <AppDeptListSelectInput
                          label="부서"
                          value={costCenter}
                          onChange={(value) => changeInput('costCenter', value)}
                          gudun="O"
                          // dept="SELDM"
                          dept={deptCd}
                          division="D"
                          required
                          errorMessage={errors.costCenter}
                        />
                      ) : (
                        <AppTextInput
                          label="부서"
                          value={costCenterNm}
                          onChange={(value) => changeInput('costCenterNm', value)}
                          required
                          disabled
                          errorMessage={errors.costCenterNm}
                        />
                      )}
                    </div>
                  </div>
                </div>
                <hr className="line dp-n"></hr>
                <div className="form-table line">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        label="계정명"
                        value={acntNm}
                        codeGrpId="CODE_GRP_OC045"
                        onChange={(value) =>
                          // changeInput('acntNm', value)

                          changeAccount('acntNm', value)
                        }
                        required
                        disabled={!formValue.costSeq ? false : true}
                        // disabled
                        errorMessage={errors.acntNm}
                      />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="계정"
                        value={acntCd}
                        onChange={(value) => changeInput('acntCd', value)}
                        required
                        disabled
                        errorMessage={errors.acntCd}
                      />
                    </div>
                  </div>

                  {/* <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker
                        label={'일자'}
                        value={invoiceDt}
                        onChange={(value) => changeInput('invoiceDt', value)}
                        required
                        //disabled
                        errorMessage={errors.invoiceDt}
                        //disabled={formValue.execClsCd === 'B' ? false : true}
                      />
                    </div>
                  </div> */}
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="전표번호"
                        value={invoiceNo}
                        onChange={(value) => changeInput('invoiceNo', value)}
                        required
                        // //disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.invoiceNo}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line dp-n"></hr>
                <div className="form-table line">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="금액"
                        value={drAmt}
                        inputType="number"
                        onChange={(value) => changeInput('drAmt', value)}
                        required
                        // //disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.drAmt}
                      />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="거래처"
                        value={vendorNm}
                        onChange={(value) => changeInput('vendorNm', value)}
                        //required
                        // //disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.vendorNm}
                      />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker
                        label={'처리일자'}
                        value={glDt}
                        onChange={(value) => changeInput('glDt', value)}
                        required
                        disabled={!formValue.costSeq ? false : true}
                        // //disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.glDt}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line dp-n"></hr>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextArea
                        label="내용"
                        value={lineDesc}
                        onChange={(value) => changeInput('lineDesc', value)}
                        //required
                        // //disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.lineDesc}
                      />
                      {/* <label className="f-label" htmlFor="testArea1">
                        내용
                      </label> */}
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
              </div>

              {/*//등록 */}
            </div>
          </div>
        </div>
        {/* //execClsCd */}
        <div className="pop_btns">
          <button
            className="btn_text text_color_neutral-10 btn_confirm"
            onClick={save}
            // 수기 등록 인경우
            style={{ display: formValue.execClsCd === 'B' ? '' : 'none' }}
          >
            저장
          </button>

          <button
            className="btn_text text_color_neutral-90 btn_close"
            // 일련번호 존재, 수기 등록 인경우
            style={{ display: formValue.costSeq && formValue.execClsCd === 'B' ? '' : 'none' }}
            onClick={execDelete}
          >
            삭제
          </button>

          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            취소
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default CostExecFormModal;
