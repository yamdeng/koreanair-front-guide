import AppTextInput from '@/components/common/AppTextInput';
//import useSysCodeFormStore from '@/stores/admin/useSysCodeFormStore';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppDatePicker from '@/components/common/AppDatePicker';

import Modal from 'react-modal';

function RiskHelpPeriodModal(props) {
  const { isOpen, closeModal, ok } = props;

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">위험도 안내</h3>

        <div className="pop_cont">
          <div className="guide-table-box">
            <table className="guidetable-type01">
              <colgroup>
                <col width="12%" />
                <col width="10%" />
                <col width="17%" />
                <col width="17%" />
                <col width="17%" />
                <col width="17%" />
              </colgroup>
              <thead>
                <tr>
                  <th colSpan={6}>중대성(강도)</th>
                </tr>
                <tr>
                  <th colSpan={2}></th>
                  <th>최대(4)</th>
                  <th>대(3)</th>
                  <th>중(2)</th>
                  <th>소(1)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th rowSpan={6}>가능성(빈도)</th>
                  <th>최상(5)</th>
                  <td className="veryhigh">매우높음(20)</td>
                  <td className="high">높음(15)</td>
                  <td className="borderlinehigh">약간높음(10)</td>
                  <td className="low">낮음(5)</td>
                </tr>
                <tr>
                  <th>상(4)</th>
                  <td className="veryhigh">매우높음(16)</td>
                  <td className="borderlinehigh">약간높음(10)</td>
                  <td className="middle">보통(8)</td>
                  <td className="low">낮음(4)</td>
                </tr>
                <tr>
                  <th>중(3)</th>
                  <td className="borderlinehigh">약간높음(12)</td>
                  <td className="borderlinehigh">약간높음(9)</td>
                  <td className="low">낮음(6)</td>
                  <td className="verylow">매우낮음(3)</td>
                </tr>
                <tr>
                  <th>하(2)</th>
                  <td className="middle">보통(8)</td>
                  <td className="low">낮음(6)</td>
                  <td className="low">낮음(4)</td>
                  <td className="verylow">매우낮음(2)</td>
                </tr>
                <tr>
                  <th>최하(1)</th>
                  <td className="low">낮음(4)</td>
                  <td className="verylow">매우낮음(3)</td>
                  <td className="verylow">매우낮음(2)</td>
                  <td className="verylow">매우낮음(1)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default RiskHelpPeriodModal;
