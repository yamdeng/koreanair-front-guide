import { Viewer } from '@toast-ui/react-editor';
import { useEffect, useState } from 'react';

function AppEditorViewer(props) {
  const [checkValueNumber, setCheckValueNumber] = useState(1);

  const { value = '' } = props;

  useEffect(() => {
    if (checkValueNumber === 1) {
      setCheckValueNumber(2);
    } else {
      setCheckValueNumber(1);
    }
  }, [value]);
  const applyComponent =
    checkValueNumber === 1 ? (
      <Viewer key={1} initialValue={value || ''} />
    ) : (
      <Viewer key={2} initialValue={value || ''} />
    );
  return value ? applyComponent : '';
}

export default AppEditorViewer;
