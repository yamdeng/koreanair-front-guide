import AppAutoComplete from '@/components/common/AppAutoComplete';

import { getUserLabelByLocale } from '@/services/i18n';

function AppUserSearch(props) {
  const { ...rest } = props;

  return (
    <AppAutoComplete
      {...rest}
      apiUrl={import.meta.env.VITE_API_URL_USERS}
      valueKey="empNo"
      dataKey="data.list"
      isMultiple={false}
      getOptionLabel={(info) => {
        return getUserLabelByLocale(info);
      }}
      filterOption={() => true}
      isValueString
      isClearable
    />
  );
}

export default AppUserSearch;
