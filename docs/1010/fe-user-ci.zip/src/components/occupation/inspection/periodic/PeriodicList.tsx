import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create, useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import AppTextInput from '@/components/common/AppTextInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppUserSelectInput from '@/components/common/AppUserSelectInput';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/inspection/periodic',
  baseRoutePath: '/occupation/inspection/periodic',
};

const initSearchParam = {
  sectCd: '',
  deptCd: '',
  chkTitle: '',
  fromRegDttm: '',
  toRegDttm: '',
};

/* zustand store 생성 */
const OcuCheckInfoListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    searchWord: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function OcuCheckInfoList() {
  const state = OcuCheckInfoListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'chkCls', headerName: '점검 구분' },
      { field: 'chkTitle', headerName: '점검 제목' },
      { field: 'chkYear', headerName: '점검 연도' },
      { field: 'chkPeriodCd', headerName: '점검 시기' },
      { field: 'chkRegDt', headerName: '점검 등록 일자' },
      { field: 'chkEmpno', headerName: '점검자' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;

  const { sectCd, deptCd, chkTitle, fromRegDttm, toRegDttm, regUserId } = searchParam;

  const profile = useStore(useAppStore, (state) => state.profile);

  const storeDeptCd = profile.userInfo.deptCd; // 사용자 부서
  // TODO: 관리 부서 세팅
  const adminDeptCd = 'AAA';

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    const detailId = data.chkId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>반기/비정기 점검</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  applyAllSelect={adminDeptCd === storeDeptCd ? true : false}
                  label={'부문'}
                  codeGrpId="CODE_GRP_OC001"
                  value={sectCd}
                  onChange={(value) => {
                    changeSearchInput('sectCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100 mr5">
                <AppDeptSelectInput
                  label={'부서'}
                  value={deptCd}
                  onChange={(deptCd) => {
                    changeSearchInput('deptCd', deptCd);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={'등록기간'}
                      value={fromRegDttm}
                      onChange={(value) => {
                        changeSearchInput('fromRegDttm', value);
                      }}
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label={'등록기간'}
                      value={toRegDttm}
                      onChange={(value) => {
                        changeSearchInput('toRegDttm', value);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppUserSelectInput
                  label="점검자"
                  value={regUserId}
                  onChange={(value) => {
                    changeSearchInput('regUserId', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={'제목'}
                  value={chkTitle}
                  onChange={(value) => {
                    changeSearchInput('chkListTitle', value);
                  }}
                />
              </div>
            </div>
            <div className="btn-area">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                조회
              </button>
              {/* <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              초기화
            </button> */}
            </div>
          </div>
        </div>
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default OcuCheckInfoList;
