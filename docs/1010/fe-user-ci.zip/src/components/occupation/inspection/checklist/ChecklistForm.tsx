import { useEffect, useState, useCallback } from 'react';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppTextInput from '@/components/common/AppTextInput';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppTable from '@/components/common/AppTable';
import Modal from 'react-modal';
import useOcuCheckListFormStore from '@/stores/occupation/inspection/useOcuCheckListFormStore';
import PartnerModal from '@/components/occupation/management/partner/PartnerModal';

const DeleteActionButton = (props) => {
  const { node, onClick } = props;
  const { rowIndex } = node;
  const handleClick = (event) => {
    event.stopPropagation();
    event.preventDefault();
    event.nativeEvent.stopPropagation();
    onClick(rowIndex);
  };
  return <div onClick={handleClick}>삭제</div>;
};

function OcuCheckListForm() {
  const state = useOcuCheckListFormStore();
  const {
    errors,
    getDetail,
    formType,
    formValue,
    setFormValue,
    setFormStatus,
    selectedPlaceIndex,
    selectedItemIndex,
    setSelectedItemIndex,
    addItemRow,
    delPlaceRow,
    delItemRow,
    setItemColumn,
    getItemColumn,
    getItemError,
    isDirty,
    saveAll,
    remove,
    cancel,
    clear,
    openItemModal,
    closeItemModal,
    isItemFormModalOpen,
    isPartnerModalOpen,
    openPartnerModal,
    closePartnerModal,
    selectPartnerModal,
  } = state;

  const { regUserNm, regDdtm, useSectCd, useDeptCd, chkListTitle } = formValue;
  const { detailId } = useParams();
  const profile = useStore(useAppStore, (state) => state.profile);
  const userId = profile.userInfo.userId; // 사용자ID
  const profileSectCd = profile.userInfo.sectd ? profile.userInfo.sectd : 'DX'; //부문
  const profileDeptCd = profile.userInfo.deptCd; //부서

  useFormDirtyCheck(isDirty);

  const [ocuCheckListPlaceColumns, setOcuCheckListPlaceColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: '_status', headerName: '상태' },
      { field: 'prtnrId', headerName: '협력업체 ID', hide: true },
      { field: 'prtnrNm', headerName: '협력업체' },
      { field: 'bizPlaceId', headerName: '사업장 ID', hide: true },
      { field: 'bizPlaceNm', headerName: '사업장' },
      { field: 'useSectNm', headerName: '사용부문' },
      {
        field: 'action',
        headerName: '삭제',
        cellRenderer: 'deleteActionButton',
        cellRendererParams: {
          onClick: delPlaceRow,
        },
      },
    ])
  );

  const [ocuCheckListItemColumns, setOcuCheckListItemColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: '_status', headerName: '상태' },
      { field: 'chkClsCd', headerName: '점검분류 코드', hide: true },
      { field: 'chkClsNm', headerName: '점검분류' },
      { field: 'chkItemNm', headerName: '점검항목' },
      {
        field: 'action',
        headerName: '삭제',
        cellRenderer: 'deleteActionButton',
        cellRendererParams: {
          onClick: delItemRow,
        },
      },
    ])
  );

  const handleRowDoubleClick_OcuCheckListItem = useCallback(
    (selectedInfo) => {
      const { rowIndex } = selectedInfo;

      if (rowIndex !== selectedItemIndex) {
        setSelectedItemIndex(rowIndex);
      }
      openItemModal();
    },
    [formValue, selectedItemIndex]
  );

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else {
      formValue.useSectCd = profileSectCd;
      formValue.useDeptCd = profileDeptCd;
      formValue.regUserId = userId;
      console.log('profile.userInfo', profile.userInfo);
      setFormStatus('A');
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>점검표 관리</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckListForm_regUserNm"
                name="nameKor"
                label={'등록자'}
                value={regUserNm}
                disabled
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput id="OcuCheckListForm_regDttm" name="toDate" label={'등록일자'} value={regDdtm} disabled />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                id="OcuCheckListForm_sectCd"
                name="sectCd"
                label={'부문'}
                codeGrpId="CODE_GRP_OC001"
                value={useSectCd}
                onChange={(value) => setFormValue('useSectCd', value)}
                errorMessage={errors.useSectCd}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDeptSelectInput
                id="OcuCheckListForm_deptCd"
                name="deptCd"
                label={'부서'}
                value={useDeptCd}
                onChange={(value) => setFormValue('useDeptCd', value)}
                errorMessage={errors.useDeptCd}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                id="OcuCheckListForm_chkListClsCd"
                name="chkListClsCd"
                label={'점검표 구분'}
                value={'A'}
                codeGrpId="CODE_GRP_OC010"
                disabled
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuCheckListForm_chkListTitle"
                name="chkListTitle"
                label={'점검표 제목'}
                value={chkListTitle}
                onChange={(value) => setFormValue('chkListTitle', value)}
                errorMessage={errors.chkListTitle}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid50 pd-10">
            <AppTable
              rowData={formValue.placeList || []}
              columns={ocuCheckListPlaceColumns}
              setColumns={setOcuCheckListPlaceColumns}
              components={{
                deleteActionButton: DeleteActionButton,
              }}
              customButtons={[
                {
                  title: '협력업체 검색',
                  onClick: () => {
                    openPartnerModal();
                  },
                },
              ]}
              getRowStyle={(params) => {
                const { data, rowIndex } = params;
                if (rowIndex === selectedPlaceIndex) {
                  return { background: '#d6d9eb' };
                } else if (data._isError) {
                  return { background: '#ebb2b2' };
                }
              }}
              hiddenPagination
            />
          </div>
          <div className="form-cell wid50 pd-10">
            <AppTable
              rowData={formValue.itemList || []}
              columns={ocuCheckListItemColumns}
              setColumns={setOcuCheckListItemColumns}
              components={{ deleteActionButton: DeleteActionButton }}
              customButtons={[
                {
                  title: '행 추가',
                  onClick: () => {
                    addItemRow();
                  },
                },
              ]}
              handleRowDoubleClick={handleRowDoubleClick_OcuCheckListItem}
              getRowStyle={(params) => {
                const { data, rowIndex } = params;
                if (rowIndex === selectedItemIndex) {
                  return { background: '#d6d9eb' };
                } else if (data._isError) {
                  return { background: '#ebb2b2' };
                }
              }}
              hiddenPagination
            />
          </div>
        </div>
      </div>

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={saveAll}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>

      {/* 모달 영역 */}
      <Modal
        shouldCloseOnOverlayClick={false}
        isOpen={isItemFormModalOpen}
        ariaHideApp={false}
        overlayClassName={'middle-modal-overlay'}
        className={'confirm-modal-content'}
        onRequestClose={() => {
          closeItemModal();
        }}
      >
        <div className="popup-container">
          <h3 className="pop_title">점검항목</h3>
          <div className="pop_cont">
            <div className="editbox">
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppCodeSelect
                      codeGrpId={'CODE_GRP_OC038'}
                      label={'점검분류'}
                      value={getItemColumn('chkClsNm')}
                      onChange={(value, label) => {
                        setItemColumn(`chkClsNm`, label.label);
                        setItemColumn(`chkClsCd`, value);
                      }}
                      required
                      errorMessage={getItemError('chkClsNm')}
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      label={'점검항목'}
                      value={getItemColumn('chkItemNm')}
                      onChange={(value) => setItemColumn(`chkItemNm`, value)}
                      required
                      errorMessage={getItemError('chkItemNm')}
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
            </div>
          </div>

          <div className="pop_btns">
            <button className="btn_text text_color_neutral-10 btn_confirm" onClick={closeItemModal}>
              확인
            </button>
          </div>
          <span className="pop_close" onClick={closeItemModal}>
            X
          </span>
        </div>
      </Modal>
      <PartnerModal isOpen={isPartnerModalOpen} closeModal={closePartnerModal} selectModal={selectPartnerModal} />
    </>
  );
}

export default OcuCheckListForm;
