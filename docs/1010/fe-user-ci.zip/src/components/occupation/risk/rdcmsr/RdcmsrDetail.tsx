import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import AppNavigation from '@/components/common/AppNavigation';
import AppFileAttach from '@/components/common/AppFileAttach';
/* TODO : store 경로를 변경해주세요. */
import shareImage from '@/resources/images/share.svg';
import AppTable from '@/components/common/AppTable';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';

import useOcuRdcmsrFormStore from '@/stores/occupation/risk/useOcuRdcmsrFormStore';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';

import CommonUtil from '@/utils/CommonUtil';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RdcmsrDetail() {
  // // 청취조사
  // const listenInfo = useOcuRiskTab2FormStore();
  // // 현장순화
  // const visitInfo = useOcuRiskTab2SiteVisitListStore();

  const {
    detailInfo,
    getDetail,
    formType,
    cancel,
    goFormPage,
    clear,
    search,
    list,
    procChange,
    goDetailPage,
    formValue,

    // list
    selectedPlaceIndex,
    setSelectedPlaceIndex,
    getPlaceColumn,
  } = useOcuRdcmsrFormStore();
  // const {
  //   /* 감소대책 수립 및 실시 form 정보 */

  //   // 공정 id

  //   // 작성자
  //   regUserId,
  //   // 작성일자
  //   regDttm,
  //   // 부문
  //   authorSectCd,
  //   // 부문명
  //   authorSectNm,
  //   // 부서
  //   nmLevel2,
  //   // 팀
  //   nmLevel3,
  //   // 그룹
  //   nmLevel4,
  //   // 반/섹션
  //   nmLevel5,
  //   // 평가년도
  //   revalYear,
  //   // 평가시기
  //   revalPeriod,
  //   // 평가시기명
  //   revalPeriodNm,
  //   // 공정명
  //   procNm,
  //   // 세부 작업명
  //   detailWrkNm,
  //   // 위험분류
  //   riskClsNm,
  //   // 위험요인
  //   riskFactorCd,
  //   // 위험성 결정
  //   riskDcsnNm,
  //   // 담당자
  //   staffEmpno,
  //   // 개선상태
  //   rdcmsrStatCd,
  //   // 개선상태명
  //   rdcmsrStatNm,
  //   // 감소대책 수립
  //   rdcmsrNm,
  //   // 개선 전 예정일자
  //   befImprSchdDt,
  //   // 개선 전 첨부파일
  //   befImprFileId,
  //   // 개선 전 위험발생 상황 및 결과
  //   riskOcurStatRes,
  //   // 개선 전 가능성
  //   riskDcsnPsbltVal,
  //   // 개선 전 중대성
  //   riskDcsnImprtVal,
  //   // 개선 전 위험도
  //   riskDcsnRiskVal,

  //   // 개선 후 예정일자
  //   aftImprCmpltDt,
  //   // 개선 후 첨부파일
  //   aftImprFileId,
  //   // 개선 후 위험발생 상황 및 결과
  //   aftImprContent,
  //   // 개선 후 가능성
  //   aftImprPsbltVal,
  //   // 개선 후 중대성
  //   aftImprImprtVal,
  //   // 개선 후 위험도
  //   aftImprRiskVal,
  // } = detailInfo;

  // console.log('값2==>', detailInfo);

  const { detailId } = useParams();

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      // { field: 'num', headerName: '번호' },
      { field: 'rdcmsrEmplNm', headerName: '이름', flex: 1 },
      { field: 'rdcmsrOpnnCn', headerName: '의견', flex: 1 },
    ])
  );

  const handleRowDoubleClick = useCallback(
    (selectedInfo) => {
      const { rowIndex } = selectedInfo;

      if (rowIndex !== selectedPlaceIndex) {
        setSelectedPlaceIndex(rowIndex);
      }
    },
    [formValue, selectedPlaceIndex]
  );

  const customButtons = [
    {
      title: '추가',
      onClick: () => {
        alert('추가');
      },
    },
  ];

  // const handleRowSingleClick = useCallback(
  //   (selectedInfo) => {
  //     setSelectedPlaceIndex(selectedInfo.rowIndex);
  //   },
  //   [selectedPlaceIndex]
  // );

  // const [columns2, setColumns2] = useState(
  //   CommonUtil.mergeColumnInfosByLocal([
  //     { field: 'num', headerName: '번호' },
  //     { field: 'svisitDt', headerName: '순회일자', flex: 1 },
  //     { field: 'svisitProcNm', headerName: '대상공정(작업)', flex: 1 },
  //     { field: 'svisitHzdOpnn', headerName: '유해, 위험요인에 대한 의견', flex: 1 },
  //     //{ field: 'execTeamPosCd', headerName: '삭제', flex: 1 },
  //     // {
  //     //   pinned: 'right',
  //     //   field: 'action',
  //     //   headerName: '삭제',
  //     //   // flex: 1,
  //     //   cellRenderer: 'deleteActionButton',
  //     //   cellRendererParams: {
  //     //     onClick: removeByIndex,
  //     //   },
  //     //},
  //   ])
  // );

  // 그리드 더블 클릭
  // const handleRowDoubleClick = useCallback((selectedInfo) => {
  //   const data = selectedInfo.data;
  //   // id
  //   const detailId = data.revalDocNo;
  //   goDetailPage(detailId);
  // }, []);

  // // 현장 순회 행 변경
  // const handleRowSingleClick2 = useCallback((selectedInfo) => {
  //   // const { rowIndex } = props;

  //   console.log('selectedInfo==>', selectedInfo);

  //   setColumns((prevColumns) => [...prevColumns]);
  //   visitInfo.visitChange(selectedInfo.data, selectedInfo.rowIndex);
  // }, []);

  // const init = async () => {
  //   getDetail(detailId);
  //   search();
  // };

  // useEffect(() => {
  //   init();
  //   return clear;
  // }, []);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  // 첫번째 행 선택
  useEffect(() => {
    if (formValue?.rdcmsrOpnnInfoList && formValue.rdcmsrOpnnInfoList.length > 0 && selectedPlaceIndex === -1) {
      const firstRow = formValue.rdcmsrOpnnInfoList[0];
      handleRowSingleClick({ data: firstRow, rowIndex: 0 });
    }
  }, [formValue, selectedPlaceIndex]);

  const handleRowSingleClick = useCallback(
    (selectedInfo) => {
      setSelectedPlaceIndex(selectedInfo.rowIndex);
    },
    [selectedPlaceIndex]
  );

  // // 첫번째 행 선택
  // useEffect(() => {
  //   if (formValue?.rdcmsrOpnnInfoList && formValue.rdcmsrOpnnInfoList.length > 0 && selectedPlaceIndex === -1) {
  //     const firstRow = formValue.rdcmsrOpnnInfoList[0];
  //     handleRowDoubleClick({ data: firstRow, rowIndex: 0 });
  //   }
  // }, [formValue, selectedPlaceIndex]);

  // 수정
  const goForm = () => {
    goFormPage(detailId);
  };

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>
          감소대책 수립 및 실시
          <span className="print">
            <a href="javascript:void(0);"></a>
          </span>
        </h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppTextInput label="작성자" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성자</label>
                    <span className="text-desc-type1">{formValue.regUserNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppTextInput label="작성일자" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성일자</label>
                    <span className="text-desc-type1">{formValue.regDttm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="부문" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부문</label>
                    <span className="text-desc-type1">{formValue.authorSectNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="부서" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부서</label>
                    <span className="text-desc-type1">{formValue.nmLevel2}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="팀" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">팀</label>
                    <span className="text-desc-type1">{formValue.nmLevel3}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="그룹" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">그룹</label>
                    <span className="text-desc-type1">{formValue.nmLevel4}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="반/섹션" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">반/섹션</label>
                    <span className="text-desc-type1">{formValue.nmLevel5}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="평가년도" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">평가년도</label>
                    <span className="text-desc-type1">{formValue.revalYear}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="평가시기" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">평가시기</label>
                    <span className="text-desc-type1">{formValue.revalPeriodNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="공정명" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">공정명</label>
                    <span className="text-desc-type1">{formValue.procNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              {/* <AppTextInput label="세부 작업명" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">세부 작업명</label>
                    <span className="text-desc-type1">{formValue.detailWrkNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppTextInput label="위험분류" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">위험분류</label>
                    <span className="text-desc-type1">{formValue.riskClsNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="위험요인" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">위험요인</label>
                    <span className="text-desc-type1">{formValue.riskFactorCd}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="위험성 결정" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">위험성 결정</label>
                    <span className="text-desc-type1">{formValue.riskDcsnNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppAutoComplete label="담당자" /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">담당자</label>
                    <span className="text-desc-type1">{formValue.staffEmpno}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppSelect label="개선상태" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">개선상태</label>
                    <span className="text-desc-type1">{formValue.rdcmsrStatNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppTextInput label="감소대책 수립" disabled /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">감소대책 수립</label>
                    <span className="text-desc-type1">{formValue.rdcmsrNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid100">
            <h3 className="table-tit">감소대책 수립 및 실시</h3>
            <div className="ck-edit-box pd-t0">
              <table className="before-after-table">
                <thead>
                  <tr>
                    <th>개선 전</th>
                    <th>개선 후</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <div className="form-table line">
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppDatePicker label="개선 예정일자" /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">개선 예정일자</label>
                                  <span className="text-desc-type1">{formValue.befImprSchdDt}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <hr className="line dp-n"></hr>
                      <div className="form-table">
                        <div className="form-cell wid50">
                          <h3 className="table-tit mb-10">사진 첨부</h3>
                          <div className="form-group wid100">
                            <AppFileAttach
                              mode="view"
                              fileGroupSeq={formValue.befImprFileId}
                              workScope={'O'}
                              // onlyImageUpload={true}
                              useDetail
                              disabled
                            />
                          </div>
                          {/* <div className="form-group wid100"> */}
                          {/* <div className="filebox error">
                              <Upload
                                action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
                                listType="picture-card"
                                fileList={fileList}
                                onPreview={handlePreview}
                                onChange={handleChange}
                              >
                                {fileList.length >= 8 ? null : uploadButton}
                              </Upload>
                              <label htmlFor="file" className="file-label">
                                사진첨부{/*<span className="required">*</span>*/}
                          {/* </label> */}
                          {/* </div>
                            <span className="errorText">fileerror</span>
                          </div>
                          {previewImage && (
                            <Image
                              wrapperStyle={{
                                display: 'none',
                              }}
                              preview={{
                                visible: previewOpen,
                                onVisibleChange: (visible) => setPreviewOpen(visible),
                                afterOpenChange: (visible) => !visible && setPreviewImage(''),
                              }}
                              src={previewImage}
                            /> */}
                          {/* )} */}
                        </div>
                      </div>
                      <hr className="line dp-n"></hr>
                      <div className="form-table line">
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppTextInput label="위험발생 상황 및 결과" disabled /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">위험발생 상황 및 결과</label>
                                  <span className="text-desc-type1">{formValue.riskOcurStatRes}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppTextInput label="가능성" disabled /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">가능성</label>
                                  <span className="text-desc-type1">{formValue.riskDcsnPsbltVal}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <hr className="line dp-n"></hr>
                      <div className="form-table line">
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppTextInput label="중대성" disabled /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">중대성</label>
                                  <span className="text-desc-type1">{formValue.riskDcsnImprtVal}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppTextInput label="위험도" disabled /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">위험도</label>
                                  <span className="text-desc-type1">{formValue.riskDcsnRiskVal}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="form-table line">
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppDatePicker label="개선 완료일자" /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">개선 완료일자</label>
                                  <span className="text-desc-type1">{formValue.aftImprCmpltDt}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <hr className="line dp-n"></hr>
                      <div className="form-table">
                        <div className="form-cell wid50">
                          <h3 className="table-tit mb-10">사진 첨부</h3>
                          <div className="form-group wid100">
                            <AppFileAttach
                              mode="view"
                              fileGroupSeq={formValue.aftImprFileId}
                              workScope={'O'}
                              // onlyImageUpload={true}
                              useDetail
                              disabled
                            />
                          </div>
                          {/* <div className="form-group wid100">
                            <div className="filebox error">
                              <Upload
                                action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
                                listType="picture-card"
                                fileList={fileList}
                                onPreview={handlePreview}
                                onChange={handleChange}
                              >
                                {fileList.length >= 8 ? null : uploadButton}
                              </Upload>
                              <label htmlFor="file" className="file-label">
                                사진첨부{/*<span className="required">*</span>*/}
                          {/* </label>
                            </div>
                            <span className="errorText">fileerror</span>
                          </div> */}
                          {/* {previewImage && (
                            <Image
                              wrapperStyle={{
                                display: 'none',
                              }}
                              preview={{
                                visible: previewOpen,
                                onVisibleChange: (visible) => setPreviewOpen(visible),
                                afterOpenChange: (visible) => !visible && setPreviewImage(''),
                              }}
                              src={previewImage}
                            />
                          )} */}
                        </div>
                      </div>
                      <hr className="line dp-n"></hr>
                      <div className="form-table line">
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppTextInput label="개선내용" disabled /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">개선내용</label>
                                  <span className="text-desc-type1">{formValue.aftImprContent}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppSelect label="가능성" /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">가능성</label>
                                  <span className="text-desc-type1">{formValue.aftImprPsbltVal}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <hr className="line dp-n"></hr>
                      <div className="form-table line">
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppSelect label="중대성" /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">중대성</label>
                                  <span className="text-desc-type1">{formValue.aftImprImprtVal}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div className="form-cell wid100">
                          <div className="form-group wid100">
                            {/* <AppTextInput label="위험도" disabled /> */}
                            <div className="box-view-list">
                              <ul className="view-list">
                                <li className="accumlate-list">
                                  <label className="t-label">위험도</label>
                                  <span className="text-desc-type1">{formValue.aftImprRiskVal}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="ck-edit-box">
              <div className="ck-list">
                <h3 className="table-tit"> 감소대책 이행에 대한 근로자 의견</h3>
                <AppTable
                  rowData={formValue.rdcmsrOpnnInfoList || []}
                  columns={columns}
                  setColumns={setColumns}
                  // customButtons={customButtons}
                  handleRowSingleClick={handleRowSingleClick}
                  hiddenPagination
                />
              </div>

              <div className="ck-edit">
                <div className="boxForm">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">이름</label>
                              <span className="text-desc-type1">{getPlaceColumn('rdcmsrEmplNm')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              {/* <label className="t-label">근로자의견</label>
                              <span className="text-desc-type1">{getPlaceColumn('rdcmsrOpnnCn')}</span> */}

                              <textarea
                                id="testArea1"
                                className="form-tag custom_textarea"
                                style={{ width: '100%' }}
                                name="testArea1"
                                value={getPlaceColumn('rdcmsrOpnnCn')}
                                // readOnly
                              />
                              <label className="f-label" htmlFor="testArea1">
                                근로자의견
                              </label>
                            </li>
                          </ul>
                        </div>
                        {/* <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <AppTextArea
                                id="testArea1"
                                label="의견"
                                className="form-tag custom_textarea"
                                // style={{ width: '100%' }}
                                // value={formValue.rdcmsrOpnnCn}
                                value={getPlaceColumn('rdcmsrOpnnCn')}
                                onChange={(value) => setPlaceColumn('rdcmsrOpnnCn', value)}
                                // onChange={(value) => changeInput('rdcmsrOpnnCn', value)}
                                errorMessage={getPlaceError('rdcmsrOpnnCn')}
                                // errorMessage={errors.rdcmsrOpnnCn}
                              />
                              {/* style={{ width: '100%' }} */}
                        {/* <textarea
                                          id="testArea1"
                                          className="form-tag custom_textarea"
                                          style={{ width: '100%' }}
                                          name="testArea1"
                                          value={svisitHzdOpnn}
                                        />
                                        <label className="f-label" htmlFor="testArea1">
                                          유해,위험요인에 대한 의견
                                        </label> */}
                        {/* <span className="text-desc-type1">{svisitHzdOpnn}</span> */}
                        {/* </li>
                          </ul>
                        </div> */}
                      </div>
                    </div>
                  </div>

                  <div className="btn-area-type01 mg-top">
                    <button type="button" name="button" className="btn_text btn_confirm">
                      저장
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">사용부문</label>
                        <span className="text-desc-type1">{getPlaceColumn('useSectCd')}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">사용부문</label>
                        <span className="text-desc-type1">{getPlaceColumn('useSectCd')}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div> */}
        {/* </div>
          </div>
        </div> */}
        <hr className="line"></hr>
      </div>

      {/*//입력영역*/}

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        {/*//하단버튼영역*/}
        {/*그리드영역 */}

        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goForm}
          // style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          수정
        </button>
        {/* <button type="button" name="button" className="btn_text btn-del">
          삭제
        </button> */}
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
      </div>
    </>
  );
}
export default RdcmsrDetail;
