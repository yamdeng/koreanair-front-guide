import { useState, useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useParams, useSearchParams } from 'react-router-dom';
import CommonUtil from '@/utils/CommonUtil';
import AppTextArea from '@/components/common/AppTextArea';
import { Viewer } from '@toast-ui/react-editor';
import AppTable from '@/components/common/AppTable';
import AppFileAttach from '@/components/common/AppFileAttach';

/* TODO : store 경로를 변경해주세요. */
import useOcuCostFormStore from '@/stores/occupation/general/useOcuCostFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCostDetail() {
  /* formStore state input 변수 */
  const { detailInfo, getDetail, cancel, goFormPage, clear, list, formType, search } = useOcuCostFormStore();
  const {
    // 년도 id
    planYearId,
    // 계획 년도
    planYear,
    // 계획 부문
    planSectCd,
    // 계획 부문명
    planSectNm,
    // 계획 Cost Center
    planCostCenter,
    // 계획 Cost Center 명
    planCostCenterNm,
    // 계획 계정
    planAcntCd,
    // 계획 계정명
    planAcntNm,
    // 계획 항목
    planItemCd,
    // 계획 항목명
    planItemNm,
    // 계획 주기
    planPayTermCd,
    // 계획 주기명
    planPayTermNm,
    // 계획 합계
    planAmt,
    // 계획 시작 월
    planFrMm,
    // 계획 종료 월
    planToMm,
    // 계획 총 합계
    planTotAmt,
    // 계획 기타
    planDesc,
  } = detailInfo;

  console.log('detailInfo값===>', detailInfo);

  // const [searchParams] = useSearchParams();
  // const planYear = searchParams.get('planYear');
  // const sectCd = searchParams.get('sectCd');
  // const searchRespCenter = searchParams.get('searchRespCenter');
  // const itemCd = searchParams.get('itemCd');
  // const searchAcntCd = searchParams.get('acntCd');

  const { detailId } = useParams();

  // const init = async () => {
  //   await getDetail(planYear, sectCd, searchRespCenter, itemCd, searchAcntCd);
  //   search();
  // };

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  // useEffect(() => {
  //   init();
  //   return clear;
  // }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>산업안전보건관리비</h2>
      </div>
      {/* 상세영역 */}
      <div className="table-wrap">
        <div className="left-table">
          {/* 입력영역 */}
          <div className="editbox">
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">년도</label>
                        <span className="text-desc-type1">{planYear}</span>
                      </li>
                    </ul>
                  </div>

                  {/* <AppDatePicker label="년도" /> */}
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppSelect label="본부" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">본부</label>
                        <span className="text-desc-type1">{planSectNm}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppSelect label="부서" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">부서</label>
                        <span className="text-desc-type1">{planCostCenterNm}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppSelect label="항목" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">항목</label>
                        <span className="text-desc-type1">{planItemNm}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppTextInput label="계정명" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">계정명</label>
                        <span className="text-desc-type1">{planAcntNm}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppTextInput label="계정" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">계정</label>
                        <span className="text-desc-type1">{planAcntCd}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppSelect label="주기" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">주기</label>
                        <span className="text-desc-type1">{planPayTermNm}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppSelect label="Month(Start)" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">Month(Start)</label>
                        <span className="text-desc-type1">{planFrMm}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppSelect label="Month(End)" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">Month(End)</label>
                        <span className="text-desc-type1">{planToMm}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppTextInput label="금액" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">금액</label>
                        <span className="text-desc-type1"> {planAmt ? planAmt.toLocaleString('ko-KR') : '0'}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppTextInput label="총 금액" /> */}
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">총 금액</label>
                        {/* <span className="text-desc-type1"> {planTotAmt}</span> */}
                        <span className="text-desc-type1">
                          {' '}
                          {planTotAmt ? planTotAmt.toLocaleString('ko-KR') : '0'}
                        </span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextArea
                    id="testArea1"
                    label="내용"
                    className="form-tag custom_textarea"
                    value={planDesc}
                    disabled
                    // style={{ width: '100%' }}
                    // onChange={(value) => changeInput('planDesc', value)}
                    // errorMessage={errors.planDesc}
                  />

                  {/* <textarea
                    id="testArea1"
                    className="form-tag custom_textarea"
                    style={{ width: '100%' }}
                    name="testArea1"
                    value={inputValue}
                    onChange={(event) => {
                      setInputValue(event.target.value);
                    }}
                  />
                  <label className="f-label" htmlFor="testArea1">
                    내용
                  </label> */}
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
          {/*//입력영역*/}
        </div>
        <div className="right-table">
          <table className="plan-table">
            <thead>
              <tr>
                <th>월</th>
                <th>금액</th>
              </tr>
            </thead>

            {list &&
              list.map((data) => (
                <>
                  <tbody>
                    {/* <tr onClick={() => userRowClick(dutyData)}> */}
                    <tr>
                      {/* <h3>임직원 리스트</h3> */}
                      <td>{data.planMonth}월</td>
                      <td>{data.planMonAmt ? data.planMonAmt.toLocaleString('ko-KR') : '0'}</td>
                    </tr>
                  </tbody>
                </>
              ))}

            {/* <tbody>
              <tr>
                <td>1월</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2월</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>3월</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>4월</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
            </tbody> */}
          </table>
        </div>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goFormPage}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          수정
        </button>
      </div>
    </>
  );
}
export default OcuCostDetail;
