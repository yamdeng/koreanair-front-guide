import { create } from 'zustand';
import { useEffect, useState, useCallback } from 'react';
import Modal from 'react-modal';
import CommonUtil from '@/utils/CommonUtil';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/partner/place',
};

const initSearchParam = {
  prtnrNm: '',
  bizPlaceClsCd: '',
  sectCd: '',
  deptCd: '',
};

/* zustand store 생성 */
const OcuPartnerModalStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    ...initSearchParam,
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function PartnerModal(props) {
  const state = OcuPartnerModalStore();
  const { enterSearch, searchParam, list, changeSearchInput, isExpandDetailSearch, toggleExpandDetailSearch, clear } =
    state;
  const { isOpen, closeModal, selectModal } = props;
  const { prtnrNm, bizPlaceClsCd, useSectCd, mgntDeptCd } = searchParam;
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'prtnrNm', headerName: '협력업체' },
      { field: 'bizPlaceNm', headerName: '사업장' },
      { field: 'useSectNm', headerName: '사용부문' },
      { field: 'mgntDeptNm', headerName: '관리부서' },
      { field: 'majorWorkCn', headerName: '주요업무' },
    ])
  );

  const handleRowDoubleClick = useCallback(async (selectedInfo) => {
    selectModal(selectedInfo.data);
    closeModal();
  }, []);

  useEffect(() => {
    if (isOpen) {
      enterSearch();
    } else {
      clear;
    }
  }, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">협력업체 사업장 검색</h3>
        <div className="pop_cont">
          <div className="boxForm">
            <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppSearchInput
                      label="협력업체"
                      value={prtnrNm}
                      onChange={(value) => {
                        changeSearchInput('prtnrNm', value);
                      }}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100 mr5">
                    <AppCodeSelect
                      label={'사업장'}
                      value={bizPlaceClsCd}
                      codeGrpId="CODE_GRP_OC009"
                      onChange={(value) => {
                        changeSearchInput('bizPlaceClsCd', value);
                      }}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppCodeSelect
                      codeGrpId="CODE_GRP_OC001"
                      label="사용부문"
                      id="OcuPartnerInfoPlaceForm_useSectCd"
                      name="useSectCd"
                      value={useSectCd}
                      onChange={(value) => changeSearchInput('useSectCd', value)}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppDeptSelectInput
                      label={'관리부서'}
                      value={mgntDeptCd}
                      onChange={(value) => {
                        changeSearchInput('mgntDeptCd', value);
                      }}
                    />
                  </div>
                </div>
                <div className="btn-area">
                  <button
                    type="button"
                    name="button"
                    className="btn-sm btn_text btn-darkblue-line"
                    onClick={enterSearch}
                  >
                    조회
                  </button>
                </div>
              </div>
            </div>
            <button
              type="button"
              name="button"
              className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
              onClick={toggleExpandDetailSearch}
            >
              <span className="hide">접기</span>
            </button>
          </div>

          <AppTable
            rowData={list}
            columns={columns}
            setColumns={setColumns}
            store={state}
            handleRowDoubleClick={handleRowDoubleClick}
          />
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            취소
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default PartnerModal;
