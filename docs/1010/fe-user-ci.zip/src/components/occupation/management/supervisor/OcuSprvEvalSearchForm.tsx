import AppTable from "@/components/common/AppTable";
import { createListSlice, listBaseState } from "@/stores/slice/listSlice";
import AppTextInput from '@/components/common/AppTextInput';

function OcuSprvEvalSearchForm() {
  const state = useOcuSprvEvalListStore();

  const {  mgntSprvEvalId, sectCd, deptCd, evalYear, qrtrYearCd, title, evalSubjEmpno, evalEmpno, fileId, linkId, remark, regDttm, regUserId, updDttm, updUserId, } = searchParam;

  return (
    <>
      {/* TODO : 검색 input 영역입니다 */}
      
      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                label="관리감독자평가_ID"
                value={mgntSprvEvalId}
                onChange={(value) => {
                  changeSearchInput('mgntSprvEvalId', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="부문_코드"
                value={sectCd}
                onChange={(value) => {
                  changeSearchInput('sectCd', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="부서_코드"
                value={deptCd}
                onChange={(value) => {
                  changeSearchInput('deptCd', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="평가년도"
                value={evalYear}
                onChange={(value) => {
                  changeSearchInput('evalYear', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="분기_코드"
                value={qrtrYearCd}
                onChange={(value) => {
                  changeSearchInput('qrtrYearCd', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="제목"
                value={title}
                onChange={(value) => {
                  changeSearchInput('title', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="피평가자_사번"
                value={evalSubjEmpno}
                onChange={(value) => {
                  changeSearchInput('evalSubjEmpno', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="평가자_사번"
                value={evalEmpno}
                onChange={(value) => {
                  changeSearchInput('evalEmpno', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                label="첨부_파일_ID"
                value={fileId}
                onChange={(value) => {
                  changeSearchInput('fileId', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                label="첨부_링크_ID"
                value={linkId}
                onChange={(value) => {
                  changeSearchInput('linkId', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="비고"
                value={remark}
                onChange={(value) => {
                  changeSearchInput('remark', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="등록_일시"
                value={regDttm}
                onChange={(value) => {
                  changeSearchInput('regDttm', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="등록자_ID"
                value={regUserId}
                onChange={(value) => {
                  changeSearchInput('regUserId', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="수정_일시"
                value={updDttm}
                onChange={(value) => {
                  changeSearchInput('updDttm', value);
                }}
              />
            </div>
          </div>             
        </div>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="수정자_ID"
                value={updUserId}
                onChange={(value) => {
                  changeSearchInput('updUserId', value);
                }}
              />
            </div>
          </div>             
        </div>     
        <div className="btn-area">
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            조회
          </button>
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            초기화
          </button>
        </div> 
      </div>
            
    </>
  );
}
export default OcuSprvEvalSearchForm;
