import AppNavigation from '@/components/common/AppNavigation';
import Config from '@/config/Config';
import Slider from 'react-slick';

function GuideSlideSimple() {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          GuideSlideSimple simple :{' '}
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideSlideSimple.tsx`}>
            GuideSlideSimple
          </a>
        </h2>
      </div>
      <div style={{ padding: 25 }}>
        <Slider {...settings}>
          <div>
            <h3>1</h3>
          </div>
          <div>
            <h3>2</h3>
          </div>
          <div>
            <h3>3</h3>
          </div>
          <div>
            <h3>4</h3>
          </div>
          <div>
            <h3>5</h3>
          </div>
          <div>
            <h3>6</h3>
          </div>
        </Slider>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm">저장</button>
      </div>
    </>
  );
}
export default GuideSlideSimple;
