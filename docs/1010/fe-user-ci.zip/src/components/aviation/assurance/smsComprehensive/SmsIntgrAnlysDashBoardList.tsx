import AppNavigation from '@/components/common/AppNavigation';
import {
  useHzrTopRiskListStore,
  useSmsIntgrAnlysDashBoardStore,
} from '@/stores/aviation/assurance/smsComprehensive/useSmsIntgrAnlysDashBoardStore';
import { useEffect } from 'react';
import HzrTopRiskList from './HzrTopRiskList';
import PSMSReportModal from './PSMSReportModal';
import TopEventList from './TopEventList';

function SmsIntgrAnlysDashBoardList() {
  // useSmsIntgrAnlysDashBoardStore 에서 정의된 메소드 사용 시 이곳에서 분해할당
  const { changeSearchInput, searchParam, tabIndex, changeTab, clear } = useSmsIntgrAnlysDashBoardStore();
  const useHzrTopRiskListStoreState = useHzrTopRiskListStore();

  const { isPSMSReportModal, gubun, code } = searchParam;

  useEffect(() => {
    useHzrTopRiskListStoreState.search();
    return clear;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>대시보드</h2>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="menu-tab">
          <a
            onClick={(e) => changeTab(0)}
            className={tabIndex == 0 ? 'active' : ''}
            data-label="HZR 전사 TOP RISK 분석 현황"
          >
            HZR 전사 TOP RISK 분석 현황
          </a>
          <a onClick={(e) => changeTab(1)} className={tabIndex == 1 ? 'active' : ''} data-label="TOP EVENT 현황">
            TOP EVENT 현황
          </a>
        </div>
      </div>
      {/*검색영역 */}

      {tabIndex == 0 ? <HzrTopRiskList /> : <></>}
      {tabIndex == 1 ? <TopEventList /> : <></>}
      <PSMSReportModal
        isOpen={isPSMSReportModal}
        closeModal={() => changeSearchInput('isPSMSReportModal', false)}
        searchInfo={searchParam}
      />
    </>
  );
}

export default SmsIntgrAnlysDashBoardList;
