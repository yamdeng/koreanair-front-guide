import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppSelect from '@/components/common/AppSelect';
import AppTextArea from '@/components/common/AppTextArea';
import AppTextInput from '@/components/common/AppTextInput';
import { useState } from 'react';

import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';
import useMyAuditPlanStore from '@/stores/aviation/audit/myAudit/useMyAuditPlanStore';

import AppCheckbox from '@/components/common/AppCheckbox';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppMaskInput from '@/components/common/AppMaskInput';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AuditCode from '@/config/AuditCode';
import { useImmer } from 'use-immer';
import AirportSearch from '../../common/AirportSearch';
import AuditorSelect from '../../common/AuditorSelect';
// import _ from 'lodash';

// const { Dragger } = Upload;
// const props: any = {
//   name: 'file',
//   multiple: true,
//   defaultFileList: [
//     {
//       uid: '1',
//       name: 'xxx.png',
//       // status: 'uploading',
//       url: 'http://www.baidu.com/xxx.png',
//       percent: 33,
//     },
//     {
//       uid: '2',
//       name: 'yyy.png',
//       status: 'done',
//       url: 'http://www.baidu.com/yyy.png',
//     },
//     {
//       uid: '3',
//       name: 'zzz.png',
//       status: 'error',
//       response: 'Server Error 500',
//       // custom error message to show
//       url: 'http://www.baidu.com/zzz.png',
//     },
//   ],
//   action: 'https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload',

//   onChange(info) {
//     const { status } = info.file;
//     if (status !== 'uploading') {
//       console.log(info.file, info.fileList);
//     }
//     if (status === 'done') {
//       alert(`${info.file.name} file uploaded successfully.`);
//     } else if (status === 'error') {
//       alert(`${info.file.name} file upload failed.`);
//     }
//   },

//   onRemove(file) {
//     return false;
//   },

//   onPreview(file) {
//     return false;
//   },

//   onDrop(e) {
//     console.log('Dropped files', e.dataTransfer.files);
//   },
// };

function MyAuditPlan() {
  // const [inputValue, setInputValue] = useState('');
  // const rowData = getAllData();
  // const columns = testColumnInfos;

  /* frameStore 변수 */
  const { hidePlan } = useMyAuditFrameStore();

  /* formStore state input 변수 */
  const {
    formValue,
    changeInput,
    errors,
    searchFligh,
    changeDivision,
    changeAuditTypeCode,
    divisionAuditTypeGrpCd,
    divisionChecklist,
    deleteAudit,
    saveAuditPlan,
    changeAirportRegion,
    airportRegions,
    changeStateProps,
    onSelectAuditorList,
    deleteAuditorList,
    userSelectKind,
    // treeWorkScope,
    // formType,
    // menuTreeData,
    // parentMenuTreeData,
    // handleTreeSelect,
    // init,
    // changeTreeWorkScope,
    // changeWorkScope,
    // handleParentTreeSelect,
    // save,
    // remove,
    // addMenu,
    // clear,
  } = useMyAuditPlanStore();

  const {
    /* Audit */
    // auditId,
    // auditNo,
    title,
    division,
    urlPlan,
    // urlResult,
    // isFinding,
    // phase,
    // phaseLevel,
    // state,
    // timezone,
    auditAt,
    isRemote,
    airlineCategory,
    auditTypeCode,
    // isSubmmited,
    // submittedAt,
    notes,
    // approvedBy,
    planFileGroupSeq,
    // resultFileGroupSeq,
    preFileGroupSeq,
    // useYn,
    // Auditor 정보
    auditorInfo,
    // Checklist 정보
    checklistInfo,
    /* Auditee */
    auditeeInfo,
  } = formValue;

  const {
    auditeeId,
    area,
    auditeeDivision,
    legFromAirport,
    legToAirport,
    auditeeType,
    airport,
    companyName,
    lineSafetyYn,
    departureAt,
    flightNo,
    fromAirport,
    toAirport,
    route,
    fleet,
    registrationSign,
    acType,
    acVersion,
    dutyPurser,
    qualification,
    rank,
    numberSeats,
    occupant,
  } = auditeeInfo;

  //console.log(`divisionChecklist : ${_.toString(divisionChecklist)}`);
  //console.log(`checklistInfo : ${_.toString(checklistInfo)}`);

  return (
    <>
      {/* <div id="area-PLAN" className={`myaudit-contents ${hidePlan}`}> */}
      <div id="area-PLAN" className="myaudit-contents">
        <div className="audit-box">
          <div className="audit-left-box">
            <h2>Plan</h2>
            <div className="editbox">
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="group-box-wrap wid100">
                    <span className="txt">
                      Remote/On-site
                      <span className="required">*</span>
                    </span>
                    <AppRadioGroup
                      id="AuditPlanFormStoreisRemote"
                      name="isRemote"
                      label="Remote/On-site"
                      options={[
                        { value: 'Y', label: 'Remote' },
                        { value: 'N', label: 'On-site' },
                      ]}
                      value={isRemote}
                      onChange={(value) => changeInput('isRemote', value)}
                      required
                      errorMessage={errors.isRemote}
                      // required={checkedRequired}
                      // disabled={checkedDisabled}
                      // toolTipMessage={checkedToolTip ? 'aaa\nbbb\ncccc' : ''}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="number-r ">
                    {/* <div className="title">Airline</div> */}
                    <div className="form-group wid100">
                      <AppCodeSelect
                        id="AuditPlanFormStoreairlineCategory"
                        codeGrpId="CODE_GRP_317"
                        label="Airline"
                        value={airlineCategory}
                        // isMultiple
                        onChange={(value) => {
                          changeInput('airlineCategory', value);
                        }}
                        required
                        errorMessage={errors.airlineCategory}
                        // disabled
                      />
                    </div>
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      id="AuditPlanFormStoretitle"
                      label="Audit Title"
                      name="title"
                      value={title}
                      onChange={(value) => changeInput('title', value)}
                      required
                      errorMessage={errors.title}
                      // disabled={formType === FORM_TYPE_UPDATE}
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppCodeSelect
                      id="AuditPlanFormStoredivision"
                      codeGrpId="CODE_GRP_301"
                      label="Division"
                      value={division}
                      onChange={(value) => {
                        changeInput('division', value);
                        changeInput('auditTypeCode', '');
                        changeInput('checklistInfo', null);
                        changeDivision(value); // 선택한 부문의 Audit유형, 체크리스트 조회
                      }}
                      required
                      errorMessage={errors.division}
                      // disabled
                      // isMultiple
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppDatePicker
                      id="AuditPlanFormStoreauditAt"
                      label="Audit Date (KST)"
                      name="auditAt"
                      value={auditAt}
                      onChange={(value) => changeInput('auditAt', value)}
                      errorMessage={errors.auditAt}
                      //showTime
                      //excludeSecondsTime
                      required
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    {/* <AppCodeSelect
                      label="Audit Type"
                      required
                      // codeGrpIdList={[
                      //   'CODE_GRP_303',
                      //   'CODE_GRP_304',
                      //   'CODE_GRP_305',
                      //   'CODE_GRP_306',
                      //   'CODE_GRP_307',
                      //   'CODE_GRP_308',
                      //   'CODE_GRP_309',
                      //   'CODE_GRP_310',
                      // ]}
                      codeGrpIdList={'CODE_GRP_303'}
                      value={auditTypeCode}
                      //isMultiGroupCode
                      onChange={(value) => {
                        //setMultipleCodeSelectValue(value);
                        changeInput('auditTypeCode', value);
                      }}
                      // isMultiple
                    /> */}
                    <AppCodeSelect
                      id="AuditPlanFormStoreauditTypeCode"
                      codeGrpId={divisionAuditTypeGrpCd}
                      label="Audit Type"
                      value={auditTypeCode}
                      onChange={(value) => {
                        changeInput('auditTypeCode', value);
                        changeAuditTypeCode(value); // 선택한 부문의 Audit유형, 체크리스트 조회
                      }}
                      required
                      errorMessage={errors.auditTypeCode}
                      // disabled
                      // isMultiple
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppSelect
                      id="AuditPlanFormStorechecklistId"
                      options={divisionChecklist}
                      label="Checklist"
                      value={checklistInfo}
                      labelKey="listName"
                      valueKey="checklistId"
                      onChange={(appSelectValue) => {
                        changeInput('checklistInfo', appSelectValue);
                      }}
                      isMultiple
                      required
                      //errorMessage={errors.checklistInfo.checklistId}
                      errorMessage={errors['checklistInfo']}
                      // disabled
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <h3 className="av-table-tit mt-10">계획보고</h3>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      label="전재 결재 문서 링크"
                      id="urlPlan"
                      name="urlPlan"
                      value={urlPlan}
                      onChange={(value) => changeInput('urlPlan', value)}
                      // required
                      errorMessage={errors.urlPlan}
                      // disabled={formType === FORM_TYPE_UPDATE}
                    />
                  </div>
                </div>
              </div>
              {/* 파일첨부영역 : drag */}
              <div className="form-cell wid100 mb-20">
                <div className="form-group wid100">
                  {/* 파일첨부영역 : drag */}
                  {/* <div className="filebox error">
                    <Dragger {...props}>
                      <p className="ant-upload-text ">+ 이 곳을 클릭하거나 마우스로 업로드할 파일을 끌어서 놓으세요.</p>
                    </Dragger>
                    <label htmlFor="file" className="file-label">
                      첨부파일 <span className="required">*</span>
                    </label>
                  </div>
                  <span className="errorText">fileerror</span> */}
                  {/* 파일첨부영역 : drag */}
                  <AppFileAttach
                    id="InvestigationReportEditspiFileGroupSeq"
                    name="spiFileGroupSeq"
                    label="전자 결재 문서"
                    fileGroupSeq={planFileGroupSeq}
                    workScope={'A'}
                    updateFileGroupSeq={(newFileGroupSeq) => {
                      changeInput('planFileGroupSeq', newFileGroupSeq);
                    }}
                    errorMessage={errors['planFileGroupSeq']}
                  />
                </div>
              </div>
              {/* <hr className="line"></hr> */}
              <div className="form-cell wid100 mb-15">
                <div className="form-group wid100">
                  <AuditorSelect
                    label="Auditor"
                    options={AuditCode.auditorType}
                    userList={auditorInfo}
                    changeUserSelectKind={(value) => {
                      changeStateProps('userSelectKind', value);
                    }}
                    userSelectKind={userSelectKind}
                    onSelect={onSelectAuditorList}
                    deleteUser={deleteAuditorList}
                    required
                    //errorMessage={errors.checklistInfo.checklistId}
                    errorMessage={errors['auditorInfo']}
                  />
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                {/* 파일첨부영역 : drag */}
                <div className="form-cell wid100">
                  <div className="form-group wid100">
                    {/* 파일첨부영역 : drag */}
                    {/* <div className="filebox error">
                      <Dragger {...props}>
                        <p className="ant-upload-text ">
                          + 이 곳을 클릭하거나 마우스로 업로드할 파일을 끌어서 놓으세요.
                        </p>
                      </Dragger>
                      <label htmlFor="file" className="file-label">
                        Pre-meeting <span className="required">*</span>
                      </label>
                    </div>
                    <span className="errorText">fileerror</span> */}
                    {/* 파일첨부영역 : drag */}
                    <AppFileAttach
                      id="InvestigationReportEditspiFileGroupSeq"
                      name="spiFileGroupSeq"
                      label="Pre-meeting"
                      fileGroupSeq={preFileGroupSeq}
                      workScope={'A'}
                      updateFileGroupSeq={(newFileGroupSeq) => {
                        changeInput('preFileGroupSeqq', newFileGroupSeq);
                      }}
                      errorMessage={errors['preFileGroupSeq']}
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextArea
                      label="notes"
                      style={{ width: '100%', height: 120 }}
                      errorMessage=""
                      value={notes}
                      onChange={(value) => changeInput('notes', value)}
                    />
                    {/* <label className="f-label" htmlFor="testArea1">
                      비고
                    </label> */}
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
            </div>
          </div>
          <div className="audit-right-box">
            <h2>Auditee</h2>
            <div className="editbox">
              <div className="form-table line">
                <div className="form-cell wid20">
                  <div className="group-box-wrap wid100">
                    <div className="radio-wrap border-no">
                      <label>
                        {/* <input type="radio" /> */}
                        <span>Airport</span>
                      </label>
                    </div>
                    {/*<span className="errorText">error</span>*/}
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    {/* <AppAutoComplete
                      label="Airport"
                      apiUrl="avn/common/airports"
                      value={airport}
                      labelKey="label"
                      valueKey="airportCode"
                      dataKey="data.list"
                      onChange={(value) => {
                        changeInput('auditeeInfo.airport', value);
                        changeAirportRegion(value.airportCode);
                      }}
                      isMultiple={false}
                      required
                      //isValueString
                      errorMessage={errors['auditeeInfo.airport']}
                      //errorMessage={errors.auditeeInfo}
                    /> */}
                    <AirportSearch
                      label="Airport"
                      value={airport}
                      onChange={(value) => {
                        changeInput('auditeeInfo.airport', value);
                        changeAirportRegion(value);
                      }}
                      required
                      errorMessage={errors['auditeeInfo.airport']}
                    />
                  </div>
                </div>
                <div className="form-cell wid30">
                  <div className="form-group wid100">
                    {/* <AppTextInput
                      label="Region"
                      id="area"
                      name="area"
                      value={area}
                      onChange={(value) => changeInput('auditeeInfo.area', value)}
                      errorMessage={errors.area}
                      // required
                      // disabled={formType === FORM_TYPE_UPDATE}
                    /> */}
                    <AppSelect
                      id="AuditPlanFormStorearea"
                      label="Area"
                      options={airportRegions}
                      value={area}
                      labelKey="airportarea"
                      valueKey="airportarea"
                      onChange={(value) => {
                        changeInput('auditeeInfo.area', value);
                      }}
                      required
                      errorMessage={errors['auditeeInfo.area']}
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid30">
                  <div className="group-box-wrap wid100">
                    <div className="radio-wrap border-no">
                      <label>
                        {/* <input type="radio" /> */}
                        <span>KE</span>
                      </label>
                    </div>
                    {/*<span className="errorText">error</span>*/}
                  </div>
                </div>
                <div className="form-cell wid60">
                  <div className="form-group wid100">
                    {/* <AppTextInput label="Division" /> */}
                    <AppTextInput
                      label="Division"
                      id="auditeeDivision"
                      name="auditeeDivision"
                      value={auditeeDivision}
                      onChange={(value) => changeInput('auditeeInfo.auditeeDivision', value)}
                      // required
                      errorMessage={errors.auditeeDivision}
                      // disabled={formType === FORM_TYPE_UPDATE}
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid30">
                  <div className="group-box-wrap wid100">
                    <div className="radio-wrap border-no">
                      <label>
                        {/* <input type="radio" /> */}
                        <span>External Service Provider</span>
                      </label>
                    </div>
                    {/*<span className="errorText">error</span>*/}
                  </div>
                </div>

                <div className="form-cell wid60">
                  <div className="form-group wid100">
                    <AppTextInput
                      label="Company Name"
                      id="companyName"
                      name="companyName"
                      value={companyName}
                      onChange={(value) => changeInput('auditeeInfo.companyName', value)}
                      errorMessage={errors.companyName}
                      // required
                      // disabled={formType === FORM_TYPE_UPDATE}
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid100">
                  <div className="group-box-wrap wid100">
                    {/* <span className="txt">
                      Line Safety Audit
                      <span className="required">*</span>
                    </span> */}
                    {/* <div className="radio-wrap">
                      <label> */}
                    {/* <input type="checkbox" /> */}
                    <AppCheckbox
                      label="Line Safety Audit"
                      value={lineSafetyYn}
                      onChange={(value) => changeInput('auditeeInfo.lineSafetyYn', value)}
                      // onChange={(value) => {
                      //   toggleExpandAuditor(value);
                      // }}
                      noBorder
                      disabled
                    />
                    {/* <span>Remote</span> */}
                    {/* </label>
                    </div> */}
                    {/*<span className="errorText">error</span>*/}
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    {/* <AppAutoComplete inputType={'number'} label={''} /> */}
                    <AppAutoComplete
                      label="Leg (From)"
                      apiUrl="avn/common/airports"
                      value={legFromAirport}
                      labelKey="label"
                      valueKey="airportCode"
                      dataKey="data.list"
                      onChange={(value) => {
                        changeInput('auditeeInfo.legFromAirport', value);
                      }}
                      isMultiple={false}
                      // required
                      isValueString
                      errorMessage={errors['auditeeInfo.legFromAirport']}
                    />
                  </div>
                </div>
                {/* <span className="unt">/</span> */}
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    {/* <AppAutoComplete inputType={'number'} label={''} /> */}
                    <AppAutoComplete
                      label="Leg (To)"
                      apiUrl="avn/common/airports"
                      value={legToAirport}
                      labelKey="label"
                      valueKey="airportCode"
                      dataKey="data.list"
                      onChange={(value) => {
                        changeInput('auditeeInfo.legToAirport', value);
                      }}
                      isMultiple={false}
                      // required
                      isValueString
                      errorMessage={errors['auditeeInfo.legToAirport']}
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="boxForm mt-15">
                <h3>Departure Date</h3>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker
                        label="Departure Date (UTC)"
                        id="departureAt"
                        name="departureAt"
                        value={departureAt}
                        onChange={(value) => changeInput('auditeeInfo.departureAt', value)}
                        errorMessage={errors['auditeeInfo.departureAt']}
                        //showTime
                        //excludeSecondsTime
                        // required
                      />
                    </div>
                  </div>
                  {/* <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppSelect label={'UTC'} disabled />
                    </div>
                  </div> */}
                </div>
                <h3>Flight No.</h3>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group va-t ant-input wid100">
                      <span className="ant-input-group-addon1">KE</span>
                      <div className="ant-input-group-addon1-input wid50">
                        {/* <AppTextInput label="Digit only" required /> */}
                        <AppMaskInput
                          id="InvestigationReportEditflightNo"
                          mask="9999"
                          name="flightNo"
                          label="Digit only"
                          value={flightNo}
                          onBlur={(event) => {
                            //const value = event.target.value;
                            // TODO : 뒤에 4자리 이하면은 앞에 0붙임
                            event.target.value = String(event.target.value).padStart(4, '0');
                          }}
                          onKeyDown={(event) => {
                            if (event.key === 'Enter') {
                              //const value = event.target.value;
                              // TODO : 뒤에 4자리 이하면은 앞에 0을 붙이고 search
                              event.target.value = String(event.target.value).padStart(4, '0');
                              searchFligh();
                            }
                          }}
                          onChange={(value) => changeInput('auditeeInfo.flightNo', 'KE' + value)}
                          hiddenClearButton
                          errorMessage={errors['auditeeInfo.flightNo']}
                        />
                      </div>
                    </div>
                  </div>
                  {/* <div className="btn-area">
                    <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                      Search
                    </button>
                  </div> */}
                  <div className="btn-area">
                    <button
                      type="button"
                      name="button"
                      className="btn-sm btn_text btn-darkblue-line"
                      onClick={() => {
                        searchFligh();
                      }}
                    >
                      Search
                    </button>
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table">
                <div className="form-cell wid40">
                  <div className="form-group wid100">
                    {/*출발 공항 */}
                    <AppAutoComplete
                      label="출발 공항"
                      apiUrl="avn/common/airports"
                      value={fromAirport}
                      labelKey="label"
                      valueKey="airportCode"
                      dataKey="data.list"
                      onChange={(value) => {
                        changeInput('auditeeInfo.fromAirport', value);
                      }}
                      isMultiple={false}
                      // required
                      isValueString
                      errorMessage={errors['auditeeInfo.fromAirport']}
                    />
                  </div>
                </div>
                {/* <span className="unt">/</span> */}
                <div className="form-cell wid40">
                  <div className="form-group wid100">
                    {/*도착 공항 */}
                    <AppAutoComplete
                      label="도착 공항"
                      apiUrl="avn/common/airports"
                      value={toAirport}
                      labelKey="label"
                      valueKey="airportCode"
                      dataKey="data.list"
                      onChange={(value) => {
                        changeInput('auditeeInfo.toAirport', value);
                      }}
                      isMultiple={false}
                      // required
                      isValueString
                      errorMessage={errors['auditeeInfo.toAirport']}
                    />
                  </div>
                </div>
                <div className="form-cell wid20">
                  <div className="form-group wid100">
                    <AppCodeSelect
                      codeGrpId="CODE_GRP_318"
                      label="Route"
                      value={route}
                      // isMultiple
                      onChange={(value) => {
                        changeInput('auditeeInfo.route', value);
                      }}
                      // disabled
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <h3 className="av-table-tit mt-10">Fleet</h3>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      id="Fleet"
                      name="Fleet"
                      value={fleet}
                      label="Fleet"
                      onChange={(value) => changeInput('auditeeInfo.fleet', value)}
                      hiddenClearButton
                      errorMessage={errors['auditeeInfo.fleet']}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    {/*항공기형식 */}
                    <AppTextInput
                      id="InvestigationReportEditaircraftTypeText"
                      name="acType"
                      // inputType="text"
                      value={acType}
                      label="A/C Type"
                      onChange={(value) => changeInput('auditeeInfo.acType', value)}
                      hiddenClearButton
                      errorMessage={errors['auditeeInfo.acType']}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      id="acVersion"
                      name="acVersion"
                      value={acVersion}
                      label="A/C Version"
                      onChange={(value) => changeInput('auditeeInfo.acVersion', value)}
                      hiddenClearButton
                      errorMessage={errors['auditeeInfo.acVersion']}
                    />
                  </div>
                </div>

                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppMaskInput
                      id="InvestigationReportEditregistrationNo"
                      mask="9999"
                      name="registrationSign"
                      label="HL"
                      value={registrationSign}
                      onChange={(value) => changeInput('auditeeInfo.registrationSign', 'HL' + value)}
                      hiddenClearButton
                      search={''}
                      errorMessage={errors['auditeeInfo.registrationSign']}
                    />
                  </div>
                </div>
              </div>
              <hr className="line"></hr>
              <div className="form-table line">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppAutoComplete label="Duty Purser" />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      id="InvestigationReportEditsupply"
                      name="Qualification"
                      value={qualification}
                      label="Qualification"
                      onChange={(value) => changeInput('auditeeInfo.qualification', value)}
                      hiddenClearButton
                      errorMessage={errors['auditeeInfo.qualification']}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      id="InvestigationReportEditsupply"
                      name="Rank"
                      value={rank}
                      label="Rank"
                      onChange={(value) => changeInput('auditeeInfo.rank', value)}
                      hiddenClearButton
                      errorMessage={errors['auditeeInfo.rank']}
                    />
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
              <div className="form-table line">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      id="InvestigationReportEditsupply"
                      name="numberSeats"
                      value={numberSeats}
                      label="좌석수(F/C/Y)"
                      onChange={(value) => changeInput('auditeeInfo.numberSeats', value)}
                      hiddenClearButton
                      errorMessage={errors['auditeeInfo.numberSeats']}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      id="InvestigationReportEditcheckIn"
                      name="occupant"
                      value={occupant}
                      label="탑승자(F/C/Y)"
                      onChange={(value) => changeInput('auditeeInfo.occupant', value)}
                      hiddenClearButton
                      errorMessage={errors['auditeeInfo.occupant']}
                    />
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
            </div>
          </div>
        </div>
        {/* 하단버튼영역 */}
        <div className="contents-btns">
          <button className="btn_text btn_list" onClick={() => deleteAudit()}>
            Delete
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={() => saveAuditPlan('PLAN')}>
            Save
          </button>
          <button
            type="button"
            name="button"
            className="btn_text text_color_neutral-10 btn_confirm"
            onClick={() => saveAuditPlan('CONDUCT')}
          >
            Next
          </button>
        </div>
        {/*//하단버튼영역*/}
      </div>
    </>
  );
}

export default MyAuditPlan;
