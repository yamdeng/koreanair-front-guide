import AppTextInput from '@/components/common/AppTextInput';
import AppEditor from '@/components/common/AppEditor';
import AppFileAttach from '@/components/common/AppFileAttach';

function CsrEventContent({ store = {} }) {
  const { formName = '', formValue, changeInput, errors } = store as any;
  const { event } = formValue;
  const { subjectNm, descriptionTxtcn, fileGroupSeq } = event;

  return (
    <div className="edit-area">
      <div className="detail-form">
        <div className="detail-list">
          <div className="form-table">
            <div className="form-cell wid50 ">
              <div className="form-group wid100">
                {/*제목*/}
                <AppTextInput
                  id={`${formName}event.subjectNm`}
                  label="제목"
                  value={subjectNm}
                  onChange={(value) => {
                    changeInput('event.subjectNm', value);
                  }}
                  required
                  errorMessage={errors['event.subjectNm']}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100 ">
                {/*내용 */}
                <AppEditor
                  id={`${formName}event.descriptionTxtcn`}
                  label="AppEditor"
                  value={descriptionTxtcn}
                  onChange={(value, byPassIsDirty) => {
                    changeInput('event.descriptionTxtcn', value, byPassIsDirty);
                  }}
                  required
                  errorMessage={errors['event.descriptionTxtcn']}
                />
              </div>
            </div>
          </div>
          {/* 파일첨부영역 : drag */}
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppFileAttach
                  label={'첨부파일'}
                  fileGroupSeq={fileGroupSeq}
                  workScope={'A'}
                  updateFileGroupSeq={(newFileGroupSeq) => {
                    changeInput('event.fileGroupSeq', newFileGroupSeq);
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CsrEventContent;
