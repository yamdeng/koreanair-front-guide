function ReportWriteFormMenu() {
  return <div>ReportWriteFormMenu</div>;
}
export default ReportWriteFormMenu;
