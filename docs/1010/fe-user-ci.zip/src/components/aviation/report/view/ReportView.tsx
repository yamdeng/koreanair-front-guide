import AppNavigation from '@/components/common/AppNavigation';
import ReportViewStore from '@/stores/aviation/report/view/ReportViewStore';
import ReportViewContent from './ReportViewContent';
import ReportViewFirstRisk from './ReportViewFirstRisk';
import ReportViewHazardClose from './ReportViewHazardClose';
import ReportViewMitigation from './ReportViewMitigation';
import ReportViewReception from './ReportViewReception';
import ReportViewSecondRisk from './ReportViewSecondRisk';
import ReportViewTop from './ReportViewTop';

/* 보고서상세 전체 layout */
function ReportView() {
  const toggleAccordionExpanded = ReportViewStore((state) => state.toggleAccordionExpanded);
  const contentExpanded = ReportViewStore((state) => state.contentExpanded);
  const analysExpanded = ReportViewStore((state) => state.analysExpanded);
  const receptionExpanded = ReportViewStore((state) => state.receptionExpanded);
  const firstRiskExpanded = ReportViewStore((state) => state.firstRiskExpanded);
  const mitigationExpanded = ReportViewStore((state) => state.mitigationExpanded);
  const secondRiskExpanded = ReportViewStore((state) => state.secondRiskExpanded);
  const hazardCloseExpanded = ReportViewStore((state) => state.hazardCloseExpanded);

  return (
    <>
      <AppNavigation />
      <ReportViewTop />
      <div className="info-wrap toggle">
        {/* 보고서 내용보기 */}
        <dl className={contentExpanded ? 'tg-item active' : 'tg-item'} id="view-content">
          <dt onClick={() => toggleAccordionExpanded('contentExpanded')}>
            <button type="button" className="btn-tg">
              보고서 내용보기<span className={contentExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: contentExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <ReportViewContent />
            </div>
          </dd>
        </dl>
        {/* 보고서 분석 */}
        <dl className={analysExpanded ? 'tg-item active' : 'tg-item'} id="view-analys">
          <dt onClick={() => toggleAccordionExpanded('analysExpanded')}>
            <button type="button" className="btn-tg">
              보고서 분석<span className={analysExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: analysExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detailForm">
                {/* 접수 */}
                <div className="detailForm-detail-box list-group" id="view-reception">
                  <div className="detailForm-detail-2deps rbox list-group">
                    <div className="list bx-toggle">
                      <dl className="tg-item rbox01 ">
                        <dt onClick={() => toggleAccordionExpanded('receptionExpanded')}>
                          <button type="button" className="tg-btn">
                            접수<span className={receptionExpanded ? 'active' : ''}></span>
                          </button>
                        </dt>
                        <dd className="tg-conts" style={{ display: receptionExpanded ? '' : 'none' }}>
                          <ReportViewReception />
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>

                {/* 1차 위험도 평가 */}
                <div className="detailForm-detail-box list-group" id="view-firstrisk">
                  <div className="detailForm-detail-2deps rbox list-group">
                    <div className="list bx-toggle">
                      <dl className="tg-item rbox01 ">
                        <dt onClick={() => toggleAccordionExpanded('firstRiskExpanded')}>
                          <button type="button" className="tg-btn">
                            1차위험도평가<span className={firstRiskExpanded ? 'active' : ''}></span>
                          </button>
                        </dt>
                        <dd className="tg-conts" style={{ display: firstRiskExpanded ? '' : 'none' }}>
                          <ReportViewFirstRisk />
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>

                {/* 경감조치 */}
                <div className="detailForm-detail-box list-group" id="view-mitigation">
                  <div className="detailForm-detail-2deps rbox list-group">
                    <div className="list bx-toggle">
                      <dl className="tg-item rbox01 ">
                        <dt onClick={() => toggleAccordionExpanded('mitigationExpanded')}>
                          <button type="button" className="tg-btn">
                            경감조치<span className={mitigationExpanded ? 'active' : ''}></span>
                          </button>
                        </dt>
                        <dd className="tg-conts" style={{ display: mitigationExpanded ? '' : 'none' }}>
                          <ReportViewMitigation />
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>

                {/* 2차 위험도 평가 */}
                <div className="detailForm-detail-box list-group" id="view-secondrisk">
                  <div className="detailForm-detail-2deps rbox list-group">
                    <div className="list bx-toggle">
                      <dl className="tg-item rbox01 ">
                        <dt onClick={() => toggleAccordionExpanded('secondRiskExpanded')}>
                          <button type="button" className="tg-btn">
                            2차위험도평가<span className={secondRiskExpanded ? 'active' : ''}></span>
                          </button>
                        </dt>
                        <dd className="tg-conts" style={{ display: secondRiskExpanded ? '' : 'none' }}>
                          <ReportViewSecondRisk />
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>

                {/* 종결 */}
                <div className="detailForm-detail-box list-group" id="view-hazard_close">
                  <div className="detailForm-detail-2deps rbox list-group">
                    <div className="list bx-toggle">
                      <dl className="tg-item rbox01 ">
                        <dt onClick={() => toggleAccordionExpanded('hazardCloseExpanded')}>
                          <button type="button" className="tg-btn">
                            종료<span className={hazardCloseExpanded ? 'active' : ''}></span>
                          </button>
                        </dt>
                        <dd className="tg-conts" style={{ display: hazardCloseExpanded ? '' : 'none' }}>
                          <ReportViewHazardClose />
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
    </>
  );
}

export default ReportView;
