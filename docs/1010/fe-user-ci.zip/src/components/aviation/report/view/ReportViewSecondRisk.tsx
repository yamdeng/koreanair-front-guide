import ReportViewSecondRiskAssessment from './ReportViewSecondRiskAssessment';
import ReportViewSecondRiskReview from './ReportViewSecondRiskReview';

/* 보고서상세 > 보고서 분석 > 2차 위험도 평가 */
function ReportViewSecondRisk() {
  return (
    <div className="edit-area">
      <ReportViewSecondRiskAssessment />
      <ReportViewSecondRiskReview />
    </div>
  );
}

export default ReportViewSecondRisk;
