import AppTextArea from '@/components/common/AppTextArea';
import ReportViewStore from '@/stores/aviation/report/view/ReportViewStore';
import ReportViewFirstRiskReviewStore from '@/stores/aviation/report/view/ReportViewFirstRiskReviewStore';

/* 보고서상세 > 보고서 분석 > 1차 위험도 평가 > SRC리뷰 */
function ReportViewFirstRiskReview() {
  const toggleAccordionExpanded = ReportViewStore((state) => state.toggleAccordionExpanded);
  const firstRiskReviewExpanded = ReportViewStore((state) => state.firstRiskReviewExpanded);

  return (
    <div className="detailForm-detail-3deps list-group" id="view-firstrisk-review">
      <div className="list bx-toggle">
        <dl className="tg-item rbox01 ">
          <dt onClick={() => toggleAccordionExpanded('firstRiskReviewExpanded')}>
            <button type="button" className="tg-btn">
              SRC리뷰<span className={firstRiskReviewExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: firstRiskReviewExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="listtable">
                <table className="info-board">
                  <colgroup>
                    <col width="25%" />
                    <col width="18%" />
                    <col width="12%" />
                    <col width="8%" />
                    <col width="18%" />
                    <col width="10%" />
                    <col width="9%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>Hazard</th>
                      <th>Potential Consequence</th>
                      <th>Risk Level 1</th>
                      <th>Mitigation</th>
                      <th>Register</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="tl">Lightning strike Environmental/Weather</td>
                      <td className="tl">Aircraft Change</td>
                      <td>
                        <div className="Safety-table-cell">
                          <span className="Safety-tag riskLevel level1">3A</span>
                        </div>
                      </td>
                      <td className="fix vm">
                        <div className="radio-wrap center">
                          <label className="text-no">
                            <input type="checkbox" />
                            <span className="text-no"></span>
                          </label>
                        </div>
                      </td>
                      <td className="tl">LSC김리더(LeaderKim)</td>
                      <td>SRC대기</td>
                      <td>
                        <a href="javascript:void(0);" className="btn-modify">
                          Approve
                        </a>
                        <a href="javascript:void(0);" className="btn-modify">
                          Reject
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td className="tl">Sandstorm Environmental/Weather</td>
                      <td className="tl">Escape slide deployment</td>
                      <td>
                        <div className="Safety-table-cell">
                          <span className="Safety-tag riskLevel level3">2B</span>
                        </div>
                      </td>
                      <td className="fix vm">
                        <div className="radio-wrap center">
                          <label className="text-no">
                            <input type="checkbox" />
                            <span className="text-no"></span>
                          </label>
                        </div>
                      </td>
                      <td className="tl">LSC김리더(LeaderKim)</td>
                      <td>SRC대기</td>
                      <td>
                        <a href="javascript:void(0);" className="btn-modify">
                          Approve
                        </a>
                        <a href="javascript:void(0);" className="btn-modify">
                          Reject
                        </a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="form-table line">
                <div className="form-cell wid100">
                  <div className="form-group wid100">
                    <AppTextArea label="회의록" style={{ width: '100%', height: 145 }} errorMessage="" />
                  </div>
                </div>
              </div>
              {/* 하단버튼영역 */}
              <div className="contents-btns">
                <button type="button" name="button" className="btn_text btn-del">
                  인쇄
                </button>
                <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
                  저장
                </button>
                <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
                  Submit
                </button>
                <button type="button" name="button" className="btn_text btn_list">
                  목록
                </button>
              </div>
              {/*//하단버튼영역*/}
            </div>
          </dd>
        </dl>
      </div>
    </div>
  );
}

export default ReportViewFirstRiskReview;
