import AppNavigation from '@/components/common/AppNavigation';
import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import useAsrFormStore from '@/stores/aviation/report/useAsrFormStore';
import CsrFlightInfo from '../../common/CsrFlightInfo';

function ReportGSREditFormInspection() {
  const formStore = useAsrFormStore();

  // TODO : expeand 변수 셋팅
  const {
    filghtExpanded,
    eventExpanded,
    errors,
    changeInput,
    getDetail,
    formValue,
    tempSave,
    save,
    print,
    toggleAccordionExpanded,
    isDirty,
    clear,
  } = formStore;

  const { event, weather, bird } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      clear();
    }
  }, [detailId]);

  useEffect(() => {
    return clear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['CSR']} />

      <div className="info-wrap toggle">
        <dl className={filghtExpanded ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button
              type="button"
              className="btn-tg"
              onClick={(event) => {
                event.stopPropagation();
                // toggleAccordionExpanded('filghtExpanded');
                history.replace(`/aviation/report-form/ASR/add`);
              }}
            >
              비행정보
              <span className={filghtExpanded ? 'active' : ''}></span>
              <div className="tag-info-wrap-end">
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      보고서 작성 가이드
                    </a>
                  </div>
                </div>
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      의무보고의 범위
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: filghtExpanded ? '' : 'none' }}>
            <CsrFlightInfo store={formStore} />
          </dd>
        </dl>

        <dl className={eventExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트
              <span className={eventExpanded ? 'active' : ''}></span>
            </button>
          </dt>
        </dl>
      </div>

      {/* 하단버튼영역 */}
      <ReportEditBottomButton print={print} tempSave={tempSave} save={save} />
    </>
  );
}

export default ReportGSREditFormInspection;
