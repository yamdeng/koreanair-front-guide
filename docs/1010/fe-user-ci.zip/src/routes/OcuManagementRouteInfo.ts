import TrainingList from '@/components/occupation/management/training/TrainingList';
import TrainingForm from '@/components/occupation/management/training/TrainingForm';
import TrainingDetail from '@/components/occupation/management/training/TrainingDetail';
import PartnerList from '@/components/occupation/management/partner/PartnerList';
import PartnerForm from '@/components/occupation/management/partner/PartnerForm';
import PartnerDetail from '@/components/occupation/management/partner/PartnerDetail';
import SealSpaceList from '@/components/occupation/management/sealSpace/SealSpaceList';
import SealSpaceForm from '@/components/occupation/management/sealSpace/SealSpaceForm';
import SealSpaceDetail from '@/components/occupation/management/sealSpace/SealSpaceDetail';
import MachinesMain from '@/components/occupation/management/machines/MachinesMain';
import MachineForm from '@/components/occupation/management/machines/MachineForm';
import WorkPermit from '@/components/occupation/management/permits/WorkPermit';
import WorkPermitDetail from '@/components/occupation/management/permits/WorkPermitDetail';
// import OutSourcingDetailModal from '@/components/occupation/management/outSourcing/OutSourcingDetailModal';
import WorkPermitForm from '@/components/occupation/management/permits/WorkPermitForm';
import WorkPermitList from '@/components/occupation/management/permits/WorkPermitList';
//import EnvironmentList from '@/components/occupation/management/environment/EnvironmentList';

const RouteInfo: any = { rootPath: 'management/' };

RouteInfo.list = [
  /** 중대재해대응훈련 **/

  // 중대재해대응훈련 목록
  {
    Component: TrainingList,
    path: 'training',
  },
  // 중대재해대응훈련 상세
  {
    Component: TrainingDetail,
    path: 'training/:detailId',
  },
  // 중대재해대응훈련 입력,수정
  {
    Component: TrainingForm,
    path: 'training/:detailId/edit',
  },

  /** 위험기계기구 **/

  // 위험기계기구 목록
  {
    Component: MachinesMain,
    path: 'machines',
  },
  // 위험기계기구 입력,수정 - TESTING 240826
  {
    Component: MachineForm,
    path: 'machines/:detailId/edit',
  },

  /** 작업환경측정 
  // 작업환경측정 목록
  {
    Component: EnvironmentList,
    path: 'environment',
  },
  // 작업환경측정 입력,수정
  {
    Component: EnvironmentForm,
    path: 'environment/:detailId/edit',
  },**/
  /** 협력업체 **/

  // 협력업체 목록
  {
    Component: PartnerList,
    path: 'partner',
  },
  // 협력업체 상세
  {
    Component: PartnerDetail,
    path: 'partner/:detailId',
  },
  // 협력업체 입력,수정
  {
    Component: PartnerForm,
    path: 'partner/:detailId/edit',
  },

  /** 외주작업허가 **/

  // 외주작업허가 메인
  {
    Component: WorkPermit,
    path: 'permits',
  },

  // 외주작업허가 목록
  {
    Component: WorkPermitList,
    path: 'permits',
  },
  // 외주작업허가 상세
  {
    Component: WorkPermitDetail,
    path: 'permits/:detailId',
  },
  // 협력업체 입력,수정
  {
    Component: WorkPermitForm,
    path: 'permits/:detailId/edit',
  },
  /** 적격수급업체평가 

  // 적격수급업체평가 목록
  {
    Component: EvaluationList,
    path: 'evaluation',
  },
  // 적격수급업체평가 상세
  {
    Component: EvaluationDetail,
    path: 'evaluation/:detailId',
  },
  // 적격수급업체평가 입력,수정
  {
    Component: EvaluationForm,
    path: 'evaluation/:detailId/edit',
  },**/

  /** 밀폐공간현황 **/

  // 밀폐공간현황 목록
  {
    Component: SealSpaceList,
    path: 'sealSpace',
  },
  // 밀폐공간현황 상세
  {
    Component: SealSpaceDetail,
    path: 'sealSpace/:detailId',
  },
  // 밀폐공간현황 입력,수정
  {
    Component: SealSpaceForm,
    path: 'sealSpace/:detailId/edit',
  },
  /** 관리감독자 평가 

  // 관리감독자 평가 목록
  {
    Component: Supervisor,
    path: 'supervisor',
  },
  // 관리감독자 평가 상세
  {
    Component: SupervisorDetail,
    path: 'supervisor/:detailId',
  },
  // 관리감독자 평가 입력,수정
  {
    Component: SupervisorForm,
    path: 'supervisor/:detailId/edit',
  },*/
];

export default RouteInfo;
