import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import AppEditor from '@/components/common/AppEditor';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useState } from 'react';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import AppDatePicker from '@/components/common/AppDatePicker';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';

import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppUserSelectInput from '@/components/common/AppUserSelectInput';

// import { Upload } from 'antd';
/* TODO : store 경로를 변경해주세요. */
import useOcuRevalPartnerFormStore from '@/stores/occupation/risk/useOcuRevalPartnerFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function NoticeForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, save, remove, cancel, clear } =
    useOcuRevalPartnerFormStore();

  const profile = useStore(useAppStore, (state) => state.profile);

  console.log('profile===>', profile);

  // 사용자명
  const nameKor = profile.userInfo.nameKor;
  // 사용자 Id
  const userId = profile.userInfo.userId;
  // 부문
  const sectCd = profile.userInfo.sectCd;
  // 부서
  const deptCd = profile.userInfo.deptCd;
  // 오늘 날짜
  const toDate = CommonUtil.getToDate();

  const {
    // 부문
    prtnrREvalSectCd,
    // 부서
    prtnrREvalDeptCd,
    // 작성자
    regUserId,
    // 작성자 성명
    regUserNm,
    // 작성일자
    regDttm,
    // 평가년도
    prtnrREvalEvalYear,
    // 평가시기
    prtnrREvalClsCd,
    // 협력업체
    prtnrId,
    // 사업장
    bizPlaceClsCd,
    // 제목
    prtnrREvalTitle,
    // 파일첨부
    prtnrREvalFileId,
  } = formValue;

  const { detailId } = useParams();

  if (detailId === 'add') {
    // 작성자 부문 코드
    formValue.prtnrREvalSectCd = sectCd;
    // 작성자 부서 코드
    formValue.prtnrREvalDeptCd = deptCd;
    // 작성자
    formValue.regUserNm = nameKor;
    // 작성자
    // formValue.regUserId = userId;
    // 작성일자
    formValue.regDttm = toDate;
  }

  useEffect(() => {
    console.log('detailId==>', detailId);
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  const clickPrtnrREvalClsCd = (v) => {
    console.log('v===>', v);

    // 대입
    formValue.prtnrId = '5';
    // changeInput('prtnrREvalClsCd', v);
    changeInput('bizPlaceClsCd', v);
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>협력사 위험성 평가 등록</h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부문</label>
                    <span className="text-desc-type1">{prtnrREvalSectCd}</span>
                  </li>
                </ul>
              </div> */}
              <AppCodeSelect
                label="부문"
                codeGrpId="CODE_GRP_OC001"
                value={detailId === 'add' ? sectCd : prtnrREvalSectCd}
                // onChange={(value) => changeInput(detailId === 'add' ? 'sectCd' : 'prtnrREvalSectCd', value)}
                onChange={(value) => {
                  changeInput('prtnrREvalSectCd', value);
                }}
                errorMessage={errors.prtnrREvalSectCd}
                disabled
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부서</label>
                    <span className="text-desc-type1">{prtnrREvalDeptCd}</span>
                  </li>
                </ul>
              </div> */}
              <AppDeptSelectInput
                label="부서"
                value={prtnrREvalDeptCd}
                onChange={(value) => {
                  changeInput('prtnrREvalDeptCd', value);
                }}
                required
                errorMessage={errors.prtnrREvalDeptCd}
                disabled
              />
              {/* <AppTextInput label="부서" required disabled /> */}
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성자</label>
                    <span className="text-desc-type1">{regUserId}</span>
                  </li>
                </ul>
              </div> */}
              {/* <AppTextInput label="작성자" required disabled /> */}
              {/* <AppUserSelectInput */}
              <AppTextInput
                label="작성자"
                value={regUserNm}
                onChange={(value) => {
                  changeInput('regUserNm', value);
                }}
                required
                errorMessage={errors.regUserNm}
                disabled
              />
            </div>
          </div>
        </div>

        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성일자</label>
                    <span className="text-desc-type1">{regDttm}</span>
                  </li>
                </ul>
              </div> */}
              {/* <AppSelect label={'작성일자'} required disabled /> */}
              <AppTextInput
                label="작성일자"
                value={regDttm}
                onChange={(value) => {
                  changeInput('regDttm', value);
                }}
                required
                errorMessage={errors.regDttm}
                disabled
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">평가년도</label>
                    <span className="text-desc-type1">{prtnrREvalEvalYear}</span>
                  </li>
                </ul>
              </div> */}
              {/* <AppSelect label={'평가년도'} /> */}
              <AppDatePicker
                label="평가년도"
                id="prtnrREvalEvalYear"
                // id={`${formName}advCmitImplmYm`}
                pickerType="year"
                value={prtnrREvalEvalYear}
                onChange={(value) => {
                  changeInput('prtnrREvalEvalYear', value);
                }}
                required
                errorMessage={errors.prtnrREvalEvalYear}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">평가시기</label>
                    <span className="text-desc-type1">{prtnrREvalClsCd}</span>
                  </li>
                </ul>
              </div> */}
              {/* <AppTextInput label="평가구분" /> */}
              <AppCodeSelect
                id="prtnrREvalClsCd"
                label="평가시기"
                codeGrpId="CODE_GRP_OC019"
                value={prtnrREvalClsCd}
                // onClick={clickPrtnrREvalClsCd}
                // onClick={(value) => clickPrtnrREvalClsCd(value)}
                // onClick={(value) => clickPrtnrREvalClsCd(value)}
                onChange={(value) => changeInput('prtnrREvalClsCd', value)}
                required
                errorMessage={errors.prtnrREvalClsCd}
              />
            </div>
          </div>
        </div>

        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">협력업체</label>
                    <span className="text-desc-type1">{prtnrId}</span>
                  </li>
                </ul>
              </div> */}
              {/* <AppSelect label={'작성일자'} required disabled /> */}
              <AppTextInput
                label="협력업체"
                value={prtnrId}
                onChange={(value) => {
                  changeInput('prtnrId', value);
                }}
                required
                errorMessage={errors.prtnrId}
                disabled
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">사업장</label>
                    <span className="text-desc-type1">{bizPlaceClsCd}</span>
                  </li>
                </ul>
              </div> */}
              {/* <AppSelect label={'평가년도'} /> */}
              <AppCodeSelect
                label="사업장"
                codeGrpId="CODE_GRP_OC009"
                value={bizPlaceClsCd}
                id="revalPeriod"
                // onChange={(value) => changeInput('bizPlaceClsCd', value)}
                onChange={(value) => clickPrtnrREvalClsCd(value)}
                required
                errorMessage={errors.bizPlaceClsCd}
              />
            </div>
          </div>
        </div>

        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppTextInput label="제목" /> */}
              {/* <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">제목</label>
                    <span className="text-desc-type1">{prtnrREvalTitle}</span>
                  </li>
                </ul>
              </div> */}
              <AppTextInput
                label="제목"
                value={prtnrREvalTitle}
                onChange={(value) => {
                  changeInput('prtnrREvalTitle', value);
                }}
                required
                errorMessage={errors.prtnrREvalTitle}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <h3 className="table-tit mb-10">사진 첨부</h3>
              <div className="form-group wid100">
                {/* <AppFileAttach
                  mode="view"
                  fileGroupSeq={prtnrREvalFileId}
                  workScope={'O'}
                  // onlyImageUpload={true}
                  useDetail
                  disabled
                /> */}

                <AppFileAttach
                  mode="edit"
                  label="파일첨부"
                  fileGroupSeq={prtnrREvalFileId}
                  workScope={'O'}
                  updateFileGroupSeq={(newFileGroupSeq) => {
                    changeInput('prtnrREvalFileId', newFileGroupSeq);
                  }}
                />
              </div>
              {/* <Upload {...props}>
                <div className="btn-area">
                  <button type="button" name="button" className="btn-big btn_text btn-darkblue-line">
                    파일 첨부
                  </button>
                </div>
              </Upload> */}
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default NoticeForm;
