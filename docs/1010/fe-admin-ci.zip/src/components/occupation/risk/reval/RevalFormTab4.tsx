import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
//import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';
import shareImage from '@/resources/images/share.svg';
// import AppFileAttach from '@/components/common/AppFileAttach';
import { useLocation } from 'react-router-dom';
import { Viewer } from '@toast-ui/react-editor';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';

import AppSearchInput from '@/components/common/AppSearchInput';

import AppFileAttach from '@/components/common/AppFileAttach';
import { Upload } from 'antd';
import useOcuRiskTab4FormStore from '@/stores/occupation/risk/useOcuRiskTab4FormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalFormTab2() {
  /* formStore state input 변수 */
  // const { detailInfo, getDetail, formType, cancel, goFormPage, clear, search, list } = useOcuRiskTab1FormStore();

  const {
    detailInfo,
    formValue,
    getDetail,
    formType,
    cancel,
    clear,
    search,
    removeByIndex,

    list,
    isDirty,

    //goForm,
    changeInput,
    errors,
    saveUseOcuRiskTab4,
  } = useOcuRiskTab4FormStore();

  const {
    // 회의_자료_사진_첨부_파일_ID
    meetDataPhotoId,
    // 회의_자료_파일_첨부_파일_ID
    meetDataFileId,
    // 교육_자료_사진_첨부_파일_ID
    eduDataPhotoFileId,
    // 교육_자료_파일_첨부_파일_ID
    eduDataFileFileId,
    // 화학_물질_첨부_파일_ID
    chmclMtrlFileId,
  } = formValue;

  const { detailId } = useParams();

  const init = async () => {
    getDetail(detailId);
    search();
  };

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      init();
    } else {
      console.log('초기화');
      // 리스트 초기화
      // list.deleteAll();
    }
    return clear;

    // init();
  }, []);

  useFormDirtyCheck(isDirty);
  // useEffect(() => {
  //   init();
  //   return clear;
  // }, []);

  return (
    <>
      {/*//탭 */}
      {/* 입력영역 */}
      {/*//탭 */}
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              회의자료<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="filebox error">
                          {/* <Upload
                            action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
                            listType="picture-card"
                            fileList={fileList}
                            onPreview={handlePreview}
                            onChange={handleChange}
                          >
                            {fileList.length >= 8 ? null : uploadButton}
                          </Upload> */}

                          <label htmlFor="file" className="file-label">
                            사진첨부{/*<span className="required">*</span>*/}
                          </label>
                          <span className="text-desc-type1">
                            <div className="filebox view">
                              <Upload {...meetDataPhotoId} listType="picture-card">
                                <div className="btn-area" style={{ display: 'none' }}>
                                  <button
                                    type="button"
                                    name="button"
                                    className="btn-big btn_text btn-darkblue-line mg-n"
                                  >
                                    + Upload
                                  </button>
                                </div>
                              </Upload>
                            </div>
                          </span>
                        </div>
                        {/* <span className="errorText">fileerror</span> */}
                      </div>
                      {/* {previewImage && (
                        <Image
                          wrapperStyle={{
                            display: 'none',
                          }}
                          preview={{
                            visible: previewOpen,
                            onVisibleChange: (visible) => setPreviewOpen(visible),
                            afterOpenChange: (visible) => !visible && setPreviewImage(''),
                          }}
                          src={previewImage}
                        />
                      )} */}
                    </div>
                  </div>
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="filebox ">
                          {/* <AppFileAttach
                            mode="edit"
                            fileGroupSeq={meetDataFileId}
                            workScope={'O'}
                            // onlyImageUpload={true}
                            // useDetail
                            // disabled
                          /> */}

                          <AppFileAttach
                            mode="edit"
                            label="파일첨부"
                            fileGroupSeq={meetDataFileId}
                            workScope={'O'}
                            updateFileGroupSeq={(newFileGroupSeq) => {
                              changeInput('meetDataFileId', newFileGroupSeq);
                            }}
                          />

                          {/* <Upload {...props}>
                            <div className="btn-area">
                              <button type="button" name="button" className="btn-big btn_text btn-darkblue-line mg-n">
                                + Upload
                              </button>
                            </div>
                          </Upload> */}
                          <label htmlFor="file" className="file-label">
                            파일 첨부 <span className="required">*</span>
                          </label>
                        </div>
                        {/*<span className="errorText">fileerror</span>*/}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              교육자료<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="filebox error">
                          <Upload {...eduDataPhotoFileId} listType="picture-card">
                            <div className="btn-area" style={{ display: 'none' }}>
                              <button type="button" name="button" className="btn-big btn_text btn-darkblue-line mg-n">
                                + Upload
                              </button>
                            </div>
                          </Upload>

                          {/* <Upload
                            action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
                            listType="picture-card"
                            fileList={fileList}
                            onPreview={handlePreview}
                            onChange={handleChange}
                          >
                            {fileList.length >= 8 ? null : uploadButton}
                          </Upload> */}
                          <label htmlFor="file" className="file-label">
                            사진첨부{/*<span className="required">*</span>*/}
                          </label>
                        </div>
                        {/* <span className="errorText">fileerror</span> */}
                      </div>
                      {/* {previewImage && (
                        <Image
                          wrapperStyle={{
                            display: 'none',
                          }}
                          preview={{
                            visible: previewOpen,
                            onVisibleChange: (visible) => setPreviewOpen(visible),
                            afterOpenChange: (visible) => !visible && setPreviewImage(''),
                          }}
                          src={previewImage}
                        />
                      )} */}
                    </div>
                  </div>
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="filebox ">
                          {/* <AppFileAttach
                            mode="view"
                            fileGroupSeq={eduDataFileFileId}
                            workScope={'O'}
                            // onlyImageUpload={true}
                            useDetail
                            disabled
                          /> */}

                          <AppFileAttach
                            mode="edit"
                            label="파일첨부"
                            fileGroupSeq={eduDataFileFileId}
                            workScope={'O'}
                            updateFileGroupSeq={(newFileGroupSeq) => {
                              changeInput('meetDataFileId', newFileGroupSeq);
                            }}
                          />

                          <label htmlFor="file" className="file-label">
                            파일 첨부 <span className="required">*</span>
                          </label>
                        </div>
                        {/*<span className="errorText">fileerror</span>*/}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              화학물질 위험성평가<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="filebox ">
                          {/* <AppFileAttach
                            mode="view"
                            fileGroupSeq={chmclMtrlFileId}
                            workScope={'O'}
                            // onlyImageUpload={true}
                            useDetail
                            disabled
                          /> */}
                          <AppFileAttach
                            mode="edit"
                            label="파일첨부"
                            fileGroupSeq={chmclMtrlFileId}
                            workScope={'O'}
                            updateFileGroupSeq={(newFileGroupSeq) => {
                              changeInput('meetDataFileId', newFileGroupSeq);
                            }}
                          />
                          <label htmlFor="file" className="file-label">
                            파일 첨부 <span className="required">*</span>
                          </label>
                        </div>
                        {/*<span className="errorText">fileerror</span>*/}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      {/*//입력영역*/}

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        {/*//하단버튼영역*/}
        {/*그리드영역 */}

        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={saveUseOcuRiskTab4}
          // style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          저장
        </button>
        {/* <button type="button" name="button" className="btn_text btn-del">
          삭제
        </button> */}
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
      </div>
    </>
  );
}
export default RevalFormTab2;
