import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
import shareImage from '@/resources/images/share.svg';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppTable from '@/components/common/AppTable';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';

import useOcuRiskTab3FormStore from '@/stores/occupation/risk/useOcuRiskTab3FormStore';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';

import RiskDcsnPsbltValModal from '@/components/modal/occupation/RiskDcsnPsbltValModal';
import RiskrDcsnImprtValModal from '@/components/modal/occupation/RiskrDcsnImprtValModal';
import RiskDcsnRiskValModal from '@/components/modal/occupation/RiskDcsnRiskValModal';

import CommonUtil from '@/utils/CommonUtil';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalDetailTab3() {
  // // 청취조사
  // const listenInfo = useOcuRiskTab2FormStore();
  // // 현장순화
  // const visitInfo = useOcuRiskTab2SiteVisitListStore();

  const {
    detailInfo,
    getDetail,
    formType,
    cancel,
    goFormPage,
    clear,
    search,
    list,
    procChange,
    openFormModal,
    isCodeFormModalOpen,
    closeFormModal,
    openFormModal2,
    isCodeFormModalOpen2,
    closeFormModal2,
    openFormModal3,
    isCodeFormModalOpen3,
    closeFormModal3,
    // list
    selectedPlaceIndex,
    setSelectedPlaceIndex,
    getPlaceColumn,
    formValue,
  } = useOcuRiskTab3FormStore();

  console.log('폼값===>', formValue);
  // const {
  //   /* 위험성정보 */

  //   // 위험성평가 문서 번호
  //   // revalDocNo,
  //   // 공정명
  //   procNm,
  //   // 세부 작업명
  //   detailWrkNm,

  //   // 위험분류
  //   riskClsNm,
  //   // 위험요인
  //   riskFactorCd,
  //   // 위험발생 상황 및 결과
  //   riskOcurStatRes,
  //   // 현재의 안전보건 조치
  //   currHlthSftyAction,
  //   // 가능성
  //   riskDcsnPsbltVal,
  //   // 중대성
  //   riskDcsnImprtVal,
  //   // 위험도
  //   riskDcsnRiskVal,
  //   // 위험성 결정
  //   riskDcsnNm,
  //   // 감소대책 수립
  //   rdcmsrNm,
  // } = detailInfo;

  console.log('값2==>', detailInfo);

  const { detailId } = useParams();

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'procNm', headerName: '공정명', flex: 1 },
      { field: 'detailWrkNm', headerName: '세부 작업명', flex: 1 },
      {
        field: 'riskClsCd',
        headerName: '위험분류',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC050',
        },
      },
      { field: 'riskFactorCd', headerName: '위험요인', flex: 1 },
      { field: 'riskOcurStatRes', headerName: '위험발생 상황 및 결과', flex: 1 },
      { field: 'currHlthSftyAction', headerName: '현재의 안전보건 조치', flex: 1 },
      { field: 'riskDcsnPsbltVal', headerName: '가능성', flex: 1 },
      { field: 'riskDcsnImprtVal', headerName: '중대성', flex: 1 },
      { field: 'riskDcsnRiskVal', headerName: '위험도', flex: 1 },
      {
        field: 'riskDcsnCd',
        headerName: '위험성 결정',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC024',
        },
      },
      {
        field: 'rdcmsrCd',
        headerName: '감소대책 수립',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC025',
        },
      },
    ])
  );

  // const customButtons = [
  //   {
  //     title: '추가',
  //     onClick: () => {
  //       alert('추가');
  //     },
  //   },
  // ];

  // const [columns2, setColumns2] = useState(
  //   CommonUtil.mergeColumnInfosByLocal([
  //     { field: 'num', headerName: '번호' },
  //     { field: 'svisitDt', headerName: '순회일자', flex: 1 },
  //     { field: 'svisitProcNm', headerName: '대상공정(작업)', flex: 1 },
  //     { field: 'svisitHzdOpnn', headerName: '유해, 위험요인에 대한 의견', flex: 1 },
  //     //{ field: 'execTeamPosCd', headerName: '삭제', flex: 1 },
  //     // {
  //     //   pinned: 'right',
  //     //   field: 'action',
  //     //   headerName: '삭제',
  //     //   // flex: 1,
  //     //   cellRenderer: 'deleteActionButton',
  //     //   cellRendererParams: {
  //     //     onClick: removeByIndex,
  //     //   },
  //     //},
  //   ])
  // );

  // // 위험성 결정 행 변경
  // const handleRowSingleClick = useCallback((selectedInfo) => {
  //   setColumns((prevColumns) => [...prevColumns]);
  //   procChange(selectedInfo.data);
  // }, []);

  // // 현장 순회 행 변경
  // const handleRowSingleClick2 = useCallback((selectedInfo) => {
  //   // const { rowIndex } = props;

  //   console.log('selectedInfo==>', selectedInfo);

  //   setColumns((prevColumns) => [...prevColumns]);
  //   visitInfo.visitChange(selectedInfo.data, selectedInfo.rowIndex);
  // }, []);

  // const init = async () => {
  //   getDetail(detailId);
  //   search();
  // };

  // useEffect(() => {
  //   init();
  //   return clear;
  // }, []);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  // 첫번째 행 선택
  useEffect(() => {
    if (formValue?.processInfoList && formValue.processInfoList.length > 0 && selectedPlaceIndex === -1) {
      const firstRow = formValue.processInfoList[0];
      handleRowSingleClick({ data: firstRow, rowIndex: 0 });
    }
  }, [formValue, selectedPlaceIndex]);

  const handleRowSingleClick = useCallback(
    (selectedInfo) => {
      setSelectedPlaceIndex(selectedInfo.rowIndex);
    },
    [selectedPlaceIndex]
  );

  // 수정
  const goForm = () => {
    goFormPage(detailId);
  };

  // 가능성 도움말 팝업
  const RiskDcsnPsbltValModalPop = () => {
    openFormModal(null);
  };

  // 중대성 도움말 팝업
  const RiskrDcsnImprtValModalPoP = () => {
    openFormModal2(null);
  };

  // 위험성 도움말 팝업
  const RiskDcsnRiskValModalPop = () => {
    openFormModal3(null);
  };

  return (
    <>
      {/*//탭 */}
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              유해, 위험 요인 파악
              <span className="active"></span>
              <div className="tag-info-wrap">
                <div className="tooltip">
                  <div className="tooltiptext tooltip-right">
                    <h3>작성요령 예시</h3>
                    <ul>
                      <li>공정명(크리닝)</li>
                      <li>세부 작업명(분부세척, part 침전, 건조)</li>
                      <li>위험분류(드롭다운 선택)</li>
                      <li>위험발생 상황(어떤 위험요인에 의해 어떤 재해발생이 우려됨)</li>
                      <li>현재의 안전보건조치(공학적, 관리적, 개인적 대책)</li>
                      <li>위험성 결정(사고발생 가능성 및 예상 피해정도)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">공정명</label>
                              {/* <span className="text-desc-type1">{formValue.procNm}</span> */}
                              <span className="text-desc-type1">{getPlaceColumn('procNm')}</span>
                            </li>
                          </ul>
                        </div>
                        {/* <AppSelect label="공정명" /> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="세부 작업명" /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">세부 작업명</label>
                              <span className="text-desc-type1">{getPlaceColumn('detailWrkNm')}</span>
                              {/* <span className="text-desc-type1">{formValue.detailWrkNm}</span> */}
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">위험분류</label>
                              <span className="text-desc-type1">{getPlaceColumn('riskClsNm')}</span>
                              {/* <span className="text-desc-type1">{formValue.riskClsNm}</span> */}
                            </li>
                          </ul>
                        </div>
                        {/* <AppSelect label="위험분류" /> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">위험요인</label>
                              <span className="text-desc-type1">{getPlaceColumn('riskFactorCd')}</span>
                            </li>
                          </ul>
                        </div>
                        {/* <AppSelect label="위험요인" disabled /> */}
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <textarea
                          id="testArea1"
                          className="form-tag custom_textarea"
                          style={{ width: '100%' }}
                          name="testArea1"
                          value={getPlaceColumn('riskOcurStatRes')}
                          // onChange={(event) => {
                          //   setInputValue(event.target.value);
                          // }}
                        />
                        <label className="f-label" htmlFor="testArea1">
                          위험발생 상황 및 결과
                        </label>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <textarea
                          id="testArea1"
                          className="form-tag custom_textarea"
                          style={{ width: '100%' }}
                          name="testArea1"
                          // <span className="text-desc-type1">{getPlaceColumn('riskFactorCd')}</span>

                          value={getPlaceColumn('riskFactorCd')}
                          // onChange={(event) => {
                          //   setInputValue(event.target.value);
                          // }}
                        />
                        <label className="f-label" htmlFor="testArea1">
                          현재의 안전보건 조치
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              위험성 결정
              <span className="active"></span>
              {/*가능성, 중대성, 위험도 - 팝업 */}
              <div className="tag-info-wrap-end">
                <div className="tip" onClick={RiskDcsnPsbltValModalPop}>
                  <div>
                    <a href="javascript:void(0);" className="txt" onClick={RiskDcsnPsbltValModalPop}>
                      가능성
                    </a>
                  </div>
                </div>
                <div className="tip" onClick={RiskrDcsnImprtValModalPoP}>
                  <div>
                    <a href="javascript:void(0);" className="txt" onClick={RiskrDcsnImprtValModalPoP}>
                      중대성
                    </a>
                  </div>
                </div>
                <div className="tip" onClick={RiskDcsnRiskValModalPop}>
                  <div>
                    <a href="javascript:void(0);" className="txt" onClick={RiskDcsnRiskValModalPop}>
                      위험도
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">가능성</label>
                              {/* <span className="text-desc-type1">{formValue.riskDcsnPsbltVal} */}

                              <span className="text-desc-type1">{getPlaceColumn('riskDcsnPsbltVal')}</span>
                            </li>
                          </ul>
                        </div>
                        {/* <AppTextInput inputType="text" placeholder="" label="가능성" /> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">중대성</label>
                              {/* {getPlaceColumn('riskDcsnImprtVal')} */}
                              <span className="text-desc-type1"> {getPlaceColumn('riskDcsnImprtVal')}</span>
                            </li>
                          </ul>
                        </div>
                        {/* <AppSelect label="중대성" /> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">위험도</label>
                              {/* {getPlaceColumn('riskDcsnRiskVal')} */}
                              <span className="text-desc-type1"> {getPlaceColumn('riskDcsnRiskVal')}</span>
                            </li>
                          </ul>
                        </div>
                        {/* <AppSelect label="위험도" disabled /> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">위험성 결정</label>
                              {/* {getPlaceColumn('riskDcsnNm')} */}
                              <span className="text-desc-type1">{getPlaceColumn('riskDcsnNm')}</span>
                            </li>
                          </ul>
                        </div>
                        {/* <AppSelect label="위험성 결정" /> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">감소대책 수립</label>
                              {/* {getPlaceColumn('rdcmsrNm')} */}
                              <span className="text-desc-type1"> {getPlaceColumn('rdcmsrNm')}</span>
                            </li>
                          </ul>
                        </div>
                        {/* <AppSelect label="감소대책 수립" /> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      {/* 가능성 */}
      <RiskDcsnPsbltValModal isOpen={isCodeFormModalOpen} closeModal={closeFormModal} />
      {/* 중대성 */}
      <RiskrDcsnImprtValModal isOpen={isCodeFormModalOpen2} closeModal={closeFormModal2} />
      {/* 위험도 */}
      <RiskDcsnRiskValModal isOpen={isCodeFormModalOpen3} closeModal={closeFormModal3} />

      {/*//입력영역*/}

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        {/* <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
          저장
        </button> */}
        {/*//하단버튼영역*/}
        {/*그리드영역 */}
        <div>
          <AppTable
            rowData={formValue.processInfoList || []}
            columns={columns}
            setColumns={setColumns}
            // customButtons={customButtons}
            handleRowSingleClick={handleRowSingleClick}
            hiddenPagination
          />
        </div>

        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goForm}
          // style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          수정
        </button>
        {/* <button type="button" name="button" className="btn_text btn-del">
          삭제
        </button> */}
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
      </div>
    </>
  );
}
export default RevalDetailTab3;
