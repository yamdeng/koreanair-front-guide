import { useEffect } from 'react';
//import AppDatePicker from '@/components/common/AppDatePicker';
//import AppSelect from '@/components/common/AppSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppSearchInput from '@/components/common/AppSearchInput';
import CommonUtil from '@/utils/CommonUtil';
import { useRef, useState } from 'react';

import AppAutoComplete from '@/components/common/AppAutoComplete';
import { Tree } from 'antd';

/* TODO : store 경로를 변경해주세요. */
import useOcuOrganizationFormStore from '@/stores/occupation/general/useOcuOrganizationFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuOrganizationForm() {
  /* formStore state input 변수 */
  const {
    // errors,
    // changeInput,
    // getDetail,
    // formType,
    // formValue,
    // save,
    // remove,
    // cancel,
    // clear,
    // menuTreeData,
    // handleTreeSelect,
    // init,
    //    parentMenuTreeData,
    selectedUserInfo,
    formValue,
    // errors,
    // changeInput,
    // formType,
    menuTreeData,
    //parentMenuTreeData,
    handleTreeSelect,
    init,
    //changeTreeWorkScope,
    //changeWorkScope,
    //handleParentTreeSelect,
    // save,
    // remove,
    // addMenu,
    clear,
    searchParam,
    getParentMenuTree,
    changeSearchInput,
    userList,
    dutyList,
    changeStateProps,

    onSelect,
    onExpand,
    searchInputValue,
    findKey,
    changeSearchValue,
    handleSearchInputEnterKey,
    selectedKeys,
    expandedKeys,
    getTreeData,
    setTreeRef,
    treeData,
  } = useOcuOrganizationFormStore();

  const { userNm } = searchParam;

  const treeDomRef: any = useRef();

  useEffect(() => {
    // getTreeData();
    setTreeRef(treeDomRef);
    init(treeDomRef);
    return clear;
  }, []);

  // 부모 컴포넌트에서 handleRowClick 함수 정의
  const userRowClick = (product) => {
    changeStateProps('selectedUserInfo', product);
  };

  // console.log(`selectedUserInfo : ${selectedUserInfo ? JSON.stringify(selectedUserInfo) : ''}`);

  console.log('treeData##===>', treeData);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      <div className="conts-title">
        <h2>산업안전보건 조직도</h2>
      </div>
      <div className="searchbox">
        <div className="left-box">
          <div className="tree-box">
            <div className="form-group wid100 mb-20">
              <AppSearchInput
                label="검색"
                value={searchInputValue}
                onChange={(value) => changeSearchValue(value)}
                search={handleSearchInputEnterKey}
              />
            </div>
            <div className="tree-list" style={{ height: 500 }}>
              <div className="tree">
                <Tree
                  onSelect={handleTreeSelect}
                  height={500}
                  ref={treeDomRef}
                  checkStrictly
                  treeData={treeData}
                  fieldNames={{ title: 'nameKor', key: 'menuId' }}
                  selectedKeys={selectedKeys}
                  expandedKeys={expandedKeys}
                  // onSelect={onSelect}
                  onExpand={onExpand}
                  titleRender={(nodeData) => {
                    const { nameKor, menuId }: any = nodeData;
                    let className = '';
                    if (findKey && menuId === findKey) {
                      className = className + ' current-find';
                    }
                    return (
                      <span
                        className={className}
                        dangerouslySetInnerHTML={{
                          __html: CommonUtil.replaceHighlightMarkup(nameKor, searchInputValue),
                        }}
                      ></span>
                    );
                  }}
                  // className="draggable-tree bg"
                  // defaultExpandedKeys={expandedKeys}
                  // draggable
                  // blockNode
                  // treeData={treeData}
                />
              </div>
              {/*조직도 .active시 리스트표출*/}
              <div className="list active">
                <table className="list-table">
                  <thead>
                    <tr>
                      <th>안전보건인력</th>
                      <th>인원</th>
                    </tr>
                  </thead>
                  {dutyList &&
                    dutyList.map((dutyData) =>
                      dutyData.dutyCd !== null ? (
                        <>
                          <tbody>
                            {/* <tr onClick={() => userRowClick(dutyData)}> */}
                            <tr>
                              {/* <h3>임직원 리스트</h3> */}
                              <td>{dutyData.dutyCd}</td>
                              <td>{dutyData.cnt}명</td>
                            </tr>
                          </tbody>
                        </>
                      ) : (
                        <>
                          <tfoot>
                            <tr>
                              <td>총원</td>
                              <td>{dutyData.cnt}명</td>
                            </tr>
                          </tfoot>
                        </>
                      )
                    )}
                  {/* <tbody>
                    <tr>
                      <td>안전보건관리 책임자</td>
                      <td>17명</td>
                    </tr>
                    <tr>
                      <td>안전보건총괄 책임자</td>
                      <td>49명</td>
                    </tr>
                    <tr>
                      <td>안전/보건 관리자</td>
                      <td>29명</td>
                    </tr>
                    <tr>
                      <td>안전담당</td>
                      <td>552명</td>
                    </tr>
                    <tr>
                      <td>관리감독자</td>
                      <td>20명</td>
                    </tr>
                  </tbody> */}
                  {/* <tfoot>
                    <tr>
                      <td>총원</td>
                      <td>684명</td>
                    </tr>
                  </tfoot> */}
                </table>
              </div>
            </div>
          </div>
        </div>
        <div className="right-box">
          {/*검색영역 */}

          <div className="boxForm">
            <div className="form-table">
              <div className="form-cell wid-300">
                <div className="form-group wid100">
                  <AppSearchInput
                    label={'성명'}
                    value={userNm}
                    search={getParentMenuTree}
                    onChange={(value) => {
                      changeSearchInput('userNm', value);
                    }}
                  />
                </div>
              </div>
              <div className="btn-area">
                <button
                  type="button"
                  name="button"
                  className="btn-sm btn_text btn-darkblue-line"
                  onClick={getParentMenuTree}
                >
                  조회
                </button>
              </div>
            </div>
          </div>
          {/* //검색영역 */}

          {/*그리드영역 */}
          <div className="searchlist">
            <div className="list">
              <h3>임직원 리스트</h3>
              <div>
                <table className="list-table">
                  <thead>
                    <tr>
                      <th>번호</th>
                      <th>본부</th>
                      <th>부서</th>
                      <th>팀</th>
                      <th>그룹</th>
                      <th>반</th>
                      <th>직책</th>
                      <th>사번</th>
                      <th>성명</th>
                      <th>발령일자</th>
                    </tr>
                  </thead>
                  <tbody>
                    {userList &&
                      userList.map((product) => (
                        <>
                          <tr onClick={() => userRowClick(product)}>
                            {/* <h3>임직원 리스트</h3> */}
                            <td style={{ backgroundColor: '#f0f0f0' }}>{product.num}</td>
                            <td>{product.sectNm ? product.sectNm : '-'}</td>
                            <td>{product.deptNm ? product.deptNm : '-'}</td>
                            <td>{product.teamNm ? product.teamNm : '-'}</td>
                            <td>{product.groupNm ? product.groupNm : '-'}</td>
                            <td>{product.classNm ? product.classNm : '-'}</td>
                            <td>{product.dutyCd ? product.dutyCd : '-'}</td>
                            <td>{product.empNo}</td>
                            <td>{product.nameKor}</td>
                            <td>{product.nameKor}</td>
                            {/* <td>{product.deptCd}</td> */}
                          </tr>
                        </>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="list-dtail">
              <h3>임직원 상세정보</h3>
              <div className="list-table">
                {/*상세*/}
                <div className="editbox">
                  <div className="form-table line">
                    <div className="form-cell pd-style01 wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">본부</label>
                              <span className="text-desc-type1">
                                {selectedUserInfo.sectNm ? selectedUserInfo.sectNm : '-'}
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell pd-style01 wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">부서</label>
                              {/* <span className="text-desc-type1">{selectedUserInfo.userDeptNm}</span> */}
                              <span className="text-desc-type1">
                                {selectedUserInfo.deptNmKor ? selectedUserInfo.deptNmKor : '-'}
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell pd-style01 wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">팀</label>
                              {/* <span className="text-desc-type1">{selectedUserInfo.userTeamNm}</span> */}
                              <span className="text-desc-type1">
                                {selectedUserInfo.teamNm ? selectedUserInfo.teamNm : '-'}
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell pd-style01 wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">그룹</label>
                              {/* <span className="text-desc-type1">{selectedUserInfo.userGroupNm}</span> */}
                              <span className="text-desc-type1">
                                {selectedUserInfo.groupNm ? selectedUserInfo.groupNm : '-'}
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell pd-style01 wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">반</label>
                              {/* <span className="text-desc-type1">{selectedUserInfo.userClassNm}</span> */}
                              <span className="text-desc-type1">
                                {selectedUserInfo.classNm ? selectedUserInfo.classNm : '-'}
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell pd-style01 wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">직책</label>
                              {/* <span className="text-desc-type1">{selectedUserInfo.userDutyCd}</span> */}
                              <span className="text-desc-type1">
                                {selectedUserInfo.dutyNm ? selectedUserInfo.dutyNm : '-'}
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  <div className="form-table line">
                    <div className="form-cell pd-style01 wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">사번</label>
                              <span className="text-desc-type1">{selectedUserInfo.empNo}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell pd-style01 wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">성명</label>
                              <span className="text-desc-type1">{selectedUserInfo.nameKor}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell pd-style01 wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">발령일자</label>
                              <span className="text-desc-type1">발령일자내용</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                </div>
                <table className="list-table">
                  <thead>
                    <tr>
                      <th className="border-no"></th>
                      <th>일자</th>
                      <th>임명/임면</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th rowSpan={2}>변동내역</th>
                      <td>2024.08.29</td>
                      <td>임명</td>
                    </tr>
                    <tr>
                      <td>2024.08.29</td>
                      <td>임면</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          {/*//그리드영역 */}
        </div>
      </div>
    </>
  );
}
export default OcuOrganizationForm;
