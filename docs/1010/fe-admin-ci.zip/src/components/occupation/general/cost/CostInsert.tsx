import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppDeptListSelectInput from '@/components/common/AppDeptListSelectInput';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import CommonUtil from '@/utils/CommonUtil';

/* TODO : store 경로를 변경해주세요. */
import useOcuCostFormStore from '@/stores/occupation/general/useOcuCostFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCostExecForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    useOcuCostFormStore();

  const {
    periodNm,
    planYear,
    sectCd,
    glDt,
    currencyCd,
    respCenter,
    acntCd,
    itemCd,
    payTerm,
    planAmt,
    totAmt,
    acntNm,
    drAmt,
    crAmt,
    lineDesc,
    invoiceNo,
    vendorNm,
    execClsCd,
    regDttm,
    regUserId,
  } = formValue;

  // const { detailId } = useParams();

  const profile = useStore(useAppStore, (state) => state.profile);
  // 사용자명
  const nameKor = profile.userInfo.nameKor;

  // 오늘 날짜
  const toDate = CommonUtil.getToDate();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    // if (detailId && detailId !== 'add') {
    //   getDetail(detailId);
    // }
    return clear;
  }, []);

  // Amount 변경시 Total Amount 계산
  const changePlanAmt = (gubun, v) => {
    console.log('이곳');

    // Amount, payTerm
    if (!v || !formValue.payTerm) {
      // Total Amount
      formValue.totAmt = 0;
    } else {
      // Total Amount
      if (formValue.payTerm == 'A') {
        formValue.totAmt = v;
      } else if (formValue.payTerm == 'B') {
        formValue.totAmt = Math.floor(v * 2);
      } else if (formValue.payTerm == 'C') {
        formValue.totAmt = Math.floor(v * 4);
      } else if (formValue.payTerm == 'D') {
        formValue.totAmt = Math.floor(v * 12);
      }
    }

    changeInput(gubun, v);

    //formValue.totAmt = '12';
  };

  // payTerm 변경시 Total Amount 계산
  const changePayTerm = (gubun, v) => {
    // Amount, payTerm
    if (!v || !formValue.planAmt) {
      // Total Amount
      formValue.totAmt = 0;
    } else {
      // Total Amount
      if (v == 'A') {
        formValue.totAmt = formValue.planAmt;
      } else if (v == 'B') {
        formValue.totAmt = Math.floor(formValue.planAmt * 2);
      } else if (v == 'C') {
        formValue.totAmt = Math.floor(formValue.planAmt * 4);
      } else if (v == 'D') {
        formValue.totAmt = Math.floor(formValue.planAmt * 12);
      }
    }

    changeInput(gubun, v);
  };

  // Cost Center 변경시 부문 변경
  const changeRespCenter = (gubun, v, deptInfo) => {
    // 부문
    if (formValue.sectCd != null) {
      formValue.sectCd = deptInfo.sectCd;
    }
    changeInput(gubun, v);
  };

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>산업안전보건관리비</h2>
      </div>
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              계획<span className="hide"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label={'년도'}
                          pickerType="year"
                          value={planYear}
                          onChange={(value) => {
                            changeInput('planYear', value);
                          }}
                          required
                          errorMessage={errors.planYear}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="부문"
                          codeGrpId="CODE_GRP_OC001"
                          value={sectCd}
                          onChange={(value) => {
                            changeInput('sectCd', value);
                          }}
                          disabled
                          required
                          errorMessage={errors.sectCd}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDeptListSelectInput
                          label="Resp Center"
                          value={respCenter}
                          gudun=""
                          level="3"
                          dept=""
                          division=""
                          //console.log("값");
                          onChange={(value, selectedDeptInfo) => {
                            //changeInput('costCenter', value);
                            changeRespCenter('respCenter', value, selectedDeptInfo);
                          }}
                          required
                          errorMessage={errors.respCenter}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="item"
                          codeGrpId="CODE_GRP_OC017"
                          value={itemCd}
                          onChange={(value) => {
                            changeInput('itemCd', value);
                          }}
                          required
                          errorMessage={errors.itemCd}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="Account Name"
                          codeGrpId="CODE_GRP_OC045"
                          value={acntCd}
                          onChange={(value) => {
                            changeInput('acntCd', value);
                          }}
                          required
                          errorMessage={errors.acntCd}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="Account"
                          value={acntCd}
                          onChange={(value) => {
                            changeInput('acntCd', value);
                          }}
                          required
                          disabled
                          errorMessage={errors.acntCd}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="Payterm"
                          codeGrpId="CODE_GRP_OC018"
                          value={payTerm}
                          onChange={(value) => {
                            //changeInput('payTerm', value);
                            changePayTerm('payTerm', value);
                          }}
                          required
                          errorMessage={errors.payTerm}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="Amount"
                          inputType="number"
                          value={planAmt}
                          onChange={(value) => {
                            changePlanAmt('planAmt', value);
                            //changeInput('planAmt', value);
                          }}
                          // required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="Total Amount"
                          value={totAmt}
                          onChange={(value) => {
                            changeInput('totAmt', value);
                          }}
                          disabled
                          // required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="Description"
                          value={lineDesc}
                          onChange={(value) => {
                            changeInput('lineDesc', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="등록자"
                          value={nameKor}
                          onChange={(value) => {
                            changeInput('nameKor', value);
                          }}
                          disabled
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label="등록일자"
                          value={toDate}
                          onChange={(value) => {
                            changeInput('toDate', value);
                          }}
                          disabled
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/*//입력영역*/}
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuCostExecForm;
