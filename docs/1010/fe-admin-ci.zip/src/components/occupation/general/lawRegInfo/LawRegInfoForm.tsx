import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import OrgTreeSelectModal from '@/components/modal/OrgTreeSelectModal';
//import AppDatePicker from '@/components/common/AppDatePicker';
import AppEditor from '@/components/common/AppEditor';
//import AppSelect from '@/components/common/AppSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import { Upload } from 'antd';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppSelect from '@/components/common/AppSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppUserSelectInput from '@/components/common/AppUserSelectInput';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';

/* TODO : store 경로를 변경해주세요. */
import useOcuLawRegInfoFormStore from '@/stores/occupation/general/useOcuLawRegInfoFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCommitteeForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, save, remove, cancel, clear, approval, isDirty } =
    useOcuLawRegInfoFormStore();

  const {
    // 법규명
    lawNm,
    // 법령일련번호
    lawSeq,
    // 법령종류
    lawKind,
    // 공포일자
    fearDt,
    // 시행일자
    implDt,
    // 제개정 종류
    lgsltKind,
    // 소관부처
    respMinistryNm,
    // 법령상세링크
    lawDtlLink,
    // 주관부서
    subjectDeptCd,
    // 주관부서명
    subjectDeptNm,
    // 개정 내용
    revisionCn,
    // 영향도 평가
    inflDegreeEval,
    // Keyword
    keyWordContent,
    // 평가자
    evalId,
    // 승인자
    aprvId,
    // 승인 상태
    aprvStat,
    // 해당부서
    rlvtDeptCd,
  } = formValue;

  const { detailId } = useParams();

  const profile = useStore(useAppStore, (state) => state.profile);

  console.log('profile===>', profile);

  // 현재 접속자 ID
  const userId = profile.userInfo.userId;
  // 현재 사용자명
  const nameKor = profile.userInfo.nameKor;
  // 현재 사용자 부서
  const deptCd = profile.userInfo.deptCd;

  // 입력 및 복사인 경우
  if (detailId === 'add') {
    // 현재 접속자 ID
    formValue.evalId = userId;
  }
  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }

    return clear;
  }, []);

  // 법 api url이동
  const lawOpenApiUrlGo = () => {
    const lawUrl = 'https://www.law.go.kr' + lawDtlLink;
    window.open(lawUrl, '_blank');
  };

  const [isOrgSelectModalopen, setIsOrgSelectModalopen] = useState(false);
  const handleOrgSelectModal = (selectedValue) => {
    console.log(selectedValue);
    setIsOrgSelectModalopen(false);
  };

  useFormDirtyCheck(isDirty);

  // // 부서 추가
  // const addDept = () => {
  //   console.log('부서추가');
  //   setIsOrgSelectModalopen(true);
  // };

  return (
    <>
      <div className="conts-title">
        <h2>법규등록대장</h2>
      </div>
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              기준정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="법규명"
                          value={lawNm}
                          onChange={(value) => changeInput('lawNm', value)}
                          required
                          disabled
                          errorMessage={errors.lawNm}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="법령 일련번호"
                          value={lawSeq}
                          onChange={(value) => changeInput('lawSeq', value)}
                          required
                          disabled
                          errorMessage={errors.lawSeq}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="법령종류"
                          value={lawKind}
                          onChange={(value) => changeInput('lawKind', value)}
                          required
                          disabled
                          errorMessage={errors.lawKind}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="공포일자(개정)"
                          value={fearDt}
                          onChange={(value) => changeInput('fearDt', value)}
                          required
                          disabled
                          errorMessage={errors.fearDt}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="시행일자"
                          value={implDt}
                          onChange={(value) => changeInput('implDt', value)}
                          required
                          disabled
                          errorMessage={errors.implDt}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="제개정종류"
                          value={lgsltKind}
                          onChange={(value) => changeInput('lgsltKind', value)}
                          required
                          disabled
                          errorMessage={errors.lgsltKind}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="소관부처"
                          value={respMinistryNm}
                          onChange={(value) => changeInput('respMinistryNm', value)}
                          required
                          disabled
                          errorMessage={errors.respMinistryNm}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap line wid100">
                        <div className="form-group wid100">
                          <AppTextInput
                            label="법령 상세 링크"
                            value={lawDtlLink}
                            onChange={(value) => changeInput('lawDtlLink', value)}
                            required
                            disabled
                            errorMessage={errors.lawDtlLink}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="주관 부서"
                          value={subjectDeptNm}
                          onChange={(value) => changeInput('subjectDeptNm', value)}
                          required
                          disabled
                          errorMessage={errors.subjectDeptNm}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="btn-area">
                        <button
                          type="button"
                          name="button"
                          className="btn-sm btn_text btn-darkblue-line"
                          onClick={lawOpenApiUrlGo}
                        >
                          법령 보기
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              영향도 평가<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="개정 내용"
                          value={revisionCn}
                          onChange={(value) => changeInput('revisionCn', value)}
                          // aprvStat !== 'B'
                          required
                          disabled={aprvStat === 'B' ? true : false}
                          errorMessage={errors.revisionCn}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="영향도 평가"
                          value={inflDegreeEval}
                          onChange={(value) => changeInput('inflDegreeEval', value)}
                          required
                          disabled={aprvStat === 'B' ? true : false}
                          errorMessage={errors.titinflDegreeEvalle}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="Keyword"
                          value={keyWordContent}
                          onChange={(value) => changeInput('keyWordContent', value)}
                          required
                          disabled={aprvStat === 'B' ? true : false}
                          errorMessage={errors.keyWordContent}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppUserSelectInput
                          label="평가자"
                          // 접속자 ID 들어가야함
                          // value={assessor}
                          value={evalId}
                          onChange={(value) => changeInput('evalId', value)}
                          required
                          disabled
                          errorMessage={errors.evalId}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppAutoComplete label="승인자" /> */}
                        <AppUserSelectInput
                          label="승인자"
                          value={aprvId}
                          onChange={(value) => changeInput('aprvId', value)}
                          required
                          disabled
                          errorMessage={errors.aprvId}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              해당 부서<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">그리드영역</div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        {/* <button className="btn_text text_color_neutral-10 btn_confirm" onClick={addDept}>
          추가
        </button> */}

        <button
          className="btn_text text_color_neutral-10 btn_confirm"
          // 접속자가 승인자인경우 and 결재 대기인 경우
          style={{ display: aprvId === profile.userInfo.userId && aprvStat === 'A' ? '' : 'none' }}
          onClick={approval}
        >
          승인
        </button>

        <button
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={save}
          // 접속자가 평가자 부서인 (처리해야함) 경우 and 승인 상태가 아닌 경우
          // style={{ display: subjectDeptCd === profile.userInfo.deptCd && aprvStat !== 'B' ? '' : 'none' }}
        >
          저장
        </button>
        {/* <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button> */}
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>

      <OrgTreeSelectModal
        isOpen={isOrgSelectModalopen}
        closeModal={() => setIsOrgSelectModalopen(false)}
        isMultiple={true}
        ok={handleOrgSelectModal}
      />
    </>
  );
}
export default OcuCommitteeForm;
