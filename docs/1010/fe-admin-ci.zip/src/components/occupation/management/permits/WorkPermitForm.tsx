import { useEffect, useState } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import OcuWorkPermitFormStore from '@/stores/occupation/management/useOcuWorkPermitFormStore';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptReadOnlyInput from '@/components/common/AppDeptReadOnlyInput';
import useAppStore from '@/stores/useAppStore';
import { useStore } from 'zustand';
import CommonUtil from '@/utils/CommonUtil';
import AppCheckboxGroup from '@/components/common/AppCheckboxGroup';
import CodeService from '@/services/CodeService';
import WorkPermitEduChoiceModal from './WorkPermitEduChoiceModal';
import WorkPermitDevice from './WorkPermitDeviceChecklist';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppSelect from '@/components/common/AppSelect';

/**NEED TO CHECK : && NEED TO ADD
 * 1. Eqpm Check List
 *    1) 작업구분 선택 - 하위구분 선택 - 작업구분 선택해제 --> 하위구분 선택 해제 되어야함
 *    2) when user saved temporary or
 *    3) when it
 * 2. every required needs to fill in even clicked the temp saved
 */

function WorkPermitForm() {
  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    save,
    remove,
    cancel,
    clear,
    isEduChoiceModalOpen,
    // 특별교육 모달 선택 결과 리스트
    eduChoiceList,
    saveEduChoiceModal,
    // 작업구분 반입장비 선택 리스트
    equipmentList,
    openEduChoiceModal,
    closeEduChoiceModal,
    saveWorkPermit, // 저장
    submitWorkPermit, // 제출
    validLocationList,
    detailInfo,
    setFormValue,
    getEquipmentList,
  } = OcuWorkPermitFormStore();

  /**로그인한 사용자 정보 설정하기 */
  const profile = useStore(useAppStore, (state) => state.profile);
  // console.log('userInfo : ', profile.userInfo);

  // 부서코드
  const userDeptCd = profile.userInfo.deptCd;
  // 신청자명
  const userNm = profile.userInfo.nameKor;
  // console.log('userNm : ', userNm);
  // 연락처(officeTelNo)
  const userOfficeTelNo = profile.userInfo.officeTelNo;
  // console.log('연락처 : ', userOfficeTelNo);

  const {
    // 부문 코드
    sectCd,
    // 부서코드
    deptCd,
    // 공사 ID
    cntrId,
    // 공사 명
    cntrNm,
    // 공사분야코드
    cntrAreaCd,
    // 특별교육 대상 여부 - 03
    spclEduTargetYn,
    // 시공사
    cnstCmpny,
    // 담당자
    staff,
    // 연락처
    contactNo,
    // 공사장소 ID
    cnstrSiteId,
    cnstrLocationNm,
    // 공사위치명
    cntrPositionNm,
    // 공사인원수
    cntrPrsnCnt,
    // 공사신청시작일시
    cntrApplyStartDttm,
    // 공사 신청 종료 일시
    cntrApplyEndDttm,
    reportFileId,
    etcReportFileId,
    // 사전동의여부
    preConsentYn,

    // 등록 일시
    regDttm,
    // 등록자 ID
    regUserId,
    // 수정 일시
    updDttm,
    // 수정자 ID
    updUserId,
    cntrWrkCd,
  } = formValue;

  const { detailId } = useParams();
  // console.log('detailId : ', detailId);
  // console.log('regUserId : ', regUserId);
  // console.log('isEduChoiceModalOpen : ', isEduChoiceModalOpen);
  // console.log('detailInfo : ', detailInfo);
  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  useEffect(() => {
    console.log('spclEduTargetYn changed:', formValue.spclEduTargetYn);
  }, [formValue.spclEduTargetYn]);

  // 오늘날짜 가져오기
  const currentDate = CommonUtil.getToDate();
  console.log('currentDate : ' + currentDate);

  const handleModalSubmit = (eduModalData) => {
    console.log('Received data from modal:', eduModalData);
    saveEduChoiceModal(eduModalData);
  };

  useEffect(() => {
    console.log('Valid Locations:', validLocationList);
  }, [validLocationList]);

  const updateEquipmentList = (newEquipmentList) => {
    setFormValue((prev) => ({
      ...prev,
      equipmentList: newEquipmentList,
    }));
  };

  useEffect(() => {
    console.log('equipmentList in workPermitForm :', formValue.equipmentList);
  }, [formValue.equipmentList]);

  useEffect(() => {
    console.log('formValue in workPermitForm : ', formValue);
  }, [formValue]);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>외주작업허가 등록</h2>
      </div>
      {/* <div className="editbox"> */}
      <div className="info-wrap toggle">
        {/* 신청자정보 */}
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              신청자 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="부문"
                          codeGrpId="CODE_GRP_OC001"
                          value={sectCd} // NEED TO CHANGE LATER
                          onChange={(value) => changeInput('sectCd', value)}
                          required
                          disabled={formType !== 'add' ? true : false}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDeptReadOnlyInput
                          label="부서"
                          value={detailId === 'add' ? userDeptCd : deptCd}
                          required
                          disabled
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="이름"
                          value={detailId === 'add' ? userNm : regUserId}
                          required
                          disabled="false"
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput label="연락처" value={userOfficeTelNo} disabled required />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          {/* 공사정보 */}
          <dt>
            <button type="button" className="btn-tg">
              공사 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="공사명"
                          value={cntrNm}
                          onChange={(value) => changeInput('cntrNm', value)}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppCheckboxGroup
                          label="공사분야"
                          options={CodeService.getCodeListByCodeGrpId('CODE_GRP_OC030')}
                          value={cntrAreaCd}
                          labelKey={'codeNameKor'}
                          valueKey={'codeId'}
                          onChange={(value) => {
                            console.log('너의정체는array가맞느냐 : ', Array.isArray(value)); // true
                            console.log('value : ', value);
                            // const selectedValues = value.map((option) => option.value);
                            // const stringConverted = selectedValues.join(', ');
                            // changeInput('cntrAreaCd', stringConverted);
                            changeInput('cntrAreaCd', value);
                          }}
                        />
                        <span className="txt">공사분야</span>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <span className="txt">특별교육 대상</span>
                        <div className="radio-wrap">
                          <label>
                            <input
                              type="radio"
                              name="spclEduTarget"
                              value="Y"
                              onClick={() => openEduChoiceModal()}
                              checked={spclEduTargetYn === 'Y'}
                              onChange={() => {
                                changeInput('spclEduTargetYn', 'Y');
                              }}
                            />
                            <span>예</span>
                          </label>
                          <button className="radio-btn" onClick={() => openEduChoiceModal()}>
                            교육내용
                          </button>
                          <WorkPermitEduChoiceModal
                            isOpen={isEduChoiceModalOpen}
                            isClose={closeEduChoiceModal}
                            onSubmit={handleModalSubmit}
                            spclEduTargetYn={spclEduTargetYn}
                          />
                          <label>
                            <input
                              type="radio"
                              name="spclEduTarget"
                              checked={spclEduTargetYn === 'N'}
                              onChange={() => {
                                changeInput('spclEduTargetYn', 'N');
                              }}
                            />
                            <span>아니오</span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="시공사"
                          value={cnstCmpny}
                          // placeholder="시공사"
                          onChange={(value) => changeInput('cnstCmpny', value)}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="담당자"
                          value={staff}
                          onChange={(value) => changeInput('staff', value)}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="연락처"
                          value={contactNo}
                          onChange={(value) => changeInput('contactNo', value)}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSelect
                          label="공사장명"
                          value={cnstrLocationNm}
                          placeholder="공사장명"
                          apiUrl="ocu/management/permits/locationNames"
                          options={validLocationList}
                          labelKey={'cntrLocationNm'}
                          valueKey={'cnstrSiteId'}
                          onChange={(value) => {
                            console.log('selected cnstrSiteId is :', value);
                            changeInput('cnstrSiteId', value);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="공사위치"
                          value={cntrPositionNm}
                          placeholder="공사위치명"
                          onChange={(value) => changeInput('cntrPositionNm', value)}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="공사인원"
                          value={cntrPrsnCnt}
                          onChange={(value) => changeInput('cntrPrsnCnt', value)}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label="공사 시작일시"
                          showTime
                          excludeSecondsTime
                          onChange={(value) => changeInput('cntrApplyStartDttm', value)}
                          value={cntrApplyStartDttm}
                          showNow={true}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label="공사 종료일시"
                          showTime
                          excludeSecondsTime
                          onChange={(value) => changeInput('cntrApplyEndDttm', value)}
                          value={cntrApplyEndDttm}
                          showNow={true}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  {/* THE END OF 공사정보 */}
                  {/* 파일첨부영역 : button */}
                  <h3 className="table-tit mt-10">첨부서류</h3>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppFileAttach
                          mode="edit"
                          label="작업계획서 및 위험성평가서"
                          fileGroupSeq={reportFileId}
                          workScope={'O'}
                          updateFileGroupSeq={(newFileGroupSeq) => {
                            changeInput('reportFileId', newFileGroupSeq);
                          }}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppFileAttach
                          mode="edit"
                          label="기타"
                          fileGroupSeq={etcReportFileId}
                          workScope={'O'}
                          updateFileGroupSeq={(newFileGroupSeq) => {
                            changeInput('etcReportFileId', newFileGroupSeq);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  {/* the end of file attachment */}
                  {/* 작업구분 그리드 시작 */}
                  <WorkPermitDevice />
                  <button type="button" onClick={getEquipmentList}>
                    확인용
                  </button>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              사전동의<span className="active"></span>
            </button>
          </dt>
        </dl>
      </div>
      <dd className="tg-conts">
        <div className="edit-area">
          <div className="detail-form">
            <div className="detail-list">
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <ul className="agree">
                      <li>1. 8시간 이상 진행되는 작업의 경우 작업 종료 후 재시작 시 현장 안전점검 실시</li>
                      <li>2. 현장점검 시 작업에 해당되는 점검표를 활용하여 점검 실시</li>
                      <li>3. 기계⋅전기⋅가스 등의 정지⋅차단 조치가 필요한 경우 Lock-Out, Tag-Out 실시</li>
                      <li>
                        4. 작업종료 후 외주업체 안전교육일지 및 작업 후 조치현황을 작업종료 후 2일 이내 승인부서에 통보
                        할 것
                      </li>
                      <li>5. 현장에서 안전조치 미흡/위반 사례 적발 시 즉시 작업중지 조치 예정</li>
                    </ul>
                    <div className="radio-wrap border-no pd-style">
                      <label>
                        <input
                          type="checkbox"
                          name="preConsentYn"
                          value="Y"
                          checked={preConsentYn === 'Y'}
                          onChange={() => {
                            changeInput('preConsentYn', preConsentYn === 'Y' ? 'N' : 'Y');
                          }}
                        />

                        <span>위 사항에 대해 충분히 이해하고 입력한 정보로 작업허가를 신청합니다.</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </dd>

      <hr className="line"></hr>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text btn-del" onClick={cancel}>
          취소
        </button>
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_conblue"
          onClick={saveWorkPermit}
        >
          저장
        </button>
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={submitWorkPermit}
        >
          제출
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
      </div>
    </>
  );
}
export default WorkPermitForm;
