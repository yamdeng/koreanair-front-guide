import AppFileAttach from '@/components/common/AppFileAttach';
import ToastService from '@/services/ToastService';
import useOcuWorkPermitEduChoiceModalStore from '@/stores/occupation/management/useOcuWorkPermitEduChoiceModalStore';
import ReactUtil from '@/utils/ReactUtil';
import { useEffect } from 'react';
import Modal from 'react-modal';

function WorkPermitEduChoiceModal(props) {
  const { isOpen, isClose, onSubmit, spclEduTargetYn } = props;

  const state = useOcuWorkPermitEduChoiceModalStore();
  const { changeInput, formValue, setSpclEduTargetYn, clear } = state;

  const { eduChoiceList } = formValue;

  useEffect(() => {
    if (isOpen) {
      console.log('Modal is opened.');
      console.log('Received spclEduTargetYn:', spclEduTargetYn);
    }
  }, [isOpen]);

  useEffect(() => {
    console.log(eduChoiceList);
  });

  const handleClose = () => {
    // ToastService.warn('교육 내용이 첨부되지 않았습니다. 창을 닫으시겠습니까?');
    alert('교육 내용이 첨부되지 않았습니다. 창을 닫으시겠습니까?');
    ToastService.warn('특별교육 내용 입력이 취소되었습니다. 다시 확인하세요.');
    // 닫을 때 선택 정보 초기화
    clear();
    console.log('Before change: ', spclEduTargetYn);
    setSpclEduTargetYn('N');
    isClose();
    console.log('After change: ', spclEduTargetYn);
  };

  const handleSubmit = () => {
    console.log('Submitting eduChoiceList : ', eduChoiceList);
    const eduChoiceResultList = eduChoiceList.map(({ spclEduItemCd, chcYn, fileId }) => ({
      spclEduItemCd,
      chcYn,
      fileId,
    }));
    console.log('The result of eduChoiceModal is : ', eduChoiceResultList);
    onSubmit(eduChoiceResultList);
    setSpclEduTargetYn('Y');
    console.log('handleSubmit_spclEduTargetYn : ', spclEduTargetYn);
    ToastService.success('저장되었습니다.');
    isClose();
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">특별교육</h3>
        <span className="txt-guide">산업안전보건법 시행규칙 제26조 및 별표5</span>
        <div className="pop_cont">
          <div className="editbox">
            {eduChoiceList.map((info, index) => {
              const { spclEduItemCd, title, subList, chcYn } = info;
              return (
                <>
                  <div className="form-table">
                    <div className="form-cell1 wid50">
                      <div className="group-box-wrap wid100">
                        <div className="radio-wrap">
                          <label className="type01">
                            <input
                              type="checkbox"
                              checked={chcYn === 'Y' ? true : false}
                              onChange={(event) => {
                                const checked = event.target.checked;
                                changeInput(`eduChoiceList[${index}].chcYn`, checked ? 'Y' : 'N');
                              }}
                            />
                            <span
                              className="type01"
                              dangerouslySetInnerHTML={{ __html: ReactUtil.convertEnterStringToBrTag(title) }}
                            />
                            <ul className="ck-guide">
                              {subList.map((subListTititle, index) => {
                                return <li key={index}>{subListTititle}</li>;
                              })}
                            </ul>
                          </label>
                        </div>
                      </div>
                      <div className="form-table">
                        <div className="form-cell wid50">
                          <div className="form-group wid100">
                            <AppFileAttach
                              mode="edit"
                              label="파일첨부"
                              fileGroupSeq={eduChoiceList[index].fileId}
                              workScope={'O'}
                              updateFileGroupSeq={(newFileGroupSeq) => {
                                changeInput(`eduChoiceList[${index}].fileId`, newFileGroupSeq);
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr className="line"></hr>
                </>
              );
            })}
          </div>
        </div>

        <div className="pop_btns mt-20">
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleSubmit}>
            저장
          </button>
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            취소
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default WorkPermitEduChoiceModal;
