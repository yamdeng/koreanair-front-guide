import AppNavigation from '@/components/common/AppNavigation';
import useOcuMachinesManageStore from '@/stores/occupation/management/useOcuMachinesManageStore';
import { listBaseState } from '@/stores/slice/listSlice';
import { useEffect } from 'react';
import MachinesList from './MachinesList';
import MachinesStatus from './MachinesStatus';
import MachinesHeader from './MachinesHeader';

// TESTING - 240826_generated

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/machines',
  baseRoutePath: '/occupation/management/machines',
};

function MachinesMain() {
  const { tabIndex, changeTab, clear } = useOcuMachinesManageStore();

  useEffect(() => {
    changeTab(0);
    return clear;
  }, []);

  console.log(`tabIndex : ${tabIndex}`);

  return (
    <>
      <MachinesHeader />
      {/* TODO : 검색 input 영역입니다 */}
      {tabIndex == 0 ? <MachinesStatus /> : <></>}
      {tabIndex == 1 ? <MachinesList /> : <></>}
    </>
  );
}

export default MachinesMain;
