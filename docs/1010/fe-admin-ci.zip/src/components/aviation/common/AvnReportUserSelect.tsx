import AppAutoComplete from '@/components/common/AppAutoComplete';
import { getUserInfoByLocale, getUserLabelByLocale } from '@/services/i18n';
import CommonInputError from '@/components/common/CommonInputError';

function AvnReportUserSelect(props) {
  const {
    label,
    required,
    errorMessage,
    onSelect,
    deleteUser,
    userList,
    up,
    down,
    displaySort = false,
    ...rest
  } = props;
  return (
    <>
      <div className={errorMessage ? 'UserChicebox Flight error' : 'UserChicebox Flight'}>
        <div className="form-group wid100">
          <AppAutoComplete
            apiUrl="avn/common/users"
            labelKey="customLabel"
            valueKey="empNo"
            dataKey="data.list"
            onSelect={(value) => {
              onSelect(value);
            }}
            onlySelect
            isMultiple={false}
            getOptionLabel={(info) => {
              return getUserLabelByLocale(info);
            }}
            filterOption={() => true}
            {...rest}
          />
          <label className="file-label">
            {label} {required ? <span className="required"></span> : null}
          </label>
          <div className="SelectedList memberClass mt10" style={{ display: userList && userList.length ? '' : 'none' }}>
            <ul>
              {userList.map((userInfo, userListIndex) => {
                const applyUserInfo = getUserInfoByLocale(userInfo);
                const { empNo, userName, deptName, rankName, tagName } = applyUserInfo;
                return (
                  <li key={empNo}>
                    <span className="InfoBox"></span>
                    <div className="Info">
                      <div className="Name">
                        {userName} ({empNo})
                      </div>
                      <div className="Dept">
                        {deptName} / {rankName}
                      </div>
                    </div>
                    <div className="column-box" style={{ display: displaySort ? '' : 'none' }}>
                      <span className="column-btn">
                        <a href={undefined} onClick={() => up(userListIndex)}>
                          <span className="up">up</span>
                        </a>
                        <a href={undefined} onClick={() => down(userListIndex)}>
                          <span className="down">down</span>
                        </a>
                      </span>
                    </div>
                    <a href={undefined} onClick={() => deleteUser(userListIndex)}>
                      <span className="delete">X</span>
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
      <CommonInputError errorMessage={errorMessage} label={label} />
    </>
  );
}

export default AvnReportUserSelect;
