import { useEffect, useState } from 'react';
// import { useTranslation } from 'react-i18next';
import CommonUtil from '@/utils/CommonUtil';
import AuditCode from '@/config/AuditCode';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppNavigation from '@/components/common/AppNavigation';
import AppSelect from '@/components/common/AppSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppTable from '@/components/common/AppTable';
import AppSearchInput from '@/components/common/AppSearchInput';
// import AppCheckbox from '@/components/common/AppCheckbox';
// import AppAutoComplete from '@/components/common/AppAutoComplete';
// import AppTextInput from '@/components/common/AppTextInput';
import { DATE_PICKER_TYPE_MONTH } from '@/config/CommonConstant';
import AppUserSearch from '@/components/common/AppUserSearch';
import useMyAuditListStore from '@/stores/aviation/audit/myAudit/useMyAuditListStore';
// import useAuthCheck from '@/hooks/useAuthCheck';
import AppCheckboxGroup from '@/components/common/AppCheckboxGroup';

/* 그리드내 컬럼 설정 */
// Audit No
function AuditNoComponent(props) {
  return (
    <div className="Safety-table-cell tl">
      <a href="javascript:void(0);">{String(props.value).toLocaleString()}</a>
    </div>
  );
}

// Auditor
function AuditorsComponent(props) {
  const state = useMyAuditListStore();
  const { expandedAuditor, editAuditProcess } = state;
  const { value } = props;
  let applyAuditorList = [];
  if (value && value.length) {
    value && expandedAuditor ? value : value[0];
    if (expandedAuditor) {
      applyAuditorList = value;
    } else {
      applyAuditorList = [value[0]];
    }
  }

  const onClick = (auditorInfo) => {
    //alert(`auditorInfo : ${JSON.stringify(auditorInfo)}`);
    //alert(auditorInfo.auditid);
    editAuditProcess(auditorInfo.auditid);
  };

  return (
    <div className="Audit-table-cell">
      <div className="list-box">
        <ul>
          {applyAuditorList.map((info) => {
            const { auditid, auditornm, auditortype } = info;
            const applyStyle: any = {};
            if (info.auditcolor) {
              applyStyle.color = info.auditcolor;
              applyStyle.cursor = 'pointer';
            }
            return (
              <>
                <li style={applyStyle}>
                  {/* <a href="javascript:void(0);"> */}
                  <span key={auditid} onClick={() => onClick(info)} style={applyStyle}>
                    {auditortype} {auditornm}
                  </span>
                  {/* </a> */}
                </li>
              </>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

// 그리드내 CAR 관련 항목 펼치기/접기
function CarComponentExpander(props) {
  const state = useMyAuditListStore();
  const { expandedCar } = state;
  const { value } = props;
  let CarList = [];
  if (value && value.length) {
    value && expandedCar ? value : value[0];
    if (expandedCar) {
      CarList = value;
    } else {
      CarList = [value[0]];
    }
  }
  return CarList;
}

// CAR By
function FindingCarNoComponent(props) {
  const CarList = CarComponentExpander(props);
  const state = useMyAuditListStore();
  const { editAuditProcessCar } = state;
  const onClick = (carInfo) => {
    editAuditProcessCar(carInfo.auditid, carInfo.findingid);
  };

  return (
    <div className="Audit-table-cell">
      <div className="list-box">
        <ul>
          {CarList.map((info) => {
            const { carno, carnocolor } = info;
            const applyStyle: any = {};
            if (carnocolor) {
              applyStyle.color = carnocolor;
              applyStyle.cursor = 'pointer';
            }
            return (
              <>
                <li style={applyStyle}>
                  {/* <a href="javascript:void(0);"> */}
                  <span key={carno} onClick={() => onClick(info)} style={applyStyle}>
                    {carno}
                  </span>
                  {/* </a> */}
                </li>
              </>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

// CAR Title
function FindingTitleComponent(props) {
  const CarList = CarComponentExpander(props);
  const state = useMyAuditListStore();
  const { editAuditProcessCar } = state;
  const onClick = (carInfo) => {
    editAuditProcessCar(carInfo.auditid, carInfo.findingid);
  };

  return (
    <div className="Audit-table-cell">
      <div className="list-box">
        <ul>
          {CarList.map((info) => {
            const { findingtitle, dueatcolor } = info;
            const applyStyle: any = {};
            applyStyle.color = dueatcolor;
            applyStyle.cursor = 'pointer';
            return (
              <>
                <li>
                  {/* <a href="javascript:void(0);"> */}
                  <span onClick={() => onClick(info)} style={applyStyle}>
                    {findingtitle}
                  </span>
                  {/* </a> */}
                </li>
              </>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

// Due Date
function FindingDueAtComponent(props) {
  const CarList = CarComponentExpander(props);
  const state = useMyAuditListStore();
  const { editAuditProcessCar } = state;
  const onClick = (carInfo) => {
    editAuditProcessCar(carInfo.auditid, carInfo.findingid);
  };

  return (
    <div className="Audit-table-cell">
      <div className="list-box">
        <ul>
          {CarList.map((info) => {
            const { dueat, dueatcolor } = info;
            const applyStyle: any = {};
            if (dueatcolor) {
              applyStyle.color = dueatcolor;
              applyStyle.cursor = 'pointer';
            }
            return (
              <>
                <li style={applyStyle}>
                  {/* <a href="javascript:void(0);"> */}
                  <span key={dueat} style={applyStyle} onClick={() => onClick(info)}>
                    {dueat}
                  </span>
                  {/* </a> */}
                </li>
              </>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

// Conduct
function ConductPhaseComponent(props) {
  const CarList = CarComponentExpander(props);
  const state = useMyAuditListStore();
  const { editAuditProcessCar } = state;
  const onClick = (carInfo) => {
    editAuditProcessCar(carInfo.auditid, carInfo.findingid);
  };

  return (
    <div className="Audit-table-cell">
      <div className="list-box">
        <ul>
          {CarList.map((info) => {
            const { conductphase } = info;
            const applyStyle: any = {};
            applyStyle.color = '#ffb533';
            applyStyle.cursor = 'pointer';
            return (
              <>
                <li style={applyStyle}>
                  {/* <a href="javascript:void(0);"> */}
                  <span key={conductphase} style={applyStyle} onClick={() => onClick(info)}>
                    {conductphase}
                  </span>
                  {/* </a> */}
                </li>
              </>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

// CAR
function CarPhaseComponent(props) {
  const CarList = CarComponentExpander(props);
  const state = useMyAuditListStore();
  const { editAuditProcessCar } = state;
  const onClick = (carInfo) => {
    editAuditProcessCar(carInfo.auditid, carInfo.findingid);
  };

  return (
    <div className="Audit-table-cell">
      <div className="list-box">
        <ul>
          {CarList.map((info) => {
            const { findingphase } = info;
            const applyStyle: any = {};
            applyStyle.color = 'red';
            applyStyle.cursor = 'pointer';
            return (
              <>
                <li style={applyStyle}>
                  {/* <a href="javascript:void(0);"> */}
                  <span key={findingphase} style={applyStyle} onClick={() => onClick(info)}>
                    {findingphase}
                  </span>
                  {/* </a> */}
                </li>
              </>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

function MyAuditList() {
  // const isAuth = useAuthCheck('GROUP_AVN_DEV_ALL', false);
  // const isAuth2 = useAuthCheck('SYSTEM_ADMIN', false);
  // const isAuth3 = useAuthCheck(['SYSTEM_ADMIN', 'GROUP_AVN_DEV_ALL'], true);

  const customButtons = [
    {
      title: '+ Add Plan',
      onClick: () => {
        addAuditPlan();
      },
    },
    {
      title: '일괄업로드',
      onClick: () => {
        alert('준비중입니다.');
      },
    },
    {
      title: 'Fields',
      onClick: () => {
        alert('준비중입니다.');
      },
      iconClass: 'icon-fields',
    },
  ];
  //debugger;
  // const [empNo, setUserEmpNo] = useState('');
  // const changeUserEmpNo = (value) => {
  //   setUserEmpNo(value);
  // };

  const state = useMyAuditListStore();
  const {
    init,
    clearList,
    divAuditYear,
    myAuditYear,
    myProcessingGubun,
    changeAuditYear,
    clickStatusNumber,

    ToggleColor1_1,
    ToggleColor1_2,
    ToggleColor1_3,
    ToggleColor1_4,
    ToggleColor1_5,
    ToggleColor1_6,
    ToggleColor2_1,
    ToggleColor2_2,
    ToggleColor2_3,
    ToggleColor2_4,
    ToggleColor2_5,
    ToggleColor2_6,
    ToggleColor3_1,
    ToggleColor3_2,
    ToggleColor3_3,
    ToggleColor3_4,
    ToggleColor3_5,

    dsStatistics,
    changeAuditStartDtSearch,
    changeAuditEndDtSearch,
    changeDueStartDtSearch,
    changeDueEndDtSearch,
    enterSearch,
    searchParam,
    changeSearchInput,
    list,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    expandedList,
    setExpandedList,
    // expandedAuditor,
    // toggleExpandAuditor,
    // expandedCar,
    // toggleExpandCar,
    // onSelect,
    // userList,
    // ...rest

    addAuditPlan,
    // editAuditProcess,
  } = state;

  //input value에 넣기 위한 분리 선언
  const {
    divSearchList,
    phaseSearchList,
    auditStartDtSearch,
    auditEndDtSearch,
    dueStartDtSearch,
    dueEndDtSearch,
    titleSearch,
    empNo,
  } = searchParam;

  // const { t } = useTranslation();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      //테이블 column 선언
      //{ field: 'auditId', headerName: 'Audit Id', cellStyle: { textAlign: 'center' } },
      {
        width: 100,
        field: 'divisionNm',
        headerName: 'Division',
        cellStyle: { textAlign: 'center' },
        // valueFormatter: (p) => String(p.value).toLocaleString(),
        // cellRenderer: AuditNoComponent,
      },
      {
        width: 130,
        field: 'auditNo',
        headerName: 'Audit No.',
        cellStyle: { textAlign: 'center' },
        // valueFormatter: (p) => String(p.value).toLocaleString(),
        cellRenderer: AuditNoComponent,
      },
      { width: 120, field: 'auditAt', headerName: 'Audit Date', cellStyle: { textAlign: 'left' } },
      { width: 200, field: 'title', headerName: 'Title', cellStyle: { textAlign: 'left' } },
      {
        width: 120,
        field: 'auditors',
        headerName: 'Auditors',
        cellStyle: { textAlign: 'center' },
        cellRenderer: AuditorsComponent,
      },
      {
        width: 170,
        field: 'findings',
        headerName: 'CAR No. / CAR By',
        cellStyle: { textAlign: 'center' },
        cellRenderer: FindingCarNoComponent,
      },
      {
        width: 220,
        field: 'findings',
        headerName: 'CAR Title',
        cellStyle: { textAlign: 'center' },
        cellRenderer: FindingTitleComponent,
      },
      {
        width: 180,
        field: 'findings',
        headerName: 'Due Date',
        cellStyle: { textAlign: 'center' },
        cellRenderer: FindingDueAtComponent,
      },
      {
        width: 90,
        field: 'findings',
        headerName: 'Conduct',
        cellStyle: { textAlign: 'center' },
        cellRenderer: ConductPhaseComponent,
      },
      {
        width: 90,
        field: 'findings',
        headerName: 'CAR',
        cellStyle: { textAlign: 'center' },
        cellRenderer: CarPhaseComponent,
      },
      {
        width: 90,
        field: 'closePhase',
        headerName: 'Close',
        cellStyle: { textAlign: 'center' },
      },
    ])
  );

  useEffect(() => {
    init();
    return clearList;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      {/*사용자기준 조회범위영역 */}
      <div className="user-wrap">
        <div className="user-box wid60">
          <div className="user-box-top">
            <div className="form-table user-head">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="df wid30">
                    <AppSelect
                      options={AuditCode.auditYear}
                      value={divAuditYear}
                      // onChange={(value) => changeAuditYear('div', value)}
                      onSelect={(value) => changeAuditYear('div', value)}
                    />
                  </div>
                  <div className="h4">Division Audit</div>
                </div>
              </div>
            </div>
            <div className="user-box-bottom">
              <div className="ant-col ant-col-11">
                <dl>
                  <dt className="tot">Total</dt>
                  <dd className={`tot-result ${ToggleColor1_1}`} onClick={(e) => clickStatusNumber(e, '1', '1_1')}>
                    {dsStatistics.divAuditCnt}
                  </dd>
                </dl>
              </div>
              <div className="ant-col">
                <dl className="sub-count">
                  <dt>Finding</dt>
                  <dd>
                    <span className={`${ToggleColor1_2}`} onClick={(e) => clickStatusNumber(e, '1', '1_2')}>
                      {dsStatistics.divFindingCompletedCnt}
                    </span>
                    <span className="text-color-blue"> / </span>
                    <span className={`${ToggleColor1_3}`} onClick={(e) => clickStatusNumber(e, '1', '1_3')}>
                      {dsStatistics.divFindingCnt}
                    </span>
                    &nbsp;({dsStatistics.divFindingCompletedPer})
                  </dd>
                </dl>
                <dl className="sub-count">
                  <dt>Observation</dt>
                  <dd>
                    <span className={`${ToggleColor1_4}`} onClick={(e) => clickStatusNumber(e, '1', '1_4')}>
                      {dsStatistics.divObservationCompletedCnt}
                    </span>
                    <span className="text-color-blue"> / </span>
                    <span className={`${ToggleColor1_5}`} onClick={(e) => clickStatusNumber(e, '1', '1_5')}>
                      {dsStatistics.divObservationCnt}
                    </span>
                    &nbsp;({dsStatistics.divObservationCompletedPer})
                  </dd>
                </dl>
                <dl className="sub-count">
                  <dt>Overdue</dt>
                  <dd>
                    <span className={`${ToggleColor1_6}`} onClick={(e) => clickStatusNumber(e, '1', '1_6')}>
                      {dsStatistics.divDueCnt}
                    </span>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="user-box-top">
            <div className="form-table user-head">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="df wid30">
                    <AppSelect
                      options={AuditCode.auditYear}
                      value={myAuditYear}
                      // onChange={(value) => changeAuditYear('my', value)}
                      onSelect={(value) => changeAuditYear('my', value)}
                    />
                  </div>
                  <div className="h4">My Audit</div>
                </div>
              </div>
            </div>
            <div className="user-box-bottom">
              <div className="ant-col ant-col-11">
                <dl>
                  <dt className="tot">Total</dt>
                  <dd className={`tot-result ${ToggleColor2_1}`} onClick={(e) => clickStatusNumber(e, '2', '2_1')}>
                    {dsStatistics.myAuditCnt}
                  </dd>
                </dl>
              </div>
              <div className="ant-col">
                <dl className="sub-count">
                  <dt>Finding</dt>
                  <dd>
                    <span className={`${ToggleColor2_2}`} onClick={(e) => clickStatusNumber(e, '2', '2_2')}>
                      {dsStatistics.myFindingCompletedCnt}
                    </span>
                    <span className="text-color-blue"> / </span>
                    <span className={`${ToggleColor2_3}`} onClick={(e) => clickStatusNumber(e, '2', '2_3')}>
                      {dsStatistics.myFindingCnt}
                    </span>
                    &nbsp;({dsStatistics.myFindingCompletedPer})
                  </dd>
                </dl>
                <dl className="sub-count">
                  <dt>Observation</dt>
                  <dd>
                    <span className={`${ToggleColor2_4}`} onClick={(e) => clickStatusNumber(e, '2', '2_4')}>
                      {dsStatistics.myObservationCompletedCnt}
                    </span>
                    <span className="text-color-blue"> / </span>
                    <span className={`${ToggleColor2_5}`} onClick={(e) => clickStatusNumber(e, '2', '2_5')}>
                      {dsStatistics.myObservationCnt}
                    </span>
                    &nbsp;({dsStatistics.myObservationCompletedPer})
                  </dd>
                </dl>
                <dl className="sub-count">
                  <dt>Overdue</dt>
                  <dd>
                    <span className={`${ToggleColor2_6}`} onClick={(e) => clickStatusNumber(e, '2', '2_6')}>
                      {dsStatistics.myDueCnt}
                    </span>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
        <div className="user-box wid40">
          <div className="user-box-top">
            <div className="form-table user-head">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="df wid20">
                    <AppSelect
                      options={AuditCode.myProcessingGubun}
                      value={myProcessingGubun}
                      // onChange={(value) => changeAuditYear('div', value)}
                      onSelect={(value) => changeAuditYear('processing', value)}
                    />
                  </div>
                  <div className="h4 tit">My Processing All</div>
                </div>
              </div>
            </div>
            <div className="user-box-bottom">
              <div className="wid100">
                <ul className="pro-list">
                  <dl>
                    <dt className="tot">Total</dt>
                    <dd className={`tot-result ${ToggleColor3_1}`} onClick={(e) => clickStatusNumber(e, '3', '3_1')}>
                      {dsStatistics.myProcessingAuditCnt}
                    </dd>
                  </dl>
                  <dl>
                    <dt className="tot">Plan</dt>
                    <dd className={`tot-result ${ToggleColor3_2}`} onClick={(e) => clickStatusNumber(e, '3', '3_2')}>
                      {dsStatistics.myProcessingPlanCnt}
                    </dd>
                  </dl>
                  <dl>
                    <dt className="tot">Conduct</dt>
                    <dd className={`tot-result ${ToggleColor3_3}`} onClick={(e) => clickStatusNumber(e, '3', '3_3')}>
                      {dsStatistics.myProcessingConductCnt}
                    </dd>
                  </dl>
                  <dl>
                    <dt className="tot">CAR</dt>
                    <dd className={`tot-result ${ToggleColor3_4}`} onClick={(e) => clickStatusNumber(e, '3', '3_4')}>
                      {dsStatistics.myProcessingCarCnt}
                    </dd>
                  </dl>
                  <dl>
                    <dt className="tot">Overdue</dt>
                    <dd className={`tot-result ${ToggleColor3_5}`} onClick={(e) => clickStatusNumber(e, '3', '3_5')}>
                      {dsStatistics.myProcessingDueCnt}
                    </dd>
                  </dl>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*//사용자기준 조회범위영역 */}

      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div id="" className={isExpandDetailSearch ? 'area-detail' : 'area-detail active'}>
          <div className="form-table">
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_301"
                  label="Division Audit"
                  value={divSearchList}
                  isMultiple
                  onChange={(value) => {
                    changeSearchInput('divSearchList', value);
                  }}
                  // disabled
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group form-glow wid30">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={'Audit Date'}
                      pickerType={DATE_PICKER_TYPE_MONTH}
                      value={auditStartDtSearch}
                      onChange={(value) => {
                        changeAuditStartDtSearch(value);
                      }}
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      pickerType={DATE_PICKER_TYPE_MONTH}
                      value={auditEndDtSearch}
                      onChange={(value) => {
                        changeAuditEndDtSearch(value);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid20">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_302"
                  label="Phase"
                  value={phaseSearchList}
                  isMultiple
                  onChange={(value) => {
                    changeSearchInput('phaseSearchList', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppSearchInput
                  label="Title or CAR Title or AuditorNm"
                  value={titleSearch}
                  onChange={(value) => {
                    changeSearchInput('titleSearch', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppUserSearch
                  label="User"
                  value={empNo}
                  onChange={(value) => {
                    changeSearchInput('empNo', value);
                  }}
                  // disabled
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group form-glow wid30">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={'Due Date'}
                      pickerType={DATE_PICKER_TYPE_MONTH}
                      value={dueStartDtSearch}
                      onChange={(value) => {
                        changeDueStartDtSearch(value);
                      }}
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      pickerType={DATE_PICKER_TYPE_MONTH}
                      value={dueEndDtSearch}
                      onChange={(value) => {
                        changeDueEndDtSearch(value);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="group-box-wrap flex-between wid100">
                <AppCheckboxGroup
                  options={[
                    { label: 'Audiror All', value: 'auditor' },
                    { label: 'CAR All', value: 'car' },
                  ]}
                  value={expandedList}
                  onChange={(value) => setExpandedList(value)}
                  noBorder
                />
                {/* <AppCheckbox
                  label="Audiror 펼치기"
                  value={expandedAuditor}
                  onChange={(value) => {
                    toggleExpandAuditor(value);
                  }}
                  noBorder
                />
                <AppCheckbox
                  label="CAR 펼치기"
                  value={expandedCar}
                  onChange={(value) => {
                    toggleExpandCar(value);
                  }}
                  noBorder
                /> */}
                <div className="btn-area">
                  <button
                    type="button"
                    name="button"
                    className="btn-sm btn_text btn-darkblue-line"
                    onClick={() => enterSearch()}
                  >
                    조회
                  </button>
                  <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                    User Guide
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <div className="">
        {/* <AppTable rowData={rowData} columns={columns} customButtons={customButtons} /> */}
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          customButtons={customButtons}
          //handleRowDoubleClick={handleRowDoubleClick}
        />
      </div>
      {/*//그리드영역 */}
    </>
  );
}

export default MyAuditList;
