import { useState } from 'react';
import { DatePicker, TimePicker, Select as AntSelect } from 'antd';
import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
import AppTextInput from '@/components/common/AppTextInput';
import AppTextArea from '@/components/common/AppTextArea';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import { Upload } from 'antd';

import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';
import useMyAuditCloseStore from '@/stores/aviation/audit/myAudit/useMyAuditCloseStore';

function MyAuditClose() {
  const [inputValue, setInputValue] = useState('');
  const rowData = getAllData();
  const columns = testColumnInfos;
  const customButtons = [
    {
      title: 'ApprReq',
      onClick: () => {
        alert('ApprReq');
      },
    },
    {
      title: 'Approval',
      onClick: () => {
        alert('Approval');
      },
    },
    {
      title: 'Reject',
      onClick: () => {
        alert('Reject');
      },
    },
    {
      title: 'Rollback',
      onClick: () => {
        alert('Rollback');
      },
    },
  ];

  const { hideClose } = useMyAuditFrameStore();

  return (
    <>
      {/* <div id="area-CLOSE" className={`myaudit-contents ${hideClose}`}> */}
      <div id="area-CLOSE" className="myaudit-contents">
        <h3 className="audit-tit">Close</h3>
        {/*그리드영역 */}
        <div className="mt-10">
          <AppTable rowData={rowData} columns={columns} customButtons={customButtons} hiddenPagination />
        </div>
        {/*//그리드영역 */}
        {/* 하단버튼영역 */}
        <div className="contents-btns">
          <button className="btn_text text_color_neutral-10 btn_confirm ">Delete</button>
          <button className="btn_text btn_list ">Save</button>
          <button disabled className="btn_text btn-disabled">
            Rollback
          </button>
          <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
            Next
          </button>
        </div>
        {/*//하단버튼영역*/}
      </div>
    </>
  );
}

export default MyAuditClose;
