import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppRangeDatePicker from '@/components/common/AppRangeDatePicker';
import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
import ApiService from '@/services/ApiService';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { create } from 'zustand';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import history from '@/utils/history';
import register from '@/resources/images/home_ico_3.svg';
import { Popconfirm } from 'antd';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';
// 아래 2개의 file import
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';

const StepList = [
  {
    stepName: 'pg_iv_reporting',
    stepNumber: 1,
    stepTitle: '작성',
  },
  {
    stepName: 'pg_iv_reception',
    stepNumber: 2,
    stepTitle: '결재',
  },
  {
    stepName: 'pg_iv_mitigation',
    stepNumber: 3,
    stepTitle: '안전권고',
  },
  {
    stepName: 'pg_iv_close',
    stepNumber: 4,
    stepTitle: '종결',
  },
];

//오늘 날짜 만들기
const today = new Date();
const year = today.getFullYear(); // 년도
const month = today.getMonth() + 1; // 월
const date = today.getDate() + 1; // 날짜
let monthString = '';
let dateString = '';
if (month < 10) {
  monthString = '0' + month;
} else {
  monthString = month.toString();
}
if (date < 10) {
  dateString = '0' + date;
} else {
  dateString = date.toString();
}
const todayString = year + '-' + monthString + '-' + dateString;

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/srm/investigation/reports',
  baseRoutePath: '/aviation/safety-risk-mgmt/investigation-report',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  titleSearch: '',
  evnetDateTypeSearch: 'event',
  startDtSearch: todayString,
  endDtSearch: todayString,
  eventClassSearch: '',
  occurrenceAirportSearch: '',
  flightPhaseSearch: '',
  pageCodeSearch: 'pg_iv_reporting',
  stepCodeSearch: '',
};

/* zustand store 생성 */
const InvestigationReportStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  //초기 step 선언
  currentStep: 'pg_iv_reporting',
  //상태 버튼 array
  statusList: [],

  //range날짜에 필요한 초기 값
  rangeDt: [todayString, todayString],

  //결재 단계 클릭 시 가져옴
  changeStep: async (step) => {
    set({ currentStep: step });
    const apiResult = await ApiService.get(`avn/common/page_code/${step}/state`);
    const data = apiResult.data || [];
    set({ statusList: data });

    const { searchParam, enterSearch } = get();
    searchParam['pageCodeSearch'] = step;
    searchParam['stepCodeSearch'] = '';
    set({ searchParam: searchParam });
    enterSearch();
  },
  //상세 결재 단계 클릭 시 조회
  searchStepCode: (step) => {
    const { searchParam, enterSearch } = get();
    searchParam['stepCodeSearch'] = step;
    set({ searchParam: searchParam });
    enterSearch();
  },

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    titleSearch: '',
    evnetDateTypeSearch: 'event',
    startDtSearch: todayString,
    endDtSearch: todayString,
    eventClassSearch: '',
    occurrenceAirportSearch: '',
    flightPhaseSearch: '',
    pageCodeSearch: 'pg_iv_reporting',
    stepCodeSearch: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
    set({ rangeDt: [todayString, todayString] });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam }, rangeDt: [todayString, todayString] });
  },
}));

function InvestigationReport() {
  //언어구분 값
  const currentLocale = useStore(useAppStore, (state) => state.currentLocale);
  const { t } = useTranslation();

  //URL 클릭 시 이동
  const CustomURLComp = (props) => {
    return (
      <div className="Safety-table-cell tl">
        <a
          href="javascript:void(0);"
          onClick={() => {
            if (props.data.pageCode == 'pg_iv_reporting' || props.data.pageCode == 'pg_iv_reception') {
              history.push(`/aviation/safety-risk-mgmt/investigation-report/${props.data.id}`);
            } else {
              history.push(`/aviation/safety-risk-mgmt/investigation-report-mitigation/${props.data.id}`);
            }
          }}
        >
          {props.value}
        </a>
      </div>
    );
  };

  //결재상태 > 반려일 시 아이콘 생성 및 사유 확인
  const CustomStatusComp = (props) => {
    let disabledReason = false;

    if (props.data.stepCode != 'rejected') {
      disabledReason = true;
    } else {
      disabledReason = false;
    }
    return (
      <>
        <Popconfirm
          title="반려사유"
          description={props.data.reason}
          disabled={disabledReason}
          showCancel={false}
          okText={<p style={{ color: '#ffffff' }}>OK</p>}
        >
          <div
            style={{
              position: 'relative',
              display: 'flex',
              justifyContent: 'center',
              cursor: disabledReason ? 'default' : 'pointer',
            }}
          >
            <p>{props.data.statusKo}</p>
            {disabledReason == false ? <img src={register}></img> : null}
          </div>
        </Popconfirm>
      </>
    );
  };
  //SPI여부 column 커스텀
  const isSpiLabel = (props) => {
    if (props.value == 'Y') {
      return '예';
    } else {
      return '아니오';
    }
  };
  //발생단계 column 커스텀
  const flightPhaseLabelLocale = (props) => {
    if (currentLocale === 'ko') {
      return props.data.flightPhaseTextKo;
    } else {
      return props.data.flightPhaseTextEn;
    }
  };

  const state = InvestigationReportStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'reportNo', headerName: '보고서 번호', cellRenderer: CustomURLComp },
      { field: 'reportTitle', headerName: 'Subject' },
      { field: 'eventAt', headerName: '발생시간' },
      {
        field: 'classification',
        headerName: 'Classification',
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_154',
        },
      },
      { field: 'eventNm', headerName: '이벤트명' },
      { field: 'airport', headerName: '발생 공항' },
      {
        field: 'flightPhase',
        headerName: '발생단계',
        cellRenderer: flightPhaseLabelLocale,
      },
      { field: 'aircraftTypeText', headerName: 'fleet' },
      { field: 'registrationNo', headerName: '등록 번호' },
      { field: 'flightNo', headerName: '비행기번호' },
      {
        field: 'stepCode',
        headerName: '결재 상태',
        cellRenderer: CustomStatusComp,
        cellStyle: { textAlign: 'center' },
      },
      {
        field: 'isSpi',
        headerName: 'SPI여부',
        cellRenderer: isSpiLabel,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_146',
        },
      },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    currentStep,
    statusList,
    goAddPage,
    rangeDt,
    changeSearchInput,
    initSearchInput,
    changeStateProps,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    changeStep,
    searchStepCode,
  } = state;
  // TODO : 검색 파라미터 나열
  const {
    titleSearch,
    evnetDateTypeSearch,
    startDtSearch,
    endDtSearch,
    eventClassSearch,
    occurrenceAirportSearch,
    flightPhaseSearch,
  } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
  }, []);

  useEffect(() => {
    enterSearch();
    changeStep('pg_iv_reporting');
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>조사보고서</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={t('ke.safetyRiskMgmt.investigationReport.label.00001')}
                  value={titleSearch}
                  onChange={(value) => {
                    changeSearchInput('titleSearch', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid20">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_153"
                  label={t('ke.safetyRiskMgmt.investigationReport.label.00002')}
                  value={evnetDateTypeSearch}
                  onChange={(value) => {
                    changeSearchInput('evnetDateTypeSearch', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid40">
              <div className="form-group wid100">
                <AppRangeDatePicker
                  label2={t('ke.safetyRiskMgmt.investigationReport.label.00003')}
                  label="검색일"
                  onChange={(value) => {
                    changeSearchInput('startDtSearch', value[0]);
                    changeSearchInput('endDtSearch', value[1]);
                    changeStateProps('rangeDt', value);
                  }}
                  value={rangeDt}
                  showNow
                  placeholder={['시작일', '종료일']}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_154"
                  applyAllSelect
                  label={t('ke.safetyRiskMgmt.investigationReport.label.00005')}
                  value={eventClassSearch}
                  onChange={(value) => {
                    changeSearchInput('eventClassSearch', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppAutoComplete
                  label={t('ke.safetyRiskMgmt.investigationReport.label.00006')}
                  apiUrl="avn/common/airports"
                  value={occurrenceAirportSearch}
                  labelKey="label"
                  valueKey="airportCode"
                  dataKey="data.list"
                  onChange={(value) => {
                    changeSearchInput('occurrenceAirportSearch', value);
                  }}
                  isMultiple={false}
                  isValueString
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpIdList={['CODE_GRP_002', 'CODE_GRP_041']}
                  isMultiGroupCode
                  label={t('ke.safetyRiskMgmt.investigationReport.label.00007')}
                  value={flightPhaseSearch}
                  applyAllSelect
                  onChange={(value) => {
                    changeSearchInput('flightPhaseSearch', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              초기화
            </button>
          </div>
        </div>
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>
      {/* 리포트 프로세스 */}
      <div className="c-step-wrap">
        <ol className="c-step-list-type-5">
          {/* 선택된 class명에 active */}
          {StepList.map((stepInfo) => {
            const { stepName, stepNumber, stepTitle } = stepInfo;
            return (
              <li key={stepNumber} className={currentStep === stepName ? 'active' : ''}>
                <a
                  href="javascript:void(0);"
                  data-label={stepTitle}
                  onClick={() => {
                    changeStep(stepName);
                  }}
                >
                  <p className={currentStep === stepName ? 'info-title active' : 'info-title'}>
                    {/* 선택된 class명에 active */}
                    <span className="hide">{stepNumber}단계</span>
                    {stepTitle}
                  </p>
                </a>
                <span className="after-arrow"></span>
              </li>
            );
          })}
        </ol>
      </div>
      {/* 업무관련 버튼 */}
      <div className="process-btns">
        <button
          type="button"
          className="btn-sm btn_text btn-blue"
          onClick={() => {
            searchStepCode('');
          }}
        >
          전체
        </button>
        {statusList.map((statusInfo) => {
          const { textAdminKo, stepCode } = statusInfo;
          return (
            <button
              key={textAdminKo}
              type="button"
              className="btn-sm btn_text btn-blue"
              onClick={() => {
                searchStepCode(stepCode);
              }}
            >
              {textAdminKo}
            </button>
          );
        })}
      </div>
      {/* //  업무관련 버튼 */}
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
        useColumnDynamicSetting
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default InvestigationReport;
