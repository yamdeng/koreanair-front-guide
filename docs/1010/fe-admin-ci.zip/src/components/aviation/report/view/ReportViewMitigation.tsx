import ReportViewMitigationAccept from './ReportViewMitigationAccept';
import ReportViewMitigationAssign from './ReportViewMitigationAssign';
import ReportViewMitigationResult from './ReportViewMitigationResult';

/* 보고서상세 > 보고서 분석 > 경감조치 */
function ReportViewMitigation() {
  return (
    <div className="edit-area">
      <ReportViewMitigationAssign />
      <ReportViewMitigationAccept />
      <ReportViewMitigationResult />
    </div>
  );
}

export default ReportViewMitigation;
