import ReportDetail from '../detail/ReportDetail';
import ReportViewStore from '@/stores/aviation/report/view/ReportViewStore';
import ReportViewContainerStore from '@/stores/aviation/report/view/ReportViewContentStore';

/* 보고서상세 > 보고서 내용보기 */
function ReportViewContent() {
  return <ReportDetail detailInfo={{ reportTypeCd: 'asr' }} />;
}

export default ReportViewContent;
