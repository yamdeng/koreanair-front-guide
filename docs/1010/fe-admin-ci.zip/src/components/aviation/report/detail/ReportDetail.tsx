import { REPORT_TYPE_ASR, REPORT_TYPE_CSR } from '@/config/ReportFormConstant';
import ReportASRDetail from './ReportASRDetail';
import ReportCSRDetail from './ReportCSRDetail';

function ReportDetail({ detailInfo = {} }) {
  const { reportTypeCd } = detailInfo as any;
  let reportDetailComponent = <div className="detailForm">존재하지 않는 보고서 유형입니다.</div>;
  if (reportTypeCd) {
    if (reportTypeCd === REPORT_TYPE_ASR) {
      reportDetailComponent = <ReportASRDetail detailInfo={detailInfo} />;
    } else if (reportTypeCd === REPORT_TYPE_CSR) {
      reportDetailComponent = <ReportCSRDetail detailInfo={detailInfo} />;
    }
  }
  return <>{reportDetailComponent}</>;
}

export default ReportDetail;
