import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppTextInput from '@/components/common/AppTextInput';
import AppUserSearch from '@/components/common/AppUserSearch';

function CsrInvolveList({ store = {} }) {
  const {
    addInvolveCustomerList,
    addInvolveCrewList,
    deleteInvolveCustomerList,
    deleteInvolveCrewList,
    changeInput,
    formValue,
    errors,
  } = store as any;

  const { involveCustomerList, involveCrewList } = formValue;

  return (
    <div className="detail-list">
      {/*Fax */}
      <div className="form-table">
        <div className="form-cell wid50">
          <div className="form-group wid100">
            <div className="UserChicebox Fax ">
              <label htmlFor="file" className="file-label">
                Pax <span className="required"></span>
              </label>
              {involveCustomerList.map((customerInfo, index) => {
                const { involveCd, paxNm, genderCd, ageCo, nationNm, seatNm } = customerInfo;
                return (
                  <div key={index} className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="관련자"
                          codeGrpId="CODE_GRP_005"
                          value={involveCd}
                          onChange={(value) => {
                            changeInput(`involveCustomerList[${index}].involveCd`, value);
                          }}
                          errorMessage={errors[`involveCustomerList[${index}].involveCd`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="이름"
                          value={paxNm}
                          onChange={(value) => {
                            changeInput(`involveCustomerList[${index}].paxNm`, value);
                          }}
                          errorMessage={errors[`involveCustomerList[${index}].paxNm`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label={'성별'}
                          codeGrpId="CODE_GRP_039"
                          value={genderCd}
                          onChange={(value) => {
                            changeInput(`involveCustomerList[${index}].genderCd`, value);
                          }}
                          errorMessage={errors[`involveCustomerList[${index}].genderCd`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          inputType={'number'}
                          label="나이"
                          value={ageCo}
                          onChange={(value) => {
                            changeInput(`involveCustomerList[${index}].ageCo`, value);
                          }}
                          errorMessage={errors[`involveCustomerList[${index}].ageCo`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="국적"
                          value={nationNm}
                          onChange={(value) => {
                            changeInput(`involveCustomerList[${index}].nationNm`, value);
                          }}
                          errorMessage={errors[`involveCustomerList[${index}].nationNm`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="좌석번호"
                          value={seatNm}
                          onChange={(value) => {
                            changeInput(`involveCustomerList[${index}].seatNm`, value);
                          }}
                          errorMessage={errors[`involveCustomerList[${index}].seatNm`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid10">
                      <div className="form-group wid100">
                        <button
                          type="button"
                          className="tabs-tab-remove Mob"
                          onClick={() => deleteInvolveCustomerList(index)}
                        >
                          <span className="btn-del delete">Delete</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}

              {/*추가버튼*/}
              <div className="btn-area">
                <button
                  type="button"
                  name="button"
                  className="btn-sm btn_text btn-darkblue-line"
                  onClick={addInvolveCustomerList}
                >
                  + Add
                </button>
              </div>
              {/*//추가버튼*/}
            </div>
          </div>
        </div>
      </div>
      {/*CREW */}
      <div className="form-table">
        <div className="form-cell wid50">
          <div className="form-group wid100">
            <div className="UserChicebox Fax ">
              <label htmlFor="file" className="file-label">
                CREW <span className="required"></span>
              </label>
              {involveCrewList.map((crewInfo, index) => {
                const { involveCd, empNo, empNm } = crewInfo;
                return (
                  <div key={index} className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="관련자"
                          codeGrpId="CODE_GRP_005"
                          value={involveCd}
                          onChange={(value) => {
                            changeInput(`involveCrewList[${index}].involveCd`, value);
                          }}
                          errorMessage={errors[`involveCrewList[${index}].involveCd`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        {/* */}
                        <AppUserSearch
                          label="사용자검색"
                          value={empNo}
                          onChange={(value) => {
                            changeInput(`involveCrewList[${index}].empNo`, value);
                          }}
                          errorMessage={errors[`involveCrewList[${index}].empNo`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid30" style={{ display: empNo ? 'none' : '' }}>
                      <div className="form-group wid100">
                        <label className="t-label">{empNm || ''}</label>
                      </div>
                    </div>
                    <div className="form-cell wid10">
                      <div className="form-group wid100">
                        <button
                          type="button"
                          className="tabs-tab-remove Mob"
                          onClick={() => deleteInvolveCrewList(index)}
                        >
                          <span className="btn-del delete">Delete</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
              <div className="btn-area">
                <button
                  type="button"
                  name="button"
                  className="btn-sm btn_text btn-darkblue-line"
                  onClick={addInvolveCrewList}
                >
                  + Add
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CsrInvolveList;
