import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import _ from 'lodash';
import history from '@/utils/history';
import { produce } from 'immer';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import ToastService from '@/services/ToastService';
import ModalService from '@/services/ModalService';
import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';

const initFormValue = {
  /* Audit */
  auditId: '',
  phase: '',
  urlResult: '',
  isFinding: '',
  resultFileGroupSeq: '',
  // Finding 정보
  findingInfo: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formValue: initFormValue,
  // formValue: {
  //   ...initFormValue,
  // },
};

/* zustand store 생성 */
const useMyAuditConductStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...initFormData,

  dsAuditConductInfo: [], // Audit 정보
  dsAuditChecklistList: [], // Checklist 정보
  dsAuditChapterList: [], // Chapter 정보
  dsAuditQuestionList: [], // Question 정보
  currentChecklistId: '',
  currentChecklistIndex: 0,
  currentChapterTabIndex: 0,
  hideChecklistYn: '', // 체크리스트 숨김 설정

  // Conduct 단계 정보 설정
  setAuditConductInfo: async (auditInfo) => {
    set({ dsAuditConductInfo: auditInfo });

    const { dsAuditConductInfo, currentChecklistIndex, currentChapterTabIndex, formValue, changeInputFindingYn } =
      get();

    //formValue.auditId = auditInfo.auditId;
    set({ formValue: auditInfo });
    formValue.isFinding = auditInfo.isFinding === 'Y' ? 'Y' : 'N';
    changeInputFindingYn(formValue.isFinding);

    // 체크리스트, 챕터, 문항 정보 조회
    ApiService.get(`avn/audit/my-audit/2/conduct/checklist/${dsAuditConductInfo.auditId}`).then((apiResult) => {
      const checklistInfo = apiResult.data || {};
      set({
        dsAuditChecklistList: checklistInfo,
        dsAuditChapterList: checklistInfo[currentChecklistIndex].chapterInfo,
        dsAuditQuestionList: checklistInfo[currentChecklistIndex].chapterInfo[currentChapterTabIndex].questionInfo,

        currentChecklistId: checklistInfo[currentChecklistIndex].checklistId,
      });
    });
  },

  // checklist 선택시 해당 chapter 조회
  changeChecklist: (selectedChecklistId) => {
    const { dsAuditChecklistList, changeChapterTabIndex } = get();
    set({
      currentChecklistId: selectedChecklistId,
      currentChecklistIndex: dsAuditChecklistList.findIndex((info) => info.checklistId === selectedChecklistId),
      dsAuditChapterList: dsAuditChecklistList.find((info) => info.checklistId === selectedChecklistId).chapterInfo,
    });

    changeChapterTabIndex(0); // 변경한 체크리스트의 첫번째 챕터로 설정
  },

  // chapter Tab 선택시 해당 문항 조회
  changeChapterTabIndex: (chapterTabIndex) => {
    set({ currentChapterTabIndex: chapterTabIndex });
    const { dsAuditChapterList, currentChapterTabIndex } = get();
    set({
      dsAuditQuestionList: dsAuditChapterList[currentChapterTabIndex].questionInfo,
    });
  },

  // Finding / Observation 여부
  changeInputFindingYn: (value) => {
    // 체크리스트는 항상 view 처리
    //set({ hideChecklistYn: value === 'Y' ? '' : 'hide' });
  },

  // 문항 수정시
  changeQuestionList: async (questionId, questionIndex, keyName, value) => {
    set(
      produce((state: any) => {
        const questionInfo = state.dsAuditQuestionList[questionIndex];
        questionInfo[keyName] = value;
        // questionInfo.updated = true;

        const { dsAuditChecklistList, currentChecklistIndex, currentChapterTabIndex } = get();
        dsAuditChecklistList[currentChecklistIndex].chapterInfo[currentChapterTabIndex].questionInfo[questionIndex][
          keyName
        ] = value;
        dsAuditChecklistList[currentChecklistIndex].chapterInfo[currentChapterTabIndex].questionInfo[
          questionIndex
        ].updated = true;
      })
    );
  },

  // Audit Conduct 저장
  saveAuditConduct: async (savePhase) => {
    const { dsAuditChecklistList } = get();
    //const questionUpdateList = dsAuditQuestionList.filter((info) => info.updated);
    //const questionUpdateList = dsAuditChecklistList.filter((info) => info.updated);

    const { formValue } = get();

    // 단계설정 : CONDUCT or CAR
    formValue.phase = savePhase;

    // findingInfo 배열형태로 변환
    const newFindinglist = [];

    // const objectChecklist = { ...formValue.checklistInfo };
    // Object.values(objectChecklist).map((value) => {
    //   newFindinglist.push({ checklistId: value });
    // });

    //const { dsAuditChecklistList } = get();
    //dsAuditChecklistList[currentChecklistIndex].chapterInfo[currentChapterTabIndex].questionInfo[questionIndex][
    //  keyName
    //] = value;

    dsAuditChecklistList.forEach((checklistInfo) => {
      checklistInfo.chapterInfo.forEach((chapterInfo) => {
        chapterInfo.questionInfo.forEach((questionInfo) => {
          //const questionUpdateList = questionInfo.filter((info) => info.updated);
          if (questionInfo.updated) {
            newFindinglist.push({
              auditId: formValue.auditId,
              checklistId: checklistInfo.checklistId,
              chapterId: chapterInfo.chapterId,
              questionId: questionInfo.questionId,
              findingType: questionInfo.findingType === null ? 'Yes' : questionInfo.findingType,
              comment: questionInfo.comment,
            });
          }
        });
      });
    });

    if (formValue.isFinding === 'Y' && newFindinglist.length === 0) {
      ModalService.alert({
        body: 'Finding / Observation 정보를 입력하십시오.',
      });
      return false;
    }

    formValue.findingInfo = newFindinglist;

    const apiParam = {
      ...formValue,
    };

    //debugger;

    await ApiService.post('avn/audit/my-audit/2/conduct', apiParam).then((apiResult) => {
      //const returnAuditId = apiResult.data;
      const returnAuditId = apiResult.ItemCount;
      //if (returnAuditId) {
      //  ToastService.error(returnAuditId);
      //} else {
      ToastService.success('Audit 정보가 저장되었습니다.');
      if (savePhase === 'CAR') {
        // Audit 재설정
        const { getAuditInfo } = useMyAuditFrameStore.getState();
        getAuditInfo(returnAuditId);
      }
      //}
    });
  },
}));

export default useMyAuditConductStore;
