import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppFileAttach from '@/components/common/AppFileAttach';

/* yup validation */
const yupFormSchema = yup.object({
  titleKo: yup.string().required(),
  popupFromDt: yup.string().required(),
  popupToDt: yup.string().required(),
  bannerType: yup.string().required(),
  linkKo: yup.string(),
  fileGroupSeq: yup.number().nullable(),
  useYn: yup.string().required(),
  viewOrder: yup.number(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  titleKo: '',
  popupFromDt: '',
  popupToDt: '',
  bannerType: '',
  linkKo: '',
  fileGroupSeq: null,
  useYn: '',
  viewOrder: null,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/board/photos',
  baseRoutePath: '/aviation/board-manage/banner-manage',
  formName: 'AvnBannerManageFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const AvnBannerManageFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue }, formType: FORM_TYPE_ADD });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function BannerManageEdit() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    AvnBannerManageFormStore();

  const { titleKo, popupFromDt, popupToDt, bannerType, linkKo, fileGroupSeq, useYn, viewOrder } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>배너관리 {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnBannerManageFormStoretitleKo"
                name="titleKo"
                label="제목"
                value={titleKo}
                onChange={(value) => changeInput('titleKo', value)}
                errorMessage={errors.titleKo}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* 해당 코드로 캘린더 한줄 입력 */}
        {/* 추가로 캘린더 클릭 이벤트 추가 해야 함 */}
        {/* <div className="form-cell wid100">
          <div className="form-group form-glow">
            <div className="df">
              <div className="date1">
                <AppDatePicker label="등록일자" />
              </div>
              <span className="unt">~</span>
              <div className="date2">
                <AppDatePicker label="등록일자" />
              </div>
            </div>
          </div>
        </div> */}
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnBannerManageFormStorepopupFromDt"
                name="popupFromDt"
                label="게시시작일자"
                value={popupFromDt}
                onChange={(value) => changeInput('popupFromDt', value)}
                errorMessage={errors.popupFromDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnBannerManageFormStorepopupToDt"
                name="popupToDt"
                label="게시종료일자"
                value={popupToDt}
                onChange={(value) => changeInput('popupToDt', value)}
                errorMessage={errors.popupToDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                apiUrl={`com/code-groups/CODE_GRP_151/codes`}
                applyAllSelect
                allValue=""
                allLabel="선택"
                id="AvnBannerManageFormStorebannerType"
                name="bannerType"
                label="배너구분"
                labelKey="codeNameKor"
                valueKey="codeId"
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={bannerType}
                onChange={(value) => changeInput('bannerType', value)}
                errorMessage={errors.bannerType}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* linkGroupAttach 여부 질문 */}
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnBannerManageFormStoreStorelinkKo"
                name="linkKo"
                label="URL"
                value={linkKo}
                onChange={(value) => changeInput('linkKo', value)}
                errorMessage={errors.linkKo}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* 파일첨부영역 : drag */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppFileAttach
                label="파일첨부"
                fileGroupSeq={fileGroupSeq}
                workScope={'A'}
                onlyImageUpload={true}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileGroupSeq', newFileGroupSeq);
                }}
                maxCount={1}
              />
              <span style={{ color: 'red' }}>* 이미지 규격은 가로 ***px, 세로 ***px 입니다.</span>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                apiUrl={`com/code-groups/CODE_GRP_146/codes`}
                applyAllSelect
                allValue=""
                allLabel="선택"
                id="AvnBannerManageFormStoreuseYn"
                name="useYn"
                label="사용여부"
                labelKey="codeNameKor"
                valueKey="codeId"
                value={useYn}
                onChange={(value) => changeInput('useYn', value)}
                errorMessage={errors.useYn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnBannerManageFormStoreviewOrder"
                name="viewOrder"
                label="정렬순서"
                value={viewOrder}
                onChange={(value) => changeInput('viewOrder', value)}
                errorMessage={errors.viewOrder}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default BannerManageEdit;
