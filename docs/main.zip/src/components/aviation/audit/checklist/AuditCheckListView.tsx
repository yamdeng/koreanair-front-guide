import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
//import { useState } from 'react';
import useCheckListStore from '@/stores/aviation/audit/checklist/useCheckListStore';
import AppSelect from '@/components/common/AppSelect';
import AppNavigation from '@/components/common/AppNavigation';
//import AppTextInput from '@/components/common/AppTextInput';
//import { getAllData } from '@/data/grid/example-data-new';
//import { testColumnInfos } from '@/data/grid/table-column';
import ChecklistDelModal from './ChecklistDelModal';

function AuditCheckListView() {
  //const [inputValue, setInputValue] = useState('');
  //const rowData = getAllData();
  //const columns = testColumnInfos;

  const { division, checklistOrigId, chapterOrigId } = useParams();

  const {
    setAuditChapterParam,
    dsAuditChapterList,
    currentChapterTabIndex,
    changeChapterTabIndex,
    dsAuditQuestionList,
    changeRevision,
    currentRevision,
    isLastRevision,
    revisions,
    clearView,
    selChecklistName,

    openCheckListDelModal,
    closeCheckListDelModal,
    isCheckListDelModal,
    okChecklistDelModal,

    printChecklistPage,
    editSelectedChapter,
    currentChapterOrigId,
    moveToListPage,
  } = useCheckListStore();

  const init = async () => {
    setAuditChapterParam(division, checklistOrigId, chapterOrigId);
  };

  useEffect(() => {
    init();
    return clearView;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="editbox Audit">
        <>
          <div className="form-table line">
            <div className="form-cell wid50">
              <div className="form-group wid100 Position-w h40">
                <span className="tit-head">{selChecklistName}</span>
              </div>
            </div>
            <div className="form-cell  Position-w">
              <div className="Position-end">
                <div className="number-r ">
                  <div className="title">Revision</div>
                  <div className="form-group wid100">
                    <AppSelect
                      id="checklistRevisions"
                      options={revisions}
                      value={currentRevision}
                      labelKey="revision"
                      valueKey="revision"
                      onChange={(appSelectValue) => {
                        changeRevision(appSelectValue);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <hr className="line dp-n"></hr>
        </>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="swiper-container">
          <div className="menu-tab Audit">
            {dsAuditChapterList.map((checklistInfo) => {
              const { chapters } = checklistInfo;
              //console.log('dsAuditChapterList length :' + dsAuditChapterList.length);
              //console.log('chapters length :' + chapters.length);
              return chapters.map((chapterInfo, index) => {
                const { chapterId, chapterName, questionCount } = chapterInfo;
                return (
                  <a
                    key={chapterId}
                    href="javascript:void(0);"
                    className={currentChapterTabIndex === index ? 'active' : ''}
                    data-label={chapterName}
                    onClick={() => changeChapterTabIndex(index)}
                  >
                    {chapterName} <em>({questionCount})</em>
                  </a>
                );
              });
            })}
          </div>

          <div className="menu-tab-nav-operations">
            <button type="button" name="button" className="menu-tab-nav-more">
              <span className="hide">더보기</span>
            </button>
            {/*<button type="button" name="button" className="menu-tab-btn-next">
              <span className="hide">다음 탭메뉴</span>
            </button>*/}
          </div>
        </div>
      </div>

      <div className="checklist-contents edit Audit">
        {/* 상세페이지 */}
        {dsAuditQuestionList.map((questionInfo) => {
          const {
            questionId,
            content,
            refManual,
            priorityNm,
            probabilityNm,
            severityNm,
            priorityColor,
            probabilityColor,
            severityColor,
          } = questionInfo;
          return (
            <div key={questionId} className="editbox">
              <div className="form-table line">
                <div className="form-cell wid100">
                  <div className="form-group wid100">
                    <div className="box-view-list Audit">
                      <ul className="view-list">
                        <li className="accumlate-list">
                          {/* <label className="t-label">Contents</label> */}
                          <span className="text-desc-type1">{content}</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="form-table line">
                <div className="form-cell wid100">
                  <div className="form-group wid100">
                    <div className="box-view-list Audit">
                      <ul className="view-list">
                        <li className="accumlate-list">
                          {/* <label className="t-label">Reference manual</label> */}
                          <span className="text-desc-type1">{refManual}</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="form-table">
                <div className="form-cell wid30">
                  <div className="form-group wid100">
                    <div className="group-box-wrap wid100">
                      <span className="txt">Priority</span>
                      <div className="editarea-box view">
                        <div className="label-box bwid50">
                          <span className={priorityColor}>{priorityNm}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <div className="group-box-wrap wid100">
                      <span className="txt">Probability</span>
                      <div className="editarea-box view">
                        <div className="label-box wid50">
                          <span className={probabilityColor}>{probabilityNm}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <div className="group-box-wrap wid100">
                      <span className="txt">Severity</span>
                      <div className="editarea-box view">
                        <div className="label-box wid50">
                          <span className={severityColor}>{severityNm}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <hr className="line dp-n"></hr>
            </div>
          );
        })}
        {/*//상세페이지*/}
      </div>

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={printChecklistPage}
        >
          Print
        </button>
        <button
          type="button"
          name="deletebutton"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={openCheckListDelModal}
          disabled={!isLastRevision}
        >
          Delete
        </button>
        <button
          type="button"
          name="editbutton"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={() => editSelectedChapter(division, checklistOrigId, currentChapterOrigId)}
          disabled={!isLastRevision}
        >
          Edit
        </button>
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={moveToListPage}
        >
          List
        </button>
      </div>
      {/*//하단버튼영역*/}
      <ChecklistDelModal
        isOpen={isCheckListDelModal}
        openModalParam={[checklistOrigId, selChecklistName]}
        closeModal={closeCheckListDelModal}
        ok={(formValue) => okChecklistDelModal(formValue)}
      />
    </>
  );
}

export default AuditCheckListView;
