function AviationPortal() {
  return <div>AviationPortal</div>;
}

export default AviationPortal;
