import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppSelect from '@/components/common/AppSelect';
import AppTextArea from '@/components/common/AppTextArea';
import AppTextInput from '@/components/common/AppTextInput';
import Code from '@/config/Code';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';
import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import { useImmer } from 'use-immer';
import * as yup from 'yup';

const yupFormSchema = yup.object({
  year: yup.string().required(),
  spiCode: yup.string().required().max(50, '50자 이내로 작성해주세요.'),
  spiName: yup.string().required().max(50, '50자 이내로 작성해주세요.'),
  spiType: yup.string().required(),
  spiTaxonomy: yup.string().required(),
  outputStnd: yup.string().required(),
  spiDescr: yup.string().max(500, '500자 이내로 작성해주세요.'),
  dataSource: yup.string().max(50, '50자 이내로 작성해주세요.'),
  cautionPoint: yup.number().nullable().min(0, '최소값은 0입니다.'),
  warnPoint: yup.number().nullable().min(0, '최소값은 0입니다.'),
  criticalPoint: yup.number().nullable().min(0, '최소값은 0입니다.'),
  sptPoint: yup.number().nullable().min(0, '최소값은 0입니다.'),
  useYn: yup.string().required(),
  viewOrder: yup.number().required().min(0, '최소값은 0입니다.'),
});
const initFormValue = {
  year: '',
  spiCode: '',
  spiName: '',
  spiType: '',
  spiTaxonomy: '',
  outputStnd: '',
  spiDescr: '',
  dataSource: '',
  cautionPoint: null,
  warnPoint: null,
  criticalPoint: null,
  sptPoint: null,
  useYn: 'Y',
  viewOrder: 1,
};

const formName = 'PSPINewModal';

function PSPINewModal(props) {
  const { isOpen, closeModal, ok, searchInfo, rowData } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});

  const {
    year,
    spiCode,
    spiName,
    spiType,
    spiTaxonomy,
    outputStnd,
    spiDescr,
    dataSource,
    cautionPoint,
    warnPoint,
    criticalPoint,
    sptPoint,
    useYn,
    viewOrder,
  } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
  };

  const handleOk = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;

    if (success) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          if (Object.keys(rowData).length != 0) {
            await ApiService.put(`avn/assurance/spi-spt/indicators/${rowData.spiCode}`, formValue).then((apiResult) => {
              ToastService.success('저장되었습니다.');
              ok(formValue);
            });
          } else {
            await ApiService.post(`avn/assurance/spi-spt/indicators`, formValue).then((apiResult) => {
              const detailInfo = apiResult.data;
              if (detailInfo) {
                ToastService.error(detailInfo);
              } else {
                ToastService.success('저장되었습니다.');
                ok(formValue);
              }
            });
          }
        },
      });
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  const handleClose = () => {
    setFormValue({ ...initFormValue });
    closeModal();
  };

  useEffect(() => {
    if (isOpen && searchInfo) {
      // const { loadYear, loadSpiType, createYear } = searchInfo;
      const { spiType, year } = searchInfo;
      changeInput('year', year);
      changeInput('spiType', spiType);
    }

    if (isOpen && Object.keys(rowData).length != 0) {
      setFormValue({ ...rowData });
    }
  }, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'alert-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">지표 신규</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              <div className="editbox">
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppDatePicker
                        id="PSPINewModalyear"
                        label="생산연도"
                        value={year}
                        pickerType="year"
                        required
                        disabled
                        errorMessage={errors.year}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        id="PSPINewModalspiType"
                        label={'지표구분'}
                        codeGrpId="CODE_GRP_113"
                        required
                        disabled
                        value={spiType}
                        errorMessage={errors.spiType}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        id="PSPINewModalspiTaxonomy"
                        label={'지표분류'}
                        codeGrpId="CODE_GRP_114"
                        required
                        value={spiTaxonomy}
                        onChange={(value) => changeInput('spiTaxonomy', value)}
                        errorMessage={errors.spiTaxonomy}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        id="PSPINewModaloutputStnd"
                        label={'산출기준'}
                        codeGrpId="CODE_GRP_116"
                        required
                        value={outputStnd}
                        onChange={(value) => changeInput('outputStnd', value)}
                        errorMessage={errors.outputStnd}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="PSPINewModalspiCode"
                        label="지표코드"
                        placeholder="지표코드를 입력해 주세요"
                        required
                        disabled={rowData.spiCode ? true : false}
                        value={spiCode}
                        onChange={(value) => changeInput('spiCode', value.toUpperCase())}
                        errorMessage={errors.spiCode}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="PSPINewModalspiName"
                        label={'지표명'}
                        placeholder="지표명을 입력해 주세요"
                        required
                        value={spiName}
                        onChange={(value) => changeInput('spiName', value)}
                        errorMessage={errors.spiName}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextArea
                        id="PSPINewModalspiDescr"
                        label="지표정의"
                        value={spiDescr}
                        onChange={(value) => changeInput('spiDescr', value)}
                        errorMessage={errors.spiDescr}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="PSPINewModalcautionPoint"
                        inputType="number"
                        label="주의"
                        value={cautionPoint}
                        onChange={(value) => changeInput('cautionPoint', value)}
                        errorMessage={errors.cautionPoint}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="PSPINewModalwarnPoint"
                          inputType="number"
                          label="경계"
                          value={warnPoint}
                          onChange={(value) => changeInput('warnPoint', value)}
                          errorMessage={errors.warnPoint}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="PSPINewModalcriticalPoint"
                          inputType="number"
                          label="심각"
                          value={criticalPoint}
                          onChange={(value) => changeInput('criticalPoint', value)}
                          errorMessage={errors.criticalPoint}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="PSPINewModalsptPoint"
                          inputType="number"
                          label="목표치(SPT)"
                          placeholder="목표치(SPT)를 입력해 주세요"
                          value={sptPoint}
                          onChange={(value) => changeInput('sptPoint', value)}
                          errorMessage={errors.sptPoint}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="PSPINewModalviewOrder"
                          inputType="number"
                          label="표시 순서"
                          required
                          placeholder="순서를 입력해 주세요"
                          value={viewOrder}
                          onChange={(value) => changeInput('viewOrder', value)}
                          errorMessage={errors.viewOrder}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppSelect
                          id="PSPINewModaluseYn"
                          name="useYn"
                          label="사용여부"
                          options={Code.useYn}
                          value={useYn}
                          onChange={(appSelectValue) => {
                            changeInput('useYn', appSelectValue);
                          }}
                          required
                          errorMessage={errors.useYn}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
              </div>
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleOk}>
            {rowData.spiCode ? '수정' : '저장'}
          </button>
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            닫기
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default PSPINewModal;
