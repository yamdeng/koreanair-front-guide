import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppTable from '@/components/common/AppTable';
import {
  hzdTabGrd1Store,
  hzdTabGrd2Store,
  hzdTabGrd3Store,
  useHzrTopRiskListStore,
  useSmsIntgrAnlysDashBoardStore,
} from '@/stores/aviation/assurance/smsComprehensive/useSmsIntgrAnlysDashBoardStore';
import CommonUtil from '@/utils/CommonUtil';
import { useState } from 'react';

function HzrTopRiskList() {
  // PotencialConListStore 에서 정의된 메소드 사용 시 이곳에서 분해할당
  const mainState = useSmsIntgrAnlysDashBoardStore();
  const state = useHzrTopRiskListStore();
  const hzdTabGrd1StoreState = hzdTabGrd1Store();
  const hzdTabGrd2StoreState = hzdTabGrd2Store();
  const hzdTabGrd3StoreState = hzdTabGrd3Store();

  const { searchParam, changeSearchInput, search, clear } = state;

  const { division, reportType, fromDate, toDate } = searchParam;

  function goHazardDetail(params) {
    return (
      <div className="Safety-table-cell tr">
        <a
          href="#"
          onClick={() => {
            mainState.openReport('hazard', params.data);
          }}
        >
          {Number(params.value).toLocaleString()}
        </a>
      </div>
    );
  }

  function goSummaryDetailInfo(params) {
    return (
      <div className="Safety-table-cell">
        <a
          href="#"
          onClick={() => {
            hzdTabGrd1StoreState.selectSummaryRowInfo(params.data);
          }}
        >
          {params.value}
        </a>
      </div>
    );
  }

  const [columns1, setColumns1] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호', cellStyle: { textAlign: 'center' } },
      { field: 'col01', headerName: 'Hazard Level3', cellRenderer: goSummaryDetailInfo },
      {
        field: 'col02',
        headerName: 'Risk 값 합계',
        valueFormatter: (p) => Number(p.value).toLocaleString(),
        cellStyle: (params) => {
          const cellStyleInfo = { textAlign: 'right' };

          if (params.data.num === 1) {
            return { ...cellStyleInfo, backgroundColor: '#56ACFF' };
          } else if (params.data.num === 2) {
            return { ...cellStyleInfo, backgroundColor: '#8FC8FF' };
          } else if (params.data.num === 3) {
            return { ...cellStyleInfo, backgroundColor: '#C7E3FF' };
          } else {
            return { ...cellStyleInfo, backgroundColor: '#EBF5FF' };
          }
        },
      },
      {
        field: 'col03',
        headerName: '빈도수',
        valueFormatter: (p) => Number(p.value).toLocaleString(),
        cellStyle: { textAlign: 'right' },
        cellRenderer: goHazardDetail,
      },
    ])
  );

  const [columns2, setColumns2] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호', cellStyle: { textAlign: 'center' } },
      { field: 'col01', headerName: 'Hazard Level3', cellStyle: { textAlign: 'center' } },
      { field: 'col02', headerName: '잠재결과', cellStyle: { textAlign: 'left' } },
      { field: 'col03', headerName: '해당부문', cellStyle: { textAlign: 'center' } },
      {
        field: 'col04',
        headerName: '단일Risk값',
        cellStyle: { textAlign: 'right' },
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
    ])
  );

  const [columns3, setColumns3] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호', cellStyle: { textAlign: 'center' } },
      { field: 'col01', headerName: 'Hazard Level3', cellStyle: { textAlign: 'center' } },
      {
        field: 'col02',
        headerName: 'Risk 값 평균',
        cellStyle: { textAlign: 'right' },
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
      {
        field: 'col03',
        headerName: '빈도수',
        cellStyle: { textAlign: 'right' },
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
    ])
  );

  return (
    <>
      {/*검색영역 */}
      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid20">
            <div className="form-group wid100">
              <div className="date1">
                <AppCodeSelect
                  label={'부문'}
                  codeGrpId="CODE_GRP_145"
                  value={division}
                  isMultiple
                  onChange={(value) => {
                    changeSearchInput('division', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-cell wid20">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'보고서구분'}
                codeGrpId="CODE_GRP_149"
                value={reportType}
                isMultiple
                onChange={(value) => {
                  changeSearchInput('reportType', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <div className="df">
                <div className="date1">
                  <AppDatePicker
                    label="시작일자"
                    value={fromDate}
                    onChange={(value) => {
                      changeSearchInput('fromDate', value);
                    }}
                    pickerType="date"
                    required
                  />
                </div>
                <span className="unt">~</span>
                <div className="date2">
                  <AppDatePicker
                    label="종료일자"
                    value={toDate}
                    onChange={(value) => {
                      changeSearchInput('toDate', value);
                    }}
                    pickerType="date"
                    required
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={search}>
              조회
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={clear}>
              초기화
            </button>
          </div>
        </div>
      </div>
      {/* //검색영역 */}
      {/*대시보드*/}
      <div className="DashBoardWrap">
        <div className="DashBoard-chart">
          <div className="DashBoard-row">
            <div className="DashBoard-col">
              <p className="h4">1. Risk 값 합계</p>
              <div className="DashBoard-box">
                <AppTable rowData={hzdTabGrd1StoreState.list} columns={columns1} store={hzdTabGrd1StoreState} />
              </div>
            </div>
          </div>
          <div className="DashBoard-row">
            <div className="DashBoard-col">
              <p className="h4">2. 부문 단일 Risk값</p>
              <div className="DashBoard-box">
                <AppTable rowData={hzdTabGrd2StoreState.list} columns={columns2} store={hzdTabGrd2StoreState} />
              </div>
            </div>
          </div>
          <div className="DashBoard-row">
            <div className="DashBoard-col">
              <p className="h4">3. Risk 값 평균</p>
              <div className="DashBoard-box">
                <AppTable rowData={hzdTabGrd3StoreState.list} columns={columns3} store={hzdTabGrd3StoreState} />
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*//대시보드 */}
    </>
  );
}

export default HzrTopRiskList;
