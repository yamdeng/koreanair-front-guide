import { useEffect, useState } from 'react';

import AppEditor from '@/components/common/AppEditor';
import AppTextInput from '@/components/common/AppTextInput';
import { useParams } from 'react-router-dom';
//import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppCodeSelect from '@/components/common/AppCodeSelect';
/* TODO : store 경로를 변경해주세요. */
import useOcuHsCommitteeFormStore from '@/stores/occupation/general/useOcuHsCommitteeFormStore';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuHsCommitteeForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, formValue, getDetail, formType, cancel, save, remove, clear } =
    useOcuHsCommitteeFormStore();
  const {
    // 본부
    advCmitSectCd,
    // 부서
    advCmitDeptCd,
    // 팀
    advCmitDeptCd2,
    // 그룹
    advCmitDeptCd3,
    // 작성자
    regUserId,
    // 작성일자
    regDttm,
    // 해당연월
    advCmitImplmYm,
    // 제목
    advCmitTitle,
    // 내용
    advCmitRemark,

    // 회의록
    prcdnFileId,
    // 회의자료
    meetDocFileId,
    // 보고문서
    //reportDocLinkId,

    // advCmitId,
  } = formValue;
  const { detailId } = useParams();

  const profile = useStore(useAppStore, (state) => state.profile);
  // 사용자명
  const nameKor = profile.userInfo.nameKor;

  // 오늘 날짜
  const toDate = CommonUtil.getToDate();

  const [isOrgSelectModalopen, setIsOrgSelectModalopen] = useState(false);

  const handleOrgSelectModal = (selectedValue) => {
    console.log(selectedValue);
    setIsOrgSelectModalopen(false);
  };

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  console.log('detailId==>', detailId);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>안전보건협의체</h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'부문'}
                codeGrpId="CODE_GRP_OC001"
                value={advCmitSectCd}
                onChange={(value) => changeInput('advCmitSectCd', value)}
                required
                disabled
                errorMessage={errors.advCmitSectCd}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label={'부서'}
                value={advCmitDeptCd}
                onChange={(value) => changeInput('advCmitDeptCd', value)}
                required
                disabled
                errorMessage={errors.advCmitDeptCd}
              />

              {/* <OrgTreeSelectModal
                label={'부서'}
                isOpen={isOrgSelectModalopen}
                closeModal={() => setIsOrgSelectModalopen(false)}
                isMultiple={false}
                ok={handleOrgSelectModal}
              /> */}
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label={'팀'}
                value={advCmitDeptCd2}
                onChange={(value) => changeInput('advCmitDeptCd2', value)}
                required
                disabled
                errorMessage={errors.advCmitDeptCd2}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label={'그룹'}
                value={advCmitDeptCd3}
                onChange={(value) => changeInput('advCmitDeptCd3', value)}
                required
                disabled
                errorMessage={errors.advCmitDeptCd3}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="작성자"
                //value= {regUserId}
                value={detailId === 'add' ? nameKor : regUserId}
                //onChange={(value) => changeInput('regUserId', value)}
                onChange={(value) => changeInput(detailId === 'add' ? 'nameKor' : 'regUserId', value)}
                required
                disabled="false"
                // errorMessage={errors.regUserId}
                errorMessage={detailId === 'add' ? errors.nameKor : errors.regUserId}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                disabled
                label="작성일자"
                // value={regDttm}
                value={detailId === 'add' ? toDate : regDttm}
                // onChange={(value) => changeInput('regDttm', value)}
                onChange={(value) => changeInput(detailId === 'add' ? 'toDate' : 'regDttm', value)}
                required
                // errorMessage={errors.regDttm}
                errorMessage={detailId === 'add' ? errors.toDate : errors.regDttm}
              />
            </div>
          </div>

          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDatePicker
                label={'해당연월'}
                pickerType="month"
                value={advCmitImplmYm}
                onChange={(value) => {
                  changeInput('advCmitImplmYm', value);
                }}
                required
                errorMessage={errors.advCmitImplmYm}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="제목"
                value={advCmitTitle}
                onChange={(value) => changeInput('advCmitTitle', value)}
                required
                errorMessage={errors.advCmitTitle}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppEditor
                placeholder="입력해주세요."
                value={advCmitRemark}
                onChange={(value) => changeInput('advCmitRemark', value)}
                required
                errorMessage={errors.advCmitRemark}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppFileAttach
                mode="edit"
                label="회의록 업로드(pdf, 그림파일)"
                fileGroupSeq={prcdnFileId}
                workScope={'O'}
                maxCount={1}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('prcdnFileId', newFileGroupSeq);
                }}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppFileAttach
                mode="edit"
                label="회의자료 업로드(ppt)"
                fileGroupSeq={meetDocFileId}
                workScope={'O'}
                onlyImageUpload={false}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('meetDocFileId', newFileGroupSeq);
                }}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="group-box-wrap line wid100">
              <span className="txt">보고문서 Link</span>

              <button type="button" name="button" className="btn-plus">
                추가
              </button>
              <div className="file-link">
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link첨부Link첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuHsCommitteeForm;
