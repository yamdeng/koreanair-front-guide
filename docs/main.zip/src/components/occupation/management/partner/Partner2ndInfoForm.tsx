import { useEffect, useState, useCallback } from 'react';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import AppTable from '@/components/common/AppTable';
import useOcuPartnerPlaceFormStore from '@/stores/occupation/management/useOcuPartnerPlaceFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuPartnerPlaceForm() {
  const {
    search,
    setFormValue,
    list,
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    remove,
    clear,
    save,
    clearForm,
  } = useOcuPartnerPlaceFormStore();

  const {
    bizPlaceClsCd,
    useSectCd,
    mgntDeptCd,
    staffNm1,
    staffContactNo1,
    staffEmail1,
    staffWork1,
    staffNm2,
    staffContactNo2,
    staffEmail2,
    staffWork2,
    sftyMgnt,
    hlthMgnt,
    majorWorkCn,
  } = formValue;

  const { detailId } = useParams();

  const [columns, setColumns] = useState([
    { field: 'bizPlaceClsCd', headerName: '사업장_분류_코드' },
    { field: 'useSectCd', headerName: '사용부문_코드' },
  ]);

  const init = async () => {
    await getDetail(detailId);
    search();
  };

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const params = selectedInfo.data;
    setFormValue(params, params.bizPlaceId);
  }, []);

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      init();
      changeInput('prtnrId', detailId);
    } else {
      changeInput('prtnrId', '');
    }
    return clear;
  }, []);

  return (
    <>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid30">
            <AppTable
              rowData={list}
              columns={columns}
              setColumns={setColumns}
              handleRowDoubleClick={handleRowDoubleClick}
            />
          </div>
          <div className="form-cell wid70">
            <h2>사업장 등록</h2>
            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormbizPlaceClsCd"
                    name="bizPlaceClsCd"
                    label="사업장_분류_코드"
                    value={bizPlaceClsCd}
                    onChange={(value) => changeInput('bizPlaceClsCd', value)}
                    errorMessage={errors.bizPlaceClsCd}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormuseSectCd"
                    name="useSectCd"
                    label="사용부문_코드"
                    value={useSectCd}
                    onChange={(value) => changeInput('useSectCd', value)}
                    errorMessage={errors.useSectCd}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormmgntDeptCd"
                    name="mgntDeptCd"
                    label="관리부서_코드"
                    value={mgntDeptCd}
                    onChange={(value) => changeInput('mgntDeptCd', value)}
                    errorMessage={errors.mgntDeptCd}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormstaffNm1"
                    name="staffNm1"
                    label="담당자_명1"
                    value={staffNm1}
                    onChange={(value) => changeInput('staffNm1', value)}
                    errorMessage={errors.staffNm1}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormstaffContactNo1"
                    name="staffContactNo1"
                    label="담당자_연락처1"
                    value={staffContactNo1}
                    onChange={(value) => changeInput('staffContactNo1', value)}
                    errorMessage={errors.staffContactNo1}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormstaffEmail1"
                    name="staffEmail1"
                    label="담당자_이메일1"
                    value={staffEmail1}
                    onChange={(value) => changeInput('staffEmail1', value)}
                    errorMessage={errors.staffEmail1}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormstaffWork1"
                    name="staffWork1"
                    label="담당자_업무1"
                    value={staffWork1}
                    onChange={(value) => changeInput('staffWork1', value)}
                    errorMessage={errors.staffWork1}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormstaffNm2"
                    name="staffNm2"
                    label="담당자_명2"
                    value={staffNm2}
                    onChange={(value) => changeInput('staffNm2', value)}
                    errorMessage={errors.staffNm2}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormstaffContactNo2"
                    name="staffContactNo2"
                    label="담당자_연락처2"
                    value={staffContactNo2}
                    onChange={(value) => changeInput('staffContactNo2', value)}
                    errorMessage={errors.staffContactNo2}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormstaffEmail2"
                    name="staffEmail2"
                    label="담당자_이메일2"
                    value={staffEmail2}
                    onChange={(value) => changeInput('staffEmail2', value)}
                    errorMessage={errors.staffEmail2}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormstaffWork2"
                    name="staffWork2"
                    label="담당자_업무2"
                    value={staffWork2}
                    onChange={(value) => changeInput('staffWork2', value)}
                    errorMessage={errors.staffWork2}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormsftyMgnt"
                    name="sftyMgnt"
                    label="안전관리"
                    value={sftyMgnt}
                    onChange={(value) => changeInput('sftyMgnt', value)}
                    errorMessage={errors.sftyMgnt}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormhlthMgnt"
                    name="hlthMgnt"
                    label="보건관리"
                    value={hlthMgnt}
                    onChange={(value) => changeInput('hlthMgnt', value)}
                    errorMessage={errors.hlthMgnt}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <AppTextInput
                    id="OcuPartnerPlaceFormmajorWorkCn"
                    name="majorWorkCn"
                    label="주요업무"
                    value={majorWorkCn}
                    onChange={(value) => changeInput('majorWorkCn', value)}
                    errorMessage={errors.majorWorkCn}
                    required
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={clearForm}>
          초기화
        </button>
      </div>
    </>
  );
}
export default OcuPartnerPlaceForm;
