import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/partner',
  baseRoutePath: '/occupation/management/partner',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  searchWord: '',
};

/* zustand store 생성 */
const OcuPartnerInfoListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    searchWord: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function OcuPartnerInfoList() {
  const state = OcuPartnerInfoListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'prtnrNm', headerName: '협력업체_명' },
      { field: 'bizNo', headerName: '사업자_번호' },
      { field: 'rprsn', headerName: '대표자' },
      { field: 'bizIndst', headerName: '업태' },
      { field: 'bizType', headerName: '업종' },
      { field: 'regDttm', headerName: '등록_일시' },
      { field: 'regUserId', headerName: '등록자_ID' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;
  // TODO : 검색 파라미터 나열
  const { prtnrNm, bizNo, rprsn, bizIndst, bizType } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    const detailId = data.prtnrId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>협력업체</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="협력업체명"
                  value={prtnrNm}
                  onChange={(value) => {
                    changeSearchInput('prtnrNm', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100 mr5">
                <AppSearchInput
                  label="사업자번호"
                  value={bizNo}
                  onChange={(value) => {
                    changeSearchInput('bizNo', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100 mr5">
                <AppSearchInput
                  label="대표자"
                  value={rprsn}
                  onChange={(value) => {
                    changeSearchInput('rprsn', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100 mr5">
                <AppSearchInput
                  label="업태"
                  value={bizIndst}
                  onChange={(value) => {
                    changeSearchInput('bizIndst', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100 mr5">
                <AppSearchInput
                  label="업종"
                  value={bizType}
                  onChange={(value) => {
                    changeSearchInput('bizType', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              초기화
            </button>
          </div>
        </div>
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">접기</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default OcuPartnerInfoList;
