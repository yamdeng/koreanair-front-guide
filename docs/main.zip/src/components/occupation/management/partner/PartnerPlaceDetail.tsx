import { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
// import { Viewer } from '@toast-ui/react-editor';
// import AppFileAttach from '@/components/common/AppFileAttach';
import AppTable from '@/components/common/AppTable';
//import useOcuPartnerInfoFormStore from '@/stores/occupation/management/useOcuPartnerPlaceFormStore';
import useOcuPartnerPlaceFormStore from '@/stores/occupation/management/useOcuPartnerPlaceFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuPartnerPlaceDetail() {
  /* formStore state input 변수 */
  const { setFormValue, detailInfo, getDetail, clear, list, search } = useOcuPartnerPlaceFormStore();
  const {
    bizPlaceClsCd,
    useSectCd,
    mgntDeptCd,
    staffNm1,
    staffContactNo1,
    staffEmail1,
    staffWork1,
    staffNm2,
    staffContactNo2,
    staffEmail2,
    staffWork2,
    sftyMgnt,
    hlthMgnt,
    majorWorkCn,
  } = detailInfo;

  const { detailId } = useParams();

  const [columns, setColumns] = useState([
    { field: 'bizPlaceClsCd', headerName: '사업장_분류_코드' },
    { field: 'useSectCd', headerName: '사용부문_코드' },
  ]);

  const init = async () => {
    await getDetail(detailId);
    search();
  };
  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const params = selectedInfo.data;
    setFormValue(params);
  }, []);

  useEffect(() => {
    init();

    return clear;
  }, []);

  return (
    <>
      <div className="eidtbox">
        <div className="form-table" style={{ display: 'flex' }}>
          <div className="form-cell wid30">
            <AppTable
              rowData={list}
              columns={columns}
              setColumns={setColumns}
              handleRowDoubleClick={handleRowDoubleClick}
            />
          </div>
          <div className="form-cell wid70">
            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">사업장_분류_코드</label>
                        <span className="text-desc-type1">{bizPlaceClsCd}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">사용부문_코드</label>
                        <span className="text-desc-type1">{useSectCd}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">관리부서_코드</label>
                        <span className="text-desc-type1">{mgntDeptCd}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">담당자_명1</label>
                        <span className="text-desc-type1">{staffNm1}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">담당자_연락처1</label>
                        <span className="text-desc-type1">{staffContactNo1}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">담당자_이메일1</label>
                        <span className="text-desc-type1">{staffEmail1}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">담당자_업무1</label>
                        <span className="text-desc-type1">{staffWork1}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">담당자_명2</label>
                        <span className="text-desc-type1">{staffNm2}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">담당자_연락처2</label>
                        <span className="text-desc-type1">{staffContactNo2}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">담당자_이메일2</label>
                        <span className="text-desc-type1">{staffEmail2}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">담당자_업무2</label>
                        <span className="text-desc-type1">{staffWork2}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">안전관리</label>
                        <span className="text-desc-type1">{sftyMgnt}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">보건관리</label>
                        <span className="text-desc-type1">{hlthMgnt}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>

            <div className="form-table">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">주요업무</label>
                        <span className="text-desc-type1">{majorWorkCn}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>
      </div>
    </>
  );
}
export default OcuPartnerPlaceDetail;
