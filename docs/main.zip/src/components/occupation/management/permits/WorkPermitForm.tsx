import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import useOcuWorkPermitFormStore from '@/stores/occupation/management/useOcuWorkPermitFormStore';
import AppTimePicker from '@/components/common/AppTimePicker';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptReadOnlyInput from '@/components/common/AppDeptReadOnlyInput';
import useAppStore from '@/stores/useAppStore';
import { useStore } from 'zustand';
import CommonUtil from '@/utils/CommonUtil';
import AppUserReadOnlyInput from '@/components/common/AppUserReadOnlyInput';
import AppCheckboxGroup from '@/components/common/AppCheckboxGroup';
import CodeService from '@/services/CodeService';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuWorkPermitForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    useOcuWorkPermitFormStore();

  const profile = useStore(useAppStore, (state) => state.profile);
  console.log(profile.userInfo);
  console.log(profile.userInfo.nameKor);

  // 작성자명 가져오기
  const userNm = profile.userInfo.nameKor;
  // 부서명 가져오기
  const loginDeptCd = profile.userInfo.deptCd;
  // 오늘날짜 가져오기
  const currentDate = CommonUtil.getToDate();

  const {
    // 부문 코드
    sectCd,
    // 부서코드
    deptCd,
    // 공사 ID
    cntrId,
    // 공사 명
    cntrNm,
    // 공사분야코드
    cntrAreaCd,
    // 특별교육 대상 여부 - 03
    spclEduTargetYn,
    // 시공사
    cnstCmpny,
    // 담당자
    staff,
    // 연락처
    contactNo,
    // 공사장소 ID
    cnstrSiteId,
    // 공사위치명
    cntrPositionNm,
    // 공사인원수
    cntrPrsnCnt,
    // 공사신청시작일시
    cntrApplyStartDttm,
    // 공사 신청 종료 일시
    cntrApplyEndDttm,
    // 사전동의여부
    preConsentYn,
    // 신청자 사번
    applyEmpno,
    // 승인자 사번
    aprvEmpno,
    // 승인부서의견
    aprvDeptOpnn,
    // 신청 상태 코드
    applyStatusCd,
    // 작업 상태 코드
    wrkStatusCd,
    // 작업 시작 일자
    wrkStartDt,
    // 작업 시작 비고
    wrkStartRemark,
    // 작업 시작 첨부 사진1 ID
    wrkStartPhoto1Id,
    // 작업 시작 첨부 사진2 ID
    wrkStartPhoto2Id,
    //교육일지 첨부 파일 ID
    eduJrnlFileId,
    // 기타 첨부 파일 ID
    etcFileId,
    // 작업 종료 일자
    wrkEndDt,
    // 작업 종료 비고
    wrkEndRemark,
    // 등록 일시
    regDttm,
    // 등록자 ID
    regUserId,
    // 수정 일시
    updDttm,
    // 수정자 ID
    updUserId,
    cntrWrkCd,
  } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }

    // com/code-groups/CODE_GRP_OC031/codes
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>외주작업허가 등록</h2>
      </div>
      <div className="editbox">
        {/* <div className="info-wrap toggle"> */}
        {/* 신청자정보 */}
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              신청자 정보<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="부문"
                          codeGrpId="CODE_GRP_OC001"
                          value={sectCd} // NEED TO CHANGE LATER
                          onChange={(value) => changeInput('sectCd', value)}
                          required
                          disabled={formType !== 'add' ? true : false}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDeptReadOnlyInput
                          label="부서"
                          value={detailId === 'add' ? loginDeptCd : deptCd}
                          required
                          disabled
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppUserReadOnlyInput
                          label="이름"
                          value={detailId === 'add' ? userNm : regUserId}
                          required
                          disabled="false"
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppUserReadOnlyInput label="연락처" value={contactNo} disabled />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        {/* 승인자정보 */}
        <dt>
          <button type="button" className="btn-tg">
            승인자 정보<span className="active"></span>
          </button>
        </dt>
        <dd className="tg-conts">
          <div className="edit-area">
            <div className="detail-form">
              <div className="detail-list">
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="부문" disabled />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="부서" disabled />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="이름" disabled />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="연락처" disabled />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </dd>
        {/* 공사정보 */}
        <dt>
          <button type="button" className="btn-tg">
            공사 정보<span className="active"></span>
          </button>
        </dt>
        <dd className="tg-conts">
          <div className="edit-area">
            <div className="detail-form">
              <div className="detail-list">
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="공사명"
                        value={cntrNm}
                        onChange={(value) => changeInput('cntrNm', value)}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="group-box-wrap wid100">
                      <AppCheckboxGroup
                        label="공사분야"
                        options={CodeService.getCodeListByCodeGrpId('CODE_GRP_OC031')}
                        value={cntrWrkCd}
                        labelKey={'codeNameKor'}
                        valueKey={'codeId'}
                        onChange={(value) => {
                          changeInput('cntrWrkCd', value);
                        }}
                      />
                      <span className="txt">공사분야</span>
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="group-box-wrap wid100">
                      <span className="txt">특별교육 대상</span>
                      <div className="radio-wrap">
                        <label>
                          <input type="radio" name="spclEduTarget" value="Y" />
                          <span>예</span>
                        </label>
                        <button className="radio-btn">교육내용</button>
                        <label>
                          <input type="radio" name="spclEduTarget" value="N" />
                          <span>아니오</span>
                        </label>
                      </div>
                      {/*<span className="errorText">error</span>*/}
                    </div>
                  </div>
                </div>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="시공사" required />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="담당자" required />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="연락처" required />
                    </div>
                  </div>
                </div>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="공사장소" required />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="공사위치" />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput label="공사인원" required />
                    </div>
                  </div>
                </div>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker label="공사 시작일시" required />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTimePicker label="공사 시작시간" required />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker label="공사 종료일시" required />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTimePicker label="공사 종료시간" required />
                    </div>
                  </div>
                </div>
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">그리드영역</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </dd>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuWorkPermitForm;
