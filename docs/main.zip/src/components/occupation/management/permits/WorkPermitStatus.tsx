import AppDatePicker from '@/components/common/AppDatePicker';
import useOcuWorkPermitStatusStore from '@/stores/occupation/management/useOcuWorkPermitStatusStore';
import { DATE_PICKER_TYPE_MONTH } from '@/config/CommonConstant';
import CommonUtil from '@/utils/CommonUtil';
import classNames from 'classnames';

/*


  1.달력 오픈 제어
  2.현재 월 정보 셋팅 : init
   -초기값으로 셋팅하는 기준이 필요할지 검토
  3.현재 선택된 일 date 정보(1~31)
  4.calendarDateList : 달력의 기준 정보
  5.달 변경 인터페이스
  5-1.이전달
  5-2.다음달
  6.스케줄 목록 정보를 셋팅함
   -클릭 처리

*/

function WorkPermitStatus() {
  const {
    monthDatePickerOpen,
    setMonthDatePickerOpen,
    searchMonth,
    selectedDate,
    calendarDateList,
    changeSelectedDate,
    scheduleList,
    dateScheduleList,
    changeSearchMonth,
    prevMonth,
    nextMonth,
    goAddPage,
    clear,
  } = useOcuWorkPermitStatusStore();

  return (
    <>
      <div className="calendar-box">
        <div className="calendar-wrap">
          <div className="calendar-tit">
            <button className="prevday" onClick={prevMonth}>
              버튼
            </button>

            <h2 className="datetitle">
              <AppDatePicker
                style={{ visibility: 'hidden', width: 0 }}
                onOpenChange={(status) => {
                  setMonthDatePickerOpen(status);
                }}
                open={monthDatePickerOpen}
                hidden
                pickerType={DATE_PICKER_TYPE_MONTH}
                getPopupContainer={(trigger) => {
                  return trigger.parentNode;
                }}
                onChange={(value) => {
                  changeSearchMonth(value);
                }}
                showNow={false}
              />
              <span className="month" onClick={() => setMonthDatePickerOpen(true)}>
                {CommonUtil.convertDate(searchMonth, 'YYYY-MM', 'YYYY.MM')}
              </span>
            </h2>

            <button className="nextday" onClick={nextMonth}>
              버튼
            </button>
          </div>
          <table className="calendar-table">
            <thead>
              <tr>
                <th>일</th>
                <th>월</th>
                <th>화</th>
                <th>수</th>
                <th>목</th>
                <th>금</th>
                <th>토</th>
              </tr>
            </thead>
            <tbody>
              {calendarDateList.map((weekList, index) => {
                return (
                  <tr key={index}>
                    {weekList.map((dateInfo) => {
                      let dateComponent = <td></td>;
                      if (dateInfo) {
                        const { date, isHoliday } = dateInfo;
                        // active가 우선
                        const applyClassName = classNames('cld_day', {
                          s_day: date !== selectedDate && isHoliday,
                          active: date === selectedDate,
                        });
                        dateComponent = (
                          <td key={date} onClick={() => changeSelectedDate(date)}>
                            <div className="cld_date">
                              <div className={applyClassName}>{date}</div>
                              <ul className="schedule" style={{ display: 'none' }}>
                                <li>
                                  <a className="ing" href="javascript:void(0);">
                                    작업중<span>(1)</span>
                                  </a>
                                </li>
                                <li>
                                  <a className="expected" href="javascript:void(0);">
                                    작업예정<span>(2)</span>
                                  </a>
                                </li>
                                <li>
                                  <a className="wait" href="javascript:void(0);">
                                    작업종료대기<span>(1)</span>
                                  </a>
                                </li>
                                <li>
                                  <a className="complete" href="javascript:void(0);">
                                    작업완료<span>(1)</span>
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        );
                      }
                      return dateComponent;
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="calendar-list">
          <h3 className="table-tit">2024년 9월 5일</h3>
          <ul className="schedule-guide">
            <li>
              <span className="expected"></span>작업예정
            </li>
            <li>
              <span className="ing"></span>작업중
            </li>
            <li>
              <span className="complete"></span>작업완료
            </li>
            <li>
              <span className="wait"></span>작업완료대기
            </li>
          </ul>
          <table className="list-table">
            <thead>
              <tr>
                <th>작업상태</th>
                <th>공사명</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="ing">작업 중</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td className="expected">작업예정</td>
                <td>외벽공사</td>
              </tr>
              <tr>
                <td className="wait">작업완료대기</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td className="complete">작업완료</td>
                <td>외벽공사</td>
              </tr>
              <tr>
                <td>작업 중</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td>작업종료대기</td>
                <td>외벽공사</td>
              </tr>
              <tr>
                <td>작업 중</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td>작업종료대기</td>
                <td>외벽공사</td>
              </tr>
              <tr>
                <td>작업 중</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td>작업종료대기</td>
                <td>외벽공사</td>
              </tr>
              <tr>
                <td>작업 중</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td>작업종료대기</td>
                <td>외벽공사</td>
              </tr>
              <tr>
                <td>작업 중</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td>작업종료대기</td>
                <td>외벽공사</td>
              </tr>
              <tr>
                <td>작업 중</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td>작업종료대기</td>
                <td>외벽공사</td>
              </tr>
              <tr>
                <td>작업 중</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td>작업종료대기</td>
                <td>외벽공사</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <h3 className="table-tit">외주작업 신청 현황</h3>
      <div className="">{/* TODO : TABLE을 넣어주세요 */}</div>
      {/*//그리드영역 */}

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          등록
        </button>
      </div>
    </>
  );
}

export default WorkPermitStatus;
