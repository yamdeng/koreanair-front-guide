import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import AppTextInput from '@/components/common/AppTextInput';

function OcuOutSourcingSearchForm() {
  const state = useOcuOutSourcingListStore();

  const {
    cntrId,
    cntrNm,
    cntrAreaCd,
    spclEduTargetYn,
    cnstCmpny,
    staff,
    contactNo,
    cntrLocationCd,
    cntrPositionNm,
    cntrPrsnCnt,
    cntrApplyStartDttm,
    cntrApplyEndDttm,
    preConsentYn,
    applyEmpno,
    aprvEmpno,
    aprvDeptOpnn,
    applyStatusCd,
    wrkStatusCd,
    wrkStartDt,
    wrkStartRemark,
    wrkStartPhoto1Id,
    wrkStartPhoto2Id,
    eduJrnlFileId,
    etcFileId,
    wrkEndDt,
    wrkEndRemark,
    regDttm,
    regUserId,
    updDttm,
    updUserId,
  } = searchParam;

  return (
    <>
      {/* TODO : 검색 input 영역입니다 */}

      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                label="공사_ID"
                value={cntrId}
                onChange={(value) => {
                  changeSearchInput('cntrId', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="공사_명"
                value={cntrNm}
                onChange={(value) => {
                  changeSearchInput('cntrNm', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="공사_분야_코드"
                value={cntrAreaCd}
                onChange={(value) => {
                  changeSearchInput('cntrAreaCd', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="특별교육_대상_여부"
                value={spclEduTargetYn}
                onChange={(value) => {
                  changeSearchInput('spclEduTargetYn', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="시공사"
                value={cnstCmpny}
                onChange={(value) => {
                  changeSearchInput('cnstCmpny', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="담당자"
                value={staff}
                onChange={(value) => {
                  changeSearchInput('staff', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="연락처"
                value={contactNo}
                onChange={(value) => {
                  changeSearchInput('contactNo', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="공사_장소_코드"
                value={cntrLocationCd}
                onChange={(value) => {
                  changeSearchInput('cntrLocationCd', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="공사_위치_명"
                value={cntrPositionNm}
                onChange={(value) => {
                  changeSearchInput('cntrPositionNm', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="공사_인원_수"
                value={cntrPrsnCnt}
                onChange={(value) => {
                  changeSearchInput('cntrPrsnCnt', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="공사_신청_시작_일시"
                value={cntrApplyStartDttm}
                onChange={(value) => {
                  changeSearchInput('cntrApplyStartDttm', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="공사_신청_종료_일시"
                value={cntrApplyEndDttm}
                onChange={(value) => {
                  changeSearchInput('cntrApplyEndDttm', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="사전동의여부"
                value={preConsentYn}
                onChange={(value) => {
                  changeSearchInput('preConsentYn', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="신청자_사번"
                value={applyEmpno}
                onChange={(value) => {
                  changeSearchInput('applyEmpno', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="승인자_사번"
                value={aprvEmpno}
                onChange={(value) => {
                  changeSearchInput('aprvEmpno', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="승인_부서_의견"
                value={aprvDeptOpnn}
                onChange={(value) => {
                  changeSearchInput('aprvDeptOpnn', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="신청_상태_코드"
                value={applyStatusCd}
                onChange={(value) => {
                  changeSearchInput('applyStatusCd', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="작업_상태_코드"
                value={wrkStatusCd}
                onChange={(value) => {
                  changeSearchInput('wrkStatusCd', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="작업_시작_일자"
                value={wrkStartDt}
                onChange={(value) => {
                  changeSearchInput('wrkStartDt', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="작업_시작_비고"
                value={wrkStartRemark}
                onChange={(value) => {
                  changeSearchInput('wrkStartRemark', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="작업_시작_첨부_사진1_ID"
                value={wrkStartPhoto1Id}
                onChange={(value) => {
                  changeSearchInput('wrkStartPhoto1Id', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="작업_시작_첨부_사진2_ID"
                value={wrkStartPhoto2Id}
                onChange={(value) => {
                  changeSearchInput('wrkStartPhoto2Id', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="교육일지_첨부_파일_ID"
                value={eduJrnlFileId}
                onChange={(value) => {
                  changeSearchInput('eduJrnlFileId', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="기타_첨부_파일_ID"
                value={etcFileId}
                onChange={(value) => {
                  changeSearchInput('etcFileId', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="작업_종료_일자"
                value={wrkEndDt}
                onChange={(value) => {
                  changeSearchInput('wrkEndDt', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="작업_종료_비고"
                value={wrkEndRemark}
                onChange={(value) => {
                  changeSearchInput('wrkEndRemark', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="등록_일시"
                value={regDttm}
                onChange={(value) => {
                  changeSearchInput('regDttm', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="등록자_ID"
                value={regUserId}
                onChange={(value) => {
                  changeSearchInput('regUserId', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="수정_일시"
                value={updDttm}
                onChange={(value) => {
                  changeSearchInput('updDttm', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="수정자_ID"
                value={updUserId}
                onChange={(value) => {
                  changeSearchInput('updUserId', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="btn-area">
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            조회
          </button>
          <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
            초기화
          </button>
        </div>
      </div>
    </>
  );
}
export default OcuOutSourcingSearchForm;
