import AppSearchInput from '@/components/common/AppSearchInput';
import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
import ApiService from '@/services/ApiService';
import { useState } from 'react';
import Modal from 'react-modal';

function LawOpenApiModal(props) {
  const { isOpen, closeModal, ok } = props;
  const [list, setList] = useState([]);
  const [popLawNm, setPopLawNm] = useState('');

  const [columns, setColumns] = useState([
    { field: 'num', headerName: '번호' },
    { field: 'lawSeq', headerName: '법령 일련번호' },
    { field: 'lawNm', headerName: '법규명' },
    {
      field: '',
      headerName: '선택',
      cellRenderer: (params) => {
        return <button onClick={() => choiceLaw(params)}>선택</button>;
      },
    },
  ]);

  const changePopLawNm = (value) => {
    setPopLawNm(value);
  };

  const search = async () => {
    // if (popLawNm) {
    const apiParam = { lawNm: popLawNm };
    const apiResult = await ApiService.post('ocu/general/selectLawOpenApi', apiParam);
    const list = apiResult.data || [];
    setList(list);
    // }
  };

  const handleClose = () => {
    setList([]);
    setPopLawNm('');
    closeModal();
  };

  const choiceLaw = (selectedInfo) => {
    console.log('선택@@@');
    const data = selectedInfo.data;
    ok(data);
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">법령</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              <div className="boxForm">
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppSearchInput
                        label="법규명"
                        value={popLawNm}
                        onChange={(value) => {
                          changePopLawNm(value);
                        }}
                        search={search}
                      />
                    </div>
                  </div>
                  <div className="btn-area">
                    <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={search}>
                      조회
                    </button>
                  </div>
                </div>
              </div>
              {/*그리드영역 */}
              <div className="table-box">
                <AppTable rowData={list} columns={columns} setColumns={setColumns} handleRowDoubleClick={choiceLaw} />
              </div>
              {/*//그리드영역 */}
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            닫기
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={closeModal}>
            선택
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default LawOpenApiModal;
