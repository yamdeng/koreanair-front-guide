import SmsIntgrAnlysDashBoardList from '@/components/aviation/assurance/smsComprehensive/SmsIntgrAnlysDashBoardList';
import SPIBoardDetail from '@/components/aviation/assurance/spi-spt/spiBoardList/SPIBoardDetail';
import SpiBoardList from '@/components/aviation/assurance/spi-spt/spiBoardList/SPIBoardList';
import SpiIndicatorList from '@/components/aviation/assurance/spi-spt/spiIndicatorList/SpiIndicatorList';
import SpiInfo from '@/components/aviation/assurance/spi-spt/spiInfo/SpiInfo';

const AssuranceRouteInfo: any = {};

AssuranceRouteInfo.list = [
  // 안전보증 > SPI/SPT > 운영현황
  {
    Component: SpiInfo,
    path: 'spi-spt/spiInfo',
  },
  // 안전보증 > SPI/SPT > 게시판
  {
    Component: SpiBoardList,
    path: 'spi-spt/spiBoardList',
  },
  // 안전보증 > SPI/SPT > 게시판상세
  {
    Component: SPIBoardDetail,
    path: 'spi-spt/spiBoardList/:detailId',
  },
  // 안전보증 > SPI/SPT > 운영현황
  {
    Component: SpiIndicatorList,
    path: 'spi-spt/spiIndicatorList',
  },
  // 안전보증 > SMS 종합분석 > 대시보드
  {
    Component: SmsIntgrAnlysDashBoardList,
    path: 'smsComprehensive/smsIntgrAnlysDashBoardList',
  },
];

export default AssuranceRouteInfo;
