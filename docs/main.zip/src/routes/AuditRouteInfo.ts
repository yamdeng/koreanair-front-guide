import AuditCheckList from '@/components/aviation/audit/checklist/AuditCheckList';
import AuditCheckListView from '@/components/aviation/audit/checklist/AuditCheckListView';
import AuditCheckListEdit from '@/components/aviation/audit/checklist/AuditCheckListEdit';

const AuditRouteInfo: any = {};

AuditRouteInfo.list = [
  {
    Component: AuditCheckList,
    path: 'audit/checklist',
  },
  {
    Component: AuditCheckListView,
    path: 'audit/checklist/:division/:checklistOrigId/:chapterOrigId',
  },
  {
    Component: AuditCheckListEdit,
    path: 'audit/checklist/:division/:checklistOrigId/:chapterOrigId/edit',
  },
];

export default AuditRouteInfo;
