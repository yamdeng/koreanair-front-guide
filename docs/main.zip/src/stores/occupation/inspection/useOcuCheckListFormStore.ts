import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  chkListClsCd: yup.string().required(),
  chkVer: yup.number().required(),
  chkListTitle: yup.string().required(),
  stdLevel: yup.number().required(),
  regDttm: yup.string().required(),
  regUserId: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  chkListClsCd: '01',
  chkVer: 1,
  chkListTitle: '제목',
  stdLevel: 1,
  regDttm: '2024-08-24',
  regUserId: 'SYSTEM',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,
  formApiPath: 'ocu/inspection/checklist',
  baseRoutePath: '/occupation/inspection/checklist',
  formName: 'OcuCheckListForm',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuCheckListFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuCheckListFormStore;
