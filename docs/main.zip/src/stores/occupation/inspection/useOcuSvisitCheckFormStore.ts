import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  chkListClsCd: yup.string().required(),
  chkTitle: yup.string().required(),
  chkRegStartDt: yup.string().required(),
  chkRegEndDt: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  chkListClsCd: '',
  chkTitle: '',
  chkRegStartDt: '',
  chkRegEndDt: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,
  formApiPath: 'ocu/inspection/walkAround',
  baseRoutePath: '/occupation/inspection/walkAround',
  formName: 'OcuSvisitCheckForm',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuSvisitCheckFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuSvisitCheckFormStore;
