import { create } from 'zustand';
import { produce } from 'immer';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  // 재난유형코드
  dssTypeCd: yup.string().required(),
  // 기타유형
  etcType: yup.string().nullable(),
  // 훈련일자
  trainDt: yup.string().required(),
  // 훈련장소
  trainLocation: yup.string().required(),
  // 참석자
  prtcNmList: yup.string().required(),
  // 훈련명
  trainNm: yup.string().required(),
  // 평가내용
  evalContent: yup.string().required(),
  // 첨부파일 ID
  fileId: yup.number().nullable().required(),
  // 첨부링크 ID
  linkId: yup.number().nullable(),
  // 등록일시
  //regDttm: yup.string().required(),
  // 등록자ID
  //regUserId: yup.string().required(),
  // 수정일시
  //updDttm: yup.string().nullable(),
  // 수정자ID
  //updUserId: yup.string().nullable(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  dssTypeCd: '',
  etcType: '',
  trainDt: '',
  deptCd: 'A',
  trainLocation: '',
  prtcNmList: null,
  trainNm: '',
  evalContent: '',
  fileId: null,
  linkId: null,
  regDttm: '',
  regUserId: '',
  updDttm: '',
  updUserId: '',
  linkAttachList: [],
};

// const initFormValue = {
//   dssTypeCd: 'A',
//   etcType: '기타유형',
//   trainDt: '2024-08-24',
//   trainLocation: '훈련장소',
//   prtc: 1,
//   trainNm: '훈련명',
//   evalContent: '컨텐츠',
//   fileId: null,
//   linkId: null,
//   regDttm: '2024-08-24',
//   regUserId: 'SYSTEM',
// };

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/training',
  baseRoutePath: '/occupation/management/training',
  formName: 'useOcuMajorDssTrainingFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuMajorDssTrainingFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  // 링크 첨부 모달
  isLinkAttachModalOpen: false,

  linkAttachDetailInfo: null,

  okLinkAttachModal: (linkAttachFormValue) => {
    set(
      produce((state: any) => {
        const newFormValue = { ...state.formValue };
        newFormValue.linkAttachList.push(linkAttachFormValue);
        state.formValue = newFormValue;
        state.isLinkAttachModalOpen = false;
      })
    );
  },

  openLinkAttachModal: (detailInfo = null) => {
    set({ isLinkAttachModalOpen: true, linkAttachDetailInfo: detailInfo });
  },

  closeLinkAttachModal: () => {
    set({ isLinkAttachModalOpen: false });
  },

  removeLinkAttach: (removeIndex) => {
    set(
      produce((state: any) => {
        const newFormValue = { ...state.formValue };
        newFormValue.linkAttachList.splice(removeIndex, 1);
        state.formValue = newFormValue;
      })
    );
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuMajorDssTrainingFormStore;
