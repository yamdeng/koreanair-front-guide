import ApiService from '@/services/ApiService';
import ToastService from '@/services/ToastService';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { create } from 'zustand';

/* yup validation */
const yupFormSchema = yup.object({
  id: yup.number().required(),
  reportNo: yup.string().required(),
  reportTitle: yup.string(),
  departureAt: yup.string(),
  flightNo: yup.string(),
  aircraftTypeText: yup.string(),
  fromAirport: yup.string(),
  toAirport: yup.string(),
  registrationNo: yup.string(),
  supply: yup.string(),
  checkIn: yup.string(),
  locationText: yup.string(),
  airport: yup.string(),
  flightPhase: yup.string(),
  empNo: yup.string().required(),
  eventAt: yup.string(),
  operationType: yup.string(),
  investigationType: yup.string(),
  isSpi: yup.string(),
  classification: yup.string(),
  deletedAt: yup.string(),
  weatherText: yup.string(),
  eventAtTz: yup.string(),
  divertAirport: yup.string(),
  isSubmitted: yup.string(),
  submittedAt: yup.string(),
  investigateBy: yup.string(),
  submittedBy: yup.string(),
  approvedId: yup.number().nullable(),
  eventId: yup.string(),
  regDttm: yup.string().required(),
  regUserId: yup.string().required(),
  updDttm: yup.string().required(),
  updUserId: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  // reportNo: '', //보고서 번호
  reportTitle: '', //리포트 subject
  eventAt: '', //발생일
  eventAtTz: '', //발생일 TimeZone
  classification: '', //Event Class
  eventId: '', //Event Type
  airport: '', //발생 공항
  flightPhase: '', //발생 단계
  weatherText: '', //기상조건
  isSpi: 'N', //SPI여부
  spiFileGroupSeq: '', //SPI첨부파일
  locationText: '', //발생 장소
  departureAt: '', //출발일자
  flightNo: '', //비행편명
  registrationNo: '', //등록기호
  aircraftTypeText: '', //항공기 형식
  fromAirport: '', //출발항공
  toAirport: '', //도착공항
  divertAirport: '', //회항공항
  supply: '', //좌석수
  checkIn: '', //탑승자
  crewMemberList: [], //승무원
  editorContents: '', //조사보고서 내용
  editorFileGroupSeq: '', //조사보고서 첨부파일
  investigateBy: '', //조사관
  hazardList: [], //위해요인 리스트
  hazardId: '', //hazard
  hazardType: 'ast', //원인구분
  consequenceId: '', //potential Consequence
  assumptionList: [], //추정원인 목록
  radicalList: [], //부수요인 목록
  approvedGroupID: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/srm/investigation/reports',
  baseRoutePath: '/aviation/safety-risk-mgmt/investigation-report',
  formName: 'AvnIvReportForm',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useInvestigationReportFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },

  //asr 이벤트 목록 가져오기
  eventListData: [],
  // hazard 목록 가져오기
  hazardListData: [],
  //consequence 목록 가져오기
  consequenceListData: [],
  //승무원 정보
  crewResult: [],

  //승무원 정보 담기
  getUserInfo: async (crewId) => {
    const { crewResult, formValue } = get();
    const crewInfoApi = await ApiService.get(`avn/common/users?searchWord=${crewId}`);
    const crewdata = crewInfoApi.data.list;

    // crewResult의 기존 값을 복사하고 crewdata의 요소들을 추가
    const updatedCrewResult = [...crewResult, ...crewdata];

    // (화면에 그려주기 위한)crewResult 업데이트
    set({ crewResult: updatedCrewResult });

    //(insert parameter로 넘겨주기 위한)crewMemberList 업데이트
    formValue['crewMemberList'] = updatedCrewResult;
    set({ formValue: formValue });
  },

  // 승무원 삭제
  deleteCrew: async (empNo) => {
    const { crewResult } = get();

    crewResult.some((data, index) => {
      if (data.empNo == empNo) {
        crewResult.splice(index, 1);
      }
    });
    set({ crewResult: [...crewResult] });
  },

  //이벤트 타입 가져오기
  getEventTypeList: async () => {
    const eventList = await ApiService.get('avn/srm/investigation/eventTypeASR');

    set({ eventListData: eventList });
  },

  //Hazard 목록 가져오기
  getHazardList: async () => {
    const hazardList = await ApiService.get('avn/srm/investigation/hazard');

    set({ hazardListData: hazardList });
  },

  //Consequence 목록 가져오기
  getConsequenceList: async () => {
    const consequenceList = await ApiService.get('avn/srm/investigation/consequence');

    set({ consequenceListData: consequenceList });
  },

  //조사관 세팅
  getInvestigatior: async (profile) => {
    const { formValue } = get();

    formValue['investigateBy'] = profile.userInfo.empNo;
    set({ formValue: formValue });
  },

  //Risk Assessment
  addRiskAssessment: () => {
    const { formValue, hazardListData, consequenceListData } = get();
    let addFlag = false;

    if (formValue.hazardId == '') {
      ToastService.error('Hazard를 선택해주세요');
      document.getElementById('InvestigationReportEditHazard').focus();
      return;
    } else if (formValue.consequenceId == '') {
      ToastService.error('Potential Consequence를 선택해주세요');
      document.getElementById('InvestigationReportEditpotentialConsequence').focus();
      return;
    } else if (formValue.hazardType == '') {
      ToastService.error('원인구분을 선택해주세요');
      document.getElementById('InvestigationReportEditpotentialhazardType').focus();
    } else {
      //위험평가 중복체크
      if (formValue.hazardList.length > 0) {
        formValue.hazardList.forEach((el) => {
          if (el.hazardId == formValue.hazardId && el.consequenceId == formValue.consequenceId) {
            addFlag = true;
            if (el.hazardType == 'ast') {
              ToastService.error('추정원인에 이미 등록된 위험평가 입니다.\n확인 후 다시 진행해주세요');
              return;
            } else {
              ToastService.error('부수요인에 이미 등록된 위험평가 입니다.\n확인 후 다시 진행해주세요');
              return;
            }
            // ToastService.error('원인구분을 선택해주세요');
          }
        });
      }

      if (addFlag) return;

      //Risk Assessment 만들어주기
      const riskAssessment = {};
      // 값 저장
      riskAssessment['hazardId'] = formValue.hazardId;
      riskAssessment['hazardType'] = formValue.hazardType;
      riskAssessment['consequenceId'] = formValue.consequenceId;
      //hazard 이름 가져오기
      hazardListData.data.some((data) => {
        if (data.lv3Id == formValue.hazardId) {
          riskAssessment['hazardName'] = data.lv3Name;
        }
      });
      //consequence이름가져오기
      consequenceListData.data.some((data) => {
        if (data.consequenceId == formValue.consequenceId) {
          riskAssessment['consequenceName'] = data.nameKo;
        }
      });
      //추정원인일 경우
      if (formValue.hazardType == 'ast') {
        //formValue에 추정원인 넣기
        const { assumptionList } = formValue;
        const arrayData = [];
        arrayData.push(riskAssessment);
        const updatedCrewResult = [...assumptionList, ...arrayData];
        formValue['assumptionList'] = updatedCrewResult;
        //부수요인일 경우
      } else {
        //formValue에 부수요인 넣기
        const { radicalList } = formValue;
        const arrayData = [];
        arrayData.push(riskAssessment);
        const updatedCrewResult = [...radicalList, ...arrayData];
        formValue['radicalList'] = updatedCrewResult;
      }
      //최종 두개 합본
      formValue['hazardList'] = [...formValue['assumptionList'], ...formValue['radicalList']];
      set({ formValue: formValue });
    }
  },
}));

export default useInvestigationReportFormStore;
