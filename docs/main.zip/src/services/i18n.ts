import useAppStore from '@/stores/useAppStore';
import { initReactI18next } from 'react-i18next';
import i18n from 'i18next';

export const getMessage = (messageKey, defaultMessage = '') => {
  if (messageKey) {
    const { messageAllList, currentLocale } = useAppStore.getState();
    const currentLocaleMessageMap = messageAllList[currentLocale];
    const messageLabel = currentLocaleMessageMap[messageKey] || defaultMessage || messageKey;
    return messageLabel;
  }
  return 'not message key';
};

export const initializeI18n = async (messageMap) => {
  i18n.use(initReactI18next).init({
    resources: {
      ko: {
        translation: messageMap['ko'],
      },
      en: {
        translation: messageMap['en'],
      },
    },
    lng: 'ko',
    fallbackLng: 'ko',
    interpolation: {
      escapeValue: false,
    },
  });
};

export const getUserInfoByLocale = (userInfo) => {
  const { currentLocale } = useAppStore.getState();
  if (userInfo) {
    const result = { ...userInfo };
    result.userName = currentLocale === 'en' ? userInfo.nameEng : userInfo.nameKor;
    result.deptName = currentLocale === 'en' ? userInfo.deptNmEng : userInfo.deptNmKor;
    result.rankName = currentLocale === 'en' ? userInfo.rankNmEng : userInfo.rankNmKor;
    result.rankName = result.rankName || '';
    result.deptName = result.deptName || '';
    return result;
  }
  return null;
};

export const getUserLabelByLocale = (userInfo) => {
  const { currentLocale } = useAppStore.getState();
  if (userInfo) {
    const { empNo } = userInfo;
    const userName = currentLocale === 'en' ? userInfo.nameEng : userInfo.nameKor;
    let deptName = currentLocale === 'en' ? userInfo.deptNmEng : userInfo.deptNmKor;
    let rankName = currentLocale === 'en' ? userInfo.rankNmEng : userInfo.rankNmKor;
    deptName = deptName || '';
    rankName = rankName || '';
    return `${userName}(${empNo})${deptName}/${rankName}`;
  }
  return null;
};

export default i18n;
