# 대한항공 프론트 프로젝트

# tailwind 실행

npx tailwindcss -i input.css -o ./src/components/aviation/report/report.css --watch
