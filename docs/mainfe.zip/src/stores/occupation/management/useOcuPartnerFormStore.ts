import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import _ from 'lodash';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { createCommonDataset } from '@/stores/common/useCommonDatasetStore';

/* yup validation */
const yupFormSchema = yup.object({
  // prtnrId: yup.number().required(),
  prtnrNm: yup.string().required(),
  bizNo: yup.string().required(),
  rprsn: yup.string().required(),
  bizIndst: yup.string().required(),
  bizType: yup.string().required(),
  placeList: yup
    .array()
    .min(1, '목록은 최소 하나여야 합니다.')
    .of(
      yup.object().shape({
        bizPlaceClsCd: yup.string().required(),
        useSectCd: yup.string().required(),
        mgntDeptCd: yup.string().required(),
        staffNm1: yup.string().required(),
        staffContactNo1: yup.string().required(),
        staffEmail1: yup.string().required(),
        staffWork1: yup.string().required(),
        majorWorkCn: yup.string().required(),
        place2ndInfoList: yup.array().of(
          yup.object().shape({
            companyNm: yup.string().required(),
            majorWorkCn: yup.string().required(),
            staffNm: yup.string().required(),
            staffContactNo: yup.string().required(),
          })
        ),
      })
    ),
});

/* formValue 초기값 */
const initFormValue = {
  prtnrId: null,
  prtnrNm: '',
  bizNo: '',
  rprsn: '',
  bizIndst: '',
  bizType: '',
  placeList: [],
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/partner',
  baseRoutePath: '/occupation/management/partner',
  formName: 'OcuPartnerInfoForm',
  formValue: {
    ...initFormValue,
  },

  selectedPlaceIndex: -1,
  selectedPlace2ndInfoIndex: -1,
};

/* zustand store 생성 */
const useOcuPartnerInfoFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...createCommonDataset(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  setSelectedPlaceIndex: (index: number) => {
    set({ selectedPlaceIndex: index });
  },

  getPlacePath: () => {
    return `formValue.placeList`;
  },

  setSelectedPlace2ndInfoIndex: (index: number) => {
    set({ selectedPlace2ndInfoIndex: index });
  },

  getPlace2ndInfoPath: () => {
    const { selectedPlaceIndex } = get();
    return `formValue.placeList[${selectedPlaceIndex}].place2ndInfoList`;
  },

  // 오류 메시지 가져오기
  getPlaceError: (field: string) => {
    const { errors, selectedPlaceIndex } = get();
    const path = `placeList[${selectedPlaceIndex}].${field}`;
    return _.get(errors, path, null); // 기본값으로 null을 설정
  },

  getPlaceColumn: (field) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.getColumn(getPlacePath(), selectedPlaceIndex, field);
  },

  setPlaceColumn: (field: string, value: any) => {
    const { CommonDS, getPlacePath, selectedPlaceIndex } = get();
    return CommonDS.setColumn(getPlacePath(), selectedPlaceIndex, field, value);
  },

  addPlaceRow: () => {
    const { CommonDS, getPlacePath, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.addRow(getPlacePath());
    setSelectedPlaceIndex(rowIdx);
  },

  delPlaceRow: () => {
    const { CommonDS, getPlacePath, selectedPlaceIndex, setSelectedPlaceIndex } = get();
    const rowIdx = CommonDS.deleteRow(getPlacePath(), selectedPlaceIndex);
    setSelectedPlaceIndex(rowIdx);
  },

  getPlace2ndList: () => {
    const { CommonDS, getPlace2ndInfoPath } = get();
    return CommonDS.getList(getPlace2ndInfoPath());
  },

  addPlace2ndInfo: () => {
    const { CommonDS, getPlace2ndInfoPath, setSelectedPlace2ndInfoIndex } = get();
    const rowIdx = CommonDS.addRow(getPlace2ndInfoPath());
    setSelectedPlace2ndInfoIndex(rowIdx);
  },

  delPlace2ndInfo: () => {
    const { CommonDS, getPlace2ndInfoPath, selectedPlace2ndInfoIndex, setSelectedPlace2ndInfoIndex } = get();
    const rowIdx = CommonDS.deleteRow(getPlace2ndInfoPath(), selectedPlace2ndInfoIndex);
    setSelectedPlace2ndInfoIndex(rowIdx);
  },

  saveAll: async () => {
    const { validate, getApiParam, formValue, formType, formDetailId, formApiPath, cancel } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          console.log(`apiParam : ${JSON.stringify(apiParam)}`);
          await ApiService.post(`${formApiPath}`, apiParam);
          await set({ isDirty: false });
          ToastService.success('저장되었습니다.');
          await cancel();
        },
      });
    } else {
      const { CommonDS, errors } = get();
      CommonDS.setValidateList('formValue', errors);
    }
  },

  // form 전체 초기화
  clear: () => {
    set({
      ...formBaseState,
      formValue: { ...initFormValue },
      selectedPlace: null,
      selectedPlaceIndex: -1,
      selectedPlace2ndInfoIndex: -1,
    });
  },
}));

export default useOcuPartnerInfoFormStore;
