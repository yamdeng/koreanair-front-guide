import { create } from 'zustand';
import { produce } from 'immer';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/permits/locations',
  baseRoutePath: '/occupation/management/permits',
};

const initSearchParam = {
  // 공사장소명
  cntrLocationNm: '',
  // 사용여부
  useYn: '',
};

/* yup validation*/
const yupFormSchema = yup.object({
  // 공사장소 등록 및 관리
  // 공사장소ID
  cnstrSiteId: yup.number(),
  // 공사장소명
  cntrLocationNm: yup.string(),
  // 사용여부
  useYn: yup.string(),
  // 등록_일시
  regDttm: yup.string(),
  // 등록자_ID
  regUserId: yup.string(),
  // 수정_일시
  updDttm: yup.string(),
  // 수정자_ID
  updUserId: yup.string(),
});

/** form 초기값 설정 */
const initFormValue = {
  // 공사장소 등록 및 관리
  // 공사장소ID
  cnstrSiteId: '',
  // 공사장소명
  cntrLocationNm: '',
  // 사용여부
  useYn: '',
  // 등록_일시
  regDttm: '',
  // 등록자_ID
  regUserId: '',
  // 수정_일시
  updDttm: '',
  // 수정자_ID
  updUserId: '',
};

/** form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits/locations',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitLocationRegisterModalStore',

  formValue: {
    ...initFormValue,
  },
};

/** zustand store 생성 */
const useOcuWorkPermitLocationRegisterModalStore = create<any>((set, get) => ({
  ...createListSlice(set, get),
  ...createFormSliceYup(set, get),
  ...initListData,
  ...initFormData,
  disablePaging: true,
  formName: 'WorkPermitLocationRegisterModal',
  yupFormSchema: yupFormSchema,
  isLocationRegisterModalOpen: false,
  locationRegisterModalInfo: null,

  searchParam: {
    //공사장소명
    cntrLocationNm: '',
    //사용여부
    useYn: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  saveLocationRegisterModal: (locationRegisterFormValue) => {
    set(
      produce((state: any) => {
        const newFormValue = { ...state.formValue };
        newFormValue.locationRegisterList.push(locationRegisterFormValue);
        state.formValue = newFormValue;
        state.isLocationRegisterModalOpen = false;
      })
    );
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuWorkPermitLocationRegisterModalStore;
