import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import history from '@/utils/history';
import { el } from '@faker-js/faker';

/* yup validation */
const yupFormSchema = yup.object({
  /* 첨부자료 */

  // 회의_자료_사진_첨부_파일_ID
  meetDataPhotoId: yup.number(),
  // 회의_자료_파일_첨부_파일_ID
  meetDataFileId: yup.number(),
  // 교육_자료_사진_첨부_파일_ID
  eduDataPhotoFileId: yup.number(),
  // 교육_자료_파일_첨부_파일_ID
  eduDataFileFileId: yup.number(),
  // 화학_물질_첨부_파일_ID
  chmclMtrlFileId: yup.number(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  /* 첨부자료 */

  // 회의_자료_사진_첨부_파일_ID
  meetDataPhotoId: null,
  // 회의_자료_파일_첨부_파일_ID
  meetDataFileId: null,
  // 교육_자료_사진_첨부_파일_ID
  eduDataPhotoFileId: null,
  // 교육_자료_파일_첨부_파일_ID
  eduDataFileFileId: null,
  // 화학_물질_첨부_파일_ID
  chmclMtrlFileId: null,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/risk/reval',
  baseRoutePath: '/occupation/risk/reval',
  formName: 'useOcuRiskTab4FormStore',
  formValue: {
    ...initFormValue,
  },
};

//  store
const useOcuRiskTab4FormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  // 위험성 정보 삭제 list
  // deleteProcGridList: [],

  yupFormSchema: yupFormSchema,

  // from 상세 조회
  getDetail: async (id) => {
    const { setList, setTotalCount, procChange } = get();

    //const { formApiPath } = get();
    const formApiPath = 'ocu/risk/reval/selectTab4';
    const response: any = await ApiService.get(`${formApiPath}/${id}`);
    const detailInfo = response.data;

    console.log('조회값=====>', detailInfo);
    set({
      // 위험성 결정 폼 정보
      detailInfo: detailInfo.revalBase,
      formValue: detailInfo.revalBase,
      formType: FORM_TYPE_UPDATE,
      rEvalDocNo: id,
    });

    // // 위험성 결정 정보
    // setTotalCount(detailInfo.revalProcess.length);
    // setList(detailInfo.revalProcess);
    // set({ rEvalDocNo: id });

    // const { list } = get();
    // // 상태값 N 추가
    // list.map((info) => {
    //   info.procGubun = 'N';
    // });

    // // set({ originExecDeptlist: detailInfo.revalExecDept });
    // console.log(' 리스트==>', list);

    // // 위험성 결정 조회 정보
    // procChange(detailInfo.revalProcess[0], 0);
  },

  goFormPage: (id) => {
    const { baseRoutePath } = get();
    history.push(`${baseRoutePath}/${id}/edit`);
  },

  // 위험성평가 첨부문서 탭 저장
  saveUseOcuRiskTab4: async () => {
    const { list, formDetailId, formApiPath, search, formValue, baseRoutePath, deleteProcGridList, rEvalDocNo } = get();

    //const { list, formDetailId, formApiPath, search, formValue, baseRoutePath } = get();

    //useOcuRiskTab1ProcessListStore.getState().list;
    const apiList = _.cloneDeep(list);

    const formParam = formValue;

    console.log('첨부문서==>', formParam);

    // 상태 변경 안된 항목 빼고 위험성 결정 List 재구성
    // const procInfoList = apiList.filter((item) => item.procGubun !== 'N');

    // console.log('위험성결정===>', procInfoList);

    ModalService.confirm({
      body: '저장하시겠습니까?',
      ok: async () => {
        // const formParam = formValue;
        // const apiParam = apiList;
        //   // 위험성 결정
        //   atthchInfoList: apiList,
        // };

        // console.log('보내는 저장값===>', apiParam);

        await ApiService.post(`${formApiPath}/${rEvalDocNo}/saveRiskTab4`, formParam);
        // await ApiService.post(`${formApiPath}/${formDetailId}`, apiParam);
        search();
        //history.push(`${baseRoutePath}`);
        ToastService.success('저장되었습니다.');
      },
    });
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuRiskTab4FormStore;
