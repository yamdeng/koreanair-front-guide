import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import _ from 'lodash';
import history from '@/utils/history';

/* zustand store 생성 */
const useMyAuditCarStore = create<any>((set, get) => ({
  dsAuditCarInfo: [],

  setAuditCarInfo: async (auditInfo) => {
    set({ dsAuditCarInfo: auditInfo });
    const { dsAuditCarInfo } = get();

    //alert('CarStore : ' + dsAuditCarInfo.auditNo);
  },
}));

export default useMyAuditCarStore;
