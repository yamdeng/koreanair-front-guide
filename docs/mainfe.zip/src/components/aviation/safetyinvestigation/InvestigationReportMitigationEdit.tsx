import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppSelect from '@/components/common/AppSelect';
import AppTextInput from '@/components/common/AppTextInput';
import AppEditor from '@/components/common/AppEditor';
import AppMaskInput from '@/components/common/AppMaskInput';
import AvnReportUserSelect from '@/components/aviation/common/AvnReportUserSelect';

//위험레벨모달
// import ReportLevelModal from '@/components/modal/ReportLevelModal';
//확인모달
import ConfirmModal from '@/components/modal/ConfirmModal';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams } from 'react-router-dom';
import ToastService from '@/services/ToastService';
/* TODO : store 경로를 변경해주세요. */
import AppCodeSelect from '@/components/common/AppCodeSelect';
import useInvestigationReportMitigationFormStore from '@/stores/aviation/safetyinvestigation/useInvestigationReportStore';
import useAppStore from '@/stores/useAppStore';
import { useStore } from 'zustand';
import AvnIvApprovalGroupFormModal from '@/components/modal/aviation/AvnIvApprovalGroupFormModal';
import ReportDocumentModal from '@/components/modal/aviation/ReportDocumentModal';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function InvestigationReportMitigationEdit() {
  //위험레벨모달
  const [isOpen, setIsOpen] = useState(false);
  //위험레벨모달 끝
  //결재그룹모달
  const [isApprovalOpen, setIsApprovalOpen] = useState(false);
  const closeApprovalModal = () => {
    setIsApprovalOpen(false);
  };
  //결재그룹모달끝
  //참고문서번호 모달
  const [isReportDocumentOpen, setIsReportDocumentOpen] = useState(false);
  const closeReportDocumentModal = () => {
    setIsReportDocumentOpen(false);
  };
  //참고문서번호 모달 끝
  //확인모달
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const confirmModalOk = () => {
    setIsConfirmModalOpen(false);
    addRiskAssessment();
  };

  const confirmModalCancel = () => {
    setIsConfirmModalOpen(false);
  };

  //위험평가 삭제 구분
  const [deleteAssessment, setDeleteAssessment] = useState(true);
  //삭제할 안전평가 index번호
  const [deleteAssessmentIndex, setDeleteAssessmentIndex] = useState(null);
  //안전평가 삭제 팝업창 open
  const [isAssessmentDeleteConfirmModalOpen, setIsAssessmentDeleteIsConfirmModalOpen] = useState(false);

  //추정원인 삭제
  const deleteConfirmAssumptionOk = () => {
    deleteAssumption(deleteAssessmentIndex);

    setIsAssessmentDeleteIsConfirmModalOpen(false);
    setDeleteAssessment(true);
  };

  //부수요인 삭제
  const deleteConfirmRadicalOk = () => {
    deleteRadical(deleteAssessmentIndex);

    setIsAssessmentDeleteIsConfirmModalOpen(false);
    setDeleteAssessment(true);
  };

  const isAssessmentDeleteConfirmCancle = () => {
    setIsAssessmentDeleteIsConfirmModalOpen(false);
  };

  //확인모달 끝

  //사용자 profile 적용
  //로그인자 프로필 정보
  const profile = useStore(useAppStore, (state) => state.profile);

  const { t } = useTranslation();
  const [firstExpaned, setFirstExpaned] = useState(true);
  const [secondExpaned, setSecondExpaned] = useState(true);
  const [thirdExpaned, setThirdExpaned] = useState(true);
  const [fourExpaned, setFourExpaned] = useState(true);
  const [fiveExpaned, setFiveExpaned] = useState(true);

  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    save,
    remove,
    cancel,
    clear,
    deleteAssumption,
    deleteRadical,
    changeErrors,
    getEventTypeList,
    getConsequenceList,
    getHazardList,
    eventListData,
    getInvestigatior,
    getApprovalGroup,
    getMember,
    hazardListData,
    consequenceListData,
    addRiskAssessment,
    onSelectFlightCrewList,
    deleteFlightCrewList,
    onSelectapprovalGroupList,
    searchFligh,
    up,
    down,
    isDeleteConfirmModal,
    isDeleteConfirmModalClose,
    memberRemoveIndex,
    isDeleteConfirmModalOpen,
    deleteConfirmModalOk,
    initFormInput,
    deleteDocument,
    safetyActionState,
    isSPIDisplayStatus,
    displayStatus,
    changeDisplayStatus,
  } = useInvestigationReportMitigationFormStore();

  //formValue
  const {
    reportNo, //보고서 번호
    reportTitle, //리포트 subject
    occurrenceInformation, //발생정보
    flight, //비행정보
    crewMemberList, //승무원
    investigationReport,
    hazardList, //위해요인 리스트
    hazardId, //hazard
    hazardType, //원인구분
    consequenceId, //potential Consequence
    assumptionList, //추정원인 목록
    radicalList, //부수요인 목록
    approvalGroupID, //결재 ID
    approvalGroupList, //결재 그룹 리스트
    memberList, //결재 멤버 정보(options)
    approvalMemberList, //결재 멤버 목록(살제 값)
    empNo, //최초 작성자 사원번호
    isSubmitted, //제출여부
    reportDocument, //참고문서
  } = formValue;

  //발생정보
  const {
    eventAt, //발생일
    eventAtTz, //발생일 TimeZone
    classification, //Event Class
    eventId, //Event Type
    airport, //발생 공항
    flightPhase, //발생 단계
    weatherText, //기상조건
    isSpi, //SPI여부
    spiFileGroupSeq, //SPI첨부파일
    locationText, //발생 장소
  } = occurrenceInformation;

  //비행정보
  const {
    departureAt, //출발일자
    flightNo, //비행편명
    registrationNo, //등록기호
    aircraftTypeText, //항공기 형식
    fromAirport, //출발항공
    toAirport, //도착공항
    divertAirport, //회항공항
    supply, //좌석수
    checkIn, //탑승자
  } = flight;

  //조사보고서
  const {
    postContents, //조사보고서 내용
    reportFileGroupSeq, //조사보고서 첨부파일
    investigateBy, //조사관
  } = investigationReport;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    //수정 ->상세정보 불러오기
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    //ASR 이벤트 목록 조회
    getEventTypeList();
    // hazard 목록 조회
    getHazardList();
    //consequence 목록 조회
    getConsequenceList();

    //조사관 처리
    getInvestigatior(profile);

    //결재 그룹 가져오기
    getApprovalGroup();

    displayStatus();

    // //reportDocument 참고문서 번호 초기화
    reportDocument.length = 0;
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2 className="reportview">
          보고서 번호
          <span>
            <a href="javascript:void(0);">{reportNo}</a>
          </span>
        </h2>
      </div>
      {/*edit 영역 */}
      {/* <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="InvestigationReportreportTitle"
                name="reportTitle"
                label="subject"
                value={reportTitle}
                onChange={(value) => changeInput('reportTitle', value)}
                errorMessage={errors.reportTitle}
                required
              />
            </div>
          </div>
        </div>
      </div> */}

      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">Subject</label>
                    <span className="text-desc-type1">{reportTitle}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="info-wrap toggle">
        <dl className="{firstExpaned ? 'tg-item active' : 'tg-item'}">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt onClick={() => setFirstExpaned(!firstExpaned)}>
            <button type="button" className="btn-tg">
              발생정보<span className={firstExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: firstExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell">
                      <div className="form-group wid50">
                        <div className="date1">
                          {/* 발생일/시간(UTC) */}
                          <AppDatePicker
                            label="발생일/시간(UTC)"
                            id="InvestigationReportdepartureAt"
                            name="departureAt"
                            value={eventAt}
                            onChange={(value) => changeInput('occurrenceInformation.eventAt', value)}
                            errorMessage={errors['occurrenceInformation.eventAt']}
                            showTime
                            excludeSecondsTime
                            required
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*Event Class */}
                        <AppCodeSelect
                          codeGrpId="CODE_GRP_154"
                          id="InvestigationReportEditclassification"
                          name="classification"
                          applyAllSelect
                          allValue=""
                          allLabel="선택"
                          label="Event Class"
                          value={classification}
                          onChange={(value) => changeInput('occurrenceInformation.classification', value)}
                          errorMessage={errors['occurrenceInformation.classification']}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* Event Type */}
                        <AppSelect
                          label="Event Type"
                          name="eventId"
                          id="InvestigationReportEditeventId"
                          applyAllSelect
                          allValue=""
                          allLabel="선택"
                          options={eventListData.data}
                          labelKey="eventNm"
                          valueKey="eventID"
                          value={eventId}
                          required
                          onChange={(value) => changeInput('occurrenceInformation.eventId', value)}
                          errorMessage={errors['occurrenceInformation.eventId']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*발생공항 */}
                        <AppAutoComplete
                          label="발생 공항"
                          apiUrl="avn/common/airports"
                          value={airport}
                          labelKey="label"
                          valueKey="airportCode"
                          dataKey="data.list"
                          onChange={(value) => {
                            changeInput('occurrenceInformation.airport', value);
                          }}
                          isMultiple={false}
                          required
                          isValueString
                          errorMessage={errors['occurrenceInformation.airport']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* 발생 단계 */}
                        <AppCodeSelect
                          codeGrpIdList={['CODE_GRP_002', 'CODE_GRP_041']}
                          isMultiGroupCode
                          label={t('ke.safetyRiskMgmt.investigationReport.label.00007')}
                          value={flightPhase}
                          applyAllSelect
                          onChange={(value) => {
                            changeInput('occurrenceInformation.flightPhase', value);
                          }}
                          required
                          errorMessage={errors['occurrenceInformation.flightPhase']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*기상조건 */}
                        <AppTextInput
                          id="InvestigationReportEditweatherText"
                          name="weatherText"
                          label="기상 조건"
                          value={weatherText}
                          onChange={(value) => changeInput('occurrenceInformation.weatherText', value)}
                          errorMessage={errors['occurrenceInformation.weatherText']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap1 wid100">
                        <AppRadioGroup
                          label="SPI 여부"
                          options={[
                            {
                              label: '예',
                              value: 'Y',
                            },
                            {
                              label: '아니오',
                              value: 'N',
                            },
                          ]}
                          value={isSpi}
                          onChange={(value) => {
                            if (value == 'Y') {
                              changeDisplayStatus('show');
                            } else {
                              changeDisplayStatus('hide');
                            }
                            changeInput('occurrenceInformation.isSpi', value);
                          }}
                          required
                          errorMessage={errors['occurrenceInformation.isSpi']}
                        />

                        <div id="spiFileDiv" className={`form-group wid100 mt15 ${isSPIDisplayStatus}`}>
                          {/* 파일첨부영역 : drag */}
                          <AppFileAttach
                            id="InvestigationReportEditspiFileGroupSeq"
                            name="spiFileGroupSeq"
                            label="첨부파일"
                            fileGroupSeq={spiFileGroupSeq}
                            workScope={'A'}
                            updateFileGroupSeq={(newFileGroupSeq) => {
                              changeInput('occurrenceInformation.spiFileGroupSeq', newFileGroupSeq);
                            }}
                            errorMessage={errors['occurrenceInformation.spiFileGroupSeq']}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="InvestigationReportEditlocationText"
                          name="locationText"
                          label="발생 위치"
                          value={locationText}
                          onChange={(value) => changeInput('occurrenceInformation.locationText', value)}
                          errorMessage={errors['occurrenceInformation.locationText']}
                          toolTipMessage="자유형식으로 입력가능
                          예)Waypoint, 이륙 후3시간 경과 시점 등"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap1 wid50">
                        <span className="txt">참고문서번호</span>
                        <div className="round-wrap num">
                          <span
                            className="icon_report"
                            onClick={() => {
                              setIsReportDocumentOpen(true);
                            }}
                          ></span>{' '}
                        </div>
                        <div className="tag-list">
                          <ul>
                            {reportDocument == undefined
                              ? null
                              : reportDocument.map((el, index) => {
                                  return (
                                    <li key={el.id} id={el.id}>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          window.open('http://www.naver.com', '_blank');
                                        }}
                                      >
                                        {el.docNo}{' '}
                                        <a href="javascript:void(0);">
                                          <span
                                            className="delete"
                                            onClick={() => {
                                              deleteDocument(index);
                                            }}
                                          >
                                            X
                                          </span>
                                        </a>
                                      </button>
                                    </li>
                                  );
                                })}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        <dl className={secondExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setSecondExpaned(!secondExpaned)}>
            <button type="button" className="btn-tg">
              비행정보<span className={secondExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: secondExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group">
                        <div className="date2">
                          <AppDatePicker
                            id="InvestigationReportEditdepartureAt"
                            name="departureAt"
                            label="출발일자(UTC)"
                            value={departureAt}
                            onChange={(value) => changeInput('flight.departureAt', value)}
                            errorMessage={errors['flight.departureAt']}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group va-t ant-input wid100">
                        <span className="ant-input-group-addon1">KE</span>
                        <div className="ant-input-group-addon1-input wid50 df">
                          <AppMaskInput
                            id="InvestigationReportEditflightNo"
                            mask="9999"
                            name="flightNo"
                            label="비행편명"
                            value={flightNo}
                            onChange={(value) => changeInput('flight.flightNo', 'KE' + value)}
                            hiddenClearButton
                            search={''}
                            errorMessage={errors['flight.flightNo']}
                          />
                          <div className="btn-area">
                            <button
                              type="button"
                              name="button"
                              className="btn-sm btn_text btn-darkblue-line"
                              onClick={() => {
                                searchFligh();
                              }}
                            >
                              Search
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group va-t ant-input wid100">
                        <span className="ant-input-group-addon1">HL</span>
                        <div className="ant-input-group-addon1-input wid50">
                          {/*등록기호 */}
                          <AppMaskInput
                            id="InvestigationReportEditregistrationNo"
                            mask="9999"
                            name="registrationNo"
                            label="등록 기호"
                            value={registrationNo}
                            onChange={(value) => changeInput('flight.registrationNo', 'HL' + value)}
                            hiddenClearButton
                            search={''}
                            errorMessage={errors['flight.registrationNo']}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*항공기형식 */}
                        <AppTextInput
                          id="InvestigationReportEditaircraftTypeText"
                          name="aircraftTypeText"
                          // inputType="text"
                          value={aircraftTypeText}
                          label="항공기형식"
                          onChange={(value) => changeInput('flight.aircraftTypeText', value)}
                          hiddenClearButton
                          errorMessage={errors['flight.aircraftTypeText']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*출발 공항 */}
                        <AppAutoComplete
                          label="출발 공항"
                          apiUrl="avn/common/airports"
                          value={fromAirport}
                          labelKey="label"
                          valueKey="airportCode"
                          dataKey="data.list"
                          onChange={(value) => {
                            changeInput('flight.fromAirport', value);
                          }}
                          isMultiple={false}
                          required
                          isValueString
                          errorMessage={errors['flight.fromAirport']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*도착 공항 */}
                        <AppAutoComplete
                          label="도착 공항"
                          apiUrl="avn/common/airports"
                          value={toAirport}
                          labelKey="label"
                          valueKey="airportCode"
                          dataKey="data.list"
                          onChange={(value) => {
                            changeInput('flight.toAirport', value);
                          }}
                          isMultiple={false}
                          required
                          isValueString
                          errorMessage={errors['flight.toAirport']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*회항 공항 */}
                        <AppAutoComplete
                          label="회항 공항"
                          apiUrl="avn/common/airports"
                          value={divertAirport}
                          labelKey="label"
                          valueKey="airportCode"
                          dataKey="data.list"
                          onChange={(value) => {
                            changeInput('flight.divertAirport', value);
                          }}
                          isMultiple={false}
                          required
                          isValueString
                          errorMessage={errors['flight.divertAirport']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="InvestigationReportEditsupply"
                          name="supply"
                          value={supply}
                          label="좌석수(F/C/Y)"
                          onChange={(value) => changeInput('flight.supply', value)}
                          hiddenClearButton
                          errorMessage={errors['flight.supply']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="InvestigationReportEditcheckIn"
                          name="checkIn"
                          value={checkIn}
                          label="탑승자(F/C/Y)"
                          onChange={(value) => changeInput('flight.checkIn', value)}
                          hiddenClearButton
                          errorMessage={errors['flight.checkIn']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*승무원 */}
                        <AvnReportUserSelect
                          label="승무원"
                          userList={crewMemberList}
                          onSelect={onSelectFlightCrewList}
                          deleteUser={deleteFlightCrewList}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        <dl className={thirdExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setThirdExpaned(!thirdExpaned)}>
            <button type="button" className="btn-tg">
              조사보고서<span className={thirdExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: thirdExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap1 wid100 ">
                        <AppEditor
                          label={'개요'}
                          value={postContents}
                          onChange={(value) => {
                            changeInput('investigationReport.postContents', value);
                          }}
                          errorMessage={errors['investigationReport.postContents']}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  {/* 파일첨부영역 : drag */}
                  <div className="form-table ">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* 파일첨부영역 : drag */}
                        <AppFileAttach
                          id="InvestigationReportEditreportFileGroupSeq"
                          name="reportFileGroupSeq"
                          label="첨부파일"
                          fileGroupSeq={reportFileGroupSeq}
                          workScope={'A'}
                          updateFileGroupSeq={(newFileGroupSeq) => {
                            // TODO : newFileGroupSeq를 handle
                            changeInput('investigationReport.reportFileGroupSeq', newFileGroupSeq);
                          }}
                          errorMessage={errors['investigationReport.reportFileGroupSeq']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid50">
                        {/*Investigator */}
                        {/* <AppAutoComplete label="Investigator" required /> */}
                        <AppAutoComplete
                          label="Investigator"
                          id="InvestigationReportEditInvestigator"
                          name="Investigator"
                          apiUrl="avn/common/users"
                          value={investigateBy}
                          defaultInputValue={investigateBy}
                          labelKey="customLabel"
                          valueKey="empNo"
                          dataKey="data.list"
                          onChange={(value) => {
                            changeInput('investigationReport.investigateBy', value);
                          }}
                          isMultiple={false}
                          isValueString
                          required
                          errorMessage={errors['investigationReport.investigateBy']}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>

        <dl className={fourExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setFourExpaned(!fourExpaned)}>
            <button type="button" className="btn-tg">
              1st Risk Assessment
              <span className={fourExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: fourExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*Hazard */}
                        <AppSelect
                          label="Hazard"
                          id="InvestigationReportEditHazard"
                          applyAllSelect
                          allValue=""
                          allLabel="선택"
                          value={hazardId}
                          options={hazardListData.data}
                          labelKey="customLabel"
                          valueKey="lv3Id"
                          onChange={(value) => {
                            changeInput('hazardId', value);
                          }}
                          errorMessage={errors.hazardId}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          id="InvestigationReportEditpotentialhazardType"
                          label="원인구분"
                          options={[
                            {
                              label: '추정원인',
                              value: 'ast', //assumption
                            },
                            {
                              label: '부수요인',
                              value: 'rdc', //radical
                            },
                          ]}
                          value={hazardType}
                          onChange={(value) => {
                            changeInput('hazardType', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/*Potential Consequence*/}
                        <AppSelect
                          label="Potential Consequence"
                          id="InvestigationReportEditpotentialConsequence"
                          applyAllSelect
                          allValue=""
                          allLabel="선택"
                          value={consequenceId}
                          options={consequenceListData.data}
                          labelKey="consequenceKoNm"
                          valueKey="consequenceId"
                          onChange={(value) => {
                            changeInput('consequenceId', value);
                          }}
                          errorMessage={errors.consequenceId}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="btn-area inbtn wid100">
                        <button
                          type="button"
                          name="button"
                          className="btn-x-sm btn_text btn-darkblue-line"
                          onClick={() => {
                            if (hazardId == '') {
                              ToastService.error('Hazard를 선택해주세요');
                              document.getElementById('InvestigationReportEditHazard').focus();
                              changeErrors('hazardId', 'Hazard를 선택해주세요');
                              return;
                            } else if (consequenceId == '') {
                              ToastService.error('Potential Consequence를 선택해주세요');
                              document.getElementById('InvestigationReportEditpotentialConsequence').focus();
                              changeErrors('consequenceId', 'Hazard를 선택해주세요');
                              return;
                            } else {
                              changeErrors('hazardId', '');
                              changeErrors('consequenceId', '');
                              setIsConfirmModalOpen(true);
                            }
                            //위험평가에 추가하기
                          }}
                        >
                          + ADD
                        </button>
                        <button
                          type="button"
                          name="button"
                          className="btn-x-sm btn_text btn-darkblue-line"
                          onClick={() => setIsOpen(true)}
                        >
                          위험레벨조회
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="info-list">
                          <h3>
                            추정원인<span className="required">*</span>
                          </h3>
                          <table className="info-board">
                            <colgroup>
                              <col width="35%" />
                              <col width="40%" />
                              <col width="15%" />
                              <col width="10%" />
                            </colgroup>
                            <thead>
                              <tr>
                                <th>Hazard</th>
                                <th>Potential Consequence</th>
                                <th>1st Risk Level</th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {assumptionList == undefined
                                ? null
                                : assumptionList.map((el, index) => {
                                    return (
                                      <tr key={index}>
                                        <td className="left">{el.hazardName}</td>
                                        <td className="left">{el.consequenceName}</td>
                                        <td className="">
                                          <div className="Safety-table-cell">
                                            <a href="javascript:void(0);">
                                              <span className="Safety-tag Select" onClick={() => setIsOpen(true)}>
                                                Select
                                              </span>
                                            </a>
                                          </div>
                                        </td>
                                        <td className="">
                                          <a href="javascript:void(0);">
                                            <span
                                              className="delete"
                                              onClick={() => {
                                                //삭제 index번호 추출
                                                setDeleteAssessmentIndex(index);
                                                //위험평가 삭제 구분
                                                setDeleteAssessment(true);
                                                //위험평가 삭제 확인 confirm 팝업 open
                                                setIsAssessmentDeleteIsConfirmModalOpen(true);
                                              }}
                                            >
                                              X
                                            </span>
                                          </a>
                                        </td>
                                      </tr>
                                    );
                                  })}
                            </tbody>
                          </table>
                        </div>
                        <div className="info-list">
                          <h3>
                            부수요인<span className="required">*</span>
                          </h3>
                          <table className="info-board">
                            <colgroup>
                              <col width="35%" />
                              <col width="40%" />
                              <col width="15%" />
                              <col width="10%" />
                            </colgroup>
                            <thead>
                              <tr>
                                <th>Hazard</th>
                                <th>Potential Consequence</th>
                                <th>1st Risk Level</th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {radicalList == undefined
                                ? null
                                : radicalList.map((el, index) => {
                                    return (
                                      <tr key={index}>
                                        <td className="left">{el.hazardName}</td>
                                        <td className="left">{el.consequenceName}</td>
                                        <td className="">
                                          <div className="Safety-table-cell">
                                            <a href="javascript:void(0);">
                                              <span className="Safety-tag Select" onClick={() => setIsOpen(true)}>
                                                Select
                                              </span>
                                            </a>
                                          </div>
                                        </td>
                                        <td className="">
                                          <a href="javascript:void(0);">
                                            <span
                                              className="delete"
                                              onClick={() => {
                                                //삭제 index번호 추출
                                                setDeleteAssessmentIndex(index);
                                                //위험평가 삭제 구분
                                                setDeleteAssessment(false);
                                                //위험평가 삭제 확인 confirm 팝업 open
                                                setIsAssessmentDeleteIsConfirmModalOpen(true);
                                              }}
                                            >
                                              X
                                            </span>
                                          </a>
                                        </td>
                                      </tr>
                                    );
                                  })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
        <dl className={fiveExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setFiveExpaned(!fiveExpaned)}>
            <button type="button" className="btn-tg">
              결재정보
              <span className={fiveExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: fiveExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid50">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <AppSelect
                              id="AvnIvApprovalGroupSelectFormgroupName"
                              label={'결재Group 명'}
                              value={approvalGroupID}
                              onChange={(value) => {
                                changeInput('approvalGroupID', value);
                                getMember(value);
                              }}
                              options={approvalGroupList}
                              labelKey="groupName"
                              valueKey="id"
                              required
                              errorMessage={errors.approvalGroupID}
                            />
                          </div>
                          <div className="form-group wid100 mt10">
                            <AvnReportUserSelect
                              label="사용자검색"
                              displaySort
                              userList={memberList}
                              onSelect={onSelectapprovalGroupList}
                              deleteUser={isDeleteConfirmModalOpen}
                              up={up}
                              down={down}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="btn-area">
                        <button
                          type="button"
                          name="button"
                          className="btn-sm btn_text btn-darkblue-line"
                          onClick={() => setIsApprovalOpen(true)}
                        >
                          결재그룹설정
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={() => {}}>
          출력
        </button>
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_conblue"
          onClick={() => {
            changeInput('isSubmitted', 'Y');
            save();
          }}
        >
          제출
        </button>

        <button type="button" name="button" className="btn_text btn_list" onClick={cancel}>
          목록
        </button>
      </div>
      {/* //하단버튼영역 */}
      {/* 위험레벨 모달 */}
      {/* 추정원인, 부수요인 확인 팝업창 */}
      <ConfirmModal
        title={hazardType == 'ast' ? '추정원인을 추가 하시겠습니까?' : '부수요인을 추가 하시겠습니까?'}
        body=""
        okLabel="저장"
        cancelLabel="닫기"
        isOpen={isConfirmModalOpen}
        closeModal={() => setIsConfirmModalOpen(false)}
        cancel={confirmModalCancel}
        ok={confirmModalOk}
      />
      {/* 추정원인, 부수요인 삭제 확인 팝업창 */}
      <ConfirmModal
        title={deleteAssessment ? '해당 추정원인을 삭제 하시겠습니까?' : '해당 부수요인을 삭제 하시겠습니까?'}
        body={''}
        okLabel="삭제"
        cancelLabel="닫기"
        isOpen={isAssessmentDeleteConfirmModalOpen}
        closeModal={() => setIsAssessmentDeleteIsConfirmModalOpen(false)}
        cancel={isAssessmentDeleteConfirmCancle}
        ok={deleteAssessment ? deleteConfirmAssumptionOk : deleteConfirmRadicalOk}
      />
      {/* 삭제 확인 팝업창 */}
      <ConfirmModal
        title={'삭제하시겠습니까?'}
        body=""
        okLabel="삭제"
        cancelLabel="닫기"
        isOpen={isDeleteConfirmModal}
        closeModal={() => isDeleteConfirmModalClose()}
        cancel={isDeleteConfirmModalClose}
        ok={deleteConfirmModalOk}
      />
      {/* 그룹설정 팝업창 */}
      <AvnIvApprovalGroupFormModal
        isOpen={isApprovalOpen}
        closeModal={closeApprovalModal}
        getGroupIvReportEdit={getApprovalGroup}
      />
      <ReportDocumentModal
        isOpen={isReportDocumentOpen}
        closeModal={closeReportDocumentModal}
        checkDataList={reportDocument}
      />
    </>
  );
}
export default InvestigationReportMitigationEdit;
