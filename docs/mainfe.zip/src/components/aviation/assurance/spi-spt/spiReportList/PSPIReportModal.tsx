import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppSelect from '@/components/common/AppSelect';
import ReportLevelModal from '@/components/modal/ReportLevelModal';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { createListSlice } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import dayjs from 'dayjs';
import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import * as yup from 'yup';
import { create } from 'zustand';

const yupFormSchema = yup.object({
  updSpiType: yup.string().required(),
  updSpiCode: yup.string().required(),
  updRiskLevelCd: yup.string().required(),
});

// TODO : 검색 초기값 설정
const initSearchParam = {
  reportId: '',
  year: dayjs().year(),
  updSpiType: '',
  updSpiCode: '',
  updRiskLevelCd: '',
  updColorCd: '',
};

/* zustand store 생성 */
const usePSPIReportModalStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    reportId: '',
    year: dayjs().year(),
    updSpiType: '',
    updSpiCode: '',
    updRiskLevelCd: '',
    updColorCd: '',
  },

  spiCodeList: [],
  isReportLevelModal: false,

  handleReportLevelModal: (val) => {
    set({ isReportLevelModal: val });
  },

  spiCodeSearch: async () => {
    const { searchParam } = get();
    const { year, updSpiType } = searchParam;
    const apiParam = { year: year, spiType: updSpiType };
    if (year && updSpiType) {
      const apiResult = await ApiService.get(`avn/assurance/spi-spt/spiCodeList`, apiParam);
      set({ spiCodeList: [{ label: 'N/A', value: 'NA' }, ...apiResult.data] });
    }
  },
  handleSelectRisk: (val) => {
    const { changeSearchInput } = get();

    changeSearchInput('updRiskLevelCd', val.riskLevelCd);
    changeSearchInput('updColorCd', val.colorCd);
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ searchParam: { ...initSearchParam } });
  },
}));

function PSPIReportModal(props) {
  const state = usePSPIReportModalStore();

  const {
    searchParam,
    changeSearchInput,
    spiCodeSearch,
    spiCodeList,
    isReportLevelModal,
    handleReportLevelModal,
    handleSelectRisk,
    clear,
  } = state;

  // input value에 넣기 위한 분리 선언
  const { year, updSpiType, updSpiCode, updRiskLevelCd, updColorCd } = searchParam;

  const { isOpen, closeModal, ok, rowData } = props;
  const [errors, setErrors] = useState<any>({});

  const {
    reportId,
    reportDocno,
    departureDt,
    aircraftTypeCd,
    aircraftTypeKor,
    aircraftTypeEng,
    fleetNm,
    regNo,
    flightNo,
    departureAirportCd,
    arrivalAirportCd,
    occurAirportCd,
    subjectNm,
    eventId,
    eventName,
    eventSummary,
    spiTypeCd,
    spiCd,
    riskLevelCd,
    colorCd,
  } = rowData;

  const spiCodeSave = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, searchParam);
    const { success, firstErrorFieldKey, errors } = validateResult;

    const formName = 'PSPIReportModal';

    if (success) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const { reportId, year, updSpiCode, updRiskLevelCd, updColorCd, updSpiType } = searchParam;
          const apiParam = {
            spiYear: year,
            spiCd: updSpiCode,
            riskLevelCd: updRiskLevelCd,
            colorCd: updColorCd,
            spiTypeCd: updSpiType,
          };
          await ApiService.put(`avn/assurance/spi-spt/reports/${reportId}`, apiParam);

          ToastService.success('저장되었습니다.');
          ok();
          clear();
          closeModal();
        },
      });
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  useEffect(() => {
    changeSearchInput('reportId', reportId);
    changeSearchInput('updSpiType', spiTypeCd);
    changeSearchInput('updSpiCode', spiCd);
    changeSearchInput('updRiskLevelCd', riskLevelCd);
    changeSearchInput('updColorCd', colorCd);

    if (spiTypeCd) spiCodeSearch();
    return;
  }, [rowData, riskLevelCd, colorCd]);
  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'alert-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">SPI 지표 추가</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              <div className="editbox">
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">Doc No</label>
                            <span className="text-desc-type1"> {reportDocno} </span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">Departure Date</label>
                            <span className="text-desc-type1"> {departureDt}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">Aircraft Type</label>
                            <span className="text-desc-type1"> {aircraftTypeKor}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">Fleet</label>
                            <span className="text-desc-type1"> {fleetNm}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">Registration No</label>
                            <span className="text-desc-type1"> {regNo}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">Flight No</label>
                            <span className="text-desc-type1"> {flightNo}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">From</label>
                            <span className="text-desc-type1"> {departureAirportCd}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">To</label>
                            <span className="text-desc-type1"> {arrivalAirportCd}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">Airport</label>
                            <span className="text-desc-type1"> {occurAirportCd}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">Subject</label>
                            <span className="text-desc-type1"> {subjectNm}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">Event Type</label>
                            <span className="text-desc-type1"> {eventName}</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        id="PSPIReportModalupdSpiType"
                        label={'지표구분'}
                        codeGrpId="CODE_GRP_113"
                        value={updSpiType}
                        required
                        errorMessage={errors.updSpiType}
                        onChange={(value) => {
                          changeSearchInput('updSpiType', value);
                          changeSearchInput('updSpiCode', '');

                          spiCodeSearch();
                        }}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppSelect
                        id="PSPIReportModalupdSpiCode"
                        label="지표명"
                        value={updSpiCode}
                        options={spiCodeList}
                        required
                        errorMessage={errors.updSpiCode}
                        onChange={(value) => {
                          changeSearchInput('updSpiCode', value);
                        }}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="box-view-list">
                        <ul className="view-list">
                          <li className="accumlate-list">
                            <label className="t-label">
                              SPI 위험도 <span className="required">*</span>
                            </label>
                            <span className="text-desc-type1" id="riskLine">
                              {updRiskLevelCd ? (
                                <span className={'Safety-tag riskLevel ' + updColorCd}>{updRiskLevelCd}</span>
                              ) : (
                                <></>
                              )}
                              <button
                                type="button"
                                className="btn-class choice"
                                onClick={() => handleReportLevelModal(true)}
                              >
                                위험도 선택
                              </button>
                            </span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
              </div>
            </div>
          </div>
        </div>
        <div className="pop_btns">
          <button
            className="btn_text text_color_neutral-90 btn_close"
            onClick={() => {
              clear();
              setErrors({});
              closeModal();
            }}
          >
            닫기
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={spiCodeSave}>
            저장
          </button>
        </div>
        <span
          className="pop_close"
          onClick={() => {
            clear();
            setErrors({});
            closeModal();
          }}
        >
          X
        </span>
      </div>
      {/*위험도 선택팝업 */}
      <ReportLevelModal
        isOpen={isReportLevelModal}
        closeModal={() => handleReportLevelModal(false)}
        selectRisk={(rtnRiskCode) => handleSelectRisk(rtnRiskCode)}
        params={{ paramEventId: eventId }}
      />
    </Modal>
  );
}

export default PSPIReportModal;
