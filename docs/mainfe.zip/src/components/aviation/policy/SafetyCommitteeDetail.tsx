import { useEffect, useState } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useParams, useNavigate } from 'react-router-dom';
import ApiService from '@/services/ApiService';
import CodeService from '@/services/CodeService';
import AppFileAttach from '@/components/common/AppFileAttach';
import useAuthCheck from '@/hooks/useAuthCheck';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
import { useTranslation } from 'react-i18next';

function SafetyCommitteeDetail() {
  //언어설정
  const { t } = useTranslation();
  // TODO:나중에 권한 다시 확인하기 (Admin 권한)
  const AdminAuth = useAuthCheck('SYSTEM_ADMIN', true);
  //사용자 profile 적용
  const profile = useStore(useAppStore, (state) => state.profile);

  const navigate = useNavigate();
  const [detailInfo, setDetailInfo] = useState<any>({});

  const { division, conferenceType, conferenceDt, conferenceTitle, fileGroupSeq, regUserId } = detailInfo;

  const { detailId } = useParams();

  const cancel = () => {
    navigate('/aviation/policy/safety-committee');
  };

  const goFormPage = () => {
    navigate(`/aviation/policy/safety-committee/${detailId}/edit`);
  };

  useEffect(() => {
    ApiService.get(`avn/policy/committee/${detailId}`).then((apiResult) => {
      const detailInfo = apiResult.data || {};
      setDetailInfo(detailInfo);
    });
  }, []);

  console.log('SafetyCommitteeDetail render');

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>안전회의체 상세</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.conference.label.00001')}</label>
                    <span className="text-desc-type1">{CodeService.getCodeLabelByValue('CODE_GRP_149', division)}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.committee.label.00004')}</label>
                    <span className="text-desc-type1">
                      {CodeService.getCodeLabelByValue('CODE_GRP_150', conferenceType)}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.committee.label.00005')}</label>
                    <span className="text-desc-type1">{conferenceDt}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.committee.label.00003')}</label>
                    <span className="text-desc-type1">{conferenceTitle}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : drag */}
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <AppFileAttach
                      mode="view"
                      label={t('ke.safety.committee.label.00006')}
                      fileGroupSeq={fileGroupSeq}
                      workScope={'업무구문(A,O,S)'}
                      onlyImageUpload={false}
                    />
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          {t('ke.safety.common.label.00006')}
        </button>
        {AdminAuth === true ? (
          <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
            {t('ke.safety.common.label.00007')}
          </button>
        ) : profile.userInfo.userId == regUserId ? (
          <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
            {t('ke.safety.common.label.00007')}
          </button>
        ) : null}
      </div>
    </>
  );
}
export default SafetyCommitteeDetail;
