import { useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import useCheckListStore from '@/stores/aviation/audit/checklist/useCheckListStore';
import ChecklistAddModal from './ChecklistAddModal';
import AppNavigation from '@/components/common/AppNavigation';
import AppCodeSelect from '@/components/common/AppCodeSelect';

function AuditCheckList() {
  const {
    langCode,
    changeLangCode,
    getDivisionList,
    dsDivisionList,
    currentDivisionTabIndex,
    changeDivisionTabIndex,
    dsAuditChecklist,
    viewSelectedChapter,
    editSelectedChapter,
    clearList,

    openCheckListUploadModal,
    openCheckListAddModal,
    closeCheckListAddModal,
    isCheckListAddModal,
    okChecklistAddModal,
  } = useCheckListStore();

  const [searchParams] = useSearchParams();
  const divisionSearchParam = searchParams.get('division');

  const init = useCallback(async () => {
    getDivisionList(divisionSearchParam);
  }, [divisionSearchParam]);

  useEffect(() => {
    init();
    return clearList;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="swiper-container">
          <div className="menu-tab Audit">
            {dsDivisionList.map((tabInfo, index) => {
              const { codeNameKor } = tabInfo;
              return (
                <a
                  key={codeNameKor}
                  href="javascript:void(0);"
                  className={currentDivisionTabIndex === index ? 'active' : ''}
                  data-label={codeNameKor}
                  onClick={() => changeDivisionTabIndex(index)}
                >
                  {codeNameKor}
                  {/* <button type="button" className="tabs-tab-remove">
                    <span className="delete">X</span>
                  </button> */}
                </a>
              );
            })}
          </div>
          <div className="menu-tab-nav-operations">
            <button type="button" name="button" className="menu-tab-nav-more">
              <span className="hide">더보기</span>
            </button>
          </div>
        </div>
      </div>

      <div className="form-table Audit">
        <div className="form-cell wid100">
          <div className="form-group wid100">
            <div className="btn-area Audit">
              <div className="type5">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_120"
                  applyAllSelect
                  name="langType"
                  label="Lang Type"
                  labelKey="codeNameKor"
                  valueKey="codeId"
                  value={langCode}
                  onChange={(value) => changeLangCode(value)}
                />
              </div>
              <div className="btn-area-box">
                <button
                  type="button"
                  name="button"
                  className="btn-sm btn_text btn-darkblue-line"
                  onClick={openCheckListUploadModal}
                >
                  Checklist Upload
                </button>
                <button
                  type="button"
                  name="button"
                  className="btn-sm btn_text btn-darkblue-line"
                  onClick={openCheckListAddModal}
                >
                  Add Checklist
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*검색영역 
      <div className="btn-area Audit">
        <div className="btn-area-box">
          <div className="form-table">
            <div className="form-cell">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_120"
                  applyAllSelect
                  name="langType"
                  label="Lang Type"
                  labelKey="codeNameKor"
                  valueKey="codeId"
                  value={langCode}
                  onChange={(value) => changeLangCode(value)}
                />
              </div>
            </div>
          </div>
        </div>
        <button
          type="button"
          name="button"
          className="btn-sm btn_text btn-darkblue-line"
          onClick={openCheckListUploadModal}
        >
          Checklist Upload
        </button>
        <button
          type="button"
          name="button"
          className="btn-sm btn_text btn-darkblue-line"
          onClick={openCheckListAddModal}
        >
          Add Checklist
        </button>
      </div>
      //검색영역 */}

      <div className="checklist-contents">
        {dsAuditChecklist.map((checklistInfo) => {
          const { division, checklistId, checklistOrigId, checklistName, chapters } = checklistInfo;
          return (
            <div key={checklistId} className="checklist-row list">
              <div className="checklist-col">
                <h4>
                  <label>
                    <button
                      type="button"
                      name="button"
                      className="btn-list editChapter"
                      onClick={() =>
                        editSelectedChapter(
                          division,
                          checklistOrigId,
                          chapters !== null ? 0 : chapters[0].chapterOrigId
                        )
                      }
                    >
                      <span className="visible"></span>
                    </button>
                    <a
                      href="javascript:void(0);"
                      onClick={() =>
                        viewSelectedChapter(
                          division,
                          checklistOrigId,
                          chapters !== null ? 0 : chapters[0].chapterOrigId
                        )
                      }
                    >
                      <span>{checklistName}</span>
                    </a>
                  </label>
                </h4>
                <ul>
                  {chapters.map((chapterInfo) => {
                    const { chapterId, chapterOrigId, questionCount, chapterName } = chapterInfo;
                    return (
                      <li key={chapterId} className="list-space">
                        <div className="ant-space">
                          <div className="ant-space-item">
                            <button
                              type="button"
                              name="buttonTest1"
                              className="btn-list editChapter"
                              onClick={() => editSelectedChapter(division, checklistOrigId, chapterOrigId)}
                            >
                              <span className="visible"></span>
                            </button>
                          </div>
                          <div className="ant-space-item">
                            <a
                              href="javascript:void(0);"
                              onClick={() => viewSelectedChapter(division, checklistOrigId, chapterOrigId)}
                            >
                              {chapterName} <i>({questionCount})</i>
                            </a>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </div>
          );
        })}
      </div>
      <ChecklistAddModal
        isOpen={isCheckListAddModal}
        closeModal={closeCheckListAddModal}
        ok={(formValue) => okChecklistAddModal(formValue)}
      />
    </>
  );
}

export default AuditCheckList;
