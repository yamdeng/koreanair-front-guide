import AppDatePicker from '@/components/common/AppDatePicker';
import AppSelect from '@/components/common/AppSelect';
import ApiService from '@/services/ApiService';
import { createListSlice } from '@/stores/slice/listSlice';
import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';
import { create } from 'zustand';

// TODO : 검색 초기값 설정
const initSearchParam = {
  selectEventId: '',
  fromDt: dayjs().add(-3, 'month').format('YYYY-MM-DD'),
  toDt: dayjs().format('YYYY-MM-DD'),
  searchDateFromDisabled: true,
  searchDateToDisabled: true,
  gubun: [
    { codeId: 1, codeNm: 'event' },
    { codeId: 2, codeNm: 'hazard' },
  ],
  searchGubun: '',
  selectDate: 'searchDate3month',
};

/* zustand store 생성 */
const useAdminTopRiskStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    selectEventId: '',
    fromDt: dayjs().add(-3, 'month').format('YYYY-MM-DD'),
    toDt: dayjs().format('YYYY-MM-DD'),
    searchDateFromDisabled: true,
    searchDateToDisabled: true,
    gubun: [
      { codeId: 1, codeNm: 'event' },
      { codeId: 2, codeNm: 'hazard' },
    ],
    searchGubun: '',
    selectDate: 'searchDate3month',
  },

  calcBfList: [],
  calcAfList: [],
  etcList: [],

  initInfoSearch: async () => {
    const { searchParam, scrollProcess } = get();
    const { gubun, fromDt, toDt } = searchParam;

    const apiParam = {
      gubun: gubun,
      fromDt: fromDt,
      toDt: toDt,
    };
    const apiResult = await ApiService.get(`avn/admin/top-risk`, apiParam);
  },

  clear: () => {},
}));

function AdminTopRisk() {
  const state = useAdminTopRiskStore();
  const { t } = useTranslation();

  const { searchParam, changeSearchInput, enterSearch, clear } = state;

  // input value에 넣기 위한 분리 선언
  const { selectDate, fromDt, toDt, searchDateFromDisabled, searchDateToDisabled, gubun, searchGubun } = searchParam;

  const searchDateChange = (e) => {
    changeSearchInput('selectDate', e.target.id);
    let inputFromDate = dayjs().format('YYYY-MM-DD');
    let inputToDate = dayjs().format('YYYY-MM-DD');
    let searchYn = true;
    changeSearchInput('searchDateFromDisabled', true);
    changeSearchInput('searchDateToDisabled', true);

    if (e.target.id === 'searchDateSelect') {
      inputFromDate = dayjs().format('YYYY-MM-DD');
      inputToDate = dayjs().format('YYYY-MM-DD');
      changeSearchInput('searchDateFromDisabled', false);
      changeSearchInput('searchDateToDisabled', false);
      searchYn = false;
    } else if (e.target.id === 'searchDateTotal') {
      inputFromDate = dayjs('2000-01-01').format('YYYY-MM-DD');
      inputToDate = dayjs('9999-12-31').format('YYYY-MM-DD');
    } else if (e.target.id === 'searchDate1year') {
      inputFromDate = dayjs().add(-1, 'year').format('YYYY-MM-DD');
      inputToDate = dayjs().format('YYYY-MM-DD');
    } else if (e.target.id === 'searchDate6month') {
      inputFromDate = dayjs().add(-6, 'month').format('YYYY-MM-DD');
      inputToDate = dayjs().format('YYYY-MM-DD');
    } else if (e.target.id === 'searchDate3month') {
      inputFromDate = dayjs().add(-3, 'month').format('YYYY-MM-DD');
      inputToDate = dayjs().format('YYYY-MM-DD');
    }

    changeSearchInput('fromDt', inputFromDate);
    changeSearchInput('toDt', inputToDate);
  };

  return (
    <>
      {/*경로 */}
      <div className="Breadcrumb">
        <ol>
          <li className="breadcrumb-item">
            <a href="javascript:void(0);">홈</a>
          </li>
          <li className="breadcrumb-item">
            <a href="javascript:void(0);">관리자</a>
          </li>
          <li className="breadcrumb-item">
            <a href="javascript:void(0);">Top 10 Event 관리</a>
          </li>
        </ol>
      </div>
      {/*경로 */}
      <div className="conts-title">
        <h2>Top 10 RISK 관리</h2>
      </div>
      {/*탭 */}

      {/*검색영역 */}
      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell Risk">
            {' '}
            <div className="flag-tag1">
              <span
                id="searchDateSelect"
                className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDateSelect' ? 'active' : ''}`}
                onClick={(e) => {
                  searchDateChange(e);
                }}
              >
                기간선택
              </span>
              <span
                id="searchDateTotal"
                className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDateTotal' ? 'active' : ''}`}
                onClick={(e) => {
                  searchDateChange(e);
                }}
              >
                전체
              </span>
              <span
                id="searchDate1year"
                className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDate1year' ? 'active' : ''}`}
                onClick={(e) => {
                  searchDateChange(e);
                }}
              >
                1년
              </span>
              <span
                id="searchDate6month"
                className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDate6month' ? 'active' : ''}`}
                onClick={(e) => {
                  searchDateChange(e);
                }}
              >
                6개월
              </span>
              <span
                id="searchDate3month"
                className={`icon-flag1 txt btn-lightblue ${selectDate == 'searchDate3month' ? 'active' : ''}`}
                onClick={(e) => {
                  searchDateChange(e);
                }}
              >
                3개월
              </span>

              {/* 선택되는 부분은 class명에 active 표시*/}
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid50 ml5">
              <div className="df">
                <div className="date1">
                  <AppDatePicker
                    id="searchDateFrom"
                    label={t('ke_change_mgmt_label_00556')}
                    pickerType="date"
                    value={fromDt}
                    onChange={(value) => {
                      changeSearchInput('fromDt', value);
                    }}
                    disabled={searchDateFromDisabled}
                    required
                  />
                </div>
                <span className="unt">~</span>
                <div className="date2">
                  <AppDatePicker
                    id="searchDateTo"
                    label={t('ke_report_label_00203')}
                    pickerType="date"
                    value={toDt}
                    onChange={(value) => {
                      changeSearchInput('toDt', value);
                    }}
                    disabled={searchDateToDisabled}
                    required
                  />
                </div>
              </div>
              <div className="form-group wid30">
                <AppSelect
                  label="구분"
                  options={gubun}
                  value={searchGubun}
                  labelKey="codeNm"
                  valueKey="codeId"
                  onChange={(value) => {
                    changeSearchInput('searchGubun', value);
                  }}
                />
              </div>
            </div>
          </div>
          {/* <div className="form-cell wid50">
            <div className="form-group wid0">
              <div className="df">
                <div className="date1">
                  <AppDatePicker label={'작성일'} />
                </div>
                <span className="unt">~</span>
                <div className="date2">
                  <AppDatePicker label={'작성일'} />
                </div>
              </div>
            </div>
          </div> */}
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
              재계산
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
              조회
            </button>
          </div>
        </div>
      </div>
      {/* //검색영역 */}

      {/*컨텐츠영역 */}
      <div className="checkbox-wrap">
        <div className="btns-area">
          <button type="button" name="button" className="btn_text btn_confirm text_color_neutral-10">
            저장
          </button>
        </div>
        <div className="checkbox-area">
          <div className="checklist">
            <div className="h3">Top Event List by Risk Level Score</div>
            <div className="listbox">
              <div className="search-list">
                <ul className="list">
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" checked />
                          <span className="ck-list">Crew schedule</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Flap placard speed over</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Securify irregularity(General)Uh-schedule engine removal</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Securify irregularity(General)Uh-schedule engine removal</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Securify irregularity(General)Uh-schedule engine removal</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Securify irregularity(General)Uh-schedule engine removal</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Securify irregularity(General)Uh-schedule engine removal</span>
                        </label>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="form-cell">
                <div className="chk-wrap">
                  <label>
                    <input type="checkbox" checked />
                    <span className="ck-list">사용</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
          <div className="checklist">
            <div className="h3">Top Event List by Risk Level Score(이상값제거)</div>
            <div className="listbox">
              <div className="search-list">
                <ul className="list">
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" checked />
                          <span className="ck-list">Crew schedule</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Flap placard speed over</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Securify irregularity(General)Uh-schedule engine removal</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Flap placard speed over</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Flap placard speed over</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Flap placard speed over</span>
                        </label>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="form-cell">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span className="ck-list">Flap placard speed over</span>
                        </label>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="form-cell">
                <div className="chk-wrap">
                  <label>
                    <input type="checkbox" checked />
                    <span className="ck-list">사용</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="info-text">
          * 주) Top Event List 중 사용을 원하는 항목에 check해 주십시오. Check된 항목이 항공안전 Home의 Top 10 Event로
          표출됩니다.
        </div>
        <div className="checkbox-area mt20">
          <div className="checklist wid100">
            <div className="h3">이상값 검출 Event List</div>
            <div className="listbox">
              <div className="search-list">
                <ul className="list">
                  <div>그리드자리</div>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="info-text">* 주) 분석포함을 선택하면 원래 평가값을 적용하여 재 계산 됩니다.</div>
      </div>
      {/*//컨텐츠영역 */}
    </>
  );
}

export default AdminTopRisk;
