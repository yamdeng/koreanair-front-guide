import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppTextArea from '@/components/common/AppTextArea';
import AppTextInput from '@/components/common/AppTextInput';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import { createListSlice } from '@/stores/slice/listSlice';
import history from '@/utils/history';

import { produce } from 'immer';
import React, { useEffect } from 'react';
import * as yup from 'yup';
import { create } from 'zustand';

// TODO : yup 3개 목록을 반영
// 1.riskPbbtList : codeField1, codeField2
// 2.riskMatrixList : colorCd, scoreCo
// 3.riskSvrtList : codeField1, codeField2, codeField3, codeField4, codeField5

const yupFormSchema = yup.object().shape({
  riskPbbtList: yup.array().of(
    yup.object().shape({
      codeField1: yup.string().required('정성적 평가 is a required field'),
      codeField2: yup.string().required('정량적 평가 is a required field'),
    })
  ),
  riskMatrixList: yup.array().of(
    yup.object().shape({
      colorCd: yup.string().required('심각도색상 is a required field'),
      scoreCo: yup.number().required('점수 is a required field'),
    })
  ),
  riskSvrtList: yup.array().of(
    yup.object().shape({
      codeNameKor: yup.string().required('심각도구분 is a required field'),
      codeField1: yup.string().required('매우심각 is a required field'),
      codeField2: yup.string().required('위험 is a required field'),
      codeField3: yup.string().required('중요 is a required field'),
      codeField4: yup.string().required('경미 is a required field'),
      codeField5: yup.string().required('매우 경미 is a required field'),
    })
  ),
});

/* zustand store 생성 */
const useAdminRiskMatrixDetailStore = create<any>((set, get) => ({
  ...createListSlice(set, get),
  ...createFormSliceYup(set, get),
  ...formBaseState,

  yupFormSchema: yupFormSchema,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {},

  riskPbbtList: [],
  riskMatrixList: [],
  riskSvrtList: [],
  riskInfo: [],
  formValue: {
    riskPbbtList: [],
    riskMatrixList: [],
    riskSvrtList: [],
  },

  lastUpdateDttm: '',

  initInfoSearch: async () => {
    const apiParam = {};
    const apiResult = await ApiService.get(`avn/admin/risk-matrix`, apiParam);

    const riskPbbtList = apiResult.data.riskPbbt.body.data || [];
    const riskMatrixList = apiResult.data.riskMatrix || [];
    const riskSvrtList = apiResult.data.riskSvrt.body.data || [];

    set({
      formValue: {
        riskPbbtList: riskPbbtList,
        riskMatrixList: riskMatrixList,
        riskSvrtList: riskSvrtList,
      },
      lastUpdateDttm: apiResult.data.riskMatrix[0].regDttmInfo,
    });
    const { changeInput, errors } = get();
    const rtnArr = [];
    let arr = [];
    riskMatrixList.map((info, index) => {
      arr.push(
        <td id={info.riskLevelCd} key={'td' + index}>
          <AppCodeSelect
            key={`riskMatrixList[${index}].colorCd`}
            id={`riskMatrixList[${index}].colorCd`}
            codeGrpId="CODE_GRP_174"
            name={info.colorCd}
            value={info.colorCd}
            onChange={(value) => changeInput(`riskMatrixList[${index}].colorCd`, value)}
            errorMessage={errors[`riskMatrixList[${index}].colorCd`]}
            required
          />
          <AppTextInput
            key={`riskMatrixList[${index}].scoreCo`}
            id={`riskMatrixList[${index}].scoreCo`}
            name="scoreRisk"
            value={info.scoreCo}
            inputType="number"
            onChange={(value) => changeInput(`riskMatrixList[${index}].scoreCo`, value)}
            errorMessage={errors[`riskMatrixList[${index}].scoreCo`]}
            required
          />
        </td>
      );
      if (index % 5 === 4 || index === riskMatrixList.length - 1) {
        const thElement = <th key={'th' + index}>{5 - Math.floor(index / 5)}</th>;
        rtnArr.push(React.createElement('tr', { key: 'risk' + index }, [thElement, ...arr]));
        arr = [];
      }
    });
    set({ riskInfo: rtnArr });
  },

  // 항목 수정
  changeList: async (listName, listLindex, keyName, value) => {
    set(
      produce((state: any) => {
        let listInfo = [];
        if (listName == 'risk') {
          listInfo = state.riskMatrixList[listLindex];
        } else if (listName == 'pbbt') {
          listInfo = state.riskPbbtList[listLindex];
        } else if (listName == 'svrt') {
          listInfo = state.riskSvrtList[listLindex];
        }
        listInfo[keyName] = value;
      })
    );
  },
  riskSave: async () => {
    const { formValue, validate } = get();
    const { riskPbbtList, riskMatrixList, riskSvrtList } = formValue;

    const apiParam = {
      riskPbbt: riskPbbtList,
      riskMatrix: riskMatrixList,
      riskSvrt: riskSvrtList,
    };

    if (await validate()) {
      // todo validtion 체크
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiResult = await ApiService.put(`avn/admin/risk-matrix`, apiParam);
          ToastService.success('저장되었습니다.');
          history.push(`/aviation/risk-matrix`);
        },
      });
    }
  },
}));

function AdminRiskMatrixDetail() {
  const state = useAdminRiskMatrixDetailStore();

  const { changeInput, errors, riskInfo, initInfoSearch, formValue, riskSave } = state;

  const { riskMatrixList, riskPbbtList, riskSvrtList } = formValue;

  const goListPage = () => {
    history.push(`/aviation/risk-matrix`);
  };
  useEffect(() => {
    initInfoSearch();
    return;
  }, []);
  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>Risk Matrix 관리 수정</h2>
      </div>

      {/*그리드영역 */}
      <div className="RiskLevel-Wrap">
        <div className="RiskLevel-Left">
          <div className="h4-tit">발생가능성</div>
          <div className="tableTop">
            <table className="RiskLevelTable left">
              <caption></caption>
              <colgroup>
                <col width="8%" />
                <col width="18%" />
                <col width="37%" />
                <col width="37%" />
              </colgroup>
              <thead>
                <tr>
                  <th>구분</th>
                  <th>발생가능성</th>
                  <th>정성적 평가</th>
                  <th>정량적 평가</th>
                </tr>
              </thead>
              <tbody>
                {riskPbbtList.map((info, index) => {
                  const { codeNameKor, codeField1, codeField2 } = info;
                  return (
                    <tr key={'Pbbt' + index}>
                      <th>{riskPbbtList.length - index}</th>
                      <td className="">{codeNameKor}</td>
                      <td className="tl">
                        <AppTextArea
                          key={`riskPbbtList[${index}].codeField1`}
                          id={`riskPbbtList[${index}].codeField1`}
                          label=""
                          style={{ width: '100%', height: 82 }}
                          placeholder=""
                          value={codeField1}
                          onChange={(value) => changeInput(`riskPbbtList[${index}].codeField1`, value)}
                          errorMessage={errors[`riskPbbtList[${index}].codeField1`]}
                        />
                      </td>
                      <td>
                        <AppTextArea
                          key={`riskPbbtList[${index}].codeField2`}
                          id={`riskPbbtList[${index}].codeField2`}
                          label=""
                          style={{ width: '100%', height: 82 }}
                          value={codeField2}
                          onChange={(value) => changeInput(`riskPbbtList[${index}].codeField2`, value)}
                          placeholder="5일 단위
(1년 중 65건 이상)
"
                          errorMessage={errors[`riskPbbtList[${index}].codeField2`]}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        <div className="RiskLevel-Right">
          <div className="h4-tit">RISK</div>
          <div className="">
            <table className="RiskLevelTable Risk">
              <caption></caption>
              <colgroup></colgroup>
              <thead>
                <tr>
                  <th rowSpan={2}>
                    발생
                    <br />
                    가능성
                  </th>
                  <th colSpan={5}>심각도</th>
                </tr>
                <tr>
                  <th>LevelA</th>
                  <th>LevelB</th>
                  <th>LevelC</th>
                  <th>LevelD</th>
                  <th>LevelE</th>
                </tr>
              </thead>
              <tbody id="riskTable">{riskInfo}</tbody>
            </table>
          </div>
        </div>
      </div>
      <div className="RiskLevel-bottom">
        <p className="h4-tit">심각도</p>
        <div className="tableTop">
          <table className="RiskLevelTable severity">
            <caption></caption>
            <colgroup>
              <col width="5%" />
              <col width="10%" />
              <col width="17%" />
              <col width="17%" />
              <col width="17%" />
              <col width="17%" />
              <col width="17%" />
            </colgroup>
            <thead>
              <tr>
                <th>순번</th>
                <th>심각도구분</th>
                <th>매우심각</th>
                <th>위험</th>
                <th>중요</th>
                <th>경미</th>
                <th>매우경미</th>
              </tr>
            </thead>
            <tbody>
              {riskSvrtList.map((info, index) => {
                const { codeNameKor, codeField1, codeField2, codeField3, codeField4, codeField5 } = info;
                return (
                  <tr key={'Svrt' + index}>
                    <th>{index + 1}</th>
                    <td className="">
                      <AppTextArea
                        key={`riskSvrtList[${index}].codeNameKor`}
                        id={`riskSvrtList[${index}].codeNameKor`}
                        label=""
                        style={{ width: '100%', height: 82 }}
                        placeholder=""
                        value={codeNameKor}
                        onChange={(value) => changeInput(`riskSvrtList[${index}].codeNameKor`, value)}
                        errorMessage={errors[`riskSvrtList[${index}].codeNameKor`]}
                      />
                    </td>
                    <td className="">
                      <AppTextArea
                        key={`riskSvrtList[${index}].codeField1`}
                        id={`riskSvrtList[${index}].codeField1`}
                        label=""
                        style={{ width: '100%', height: 82 }}
                        placeholder=""
                        value={codeField1}
                        onChange={(value) => changeInput(`riskSvrtList[${index}].codeField1`, value)}
                        errorMessage={errors[`riskSvrtList[${index}].codeField1`]}
                      />
                    </td>
                    <td className="">
                      <AppTextArea
                        key={`riskSvrtList[${index}].codeField2`}
                        id={`riskSvrtList[${index}].codeField2`}
                        label=""
                        style={{ width: '100%', height: 82 }}
                        placeholder=""
                        value={codeField2}
                        onChange={(value) => changeInput(`riskSvrtList[${index}].codeField2`, value)}
                        errorMessage={errors[`riskSvrtList[${index}].codeField2`]}
                      />
                    </td>
                    <td className="">
                      <AppTextArea
                        key={`riskSvrtList[${index}].codeField3`}
                        id={`riskSvrtList[${index}].codeField3`}
                        label=""
                        style={{ width: '100%', height: 82 }}
                        placeholder=""
                        value={codeField3}
                        onChange={(value) => changeInput(`riskSvrtList[${index}].codeField3`, value)}
                        errorMessage={errors[`riskSvrtList[${index}].codeField3`]}
                      />
                    </td>
                    <td className="">
                      <AppTextArea
                        key={`riskSvrtList[${index}].codeField4`}
                        id={`riskSvrtList[${index}].codeField4`}
                        label=""
                        style={{ width: '100%', height: 82 }}
                        placeholder=""
                        value={codeField4}
                        onChange={(value) => changeInput(`riskSvrtList[${index}].codeField4`, value)}
                        errorMessage={errors[`riskSvrtList[${index}].codeField4`]}
                      />
                    </td>
                    <td className="">
                      <AppTextArea
                        key={`riskSvrtList[${index}].codeField5`}
                        id={`riskSvrtList[${index}].codeField5`}
                        label=""
                        style={{ width: '100%', height: 82 }}
                        placeholder=""
                        value={codeField5}
                        onChange={(value) => changeInput(`riskSvrtList[${index}].codeField5`, value)}
                        errorMessage={errors[`riskSvrtList[${index}].codeField5`]}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      {/*//그리드영역 */}

      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={riskSave}>
          저장
        </button>
        <button type="button" name="button" className="btn_text btn_list" onClick={goListPage}>
          목록
        </button>
      </div>
      {/* //하단버튼영역 */}
    </>
  );
}

export default AdminRiskMatrixDetail;
