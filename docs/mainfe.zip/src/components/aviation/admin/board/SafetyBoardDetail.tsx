import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import { useTranslation } from 'react-i18next';
import AppTable from '@/components/common/AppTable';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import CodeService from '@/services/CodeService';

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/board/boardList',
  baseRoutePath: '/aviation/board-manage/safety-board',
};

/* zustand store 생성 */
const AvnSafetyBoardDetailStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SafetyBoardDetail() {
  const rowData = getAllData();
  const columns = testColumnInfos;
  const [firstExpaned, setFirstExpaned] = useState(true);

  // 언어 설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const { detailInfo, getDetail, formType, cancel, goFormPage, clear } = AvnSafetyBoardDetailStore();
  const { boardType, viewYn, jobType, titleKo, content, useYn, safetyUrl, linkGroupSeq, fileGroupSeq, viewCount } =
    detailInfo;

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>Safety 게시판 상세</h2>
      </div>
      <div className="eidtbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00001')}</label>
                    <span className="text-desc-type1">
                      {CodeService.getCodeLabelByValue('CODE_GRP_141', boardType)}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00004')}</label>
                    <span className="text-desc-type1">{viewYn}</span>
                    {/* <label className="t-label">
                      열람여부 <span className="required">*</span>
                    </label>
                    <span className="text-desc-type1">
                      <div className="chk-wrap">
                        <label className="text-no">
                          <input type="checkbox" checked />
                          <span className="text-no"></span>
                        </label>
                      </div>
                    </span> */}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00005')}</label>
                    <span className="text-desc-type1">{CodeService.getCodeLabelByValue('CODE_GRP_148', jobType)}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00002')}</label>
                    <span className="text-desc-type1">{titleKo}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00009')}</label>
                    <span className="text-desc-type1">{content}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00008')}</label>
                    <span className="text-desc-type1">{safetyUrl}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00003')}</label>
                    <span className="text-desc-type1">{CodeService.getCodeLabelByValue('CODE_GRP_146', useYn)}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00006')}</label>
                    <span className="text-desc-type1">{linkGroupSeq}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00007')}</label>
                    <span className="text-desc-type1">
                      <AppFileAttach mode="view" onlyImageUpload={true} fileGroupSeq={fileGroupSeq} disabled={true} />
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">조회수</label>
                    <span className="text-desc-type1">{viewCount}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          {t('ke.safety.common.label.00006')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goFormPage}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00007')}
        </button>
      </div>
      {/* 열람정보 상세 toggle*/}
      <div className="info-wrap toggle">
        <dl className={firstExpaned ? 'tg-item active' : 'tg-item'}>
          <dt onClick={() => setFirstExpaned(!firstExpaned)}>
            <button type="button" className="btn-tg">
              {/* toggle 열어지면 active붙임*/}
              열람정보<span className={firstExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: firstExpaned ? '' : 'none' }}>
            {/*검색영역 */}
            <div className="boxForm">
              {/*area-detail명 옆에 active  */}
              <div id="" className="area-detail active">
                <div className="form-table">
                  <div className="form-cell wid30">
                    <div className="form-group wid100">
                      <AppAutoComplete label={'부서'} />
                    </div>
                  </div>
                  <div className="form-cell wid30">
                    <div className="form-group wid100">
                      <AppAutoComplete label={'이름'} />
                    </div>
                  </div>
                  <div className="btn-area">
                    <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                      조회
                    </button>
                    <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                      초기화
                    </button>
                  </div>
                </div>
              </div>
            </div>
            {/* //검색영역 */}

            {/*그리드영역 */}
            <div className="">
              <AppTable rowData={rowData} columns={columns} />
            </div>
            {/*//그리드영역 */}
          </dd>
        </dl>
      </div>
      {/* //열람정보 상세 toggle*/}
    </>
  );
}
export default SafetyBoardDetail;
