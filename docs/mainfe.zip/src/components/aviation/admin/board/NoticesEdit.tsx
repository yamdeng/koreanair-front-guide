import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import AppDatePicker from '@/components/common/AppDatePicker';
import { Editor } from '@toast-ui/react-editor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import { useTranslation } from 'react-i18next';
import AppCheckbox from '@/components/common/AppCheckbox';
import dayjs from 'dayjs';

/* yup validation */
const yupFormSchema = yup.object({
  notiTypeCd: yup.string().required(),
  viewYn: yup.string().required(),
  subjectKoNm: yup.string().required(),
  popupFromDt: yup.string().required(),
  popupToDt: yup.string().required(),
  popupYn: yup.string().required(),
  topFixYn: yup.string(),
  mainShowYn: yup.string(),
  boardTxtcn: yup.string().required(),
  linkKoNm: yup.string(),
  linkGroupSeq: yup.number().nullable(),
  fileGroupSeq: yup.number().nullable(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  boardTypeCd: '70',
  notiTypeCd: '',
  viewYn: 'N',
  viewCheckYn: false,
  subjectKoNm: '',
  popupFromDt: dayjs().format('YYYY-MM-DD'),
  popupToDt: dayjs().format('YYYY-MM-DD'),
  popupYn: '',
  topFixYn: '',
  mainShowYn: '',
  boardTxtcn: '',
  linkKoNm: '',
  // linkGroupSeq: null,
  fileGroupSeq: null,

  // 필수값
  useYn: 'Y',
  viewCo: 0,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/board/board',
  baseRoutePath: '/aviation/board-manage/notices',
  formName: 'AvnNoticesFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const AvnNoticesFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function NoticesEdit() {
  // 언어 설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    save,
    remove,
    cancel,
    clear,
    //  isDisabledAction,
    enterSearch,
  } = AvnNoticesFormStore();

  const {
    notiTypeCd,
    viewCheckYn,
    subjectKoNm,
    popupFromDt,
    popupToDt,
    popupYn,
    topFixYn,
    mainShowYn,
    boardTxtcn,
    // linkKo,
    // linkGroupSeq,
    fileGroupSeq,
  } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>공지사항 {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid50">
              <AppCodeSelect
                codeGrpId="CODE_GRP_142"
                id="AvnNoticesListFormStorenotiTypeCd"
                name="notiTypeCd"
                label={'공지구분'}
                disabled={formType === FORM_TYPE_UPDATE ? true : false}
                value={notiTypeCd}
                onChange={(value) => {
                  changeInput('notiTypeCd', value);
                  //  isDisabledAction(value);
                }}
                search={enterSearch}
                errorMessage={errors.notiTypeCd}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid50">
              <div className="group-box-wrap wid100">
                <AppCheckbox
                  label="열람여부"
                  value={viewCheckYn}
                  onChange={(value) => {
                    if (value) {
                      changeInput('viewYn', 'Y');
                      changeInput('viewCheckYn', true);
                    } else {
                      changeInput('viewYn', 'N');
                      changeInput('viewCheckYn', false);
                    }
                  }}
                  required
                />
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnNoticesListFormStoresubjectKoNm"
                name="subjectKoNm"
                label="제목"
                value={subjectKoNm}
                onChange={(value) => changeInput('subjectKoNm', value)}
                errorMessage={errors.subjectKoNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid30">
            <div className="form-group wid30">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={t('ke_change_mgmt_label_00556')}
                      //pickerType="date"
                      value={popupFromDt}
                      onChange={(value) => {
                        changeInput('popupFromDt', value);
                      }}
                      required
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label={t('ke_report_label_00203')}
                      //pickerType="date"
                      value={popupToDt}
                      onChange={(value) => {
                        changeInput('popupToDt', value);
                      }}
                      required
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid25">
            <div className="form-group wid25">
              <AppCodeSelect
                codeGrpId="CODE_GRP_146"
                id="AvnNoticesListFormStorepopupYn"
                name="popupYn"
                label="팝업여부"
                value={popupYn}
                onChange={(value) => changeInput('popupYn', value)}
                errorMessage={errors.popupYn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid25">
            <div className="form-group wid25">
              <AppCodeSelect
                codeGrpId="CODE_GRP_146"
                id="AvnNoticesListFormStoretopFixYn"
                name="topFixYn"
                label="상단고정여부"
                value={topFixYn}
                onChange={(value) => changeInput('topFixYn', value)}
                errorMessage={errors.topFixYn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid25">
            <div className="form-group wid25">
              <AppCodeSelect
                codeGrpId="CODE_GRP_146"
                id="AvnNoticesListFormStoremainShowYn"
                name="mainShowYn"
                label="메인표출여부"
                value={mainShowYn}
                onChange={(value) => changeInput('mainShowYn', value)}
                errorMessage={errors.mainShowYn}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100 mr5">
              {/*내용 */}
              <Editor
                id="AvnNoticesListFormStoreboardTxtcn"
                name="conteboardTxtcnnt"
                label={t('ke.safety.Notice.label.00009')}
                value={boardTxtcn}
                onChange={(value) => changeInput('boardTxtcn', value)}
                errorMessage={errors.boardTxtcn}
                hideModeSwitch={true}
                initialEditType="wysiwyg"
                previewStyle="vertical"
                // initialValue={initValue}
                height={'500px'}
                // onChange={() => {}}
                usageStatistics={false}
                customHTMLSanitizer={(html) => {
                  return html;
                }}
                viewer={true}
                autofocus={false}
                customHTMLRenderer={{
                  htmlBlock: {
                    table(node) {
                      return [
                        { type: 'openTag', tagName: 'table', outerNewLine: true, attributes: node.attrs },
                        { type: 'html', content: node.childrenHTML },
                        { type: 'closeTag', tagName: 'table', outerNewLine: true },
                      ];
                    },
                  },
                }}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid80">
            <div className="group-box-wrap line wid100">
              <span className="txt">Link{/*<span className="required">*</span>*/}</span>
              <button type="button" name="button" className="btn-plus">
                추가
              </button>
              <div className="file-link">
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link첨부Link첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* 파일첨부영역 : drag */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* 파일첨부영역 : drag */}
              <AppFileAttach
                label={t('ke.safety.Notice.label.00007')}
                fileGroupSeq={fileGroupSeq}
                workScope={'A'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileGroupSeq', newFileGroupSeq);
                }}
                errorMessage={errors.fileGroupSeq}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
      {/*//하단 버튼 영역 */}
    </>
  );
}
export default NoticesEdit;
