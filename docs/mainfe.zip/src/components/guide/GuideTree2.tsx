import AppNavigation from '@/components/common/AppNavigation';
import ApiService from '@/services/ApiService';
import { treeBaseState, createTreeSearchSlice } from '@/stores/slice/treeSearchSlice';
import CommonUtil from '@/utils/CommonUtil';
import { Tree } from 'antd';
import { useRef, useEffect } from 'react';
import Config from '@/config/Config';
import { create } from 'zustand';

import AppSearchInput from '../common/AppSearchInput';

const baseState = {
  ...treeBaseState,
  valueKey: 'deptCd',
  parentKey: 'upperDeptCd',
  labelKey: 'nameKor',
  searchApplyInputLength: 1,
};

/* zustand store 생성 */
const TreeTestStore = create<any>((set, get) => ({
  ...createTreeSearchSlice(set, get),

  ...baseState,

  getTreeData: async () => {
    const { setTreeData } = get();
    const apiUrl = import.meta.env.VITE_API_URL_DEPTS;
    const apiResult = await ApiService.get(apiUrl, {
      pageNum: 1,
      pageSize: 100000,
    });
    const list = apiResult.data;
    const treeData = CommonUtil.listToTreeData(list, 'deptCd', 'upperDeptCd', null);
    setTreeData(treeData, list);
  },

  clear: () => {
    const { clearInputInterval } = get();
    clearInputInterval();
    set({ ...baseState });
  },
}));

function GuideTree2() {
  const treeDomRef: any = useRef();

  const {
    treeData,
    onSelect,
    onExpand,
    selectedKeys,
    expandedKeys,
    searchInputValue,
    changeSearchValue,
    handleSearchInputEnterKey,
    findKey,
    getTreeData,
    setTreeRef,
  } = TreeTestStore();

  useEffect(() => {
    getTreeData();
    setTreeRef(treeDomRef);
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>
          Tree :{' '}
          <a style={{ fontSize: 20 }} href={Config.hrefBasePath + `GuideTree2.tsx`}>
            GuideTree2
          </a>
        </h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="tree_form">
                <div className="form-group wid100">
                  <AppSearchInput
                    label="검색"
                    value={searchInputValue}
                    onChange={(value) => changeSearchValue(value)}
                    search={handleSearchInputEnterKey}
                  />
                </div>
              </div>
              <div className="tree_box" style={{ height: 500 }}>
                <Tree
                  height={500}
                  ref={treeDomRef}
                  checkStrictly
                  treeData={treeData}
                  fieldNames={{ title: 'nameKor', key: 'deptCd' }}
                  selectedKeys={selectedKeys}
                  expandedKeys={expandedKeys}
                  onSelect={onSelect}
                  onExpand={onExpand}
                  titleRender={(nodeData) => {
                    const { nameKor, deptCd }: any = nodeData;
                    let className = '';
                    if (findKey && deptCd === findKey) {
                      className = className + ' current-find';
                    }
                    return (
                      <span
                        className={className}
                        dangerouslySetInnerHTML={{
                          __html: CommonUtil.replaceHighlightMarkup(nameKor, searchInputValue),
                        }}
                      ></span>
                    );
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="tree_form">
                <div className="form-group wid100">{/* <AppSearchInput label="검색" /> */}</div>
              </div>
              <div className="tree_box" style={{ height: 500 }}>
                {/* <Tree checkStrictly treeData={[]} fieldNames={{ title: 'nameKor', key: 'deptCd' }} onSelect={null} /> */}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm">저장</button>
      </div>
    </>
  );
}
export default GuideTree2;
