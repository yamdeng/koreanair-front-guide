import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';
import shareImage from '@/resources/images/share.svg';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useLocation } from 'react-router-dom';
import { Viewer } from '@toast-ui/react-editor';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';

import AppSearchInput from '@/components/common/AppSearchInput';

import RevalDetailTab1 from './RevalDetailTab1';
import RevalDetailTab2 from './RevalDetailTab2';
import RevalDetailTab3 from './RevalDetailTab3';
import RevalDetailTab4 from './RevalDetailTab4';
import RevalHeader from './RevalHeader';

import useOcuRiskMasterStore from '@/stores/occupation/risk/useOcuRiskMasterStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalDetail() {
  const { tabIndex, changeTab, clear } = useOcuRiskMasterStore();

  useEffect(() => {
    //tabIndex = 0;
    changeTab(0);
    return clear;
  }, []);

  return (
    <>
      {/* 위험성평가 탭 상단 */}
      <RevalHeader />
      {/* 사전준비 */}
      {tabIndex == 0 ? <RevalDetailTab1 /> : <></>}
      {/* 유해 위험요인 파악 */}
      {tabIndex == 1 ? <RevalDetailTab2 /> : <></>}
      {/* 위험성결정 */}
      {tabIndex == 2 ? <RevalDetailTab3 /> : <></>}
      {/* 첨부문서 */}
      {tabIndex == 3 ? <RevalDetailTab4 /> : <></>}
    </>
  );
}
export default RevalDetail;
