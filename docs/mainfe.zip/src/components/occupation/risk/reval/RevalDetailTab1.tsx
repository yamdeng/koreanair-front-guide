import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
//import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';
import shareImage from '@/resources/images/share.svg';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useLocation } from 'react-router-dom';
import { Viewer } from '@toast-ui/react-editor';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';

import AppSearchInput from '@/components/common/AppSearchInput';
import RiskHelpPeriodModal from '@/components/modal/occupation/RiskHelpPeriodModal';
import useOcuRiskMasterStore from '@/stores/occupation/risk/useOcuRiskMasterStore';

import {
  useOcuRiskTab1FormStore,
  useOcuRiskTab1ProcessListStore,
} from '@/stores/occupation/risk/useOcuRiskTab1FormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalFormTab1() {
  /* formStore state input 변수 */
  // const { detailInfo, getDetail, formType, cancel, goFormPage, clear, search, list } = useOcuRiskTab1FormStore();

  const { tabIndex, changeTab } = useOcuRiskMasterStore();

  const baseInfo = useOcuRiskTab1FormStore();
  const proc = useOcuRiskTab1ProcessListStore();

  const {
    detailInfo,
    getDetail,
    formType,
    cancel,
    goFormPage,
    clear,
    search,
    removeByIndex,
    gridChangeStatus,
    changeStateProps,
    execDeptChange,
    openFormModal,
    isCodeFormModalOpen,
    closeFormModal,
    okModal,
    // goForm,
  } = baseInfo;

  const {
    /* 기본 정보 */

    // 위험성평가 문서 번호
    revalDocNo,
    // 부문
    authorSectCd,
    // 부문명
    authorSectNm,
    // 부서
    authorDeptCd,
    // 위험성평가 년도
    revalYear,
    // 위험성평가 시기
    revalPeriod,
    // 위험성평가 시기 명
    revalPeriodNm,
    // 평가 시작일자
    evalStartDt,
    // 평가 종료일자
    evalEndDt,
    // 위험성평가 제목
    revalTitle,
    // 재해발생보고서 문서 번호
    dssReportDocNo,
    // 근로자_수
    emplCnt,
    // 근무형태
    workForm,
    // 위험성평가 1번 문항
    revalItem1,
    // 위험성평가 2번 문항
    revalItem2,
    // 위험성평가 3번 문항
    revalItem3,
    // 위험성평가 4번 문항
    revalItem4,
    // 안전보건_정보_내용
    hlthSftyInfoCn,
    // 준비_관련_첨부_파일_ID
    prepareRelFileId,

    // 부서명
    nmLevel2,
    // 팀명
    nmLevel3,
    // 그룹명
    nmLevel4,
    // 반/섹션명
    nmLevel5,

    /* 추진팀 정보 */

    // 추진팀 구분 코드
    execTeamClsCd,
    // 추진팀 성명
    execTeamNm,
    // 추진팀 사번
    execTeamEmpno,
    // 추진팀 부문 코드
    execTeamSectCd,
    // 추진팀 부서 코드
    execTeamDeptCd,
    //  추진팀 업체명
    execTeamCompNm,
    // 추진팀 직책 코드
    execTeamPosCd,

    // 추진팀 구분명
    execTeamClsNm,
    // 추진팀 부문명
    execTeamSectNm,
    // 추진팀 직책 명
    execTeamPosNm,

    /* 공정 정보 */

    // 공정 명
    procNm,

    regDttm,
    regUserId,
  } = detailInfo;

  const { detailId } = useParams();

  console.log('detailId==>', detailId);

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호', flex: 1 },
      { field: 'execTeamClsNm', headerName: '구분', flex: 1 },
      { field: 'execTeamNm', headerName: '이름', flex: 1 },
      { field: 'execTeamPosNm', headerName: '직책', flex: 1 },
      { field: 'execTeamDeptCd', headerName: '부서', flex: 1 },
      { field: 'execTeamCompNm', headerName: '업체', flex: 1 },
    ])
  );

  const [columns2, setColumns2] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호' },
      { field: 'procNm', headerName: '공정명', flex: 1 },
      //{ field: 'execTeamPosCd', headerName: '삭제', flex: 1 },
      // {
      //   pinned: 'right',
      //   field: 'action',
      //   headerName: '삭제',
      //   // flex: 1,
      //   cellRenderer: 'deleteActionButton',
      //   cellRendererParams: {
      //     onClick: removeByIndex,
      //   },
      //},
    ])
  );

  console.log('랜더링@@@');

  // 추진팀 구성 행 변경
  const handleRowSingleClick = useCallback((selectedInfo) => {
    setColumns((prevColumns) => [...prevColumns]);
    execDeptChange(selectedInfo.data);
  }, []);

  // 공정 행 변경
  const handleRowSingleClick2 = useCallback((selectedInfo) => {
    // const { rowIndex } = props;

    console.log('selectedInfo==>', selectedInfo);

    setColumns((prevColumns) => [...prevColumns]);
    proc.procChange(selectedInfo.data, selectedInfo.rowIndex);
  }, []);

  // 수정
  const goForm = () => {
    goFormPage(detailId);
  };

  // const DeleteActionButton = (props) => {
  //   const { node, onClick } = props;
  //   const { rowIndex } = node;
  //   const handleClick = (event) => {
  //     gridChangeStatus(props);
  //     event.stopPropagation();
  //     event.preventDefault();
  //     event.nativeEvent.stopPropagation();
  //     onClick(rowIndex);
  //   };

  //   return <div onClick={handleClick}>삭제</div>;
  // };

  const init = async () => {
    getDetail(detailId);
    search();
  };

  useEffect(() => {
    init();
    return clear;
  }, []);

  // useEffect(() => {
  //   getDetail(detailId);
  //   return clear;
  // }, []);

  // 평가 시기 도움말 팝업
  const helpPeriod = () => {
    console.log('테스트2');
    openFormModal(null);
  };

  return (
    <>
      {/* <AppNavigation />
      <div className="conts-title">
        <h2>
          위험성평가 상세
          <span>
            <a href="javascript:void(0);"></a>
          </span>
        </h2>
      </div> */}
      {/*탭 */}
      {/* <div className="menu-tab-nav">
        <div className="menu-tab">
          <a href="javascript:void(0);" className="active" data-label="사전준비">
            사전준비
          </a>
          <a href="javascript:void(0);" data-label="유해 위험요인 파악">
            유해 위험요인 파악
          </a>
          <a href="javascript:void(0);" data-label="위험성 결정">
            위험성 결정3
          </a>
          <a href="javascript:void(0);" data-label="첨부문서">
            첨부문서
          </a>
        </div>
      </div> */}
      {/*//탭 */}
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              기본 사항<span className="active"></span>
              {/*평가시기 - 팝업 */}
              <div className="tag-info-wrap-end" onClick={helpPeriod}>
                <div className="tip">
                  <div>
                    <a href="javascript:void(0);" className="txt" onClick={helpPeriod}>
                      평가시기
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              {/* <AppTextInput label="작성자" disabled /> */}
                              <label className="t-label">작성자</label>
                              <span className="text-desc-type1">{regUserId}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="작성일자" disabled /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">작성일자</label>
                              <span className="text-desc-type1">{regDttm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="부문" disabled /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">부문</label>
                              <span className="text-desc-type1">{authorSectNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">부서</label>
                              <span className="text-desc-type1">{nmLevel2}</span>
                            </li>
                          </ul>
                        </div>
                        {/* <AppTextInput label="부서" disabled /> */}
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="팀" disabled /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">팀</label>
                              <span className="text-desc-type1">{nmLevel3}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="그룹" disabled /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">그룹</label>
                              <span className="text-desc-type1">{nmLevel4}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="반/섹션" disabled /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">반/섹션</label>
                              <span className="text-desc-type1">{nmLevel5}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="평가년도" /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">평가년도</label>
                              <span className="text-desc-type1">{revalYear}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppCodeSelect label="평가시기" required /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">평가시기</label>
                              <span className="text-desc-type1">{revalPeriodNm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppSearchInput label="재해발생보고서" /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">재해발생보고서</label>
                              <span className="text-desc-type1">{dssReportDocNo}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppDatePicker label="평가시작일" /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">평가시작일</label>
                              <span className="text-desc-type1">{evalStartDt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppDatePicker label="평가종료일" /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">평가종료일</label>
                              <span className="text-desc-type1">{evalEndDt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid70">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="제목" required /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">제목</label>
                              <span className="text-desc-type1">{revalTitle}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid30">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="문서번호" disabled /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">문서번호</label>
                              <span className="text-desc-type1">{revalDocNo}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="ck-edit-box">
                        <div className="ck-list">
                          <h3 className="table-tit">추진팀 구성</h3>
                          {/* 그리드영역 */}
                          <AppTable
                            rowData={baseInfo.list}
                            columns={columns}
                            setColumns={setColumns}
                            store={baseInfo}
                            handleRowSingleClick={handleRowSingleClick}
                            hiddenPagination
                          />
                        </div>
                        <div className="ck-edit">
                          <div className="boxForm">
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  {/* <AppCodeSelect label="구분" /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">구분</label>
                                        <span className="text-desc-type1">{execTeamClsNm}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {/* <AppSearchInput label="이름" disabled /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">이름</label>
                                        <span className="text-desc-type1">{execTeamNm}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {/* <AppSearchInput label="사번" disabled /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">사번</label>
                                        <span className="text-desc-type1">{execTeamEmpno}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {/* <AppSearchInput label="부문" disabled /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">부문</label>
                                        <span className="text-desc-type1">{execTeamSectNm}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {/* <AppSearchInput label="부서" disabled /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">부서</label>
                                        <span className="text-desc-type1">{execTeamDeptCd}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {/* <AppSearchInput label="업체" disabled /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">업체</label>
                                        <span className="text-desc-type1">{execTeamCompNm}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  {/* <AppCodeSelect label="직책" /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">직책</label>
                                        <span className="text-desc-type1">{execTeamPosNm}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            {/* <div className="btn-area-type01 mg-top">
                              <button type="button" name="button" className="btn_text btn_confirm">
                                저장
                              </button>
                            </div> */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              안전보건 정보 수집<span className="active"></span>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="근로자수" /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">근로자수</label>
                              <span className="text-desc-type1">{emplCnt}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="근무형태" /> */}
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">근무형태</label>
                              <span className="text-desc-type1">{workForm}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <h3>다음 각 호의 사항을 조사하여 위험성평가에 활용한다.</h3>
                      <div>
                        <ul className="list-input-box">
                          <li>
                            <span className="list-tit">1. 산업재해 및 아차사고 발생 사례 (5개년 이상)</span>
                            <AppSearchInput disabled label="" value={revalItem1} />
                          </li>
                          <li>
                            <span className="list-tit">2. 설비, 기계, 기구 보유 현황</span>
                            <AppSearchInput disabled label="" value={revalItem2} />
                          </li>
                          <li>
                            <span className="list-tit">3. 작업표준서, 작업절차</span>
                            <AppSearchInput disabled label="" value={revalItem3} />
                          </li>
                          <li>
                            <span className="list-tit">4. 협력사 혼재작업 시 위험성 및 작업상황 정보</span>
                            <AppSearchInput disabled label="" value={revalItem4} />
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="ck-edit-box">
                        <div className="ck-list">
                          <h3 className="table-tit">평가항목 선정</h3>
                          {/* 그리드영역 */}
                          <AppTable
                            rowData={proc.list}
                            columns={columns2}
                            setColumns={setColumns2}
                            handleRowSingleClick={handleRowSingleClick2}
                            store={proc}
                            hiddenPagination
                            // components={{
                            //   deleteActionButton: DeleteActionButton,
                            // }}
                          />
                        </div>

                        <div className="ck-edit">
                          <div className="boxForm">
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  {/* <AppCodeSelect label="구분" /> */}
                                  <div className="box-view-list">
                                    <ul className="view-list">
                                      <li className="accumlate-list">
                                        <label className="t-label">공정명</label>
                                        <span className="text-desc-type1">{procNm}</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <h3 className="table-tit">참여자 교육</h3>
                      <span>다음 각 호의 사항을 조사하여 위험성평가에 활용한다.</span>
                      <ul className="guide-list">
                        <li>1. 위험성평가 대상 공정 선정 및 Process에 관한 사항</li>
                        <li>2. 역할별 임무 안내(책임자, 관리감독자, 작업자, 안전보건조직 등)</li>
                        <li>3. 위험성평가 방법 안내(유해위험요인파악, 감소대책 수립 및 참여 방법 등)</li>
                        <li>4. 안전보건정보 수집 및 활용 방법</li>
                      </ul>
                    </div>
                  </div>
                  {/* 파일첨부영역 : button */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <h3 className="table-tit mb-10">준비관련 첨부 문서</h3>
                      <div className="form-group wid100">
                        <AppFileAttach
                          mode="view"
                          fileGroupSeq={prepareRelFileId}
                          workScope={'O'}
                          // onlyImageUpload={true}
                          useDetail
                          disabled
                        />
                        {/* <div className="filebox "> */}
                        {/* <Upload {...props}>
                            <div className="btn-area">
                              <button type="button" name="button" className="btn-big btn_text btn-darkblue-line mg-n">
                                + Upload
                              </button>
                            </div>
                          </Upload>
                          <label htmlFor="file" className="file-label">
                            파일 첨부 <span className="required">*</span>
                          </label> */}
                        {/* </div> */}
                        {/*<span className="errorText">fileerror</span>*/}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      <RiskHelpPeriodModal isOpen={isCodeFormModalOpen} closeModal={closeFormModal} ok={okModal} />

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goForm}
          // style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          수정
        </button>
        {/* <button type="button" name="button" className="btn_text btn-del">
          삭제
        </button> */}
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
      </div>
    </>
  );
}
export default RevalFormTab1;
