import AppNavigation from '@/components/common/AppNavigation';
import WorkPermitList from './WorkPermitList';
import WorkPermitStatus from './WorkPermitStatus';
import { useEffect } from 'react';
import useOcuWorkPermitManageStore from '@/stores/occupation/management/useOcuWorkPermitManageStore';
import WorkPermitHeader from './WorkPermitHeader';

function WorkPermit() {
  const { tabIndex, changeTab, clear } = useOcuWorkPermitManageStore();

  useEffect(() => {
    changeTab(0);
    return clear;
  }, []);

  return (
    <>
      {/* 외주작업허가 상단 */}
      <WorkPermitHeader />
      {/* 외주작업현황 */}
      {tabIndex == 0 ? <WorkPermitStatus /> : <></>}
      {/* 외주작업조회 */}
      {tabIndex == 1 ? <WorkPermitList /> : <></>}
    </>
  );
}

export default WorkPermit;
