import AppFileAttach from '@/components/common/AppFileAttach';
import useOcuWorkPermitEduChoiceModalStore from '@/stores/occupation/management/useOcuWorkPermitEduChoiceModalStore';
import { Upload } from 'antd';
import { useEffect, useState } from 'react';
import Modal from 'react-modal';

function WorkPermitEduChoiceModal(props) {
  const { isOpen, closeModal, ok } = props;

  /**
   * 0. 체크박스 상태 선언해야쥬
   * 1. 체크박스 선택혀 - true되겄쥬?
   * 2. 체크박스 선택 값 바꿔유
   * 3. 외주작업 등록창 - 부모컴포넌트에 저장한 배열 보내유
   * 4. 취소를 누르면 모든 데이터 슈슈슈슉
   *
   * 혹쉬...체크박스의 모든 값을 다 꽂은 다음에 선택이 안된 애들만 reduce하면..위험쓰....?
   * 근데 그러기에는 파일Id값이 읎음
   */

  // 체크박스 선택 여부
  const [isChecked, setIsChecked] = useState(false);
  const [spclEduItemCd, setSpclEduItemCd] = useState('');

  const [checkboxStates, setCheckboxStates] = useState({
    A: false,
    B: false,
    C: false,
    D: false,
    E: false,
    F: false,
    G: false,
    H: false,
    I: false,
    J: false,
    K: false,
    L: false,
    M: false,
    N: false,
    O: false,
    P: false,
    Q: false,
    R: false,
  });

  // 체크박스 값이 바뀌면 값을 업데이트혀
  const handleCheckboxChange = (event) => {
    const { checked, name } = event.target;
    // setIsChecked(checked);
    // setSpclEduItemCd(name || '');
    // console.log(name);

    //선택된 친구만 업데이트혀
    setCheckboxStates((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  const handleClearSelection = () => {
    setCheckboxStates({});
  };

  useEffect(() => {
    if (isOpen) {
      console.log('모달이 열렸습니다.');
    }
  }, [isOpen]);

  useEffect(() => {
    console.log('체크박스 상태보고해봐유:', checkboxStates);
  }, [checkboxStates]);

  const handleClose = () => {
    alert('교육 내용이 첨부되지 않았습니다. 창을 닫으시겠습니까?');
    // 닫을 때 선택 정보 초기화혀
    handleClearSelection();
    closeModal();
  };

  // 선택한 체크박스 항목을 배열에 반영해야혀
  const handleSubmit = () => {
    ok();
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">특별교육</h3>
        <span className="txt-guide">산업안전보건법 시행규칙 제26조 및 별표5</span>
        <div className="pop_cont">
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="A"
                        value="A"
                        //checked={isChecked}
                        checked={checkboxStates.A}
                        onChange={handleCheckboxChange}
                      />
                      <span>{spclEduItemCd}</span>
                      <span className="type01">
                        아세틸렌 용접장치 또는 가스집합 용접장치를 사용하는 금속의 용접·용단 또는 가열작업(발생기·도관
                        등에 의하여 구성되는 용접장치만 해당한다)
                      </span>
                      <span className="type01">
                        아세틸렌 용접장치 또는 가스집합 용접장치를 사용하는 금속의 용접·용단 또는 가열작업(발생기·도관
                        등에 의하여 구성되는 용접장치만 해당한다)
                        {/* {CodeService.getCodeLabelByValue('CODE_OCC_158', 'A')} */}
                      </span>
                      <ul className="ck-guide">
                        <li>용접 흄, 분진 및 유해광선 등의 유해성에 관한 사항</li>
                        <li>
                          가스용접기, 압력조정기, 호스 및 취관두(불꽃이 나오는 용접기의 앞부분) 등의 기기점검에 관한
                          사항
                        </li>
                        <li>작업방법·순서 및 응급처치에 관한 사항</li>
                        <li>안전기 및 보호구 취급에 관한 사항</li>
                        <li>화재예방 및 초기대응에 관한사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="B"
                        value="B"
                        //checked={isChecked}
                        checked={checkboxStates.B}
                        onChange={handleCheckboxChange}
                      />
                      <span>{spclEduItemCd}</span>
                      <span className="type01">
                        밀폐된 장소(탱크 내 또는 환기가 극히 불량한 좁은 장소 를 말한다)에서 하는 용접작업 또는 습한
                        장소에서 하는 전기용접 작업
                      </span>
                      <ul className="ck-guide">
                        <li>작업순서, 안전작업방법 및 수칙에 관한 사항</li>
                        <li>환기설비에 관한 사항</li>
                        <li>전격 방지 및 보호구 착용에 관한 사항</li>
                        <li>질식 시 응급조치에 관한 사항</li>
                        <li>작업환경 점검에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="C"
                        value="C"
                        //checked={isChecked}
                        checked={checkboxStates.C}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">
                        폭발성·물반응성·자기반응성·자기발열성 물질, 자연발화성 액체·고체 및 인화성 액체의 제조 또는
                        취급작업(시험연구를 위한 취급작업은 제외한다)
                      </span>
                      <ul className="ck-guide">
                        <li>
                          폭발성·물반응성·자기반응성·자기발열성 물질, 자연발화성 액체·고체 및 인화성 액체의 성질이나
                          상태에 관한 사항
                        </li>
                        <li>폭발 한계점, 발화점 및 인화점 등에 관한 사항</li>
                        <li>취급방법 및 안전수칙에 관한 사항</li>
                        <li>이상 발견 시의 응급처치 및 대피 요령에 관한 사항</li>
                        <li>화기·정전기·충격 및 자연발화 등의 위험방지에 관한 사항</li>
                        <li>작업순서, 취급주의사항 및 방호거리 등에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                      {/*<span className="errorText">fileerror</span>*/}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="D"
                        value="D"
                        checked={checkboxStates.D}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">화학설비의 탱크 내 작업</span>
                      <ul className="ck-guide">
                        <li>차단장치·정지장치 및 밸브 개폐장치의 점검에 관한 사항</li>
                        <li>탱크 내의 산소농도 측정 및 작업환경에 관한 사항</li>
                        <li>안전보호구 및 이상 발생 시 응급조치에 관한 사항</li>
                        <li>작업절차·방법 및 유해·위험에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="E"
                        value="E"
                        checked={checkboxStates.E}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">
                        1톤 이상의 크레인을 사용하는 작업 또는 1톤 미만의크레인 또는 호이스트를 5대이상 보유한
                        사업장에서 해당기계로 하는 작업(제40호의작업은 제외한다)
                      </span>
                      <ul className="ck-guide">
                        <li>방호장치의 종류, 기능 및 취급에 관한 사항</li>
                        <li>걸고리·와이어로프 및 비상정지장치 등의 기계·기구 점검에관한 사항</li>
                        <li>화물의 취급 및 안전작업방법에 관한 사항</li>
                        <li>신호방법 및 공동작업에 관한 사항</li>
                        <li>인양 물건의 위험성 및 낙하·비래(飛來)·충돌재해 예방에 관한사항</li>
                        <li>인양물이 적재될 지반의 조건, 인양하중, 풍압 등이 인양물과타워크레인에 미치는 영향</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="F"
                        value="F"
                        checked={checkboxStates.F}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">전압이 75볼트 이상인 정전및 활선작업</span>
                      <ul className="ck-guide">
                        <li>전기의 위험성 및 전격 방지에 관한 사항</li>
                        <li>해당 설비의 보수 및 점검에 관한 사항</li>
                        <li>정전작업·활선작업 시의 안전작업방법 및 순서에 관한 사항</li>
                        <li>절연용 보호구, 절연용 보호구 및 활선작업용 기구 등의 사용에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="G"
                        value="G"
                        checked={checkboxStates.G}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">
                        콘크리트 파쇄기를 사용하여 하는 파쇄작업(2미터 이상인 구축물의 파쇄작업만 해당한다)
                      </span>
                      <ul className="ck-guide">
                        <li>콘크리트 해체 요령과 방호거리에 관한 사항</li>
                        <li>작업안전조치 및 안전기준에 관한 사항</li>
                        <li>파쇄기의 조작 및 공통작업 신호에 관한 사항</li>
                        <li>보호구 및 방호장비 등에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="H"
                        value="H"
                        checked={checkboxStates.H}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">
                        굴착면의 높이가 2미터 이상이 되는 지반 굴착(터널 및 수직갱 외의 갱 굴착은 제외한다)작업
                      </span>
                      <ul className="ck-guide">
                        <li>지반의 형태·구조 및 굴착 요령에 관한 사항</li>
                        <li>지반의 붕괴재해 예방에 관한 사항</li>
                        <li>붕괴 방지용 구조물 설치 및 작업방법에 관한 사항</li>
                        <li>보호구의 종류 및 사용에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="I"
                        value="I"
                        checked={checkboxStates.I}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">
                        높이가 2미터 이상인 물건을 쌓거나 무너뜨리는 작업(하역기계로만 하는 작업은제외한다)
                      </span>
                      <ul className="ck-guide">
                        <li>원부재료의 취급 방법 및 요령에 관한 사항</li>
                        <li>물건의 위험성·낙하 및 붕괴재해 예방에 관한 사항</li>
                        <li>적재방법 및 전도 방지에 관한 사항</li>
                        <li>보호구 착용에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="J"
                        value="J"
                        checked={checkboxStates.J}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">비계의 조립·해체 또는 변경작업</span>
                      <ul className="ck-guide">
                        <li>비계의 조립순서 및 방법에 관한 사항</li>
                        <li>비계작업의 재료 취급 및 설치에 관한 사항</li>
                        <li>추락재해 방지에 관한 사항</li>
                        <li>보호구 착용에 관한 사항</li>
                        <li>비계상부 작업 시 최대 적재하중에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="K"
                        value="K"
                        checked={checkboxStates.K}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">
                        콘크리트 인공구조물(그 높이가 2미터 이상인 것만 해당한다)의 해체 또는 파괴작업
                      </span>
                      <ul className="ck-guide">
                        <li>콘크리트 해체기계의 점점에 관한 사항</li>
                        <li>파괴 시의 안전거리 및 대피 요령에 관한 사항</li>
                        <li>작업방법·순서 및 신호 방법 등에 관한 사항</li>
                        <li>해체·파괴 시의 작업안전기준 및 보호구에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="L"
                        value="L"
                        checked={checkboxStates.L}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">
                        보일러(소형 보일러 및 다음각 목에서 정하는 보일러는제외한다)의 설치 및 취급 작업 <br />
                        가. 몸통 반지름이 750밀리미터 이하이고 그 길이가 1,300밀리미터 이하인 증기보일러
                        <br />
                        나. 전열면적이 3제곱미터 이하인 증기보일러
                        <br />
                        다. 전열면적이 14제곱미터이하인 온수보일러
                        <br />
                        라. 전열면적이 30제곱미터이하인 관류보일러(물관을 사용하여 가열시키는 방식의 보일러)
                      </span>
                      <ul className="ck-guide">
                        <li>기계 및 기기 점화장치 계측기의 점검에 관한 사항</li>
                        <li>열관리 및 방호장치에 관한 사항</li>
                        <li>작업순서 및 방법에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="M"
                        value="M"
                        checked={checkboxStates.M}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">
                        게이지 압력을 제곱센티미터당 1킬로그램 이상으로 사용하는 압력용기의 설치 및 취급작업
                      </span>
                      <ul className="ck-guide">
                        <li>안전시설 및 안전기준에 관한 사항</li>
                        <li>압력용기의 위험성에 관한 사항</li>
                        <li>용기 취급 및 설치기준에 관한 사항</li>
                        <li>작업안전 점검 방법 및 요령에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="N"
                        value="N"
                        checked={checkboxStates.N}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">방사선 업무에 관계되는 작업(의료 및 실험용은 제외한다)</span>
                      <ul className="ck-guide">
                        <li>방사선의 유해·위험 및 인체에 미치는 영향</li>
                        <li>방사선의 측정기기 기능의 점검에 관한 사항</li>
                        <li>방호거리·방호벽 및 방사선물질의 취급 요령에 관한 사항</li>
                        <li>응급처치 및 보호구 착용에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="O"
                        value="O"
                        checked={checkboxStates.O}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">밀폐공간에서의 작업</span>
                      <ul className="ck-guide">
                        <li>산소농도 측정 및 작업환경에 관한 사항</li>
                        <li>사고 시의 응급처치 및 비상 시 구출에 관한 사항</li>
                        <li>보호구 착용 및 보호 장비 사용에 관한 사항</li>
                        <li>작업내용ㆍ안전작업방법 및 절차에 관한 사항</li>
                        <li>장비ㆍ설비 및 시설 등의 안전점검에 관한 사항</li>
                        <li>그 밖에 안전ㆍ보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="P"
                        value="P"
                        checked={checkboxStates.P}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">허가 또는 관리 대상 유해물질의 제조 또는 취급작업</span>
                      <ul className="ck-guide">
                        <li>취급물질의 성질 및 상태에 관한 사항</li>
                        <li>유해물질이 인체에 미치는 영향</li>
                        <li>국소배기장치 및 안전설비에 관한 사항</li>
                        <li>안전작업방법 및 보호구 사용에 관한 사항</li>
                        <li>그 밖에 안전ㆍ보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="Q"
                        value="Q"
                        checked={checkboxStates.Q}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">석면해체·제거작업</span>
                      <ul className="ck-guide">
                        <li>석면의 특성과 위험성</li>
                        <li>석면해체·제거의 작업방법에 관한 사항</li>
                        <li>장비 및 보호구 사용에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell1 wid50">
                <div className="group-box-wrap wid100">
                  <div className="radio-wrap">
                    <label className="type01">
                      <input
                        type="checkbox"
                        name="R"
                        value="R"
                        checked={checkboxStates.R}
                        onChange={handleCheckboxChange}
                      />
                      <span className="type01">가연물이 있는 장소에서 하는 화재위험작업</span>
                      <ul className="ck-guide">
                        <li>작업준비 및 작업절차에 관한 사항</li>
                        <li>작업장 내 위험물, 가연물의 사용·보관·설치 현황에 관한 사항</li>
                        <li>화재위험작업에 따른 인근 인화성 액체에 대한 방호조치에 관한 사항</li>
                        <li>화재위험작업으로 인한 불꽃, 불티 등의 흩날림 방지 조치에관한 사항</li>
                        <li>인화성 액체의 증기가 남아 있지 않도록 환기 등의 조치에 관한 사항</li>
                        <li>화재감시자의 직무 및 피난교육 등 비상조치에 관한 사항</li>
                        <li>그 밖에 안전·보건관리에 필요한 사항</li>
                      </ul>
                    </label>
                  </div>
                  {/*<span className="errorText">error</span>*/}
                </div>
                {/* 파일첨부영역 : button */}
                <div className="form-table">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppFileAttach
                        mode="edit"
                        label="파일첨부"
                        fileGroupSeq={''}
                        workScope={'O'}
                        updateFileGroupSeq={(newFileGroupSeq) => {
                          changeInput('fileId', newFileGroupSeq);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>

        <div className="pop_btns mt-20">
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleSubmit}>
            저장
          </button>
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            취소
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default WorkPermitEduChoiceModal;
