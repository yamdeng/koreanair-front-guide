import AppDatePicker from '@/components/common/AppDatePicker';
import useOcuWorkPermitStatusStore from '@/stores/occupation/management/useOcuWorkPermitStatusStore';
import { DATE_PICKER_TYPE_MONTH } from '@/config/CommonConstant';
import CommonUtil from '@/utils/CommonUtil';
import classNames from 'classnames';
import WorkPermitApproval from './WorkPermitApproval';
import { useEffect, useState } from 'react';

/*
  1.달력 오픈 제어
  2.현재 월 정보 셋팅 : init
   -초기값으로 셋팅하는 기준이 필요할지 검토
  3.현재 선택된 일 date 정보(1~31)
  4.calendarDateList : 달력의 기준 정보
  5.달 변경 인터페이스
  5-1.이전달
  5-2.다음달
  6.스케줄 목록 정보를 셋팅함
   -클릭 처리
*/

function WorkPermitStatus() {
  const {
    monthDatePickerOpen, // 월 선택 드롭다운 열려있는지 여부
    setMonthDatePickerOpen,
    // searchMonth,
    selectedDate,
    calendarDateList, // 캘린더에 표시할 주 단위 날짜 목록
    changeSelectedDate,
    //scheduleList, // 월 리스트
    dateScheduleList, // 특정 날짜 리스트
    changeSearchMonth,
    prevMonth,
    nextMonth,
    goAddPage,
    clear,
  } = useOcuWorkPermitStatusStore();

  const [scheduleList, setScheduleList] = useState([]);
  const [searchMonth, setSearchMonth] = useState('2024-09'); // 임시 초기값 설정

  // 오늘날짜를 default로 하는게 나은가
  const currentDate = CommonUtil.getToDate();
  console.log('currentDate : ' + currentDate);
  const defaultCurrentDate = CommonUtil.convertDate(currentDate, 'YYYY-MM-DD', 'YYYY년 MM월 DD일');
  console.log(defaultCurrentDate);
  console.log('searchMonth : ', searchMonth);
  console.log('typeof searchMonth : ', typeof searchMonth); //string
  console.log('typeof selectedDate : ', typeof selectedDate); //number
  console.log('selectedDate : ', selectedDate);

  useEffect(() => {
    const fetchCalendarData = async () => {
      try {
        const response = await fetch('/management/permits/calendar');
        if (!response.ok) {
          const errorText = await response.text();
          console.error('API request failed:', errorText);
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        console.log('API request successful');

        console.log('scheduleList : ', scheduleList);
        console.log('데이터를 가져와볼꼐유');
        console.log('response : ', response);
        console.log('response.json : ', response.json());
        const data = await response.json();
        console.log('data 넣기전에 보여줘봐유 : ', data);
        setScheduleList(data); // 가져온 데이터를 상태에 저장
        console.log('data보여줘봐유 : ', data);
        console.log('data안보여주면 너라도 보여줘유 : ', scheduleList);
      } catch (error) {
        console.error('데이터 가져오기 오류:', error);
      }
    };

    fetchCalendarData(); // 데이터를 가져오는 함수 호출
  }, [searchMonth]); // searchMonth가 변경될 때마다 실행

  return (
    <>
      {/* 버튼영역 */}
      {/* THE END OF 버튼영역 */}
      <div className="calendar-box">
        <div className="calendar-wrap">
          <div className="calendar-tit">
            <button className="prevday" onClick={prevMonth}>
              버튼
            </button>
            <h2 className="datetitle">
              <AppDatePicker
                style={{ visibility: 'hidden', width: 0 }}
                onOpenChange={(status) => {
                  setMonthDatePickerOpen(status);
                }}
                open={monthDatePickerOpen}
                hidden
                pickerType={DATE_PICKER_TYPE_MONTH}
                getPopupContainer={(trigger) => {
                  return trigger.parentNode;
                }}
                onChange={(value) => {
                  changeSearchMonth(value);
                }}
                showNow={false}
              />
              <span className="month" onClick={() => setMonthDatePickerOpen(true)}>
                {CommonUtil.convertDate(searchMonth, 'YYYY-MM', 'YYYY.MM')}
              </span>
            </h2>

            <button className="nextday" onClick={nextMonth}>
              버튼
            </button>
          </div>
          <table className="calendar-table">
            <thead>
              <tr>
                <th>일</th>
                <th>월</th>
                <th>화</th>
                <th>수</th>
                <th>목</th>
                <th>금</th>
                <th>토</th>
              </tr>
            </thead>
            <tbody>
              {calendarDateList.map((weekList, index) => {
                return (
                  <tr key={index}>
                    {weekList.map((dateInfo) => {
                      let dateComponent = <td></td>;
                      if (dateInfo) {
                        const { date, isHoliday } = dateInfo;
                        // active가 우선
                        const applyClassName = classNames('cld_day', {
                          s_day: date !== selectedDate && isHoliday,
                          active: date === selectedDate,
                        });
                        dateComponent = (
                          <td key={date} onClick={() => changeSelectedDate(date)}>
                            <div className="cld_date">
                              <div className={applyClassName}>{date}</div>
                              <ul className="schedule" style={{ display: 'none' }}>
                                <li>
                                  <a className="ing" href="javascript:void(0);">
                                    작업중<span>(1)</span>
                                  </a>
                                </li>
                                <li>
                                  <a className="expected" href="javascript:void(0);">
                                    작업예정<span>(2)</span>
                                  </a>
                                </li>
                                <li>
                                  <a className="wait" href="javascript:void(0);">
                                    작업종료대기<span>(1)</span>
                                  </a>
                                </li>
                                <li>
                                  <a className="complete" href="javascript:void(0);">
                                    작업완료<span>(1)</span>
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        );
                      }
                      return dateComponent;
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="calendar-list">
          <h3 className="table-tit">
            {' '}
            {/* 클릭된 날짜 표시 */}
            {searchMonth && selectedDate
              ? `${CommonUtil.convertDate(searchMonth, 'YYYY-MM', 'YYYY년 MM월')} ${selectedDate}일`
              : `${defaultCurrentDate}`}
          </h3>
          <ul className="schedule-guide">
            <li>
              <span className="expected"></span>작업예정
            </li>
            <li>
              <span className="ing"></span>작업중
            </li>
            <li>
              <span className="complete"></span>작업완료
            </li>
            <li>
              <span className="wait"></span>작업완료대기
            </li>
          </ul>
          <table className="list-table">
            <thead>
              <tr>
                <th>작업상태</th>
                <th>공사명</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="ing">작업 중</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td className="expected">작업예정</td>
                <td>외벽공사</td>
              </tr>
              <tr>
                <td className="wait">작업완료대기</td>
                <td>도로포장</td>
              </tr>
              <tr>
                <td className="complete">작업완료</td>
                <td>외벽공사</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      {/* 승인/ 작업종료 그리드 */}
      <WorkPermitApproval />
    </>
  );
}

export default WorkPermitStatus;
