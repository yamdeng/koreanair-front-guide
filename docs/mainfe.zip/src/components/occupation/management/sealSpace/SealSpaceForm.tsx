import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import AppDatePicker from '@/components/common/AppDatePicker';
// import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import { useStore } from 'zustand';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import useAppStore from '@/stores/useAppStore';
import AppTextInput from '@/components/common/AppTextInput';
import AppUserReadOnlyInput from '@/components/common/AppUserReadOnlyInput';
import CommonUtil from '@/utils/CommonUtil';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppTextArea from '@/components/common/AppTextArea';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppDeptReadOnlyInput from '@/components/common/AppDeptReadOnlyInput';
import useOcuSealSpaceFormStore from '@/stores/occupation/management/useOcuSealSpaceFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuSealSpaceForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, save, remove, cancel, clear } =
    useOcuSealSpaceFormStore();

  const profile = useStore(useAppStore, (state) => state.profile);

  // 작성자명
  const userId = profile.userInfo.userId;
  const loginDeptCd = profile.userInfo.deptCd;
  console.log('profile==>', profile);

  // 오늘 날짜 가져오기
  const currentDate = CommonUtil.getToDate();

  const {
    // 부문코드
    sectCd,
    // 부서코드
    deptCd,
    // 권역코드
    areaCd,
    // 사업장
    bizPlace,
    // 위치분류1
    positionCls1,
    // 위치분류2
    positionCls2,
    // 취급화학물질
    hndChmcl,
    // 유해인자
    hzdFactor,
    // 기준에 관한 규칙 코드
    stdRuleCd,
    // 작업업체명
    wrkCompanyNm,
    // 출입주기
    entExtIntrv,
    // 작업내용
    wrkContent,
    // 참고사진1
    photoId1,
    // 참고사진2
    photoId2,
    // 등록일시
    regDttm,
    // 등록자 ID
    regUserId,
    // 수정자 ID
    updUserId,
  } = formValue;

  const { detailId } = useParams();

  console.log('여기좀봐줘유 : ' + regDttm);

  useEffect(() => {
    console.log('detailId==>', detailId);
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  // useFormDirtyCheck(isDirty);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>밀폐공간현황</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppUserReadOnlyInput
                label="작성자"
                value={detailId === 'add' ? userId : regUserId}
                required
                disabled="false"
              />
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppDatePicker
                  id="OcuSealSpaceFormregDttm"
                  name="regDttm"
                  label="작성일자"
                  value={detailId === 'add' ? currentDate : regDttm}
                  onChange={(value) => changeInput(detailId === 'add' ? 'currentDate' : 'regDttm', value)}
                  required
                  disabled
                />
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                label="부문"
                codeGrpId="CODE_GRP_OC001"
                id="OcuSealSpaceFormsectCd"
                name="sectCd"
                value={sectCd} // 작성자 정보로 가져와야함
                onChange={(value) => changeInput('sectCd', value)}
                required
                disabled={formType !== 'add' ? true : false}
              />
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                {/* <AppSearchInput
                codeGrpId=""
                id="OcuSealSpaceFormdeptCd"
                name="deptCd"
                label="부서"
                value={deptCd}
                onChange={(value) => changeInput('deptCd', value)}
                required
              /> */}
                <AppDeptReadOnlyInput label="부서" value={detailId === 'add' ? loginDeptCd : deptCd} required />
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_OC007"
                id="OcuSealSpaceFormareaCd"
                name="areaCd"
                label="권역"
                value={areaCd}
                onChange={(value) => changeInput('areaCd', value)}
                errorMessage={errors.areaCd}
                required
              />
            </div>
          </div>
          <hr className="line"></hr>
          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppTextInput
                  id="OcuSealSpaceFormbizPlace"
                  name="bizPlace"
                  label="사업장"
                  value={bizPlace}
                  placeholder="건물명"
                  onChange={(value) => changeInput('bizPlace', value)}
                  errorMessage={errors.bizPlace}
                  required
                />
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSealSpaceFormpositionCls1"
                name="positionCls1"
                label="위치분류1"
                value={positionCls1}
                onChange={(value) => changeInput('positionCls1', value)}
                errorMessage={errors.positionCls1}
                placeholder="층, 실"
                required
              />
            </div>
          </div>

          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppTextInput
                  id="OcuSealSpaceFormpositionCls2"
                  name="positionCls2"
                  label="위치분류2"
                  value={positionCls2}
                  placeholder="상세장소"
                  onChange={(value) => changeInput('positionCls2', value)}
                  errorMessage={errors.positionCls2}
                />
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSealSpaceFormhndChmcl"
                name="hndChmcl"
                label="취급화학물질"
                value={hndChmcl}
                onChange={(value) => changeInput('hndChmcl', value)}
                errorMessage={errors.hndChmcl}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSealSpaceFormhzdFactor"
                name="hzdFactor"
                label="유해인자"
                value={hzdFactor}
                onChange={(value) => changeInput('hzdFactor', value)}
                errorMessage={errors.hzdFactor}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppCodeSelect
                codeGrpId="CODE_GRP_OC008"
                id="OcuSealSpaceFormstdRuleCd"
                name="stdRuleCd"
                label="기준에 관한 규칙"
                value={stdRuleCd}
                onChange={(value) => changeInput('stdRuleCd', value)}
                errorMessage={errors.stdRuleCd}
                required
                placeholder="산업안전보건기준에 관한 규칙[별표18] 밀폐공간(제618조 제1호 관련)"
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuSealSpaceFormwrkCompanyNm"
                name="wrkCompanyNm"
                label="작업업체"
                value={wrkCompanyNm}
                onChange={(value) => changeInput('wrkCompanyNm', value)}
                errorMessage={errors.wrkCompanyNm}
                required
              />
            </div>
          </div>

          <hr className="line"></hr>
          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppTextInput
                  id="OcuSealSpaceFormentExtIntrv"
                  name="entExtIntrv"
                  label="출입주기"
                  placeholder="1회/n"
                  value={entExtIntrv}
                  onChange={(value) => changeInput('entExtIntrv', value)}
                  errorMessage={errors.entExtIntrv}
                  required
                />
                {/* 형식만 입력 가능하다면 효과 넣어주기 */}
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextArea
                id="OcuSealSpaceFormwrkContent"
                name="wrkContent"
                label="출입 시 작업내용"
                value={wrkContent}
                onChange={(value) => changeInput('wrkContent', value)}
                placeholder="출입 시 작업내용을 입력해주시기 바랍니다."
                errorMessage={errors.wrkContent}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppFileAttach
                mode="edit"
                label="참고사진1"
                fileGroupSeq={photoId1}
                workScope={'O'}
                onlyImageUpload={true}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('photoId1', newFileGroupSeq);
                }}
              />
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppFileAttach
                  mode="edit"
                  label="참고사진2"
                  fileGroupSeq={photoId2}
                  workScope={'O'}
                  onlyImageUpload={true}
                  updateFileGroupSeq={(newFileGroupSeq) => {
                    changeInput('photoId2', newFileGroupSeq);
                  }}
                />
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
      </div>
    </>
  );
}
export default OcuSealSpaceForm;
