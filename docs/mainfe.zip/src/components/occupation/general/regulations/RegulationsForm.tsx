import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import AppEditor from '@/components/common/AppEditor';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppFileAttach from '@/components/common/AppFileAttach';
import { Upload } from 'antd';
import ApiService from '@/services/ApiService';
import { useStore } from 'zustand';
import useAppStore from '@/stores/useAppStore';
/* TODO : store 경로를 변경해주세요. */
import useOcuRegulationsFormStore from '@/stores/occupation/general/useOcuRegulationsFormStore';
import AppNavigation from '@/components/common/AppNavigation';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuRulesFormForm() {
  /* formStore state input 변수 */
  const { errors, changeInput, getDetail, formType, formValue, save, remove, cancel, clear } =
    useOcuRegulationsFormStore();

  const {
    // 부문명
    sectCd,
    // 등록자
    regUserId,
    // 구분
    formCls,
    // 개정번호
    revisionNo,
    // 제정일자
    enactedDt,
    // 개정일자
    revisionDt,
    // 첨부 link
    // linkId,
    // 제목
    revisionTitle,
    // 내용
    majorRevisionCn,
    // 첨부 파일
    fileId,
  } = formValue;

  const { detailId } = useParams();

  const profile = useStore(useAppStore, (state) => state.profile);
  // 사용자명
  const nameKor = profile.userInfo.nameKor;

  // 부문 변경시 개정번호 조회
  const sectCdSelectRevisionNo = async (type, typeValue) => {
    const formApiPath = 'ocu/general/selectRevisionNo';
    const apiParam = {
      sectCd: typeValue,
      formCls: formCls,
    };
    const apiResult: any = await ApiService['get'](formApiPath, apiParam, { disableLoadingBar: true });

    const data = apiResult.data;
    formValue.revisionNo = data.rulesFormId;
    formValue.enactedDt = data.enactedDt;
    changeInput(type, typeValue);
  };

  // 구분 변경시 개정번호 조회
  const typeSelectRevisionNo = async (type, typeValue) => {
    const formApiPath = 'ocu/general/selectRevisionNo';
    const apiParam = {
      sectCd: sectCd,
      formCls: typeValue,
    };
    const apiResult: any = await ApiService['get'](formApiPath, apiParam, { disableLoadingBar: true });
    const data = apiResult.data;

    console.log('data==>', data);
    console.log('data.enactedDt==>', data.enactedDt);

    formValue.revisionNo = data.rulesFormId;
    formValue.enactedDt = data.enactedDt;
    changeInput(type, typeValue);
  };

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  const [fileGroupSeq, setFileGroupSeq] = useState('');

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>규정/지침/매뉴얼/양식</h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label="부문"
                codeGrpId="CODE_GRP_OC001"
                value={sectCd}
                onChange={(value) => sectCdSelectRevisionNo('sectCd', value)}
                // onChange={(value) => changeInput('sectCd', value)}
                required
                disabled={formType !== 'add' ? true : false}
                errorMessage={errors.sectCd}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="등록자"
                // value={regUserId}
                value={detailId === 'add' ? nameKor : regUserId}
                // onChange={(value) => changeInput('regUserId', value)}
                onChange={(value) => changeInput(detailId === 'add' ? 'nameKor' : 'regUserId', value)}
                required
                disabled="false"
                // errorMessage={errors.regUserId}
                errorMessage={detailId === 'add' ? errors.nameKor : errors.regUserId}
                // disabled={formType !== 'add' ? true : false}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppCodeSelect
                label="구분"
                codeGrpId="CODE_GRP_OC005"
                value={formCls}
                // onChange={(value) => changeInput('formCls', value)}
                onChange={(value) => typeSelectRevisionNo('formCls', value)}
                required
                disabled={formType !== 'add' ? true : false}
                errorMessage={errors.formCls}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="개정번호"
                value={revisionNo}
                onChange={(value) => changeInput('revisionNo', value)}
                required
                disabled
                errorMessage={errors.revisionNo}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDatePicker
                label={'제정일자'}
                value={enactedDt}
                onChange={(value) => {
                  changeInput('enactedDt', value);
                }}
                // disabled={formType !== 'add' ? true : false}
                // 개정된게 없는 경우에만 입력 가능
                disabled={formType === 'add' && revisionNo == '1' ? false : true}
                errorMessage={errors.enactedDt}
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppDatePicker
                label={'개정일자'}
                value={revisionDt}
                onChange={(value) => {
                  changeInput('revisionDt', value);
                }}
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="group-box-wrap line wid100">
              <span className="txt">첨부파일 Link{/*<span className="required">*</span>*/}</span>
              {/*<div className="radio-wrap">
              <label>
                <input type="radio" checked />
                <span>YES</span>
              </label>
              <label>
                <input type="radio" />
                <span>NO</span>
              </label>
            </div>*/}
              <button type="button" name="button" className="btn-plus">
                추가
              </button>
              <div className="file-link">
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link첨부Link첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
                <div className="link-box">
                  <a href="javascript:void(0);">첨부Link</a>
                  <a href="javascript:void(0);">
                    <span className="close-btn">close</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                label="제목"
                value={revisionTitle}
                onChange={(value) => changeInput('revisionTitle', value)}
                required
                errorMessage={errors.revisionTitle}
              />
            </div>
          </div>
        </div>

        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppEditor
                placeholder="입력해주세요."
                value={majorRevisionCn}
                onChange={(value) => changeInput('majorRevisionCn', value)}
                required
                errorMessage={errors.majorRevisionCn}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppFileAttach
                mode="edit"
                label="파일첨부"
                fileGroupSeq={fileId}
                workScope={'O'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileId', newFileGroupSeq);
                }}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuRulesFormForm;
