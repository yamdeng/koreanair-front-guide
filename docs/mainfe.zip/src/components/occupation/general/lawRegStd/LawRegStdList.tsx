import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import CommonUtil from '@/utils/CommonUtil';
import { useCallback, useEffect, useState } from 'react';
import ApiService from '@/services/ApiService';
//import AppSearchInput from '@/components/common/AppSearchInput';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
// import RgSelectInput from '../../RgSelectInput';
import AppTextInput from '@/components/common/AppTextInput';
import LawRegStdFormModal from '@/components/modal/occupation/LawRegStdFormModal';
import useOcuLawRegStdFormStore from '@/stores/occupation/general/useOcuLawRegStdFormStore';

import LawOpenApiModal from '@/components/modal/occupation/LawOpenApiModal';

function OcuLawRegStdList() {
  const state = useOcuLawRegStdFormStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'lawNm', headerName: '법규명', flex: 1 },
      { field: 'lawSeq', headerName: '법령 일련번호', flex: 1 },
      { field: 'subjectDeptCd', headerName: '주관부서', flex: 1 },
      {
        field: '',
        headerName: '보기',
        cellRenderer: (params) => {
          return <button onClick={() => lawOpenApiUrlGo(params)}>보기</button>;
        },
      },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    changeSearchInput,
    changeSearchDeptInfo,
    searchDeptInfo,
    clear,
    goDetailPage,
    isLawOpenApiModalOpen,
    isLawOpenApiCloseModal,
    okLawOpenApiokModal,
  } = state;

  // console.log('리스트값=========>', list);
  const { lawNm, subjectDeptCd } = searchParam;

  const { openFormModal, isCodeFormModalOpen, closeFormModal, okModal } = useOcuLawRegStdFormStore();
  // TODO : 검색 파라미터 나열

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    // 법령 일련번호
    console.log('data.ocuCommitId===>', data);
    openFormModal('U', data);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  const handleDeptSelectInput = (selectedValue, deptCd) => {
    changeSearchDeptInfo(selectedValue);
    changeSearchInput('subjectDeptCd', deptCd);
  };

  // 법규 등록 대장 상세, 입력 팝업 호출
  const selectLawOpenApi = () => {
    openFormModal('I');
  };

  // 법 api url이동
  const lawOpenApiUrlGo = (params) => {
    const url =
      'http://www.law.go.kr/DRF/lawService.do?OC=wlsrkd12345&target=law&MST=' + params.data.lawSeq + '&type=HTML';

    window.open(url, '_blank');
  };

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      <div className="conts-title">
        <h2>법규등록대장 기준 정보</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid-300">
            <div className="form-group wid100">
              <AppTextInput
                label="법규명"
                value={lawNm}
                onChange={(value) => {
                  changeSearchInput('lawNm', value);
                }}
                search={enterSearch}
              />
            </div>
          </div>
          <div className="form-cell wid-300">
            <div className="form-group wid100">
              <AppDeptSelectInput
                label={'주관부서'}
                value={subjectDeptCd}
                onChange={(deptCd) => {
                  changeSearchInput('subjectDeptCd', deptCd);
                }}
              />
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              조회
            </button>
          </div>
        </div>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />

      <LawRegStdFormModal isOpen={isCodeFormModalOpen} closeModal={closeFormModal} ok={okModal} />
      <LawOpenApiModal isOpen={isLawOpenApiModalOpen} closeModal={isLawOpenApiCloseModal} ok={okLawOpenApiokModal} />

      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        {/* <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}> */}
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={selectLawOpenApi}
        >
          신규
        </button>
      </div>
    </>
  );
}

export default OcuLawRegStdList;
