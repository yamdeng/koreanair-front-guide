import AppTextInput from '@/components/common/AppTextInput';
//import useSysCodeFormStore from '@/stores/admin/useSysCodeFormStore';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import ApiService from '@/services/ApiService';
import useOcuLawRegStdFormStore from '@/stores/occupation/general/useOcuLawRegStdFormStore';
// import LawOpenApiModal from '@/components/modal/occupation/LawOpenApiModal';

import Modal from 'react-modal';

const formName = 'LawRegStdFormModal';

function LawRegStdFormModal(props) {
  const { isOpen, closeModal, ok } = props;

  const {
    formValue,
    errors,
    changeInput,
    validate,
    gubun,
    deleteRegStd,
    openApiFormModal,
    // isLawOpenApiModalOpen,
    // isLawOpenApiCloseModal,
  } = useOcuLawRegStdFormStore();

  const save = async () => {
    const isValid = await validate();
    if (isValid) {
      ok(formValue);
    }
  };
  const {
    // 법령 ID
    lawId,
    // 법령 일련번호
    lawSeq,
    // 법령 명
    lawNm,
    // 주관 부서
    subjectDeptCd,
  } = formValue;

  // 법규 등록 대장 OPEN API 팝업 호출
  const lawOpenApiPopup = () => {
    openApiFormModal();
  };

  const saveLawRegStdDupChk = async () => {
    // 내가 접속한 정보에 부서가 저장된게 있는지 확인
    const selectFormApiPath = 'ocu/general/selectOcuLawRegInfoChk';

    // 등록된 부서 조회(중복 체크)
    const apiParam = {
      lawId: formValue.lawId,
    };
    const apiResult: any = await ApiService['get'](selectFormApiPath, apiParam, { disableLoadingBar: true });

    console.log('apiResult===>', apiResult);
    console.log('apiResult.ItemCount===>', apiResult.ItemCount);

    if (apiResult.ItemCount > 0) {
      alert('이미 등록된 기준정보가 존재하여 저장 불가합니다.');
    } else {
      {
        save();
      }
    }
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'middle-modal-overlay'}
      className={'confirm-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">법령</h3>
        <div className="pop_cont">
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppAutoComplete */}
                  <AppTextInput
                    id={`${formName}lawNm`}
                    label={'법규명'}
                    value={lawNm}
                    onChange={(value) => changeInput('lawNm', value)}
                    required
                    disabled
                    errorMessage={errors.lawNm}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    id={`${formName}lawSeq`}
                    label={'법령 일련번호'}
                    value={lawSeq}
                    onChange={(value) => changeInput('lawSeq', value)}
                    required
                    disabled
                    errorMessage={errors.lawSeq}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppDeptSelectInput
                    id={`${formName}subjectDeptCd`}
                    label={'주관부서'}
                    value={subjectDeptCd}
                    onChange={(deptCd) => {
                      changeInput('subjectDeptCd', deptCd);
                    }}
                    required
                    errorMessage={errors.subjectDeptCd}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>

        <div className="pop_btns">
          <button
            className="btn_text text_color_neutral-10 btn_confirm"
            style={{ display: gubun !== 'U' ? '' : 'none' }}
            onClick={lawOpenApiPopup}
          >
            검색
          </button>
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            취소
          </button>

          <button
            className="btn_text text_color_neutral-10 btn_confirm"
            style={{ display: gubun === 'U' ? '' : 'none' }}
            onClick={deleteRegStd}
            //onClick={deleteChkLawRegInfo}
          >
            삭제
          </button>

          {/* <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goFormPage}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          수정 */}

          {/* <button
            className="btn_text text_color_neutral-10 btn_confirm"
            style={{ display: gubun !== 'I' ? '' : 'none' }}
            onClick={deleteRegStd}
            //onClick={deleteChkLawRegInfo}
          >
            삭제 */}

          {/* <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}> */}
          <button
            className="btn_text text_color_neutral-10 btn_confirm"
            // style={{ display: gubun !== 'U' ? '' : 'none' }}
            onClick={saveLawRegStdDupChk}
          >
            저장
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default LawRegStdFormModal;
