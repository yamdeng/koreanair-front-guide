import React, { useState, useEffect, useMemo, useCallback } from 'react';

import { Row, Col, Spin, message } from 'antd';
import Summary from './Summary';
import Victim from './Victim';
import Contact from './Contact';

import { defaultAxios } from 'utils/AxiosFunc';
import { intlObj } from 'utils/commonUtils';

function OverView({ planList, selectedPlan, isAdmin, locale = 'ko' }) {
  const [overview, setOverView] = useState({});
  const [isLoaded, setIsLoaded] = useState(false);
  const plan = useMemo(() => {
    if (selectedPlan) {
      const index = planList.findIndex(plan => plan.nodeId === selectedPlan);
      if (index > -1) {
        return planList[index];
      }
    }
  }, [selectedPlan]);

  useEffect(() => {
    if (plan) {
      getOverView(plan.id).then(() => setIsLoaded(true));
    }
  }, [plan]);

  const getOverView = useCallback(async planId => {
    const {
      data: { data },
      status,
    } = await defaultAxios.get({ url: `/api/builder/board/v1/erp/overview/${planId}` });
    if (status === 200) {
      setOverView(data);
    } else if (status === 404) {
      message.error(intlObj.get('ke_common_message_00684', '데이터가 존재하지 않습니다.', locale));
    } else if (status === 500) {
      message.error(
        intlObj.get(
          'ke_common_message_00679',
          '요청한 작업을 수행하는데 오류가 발생했습니다.\n잠시 후 다시 시도해주십시오.',
          locale,
        ),
      );
    }
  }, []);

  const onSave = (payload, type) => {
    setIsLoaded(false);
    patchOverView(payload, type).then(() => {
      setIsLoaded(true);
    });
  };

  const patchOverView = useCallback(
    async (payload, type) => {
      let url = `/api/builder/board/v1/erp/overview/${plan.id}/${type}`;

      const {
        data: { data },
        status,
      } = await defaultAxios.patch({ url, payload: { ...payload, planKey: plan.planKey } });

      if (status === 200) {
        setOverView(data);
        message.success(intlObj.get('ke_common_message_00667', '성공적으로 저장되었습니다.', locale));
      } else if (status === 404) {
        message.error(intlObj.get('ke_common_message_00684', '데이터가 존재하지 않습니다.', locale));
      } else if (status === 500) {
        message.error(
          intlObj.get(
            'ke_common_message_00679',
            '요청한 작업을 수행하는데 오류가 발생했습니다.\n잠시 후 다시 시도해주십시오.',
            locale,
          ),
        );
      }
    },
    [plan],
  );

  return (
    <Spin spinning={!isLoaded}>
      <Row gutter={[14, 14]}>
        <Col xs={24} xl={8}>
          <Summary data={overview?.summary} onSave={onSave} locale={locale} isAdmin={isAdmin} />
        </Col>
        <Col xs={24} xl={10}>
          <Victim data={overview?.victim} onSave={onSave} locale={locale} isAdmin={isAdmin} />
        </Col>
        <Col xs={24} xl={6}>
          <Contact data={overview?.connect} onSave={onSave} locale={locale} isAdmin={isAdmin} />
        </Col>
      </Row>
    </Spin>
  );
}

export default OverView;
