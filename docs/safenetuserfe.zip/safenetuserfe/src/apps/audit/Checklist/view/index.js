import React from 'react';
import { connect } from 'react-redux';
import { Tabs, Button, Radio, Row, Col, Select } from 'antd';
import StyledChecklist from 'style/styledChecklist';
import PrintButton from 'components/PrintButton';
import { createStructuredSelector } from 'reselect';
import * as actions from '../store/checklist/actions';
import * as selectors from '../store/checklist/selectors';
import moment from 'moment';
import styled from 'styled-components';
import ChecklistDeleteModal from '../create/ChecklistDeleteModal';

const View = ({
  match,
  location,
  history,
  profile,
  getChecklist,
  getQuestions,
  checklist,
  questions,
  resetChecklist,
  deleteChecklist,
  apiResult,
}) => {
  const latestRevision = React.useRef(1);
  const currentRevision = React.useRef(0);
  const [revisions, setRevisions] = React.useState([]);
  const [initialTab, setInitialTab] = React.useState(-1);
  const [checklistDeleteModalVisible, setChecklistDeleteModalVisible] = React.useState(false);
  const selectChapterName = React.useRef('');

  React.useEffect(() => {
    if (apiResult.type === 'deleteChecklist') {
      history.push('/apps/77/audit/Checklist');
    }
  }, [apiResult]);

  React.useEffect(() => {
    return () => resetChecklist();
  }, []);

  React.useEffect(() => {
    const checklistId = match.params.id;
    if (checklistId) {
      getChecklist(checklistId, true);
    }
  }, [match.params.id]);

  React.useEffect(() => {
    const chapterId = new URLSearchParams(location.search).get('chapter');
    if (chapterId) {
      getQuestions(chapterId, currentRevision.current);
    }
  }, [location.search]);

  const createRevisionOptions = React.useCallback(
    (revisions = []) => revisions.map(({ revision }) => ({ label: revision, value: revision })),
    [],
  );

  React.useEffect(() => {
    if (checklist.revisions) {
      latestRevision.current = checklist.revisions[checklist.revisions.length - 1].revision;
      // currentRevision.current = checklist.revisions[checklist.revisions.length - 1].revision;
      setRevisions(createRevisionOptions(checklist.revisions));
    }

    if (checklist?.chapters?.length) {
      if (!location.search) {
        history.replace(`${match.url}?chapter=${checklist.chapters[0].origId}`);
        selectChapterName.current = checklist.chapters[0]?.chapterName;
      } else {
        const chapterId = new URLSearchParams(location.search).get('chapter');
        const selected = checklist.chapters.find(chapter => chapter.origId === Number(chapterId));
        selectChapterName.current = selected?.chapterName;
      }
      setInitialTab(checklist.chapters[0].origId);
      // handleTabChange(checklist.chapters[0].origId);
    }
  }, [checklist]);

  const handleTabChange = tab => {
    const queryString = new URLSearchParams({ chapter: tab });
    history.push(`${match.url}?${queryString}`);
    const selected = checklist.chapters.find(chapter => chapter.origId + '' === tab + '');
    selectChapterName.current = selected.chapterName;
  };

  const PrintHeader = styled.div`
    @media screen {
      display: none;
    }

    @media print {
      display: block;
    }
  `;

  const handleEdit = () => {
    const chapterQuery = new URLSearchParams(location.search).get('chapter')
      ? `?chapter=${new URLSearchParams(location.search).get('chapter')}`
      : '';
    history.push(`/apps/77/audit/Checklist/update/${match.params.id}` + chapterQuery);
  };

  const handleRevisionChange = value => {
    const checklistOriginId = match.params.id;
    const chapterId = new URLSearchParams(location.search).get('chapter');
    getChecklist(checklistOriginId, true, value);
    getQuestions(chapterId, value);
    // set
    currentRevision.current = value;
    handleTabChange(initialTab);
  };

  const ButtonArea = styled.div`
    @media print {
      display: none;
    }
  `;

  const handleChecklistDeleteButtonClick = () => {
    setChecklistDeleteModalVisible(true);
  };

  const handleChecklistDelete = formData => {
    deleteChecklist({ checklistOriginId: match.params.id, isRevisionUpdate: formData.isRevisionUpdate });
    setChecklistDeleteModalVisible(false);
  };

  const PrintChapterTitle = styled.h3`
    display: none;
    @media print {
      padding-top: 0px;
      padding-bottom: 15px;
      display: block;
    }
  `;

  return (
    <StyledChecklist className="keWrap">
      <ChecklistDeleteModal
        visible={checklistDeleteModalVisible}
        onOk={handleChecklistDelete}
        onCancel={() => setChecklistDeleteModalVisible(false)}
        checklistName={checklist.checklistName}
        centered
      />
      <PrintHeader>{`${moment().format('YYYY-MM-DD HH:mm:ss')} / ${profile.NAME_KOR} (${profile.EMP_NO})`}</PrintHeader>
      <section className="chapter-container">
        <h2>
          <Row align="middle">
            <Col span={18}>
              <span>{checklist?.checklistName}</span>
            </Col>
            <Col span={6} style={{ textAlign: 'right' }}>
              <div>
                Revision:
                <Select
                  style={{ width: '70px', marginLeft: '10px', textAlign: 'left' }}
                  options={revisions}
                  value={currentRevision.current || latestRevision.current}
                  onChange={handleRevisionChange}
                />
              </div>
            </Col>
          </Row>
        </h2>
        <Tabs
          type="card"
          size="small"
          onChange={handleTabChange}
          activeKey={new URLSearchParams(location.search).get('chapter') ?? '-1'}
          destroyInactiveTabPane
          renderTabBar={(props, Default) => (
            <>
              <PrintChapterTitle>{selectChapterName.current}</PrintChapterTitle>
              <Default {...props} />
            </>
          )}
        >
          {checklist?.chapters?.map(chapter => (
            <Tabs.TabPane
              tab={
                <>
                  {chapter.chapterName} <span>({chapter.questionCount})</span>
                </>
              }
              key={chapter.origId}
            >
              {/* <ol style={{ listStyle: 'none' }}> */}
              {questions.map(question => (
                <li className="checklist-chapter-item" key={question.id}>
                  <div className="inquiry" style={{ whiteSpace: 'pre-wrap' }}>
                    {question.content}
                  </div>
                  <div className="check">
                    <span>{question.refManual}</span>
                    <div className="checkbox-group">
                      <Radio.Group value={undefined}>
                        <Radio value="Y">Yes</Radio>
                        <Radio value="finding">Finding</Radio>
                        <Radio value="observation">Observation</Radio>
                        <Radio value="na">N/A</Radio>
                      </Radio.Group>
                    </div>
                  </div>
                  <div className="comment">{/* <Input placeholder="Input Comment" /> */}</div>
                </li>
              ))}
              {/* </ol> */}
            </Tabs.TabPane>
          ))}
        </Tabs>
      </section>
      <ButtonArea>
        <section className="chapter-footer">
          <div className="buttonGroup">
            <PrintButton></PrintButton>
            {currentRevision.current === 0 || currentRevision.current === latestRevision.current ? (
              <>
                <Button onClick={handleChecklistDeleteButtonClick}>Delete</Button>
                <Button onClick={handleEdit}>Edit</Button>
              </>
            ) : null}
          </div>
        </section>
      </ButtonArea>
    </StyledChecklist>
  );
};

const mapStateToProps = createStructuredSelector({
  checklist: selectors.selectChecklist(),
  questions: selectors.selectQuestions(),
  isLoading: selectors.selectIsLoading(),
  profile: selectors.selectProfile(),
  apiResult: selectors.selectApiResult(),
});

const mapDispatchToProps = dispatch => ({
  getChecklist: (id, isView, revision) => dispatch(actions.getChecklist(id, isView, revision)),
  getQuestions: (id, revision) => dispatch(actions.getQuestions(id, revision)),
  deleteChecklist: checklistOriginId => dispatch(actions.deleteChecklist(checklistOriginId)),
  resetChecklist: () => dispatch(actions.resetChecklist()),
});

export default connect(mapStateToProps, mapDispatchToProps)(View);
