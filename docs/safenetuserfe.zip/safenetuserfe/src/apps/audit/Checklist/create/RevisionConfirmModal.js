import React from 'react';
import { Button, Modal, Checkbox, Space } from 'antd';

const RevisionConfirmModal = props => {
  const [isRevisionUpdate, setIsRevisionUpdate] = React.useState(true);

  const handleCancel = () => {
    props.onCancel();
    setIsRevisionUpdate(true);
  };

  const handleOk = () => {
    if (isRevisionUpdate) {
      props.onSave();
    } else {
      props.onUpdate();
    }
    setIsRevisionUpdate(true);
  };

  const Footer = (
    <>
      <Button onClick={handleCancel}>취소</Button>
      <Button onClick={handleOk}>확인</Button>
    </>
  );
  const handleRevisionUpdateChange = event => {
    setIsRevisionUpdate(event.target.checked);
  };

  return (
    <Modal {...props} title="체크리스트 저장" footer={Footer}>
      <Space direction="vertical">
        <p>Checklist 변경사항을 저장합니다.</p>
        <Checkbox checked={isRevisionUpdate} onChange={handleRevisionUpdateChange}>
          Revision 업데이트
        </Checkbox>
      </Space>
    </Modal>
  );
};

export default RevisionConfirmModal;
