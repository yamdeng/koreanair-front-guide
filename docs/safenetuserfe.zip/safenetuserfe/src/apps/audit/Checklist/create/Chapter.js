import React from 'react';
import { connect } from 'react-redux';
import { Button, Form } from 'antd';
import Questionnaire from 'components/Questionnaires';

import { createStructuredSelector } from 'reselect';
import * as actions from '../store/checklist/actions';
import * as selectors from '../store/checklist/selectors';

const Chapter = ({ id, isLoading, handleAddQuestion, isUpdated, resetQuestions, setDeletedQuestionIds }) => {
  React.useEffect(() => {
    return () => {
      resetQuestions();
    };
  }, []);

  return (
    <Form.List name="questions">
      {(fields, { add, remove }) => (
        <>
          {fields.map(({ key, name }) => (
            <Questionnaire key={key} name={name} remove={remove} setDeletedQuestionIds={setDeletedQuestionIds} />
          ))}
          <section className="chapter-add">
            <Button
              className="add-btn"
              onClick={() => {
                isUpdated.current = true;
                add();
              }}
            >
              + Add Question
            </Button>
          </section>
        </>
      )}
    </Form.List>
  );
};

const mapStateToProps = createStructuredSelector({
  isLoading: selectors.selectIsLoading(),
});

const mapDispatchToProps = dispatch => ({
  resetQuestions: () => dispatch(actions.resetQuestions()),
});

export default connect(mapStateToProps, mapDispatchToProps)(Chapter);
