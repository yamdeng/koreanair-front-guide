import React from 'react';
import { Button, Input, Form, Popconfirm, Radio } from 'antd';
import { CloseSquareFilled } from '@ant-design/icons';

const Questionnaire = ({ name, remove }) => {
  return (
    <>
      <section className="checklist-chapter-edit">
        <section className="checklist-chapter-add-item">
          <Form.Item name={[name, 'content']} className="inquiry">
            <Input.TextArea rows={4} style={{ width: '100%' }} />
          </Form.Item>
          <div className="check" style={{ marginBottom: 0 }}>
            <span className="manual">
              <Form.Item name={[name, 'refManual']} style={{ marginBottom: 0 }}>
                <Input />
              </Form.Item>
            </span>
            <div className="checkbox-group">
              <Form.Item style={{ marginBottom: 0 }} initialValue="Y">
                <Radio.Group>
                  <Radio value="Y">Yes</Radio>
                  <Radio value="finding">Finding</Radio>
                  <Radio value="observation">Observation</Radio>
                  <Radio value="na">N/A</Radio>
                </Radio.Group>
              </Form.Item>
            </div>
          </div>
          <Popconfirm
            title="질문을 삭제하시겠습니까?"
            okText="OK"
            cancelText="Cancel"
            onConfirm={() => {
              remove(name);
            }}
          >
            <Button type="text" icon={<CloseSquareFilled />} className="delete" />
          </Popconfirm>
        </section>
      </section>
    </>
  );
};

export default Questionnaire;
