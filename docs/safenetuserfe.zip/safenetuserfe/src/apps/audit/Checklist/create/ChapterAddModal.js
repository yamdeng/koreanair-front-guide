import React from 'react';
import { Modal, Input, Checkbox, Form } from 'antd';

const ChapterAddModal = ({ visible, onOk, onCancel, isNew }) => {
  const [form] = Form.useForm();
  const handleOk = () => {
    form
      .validateFields()
      .then(values => {
        onOk({
          chapterName: values.chapterName,
          isRevisionUpdate: values.isRevisionUpdate,
        });
      })
      .then(() => form.resetFields())
      .catch(error => console.debug(error));
  };

  const handleCancel = () => {
    form.resetFields();
    onCancel();
  };

  return (
    <Modal visible={visible} title="Add Chapter" onOk={handleOk} onCancel={handleCancel}>
      <Form form={form} autoComplete="off">
        <Form.Item
          style={{ marginBottom: '20px' }}
          name="chapterName"
          rules={[
            {
              required: true,
              message: '챕터 명을 입력하세요.',
            },
          ]}
        >
          <Input placeholder="Chapter name" />
        </Form.Item>
        <Form.Item name="isRevisionUpdate" initialValue={true} valuePropName="checked" hidden={isNew}>
          <Checkbox>Revision 업데이트</Checkbox>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default ChapterAddModal;
