import styled from 'styled-components';

const Styled = styled.section`
  padding-top: 30px;

  .chapter-add {
    margin-top: 10px;
    & .add-btn {
      width: 100%;
    }
  }

  .checklist {
    &-container {
      padding: 0 0 20px;
      background-color: #fff;
    }

    &-tool {
      text-align: right;
      margin: 10px 0 20px;
    }

    &-list {
      h4 {
        color: #333;
        border-bottom: 1px solid #bcbccd;
        font-weight: 700;
      }

      ul {
        display: flex;
        flex-direction: column;
        padding: 16px 0;

        li {
          & > i {
            font-style: normal;
            font-size: 0.9em;
            opacity: 0.8;
          }
          button.editChapter {
            visibility: hidden;
            opacity: 0;
            margin-right: 2px;
          }

          &:hover {
            button.editChapter {
              visibility: visible;
              opacity: 1;
            }
          }
        }
      }
    }

    &-chapter {
      &-add {
        padding: 20px;
        background-color: #f5f6f7;

        &-item {
          padding: 35px 20px;
          background-color: #dee0ef;
          position: relative;

          & + .checklist-chapter-add-item {
            margin-top: 10px;
          }

          .check {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
            flex-wrap: wrap;

            &box-group {
              width: 100%;
              margin-top: 10px;
              text-align: right;
            }
          }

          .delete {
            position: absolute;
            top: 0;
            right: 0;
            opacity: 0.5;

            &:hover {
              opacity: 1;
            }
          }
        }
      }

      &-list {
        /* ol */
        list-style: none;
        padding: 0;
      }

      &-item {
        padding: 20px;

        & + .checklist-chapter-item {
          border-top: 1px solid #ddd;
        }

        .check {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin: 20px 0;
          flex-wrap: wrap;

          &box-group {
            min-width: 100%;
            margin-top: 10px;
            text-align: right;
          }
        }
      }

      &-edit {
        background-color: #f5f6f7;
        padding: 0;

        .checklist-chapter-add-item {
          padding: 20px 40px 20px 20px;
          background-color: transparent;

          & + .checklist-chapter-add-item {
            margin-top: 0;
            border-top: 1px solid #ddd;
          }

          .delete {
            top: 11px;
            right: 4px;
          }
        }
      }
    }
  }

  .ant-tabs-card {
    .ant-tabs-tab,
    .ant-tabs-nav-add {
      background-color: #fff;
      border-color: #bdbdbd;

      &-btn {
        min-width: 200px;

        button {
          margin: 0 0 0 8px;
          opacity: 0.5;

          &:hover {
            opacity: 1;
          }
        }
      }
    }
  }
`;
export default Styled;
