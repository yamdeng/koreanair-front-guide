import React from 'react';
import { Modal, Button } from 'antd';

const ExpiredTimeModal = ({ visible, handleOk }) => {
  const Footer = <Button onClick={handleOk}>확인</Button>;

  return (
    <Modal title="편집 유효시간 종료" visible={visible} closable={false} footer={Footer}>
      편집 유효시간이 종료되었습니다. 체크리스트 목록화면으로 이동합니다.
    </Modal>
  );
};

export default ExpiredTimeModal;
