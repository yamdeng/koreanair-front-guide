import React from 'react';
import { Modal, Form, Input, Checkbox } from 'antd';
import { useForm } from 'antd/lib/form/Form';

const ChecklistDeleteModal = ({ visible, onOk, onCancel, checklistName, centered }) => {
  const [form] = useForm();
  const inputRef = React.useRef();

  React.useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
    return () => {
      form.resetFields();
    };
  }, []);

  const handleOk = () => {
    form
      .validateFields()
      .then(values => {
        onOk(values);
      })
      .then(() => form.resetFields())
      .catch(error => console.debug('error', error));
  };

  const handleCancel = () => {
    form.resetFields();
    onCancel();
  };

  return (
    <Modal title="체크리스트 삭제" onOk={handleOk} onCancel={handleCancel} visible={visible} centered={centered}>
      <div>
        <div>체크리스트를 삭제하면 모든 챕터와 문항이 삭제됩니다. 삭제하시겠습니까?</div>
        <div style={{ marginBottom: '15px' }}>체크리스트명을 아래에 입력하세요.</div>
        <h3 style={{ textAlign: 'center', marginBottom: '10px' }}>{checklistName ?? ''}</h3>
      </div>
      <Form form={form} autoComplete="off" layout="vertical">
        <Form.Item
          name="deletedName"
          style={{ marginBottom: '20px' }}
          rules={[
            {
              validator: async (_, value) => {
                if (!value) {
                  return Promise.reject('챕터 명을 입력하세요.');
                }

                if (value !== checklistName) {
                  return Promise.reject('챕터 명을 올바르게 입력하세요.');
                }
                return Promise.resolve();
              },
            },
          ]}
        >
          <Input ref={inputRef} />
        </Form.Item>
        {/* <Form.Item name="isRevisionUpdate" initialValue={true} valuePropName="checked">
          <Checkbox>Revision 업데이트</Checkbox>
        </Form.Item> */}
      </Form>
    </Modal>
  );
};

export default ChecklistDeleteModal;
