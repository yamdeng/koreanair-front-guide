import React from 'react';
import { connect } from 'react-redux';
import { Tabs, Input, Modal, Form, Button, Checkbox, Row, Col, Select } from 'antd';
import { EditOutlined } from '@ant-design/icons';

import StyledChecklist from './styledChecklist';
import Chapter from './Chapter';

import { createStructuredSelector } from 'reselect';
import * as actions from '../store/checklist/actions';
import * as selectors from '../store/checklist/selectors';
import PrintButton from 'components/PrintButton';
import ChecklistDeleteModal from './ChecklistDeleteModal';
import RevisionConfirmModal from './RevisionConfirmModal';
import ChapterAddModal from './ChapterAddModal';
import ExpiredTimeModal from './ExpiredTimeModal';
import PageExpiryTimer from 'components/PageExpiryTimer';
import usePageConnectionCheck from 'hooks/usePageConnectionCheck';

// export const CreateChecklistContext = React.useContext();
const CONNECTION_KEY = 'CHECKLIST';
const CreateChecklist = ({
  match,
  history,
  location,
  checklist,
  isLoading,
  getChecklist,
  getQuestions,
  postChapter,
  updateChapter,
  deleteChapter,
  apiResult,
  questions,
  updateQuestions,
  deleteChecklist,
  resetApiResult,
  setIsLoaded,
  isLoaded,
  resetChecklist,
}) => {
  const [chapterTitle, setChapterTitle] = React.useState('');
  const [selectedKey, setSelectedKey] = React.useState('');
  const [updatedQuestions, setUpdatedQuestions] = React.useState({});
  const [deletedQuestionIds, setDeletedQuestionIds] = React.useState([]);
  const [checklistName, setChecklistName] = React.useState('');
  const [createModalVisible, setCreateModalVisible] = React.useState(false);
  const [updateModalVisible, setUpdateModalVisible] = React.useState(false);
  const [deleteModalVisible, setDeleteModalVisible] = React.useState(false);
  const [checklistDeleteModalVisible, setChecklistDeleteModalVisible] = React.useState(false);
  const [revisionConfirmModalVisible, setRevisionConfirmModalVisible] = React.useState(false);
  const [expiredTimeModalVisible, setExpiredTimeModalVisible] = React.useState(false);

  const [deleteForm] = Form.useForm();
  const [updateForm] = Form.useForm();
  const [chapterForm] = Form.useForm();
  const deleteInputRef = React.useRef();
  const updateInputRef = React.useRef();
  const titleRef = React.useRef();
  const isUpdated = React.useRef(false);
  const isNew = React.useRef(location.state?.isNew ?? false);

  React.useEffect(() => {
    titleRef.current.focus();
    return () => {
      setIsLoaded(false);
      resetApiResult();
      resetChecklist();
    };
  }, []);

  React.useEffect(() => {
    const checklistId = match.params.id;
    if (checklistId) {
      // getChecklist({ checklistId, isView: false });
      getChecklist(checklistId, false);
    }
  }, [match.params.id]);

  React.useEffect(() => {
    const chapterId = new URLSearchParams(location.search).get('chapter');
    if (chapterId) {
      getQuestions(chapterId);
    }
  }, [location.search]);

  React.useEffect(() => {
    // postChapter(chapter add) -> 추가된 챕터로 이동
    // putChapter(chapter title update) -> 변경된 챕터로 이동/갱신
    // deleteChapter(chapter delete) -> 체크리스트의 첫 챕터로 이동, 없으면 그냥 빈 체크리스트로
    // updateQuestions(save btn click) -> 현재화면 갱신
    // deleteChecklist(delete btn click) -> 체크리스트 목록으로 이동
    if (apiResult.type === 'postChapter') {
      const { chapterId } = apiResult.data;
      history.push(`?chapter=${chapterId}`);
    } else if (apiResult.type === 'putChapter') {
      const { chapterId } = apiResult.data;
      history.push(`?chapter=${chapterId}`);
    } else if (apiResult.type === 'deleteChapter') {
      history.push(match.url);
    } else if (apiResult.type === 'updateQuestions') {
      // const { chapterId } = apiResult.data;
      // history.push(`?chapter=${chapterId}`);
    } else if (apiResult.type === 'deleteChecklist') {
      history.push('/apps/77/audit/Checklist');
    } else if (apiResult.type === 'conflict') {
      history.push('/apps/77/audit/Checklist');
    } else if (apiResult.type === 'error') {
      history.push(`/error`, apiResult.data);
      setIsLoaded(false);
    }
  }, [apiResult]);

  React.useEffect(() => {
    chapterForm.setFieldsValue({ questions });
  }, [questions]);

  React.useEffect(() => {
    if (checklist.checklistId) {
      setIsLoaded(true);
    }
    if (checklist.checklistName) {
      setChecklistName(checklist.checklistName);
    }

    if (checklist?.chapters?.length && !location.search) {
      handleTabChange(checklist.chapters[0].origId);
    }
  }, [checklist]);

  usePageConnectionCheck({
    connectionKey: CONNECTION_KEY,
    id: match.params.id,
    disabled: !isLoaded,
  });

  const editActions = {
    add() {
      setCreateModalVisible(true);
    },
    remove(targetKey) {
      new Promise(res => res(setDeleteModalVisible(true)))
        .then(() => setSelectedKey(targetKey))
        .then(() => deleteInputRef.current.focus());
    },
  };

  const handleEdit = (targetKey, action) => {
    editActions[action](targetKey);
  };

  const addTab = ({ chapterName, isRevisionUpdate }) => {
    setCreateModalVisible(false);
    // const isNew = location.state?.isNew ?? false;
    const newChapter = {
      chapterName: chapterTitle,
      checklistOriginId: match.params.id,
      chapterName,
      isRevisionUpdate: !(isNew.current || !isRevisionUpdate),
    };
    setChapterTitle('');
    postChapter(newChapter);
  };

  const deleteTab = () => {
    // deleteForm.submit();
    deleteForm
      .validateFields()
      .then(values => {
        const { chapters = [] } = checklist;
        // 여기서 delete api 요청
        const deletedIndex = chapters.findIndex(chapter => chapter.origId === Number(selectedKey));
        if (deletedIndex === -1) {
          return;
        }

        let revisionUpdate = true;
        if (!!location?.state?.isNew || !values.isRevisionUpdate) {
          revisionUpdate = false;
        }

        const initialChapter = chapters[0];
        deleteChapter({
          chapterOriginId: selectedKey,
          checklistOriginId: match.params.id,
          isRevisionUpdate: !(isNew.current || !values.isRevisionUpdate),
          chapterName: values.deletedName,
        });
        if (initialChapter) {
          const { origId } = initialChapter;
          handleTabChange(origId);
          return;
        }
        history.replace(`${match.url}`);
      })
      .then(() => {
        deleteForm.resetFields();
        setDeleteModalVisible(false);
      })
      .catch(error => console.debug('delete error!', error));
  };

  const updateTab = () => {
    updateForm
      .validateFields()
      .then(values => {
        // 여기서 update api 요청
        const newTabs = [...checklist.chapters];
        const index = newTabs.findIndex(chapter => chapter.origId === Number(selectedKey));
        const newTab = { ...newTabs[index] };
        newTabs[index] = newTab;
        // setChapterTabs(newTabs);
        let revisionUpdate = true;
        if (!!location?.state?.isNew || !values.isRevisionUpdate) {
          revisionUpdate = false;
        }

        updateChapter({
          chapterOriginId: newTab.origId,
          chapterName: values.updateName,
          isRevisionUpdate: !(isNew.current || !values.isRevisionUpdate),
          checklistOriginId: match.params.id,
        });
      })
      .then(() => {
        updateForm.resetFields();
        setUpdateModalVisible(false);
      })
      .catch(error => console.debug(error));
  };

  const handleDeleteModalCancel = () => {
    setDeleteModalVisible(false);
    deleteForm.resetFields();
  };

  const handleUpdateModalVisible = (e, { origId, chapterName }) => {
    e.stopPropagation();
    new Promise(res => res(updateForm.setFieldsValue({ updateName: chapterName })))
      .then(() => setUpdateModalVisible(true))
      .then(() => setChapterTitle(chapterName))
      .then(() => setSelectedKey(origId))
      .then(() => updateInputRef.current.focus());
  };

  const handleTabChange = tab => {
    if (isUpdated.current) {
      if (!window.confirm('저장하지 않은 문항은 사라집니다. 챕터를 이동하시겠습니까?')) {
        return;
      }
    }
    const queryString = new URLSearchParams({ chapter: tab });
    history.push(`${match.url}?${queryString}`);
    getQuestions(tab);
    isUpdated.current = false;
    resetApiResult();
  };

  const handleFormChange = changed => {
    if (changed[0].name.length === 1) {
      //['questions'] 일 때, add remove 시
      return;
    }
    isUpdated.current = true;
    const [changeField] = changed;
    const { name, value } = changeField;
    const [_, index, field] = name;
    const changedResult = { [field]: value };
    const originQuestions = chapterForm.getFieldValue(['questions', index]);
    const originId = originQuestions.id;

    setUpdatedQuestions(prev => {
      const updated = { ...prev };
      if (originId) {
        updated[originId] = { ...updated[originId], ...changedResult, id: originId };
      } else {
        updated['new' + index] = { ...updated['new' + index], ...changedResult, id: undefined };
      }
      return updated;
    });
  };

  const handleQuestionRemove = formName => {
    const removed = chapterForm.getFieldValue(['questions', formName]);
    if (removed.id) {
      // id 가 있는 경우, 원래 추가된 문항
      const deleted = new Set(deletedQuestionIds);
      deleted.add(removed.id);
      setDeletedQuestionIds([...deleted]);
    } else {
      // id가 없는 새로 추가된 문항
      setUpdatedQuestions(prev => {
        const next = { ...prev };
        delete next['new' + formName];
        return next;
      });
    }
  };

  const postQuestion = isRevisionUpdate => {
    const chapterOriginid = new URLSearchParams(location.search).get('chapter');
    const checklistOriginId = match.params.id;
    const values = Object.values(updatedQuestions);
    const inserted = values.filter(value => !value.id);
    const updated = values.filter(value => value.id);
    const deleted = deletedQuestionIds;
    updateQuestions({
      inserted,
      updated,
      deleted,
      chapterOriginid,
      checklistOriginId,
      checklistName,
      isRevisionUpdate,
    });
    setUpdatedQuestions({});
    setRevisionConfirmModalVisible(false);
  };

  const handleSave = () => {
    // const isNew = location.state?.isNew ?? false;
    postQuestion(true);
  };

  const handleUpdate = () => {
    postQuestion(false);
  };
  const handleChecklistDeleteButtonClick = () => {
    setChecklistDeleteModalVisible(true);
  };

  const handleChecklistDelete = formData => {
    deleteChecklist({ checklistOriginId: match.params.id, isRevisionUpdate: formData.isRevisionUpdate });
    setChecklistDeleteModalVisible(false);
  };

  const handleOnExpired = () => {
    setIsLoaded(false);
    setExpiredTimeModalVisible(true);
  };

  return (
    <StyledChecklist className="keWrap">
      {/* <PageExpiryTimer callbackOnExpired={handleCallbackOnExpired} maxSecond={15} minSecond={3}></PageExpiryTimer> */}
      <PageExpiryTimer maxSecond={1200} callbackOnExpired={handleOnExpired}></PageExpiryTimer>
      <ExpiredTimeModal
        visible={expiredTimeModalVisible}
        handleOk={() => {
          history.replace('/apps/77/audit/Checklist');
          setExpiredTimeModalVisible(false);
        }}
      />
      <ChapterAddModal
        visible={createModalVisible}
        onOk={addTab}
        onCancel={() => setCreateModalVisible(false)}
        isNew={isNew.current}
      />
      <Modal
        visible={updateModalVisible}
        title="Modify Chapter"
        onOk={updateTab}
        onCancel={() => {
          setChapterTitle('');
          setUpdateModalVisible(false);
          updateForm.resetFields();
        }}
      >
        <div>
          <div style={{ marginBottom: '15px' }}>챕터명을 아래에 입력하세요.</div>
        </div>
        <Form form={updateForm} autoComplete="off">
          <Form.Item
            style={{ marginBottom: '20px' }}
            name="updateName"
            rules={[
              {
                required: true,
                message: '챕터 명을 입력하세요.',
              },
            ]}
          >
            <Input ref={updateInputRef} />
          </Form.Item>
          <Form.Item name="isRevisionUpdate" initialValue={true} valuePropName="checked" hidden={isNew.current}>
            <Checkbox>Revision 업데이트</Checkbox>
          </Form.Item>
        </Form>
      </Modal>
      <Modal visible={deleteModalVisible} title="Delete Chapter" onOk={deleteTab} onCancel={handleDeleteModalCancel}>
        <div>
          <div>챕터를 삭제하면 모든 문항이 삭제됩니다. 삭제하시겠습니까?</div>
          <div style={{ marginBottom: '15px' }}>챕터명을 아래에 입력하세요.</div>
          <h3 style={{ textAlign: 'center', marginBottom: '10px' }}>
            {checklist?.chapters?.find(chapter => chapter.origId === Number(selectedKey))?.chapterName ?? ''}
          </h3>
        </div>
        <Form form={deleteForm} autoComplete="off">
          <Form.Item
            style={{ marginBottom: '20px' }}
            name="deletedName"
            rules={[
              {
                validator: async (_, value) => {
                  if (!value) {
                    return Promise.reject('챕터 명을 입력하세요.');
                  }

                  if (
                    value !== checklist.chapters.find(chapter => chapter.origId === Number(selectedKey))?.chapterName
                  ) {
                    return Promise.reject('챕터 명을 올바르게 입력하세요.');
                  }
                  return Promise.resolve();
                },
              },
            ]}
          >
            <Input ref={deleteInputRef} />
          </Form.Item>
          <Form.Item name="isRevisionUpdate" initialValue={true} valuePropName="checked" hidden={isNew.current}>
            <Checkbox>Revision 업데이트</Checkbox>
          </Form.Item>
        </Form>
      </Modal>
      <ChecklistDeleteModal
        visible={checklistDeleteModalVisible}
        onOk={handleChecklistDelete}
        onCancel={() => setChecklistDeleteModalVisible(false)}
        checklistName={checklist.checklistName}
        centered
      />
      <RevisionConfirmModal
        visible={revisionConfirmModalVisible}
        onSave={handleSave}
        onUpdate={handleUpdate}
        onCancel={() => setRevisionConfirmModalVisible(false)}
        centered
      />
      <section className="chapter-container">
        <Row gutter={[24, 8]}>
          <Col span={18}>
            <Input
              // value={checklist.checklistName}
              value={checklistName}
              onChange={event => setChecklistName(event.target.value)}
              style={{ marginBottom: '20px' }}
              ref={titleRef}
            />
          </Col>
          <Col span={6} style={{ textAlign: 'right' }}>
            <div>
              Revision:
              <Select
                disabled
                value={checklist.checklistRevision}
                style={{ width: '70px', marginLeft: '10px', textAlign: 'left' }}
              />
            </div>
          </Col>
        </Row>
        <Tabs
          type="editable-card"
          size="small"
          onEdit={handleEdit}
          onChange={handleTabChange}
          activeKey={new URLSearchParams(location.search).get('chapter') ?? '-1'}
          destroyInactiveTabPane
        >
          {checklist.chapters.map(chapter => (
            <Tabs.TabPane
              tab={
                <>
                  {chapter.chapterName} ({chapter.questionCount})
                  <Button type="text" onClick={e => handleUpdateModalVisible(e, chapter)} icon={<EditOutlined />} />
                </>
              }
              key={chapter.origId}
            >
              <Form form={chapterForm} onFieldsChange={handleFormChange}>
                <Chapter
                  id={chapter.origId}
                  isUpdated={isUpdated}
                  form={chapterForm}
                  setDeletedQuestionIds={handleQuestionRemove}
                />
              </Form>
            </Tabs.TabPane>
          ))}
        </Tabs>
      </section>
      <section className="chapter-footer">
        <div className="buttonGroup">
          <PrintButton>Print</PrintButton>
          <Button onClick={handleChecklistDeleteButtonClick}>Delete</Button>
          {/* <Button onClick={handleSave}>Save</Button> */}
          <Button onClick={isNew.current ? () => postQuestion(false) : () => setRevisionConfirmModalVisible(true)}>
            Save
          </Button>
        </div>
      </section>
    </StyledChecklist>
  );
};

const mapStateToProps = createStructuredSelector({
  checklist: selectors.selectChecklist(),
  isLoading: selectors.selectIsLoading(),
  apiResult: selectors.selectApiResult(),
  questions: selectors.selectQuestions(),
  isLoaded: selectors.selectIsLoaded(),
});

const mapDispatchToProps = dispatch => ({
  getChecklist: (checklist, isView) => dispatch(actions.getChecklist(checklist, isView)),
  getQuestions: id => dispatch(actions.getQuestions(id)),
  setTitle: title => dispatch(actions.setTitle(title)),
  postChapter: chapter => dispatch(actions.postChapter(chapter)),
  updateChapter: chapter => dispatch(actions.updateChapter(chapter)),
  deleteChapter: id => dispatch(actions.deleteChapter(id)),
  updateQuestions: questions => dispatch(actions.updateQuestions(questions)),
  deleteChecklist: checklistOriginId => dispatch(actions.deleteChecklist(checklistOriginId)),
  resetApiResult: () => dispatch(actions.resetApiResult()),
  setIsLoaded: isLoaded => dispatch(actions.setIsLoaded(isLoaded)),
  resetChecklist: () => dispatch(actions.resetChecklist()),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateChecklist);
