import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { Tabs, Button, Row, Col, message, Space } from 'antd';
import { PlusOutlined, EditOutlined } from '@ant-design/icons';
import CreateModal from './CreateModal';

import StyledChecklist from 'style/styledChecklist';

import { createStructuredSelector } from 'reselect';
import * as actions from '../store/checklist/actions';
import * as selectors from '../store/checklist/selectors';
import useCommonCodes from 'hooks/useCommonCodes';
import { defaultAxios } from 'utils/AxiosFunc';
import { forbidden } from 'utils/errorCode';

const codes = [109];
export const ChecklistContext = React.createContext();
const Checklists = ({ getChecklists, history, match, postChecklist, apiResult, profile, setApiResult }) => {
  const [visible, setVisible] = React.useState(false);
  const [currentTab, setCurrentTab] = React.useState('1');
  const [checklists, setChecklists] = React.useState([]);
  const [divisions, setDivisions] = React.useState([]);
  const divisionCodes = useCommonCodes(codes);

  React.useEffect(() => {
    const checklistAuth = profile.RESOURCE_AUTH.audit_authority.check_list;
    const divisions = divisionCodes?.['division(audit)'] ?? [];

    if (checklistAuth.includes('all')) {
      return setDivisions(divisions);
    } else {
      return setDivisions(divisions.filter(division => division.codeValue === checklistAuth[0]));
    }
  }, [divisionCodes]);

  React.useEffect(() => {
    if (apiResult.type === 'postChecklist') {
      if (apiResult.data) {
        const id = apiResult.data;
        history.push(`${match.url}/update/${id}`, { isNew: true });
      }
    } else if (apiResult.type === 'delete') {
      history.push(`/myMenu`);
    } else if (apiResult.type === 'error') {
      history.push(`/error`, apiResult.data);
    }
  }, [apiResult]);

  React.useEffect(() => {
    getChecklists();
  }, []);

  React.useEffect(() => {
    const checklistAuth = profile.RESOURCE_AUTH.audit_authority.check_list;
    if (location.search) {
      const division = new URLSearchParams(location.search).get('division');
      const hasAuth = checklistAuth.includes(division);
      if (checklistAuth.includes('all') || hasAuth) {
        setCurrentTab(division);
        fetchDivisionChecklist(division);
        return;
      }
    } else {
      if (checklistAuth.includes('all')) {
        handleTabChange('SELOYE');
      } else {
        handleTabChange(checklistAuth);
      }
      return;
    }
    const apiResult = {
      type: 'error',
      data: forbidden,
    };
    setApiResult(apiResult);
  }, [location.search]);

  const handleVisible = visible => {
    setVisible(visible);
  };

  const fetchDivisionChecklist = async division => {
    const { data: result, status } = await defaultAxios.get({
      url: `/api/ke/audit/v1/checklist/checklists/${division}`,
    });

    if (status === 200) {
      setChecklists(result.data);
      return { checklist: result.data, count: result.totalCount };
    }
    return message.error('체크리스트 조회가 실패했습니다.');
  };

  const handleTabChange = tab => {
    setCurrentTab(tab);
    history.push(`?division=${tab}`);
    // fetchDivisionChecklist(tab);
  };

  const handleOk = checklist => {
    postChecklist(checklist);
    setVisible(false);
  };

  const handleCancel = () => {
    // setAuditTypeOptions([]);
    setVisible(false);
  };

  return (
    <ChecklistContext.Provider value={currentTab}>
      <StyledChecklist className="keWrap">
        <CreateModal visible={visible} onOk={handleOk} onCancel={handleCancel} />
        <Tabs defaultActiveKey="1" size="middle" activeKey={currentTab} onChange={handleTabChange}>
          {divisions.map(division => (
            <Tabs.TabPane tab={division.nameKo} key={division.codeValue}>
              <section className="checklist-container">
                <aside className="checklist-tool">
                  <Button type="primary" ghost icon={<PlusOutlined />} onClick={() => handleVisible(true)}>
                    Add Checklist
                  </Button>
                </aside>
                <Row gutter={[24, 24]} className="checklist-list">
                  {checklists.map(checklist => (
                    <Col xs={24} md={8} key={checklist.originId}>
                      <h4>
                        <Link to={`${match.url}/update/${checklist.originId}`}>
                          <Button type="text" icon={<EditOutlined />} />
                        </Link>
                        <Link to={`${match.url}/view/${checklist.originId}`}>{checklist.name}</Link>
                      </h4>
                      <ul>
                        {checklist.chapters.map(chapter => (
                          <li key={chapter.id}>
                            <Space>
                              <Link to={`${match.url}/update/${checklist.originId}?chapter=${chapter.origId}`}>
                                <Button type="text" icon={<EditOutlined />} className="editChapter" />
                              </Link>
                              <Link to={`${match.url}/view/${checklist.originId}?chapter=${chapter.origId}`}>
                                {chapter.chapterName} <i>({chapter.questionCount ?? 0})</i>
                              </Link>
                            </Space>
                          </li>
                        ))}
                      </ul>
                    </Col>
                  ))}
                </Row>
              </section>
            </Tabs.TabPane>
          ))}
        </Tabs>
      </StyledChecklist>
    </ChecklistContext.Provider>
  );
};

const mapStateToProps = createStructuredSelector({
  checklists: selectors.selectChecklists(),
  apiResult: selectors.selectApiResult(),
  profile: selectors.selectProfile(),
});

const mapDispatchToProps = dispatch => ({
  getChecklists: () => dispatch(actions.getChecklists()),
  postChecklist: checklist => dispatch(actions.postChecklist(checklist)),
  setApiResult: apiResult => dispatch(actions.setApiResult(apiResult)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Checklists);
