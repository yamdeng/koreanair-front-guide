import React from 'react';
import { Input, Modal, Form, Select } from 'antd';
import { withRouter } from 'react-router-dom';
import { codesToSelectOptions } from 'apps/sms/getCodes';
import useCommonCodes from 'hooks/useCommonCodes';
import { ChecklistContext } from './index';

const auditTypeCode = [129, 130, 131, 132, 133, 134, 135, 136];
const CreateModal = ({ visible, onOk, onCancel }) => {
  const [auditTypeOptions, setAuditTypeOptions] = React.useState([]);
  const [form] = Form.useForm();
  const auditTypes = useCommonCodes(auditTypeCode) ?? {};
  const division = React.useContext(ChecklistContext);

  React.useEffect(() => {
    const mergedTypes = [];
    Object.keys(auditTypes).forEach(key => mergedTypes.push(...auditTypes[key]));
    setAuditTypeOptions(codesToSelectOptions(mergedTypes));
    return () => {
      form.resetFields();
      setAuditTypeOptions([]);
    };
  }, [auditTypes]);

  const handleOk = () => {
    form.setFieldsValue({ division });
    form
      .validateFields()
      .then(values => {
        onOk(values);
        // history.push(`${match.url}/update/1`);
      })
      .then(() => {
        form.resetFields();
      })
      .catch(error => console.debug(error));
  };

  const handleCancel = () => {
    form.resetFields();
    onCancel();
  };

  return (
    <Modal visible={visible} onOk={handleOk} onCancel={handleCancel} title="체크리스트 추가">
      <Form labelCol={{ span: 6 }} wrapperCol={{ span: 14 }} layout="horizontal" form={form}>
        <Form.Item hidden name="division" initialValue={division} required>
          <div />
        </Form.Item>
        <Form.Item
          style={{ marginBottom: '20px' }}
          label="Audit Type"
          name="auditType"
          rules={[{ required: true, message: 'Audit Type을 입력하세요.' }]}
        >
          <Select options={auditTypeOptions} />
        </Form.Item>
        <Form.Item
          label="Checklist Title"
          name="listName"
          rules={[{ required: true, message: '체크리스트명을 입력하세요.' }]}
        >
          <Input />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default withRouter(CreateModal);
