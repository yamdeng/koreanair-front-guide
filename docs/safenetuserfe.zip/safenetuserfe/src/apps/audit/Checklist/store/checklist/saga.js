import { takeLatest, put, call } from 'redux-saga/effects';
import { defaultAxios } from 'utils/AxiosFunc';
import * as constants from './constants';
import { badRequest, notFound, serverError } from 'utils/errorCode';
import { message } from 'antd';

export function* getChecklists({ id }) {
  // const { data, status } = yield call(Axios.get, 'getUlr', { id });
  // yield put({ type: constants.SET_CHECKLISTS, checklists: checklists });
}

export function* getChecklist({ checklistId, isView = false, revision = 0 }) {
  const queryString = new URLSearchParams({ isView, revision });
  const { data: result, status } = yield call(defaultAxios.get, {
    // url: `/api/ke/audit/v1/checklist/${checklistId}?isView=${isView}&revision=${revision}`,
    url: `/api/ke/audit/v1/checklist/${checklistId}?${queryString.toString()}`,
  });
  if (status === 200) {
    yield put({
      type: constants.SET_CHECKLIST,
      checklist: result.data,
    });
    // yield put({ type: constants.SET_IS_LOADED, isLoaded: true });
  } else if (status === 400) {
    const apiResult = {
      type: 'error',
      data: badRequest,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 404) {
    const apiResult = {
      type: 'error',
      data: notFound,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 409) {
    const { nameKo, empNo } = result.details;
    message.error(`${nameKo} (${empNo})님이 현재 편집중입니다.`);
    const apiResult = {
      type: 'conflict',
      data: notFound,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else {
    const apiResult = {
      type: 'error',
      data: serverError,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  }
}

export function* postChecklist({ checklist }) {
  const { data: result, status } = yield call(defaultAxios.post, {
    url: '/api/ke/audit/v1/checklist',
    payload: checklist,
  });

  if (status === 200) {
    const apiResult = {
      type: 'postChecklist',
      data: result.id[0],
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
    message.success('체크리스트가 추가되었습니다.');
  } else if (status === 400) {
    const apiResult = {
      type: 'error',
      data: badRequest,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 404) {
    const apiResult = {
      type: 'error',
      data: notFound,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else {
    const apiResult = {
      type: 'error',
      data: serverError,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  }
}

export function* updateChecklist({ checklist }) {
  // yield call(axios.put, 'url', checklist);
}

export function* deleteChecklist({ checklist }) {
  const { data: result, status } = yield call(defaultAxios.delete, {
    url: `/api/ke/audit/v1/checklist/${checklist.checklistOriginId}`,
  });
  if (status === 200) {
    message.success('체크리스트가 삭제되었습니다.');
    const apiResult = {
      type: 'deleteChecklist',
      data: undefined,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
    // yield put({ type: constants.GET_CHECKLIST, id: data.results.checklistId });
  } else if (status === 400) {
    const apiResult = {
      type: 'error',
      data: badRequest,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 404) {
    const apiResult = {
      type: 'error',
      data: notFound,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else {
    const apiResult = {
      type: 'error',
      data: serverError,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  }
}

export function* postChapter({ chapter }) {
  const { data, status } = yield call(defaultAxios.post, {
    url: '/api/ke/audit/v1/chapter',
    payload: chapter,
  });

  if (status === 200) {
    message.success(`"${chapter.chapterName}" 이(가) 추가되었습니다.`);
    const apiResult = {
      type: 'postChapter',
      data: data.results,
    };
    yield put({ type: constants.GET_CHECKLIST, checklistId: data.results.checklistId, isView: false });
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
    // yield put({ type: constants.GET_CHECKLIST, id: data.results.checklistId });
  } else if (status === 400) {
    const apiResult = {
      type: 'error',
      data: badRequest,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 404) {
    const apiResult = {
      type: 'error',
      data: notFound,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else {
    const apiResult = {
      type: 'error',
      data: serverError,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  }
}

export function* updateChapter({ chapter }) {
  const { data, status } = yield call(defaultAxios.put, {
    url: `/api/ke/audit/v1/chapter/${chapter.chapterOriginId}`,
    payload: chapter,
  });
  if (status === 200) {
    message.success(`"${chapter.chapterName}" 이(가) 수정되었습니다.`);
    const apiResult = {
      type: 'putChapter',
      data: data.results,
    };
    yield put({ type: constants.GET_CHECKLIST, checklistId: data.results.checklistId, isView: false });
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 400) {
    const apiResult = {
      type: 'error',
      data: badRequest,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 404) {
    const apiResult = {
      type: 'error',
      data: notFound,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else {
    const apiResult = {
      type: 'error',
      data: serverError,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  }
}

export function* deleteChapter({ chapter }) {
  const { checklistOriginId, chapterOriginId, isRevisionUpdate, chapterName } = chapter;
  const queryString = !isRevisionUpdate ? '' : `?isRevisionUpdate=${isRevisionUpdate}`;
  const { data: result, status } = yield call(defaultAxios.delete, {
    url: `/api/ke/audit/v1/chapter/${checklistOriginId}/${chapterOriginId}${queryString}`,
  });
  if (status === 200) {
    message.success(`"${chapterName}" 이(가) 삭제되었습니다.`);
    const checklistOriginId = result.id[0];
    const apiResult = {
      type: 'deleteChapter',
      data: checklistOriginId,
    };
    yield put({ type: constants.GET_CHECKLIST, checklistId: checklistOriginId, isView: false });
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 400) {
    const apiResult = {
      type: 'error',
      data: badRequest,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 404) {
    const apiResult = {
      type: 'error',
      data: notFound,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else {
    const apiResult = {
      type: 'error',
      data: serverError,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  }

  // yield call(axios.delete, 'url', id);
}

export function* getQuestions({ id, revision = 0 }) {
  // yield call(axios.get, 'url', id);
  const { data: result, status } = yield call(defaultAxios.get, {
    url: `/api/ke/audit/v1/checklist/questions/${id}?revision=${revision}`,
  });
  if (status === 200) {
    // setQuestions(result.data);
    yield put({ type: constants.SET_QUESTIONS, questions: result.data });
  } else if (status === 400) {
    const apiResult = {
      type: 'error',
      data: badRequest,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 404) {
    const apiResult = {
      type: 'error',
      data: notFound,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else {
    const apiResult = {
      type: 'error',
      data: serverError,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  }

  // yield put({ type: constants.SET_QUESTIONS, questions: questions[`questions${id}`] ?? [] });
}

function* updateQuestions({ questions }) {
  const { data, status } = yield call(defaultAxios.post, {
    url: '/api/ke/audit/v1/questions',
    payload: questions,
  });
  if (status === 200) {
    message.success('체크리스트가 수정되었습니다.');
    const apiResult = {
      type: 'updateQuestions',
      data: data.results,
    };
    yield put({ type: constants.GET_QUESTIONS, id: data.results.chapterId });
    yield put({ type: constants.GET_CHECKLIST, checklistId: data.results.checklistId, isView: false });
    // yield put({ type: constants.SET_API_RESULT, result: apiResult });
    // setQuestions(result.data);
    // yield put({ type: constants.SET_QUESTIONS, questions: result.data });
  } else if (status === 400) {
    const apiResult = {
      type: 'error',
      data: badRequest,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else if (status === 404) {
    const apiResult = {
      type: 'error',
      data: notFound,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  } else {
    const apiResult = {
      type: 'error',
      data: serverError,
    };
    yield put({ type: constants.SET_API_RESULT, result: apiResult });
  }
}

export default function* checklistSaga() {
  yield takeLatest(constants.GET_CHECKLISTS, getChecklists);
  yield takeLatest(constants.GET_CHECKLIST, getChecklist);
  yield takeLatest(constants.POST_CHECKLIST, postChecklist);
  yield takeLatest(constants.UPDATE_CHECKLIST, updateChecklist);
  yield takeLatest(constants.DELETE_CHECKLIST, deleteChecklist);
  yield takeLatest(constants.UPDATE_CHAPTER, updateChapter);
  yield takeLatest(constants.DELETE_CHAPTER, deleteChapter);
  yield takeLatest(constants.GET_QUESTIONS, getQuestions);
  yield takeLatest(constants.POST_CHAPTER, postChapter);
  yield takeLatest(constants.UPDATE_QUESTIONS, updateQuestions);
}
