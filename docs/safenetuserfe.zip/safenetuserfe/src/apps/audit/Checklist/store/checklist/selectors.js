import { createSelector } from 'reselect';

const selectChecklistStore = state => state.get('checklist');
const selectAuth = state => state.get('auth');

export const selectIsLoading = () => createSelector(selectChecklistStore, state => state.get('isLoading'));
export const selectChecklists = () => createSelector(selectChecklistStore, state => state.get('checklists').toJS());
export const selectChecklist = () => createSelector(selectChecklistStore, state => state.get('checklist').toJS());
export const selectQuestions = () => createSelector(selectChecklistStore, state => state.get('questions').toJS());
export const selectApiResult = () => createSelector(selectChecklistStore, state => state.get('apiResult').toJS());
export const selectIsLoaded = () => createSelector(selectChecklistStore, state => state.get('isLoaded'));
export const selectProfile = () => createSelector(selectAuth, state => state.get('profile'));
