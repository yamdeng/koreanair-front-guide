const PATH = 'app/checklist';

export const SET_IS_LOADING = `${PATH}/SET_IS_LOADING`;

// 체크리스트 목록 조회(체크리스트, 챕터)
export const GET_CHECKLISTS = `${PATH}/GET_CHECKLISTS`;
export const SET_CHECKLISTS = `${PATH}/SET_CHECKLISTS`;

// 체크리스트 조회(체크리스트, 챕터)
export const GET_CHECKLIST = `${PATH}/GET_CHECKLIST`;
export const SET_CHECKLIST = `${PATH}/SET_CHECKLIST`;
export const RESET_CHECKLIST = `${PATH}/RESET_CHECKLIST`;

export const SET_TITLE = `${PATH}/SET_TITLE`;

// 체크리스트 추가, 수정, 삭제
export const POST_CHECKLIST = `${PATH}/POST_CHECKLIST`;
export const UPDATE_CHECKLIST = `${PATH}/UPDATE_CHECKLIST`;
export const DELETE_CHECKLIST = `${PATH}/DELETE_CHECKLIST`;

// 챕터 명 수정, 챕터 삭제
export const POST_CHAPTER = `${PATH}/POST_CHAPTER`;
export const UPDATE_CHAPTER = `${PATH}/UPDATE_CHAPTER`;
export const DELETE_CHAPTER = `${PATH}/DELETE_CHAPTER`;

// 챕터 id로 해당 챕터 문항 조회
export const GET_QUESTIONS = `${PATH}/GET_QUESTIONS`;
export const SET_QUESTIONS = `${PATH}/SET_QUESTIONS`;

export const RESET_QUESTIONS = `${PATH}/RESET_QUESTIONS`;

export const SET_API_RESULT = `${PATH}/SET_API_RESULT`;
export const RESET_API_RESULT = `${PATH}/RESET_API_RESULT`;

// 문항 추가/수정/삭제
export const UPDATE_QUESTIONS = `${PATH}/UPDATE_QUESTIONS`;

export const SET_IS_LOADED = `${PATH}/SET_IS_LOADED`;
