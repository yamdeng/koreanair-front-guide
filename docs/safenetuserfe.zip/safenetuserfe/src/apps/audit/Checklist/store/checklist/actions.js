import * as constants from './constants';

export const setIsLoading = isLoading => ({
  type: constants.SET_IS_LOADING,
  isLoading,
});

export const getChecklists = () => ({
  type: constants.GET_CHECKLISTS,
});

export const setChecklists = checklists => ({
  type: constants.SET_CHECKLISTS,
  checklists,
});

export const getChecklist = (checklistId, isView, revision) => ({
  type: constants.GET_CHECKLIST,
  checklistId,
  isView,
  revision,
});

export const setChecklist = checklist => ({
  type: constants.SET_CHECKLIST,
  checklist,
});

export const resetChecklist = () => ({
  type: constants.RESET_CHECKLIST,
});

export const setTitle = title => ({
  type: constants.SET_TITLE,
  title,
});

export const postChecklist = checklist => ({
  type: constants.POST_CHECKLIST,
  checklist,
});

export const updateChecklist = checklist => ({
  type: constants.UPDATE_CHECKLIST,
  checklist,
});

export const deleteChecklist = checklist => ({
  type: constants.DELETE_CHECKLIST,
  checklist,
});

export const postChapter = chapter => ({
  type: constants.POST_CHAPTER,
  // { id: number, title: string }
  chapter,
});

export const updateChapter = chapter => ({
  type: constants.UPDATE_CHAPTER,
  // { id: number, title: string }
  chapter,
});

export const deleteChapter = chapter => ({
  type: constants.DELETE_CHAPTER,
  chapter,
});

export const getQuestions = (chapterId, revision = 0) => ({
  type: constants.GET_QUESTIONS,
  id: chapterId,
  revision,
});

export const setQuestions = questions => ({
  type: constants.SET_QUESTIONS,
  questions,
});

export const resetQuestions = () => ({
  type: constants.RESET_QUESTIONS,
});

export const setApiResult = result => ({
  type: constants.SET_API_RESULT,
  result,
});

export const resetApiResult = () => ({
  type: constants.RESET_API_RESULT,
});

export const updateQuestions = questions => ({
  type: constants.UPDATE_QUESTIONS,
  questions,
});

export const setIsLoaded = isLoaded => ({
  type: constants.SET_IS_LOADED,
  isLoaded,
});
