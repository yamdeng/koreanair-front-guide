import * as constants from './constants';
import { List, fromJS } from 'immutable';

const apiResult = fromJS({
  type: '',
  data: '',
});

const initialState = fromJS({
  isLoading: false,
  checklists: [],
  checklist: {
    title: 'Checklist',
    chapters: [
      // {
      //   id: '-1',
      //   title: 'Sub Chapter 1',
      // },
    ],
  },
  // chapters:
  questions: [],
  isLoaded: false,
  apiResult,
});

const checklistReducer = (state = initialState, action) => {
  switch (action.type) {
    case constants.SET_IS_LOADING:
      return state.set('isLoading', action.isLoading);
    case constants.SET_CHECKLISTS:
      return state.set('checklists', fromJS(action.checklists));
    case constants.SET_CHECKLIST:
      return state.set('checklist', fromJS(action.checklist));
    case constants.RESET_CHECKLIST:
      return state
        .set(
          'checklist',
          fromJS({
            title: 'Checklist',
            chapters: [],
          }),
        )
        .set('questions', List());
    case constants.SET_TITLE:
      return state.setIn(['checklist', 'title'], action.title);
    case constants.SET_QUESTIONS:
      return state.set('questions', fromJS(action.questions));
    case constants.RESET_QUESTIONS:
      return state.set('questions', List());
    case constants.SET_API_RESULT:
      return state.set('apiResult', fromJS(action.result));
    case constants.RESET_API_RESULT:
      return state.set('apiResult', apiResult);
    case constants.SET_IS_LOADED:
      return state.set('isLoaded', action.isLoaded);
    default:
      return state;
  }
};

export default checklistReducer;
