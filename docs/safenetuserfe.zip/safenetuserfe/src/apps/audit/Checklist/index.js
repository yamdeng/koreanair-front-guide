import React from 'react';
import { Switch, Route } from 'react-router-dom';
import { createStructuredSelector } from 'reselect';

import Create from './create';
import List from './list';
import View from './view';
import { WithStateManagement } from 'utils/stateUtils';
import reducer from './store/checklist/reducer';
import saga from './store/checklist/saga';

const Checklist = ({ match }) => {
  const ROOT_URL = `${match.url}/audit/Checklist`;

  return (
    <Switch>
      <Route path={ROOT_URL} exact component={List} />
      <Route path={`${ROOT_URL}/update/:id`} exact component={Create} />
      <Route path={`${ROOT_URL}/view/:id`} exact component={View} />
    </Switch>
  );
};

const mapStateToProps = createStructuredSelector({});

const mapDispatchToProps = dispatch => ({});

// export default withRouter(Checklist);
export default WithStateManagement(Checklist, {
  mapStateToProps,
  mapDispatchToProps,
  key: 'checklist',
  reducer,
  saga,
  useRouter: true,
});
