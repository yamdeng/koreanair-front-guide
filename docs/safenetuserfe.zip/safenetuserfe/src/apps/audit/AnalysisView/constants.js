export const columnInfo = {
  QAS: [
    {
      key: 'audit',
      title: 'Audit',
      sort: 0,
      totalAvg: 'total',
    },
    {
      key: 'car',
      title: '# CAR',
      sort: 1,
      totalAvg: 'total',
    },
    {
      key: 'carDivAudit',
      title: '# CAR / Audit',
      sort: 2,
      totalAvg: 'avg',
    },
  ],
  QARD: [
    {
      key: 'audit',
      title: 'Audit',
      sort: 0,
      totalAvg: 'total',
    },
    {
      key: 'car',
      title: '# CAR',
      sort: 1,
      totalAvg: 'total',
    },
    {
      key: 'closedCar',
      title: '# Closed Car',
      sort: 2,
      totalAvg: 'total',
    },
    {
      key: 'closedRate',
      title: 'Closed Rate',
      sort: 3,
      totalAvg: 'avg',
    },
    {
      key: 'carDivAudit',
      title: '# CAR / Audit',
      sort: 4,
      totalAvg: 'avg',
    },
    {
      key: 'hfacs',
      title: '# HFACS',
      sort: 5,
      totalAvg: 'total',
    },
    {
      key: 'hfacsDivCar',
      title: '# HFACS / CAR',
      sort: 6,
      totalAvg: 'avg',
    },
  ],
  CFA: [
    {
      key: 'count',
      title: 'Count',
      sort: 0,
      totalAvg: 'total',
    },
    {
      key: 'countRatio',
      title: 'Count Ratio',
      sort: 1,
      totalAvg: 'total',
    },
  ],
};
