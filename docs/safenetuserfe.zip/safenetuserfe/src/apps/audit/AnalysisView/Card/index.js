import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import Loadable from 'components/Loadable';

import { columnInfo } from '../constants';

const Card = ({ type, ...props }) => {
  const CardBody = useMemo(() => Loadable({ loader: () => import(`./CardBody/${type}`) }), [type]);

  return (
    <section className="analysis-item" style={{ height: '100%' }}>
      <CardBody columnInfo={columnInfo[type]} {...props} />
    </section>
  );
};

Card.propTypes = {
  type: PropTypes.oneOf(['QAS', 'QARD', 'ACFD', 'CFA']).isRequired,
};

export default Card;
