import React from 'react';
import PropTypes from 'prop-types';

import { Spin } from 'antd';
import StyledTableAnalysis from 'style/styledTableAnalysis';
import StyledTable from './StyledTable';

import { renderNumber, sortArray } from '../../utils';

const QualityAuditQuarter = ({ data, columnInfo, rowHeadInfo, loading }) => {
  // Sort columns' information.
  const columns = columnInfo?.sort((a, b) => sortArray(a.sort, b.sort)) ?? [];

  // Get actual rows removing total and avg.
  const actualRowHeads = rowHeadInfo.sort((a, b) => sortArray(a.sort, b.sort));
  for (let i = 0; i < actualRowHeads.length; i += 1) {
    if (['total', 'avg'].indexOf(actualRowHeads[i].key) > -1) {
      actualRowHeads.splice(i, 1);
      i -= 1;
    }
  }

  const auditSum = data.audit ? Object.values(data.audit).reduce((sum, value) => +(sum + value).toFixed(1), 0) : 0;
  const carSum = data.car ? Object.values(data.car).reduce((sum, value) => +(sum + value).toFixed(1), 0) : 0;
  const closedCarSum = data.closedCar
    ? Object.values(data.closedCar).reduce((sum, value) => +(sum + value).toFixed(1), 0)
    : 0;
  const closedRateAvg = carSum === 0 ? closedCarSum * 100 : (closedCarSum / carSum) * 100;
  const carDivAuditAvg = auditSum === 0 ? auditSum : carSum / auditSum;
  const hfacsSum = data.car ? Object.values(data.hfacs).reduce((sum, value) => +(sum + value).toFixed(1), 0) : 0;
  const hfacsDivCarAvg = carSum === 0 ? hfacsSum : hfacsSum / carSum;

  return (
    <main>
      <h3>Quality Audit Result Detail</h3>

      <Spin spinning={loading}>
        <StyledTableAnalysis>
          <StyledTable className="q4">
            <colgroup>
              <col style={{ width: '23%' }} />
              {columns.map(column => (
                <col key={column.key} style={{ width: '11%' }} />
              ))}
            </colgroup>

            <thead>
              <tr>
                <th scope="col">Division</th>
                {columns.map(column => (
                  <th key={column.key} scope="col">
                    {column.title}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {actualRowHeads.map(rowHead => {
                const { key: rowKey, title: rowTitle } = rowHead;
                return (
                  <tr key={rowKey}>
                    <th scope="row">{rowTitle}</th>
                    {columns.map(column => {
                      const { key: colKey } = column;
                      const item = data[colKey] ?? {};
                      return <td key={colKey}>{renderNumber(item[rowKey] ?? 0, colKey)}</td>;
                    })}
                  </tr>
                );
              })}
              <tr>
                <th scope="row">Total/Average</th>
                {columns.map(column => {
                  const { key } = column;
                  let result = 0;
                  switch (key) {
                    case 'audit':
                      result = auditSum;
                      break;
                    case 'car':
                      result = carSum;
                      break;
                    case 'closedCar':
                      result = closedCarSum;
                      break;
                    case 'closedRate':
                      result = closedRateAvg;
                      break;
                    case 'carDivAudit':
                      result = carDivAuditAvg;
                      break;
                    case 'hfacs':
                      result = hfacsSum;
                      break;
                    case 'hfacsDivCar':
                      result = hfacsDivCarAvg;
                      break;
                    default:
                      break;
                  }
                  return <td key={key}>{renderNumber(result ?? 0, key)}</td>;
                })}
              </tr>
            </tbody>
          </StyledTable>
        </StyledTableAnalysis>
      </Spin>
    </main>
  );
};

QualityAuditQuarter.propTypes = {
  selected: PropTypes.any,
  data: PropTypes.object,
  columnInfo: PropTypes.arrayOf(PropTypes.object),
  rowHeadInfo: PropTypes.arrayOf(PropTypes.object),
  loading: PropTypes.bool,
};

QualityAuditQuarter.defaultProps = {
  selected: null,
  data: {},
  columnInfo: [],
  rowHeadInfo: [],
  loading: false,
};

export default QualityAuditQuarter;
