import React from 'react';
import PropTypes from 'prop-types';
import { Chart as ChartJS, RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend } from 'chart.js';
import { Radar } from 'react-chartjs-2';

ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

export const defaultDataset = {
  label: '', // string
  data: [], // number[]
  backgroundColor: 'rgba(255, 99, 132, 0.2)', // string
  borderColor: 'rgba(255, 99, 132, 1)', // string
  borderWidth: 1, // number
};

export const defaultData = {
  labels: [], // string[]
  datasets: [], // dataset[]
};

const options = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false,
    },
  },
  scale: {
    ticks: {
      beginAtZero: true,
      precision: 0,
      maxTicksLimit: 11,
    },
  },
};

const RadarChart = ({ labels, datasets, width, height }) => {
  return (
    <Radar
      options={options}
      data={{
        labels,
        datasets,
      }}
      width={width}
      height={height}
    />
  );
};

RadarChart.propTypes = {
  labels: PropTypes.arrayOf(PropTypes.string),
  datasets: PropTypes.arrayOf(PropTypes.object),
  width: PropTypes.number,
  height: PropTypes.number,
};

RadarChart.defaultProps = {
  labels: [],
  datasets: [],
  width: 300,
  height: 300,
};

export default RadarChart;
