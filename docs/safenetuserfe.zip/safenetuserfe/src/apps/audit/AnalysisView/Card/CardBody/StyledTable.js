import styled from 'styled-components';

const StyledTable = styled.table`
  table-layout: fixed;
  height: 300px;

  thead tr th {
    padding: 4px 0 !important;
    white-space: normal !important;
    line-height: 120%;
  }

  thead tr:first-child th:first-child {
    height: 50px;
  }

  tbody tr th,
  tbody tr td {
    height: 32px;
    padding: 0 8px !important;
    line-height: 120%;
  }
`;

export default StyledTable;
