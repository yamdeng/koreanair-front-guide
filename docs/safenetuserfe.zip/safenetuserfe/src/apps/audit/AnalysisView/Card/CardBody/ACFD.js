import React from 'react';
import PropTypes from 'prop-types';

import Styled from 'styled-components';

import { Spin, Row, Col } from 'antd';
import Bar, { bgColors, defaultDataset } from '../ChartView/BarChart';

import capitalize from 'lodash/capitalize';
import { intlObj } from 'utils/commonUtils';

const StyledACFD = Styled(Row)`
  canvas {
    height: 340px !important;
  }
`;

const AnalysisCausalFactorDepartment = ({ data, labels, rowHeadInfo, loading }) => {
  const intlLabels = labels?.map(item => intlObj.formatDynamic(item, 'name'));
  const sortingBaseArray = labels?.map(item => item.codeValue);
  const locale = intlObj.locale;

  // Generate dataset for chart.
  const dsGroup = {};
  data.forEach(item => {
    const year = Object.keys(item)[0];
    const datasets = [];
    rowHeadInfo.forEach((rowHead, rowIndex) => {
      const rowTitle = intlObj.formatDynamic(rowHead, 'level1');
      const rowKey = `rootCauseName${capitalize(locale)}`;
      const chartData = Object.keys(item[year])
        .sort((a, b) => sortingBaseArray.indexOf(a) - sortingBaseArray.indexOf(b))
        .map(division => {
          const divData = item[year][division] ?? [];
          const index = divData.findIndex(data => data[rowKey] === rowTitle);
          if (index < 0) {
            return 0;
          }

          return divData[index].rootCauseCount ?? 0;
        });

      const dataset = {
        ...defaultDataset,
        label: rowTitle,
        data: chartData,
        backgroundColor: bgColors[rowIndex % bgColors.length],
      };

      datasets.push(dataset);
    });

    dsGroup[year] = datasets;
  });

  return (
    <main>
      <h3>Analysis on Causal Factors per Division</h3>

      <Spin spinning={loading}>
        <StyledACFD gutter={20}>
          {data.map(item => {
            const year = Object.keys(item)[0];

            return (
              <Col key={year} span={12}>
                <Bar labels={intlLabels} datasets={dsGroup[year] ?? []} title={year} />
              </Col>
            );
          })}
        </StyledACFD>
      </Spin>
    </main>
  );
};

AnalysisCausalFactorDepartment.propTypes = {
  selected: PropTypes.any,
  data: PropTypes.arrayOf(PropTypes.object),
  columnInfo: PropTypes.arrayOf(PropTypes.object),
  rowHeadInfo: PropTypes.arrayOf(PropTypes.object),
  loading: PropTypes.bool,
};

AnalysisCausalFactorDepartment.defaultProps = {
  selected: null,
  data: [],
  columnInfo: [],
  rowHeadInfo: [],
  loading: false,
};

export default AnalysisCausalFactorDepartment;
