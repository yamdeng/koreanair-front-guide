import React from 'react';
import PropTypes from 'prop-types';

import { Spin } from 'antd';
import StyledTableAnalysis from 'style/styledTableAnalysis';
import StyledTable from './StyledTable';

import { sortArray, renderNumber } from '../../utils';

const QualityAuditYear = ({ data, columnInfo, rowHeadInfo, loading }) => {
  // Extract and sort data keys.
  const colKeys = {};
  columnInfo
    ?.sort((a, b) => sortArray(a.sort, b.sort))
    .forEach(column => {
      const colKey = column.key;
      colKeys[colKey] = data[colKey] ? Object.keys(data[colKey]).sort((a, b) => sortArray(a, b, true)) : [];
    });

  const auditSum = colKeys.audit.map(
    key => Object.values(data.audit[key]).reduce((sum, value) => +(sum + value), 0) ?? 0,
  );

  const carSum = colKeys.car.map(key => Object.values(data.car[key]).reduce((sum, value) => +(sum + value), 0) ?? 0);

  const carDivAudit = colKeys.carDivAudit.map((_key, index) => {
    if (auditSum[index] === 0) {
      return carSum[index];
    }

    return carSum[index] / auditSum[index];
  });

  return (
    <main>
      <h3>Quality Audit Status</h3>

      <Spin spinning={loading}>
        <StyledTableAnalysis>
          <StyledTable>
            <colgroup>
              <col style={{ width: '28%' }} />
              {Object.keys(colKeys).map(colKey => (
                <React.Fragment key={colKey}>
                  {colKeys[colKey].map(key => (
                    <col key={`${colKey}-${key}`} style={{ width: '8%' }} />
                  ))}
                </React.Fragment>
              ))}
            </colgroup>

            <thead>
              <tr>
                <th scope="col" rowSpan={2}>
                  Division
                </th>
                {columnInfo.map(column => (
                  <th key={column.key} scope="col" colSpan={colKeys[column.key].length}>
                    {column.title}
                  </th>
                ))}
              </tr>
              <tr>
                {Object.keys(colKeys).map(colKey => (
                  <React.Fragment key={colKey}>
                    {colKeys[colKey].map(key => (
                      <th key={`${colKey}-${key}`} scope="col">
                        {key.toLowerCase() === 'yoy' ? 'YoY' : key}
                      </th>
                    ))}
                  </React.Fragment>
                ))}
              </tr>
            </thead>

            <tbody>
              {rowHeadInfo.map(rowHead => {
                const { key: rowKey, title: rowTitle } = rowHead;
                if (['total', 'avg'].indexOf(rowKey.toLowerCase()) > -1) {
                  return null;
                }
                return (
                  <tr key={rowKey}>
                    <th scope="row">{rowTitle}</th>
                    {Object.keys(colKeys).map(colKey => (
                      <React.Fragment key={colKey}>
                        {colKeys[colKey].map(key => {
                          const itemGroup = data[colKey] ?? {};
                          const item = itemGroup[key] ?? {};
                          let value = item[rowKey] ?? 0;
                          if (colKey === 'carDivAudit') {
                            value = value.toFixed(1);
                          }
                          return <td key={`${colKey}-${key}`}>{renderNumber(value, key)}</td>;
                        })}
                      </React.Fragment>
                    ))}
                  </tr>
                );
              })}

              <tr>
                <th scope="row">Total/Average</th>
                {Object.keys(colKeys).map(colKey => (
                  <React.Fragment key={colKey}>
                    {colKeys[colKey].map((key, index) => {
                      let value = 0;
                      switch (colKey) {
                        case 'audit':
                          value = auditSum[index];
                          break;
                        case 'car':
                          value = carSum[index];
                          break;
                        case 'carDivAudit':
                          value = carDivAudit[index].toFixed(1);
                          break;
                        default:
                          value = 0;
                          break;
                      }
                      return <td key={`${colKey}-${key}`}>{renderNumber(value, key)}</td>;
                    })}
                  </React.Fragment>
                ))}
              </tr>
            </tbody>
          </StyledTable>
        </StyledTableAnalysis>
      </Spin>
    </main>
  );
};

QualityAuditYear.propTypes = {
  selected: PropTypes.any,
  data: PropTypes.object,
  columnInfo: PropTypes.arrayOf(PropTypes.object),
  rowHeadInfo: PropTypes.arrayOf(PropTypes.object),
  loading: PropTypes.bool,
};

QualityAuditYear.defaultProps = {
  selected: null,
  data: {},
  columnInfo: [],
  rowHeadInfo: [],
  loading: false,
};

export default QualityAuditYear;
