import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar } from 'react-chartjs-2';
import ChartDataLabels from 'chartjs-plugin-datalabels';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ChartDataLabels);

export const bgColors = ['#2085c5', '#ff9715', '#f20253', '#a0d911', '#7ecefd', '#677480'];

export const defaultDataset = {
  label: '', // string
  data: [], // number[]
  backgroundColor: bgColors[0],
  stack: 'bar',
};

const BarChart = ({ labels, datasets, width, height, title }) => {
  const options = useMemo(
    () => ({
      plugins: {
        datalabels: {
          color: '#ffffff',
          display: context => context.dataset.data[context.dataIndex] > 0,
          formatter: function(value, context) {
            if (context.chart.data.datasets[context.datasetIndex]) {
              const barTotal = context.chart.data.datasets
                .map(x => x.data[context.dataIndex])
                .reduce((a, b) => a + b, 0);
              return `${((value * 100) / barTotal).toFixed(1)}%`;
            }
          },
          font: {
            size: '10px',
            weight: '300',
          },
          align: 'center',
          anchor: 'center',
        },
        legend: {
          position: 'bottom',
          align: 'center',
          labels: {
            usePointStyle: true,
            pointStyle: 'rect',
          },
        },
      },
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        mode: 'index',
        intersect: false,
      },
      scales: {
        x: {
          stacked: true,
        },
        y: {
          stacked: true,
          title: {
            display: true,
            text: title,
            font: {
              size: 16,
            },
          },
          ticks: {
            precision: 0,
            maxTicksLimit: 11,
          },
        },
      },
    }),
    [title],
  );

  return <Bar options={options} data={{ labels, datasets }} width={width} height={height} />;
};

BarChart.propTypes = {
  labels: PropTypes.arrayOf(PropTypes.string),
  datasets: PropTypes.arrayOf(PropTypes.object),
  width: PropTypes.number,
  height: PropTypes.number,
};

BarChart.defaultProps = {
  labels: [],
  datasets: [],
  width: 300,
  height: 300,
};

export default BarChart;
