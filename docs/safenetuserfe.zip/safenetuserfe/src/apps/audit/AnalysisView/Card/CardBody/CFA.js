import React, { useMemo } from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';

import { Spin, Row, Col, TreeSelect, Button } from 'antd';
import { ReloadOutlined } from '@ant-design/icons';
import StyledTableAnalysis from 'style/styledTableAnalysis';
import StyledTable from './StyledTable';
import Radar, { defaultDataset } from '../ChartView/RadarChart';

import { intlObj, keMapper } from 'utils/commonUtils';
import { renderNumber, sortArray } from '../../utils';

const StyledHeader = styled.section`
  display: flex;
  align-items: center;

  .ant-select-selector {
    font-size: 13px;
  }

  .ant-select-multiple .ant-select-selection-item {
    min-width: 0;
  }

  .btn-reload {
    color: #213184;
  }
`;

const StyledBody = styled.section`
  .ant-row {
    align-items: center;
  }

  canvas {
    height: 360px;
  }
`;

const CausalFactorAnalysis = ({ data, columnInfo, rowHeadInfo, loading, value, options, onSelectChange, onReload }) => {
  const labelIntl = useMemo(() => `name${keMapper[intlObj.locale]}`, []);

  // Sort columns' information.
  const columns = columnInfo?.sort((a, b) => sortArray(a.sort, b.sort)) ?? [];

  // Generate dataset for chart.
  const datasets = [
    {
      ...defaultDataset,
      label: 'Causal Factor Analysis',
      data: rowHeadInfo.map(key => {
        const dataGroup = data?.count ?? {};

        return dataGroup[key] ?? 0;
      }),
    },
  ];

  return (
    <main>
      <StyledHeader>
        <h3>Causal Factor Analysis</h3>
        <TreeSelect
          placeholder="Select Division"
          fieldNames={{ label: labelIntl }}
          treeData={options}
          value={value}
          onChange={onSelectChange}
          showCheckedStrategy={TreeSelect.SHOW_PARENT}
          maxTagCount={1}
          treeDefaultExpandAll
          treeCheckable
          style={{ maxWidth: '100%', width: 240 }}
          size="small"
        />
        <Button type="text" className="btn-reload" onClick={onReload}>
          <ReloadOutlined />
        </Button>
      </StyledHeader>
      <StyledBody>
        <Spin spinning={loading}>
          <Row gutter={20}>
            <Col span={12}>
              <Radar labels={rowHeadInfo} datasets={datasets} />
            </Col>
            <Col span={12}>
              <StyledTableAnalysis>
                <StyledTable className="q4">
                  <colgroup>
                    <col style={{ width: '50%' }} />
                    {columns.map(column => (
                      <col key={column.key} style={{ width: '25%' }} />
                    ))}
                  </colgroup>

                  <thead>
                    <tr>
                      <th scope="col">Causal Factor</th>
                      {columns.map(column => (
                        <th key={column.key} scope="col">
                          {column.title}
                        </th>
                      ))}
                    </tr>
                  </thead>

                  <tbody>
                    {rowHeadInfo.map(rowHead => {
                      return (
                        <tr key={rowHead}>
                          <th scope="row">{rowHead}</th>
                          {columns.map(column => {
                            const { key: colKey } = column;
                            const item = data[colKey] ?? {};
                            return <td key={colKey}>{renderNumber(item[rowHead] ?? 0, colKey)}</td>;
                          })}
                        </tr>
                      );
                    })}
                    <tr>
                      <th scope="row">TTL</th>
                      {columns.map(column => {
                        const { key } = column;
                        const item = data[key];
                        if (item) {
                          const sum = Object.values(item).reduce((sum, value) => +(sum + value).toFixed(1), 0);
                          let label = sum;
                          if (key === 'countRatio') {
                            label = `${parseInt(Math.round(sum) ?? 0)}%`;
                          }
                          return <td key={key}>{label}</td>;
                        }
                        return <td key={key}>{renderNumber(0, key)}</td>;
                      })}
                    </tr>
                  </tbody>
                </StyledTable>
              </StyledTableAnalysis>
            </Col>
          </Row>
        </Spin>
      </StyledBody>
    </main>
  );
};

CausalFactorAnalysis.propTypes = {
  selected: PropTypes.any,
  data: PropTypes.object,
  columnInfo: PropTypes.arrayOf(PropTypes.object),
  rowHeadInfo: PropTypes.arrayOf(PropTypes.string),
  loading: PropTypes.bool,
};

CausalFactorAnalysis.defaultProps = {
  selected: null,
  data: {},
  columnInfo: [],
  rowHeadInfo: [],
  loading: false,
};

export default CausalFactorAnalysis;
