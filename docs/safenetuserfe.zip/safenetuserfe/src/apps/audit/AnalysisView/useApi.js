import { useState, useCallback } from 'react';

import { defaultAxios } from 'utils/AxiosFunc';
import { parsingQas, parsingQard, parsingCfa } from './utils';

const validateValue = value => {
  let isValid = true;

  if (!Array.isArray(value)) {
    isValid = false;
  }

  if (Array.isArray(value) && value.length < 1) {
    isValid = false;
  }

  if (Array.isArray(value) && value.length === 1 && value[0] === 'all') {
    isValid = false;
  }

  return isValid;
};

const useApi = () => {
  const [qas, setQas] = useState();
  const [isQasLoad, setIsQasLoad] = useState(false);

  const [qard, setQard] = useState();
  const [isQardLoad, setIsQardLoad] = useState(false);

  const [acfd, setAcfd] = useState();
  const [isAcfdLoad, setIsAcfdLoad] = useState(false);

  const [cfa, setCfa] = useState();
  const [isCfaLoad, setIsCfaLoad] = useState(false);

  const makePayload = ({ dateRange, division, setDivision, options }) => {
    const [startDate, endDate] = dateRange;
    const payload = {
      startDate: startDate.format('YYYYMMDD'),
      endDate: endDate.format('YYYYMMDD'),
    };

    if (division) {
      if (validateValue(division)) {
        payload.divisions = division;
      } else {
        payload.divisions = options[0].children.map(option => option.value);
        setDivision(['all']);
      }
    }

    return payload;
  };

  const getQas = useCallback(payload => {
    setIsQasLoad(false);
    defaultAxios
      .get({
        url: '/api/ke/audit/v1/analysis/qas',
        payload: makePayload(payload),
      })
      .then(({ data: response, status }) => {
        if (status === 200) {
          const year = payload.dateRange[0].year();
          setQas(parsingQas(response.data, year));
        }
      })
      .finally(() => {
        setIsQasLoad(true);
      });
  }, []);

  const getQard = useCallback(payload => {
    setIsQardLoad(false);
    defaultAxios
      .get({ url: '/api/ke/audit/v1/analysis/qard', payload: makePayload(payload) })
      .then(({ data: response, status }) => {
        if (status === 200) {
          setQard(parsingQard(response.data));
        }
      })
      .finally(() => {
        setIsQardLoad(true);
      });
  }, []);

  const getAcfd = useCallback(payload => {
    setIsAcfdLoad(false);
    defaultAxios
      .get({ url: '/api/ke/audit/v1/analysis/acfd', payload: makePayload(payload) })
      .then(({ data: response, status }) => {
        if (status === 200) {
          setAcfd(response.data);
        }
      })
      .finally(() => {
        setIsAcfdLoad(true);
      });
  }, []);

  const getCfa = useCallback(payload => {
    setIsCfaLoad(false);
    defaultAxios
      .get({ url: '/api/ke/audit/v1/analysis/cfa', payload: makePayload(payload) })
      .then(({ data: response, status }) => {
        if (status === 200) {
          setCfa(parsingCfa(response.data));
        }
      })
      .finally(() => {
        setIsCfaLoad(true);
      });
  });

  return [qas, getQas, isQasLoad, qard, getQard, isQardLoad, acfd, getAcfd, isAcfdLoad, cfa, getCfa, isCfaLoad];
};

export default useApi;
