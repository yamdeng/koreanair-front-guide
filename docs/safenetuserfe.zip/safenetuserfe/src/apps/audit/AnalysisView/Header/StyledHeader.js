import styled from 'styled-components';

const StyledHeader = styled.section`
  &.analysis-item {
    padding: 24px 40px;

    .search {
      &-container {
        display: flex;
        justify-content: flex-start;
        align-itmes: flex-end;
        margin: 0px -10px;
        flex-wrap: wrap;
      }

      &-input {
        padding: 4px 10px;

        .ant-picker-panels {
          & > *:first-child button.ant-picker-header-next-btn {
            visibility: visible !important;
          }

          & > *:first-child button.ant-picker-header-super-next-btn {
            visibility: visible !important;
          }

          & > *:last-child {
            display: none;
          }

          .ant-picker-month-panel {
            width: 254px;
          }

          .ant-picker-panel-container,
          .ant-picker-footer {
            width: 280px !important;
          }

          .ant-picker-footer-extra > div {
            flex-wrap: wrap !important;
          }
        }
      }

      &-button {
        padding: 4px 10px;
      }
    }
  }
`;

export default StyledHeader;
