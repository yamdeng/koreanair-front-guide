import React, { useState } from 'react';

import { DatePicker, Button } from 'antd';
import { SearchOutlined } from '@ant-design/icons';
const { RangePicker } = DatePicker;

import StyledHeader from './StyledHeader';

function Header({ dateRange, setDateRange, onSeearch }) {
  const [dates, setDates] = useState();
  const [tempDates, setTempDates] = useState();

  const disabledDate = current => {
    if (!dates) {
      return false;
    }

    const [start, end] = dates;
    const tooLate = start && start.year() !== current.year();
    const tooEarly = end && end.year() !== current.year();
    return !!tooEarly || !!tooLate;
  };

  const onOpenChange = open => {
    if (open) {
      setTempDates([null, null]);
      setDates([null, null]);
    } else {
      setTempDates();
    }
  };

  return (
    <StyledHeader className="analysis-item" style={{ padding: '24px 40px' }}>
      <div className="search-container">
        <div className="search-input">
          <RangePicker
            picker="month"
            value={tempDates || dateRange}
            disabledDate={disabledDate}
            onCalendarChange={value => setDates(value)}
            onChange={value => {
              const [start, end] = value;
              setDateRange([start.startOf('month'), end.endOf('month')]);
            }}
            onOpenChange={onOpenChange}
          />
        </div>
        <div className="search-button">
          <Button type="primary" icon={<SearchOutlined />} onClick={onSeearch}>
            Search
          </Button>
        </div>
      </div>
    </StyledHeader>
  );
}

export default Header;
