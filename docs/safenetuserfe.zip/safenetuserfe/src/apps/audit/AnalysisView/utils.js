/**
 * Local utils for Audit AnalysisView
 */

import React from 'react';

import capitalize from 'lodash/capitalize';
import { intlObj } from 'utils/commonUtils';

export const getRandomNN = max => {
  return Math.round(Math.random() * max);
};

export const num = string => {
  let result = Number(string);

  if (Number.isNaN(result)) {
    result = 0;
  }

  return result;
};

export const sortArray = (a, b, isDesc) => {
  if (isDesc) {
    return num(b) - num(a);
  }
  return num(a) - num(b);
};

// Renderers.
export const renderNumber = (value = 0, type = '') => {
  // YoY
  if (type.toLowerCase() === 'yoy') {
    let color = 'inherit';
    if (value > 0) {
      color = '#118fe4';
    } else if (value < 0) {
      color = '#ff6384';
    }

    return <span style={{ color }}>{value}</span>;
  }

  // Closed Rate
  if (['closedRate', 'countRatio'].indexOf(type) > -1) {
    return `${value.toFixed(1)}%`;
  }

  // # CAR / Audit
  if (['carDivAudit', 'hfacsDivCar'].indexOf(type) > -1) {
    if (typeof value) {
    }
    return value.toFixed(1);
  }

  // Default
  return value;
};

export const parsingQas = (data, year) => {
  const curr = year;
  const prev = year - 1;

  const rowHeadInfo = [];

  const parsed = {
    audit: { [curr]: {}, [prev]: {}, yoy: {} },
    car: { [curr]: {}, [prev]: {}, yoy: {} },
    carDivAudit: { [curr]: {}, [prev]: {}, yoy: {} },
  };

  for (let statistic of data) {
    const { audit, car, divide, division } = statistic;
    rowHeadInfo.push({ key: division, title: intlObj.formatDynamic(statistic, 'division') });

    parsed.audit[curr][division] = audit[curr];
    parsed.audit[prev][division] = audit[prev];
    parsed.audit.yoy[division] = audit.yoy;

    parsed.car[curr][division] = car[curr];
    parsed.car[prev][division] = car[prev];
    parsed.car.yoy[division] = car.yoy;

    parsed.carDivAudit[curr][division] = divide[curr];
    parsed.carDivAudit[prev][division] = divide[prev];
    parsed.carDivAudit.yoy[division] = divide.yoy;
  }

  return { data: parsed, rowHeadInfo };
};

export const parsingQard = data => {
  const rowHeadInfo = [];

  const parsed = {
    audit: {},
    car: {},
    closedCar: {},
    closedRate: {},
    carDivAudit: {},
    hfacs: {},
    hfacsDivCar: {},
  };

  for (let statistic of data) {
    const { audit, car, closedCar, closedCarRatio, hfacs, carDivAudit, hfacsDivCar, division } = statistic;

    rowHeadInfo.push({ key: division, title: intlObj.formatDynamic(statistic, 'division') });

    parsed.audit[division] = audit;
    parsed.car[division] = car;
    parsed.closedCar[division] = closedCar;
    parsed.closedRate[division] = closedCarRatio;
    parsed.carDivAudit[division] = carDivAudit;
    parsed.hfacs[division] = hfacs;
    parsed.hfacsDivCar[division] = hfacsDivCar;
  }

  return { data: parsed, rowHeadInfo };
};

export const parsingCfa = ({ rowHeadInfo, data }) => {
  const parsed = {
    count: {},
    countRatio: {},
  };
  const rowInfoIntl = rowHeadInfo.map(row => intlObj.formatDynamic(row, 'level1'));

  const locale = intlObj.locale;
  const key = `rootCauseName${capitalize(locale)}`;

  for (let row of rowInfoIntl) {
    const index = data.findIndex(item => item[key] === row);
    if (index > -1) {
      const target = data[index];
      parsed.count[row] = target.rootCauseCount;
      parsed.countRatio[row] = target.rootCauseRatio;
    }
  }

  return { data: parsed, rowHeadInfo: rowInfoIntl };
};
