import React, { useState, useEffect } from 'react';
import moment from 'moment';

import { Row, Col } from 'antd';
import StyledDashboard from 'style/styledDashboard';
import Header from './Header';
import Card from './Card';

import { defaultAxios } from 'utils/AxiosFunc';
import useApi from './useApi';

const AnalysisView = () => {
  const [dateRange, setDateRange] = useState([moment().startOf('year'), moment().endOf('year')]);
  const [tempDate, setTempDate] = useState(dateRange);
  const [division, setDivision] = useState(['all']);
  const [options, setOptions] = useState([{ value: 'all', nameKo: '모두', nameEn: 'All' }]);
  const [
    qas,
    getQas,
    isQasLoad,
    qard,
    getQard,
    isQardLoad,
    acfd,
    getAcfd,
    isAcfdLoad,
    cfa,
    getCfa,
    isCfaLoad,
  ] = useApi();

  useEffect(() => {
    defaultAxios
      .get({ url: '/api/ke/audit/v1/common/condition', payload: { type: 'AUDIT' } })
      .then(({ data: { data: options }, status }) => {
        if (status === 200) {
          setOptions(options);
        }

        return options;
      })
      .then(options => onSearch(options));
  }, []);

  const onSearch = options => {
    getQas({ dateRange });
    getQard({ dateRange });
    getAcfd({ dateRange });
    getCfa({ dateRange, division, setDivision, options });
    setTempDate(dateRange);
  };

  const onSelectChange = value => setDivision(value);

  const onReload = () => {
    getCfa({ dateRange: tempDate, division, setDivision, options });
  };

  return (
    <StyledDashboard>
      <section className="analysis-container">
        <Row gutter={[24, 24]}>
          <Col xs={24} xl={24}>
            <Header dateRange={dateRange} setDateRange={setDateRange} onSeearch={() => onSearch(options)} />
          </Col>
          <Col xs={24} xl={12}>
            <Card type="QAS" data={qas?.data} rowHeadInfo={qas?.rowHeadInfo} loading={!isQasLoad} />
          </Col>
          <Col xs={24} xl={12}>
            <Card type="QARD" data={qard?.data} rowHeadInfo={qard?.rowHeadInfo} loading={!isQardLoad} />
          </Col>
          <Col xs={24} xl={24}>
            <Card
              type="ACFD"
              data={acfd?.data}
              rowHeadInfo={acfd?.rowHeadInfo}
              labels={acfd?.labels}
              loading={!isAcfdLoad}
            />
          </Col>
          <Col xs={24} xl={24}>
            <Card
              type="CFA"
              data={cfa?.data}
              rowHeadInfo={cfa?.rowHeadInfo}
              loading={!isCfaLoad}
              value={division}
              options={options}
              onReload={onReload}
              onSelectChange={onSelectChange}
            />
          </Col>
        </Row>
      </section>
    </StyledDashboard>
  );
};

export default AnalysisView;
