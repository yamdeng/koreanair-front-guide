const prefix = 'apps/audit/MyAudit/List/MyAuditList';

export const RESET_STATE_VALUE = `${prefix}/RESET_STATE_VALUE`;
export const GET_VIEW_LIST_DATA = `${prefix}/GET_VIEW_LIST_DATA`;
export const SUCCESS_GET_VIEW_LIST_DATA = `${prefix}/SUCCESS_GET_VIEW_LIST_DATA`;
export const UPDATE_APPROVAL_STATUS = `${prefix}/UPDATE_APPROVAL_STATUS`;
export const SUCCESS_UPDATE_APPROVAL_STATUS = `${prefix}/SUCCESS_UPDATE_APPROVAL_STATUS`;
export const SET_RESPONSE_MESSAGE = `${prefix}/SET_RESPONSE_MESSAGE`;
