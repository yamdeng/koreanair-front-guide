import { intlObj } from 'utils/commonUtils';
import capitalize from 'lodash/capitalize';

export const processPhase = phase => {
  switch (phase) {
    case 'plan':
      return { phaseKo: '계획', phaseEn: 'Plan' };
    case 'conduct':
      return { phaseKo: '실시', phaseEn: 'Conduct' };
    case 'finding_assign':
      return { phaseKo: '경감조치 할당', phaseEn: 'Finding Assign' };
    case 'mitigation_result':
      return { phaseKo: '경감조치 계획/결과', phaseEn: 'Mitigation Result' };
    case 'finding_close':
      return { phaseKo: '경감조치 평가완료', phaseEn: 'Finding Close' };
    case 'audit_close':
      return { phaseKo: 'Audit 종결', phaseEn: 'Audit Close' };
    default:
      return { phaseKo: '', phaseEn: '' };
  }
};

const makeAuditors = auditors => {
  const result = auditors.map(auditor => {
    const { type, empNo } = auditor;
    const auditType = capitalize(type);
    return `${auditType} ${intlObj.formatDynamic(auditor, 'name')}(${empNo})`;
  });

  return result.join('\n');
};

export const processDataSource = ({ dataSource }) => {
  return dataSource.map(data => {
    const { auditors } = data;

    return {
      ...data,
      auditors: makeAuditors(auditors),
      status: intlObj.formatDynamic(data, 'status'),
    };
  });
};
