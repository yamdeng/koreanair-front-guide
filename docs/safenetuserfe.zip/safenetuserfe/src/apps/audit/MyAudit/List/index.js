import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Tabs, message } from 'antd';
import StyledAudit from 'style/styledAudit';
import MyAuditList from './MyAuditList';
import Schedule from './Schedule';

const { TabPane } = Tabs;

const tabKeys = ['list', 'schedule'];

const MyAudit = props => {
  const { location } = props;

  // Control default tab with selectedTab state in location.
  const [selectedTab, setSelectedTab] = useState(location.state?.selectedTab ?? tabKeys[0]);

  // Do action with location.state from props.
  useEffect(() => {
    const { state = {} } = location;

    // Initialize selectedTab if state contains option.
    const stateTab = state.selectedTab ?? '';
    if (tabKeys.indexOf(stateTab.toLowerCase()) > -1) {
      setSelectedTab(stateTab);
    } else {
      setSelectedTab(tabKeys[1]);
    }

    // Show error message if code in state exists and is not 200.
    const stateCode = state.code ?? 200;
    switch (stateCode) {
      case 404:
        message.error('Cannot find requested contents.');
        break;

      default:
        break;
    }
  }, [location.state]);

  return (
    <StyledAudit className="keWrap">
      <Tabs defaultActiveKey={selectedTab} size="middle">
        <TabPane tab="My Audit" key={tabKeys[0]}>
          <MyAuditList {...props} />
        </TabPane>
        <TabPane tab="Schedule" key={tabKeys[1]}>
          <Schedule {...props} />
        </TabPane>
      </Tabs>
    </StyledAudit>
  );
};

MyAudit.propTypes = {
  location: PropTypes.object,
};

MyAudit.defaultProps = {
  location: {},
};

export default MyAudit;
