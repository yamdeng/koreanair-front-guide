import { fromJS } from 'immutable';
import * as actionType from './constants';
import { initialMessageObj } from 'hooks/useAntdMessage';

const initialState = fromJS({
  viewListData: {
    headerInfo: [],
    dataSource: [],
  },
  messageObj: initialMessageObj,
  isLoaded: false,
});

const myAuditListReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionType.RESET_STATE_VALUE:
      return initialState;
    case actionType.GET_VIEW_LIST_DATA:
      return state.set('isLoaded', false);
    case actionType.SUCCESS_GET_VIEW_LIST_DATA:
      return state.set('isLoaded', true).set('viewListData', fromJS(action.payload));
    case actionType.SUCCESS_UPDATE_APPROVAL_STATUS:
      return state.updateIn(['viewListData', 'dataSource'], item =>
        item.mergeIn([item.findIndex(x => x.get('id') === action.payload.id)], {
          phase: action.payload.phase,
          stepCode: action.payload.stepCode,
          statusKo: action.payload.statusKo,
          statusEn: action.payload.statusEn,
          reason: action.payload.reason,
        }),
      );
    case actionType.SET_RESPONSE_MESSAGE:
      return state.set('messageObj', fromJS(action.payload));
    default:
      return state;
  }
};

export default myAuditListReducer;
