import { useState } from 'react';
import moment from 'moment';

export const useCalendarSearch = initialValue => {
  const [date, setDate] = useState(moment());
  const [division, setDivision] = useState(['all']);

  const parameter = {
    date,
    division,
  };

  const setParameter = (type, value) => {
    switch (type) {
      case 'date':
        return setDate(value);
      case 'division':
        return setDivision(value);
      default:
        return;
    }
  };

  return [parameter, setParameter];
};
