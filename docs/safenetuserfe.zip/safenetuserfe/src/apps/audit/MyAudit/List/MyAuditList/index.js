import React, { useState, useEffect } from 'react';
import { Button } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { WithStateManagement } from 'utils/stateUtils';
import { createStructuredSelector } from 'reselect';
import debounce from 'lodash/debounce';
import saga from './store/saga';
import * as actions from './store/actions';
import reducer from './store/reducer';
import * as selectors from './store/selectors';
import ViewListTable from 'components/ViewListTable';
import RangeSearch from 'components/RangeSearch/audit';
import useRangeSearch from 'components/RangeSearch/audit/customHook';
import { useInitialFilter } from 'components/ViewListTable/utils';
import ExportCSVButton from 'components/ExportCSVButton';
import fileNameUtils from 'components/ExportCSVButton/utils/fileNameUtils';
import useAntdMessage from 'hooks/useAntdMessage';
import { makeDateCondition } from 'apps/audit/MyAudit/utils';
import {
  isInternalAuditor as validateInternalAuditor,
  isAuditAdmin as validateAuditAdmin,
} from 'hooks/useAuthorization';
import { STEP_CONDUCT, STEP_CLOSE } from 'apps/audit/MyAudit/Write/store/constants';

const MyAuditList = ({
  history,
  location: { pathname: basePath },
  isLoaded,
  getViewListData,
  viewListData,
  updateApprovalStatus,
  messageObj,
  resetStateValue,
}) => {
  // Define list data.
  const { dataSource, headerInfo } = viewListData;
  const [rangeSearchPayload, setRangeSearchPayload] = useRangeSearch();
  const defaultFilterValue = useInitialFilter();
  const { dateType, startDate, endDate } = rangeSearchPayload;
  const [exportDatasource, setExportDataSource] = useState([]);
  const isInternalAuditor = validateInternalAuditor() || validateAuditAdmin();
  useAntdMessage(messageObj);

  useEffect(() => {
    getViewListData(makeDateCondition(dateType, startDate, endDate));
    return () => resetStateValue();
  }, []);

  useEffect(() => {
    setExportDataSource(viewListData.dataSource);
  }, [viewListData.dataSource]);

  const onSearch = debounce(parameter => {
    const { dateType, startDate, endDate } = parameter;
    getViewListData(makeDateCondition(dateType, startDate, endDate));
  }, 500);

  // Table cell click handlers.
  const onClickColumn = record => {
    const { id } = record;
    return `${basePath}/view/${id}`;
  };

  // Action button click handlers.
  const callbackOnAction = props => {
    const { type, record, reason } = props;
    const { id, phase, editPhase, isFinding } = record;
    if (type === 'edit') {
      if (phase) {
        window.open(`${basePath}/write/${editPhase}/${id}`, '_blank', 'noopener noreferrer');
      }
    } else if (type === 'approve' || type === 'reject') {
      updateApprovalStatus({ id, approvalType: type, reason });
    } else if (type === 'view') {
      const step = isFinding === 'Y' ? STEP_CONDUCT : STEP_CLOSE;
      window.open(`${basePath}/write/${step}/${id}`, '_blank', 'noopener noreferrer');
    }
  };

  // Utility buttons.
  const onClickAddPlan = () => {
    history.push(`${basePath}/write/plan`);
  };

  return (
    <section className="keWrap viewList">
      {/* Search */}
      <section className="search-container">
        <RangeSearch
          onSearch={onSearch}
          parameter={rangeSearchPayload}
          setParameter={setRangeSearchPayload}
          enableDateType={['audit']}
        />
      </section>
      {/* List */}
      <section className="table-container">
        <ViewListTable
          headerInfo={headerInfo}
          dataSource={dataSource}
          fixHeader
          usePaging
          onClickColumn={onClickColumn}
          callbackOnAction={callbackOnAction}
          extraButtons={
            isInternalAuditor && (
              <Button type="primary" icon={<PlusOutlined />} onClick={onClickAddPlan}>
                Add Plan
              </Button>
            )
          }
          handleExportData={setExportDataSource}
          defaultFilterValue={defaultFilterValue}
          loading={!isLoaded}
        />
      </section>
      <section className="chapter-footer">
        <div className="buttonGroup">
          <ExportCSVButton
            dataSource={exportDatasource}
            columns={headerInfo}
            fileName={fileNameUtils('my_audit', dateType, startDate, endDate)}
          />
        </div>
      </section>
    </section>
  );
};

const mapStateToProps = createStructuredSelector({
  isLoaded: selectors.makeIsLoaded(),
  viewListData: selectors.makeViewlistData(),
  messageObj: selectors.makeMessage(),
});

const mapDispatchToProps = dispatch => ({
  getViewListData: payload => dispatch(actions.getViewListData(payload)),
  updateApprovalStatus: payload => dispatch(actions.updateApprovalStatus(payload)),
  resetStateValue: () => dispatch(actions.resetStateValue()),
});

export default WithStateManagement(MyAuditList, {
  mapStateToProps,
  mapDispatchToProps,
  key: 'myAuditList',
  reducer,
  saga,
});
