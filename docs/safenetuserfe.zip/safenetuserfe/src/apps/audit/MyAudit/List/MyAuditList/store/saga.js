import { call, put, takeLatest } from 'redux-saga/effects';
import * as actionType from './constants';
import * as actions from './actions';
import { Axios, defaultAxios } from 'utils/AxiosFunc';
import { processHeaderInfo } from 'components/ViewListTable/utils';
import { processDataSource } from './utils';
import { intlObj } from 'utils/commonUtils';

function* getViewListData(action) {
  const { data } = yield call(Axios.get, '/api/ke/audit/v1/my-audit/list', action.payload);
  if (data) {
    const headerInfo = processHeaderInfo(data);
    const dataSource = processDataSource(data);

    yield put(actions.successGetViewListData({ headerInfo, dataSource }));
  }
}

function* updateApprovalStatus(action) {
  const { payload } = action;
  const { id, approvalType } = payload;
  const response = yield call(defaultAxios.post, { url: `/api/ke/audit/v1/close/final-approval/${id}`, payload });

  if (response.status === 200) {
    const {
      data: { data },
    } = response;
    const message = {
      content: `Audit종결을 ${approvalType === 'approve' ? '승인' : '반려'} 했습니다.`,
      messageType: 'success',
      target: 'approval',
    };
    yield put(actions.setResponseMessage(message));
    yield put(actions.successUpdateApprovalStatus({ ...data, status: intlObj.formatDynamic(data, 'status') }));
  }
}

export default function* myAuditListSaga() {
  yield takeLatest(actionType.GET_VIEW_LIST_DATA, getViewListData);
  yield takeLatest(actionType.UPDATE_APPROVAL_STATUS, updateApprovalStatus);
}
