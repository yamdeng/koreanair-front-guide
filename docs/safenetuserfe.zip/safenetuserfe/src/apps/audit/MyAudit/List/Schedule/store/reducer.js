import { fromJS } from 'immutable';
import * as actionType from './constants';

const initialState = fromJS({
  calendar: {
    data: {},
    isLoaded: false,
  },
  summary: {
    data: {},
    isLoaded: false,
  },
  options: [],
});

const myAuditScheduleReducer = (state = initialState, action) => {
  const { payload } = action;
  switch (action.type) {
    case actionType.SUCCESS_GET_DIVISION_OPTION:
      return state.set('options', fromJS(payload));
    case actionType.GET_DIV_SUMMARY:
      return state.setIn(['summary', 'isLoaded'], false);
    case actionType.SUCCESS_GET_DIV_SUMMARY:
      return state.setIn(['summary', 'data'], fromJS(payload)).setIn(['summary', 'isLoaded'], true);
    case actionType.GET_CALENDAR_DATA:
      return state.setIn(['calendar', 'isLoaded'], false);
    case actionType.SUCCESS_GET_CALENDAR_DATA:
      return state.setIn(['calendar', 'data'], fromJS(payload)).setIn(['calendar', 'isLoaded'], true);
    case actionType.RESET_STATE_VALUE:
      return initialState;
    default:
      return state;
  }
};

export default myAuditScheduleReducer;
