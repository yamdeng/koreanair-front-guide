import React from 'react';

import { Badge } from 'antd';

import { progresses } from '../../../constants';

const ExplanatoryNotes = () => (
  <aside className="schedule-legend">
    <ul>
      {progresses.map(prog => (
        <li key={prog.code}>
          <Badge status={prog.badge} text={prog.title} />
        </li>
      ))}
    </ul>
  </aside>
);

export default ExplanatoryNotes;
