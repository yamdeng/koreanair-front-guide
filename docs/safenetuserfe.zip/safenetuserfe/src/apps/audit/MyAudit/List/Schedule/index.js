import React, { useState, useEffect } from 'react';
import moment from 'moment';
import { createStructuredSelector } from 'reselect';
import { WithStateManagement } from 'utils/stateUtils';
import { isAuditAdmin as validateAuditAdmin } from 'hooks/useAuthorization';
import reducer from './store/reducer';
import saga from './store/saga';
import * as actions from './store/actions';
import * as selectors from './store/selectors';
import Summary from './Summary';
import CalendarView from './Calendar';
import { useCalendarSearch } from './customHook';

const Schedule = ({
  location: { pathname: basePath },
  summaryData,
  calendarData,
  getScheduleData,
  getDivisionOption,
  resetStateValue,
}) => {
  const [parameter, setParameter] = useCalendarSearch();
  const [selected, setSelected] = useState(moment());
  const [selYear, setSelYear] = useState(moment().year());
  const [selDate, setSelDate] = useState(
    moment()
      .startOf('month')
      .format('YYYY-MM-DD'),
  );
  const [isSearch, setIsSearch] = useState(false);
  const { data: calendar, isLoaded: isCalendarLoaded } = calendarData;
  const { data: summary, isLoaded: isSummaryLoaded } = summaryData;
  const isAuditAdmin = validateAuditAdmin();

  useEffect(() => {
    if (isAuditAdmin) {
      getDivisionOption();
    }
    return () => resetStateValue();
  }, []);

  useEffect(() => {
    const year = selected.year();
    const date = moment(selected)
      .startOf('month')
      .format('YYYY-MM-DD');
    setSelYear(year);
    setSelDate(date);
  }, [selected]);

  useEffect(() => {
    if (isSearch) {
      setIsSearch(false);
    } else {
      getScheduleData(parameter);
    }
  }, [selDate]);

  const onSearchSelect = date => {
    const { division } = parameter;
    if (Array.isArray(division) && division.length === 0) {
      setParameter('division', ['all']);
    }

    setIsSearch(true);
    getScheduleData(parameter);

    setSelected(date);
  };

  return (
    <div>
      <Summary divSummary={summary} selYear={selYear} loading={!isSummaryLoaded} />
      <CalendarView
        data={calendar}
        selected={selected}
        setSelected={setSelected}
        selectValue={parameter}
        onChangeSelect={setParameter}
        onSearchSelect={onSearchSelect}
        loading={!isCalendarLoaded}
        basePath={basePath}
      />
    </div>
  );
};

const mapStateToProps = createStructuredSelector({
  summaryData: selectors.makeSummary(),
  calendarData: selectors.makeCalendar(),
});

const mapDispatchToProps = dispatch => ({
  getDivisionOption: () => dispatch(actions.getDivisionOption()),
  getScheduleData: payload => dispatch(actions.getScheduleData(payload)),
  resetStateValue: () => dispatch(actions.resetStateValue()),
});

export default WithStateManagement(Schedule, {
  mapStateToProps,
  mapDispatchToProps,
  key: 'myAuditSchedule',
  reducer,
  saga,
});
