import { call, put, takeLatest } from 'redux-saga/effects';
import * as actionType from './constants';
import * as actions from './actions';
import { Axios } from 'utils/AxiosFunc';
import { processCalendarData, processDivision, makeSummaryPayload, makeCalendarPayload } from './utils';

export function* getDivisionOption() {
  const { data } = yield call(Axios.get, '/api/ke/audit/v1/common/audit-division');
  yield put(actions.successGetDivisionOption(processDivision(data)));
}

export function* getScheduleData(action) {
  const { payload } = action;
  yield put(actions.getDivSummary(payload));
  yield put(actions.getCalendarData(payload));
}

export function* getDivSummary(action) {
  const { payload } = action;
  const { data } = yield call(Axios.get, '/api/ke/audit/v1/my-audit/summary', makeSummaryPayload(payload));
  yield put(actions.successGetDivSummary(data));
}

export function* getCalendarData(action) {
  const { payload } = action;
  const { data } = yield call(Axios.get, '/api/ke/audit/v1/my-audit/calendar', makeCalendarPayload(payload));
  yield put(actions.successGetCalendarData(processCalendarData(data)));
}

export default function* myAuditScheduleSaga() {
  yield takeLatest(actionType.GET_SCHEDULE_DATA, getScheduleData);
  yield takeLatest(actionType.GET_DIVISION_OPTION, getDivisionOption);
  yield takeLatest(actionType.GET_CALENDAR_DATA, getCalendarData);
  yield takeLatest(actionType.GET_DIV_SUMMARY, getDivSummary);
}
