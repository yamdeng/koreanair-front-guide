const prefix = 'app/audit/MyAudit/Schedule';

export const RESET_STATE_VALUE = `${prefix}/RESET_STATE_VALUE`;

export const GET_DIVISION_OPTION = `${prefix}/GET_DIVISION_OPTION`;
export const SUCCESS_GET_DIVISION_OPTION = `${prefix}/SUCCESS_GET_DIVISION_OPTION`;

export const GET_SCHEDULE_DATA = `${prefix}/GET_SCHEDULE_DATA`;

export const GET_CALENDAR_DATA = `${prefix}/GET_CALENDAR_DATA`;
export const SUCCESS_GET_CALENDAR_DATA = `${prefix}/SUCCESS_GET_CALENDAR_DATA`;

export const GET_DIV_SUMMARY = `${prefix}/GET_DIV_SUMMARY`;
export const SUCCESS_GET_DIV_SUMMARY = `${prefix}/SUCCESS_GET_DIV_SUMMARY`;

export const SUCCESS_LOADED = `${prefix}/SUCCESS_LOADED`;
