import * as constants from './constants';

export const getViewListData = payload => ({
  type: constants.GET_VIEW_LIST_DATA,
  payload,
});

export const successGetViewListData = payload => ({
  type: constants.SUCCESS_GET_VIEW_LIST_DATA,
  payload,
});

export const updateApprovalStatus = payload => ({
  type: constants.UPDATE_APPROVAL_STATUS,
  payload,
});

export const successUpdateApprovalStatus = payload => ({
  type: constants.SUCCESS_UPDATE_APPROVAL_STATUS,
  payload,
});

export const setResponseMessage = payload => ({
  type: constants.SET_RESPONSE_MESSAGE,
  payload,
});

export const resetStateValue = () => ({
  type: constants.RESET_STATE_VALUE,
});
