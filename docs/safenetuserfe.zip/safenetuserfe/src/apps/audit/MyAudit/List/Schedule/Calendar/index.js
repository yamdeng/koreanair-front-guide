import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import moment from 'moment';
import { Spin, Calendar, Badge, Button, Tooltip } from 'antd';
import en from 'antd/es/calendar/locale/en_US';
import ko from 'antd/es/calendar/locale/ko_KR';
import { intlObj } from 'utils/commonUtils';
import * as constants from '../../../Write/store/constants';
import ExplanatoryNotes from './ExplanatoryNotes';
import calendarHeaderRender from './calendarHeaderRender';
import {
  isInternalAuditor as validateInternalAuditor,
  isAuditAdmin as validateAuditAdmin,
} from 'hooks/useAuthorization';
import { STEP_CONDUCT, STEP_CLOSE } from 'apps/audit/MyAudit/Write/store/constants';

import { connect } from 'react-redux';
import { makeOption } from '../store/selectors';
import { createStructuredSelector } from 'reselect';

const ScheduleItem = styled(Button)`
  width: 100%;
  padding: 0;
  text-align: left;

  .ant-badge {
    display: block;
    width: 100%;

    & > * {
      display: inline-block;
      vertical-align: middle;
    }

    &-status-text {
      display: inline-block;
      width: calc(100% - 14px);
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
`;

const supportingLocales = {
  en: {
    string: 'en',
    object: en,
  },
  ko: {
    string: 'ko',
    object: ko,
  },
};

const CalendarView = ({
  data,
  selected,
  setSelected,
  selectValue,
  onChangeSelect,
  onSearchSelect,
  options,
  loading,
  basePath,
}) => {
  // Locale setting
  const [locale] = useState(supportingLocales[intlObj.locale]);
  const isInternalAuditor = validateInternalAuditor() || validateAuditAdmin();

  // Event handlers.
  const onClickItem = (event, item) => {
    event.stopPropagation();
    const { id, editPhase, enableEdit, enableView, isFinding } = item;
    if (enableEdit) {
      window.open(`${basePath}/write/${editPhase}/${id}`, '_blank', 'noopener noreferrer');
      return;
    } else if (enableView) {
      const step = isFinding === 'Y' ? STEP_CONDUCT : STEP_CLOSE;
      window.open(`${basePath}/write/${step}/${id}`, '_blank', 'noopener noreferrer');
      return;
    }
    window.open(`${basePath}/view/${id}`, '_blank', 'noopener noreferrer');
    return;
  };

  const onDoubleClickDateCell = date => {
    const auditAt = date.format('YYYY-MM-DD');
    window.open(`${basePath}/write/${constants.STEP_PLAN}?auditAt=${auditAt}`, '_blank', 'noopener noreferrer');
  };

  const dateFullCellRender = date => {
    const today = moment().startOf('day');
    const calendarDate = date.startOf('day');
    const isToday = today.diff(calendarDate, 'days') === 0;

    if (isInternalAuditor) {
      return (
        <div
          className={`ant-picker-cell-inner ant-picker-calendar-date ${
            isToday ? 'ant-picker-calendar-date-today' : ''
          }`}
          onDoubleClick={() => onDoubleClickDateCell(date)}
        >
          <div className="ant-picker-calendar-date-value">{date.date()}</div>
          <div className="ant-picker-calendar-date-content">{dateCellRender(date)}</div>
        </div>
      );
    }

    return (
      <div
        className={`ant-picker-cell-inner ant-picker-calendar-date ${isToday ? 'ant-picker-calendar-date-today' : ''}`}
      >
        <div className="ant-picker-calendar-date-value">{date.date()}</div>
        <div className="ant-picker-calendar-date-content">{dateCellRender(date)}</div>
      </div>
    );
  };

  const dateCellRender = date => {
    const arrYMD = date.format('YYYY-MM-DD').split('-');
    const monthData = data[arrYMD[1]] ?? {};
    const dayData = monthData[arrYMD[2]] ?? [];

    return (
      <ul className="events">
        {dayData.map(item => (
          <li key={item.key}>
            <Tooltip
              title={
                <>
                  <p>{`${item.auditNo} / ${item.division}`}</p>
                  <p>{item.subject}</p>
                  <p>Lead: {item.auditor}</p>
                  <p>{`Auditee: ${item.auditee !== 'unknown' ? item.auditee : 'Line Safety Audit'}`}</p>
                </>
              }
              placement="topLeft"
              getPopupContainer={trigger => trigger.parentNode}
            >
              <ScheduleItem
                type="link"
                size="small"
                block
                onClick={event => onClickItem(event, item)}
                title={item.cont}
              >
                <Badge status={item.badge} text={item.subject} />
              </ScheduleItem>
            </Tooltip>
          </li>
        ))}
      </ul>
    );
  };

  const onSelect = date => {
    setSelected(date);
    onChangeSelect('date', date);
  };

  const onSearch = async date => {
    onSearchSelect(date);
  };

  return (
    <section className="schedule-calendar">
      <Spin spinning={loading}>
        <Calendar
          value={selected}
          locale={locale.object}
          headerRender={() => calendarHeaderRender(selectValue, locale.string, options, onChangeSelect, onSearch)}
          dateFullCellRender={dateFullCellRender}
          onSelect={onSelect}
        />
        <ExplanatoryNotes />
      </Spin>
    </section>
  );
};

CalendarView.propTypes = {
  data: PropTypes.object,
  selected: PropTypes.any,
  setSelected: PropTypes.func,
  loading: PropTypes.bool,
};

CalendarView.defaultProps = {
  data: {},
  selected: null,
  setSelected: () => {},
  loading: false,
};

const mapStateToProps = createStructuredSelector({
  options: makeOption(),
});

export default connect(mapStateToProps)(CalendarView);
