import { createSelector } from 'reselect';

const selectMyAuditList = state => state.get('myAuditList');

const makeIsLoaded = () => createSelector(selectMyAuditList, state => state.get('isLoaded'));
const makeViewlistData = () => createSelector(selectMyAuditList, state => state.get('viewListData').toJS());
const makeMessage = () => createSelector(selectMyAuditList, state => state.get('messageObj'));

export { selectMyAuditList, makeIsLoaded, makeViewlistData, makeMessage };
