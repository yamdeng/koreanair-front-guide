import React from 'react';
import { fromJS } from 'immutable';
import { Row, Col, Select, TreeSelect, Button } from 'antd';
import { SearchOutlined } from '@ant-design/icons';

import { isAuditAdmin as validateAuditAdmin } from 'hooks/useAuthorization';

const parent = [
  {
    title: 'All',
    value: 'all',
    key: 'all',
  },
];

const calendarHeaderRender = (value, locale, divOptions, onChangeSelect, onSearch) => {
  const { date, division } = value;
  const isAuditAdmin = validateAuditAdmin();

  const current = date.clone();
  const localeData = date.locale(locale).localeData();
  // const localeData = date.localeData();
  const months = [];
  for (let i = 0; i < 12; i += 1) {
    current.month(i);
    months.push(localeData.monthsShort(current));
  }

  const month = date.month();

  const year = date.year();
  const years = [];
  const startYear = year - 10 < 2021 ? 2021 : year - 10;
  for (let i = startYear; i < year + 10; i += 1) {
    years.push(
      <Select.Option key={i} value={i} className="year-item">
        {i}
      </Select.Option>,
    );
  }

  const treeData = fromJS(parent)
    .setIn([0, 'children'], divOptions)
    .toJS();

  const handleChangeDiv = nextValue => {
    onChangeSelect('division', nextValue);
  };

  return (
    <div style={{ padding: '12px 0' }}>
      <Row gutter={8}>
        {isAuditAdmin && (
          <Col>
            <TreeSelect
              placeholder="Select Division"
              treeData={treeData}
              value={division}
              onChange={handleChangeDiv}
              showCheckedStrategy={TreeSelect.SHOW_PARENT}
              maxTagCount={1}
              treeDefaultExpandAll
              treeCheckable
              style={{ maxWidth: '100%', width: 240 }}
            />
          </Col>
        )}
        <Col>
          <Select
            dropdownMatchSelectWidth={false}
            className="my-year-select"
            onChange={newYear => {
              const now = date.clone().year(newYear);
              onChangeSelect('date', now);
            }}
            value={String(year)}
          >
            {years}
          </Select>
        </Col>
        <Col>
          <Select
            dropdownMatchSelectWidth={false}
            value={String(month)}
            onChange={selectedMonth => {
              const newValue = date.clone();
              newValue.month(parseInt(selectedMonth, 10));
              onChangeSelect('date', newValue);
            }}
          >
            {months.map((month, index) => (
              <Select.Option className="month-item" key={`${index}`}>
                {month}
              </Select.Option>
            ))}
          </Select>
        </Col>
        <Col>
          <Button type="primary" icon={<SearchOutlined />} onClick={() => onSearch(date)}>
            Search
          </Button>
        </Col>
      </Row>
    </div>
  );
};

export default calendarHeaderRender;
