import * as constants from './constants';

export const getDivisionOption = () => ({
  type: constants.GET_DIVISION_OPTION,
});

export const successGetDivisionOption = payload => ({
  type: constants.SUCCESS_GET_DIVISION_OPTION,
  payload,
});

export const getScheduleData = payload => ({
  type: constants.GET_SCHEDULE_DATA,
  payload,
});

export const getCalendarData = payload => ({
  type: constants.GET_CALENDAR_DATA,
  payload,
});

export const successGetCalendarData = payload => ({
  type: constants.SUCCESS_GET_CALENDAR_DATA,
  payload,
});

export const getDivSummary = payload => ({
  type: constants.GET_DIV_SUMMARY,
  payload,
});

export const successGetDivSummary = payload => ({
  type: constants.SUCCESS_GET_DIV_SUMMARY,
  payload,
});

export const resetStateValue = () => ({
  type: constants.RESET_STATE_VALUE,
});
