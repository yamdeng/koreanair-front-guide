import React from 'react';
import { withRouter, Switch, Route, Redirect } from 'react-router-dom';
import PropTypes from 'prop-types';
import List from './List';
import Write from './Write/Routes';
import View from './View';

const MyAudit = ({ basePath }) => (
  <Switch>
    {/* List */}
    <Route exact path={basePath} component={List} />
    <Route exact path={`${basePath}/list`}>
      <Redirect
        to={{
          pathname: basePath,
          state: {
            selectedTab: 'list',
          },
        }}
      />
    </Route>
    <Route exact path={`${basePath}/schedule`}>
      <Redirect
        to={{
          pathname: basePath,
          state: {
            selectedTab: 'schedule',
          },
        }}
      />
    </Route>

    {/* Write/Edit */}
    <Route
      path={`${basePath}/write/:step`}
      render={data => <Write basePath={`${basePath}/write`} home={basePath} {...data} />}
    />
    {/* View */}
    <Route path={`${basePath}/view/:id`} render={data => <View {...data} />} />
  </Switch>
);

MyAudit.propTypes = {
  basePath: PropTypes.string,
};

MyAudit.defaultProps = {
  basePath: '',
};

export default withRouter(MyAudit);
