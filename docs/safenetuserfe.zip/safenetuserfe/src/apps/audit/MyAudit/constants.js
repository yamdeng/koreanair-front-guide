export const phases = ['plan', 'conduct', 'car', 'mitigation', 'close'];
export const statuses = ['draft', 'completed', 'rejected', 'approved'];
export const progresses = [
  {
    code: 'plan',
    title: 'Plan',
    badge: 'warning',
  },
  {
    code: 'conduct',
    title: 'Conduct',
    badge: 'success',
  },
  {
    code: 'car',
    title: 'Corrective Action',
    badge: 'error',
  },
  {
    code: 'close',
    title: 'Close',
    badge: 'default',
  },
];
