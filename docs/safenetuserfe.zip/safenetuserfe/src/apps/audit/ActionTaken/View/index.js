import React, { useEffect } from 'react';
import moment from 'moment';
import StyledAudit from 'style/styledAudit';
import { WithStateManagement } from 'utils/stateUtils';
import { createStructuredSelector } from 'reselect';
import reducer from './store/reducer';
import saga from './store/saga';
import * as actions from './store/actions';
import * as selectors from './store/selectors';

import RangeSearch from 'components/RangeSearch/audit';
import ViewListTable from 'components/ViewListTable';
import { useInitialFilter } from 'components/ViewListTable/utils';
import useRangeSearch from 'components/RangeSearch/audit/customHook';

const ViewlistAuditMitigation = ({ resetStateValue, getViewListData, viewListData, isLoaded, basePath }) => {
  const [rangeSearchPayload, setRangeSearchPayload] = useRangeSearch({
    dateRange: [moment().add(-6, 'months'), moment().add(2, 'months')],
  });
  const defaultFilterValue = useInitialFilter();
  useEffect(() => {
    const { dateType, startDate, endDate } = rangeSearchPayload;
    getViewListData({ dateType, startDate, endDate });
    return () => resetStateValue();
  }, []);

  const handleSearch = payload => {
    const { dateType, startDate, endDate } = payload;
    getViewListData({ dateType, startDate, endDate });
  };
  // const onClickColumn = payload => {
  //   console.log('컬럼클릭', payload);
  //   return '';
  // };
  const callbackOnAction = payload => {
    const {
      type,
      record: { id },
    } = payload;
    if (type === 'write') {
      window.open(`${basePath}/write/${id}`, '_blank', 'noopener noreferrer');
    }
  };
  return (
      <StyledAudit className="keWrap viewList">
        <section className="viewList">
          <section className="search-container">
            <RangeSearch
                onSearch={handleSearch}
                parameter={rangeSearchPayload}
                setParameter={setRangeSearchPayload}
                enableDateType={['audit']}
            ></RangeSearch>
          </section>
          <section className="table-container">
            <ViewListTable
                headerInfo={viewListData.headerInfo}
                dataSource={viewListData.dataSource}
                fixHeader
                usePaging
                // onClickColumn={onClickColumn}
                callbackOnAction={callbackOnAction}
                defaultFilterValue={defaultFilterValue}
                loading={!isLoaded}
            />
          </section>
        </section>
      </StyledAudit>
  );
};

const mapStateToProps = createStructuredSelector({
  viewListData: selectors.selectViewListData(),
  isLoaded: selectors.selectIsLoaded(),
  messageObj: selectors.selectMessageObj(),
});

const mapDispatchToProps = dispatch => ({
  resetStateValue: () => dispatch(actions.resetStateValue()),
  getViewListData: payload => dispatch(actions.getViewListData(payload)),
});

export default WithStateManagement(ViewlistAuditMitigation, {
  mapStateToProps,
  mapDispatchToProps,
  key: 'ViewlistAuditMitigation',
  reducer,
  saga,
  useRouter: true,
});
