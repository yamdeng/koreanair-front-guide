const prefix = 'apps/audit/Mitigation';

export const RESET_STATE_VALUE = `${prefix}/RESET_STATE_VALUE`;

export const GET_VIEW_LIST_DATA = `${prefix}/GET_VIEW_LIST_DATA`;
export const SUCCESS_GET_VIEW_LIST_DATA = `${prefix}/SUCCESS_GET_VIEW_LIST_DATA`;
