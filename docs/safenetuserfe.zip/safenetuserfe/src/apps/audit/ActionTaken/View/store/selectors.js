import { createSelector } from 'reselect';

const getViewlistAudit = state => state.get('ViewlistAuditMitigation');

const selectViewListData = () => createSelector(getViewlistAudit, state => state.get('viewListData').toJS());
const selectIsLoaded = () => createSelector(getViewlistAudit, state => state.get('isLoaded'));
const selectMessageObj = () => createSelector(getViewlistAudit, state => state.get('messageObj'));

export { selectViewListData, selectIsLoaded, selectMessageObj };
