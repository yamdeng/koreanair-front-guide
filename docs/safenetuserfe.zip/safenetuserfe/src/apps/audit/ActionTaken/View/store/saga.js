import { delay } from 'redux-saga';
import { call, put, takeLatest, select } from 'redux-saga/effects';
import * as actionType from './constants';
import * as actions from './actions';
import { defaultAxios } from 'utils/AxiosFunc';
import { processHeaderInfo } from 'components/ViewListTable/utils';

function* getViewListData(action) {
  const { dateType, startDate, endDate } = action.payload;
  const payload = {
    dateType,
    startDate,
    endDate,
  };
  const response = yield call(defaultAxios.get, { url: '/api/ke/audit/v1/viewList/mitigation', payload });
  if (response.status === 200) {
    const { data } = response.data;
    const headerInfo = processHeaderInfo(data);
    const { dataSource } = data;
    yield put(actions.successGetViewListData({ headerInfo, dataSource }));
  }
}

export default function* viewlistAuditSaga() {
  yield takeLatest(actionType.GET_VIEW_LIST_DATA, getViewListData);
}
