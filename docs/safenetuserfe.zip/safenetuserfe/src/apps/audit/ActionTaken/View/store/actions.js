import * as actionType from './constants';

export const resetStateValue = () => ({
  type: actionType.RESET_STATE_VALUE,
});

export const getViewListData = payload => ({
  type: actionType.GET_VIEW_LIST_DATA,
  payload,
});

export const successGetViewListData = payload => ({
  type: actionType.SUCCESS_GET_VIEW_LIST_DATA,
  payload,
});
