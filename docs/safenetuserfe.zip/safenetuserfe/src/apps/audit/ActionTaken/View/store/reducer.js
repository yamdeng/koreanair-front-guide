import { fromJS } from 'immutable';
import * as actionType from './constants';
import { initialMessageObj } from 'hooks/useAntdMessage';

const initialState = fromJS({
  viewListData: {
    headerInfo: [],
    dataSource: [],
  },
  messageObj: initialMessageObj,
  isLoaded: false,
});

const viewlistAuditReducer = (state = initialState, action) => {
  const { payload } = action;
  switch (action.type) {
    case actionType.GET_VIEW_LIST_DATA:
      return state.set('isLoaded', false);
    case actionType.SUCCESS_GET_VIEW_LIST_DATA:
      return state.set('isLoaded', true).set('viewListData', fromJS(payload));
    default:
      return state;
  }
};

export default viewlistAuditReducer;
