import React from 'react';
import StyledAudit from 'style/styledAudit';
import { withRouter, Switch, Route, Redirect } from 'react-router-dom';
import ErrorPage from 'containers/portal/App/ErrorPage';
import View from './View';
import Write from './Write';

const AuditMitigation = ({ basePath }) => {
  return (
    <Switch>
      <Route exact path={basePath} render={props => <View {...props} basePath={basePath} />} />
      <Route exact path={`${basePath}/write/:id`} render={props => <Write {...props} basePath={basePath} />} />
    </Switch>
  );
};

export default AuditMitigation;
