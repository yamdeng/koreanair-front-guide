import * as actionType from './constants';

export const resetStateValue = () => ({
  type: actionType.RESET_STATE_VALUE,
});

export const getMitigationDetail = payload => ({
  type: actionType.GET_MITIGATION_DETAIL,
  payload,
});

export const successGetMitigationDetail = (payload, concurrent) => ({
  type: actionType.SUCCESS_GET_MITIGATION_DETAIL,
  payload,
  concurrent,
});

export const setResponseMessage = payload => ({
  type: actionType.SET_RESPONSE_MESSAGE,
  payload,
});

export const saveMitigationDetail = payload => ({
  type: actionType.SAVE_MITIGATION_DETAIL,
  payload,
});

export const submitMitigationDetail = payload => ({
  type: actionType.SUBMIT_MITIGATION_DETAIL,
  payload,
});
