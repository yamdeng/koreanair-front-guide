import { call, put, takeLatest, select } from 'redux-saga/effects';
import * as actionType from './constants';
import * as actions from './actions';
import { makeConcurrentMessage } from '../utils';
import { defaultAxios } from 'utils/AxiosFunc';

function* getMitigationDetail(action) {
  console.log(action, 'callAPI');
  const { id } = action.payload;

  const response = yield call(defaultAxios.get, { url: `/api/ke/audit/v1/mitigation/${id}` });
  if (response.status === 200) {
    const { data } = response.data;
    const detail = data.detail;
    const finding = data.finding;
    detail.finding = finding;
    yield put(actions.successGetMitigationDetail(detail, data.concurrent));

    if (data.concurrent) {
      yield put(actions.setResponseMessage(makeConcurrentMessage(data.connectionCheck)));
    }
  }
}

function* saveMitigationDetail(action) {
  const { id, detail } = action.payload;
  const response = yield call(defaultAxios.put, {
    url: `/api/ke/audit/v1/mitigation/${id}?submit=false`,
    payload: { detail },
  });
  if (response.status === 200) {
    const message = {
      content: `성공적으로 저장했습니다.`,
      messageType: 'success',
      target: 'save',
    };
    yield put(actions.setResponseMessage(message));
  } else {
    const message = {
      content: `저장중 에러가 발생했습니다.`,
      messageType: 'error',
      target: 'save',
    };
    yield put(actions.setResponseMessage(message));
  }
}

function* submitMitigationDetail(action) {
  const { id, detail } = action.payload;
  const response = yield call(defaultAxios.put, {
    url: `/api/ke/audit/v1/mitigation/${id}?submit=true`,
    payload: { detail },
  });
  if (response.status === 200) {
    const message = {
      content: `조치사항 결과를 제출했습니다.`,
      messageType: 'success',
      target: 'submit',
    };
    yield put(actions.setResponseMessage(message));
  } else {
    const message = {
      content: `제출중 에러가 발생했습니다.`,
      messageType: 'error',
      target: 'error',
    };
    yield put(actions.setResponseMessage(message));
  }
}

export default function* writeAuditMitigationSaga() {
  yield takeLatest(actionType.GET_MITIGATION_DETAIL, getMitigationDetail);
  yield takeLatest(actionType.SAVE_MITIGATION_DETAIL, saveMitigationDetail);
  yield takeLatest(actionType.SUBMIT_MITIGATION_DETAIL, submitMitigationDetail);
}
