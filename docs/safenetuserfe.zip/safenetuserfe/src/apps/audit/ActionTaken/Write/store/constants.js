const prefix = 'apps/audit/Mitigation/Write';

export const RESET_STATE_VALUE = `${prefix}/RESET_STATE_VALUE`;

export const GET_MITIGATION_DETAIL = `${prefix}/GET_MITIGATION_DETAIL`;
export const SUCCESS_GET_MITIGATION_DETAIL = `${prefix}/SUCCESS_GET_MITIGATION_DETAIL`;

export const SET_RESPONSE_MESSAGE = `${prefix}/SET_RESPONSE_MESSAGE`;

export const SAVE_MITIGATION_DETAIL = `${prefix}/SAVE_MITIGATION_DETAIL`;

export const SUBMIT_MITIGATION_DETAIL = `${prefix}/SUBMIT_MITIGATION_DETAIL`;
