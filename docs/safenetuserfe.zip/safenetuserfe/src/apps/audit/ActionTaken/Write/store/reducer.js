import { fromJS } from 'immutable';
import * as actionType from './constants';
import { initialMessageObj } from 'hooks/useAntdMessage';

const initialState = fromJS({
  detail: {},
  messageObj: initialMessageObj,
  isLoaded: false,
  concurrent: false,
});

const writeAuditMitigationRecucer = (state = initialState, action) => {
  const { payload } = action;
  switch (action.type) {
    case actionType.GET_MITIGATION_DETAIL:
      return state.set('isLoaded', false);
    case actionType.SUCCESS_GET_MITIGATION_DETAIL:
      return state
        .set('isLoaded', true)
        .set('detail', fromJS(payload))
        .set('concurrent', action.concurrent);
    case actionType.SET_RESPONSE_MESSAGE:
      return state.set('messageObj', fromJS(payload));
    case actionType.RESET_STATE_VALUE:
      return initialState;
    default:
      return state;
  }
};

export default writeAuditMitigationRecucer;
