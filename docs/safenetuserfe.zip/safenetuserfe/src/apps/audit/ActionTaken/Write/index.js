import React, { useEffect } from 'react';
import { Row, Col, Form, Spin, Button, Modal } from 'antd';

import StyledAudit from 'style/styledAudit';
import { WithStateManagement } from 'utils/stateUtils';
import { createStructuredSelector } from 'reselect';
import usePageConnectionCheck from 'hooks/usePageConnectionCheck';
import PageExpiryTimer from 'components/PageExpiryTimer';
import reducer from './store/reducer';
import saga from './store/saga';
import * as actions from './store/actions';
import * as selectors from './store/selectors';
import useAntdMessage from 'hooks/useAntdMessage';
import { FINDING_MAPPER } from 'apps/audit/MyAudit/Write/store/constants';
import FindingsItem from 'apps/audit/MyAudit/Write/Components/FindingsItem';
import { extractMitigationDetail } from './utils';

const { confirm } = Modal;
const CONNECTION_KEY = 'AUDIT_ACTION_TAKEN';
const WriteAuditMitigation = ({
  detail,
  isLoaded,
  messageObj,
  basePath,
  getMitigationDetail,
  saveMitigationDetail,
  submitMitigationDetail,
  match,
  history,
  resetStateValue,
  concurrent,
}) => {
  const { auditNo, findingType, phase, stepCode } = detail;
  const renderFooter =
    phase === 'mitigation_result' && (stepCode === 'draft' || stepCode === 'rejected') && !concurrent;
  const disabled = !renderFooter;
  const [form] = Form.useForm();
  usePageConnectionCheck({
    connectionKey: CONNECTION_KEY,
    id: match.params.id,
    disabled: disabled,
  });
  useEffect(() => {
    const target = messageObj.get('target');
    if (target !== '' && target === 'submit') {
      history.replace(basePath);
    }
  }, [messageObj]);

  useAntdMessage(messageObj);
  useEffect(() => {
    const {
      params: { id },
    } = match;
    if (isNaN(id)) {
      history.replace(basePath);
    } else {
      getMitigationDetail({ id });
    }
    return () => {
      resetStateValue();
    };
  }, []);
  const handleClickAction = data => {
    //TODO doc no 클릭시 추가처리
    console.log('??', data);
  };
  const handleClickSave = () => {
    const {
      params: { id },
    } = match;

    const data = form.getFieldsValue(true);
    const detail = extractMitigationDetail(data.finding);
    saveMitigationDetail({ detail, id });
  };
  const handleFinish = () => {
    const {
      params: { id },
    } = match;
    const data = form.getFieldsValue(true);
    const detail = extractMitigationDetail(data.finding);
    submitMitigationDetail({ detail, id });
  };

  return (
    <StyledAudit className="keWrap">
      {!disabled && (
        <PageExpiryTimer maxSecond={1200} callbackOnExpired={() => history.replace(basePath)}></PageExpiryTimer>
      )}
      <section className="chapter-container">
        {isLoaded ? (
          <>
            <section className="search-container">
              <Row gutter={[16, 16]} align="middle">
                <Col xs={24} sm={4} lg={3} className="search-label">
                  Audit No.
                </Col>
                <Col xs={24} sm={10} lg={6} className="search-input">
                  <span>{auditNo}</span>
                </Col>
              </Row>
            </section>
            <Form
              form={form}
              labelCol={{ xs: 24, md: 6, lg: 5, xl: 4 }}
              wrapperCol={{ xs: 24, md: 18, lg: 19, xl: 20 }}
              initialValues={detail}
              onFinish={handleFinish}
            >
              <Form.List name={'finding'}>
                {fields => (
                  <>
                    <h2>{FINDING_MAPPER[findingType].name}</h2>
                    <section className={FINDING_MAPPER[findingType].className}>
                      {fields.map(field => {
                        const basePath = ['finding', field.name];
                        return (
                          <Form.Item key={field.key} shouldUpdate={true} noStyle>
                            {({ getFieldValue }) => {
                              return (
                                <FindingsItem
                                  {...field}
                                  basePath={basePath}
                                  item={getFieldValue(basePath)}
                                  useForceRender={false}
                                  useMitigation={true}
                                  defaultExpand={true}
                                  disabled={disabled}
                                  page="mitigation"
                                  onClickAction={handleClickAction}
                                />
                              );
                            }}
                          </Form.Item>
                        );
                      })}
                    </section>
                  </>
                )}
              </Form.List>
            </Form>
            {renderFooter && (
              <section className="chapter-footer justify">
                <div className="buttonGroup"></div>
                <div className="buttonGroup">
                  <Button onClick={handleClickSave}>Save</Button>
                  <Button
                    type="primary"
                    onClick={() =>
                      confirm({
                        title: '조치사항을 제출하시겠습니까?',
                        content: '이후 수정이 불가합니다.',
                        onOk: () => form.submit(),
                      })
                    }
                  >
                    Submit
                  </Button>
                </div>
              </section>
            )}
          </>
        ) : (
          <Spin tip="Loading..."></Spin>
        )}
      </section>
    </StyledAudit>
  );
};

const mapStateToProps = createStructuredSelector({
  detail: selectors.selectMitigationDetail(),
  isLoaded: selectors.selectIsLoaded(),
  messageObj: selectors.selectMessageObj(),
  concurrent: selectors.selectConcurrent(),
});

const mapDispatchToProps = dispatch => ({
  getMitigationDetail: payload => dispatch(actions.getMitigationDetail(payload)),
  saveMitigationDetail: payload => dispatch(actions.saveMitigationDetail(payload)),
  submitMitigationDetail: payload => dispatch(actions.submitMitigationDetail(payload)),
  resetStateValue: () => dispatch(actions.resetStateValue()),
});

export default WithStateManagement(WriteAuditMitigation, {
  mapStateToProps,
  mapDispatchToProps,
  key: 'writeAuditMitigation',
  reducer,
  saga,
  useRouter: true,
});
