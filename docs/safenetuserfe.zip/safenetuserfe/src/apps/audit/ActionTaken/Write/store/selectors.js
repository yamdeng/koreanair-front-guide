import { createSelector } from 'reselect';

const getWriteMitigation = state => state.get('writeAuditMitigation');

const selectMitigationDetail = () => createSelector(getWriteMitigation, state => state.get('detail').toJS());
const selectConcurrent = () => createSelector(getWriteMitigation, state => state.get('concurrent'));
const selectIsLoaded = () => createSelector(getWriteMitigation, state => state.get('isLoaded'));
const selectMessageObj = () => createSelector(getWriteMitigation, state => state.get('messageObj'));

export { selectMitigationDetail, selectIsLoaded, selectMessageObj, selectConcurrent };
