import { intlObj } from 'utils/commonUtils';

export const extractMitigationDetail = finding => {
  try {
    return finding[0].mitigation[0];
  } catch {}
  return {};
};

export const makeConcurrentMessage = data => {
  const messageObj = {
    content: `${intlObj.formatDynamic(data, 'name')} (${data.empNo})님이 편집 하고 있어, View 모드로 표시합니다.`,
    target: 'concurrent',
    messageType: 'error',
  };
  return messageObj;
};
