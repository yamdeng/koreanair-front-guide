# BizMicro-User-Front

STG 브랜치는 개발 브랜치와 별개로 커밋바랍니다.

1. 각자 브랜치에서 개발
2. 개발 브랜치(master)에 커밋 후 테스트
3. 테스트 완료 시 각자 브랜치에서 stg로 커밋
   - master -> stg 아님

Deployed by ALM