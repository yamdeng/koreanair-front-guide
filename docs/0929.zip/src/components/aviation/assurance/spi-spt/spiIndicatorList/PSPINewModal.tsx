import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppSelect from '@/components/common/AppSelect';
import AppTextArea from '@/components/common/AppTextArea';
import AppTextInput from '@/components/common/AppTextInput';
import Code from '@/config/Code';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';
import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import { useImmer } from 'use-immer';
import * as yup from 'yup';

const yupFormSchema = yup.object({
  spiYear: yup.string().required(),
  spiCd: yup.string().required().max(50, '50자 이내로 작성해주세요.'),
  spiNm: yup.string().required().max(50, '50자 이내로 작성해주세요.'),
  spiTypeCd: yup.string().required(),
  spiTaxonomyCd: yup.string().required(),
  spiOutputStndCd: yup.string().required(),
  spiDescrCn: yup.string().max(500, '500자 이내로 작성해주세요.'),
  dataSourcesCd: yup.string().max(50, '50자 이내로 작성해주세요.'),
  spiCautionScore: yup.number().nullable().min(0, '최소값은 0입니다.'),
  spiWarnScore: yup.number().nullable().min(0, '최소값은 0입니다.'),
  spiCriticalScore: yup.number().nullable().min(0, '최소값은 0입니다.'),
  spiTargetScore: yup.number().nullable().min(0, '최소값은 0입니다.'),
  useYn: yup.string().required(),
  viewSn: yup.number().required().min(0, '최소값은 0입니다.'),
});
const initFormValue = {
  spiYear: '',
  spiCd: '',
  spiNm: '',
  spiTypeCd: '',
  spiTaxonomyCd: '',
  spiOutputStndCd: '',
  spiDescrCn: '',
  dataSourcesCd: '',
  spiCautionScore: null,
  spiWarnScore: null,
  spiCriticalScore: null,
  spiTargetScore: null,
  useYn: 'Y',
  viewSn: 1,
};

const formName = 'PSPINewModal';

function PSPINewModal(props) {
  const { isOpen, closeModal, ok, searchInfo, rowData } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});

  const {
    spiYear,
    spiCd,
    spiNm,
    spiTypeCd,
    spiTaxonomyCd,
    spiOutputStndCd,
    spiDescrCn,
    spiCautionScore,
    spiWarnScore,
    spiCriticalScore,
    spiTargetScore,
    useYn,
    viewSn,
  } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
  };

  const handleOk = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;

    if (success) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          if (Object.keys(rowData).length != 0) {
            await ApiService.put(`avn/assurance/spi-spt/indicators/${rowData.spiCode}`, formValue).then((apiResult) => {
              ToastService.success('저장되었습니다.');
              ok(formValue);
            });
          } else {
            await ApiService.post(`avn/assurance/spi-spt/indicators`, formValue).then((apiResult) => {
              const detailInfo = apiResult.data;
              if (detailInfo) {
                ToastService.error(detailInfo);
              } else {
                ToastService.success('저장되었습니다.');
                ok(formValue);
              }
            });
          }
        },
      });
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  const handleClose = () => {
    setFormValue({ ...initFormValue });
    closeModal();
  };

  useEffect(() => {
    if (isOpen && searchInfo) {
      // const { loadYear, loadSpiType, createYear } = searchInfo;
      const { spiTypeCd, spiYear } = searchInfo;
      changeInput('spiYear', spiYear);
      changeInput('spiTypeCd', spiTypeCd);
    }

    if (isOpen && Object.keys(rowData).length != 0) {
      setFormValue({ ...rowData });
    }
  }, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'alert-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">지표 신규</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              <div className="editbox">
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppDatePicker
                        id="PSPINewModalspiYear"
                        label="생산연도"
                        value={spiYear}
                        pickerType="year"
                        required
                        disabled
                        errorMessage={errors.spiYear}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        id="PSPINewModalspiTypeCd"
                        label={'지표구분'}
                        codeGrpId="CODE_GRP_113"
                        required
                        disabled
                        value={spiTypeCd}
                        errorMessage={errors.spiTypeCd}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        id="PSPINewModalspiTaxonomyCd"
                        label={'지표분류'}
                        codeGrpId="CODE_GRP_114"
                        required
                        value={spiTaxonomyCd}
                        onChange={(value) => changeInput('spiTaxonomyCd', value)}
                        errorMessage={errors.spiTaxonomyCd}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppCodeSelect
                        id="PSPINewModalspiOutputStndCd"
                        label={'산출기준'}
                        codeGrpId="CODE_GRP_116"
                        required
                        value={spiOutputStndCd}
                        onChange={(value) => changeInput('spiOutputStndCd', value)}
                        errorMessage={errors.spiOutputStndCd}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="PSPINewModalspiCd"
                        label="지표코드"
                        placeholder="지표코드를 입력해 주세요"
                        required
                        disabled={rowData.spiCd ? true : false}
                        value={spiCd}
                        onChange={(value) => changeInput('spiCd', value.toUpperCase())}
                        errorMessage={errors.spiCd}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="PSPINewModalspiNm"
                        label={'지표명'}
                        placeholder="지표명을 입력해 주세요"
                        required
                        value={spiNm}
                        onChange={(value) => changeInput('spiNm', value)}
                        errorMessage={errors.spiNm}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextArea
                        id="PSPINewModalspiDescrCn"
                        label="지표정의"
                        value={spiDescrCn}
                        onChange={(value) => changeInput('spiDescrCn', value)}
                        errorMessage={errors.spiDescrCn}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <AppTextInput
                        id="PSPINewModalspiCautionScore"
                        inputType="number"
                        label="주의"
                        value={spiCautionScore}
                        onChange={(value) => changeInput('spiCautionScore', value)}
                        errorMessage={errors.spiCautionScore}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="PSPINewModalspiWarnScore"
                          inputType="number"
                          label="경계"
                          value={spiWarnScore}
                          onChange={(value) => changeInput('spiWarnScore', value)}
                          errorMessage={errors.spiWarnScore}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="PSPINewModalspiCriticalScore"
                          inputType="number"
                          label="심각"
                          value={spiCriticalScore}
                          onChange={(value) => changeInput('spiCriticalScore', value)}
                          errorMessage={errors.spiCriticalScore}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="PSPINewModalspiTargetScore"
                          inputType="number"
                          label="목표치(SPT)"
                          placeholder="목표치(SPT)를 입력해 주세요"
                          value={spiTargetScore}
                          onChange={(value) => changeInput('spiTargetScore', value)}
                          errorMessage={errors.spiTargetScore}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="PSPINewModalviewSn"
                          inputType="number"
                          label="표시 순서"
                          required
                          placeholder="순서를 입력해 주세요"
                          value={viewSn}
                          onChange={(value) => changeInput('viewSn', value)}
                          errorMessage={errors.viewSn}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <hr className="line"></hr>
                <div className="form-table">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="form-group wid100">
                        <AppSelect
                          id="PSPINewModaluseYn"
                          name="useYn"
                          label="사용여부"
                          options={Code.useYn}
                          value={useYn}
                          onChange={(appSelectValue) => {
                            changeInput('useYn', appSelectValue);
                          }}
                          required
                          errorMessage={errors.useYn}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line"></hr>
              </div>
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleOk}>
            {rowData.spiCd ? '수정' : '저장'}
          </button>
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            닫기
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default PSPINewModal;
