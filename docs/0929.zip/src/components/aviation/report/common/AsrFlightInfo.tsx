import AppDatePicker from '@/components/common/AppDatePicker';
import AppSelect from '@/components/common/AppSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppSearchInput from '@/components/common/AppSearchInput';
import AirportSearch from '../../common/AirportSearch';
import AppTimePicker from '@/components/common/AppTimePicker';
import AppTextInput from '@/components/common/AppTextInput';
import AvnReportUserSelectType2 from '../../common/AvnReportUserSelectType2';

function AsrFlightInfo({ store = {} }) {
  const {
    changeStateProps,
    changeInput,
    formValue,
    searchFligh,
    onSelectFlightCrewList,
    deleteFlightCrewList,
    userSelectKind,
    errors,
  } = store as any;
  const { flight, flightCrew } = formValue;

  const {
    departureDt,
    flightNo,
    regNo,
    aircraftTypeCd,
    departureAirportCd,
    arrivalAirportCd,
    divertAirportCd,
    stdTime,
    staTime,
    atdTime,
    ataTime,
    delayedMinCo,
    supplyNm,
    checkinNm,
  } = flight;

  return (
    <div className="edit-area">
      <div className="detail-form">
        <div className="detail-list">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <div className="df">
                  <div className="type3">
                    <AppDatePicker
                      label="출발일자"
                      valueFormat="YYYYMMDD"
                      value={departureDt}
                      onChange={(value) => {
                        changeInput('flight.departureDt', value);
                      }}
                      required
                      errorMessage={errors['flight.departureDt']}
                    />
                  </div>
                  <div className="type4">
                    <AppSelect disabled value="UTC" />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group va-t ant-input wid100">
                <span className="ant-input-group-addon1">KE</span>
                <div className="ant-input-group-addon1-input wid50 df">
                  {/*비행편명 */}
                  <AppSearchInput
                    label="비행편명"
                    value={flightNo}
                    onChange={(value) => {
                      changeInput('flight.flightNo', value);
                    }}
                    search={searchFligh}
                    required
                    hiddenClearButton
                    errorMessage={errors['flight.flightNo']}
                  />
                  <div className="btn-area">
                    <button
                      type="button"
                      name="button"
                      className="btn-sm btn_text btn-darkblue-line"
                      onClick={searchFligh}
                    >
                      Search
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group va-t ant-input wid100">
                <span className="ant-input-group-addon1">HL</span>
                <div className="ant-input-group-addon1-input wid50">
                  {/*등록기호 */}
                  <AppTextInput
                    label="등록부호"
                    value={regNo}
                    onChange={(value) => {
                      changeInput('flight.regNo', value);
                    }}
                    required
                    errorMessage={errors['flight.regNo']}
                  />
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*항공기형식 */}
                <AppCodeSelect
                  label="항공기형식"
                  codeGrpId="CODE_GRP_159"
                  value={aircraftTypeCd}
                  onChange={(value) => {
                    changeInput('flight.aircraftTypeCd', value);
                  }}
                  required
                  errorMessage={errors['flight.aircraftTypeCd']}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*출발공항 */}
                <AirportSearch
                  label="출발공항"
                  value={departureAirportCd}
                  onChange={(value) => {
                    changeInput('flight.departureAirportCd', value);
                  }}
                  required
                  errorMessage={errors['flight.departureAirportCd']}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AirportSearch
                  label="도착공항"
                  value={arrivalAirportCd}
                  onChange={(value) => {
                    changeInput('flight.arrivalAirportCd', value);
                  }}
                  required
                  errorMessage={errors['flight.arrivalAirportCd']}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*회항공항 */}
                <AirportSearch
                  label="회항공항"
                  value={divertAirportCd}
                  onChange={(value) => {
                    changeInput('flight.divertAirportCd', value);
                  }}
                  errorMessage={errors['flight.divertAirportCd']}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*STD */}
                <AppTimePicker
                  label={'STD'}
                  excludeSecondsTime
                  value={stdTime}
                  valueFormat="HHmm"
                  displayFormat="HH:mm"
                  onChange={(value) => {
                    changeInput('flight.stdTime', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*STA */}
                <AppTimePicker
                  label={'STA'}
                  excludeSecondsTime
                  value={staTime}
                  valueFormat="HHmm"
                  displayFormat="HH:mm"
                  onChange={(value) => {
                    changeInput('flight.staTime', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*ATD */}
                <AppTimePicker
                  label={'ATD'}
                  excludeSecondsTime
                  value={atdTime}
                  valueFormat="HHmm"
                  displayFormat="HH:mm"
                  onChange={(value) => {
                    changeInput('flight.atdTime', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*ATA */}
                <AppTimePicker
                  label={'ATA'}
                  excludeSecondsTime
                  value={ataTime}
                  valueFormat="HHmm"
                  displayFormat="HH:mm"
                  onChange={(value) => {
                    changeInput('flight.ataTime', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*Delay */}
                <AppTextInput
                  inputType={'number'}
                  label="Delay"
                  value={delayedMinCo}
                  onChange={(value) => {
                    changeInput('flight.delayedMinCo', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="좌석수(F/C/Y)"
                  value={supplyNm}
                  onChange={(value) => {
                    changeInput('flight.supplyNm', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="탑승자(F/C/Y)"
                  value={checkinNm}
                  onChange={(value) => {
                    changeInput('flight.checkinNm', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid50">
                <AvnReportUserSelectType2
                  label="비행승무원"
                  userList={flightCrew}
                  onSelect={onSelectFlightCrewList}
                  deleteUser={deleteFlightCrewList}
                  changeUserSelectKind={(value) => changeStateProps('userSelectKind', value)}
                  userSelectKind={userSelectKind}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AsrFlightInfo;
