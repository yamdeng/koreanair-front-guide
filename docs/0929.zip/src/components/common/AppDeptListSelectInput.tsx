import { useState, useEffect, useCallback } from 'react';
// import UserSelectModal from '../modal/UserSelectModal';
import DeptListModal from '../modal/DeptListModal';
import UserSelectWithOrgTreeModal from '../modal/UserSelectWithOrgTreeModal';
import AppSearchInput from './AppSearchInput';
import ApiService from '@/services/ApiService';

function AppDeptListSelectInput(props) {
  const { value, onChange, withOrgTree = false, ...rest } = props;
  const [isDeptSelectModalopen, setIsDeptSelectModalopen] = useState(false);
  const [selectDeptInfo, setSelectDeptInfo] = useState(null);

  console.log('props: ', props);
  const clearHandler = () => {
    onChange(null);
    setSelectDeptInfo(null);
  };

  const handleOrgSelectModal = (selectedValue) => {
    console.log('핸들러');
    if (selectedValue) {
      setSelectDeptInfo(selectedValue);
      onChange(selectedValue.deptCd, selectedValue);
    }
    setIsDeptSelectModalopen(false);
  };

  const searchInputValue = selectDeptInfo ? selectDeptInfo.nameKor : '';

  const searchDept = useCallback(
    async (deptCd) => {
      console.log('우리쪽 조회');
      const apiUrl = 'com/deptList/' + deptCd;
      const apiResult = await ApiService.get(apiUrl);
      const data = apiResult.data;
      setSelectDeptInfo(data);
    },
    [value]
  );

  useEffect(() => {
    if (value) {
      searchDept(value);
    }
  }, [value]);

  return (
    <>
      <AppSearchInput
        {...rest}
        disabled
        search={() => setIsDeptSelectModalopen(true)}
        clearHandler={clearHandler}
        value={searchInputValue}
      />
      {withOrgTree ? (
        <UserSelectWithOrgTreeModal
          isOpen={isDeptSelectModalopen}
          closeModal={() => setIsDeptSelectModalopen(false)}
          isMultiple={false}
          ok={handleOrgSelectModal}
        />
      ) : (
        // <UserSelectModal
        <DeptListModal
          isOpen={isDeptSelectModalopen}
          closeModal={() => setIsDeptSelectModalopen(false)}
          isMultiple={false}
          // A: 전체, O: 산업안전
          gudun={props.gudun}
          // 레벨 (레벨에 부서 출력)
          level={props.level}
          // 부서 코드 (LEVEL과 세트)
          dept={props.dept}
          // 현재 레벨 U: 상위부서, D: 하위부서, '': 내 부서만
          division={props.division}
          ok={handleOrgSelectModal}
        />
      )}
    </>
  );
}

export default AppDeptListSelectInput;
