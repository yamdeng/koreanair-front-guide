import CommonUtil from '@/utils/CommonUtil';
import classNames from 'classnames';
import CommonInputError from './CommonInputError';
import CommonInputToolTip from './CommonInputToolTip';
import InputMask from 'react-input-mask';

function AppMaskInput(props) {
  const {
    id = CommonUtil.getUUID(),
    name = '',
    mask = '9999999',
    maskChar = '',
    label,
    value,
    onChange,
    placeholder = '',
    required = false,
    errorMessage,
    disabled = false,
    style = {},
    hiddenClearButton = false,
    toolTipMessage = '',
    ...rest
  } = props;

  let isActiveClass = false;
  if (placeholder) {
    isActiveClass = true;
  }
  const applyClassName = classNames('form-tag', {
    error: errorMessage,
    active: isActiveClass,
  });

  return (
    <>
      <InputMask
        id={id}
        name={name}
        style={style}
        className={applyClassName}
        mask={mask}
        maskChar={maskChar}
        value={value}
        onChange={(event) => {
          onChange(event.target.value, event);
        }}
        {...rest}
      />
      <label className="f-label" htmlFor={id} style={{ display: label ? '' : 'none' }}>
        {label} {required ? <span className="required">*</span> : null}
        <CommonInputToolTip toolTipMessage={toolTipMessage} />
      </label>
      {disabled || hiddenClearButton || !value ? null : (
        <button className="btnclear" onClick={() => onChange('')}></button>
      )}
      <CommonInputError errorMessage={errorMessage} label={label} />
    </>
  );
}

export default AppMaskInput;
