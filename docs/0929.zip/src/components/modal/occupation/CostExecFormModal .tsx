import AppTextInput from '@/components/common/AppTextInput';
//import useSysCodeFormStore from '@/stores/admin/useSysCodeFormStore';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppSelect from '@/components/common/AppSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';

import { useOcuCostModalFormStore } from '@/stores/occupation/general/useOcuCostFormStore';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDeptListSelectInput from '@/components/common/AppDeptListSelectInput';

//import useOcuCostFormStore from '@/stores/occupation/general/useOcuCostFormStore';

import Modal from 'react-modal';

function CostExecFormModal(props) {
  const { isOpen, closeModal, ok } = props;

  const { formValue, errors, changeInput, save } = useOcuCostModalFormStore();

  const {
    // 년도
    planYear,
    // 부문명
    sectNm,
    // Resp Center
    respCenter,
    // Cost Center
    costCenter,
    // Account Name
    acntNm,
    // Account Cd
    acntCd,
    // Invoice Date
    invoiceDt,
    // Invoice Number
    invoiceNo,
    // Amount
    drAmt,
    // Supplier
    vendorNm,
    // GL Date
    glDt,
    // Description
    execLineDesc,
    // 등록자
    regDttm,
    // 등록일자
    regUserId,
    // 저장 구분 값
    saveGubun,
    // 실적 구분 값
    execClsCd,
    // 부문 코드
    sectCd,
  } = formValue;

  console.log('formValue==??>', formValue);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'middle-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">실적 등록</h3>
        <div className="pop_lg_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              {/*등록 */}
              <div className="editbox">
                <div className="form-table">
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppDatePicker
                          label={'년도'}
                          pickerType="year"
                          value={planYear}
                          onChange={(value) => changeInput('planYear', value)}
                          required
                          disabled
                          errorMessage={errors.planYear}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="구분"
                          value={execClsCd}
                          codeGrpId="CODE_GRP_OC049"
                          onChange={(value) => changeInput('execClsCd', value)}
                          required
                          disabled
                          errorMessage={errors.execClsCd}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="부문"
                          value={sectCd}
                          codeGrpId="CODE_GRP_OC001"
                          onChange={(value) => changeInput('sectCd', value)}
                          required
                          disabled
                          errorMessage={errors.sectCd}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <hr className="line dp-n"></hr>
                <div className="form-table line">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      {/* <AppSelect
                        label="Cost Center"
                        value={costCenter}
                        onChange={(value) => changeInput('costCenter', value)}
                        required
                        disabled
                        errorMessage={errors.costCenter}
                      /> */}

                      <AppSelect
                        label="Resp Center"
                        value={respCenter}
                        onChange={(value) => changeInput('respCenter', value)}
                        required
                        disabled
                        errorMessage={errors.respCenter}
                      />
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDeptListSelectInput
                        label="Cost Center"
                        value={costCenter}
                        onChange={(value) => changeInput('costCenter', value)}
                        gudun="O"
                        dept="SELDC"
                        division="D"
                        required
                        //disabled
                        errorMessage={errors.costCenter}
                      />
                      {/* <AppSelect
                        label="Account Name"
                        value={acntNm}
                        onChange={(value) => changeInput('acntNm', value)}
                        required
                        disabled
                        errorMessage={errors.acntNm}
                      /> */}
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker
                        label={'GL date'}
                        value={glDt}
                        onChange={(value) => changeInput('glDt', value)}
                        required
                        disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.glDt}
                      />
                      {/* <AppTextInput
                        label="Account"
                        value={acntCd}
                        onChange={(value) => changeInput('acntCd', value)}
                        required
                        disabled
                        errorMessage={errors.acntCd}
                      /> */}
                    </div>
                  </div>
                </div>
                <hr className="line dp-n"></hr>
                <div className="form-table line">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppSelect
                        label="Account Name"
                        value={acntNm}
                        onChange={(value) => changeInput('acntNm', value)}
                        required
                        disabled
                        errorMessage={errors.acntNm}
                      />
                      {/* <AppDatePicker
                        label={'Invoice date'}
                        value={invoiceDt}
                        onChange={(value) => changeInput('invoiceDt', value)}
                        required
                        errorMessage={errors.invoiceDt}
                      /> */}
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="Account"
                        value={acntCd}
                        onChange={(value) => changeInput('acntCd', value)}
                        required
                        disabled
                        errorMessage={errors.acntCd}
                      />
                      {/* <AppTextInput
                        label="Invoice Number"
                        value={invoiceNo}
                        onChange={(value) => changeInput('invoiceNo', value)}
                        required
                        errorMessage={errors.invoiceNo}
                      /> */}
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker
                        label={'Invoice date'}
                        value={invoiceDt}
                        onChange={(value) => changeInput('invoiceDt', value)}
                        required
                        //disabled
                        errorMessage={errors.invoiceDt}
                        disabled={formValue.execClsCd === 'B' ? false : true}
                      />
                      {/* <AppTextInput
                        label="Amount"
                        value={drAmt}
                        onChange={(value) => changeInput('drAmt', value)}
                        required
                        errorMessage={errors.drAmt}
                      /> */}
                    </div>
                  </div>
                </div>
                <hr className="line dp-n"></hr>
                <div className="form-table line">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="Invoice Number"
                        value={invoiceNo}
                        onChange={(value) => changeInput('invoiceNo', value)}
                        required
                        disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.invoiceNo}
                      />
                      {/* <AppTextInput
                        label="Supplier"
                        value={vendorNm}
                        onChange={(value) => changeInput('vendorNm', value)}
                        required
                        errorMessage={errors.vendorNm}
                      /> */}
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="Amount"
                        value={drAmt}
                        inputType="number"
                        onChange={(value) => changeInput('drAmt', value)}
                        required
                        disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.drAmt}
                      />
                      {/* <AppDatePicker
                        label={'GL date'}
                        value={glDt}
                        onChange={(value) => changeInput('glDt', value)}
                        required
                        errorMessage={errors.glDt}
                      /> */}
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="Supplier"
                        value={vendorNm}
                        onChange={(value) => changeInput('vendorNm', value)}
                        //required
                        disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.vendorNm}
                      />
                      {/* <AppTextInput
                        label="Description"
                        value={execIneDesc}
                        onChange={(value) => changeInput('execIneDesc', value)}
                        required
                        errorMessage={errors.execIneDesc}
                      /> */}
                    </div>
                  </div>
                </div>
                <hr className="line dp-n"></hr>
                <div className="form-table line">
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="Description"
                        value={execLineDesc}
                        onChange={(value) => changeInput('execLineDesc', value)}
                        //required
                        disabled={formValue.execClsCd === 'B' ? false : true}
                        errorMessage={errors.execLineDesc}
                      />
                      {/* <AppTextInput
                        label="등록자"
                        value={regUserId}
                        onChange={(value) => changeInput('regUserId', value)}
                        required
                        disabled
                        errorMessage={errors.regUserId}
                      /> */}
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppTextInput
                        label="등록자"
                        value={regUserId}
                        onChange={(value) => changeInput('regUserId', value)}
                        required
                        disabled
                        errorMessage={errors.regUserId}
                      />
                      {/* <AppDatePicker
                        label={'등록일자'}
                        value={regDttm}
                        onChange={(value) => changeInput('regDttm', value)}
                        required
                        disabled
                        errorMessage={errors.regDttm}
                      /> */}
                    </div>
                  </div>
                  <div className="form-cell wid50">
                    <div className="form-group wid100">
                      <AppDatePicker
                        label={'등록일자'}
                        value={regDttm}
                        onChange={(value) => changeInput('regDttm', value)}
                        required
                        disabled
                        errorMessage={errors.regDttm}
                      />
                    </div>
                  </div>
                </div>
                <hr className="line dp-n"></hr>
              </div>
              {/*//등록 */}
            </div>
          </div>
        </div>
        {/* //execClsCd */}
        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            취소
          </button>
          <button
            className="btn_text text_color_neutral-10 btn_confirm"
            onClick={save}
            style={{ display: formValue.execClsCd === 'B' ? '' : 'none' }}
          >
            저장
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default CostExecFormModal;
