import AppTextInput from '@/components/common/AppTextInput';
//import useSysCodeFormStore from '@/stores/admin/useSysCodeFormStore';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppDatePicker from '@/components/common/AppDatePicker';

import useOcuRiskTab3FormStore from '@/stores/occupation/risk/useOcuRiskTab3FormStore';

import Modal from 'react-modal';

function RiskHelpPeriodModal(props) {
  const { isOpen, closeModal, ok } = props;

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'alert-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">중대성 안내</h3>

        <div className="pop_cont">
          <div className="guide-table-box">
            <table className="guide-table">
              <colgroup>
                <col width="15%" />
                <col width="15%" />
                <col width="15%" />
                <col width="*" />
              </colgroup>
              <thead>
                <tr>
                  <th>구분</th>
                  <th colSpan={2}>중대성</th>
                  <th>내용</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>최대</td>
                  <td>사망</td>
                  <td>4</td>
                  <td>사망재해</td>
                </tr>
                <tr>
                  <td>대</td>
                  <td>장애발생</td>
                  <td>3</td>
                  <td>휴업 1월 이상인 재해</td>
                </tr>
                <tr>
                  <td>중</td>
                  <td>병원치료</td>
                  <td>2</td>
                  <td>휴업 1월 미만인 재해</td>
                </tr>
                <tr>
                  <td>소</td>
                  <td>비치료</td>
                  <td>1</td>
                  <td>휴업이 수반되지 않은 재해</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default RiskHelpPeriodModal;
