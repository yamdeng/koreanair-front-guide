import Modal from 'react-modal';
import { useEffect, useState } from 'react';
import OcuWorkPermitLocationRegisterModalStore from '@/stores/occupation/management/useOcuWorkPermitLocationRegisterModalStore';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppSelect from '@/components/common/AppSelect';
import AppTable from '@/components/common/AppTable';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppTextInput from '@/components/common/AppTextInput';
import AppSearchInput from '@/components/common/AppSearchInput';

function WorkPermitLocationRegisterModal(props) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [columns, setColumns] = useState([
    { field: 'cntrLocationNm', headerName: '공사장소명' },
    { field: 'useYn', headerName: '사용여부' },
  ]);

  const fetchData = async () => {
    try {
      const response = await fetch('ocu/management/permits/locations');
      if (!response.ok) {
        throw new Error('네트워크 응답에 문제가 있습니다.');
      }
      const result = await response.json();
      setData(result);
    } catch (error) {
      setError(error);
      console.error('데이터 가져오기 실패', error);
    }
  };

  const { isOpen, closeModal, ok, detailInfo } = props;

  const state = OcuWorkPermitLocationRegisterModalStore();

  const { setFormValue, changeSearchInput, enterSearch, clear, validate, formValue, list } = state;

  useEffect(() => {
    if (isOpen) {
      if (detailInfo) {
        const { cntrLocationNm, useYn } = detailInfo;
        setFormValue({
          cntrLocationNm: cntrLocationNm,
          useYn: useYn,
        });
      } else {
        setFormValue({
          cntrLocationNm: '',
          useYn: '',
        });
      }
      fetchData();
    }
  }, [isOpen, detailInfo]);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  const save = async () => {
    const isValid = await validate();
    if (isValid) {
      ok(formValue);
    }
  };

  const {
    //공사장소명 id
    cnstrSiteId,
    //공사장소명
    cntrLocationNm,
    //사용여부
    useYn,
  } = formValue;

  const customButtons = [
    {
      title: '추가',
      onClick: () => {
        alert('추가');
      },
    },
  ];

  const handleClose = () => {
    alert('Closing Modal');
    closeModal();
  };

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">공사장소 관리</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form pb_0">
              {/*검색영역 */}
              <div className="boxForm">
                {/*area-detail명 옆에 active  */}
                <div id="" className="area-detail active">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSearchInput
                          label="공사명"
                          value={cntrLocationNm}
                          onChange={(value) => {
                            changeSearchInput('cntrLocationNm', value);
                          }}
                          search={enterSearch}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label={'사용여부'}
                          applyAllSelect="true"
                          codeGrpId="CODE_GRP_OC047"
                          value={useYn} // 초기값 설정
                          onChange={(value) => {
                            changeSearchInput('useYn', value);
                          }}
                        />
                      </div>
                    </div>
                    <input
                      type="hidden"
                      value={cnstrSiteId}
                      // onChange={(value) => {
                      //   changeSearchInput('cnstrSiteId', value);
                      // }}
                      name="cnstrSiteId"
                    />

                    <div className="btn-area mb-10">
                      <button
                        type="button"
                        name="button"
                        className="btn-sm btn_text btn-darkblue-line"
                        onClick={enterSearch}
                      >
                        조회
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              {/* //검색영역 */}
              <div className="modal-group-box">
                {/*그리드영역 */}
                <div className="left-group">
                  <h3 className="table-tit">공사장소 조회</h3>
                  <AppTable rowData={list} columns={columns} customButtons={customButtons} />
                </div>
                {/*//그리드영역 */}
                <div className="right-group">
                  <div className="group-box mb-20">
                    <div className="ck-edit-box">
                      <div className="ck-edit">
                        <div className="boxForm">
                          <h3 className="table-tit mt-10">공사장소 등록</h3>
                          <div className="form-table">
                            <div className="form-cell wid50">
                              <div className="form-group wid100">
                                <AppTextInput label="공사장소명" />
                              </div>
                            </div>
                          </div>
                          <div className="form-table">
                            <div className="form-cell wid50">
                              <div className="form-group wid100">
                                <AppSelect label="사용여부" />
                              </div>
                            </div>
                          </div>
                          <div className="btn-area mb-10">
                            <button type="button" name="button" className="btn-big btn_confirm text_color_neutral-10">
                              등록
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="group-box mb-20">
                    <div className="ck-edit-box">
                      <div className="ck-edit">
                        <div className="boxForm">
                          <h3 className="table-tit mt-10">공사장소 수정</h3>
                          <div className="form-table">
                            <div className="form-cell wid50">
                              <div className="form-group wid100">
                                <AppTextInput label="공사장소명" />
                              </div>
                            </div>
                          </div>
                          <div className="form-table">
                            <div className="form-cell wid50">
                              <div className="form-group wid100">
                                <AppSelect label="사용여부" />
                              </div>
                            </div>
                          </div>
                          <div className="btn-area mb-10">
                            <button type="button" name="button" className="btn-big btn_confirm text_color_neutral-10">
                              저장
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}
export default WorkPermitLocationRegisterModal;
