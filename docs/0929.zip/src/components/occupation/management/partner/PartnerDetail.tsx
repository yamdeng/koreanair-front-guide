import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import CommonUtil from '@/utils/CommonUtil';
import useOcuPartnerFormStore from '@/stores/occupation/management/useOcuPartnerFormStore';
import { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';

function OcuPartnerInfoDetail() {
  const {
    getDetail,
    formValue,
    selectedPlaceIndex,
    setSelectedPlaceIndex,
    getPlaceColumn,
    goFormPage,
    getPlace2ndList,
    cancel,
    clear,
  } = useOcuPartnerFormStore();

  const { detailId } = useParams();

  // Grid Column  - 협력업체 사업장
  const [ocuPartnerPlaceColumns, setOcuPartnerPlaceColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'bizPlaceClsCd', headerName: '사업장분류' },
      { field: 'useSectCd', headerName: '사용부문' },
    ])
  );

  // Grid Column  - 협력업체 사업장의 2차 협력업체
  const [ocuPartner2ndInfoColumns, setOcuPartner2ndInfoColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'companyNm', headerName: '업체명' },
      { field: 'majorWorkCn', headerName: '주요업무' },
      { field: 'staffNm', headerName: '담당자명' },
      { field: 'staffContactNo', headerName: '연락처' },
    ])
  );

  const handleRowDoubleClick_OcuPartnerPlace = useCallback(
    (selectedInfo) => {
      const { rowIndex } = selectedInfo;

      if (rowIndex !== selectedPlaceIndex) {
        setSelectedPlaceIndex(rowIndex);
      }
    },
    [formValue, selectedPlaceIndex]
  );

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  // 첫번째 행 선택
  useEffect(() => {
    if (formValue?.placeList && formValue.placeList.length > 0 && selectedPlaceIndex === -1) {
      const firstRow = formValue.placeList[0];
      handleRowDoubleClick_OcuPartnerPlace({ data: firstRow, rowIndex: 0 });
    }
  }, [formValue, selectedPlaceIndex]);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>협력업체 조회</h2>
      </div>
      {/*상세페이지*/}
      <div className="editbox">
        <div className="form-table line">
          {/* <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성자</label>
                    <span className="text-desc-type1">{formValue.regUserId}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성일자</label>
                    <span className="text-desc-type1">{formValue.regDttm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div> */}
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">업체명</label>
                    <span className="text-desc-type1">{formValue.prtnrNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">사업자번호</label>
                    <span className="text-desc-type1">{formValue.bizNo}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">대표자</label>
                    <span className="text-desc-type1">{formValue.bizNo}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">업태</label>
                    <span className="text-desc-type1">{formValue.bizIndst}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">업종</label>
                    <span className="text-desc-type1">{formValue.bizType}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="ck-edit-box pd-t0">
              <div className="ck-list">
                <span className="stit-btn">
                  <h3>사업장 목록</h3>
                  {/*<button>추가</button>*/}
                </span>
                <AppTable
                  rowData={formValue.placeList || []}
                  columns={ocuPartnerPlaceColumns}
                  setColumns={setOcuPartnerPlaceColumns}
                  handleRowDoubleClick={handleRowDoubleClick_OcuPartnerPlace}
                  hiddenTableHeader={true}
                />
              </div>
              <div className="ck-edit">
                <div className="boxForm">
                  <h3 className="table-tit mt-10">사업장 상세정보</h3>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">사업장분류</label>
                              <span className="text-desc-type1">{getPlaceColumn('bizPlaceClsCd')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">사용부문</label>
                              <span className="text-desc-type1">{getPlaceColumn('useSectCd')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">관리부서</label>
                              <span className="text-desc-type1">{getPlaceColumn('mgntDeptCd')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">관리자1</label>
                              <span className="text-desc-type1">{getPlaceColumn('staffNm1')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">연락처1</label>
                              <span className="text-desc-type1">{getPlaceColumn('staffContactNo1')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">이메일1</label>
                              <span className="text-desc-type1">{getPlaceColumn('staffEmail1')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">담당업무1</label>
                              <span className="text-desc-type1">{getPlaceColumn('staffWork1')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">관리자2</label>
                              <span className="text-desc-type1">{getPlaceColumn('staffNm2')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">연락처2</label>
                              <span className="text-desc-type1">{getPlaceColumn('staffContactNo2')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">이메일2</label>
                              <span className="text-desc-type1">{getPlaceColumn('staffEmail2')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">담당업무2</label>
                              <span className="text-desc-type1">{getPlaceColumn('staffWork2')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">안전관리</label>
                              <span className="text-desc-type1">{getPlaceColumn('sftyMgnt')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">보건관리</label>
                              <span className="text-desc-type1">{getPlaceColumn('hlthMgnt')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="box-view-list">
                          <ul className="view-list">
                            <li className="accumlate-list">
                              <label className="t-label">주요업무</label>
                              <span className="text-desc-type1">{getPlaceColumn('majorWorkCn')}</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <span className="stit-btn">
                          <h3>2차 협력업체</h3>
                          {/*<button>추가</button>*/}
                        </span>
                        <AppTable
                          rowData={getPlace2ndList()} // 2nd info를 담은 리스트를 그리드에 표시
                          columns={ocuPartner2ndInfoColumns} // 2nd info의 칼럼
                          setColumns={setOcuPartner2ndInfoColumns}
                          hiddenTableHeader={true}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
      </div>
      {/*//상세페이지*/}

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          수정
        </button>
      </div>
    </>
  );
}
export default OcuPartnerInfoDetail;
