import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import CommonUtil from '@/utils/CommonUtil';
import { useOcuCheckListFormStore } from '@/stores/occupation/inspection/useOcuCheckListFormStore';

function OcuCheckListDetail() {
  const state = useOcuCheckListFormStore();
  const { formValue, detailInfo, getDetail, cancel, goFormPage, clear } = state;
  const { chkListClsCd, chkListTitle, regDttm, regUserId } = detailInfo;
  const { detailId } = useParams();

  const [ocuCheckListPlaceColumns, setOcuCheckListPlaceColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'prtnrId', headerName: '협력업체' },
      { field: 'bizPlaceId', headerName: '사업장' },
    ])
  );

  const [ocuCheckListItemColumns, setOcuCheckListItemColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'chkClsCd', headerName: '점검분류' },
      { field: 'chkItemNm', headerName: '점검항목' },
    ])
  );

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>점검표 관리</h2>
      </div>
      <div className="eidtbox">
        <div className="form-table line" style={{ display: 'flex' }}>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">등록자_ID</label>
                    <span className="text-desc-type1">{regUserId}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">등록_일시</label>
                    <span className="text-desc-type1">{regDttm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">점검표_구분_코드</label>
                    <span className="text-desc-type1">{chkListClsCd}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">점검표_제목</label>
                    <span className="text-desc-type1">{chkListTitle}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
      </div>
      <div className="eidtbox">
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="ck-edit-box pd-t0">
              <div className="ck-list">
                <span className="stit-btn">
                  <h3>점검대상</h3>
                </span>
                <AppTable
                  rowData={formValue.placeList || []}
                  columns={ocuCheckListPlaceColumns}
                  setColumns={setOcuCheckListPlaceColumns}
                  hiddenTableHeader={true}
                />
              </div>
              <div className="ck-right-list">
                <div className="ck-list">
                  <span className="stit-btn">
                    <h3>점검항목</h3>
                  </span>
                  <AppTable
                    rowData={formValue.itemList || []}
                    columns={ocuCheckListItemColumns}
                    setColumns={setOcuCheckListItemColumns}
                    hiddenTableHeader={true}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          수정
        </button>
      </div>
    </>
  );
}

export default OcuCheckListDetail;
