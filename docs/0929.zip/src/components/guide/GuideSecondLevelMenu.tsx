import AppNavigation from '../common/AppNavigation';

function GuideSecondLevelMenu() {
  return (
    <>
      <AppNavigation />
      <div>GuideSecondLevelMenu</div>
    </>
  );
}
export default GuideSecondLevelMenu;
