import AuditCheckList from '@/components/aviation/audit/checklist/AuditCheckList';
import AuditCheckListView from '@/components/aviation/audit/checklist/AuditCheckListView';
import AuditCheckListEdit from '@/components/aviation/audit/checklist/AuditCheckListEdit';

import MyAuditList from '@/components/aviation/audit/myAudit/MyAuditList';
//import MyAuditView from '@/components/aviation/audit/myAudit/MyAuditView';
import MyAuditFrame from '@/components/aviation/audit/myAudit/MyAuditFrame';

const AuditRouteInfo: any = {};

AuditRouteInfo.list = [
  {
    Component: AuditCheckList,
    path: 'audit/checklist',
  },
  {
    Component: AuditCheckListView,
    path: 'audit/checklist/:division/:checklistOrigId/:chapterOrigId',
  },
  {
    Component: AuditCheckListEdit,
    path: 'audit/checklist/:division/:checklistOrigId/:chapterOrigId/edit',
  },
  {
    Component: MyAuditList,
    path: 'audit/myAudit',
  },
  // {
  //   Component: MyAuditView,
  //   path: 'audit/myAudit/:auditId/view',
  // },
  {
    Component: MyAuditFrame,
    path: 'audit/myAudit/add',
  },
  {
    Component: MyAuditFrame,
    path: 'audit/myAudit/:auditId/edit',
  },
  {
    Component: MyAuditFrame,
    path: 'audit/myAudit/:auditId/:findingId/edit',
  },
];

export default AuditRouteInfo;
