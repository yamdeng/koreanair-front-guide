import ReportASREditForm from '@/components/aviation/report/edit/ReportASREditForm';
import ReportCSREditForm from '@/components/aviation/report/edit/ReportCSREditForm';
import ReportDSREditForm from '@/components/aviation/report/edit/ReportDSREditForm';
import ReportFOQAEditForm from '@/components/aviation/report/edit/ReportFOQAEditForm';
import ReportGSREditForm from '@/components/aviation/report/edit/ReportGSREditForm';
import ReportHZREditForm from '@/components/aviation/report/edit/ReportHZREditForm';
import ReportMSREditForm from '@/components/aviation/report/edit/ReportMSREditForm';
import ReportRSREditForm from '@/components/aviation/report/edit/ReportRSREditForm';

import ReportWriteFormMenu from '@/components/aviation/report/ReportWriteFormMenu';
import ReportWriteFormCategoryMenu from '@/components/aviation/report/ReportWriteFormCategoryMenu';

const ReportEditFormRouteInfo: any = {};

// -- ASR : ReportASREditForm : report-form/ASR/:detailId

// -- CSR > 수검 :ReportCSREditFormInspection : report-form/CSR/inspection/:detailId
// -- CSR > 승객하기 :ReportCSREditFormPaxDeplane : report-form/CSR/paxdeplane/:detailId
// -- CSR > 승객환자 :ReportCSREditFormPaxPatient : report-form/CSR/paxpatient/:detailId
// -- CSR > 승객부상 :ReportCSREditFormPaxInjury : report-form/CSR/paxinjury/:detailId
// -- CSR > 승무원환자 :ReportCSREditFormCrewPatient : report-form/CSR/crewpatient/:detailId
// -- CSR > 승무원부상 :ReportCSREditFormCrewInjury : report-form/CSR/crewinjury/:detailId
// -- CSR > 불법방해행위 :ReportCSREditFormUnlawful : report-form/CSR/unlawful/:detailId
// -- CSR > 흡연 :ReportCSREditFormSmoking : report-form/CSR/smoking/:detailId
// -- CSR > 설비장비 :ReportCSREditFormMaintenance : report-form/CSR/maintenance/:detailId
// -- CSR > 기타 보고항목 :ReportCSREditFormOther : report-form/CSR/other/:detailId

// -- GSR > Damage : ReportGSREditFormDamage : report-form/GSR/damage/:detailId
// -- GSR > Inspection : ReportGSREditFormInspection : report-form/GSR/inspection/:detailId
// -- GSR > PAX Handling IRR : ReportGSREditFormPaxIrr : report-form/GSR/paxirr/:detailId
// -- GSR > Cargo Handling IRR : ReportGSREditFormCargoIrr : report-form/GSR/cargoirr/:detailId

// -- MSR > AOC : ReportMSREditFormAOC : report-form/MSR/aoc/:detailId
// -- MSR > AMO : ReportMSREditFormAMO : report-form/MSR/amo/:detailId

// -- DSR : ReportDSREditForm : report-form/DSR/:detailId
// -- RSR : ReportRSREditForm : report-form/RSR/:detailId
// -- HZR : ReportHZREditForm : report-form/HZR/:detailId

ReportEditFormRouteInfo.list = [
  {
    Component: ReportASREditForm,
    path: 'report-form/ASR/:detailId',
  },
  {
    Component: ReportCSREditForm,
    path: 'report-form/CSR/:detailId',
  },
  {
    Component: ReportDSREditForm,
    path: 'report-form/DSR/:detailId',
  },
  {
    Component: ReportFOQAEditForm,
    path: 'report-form/FOQA/:detailId',
  },
  {
    Component: ReportGSREditForm,
    path: 'report-form/GSR/:detailId',
  },
  {
    Component: ReportHZREditForm,
    path: 'report-form/HZR/:detailId',
  },
  {
    Component: ReportMSREditForm,
    path: 'report-form/MSR/:detailId',
  },
  {
    Component: ReportRSREditForm,
    path: 'report-form/RSR/:detailId',
  },

  {
    Component: ReportWriteFormMenu,
    path: 'report-form',
  },
  {
    Component: ReportWriteFormCategoryMenu,
    path: 'report-form/:reportKind',
  },
];

export default ReportEditFormRouteInfo;
