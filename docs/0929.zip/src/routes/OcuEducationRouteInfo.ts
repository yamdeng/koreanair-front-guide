import EduManualList from '@/components/occupation/education/EduManualList';

const RouteInfo: any = { rootPath: 'education/' };

RouteInfo.list = [
  // 작업내용 변경시교육 목록
  {
    Component: EduManualList,
    path: 'manual/TC',
  },
  // 특별 교육 목록
  {
    Component: EduManualList,
    path: 'manual/SP',
  },
  // TBM 목록
  {
    Component: EduManualList,
    path: 'manual/TB',
  },
];

export default RouteInfo;
