import { create } from 'zustand';
import { produce } from 'immer';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';
import { asrFlightYupSchema } from './reportFormYupSchema';
import { REPORT_TYPE_ASR } from '@/config/ReportFormConstant';
import history from '@/utils/history';
import _ from 'lodash';

// report/my-reports/{reportId}

/* yup validation */
const yupFormSchema = yup.object().shape({
  flight: asrFlightYupSchema,
  flightCrew: yup.array(),
  event: yup.object().shape({
    occurPlaceNm: yup.string(),
    occurAirportCd: yup.string(),
    runwayNm: yup.string(),
    occurDttm: yup.string(),
    occurTimezoneCd: yup.string(),
    flightPhaseCd: yup.string(),
    altitudeUnitCd: yup.string(),
    altitudeCo: yup.number().nullable(),
    speedUnitCd: yup.string(),
    speedCo: yup.number().nullable(),
    subjectNm: yup.string().required(),
    descriptionTxtcn: yup.string().required(),
  }),
  weather: yup.object().shape({
    metCd: yup.string(),
    windOneCo: yup.number().nullable(),
    windTwoCo: yup.number().nullable(),
    gustCo: yup.number().nullable(),
    visibilityNm: yup.string(),
    cloudCd: yup.string(),
    tempCo: yup.number().nullable(),
    altimeterUnitCd: yup.string(),
    altimeterCo: yup.number().nullable(),
  }),
  bird: yup.object().shape({
    birdTypeNm: yup.string(),
    birdSizeCd: yup.string(),
    birdCoCd: yup.string(),
    struckBirdCoCd: yup.string(),
    timeTypeCd: yup.string(),
    landingLightYn: yup.string(),
    pilotWarnedYn: yup.string(),
    impactTimeNm: yup.string(),
    birdDescriptionCn: yup.string(),
  }),
});

const initFormValue = {
  flight: {
    departureDt: CommonUtil.getNowDateString('YYYYMMDD'),
    flightNo: '',
    regNo: '',
    aircraftTypeCd: '',
    departureAirportCd: '',
    arrivalAirportCd: '',
    divertAirportCd: '',
    stdTime: '',
    staTime: '',
    atdTime: '',
    ataTime: '',
    delayedMinCo: null,
    supplyNm: '',
    checkinNm: '',
  },
  flightCrew: [],
  event: {
    occurPlaceNm: '',
    occurAirportCd: '',
    runwayNm: '',
    occurDttm: '',
    occurTimezoneCd: 'utc',
    flightPhaseCd: '',
    altitudeUnitCd: '',
    altitudeCo: null,
    speedUnitCd: '',
    speedCo: null,
    subjectNm: '',
    descriptionTxtcn: '',
    fileGroupSeq: null,
  },
  weather: {
    metCd: '',
    windOneCo: null,
    windTwoCo: null,
    gustCo: null,
    visibilityNm: '',
    cloudCd: '',
    tempCo: null,
    altimeterCo: null,
    altimeterUnitCd: '',
    weatherCodeList: [],
  },
  bird: {
    birdTypeNm: '',
    birdSizeCd: '',
    birdCoCd: '',
    struckBirdCoCd: '',
    timeTypeCd: '',
    landingLightYn: '',
    pilotWarnedYn: '',
    impactTimeNm: '',
    birdDescriptionCn: '',
  },
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'sys/messages',
  baseRoutePath: '/messages',
  formName: 'useAsrFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useAsrFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  reportTypeCd: REPORT_TYPE_ASR,

  yupFormSchema: yupFormSchema,

  filghtExpanded: true,
  eventExpanded: false,
  weatherExpaned: false,
  birdExapned: false,
  userSelectKind: 'PF',

  searchFligh: async () => {
    const { formValue } = get();
    const { flight } = formValue;
    const { flightNo } = flight;
    if (!flightNo) {
      ToastService.warn('비행편명을 입력해주세요.');
      return;
    }

    const apiResult = await ApiService.get('com/flight', { departureDate: '', fltNo: flightNo });
    const data = apiResult.data || [];
    const searchInfo = data.length ? data[0] : null;

    if (searchInfo) {
      set(
        produce((state: any) => {
          const flight = state.formValue.flight;
          flight.regNo = searchInfo.registrationNo;
          flight.aircraftTypeCd = searchInfo.aircraftType;
          flight.departureAirportCd = searchInfo.to;
          flight.arrivalAirportCd = searchInfo.from;
          flight.supplyNm = searchInfo.supply;
          flight.checkinNm = searchInfo.checkIn;
          flight.stdTime = CommonUtil.getTimeStringByDateFullString(searchInfo.std);
          flight.staTime = CommonUtil.getTimeStringByDateFullString(searchInfo.sta);
          flight.atdTime = CommonUtil.getTimeStringByDateFullString(searchInfo.atd);
          flight.ataTime = CommonUtil.getTimeStringByDateFullString(searchInfo.ata);
          flight.stdLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.stdLocTime);
          flight.staLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.staLocTime);
          flight.atdLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.atdLocTime);
          flight.ataLocTime = CommonUtil.getTimeStringByDateFullString(searchInfo.ataLocTime);
          flight.delayedMinCo = searchInfo.delay;
        })
      );
    } else {
      ToastService.warn('비행정보가 존재하지 않습니다.');
    }
  },

  // 비행승무원 선택
  onSelectFlightCrewList: (selectedValue) => {
    const { userSelectKind } = get();
    set(
      produce((state: any) => {
        const flightCrewList = state.formValue.flightCrew;
        if (!flightCrewList.find((info) => info.empNo === selectedValue.empNo)) {
          flightCrewList.push({ ...selectedValue, tagName: userSelectKind });
        }
      })
    );
  },

  // 비행승무원 삭제
  deleteFlightCrewList: (removeIndex) => {
    set(
      produce((state: any) => {
        state.formValue.flightCrew.splice(removeIndex, 1);
      })
    );
  },

  getDetail: async (id) => {
    const response: any = await ApiService.get(`avn/report/my-reports/${id}`);
    const detailInfo = response.data;
    const { report, reportAsr, flight, flightCrew } = detailInfo;

    // 'report' api에서 event 정보 추출
    const applyEvent = _.pick(report, [
      'occurPlaceNm',
      'occurAirportCd',
      'occurDttm',
      'occurTimezoneCd',
      'subjectNm',
      'descriptionTxtcn',
      'fileGroupSeq',
    ]);

    // 'reportAsr' api에서 event 정보 추출
    const applyEvent2 = _.pick(reportAsr, [
      'flightPhaseCd',
      'altitudeUnitCd',
      'altitudeCo',
      'speedUnitCd',
      'speedCo',
      'runwayNm',
    ]);

    const weatherCodeList = reportAsr.weatherCdarr ? reportAsr.weatherCdarr.split(',') : [];
    const applyFormValue = {
      flight: flight,
      flightCrew: flightCrew,
      event: { ...applyEvent, applyEvent2 },
      weather: { ...reportAsr, weatherCodeList: weatherCodeList },
      bird: { ...reportAsr },
    };
    set({
      detailInfo: detailInfo,
      formValue: applyFormValue,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  getApiParam: () => {
    const { formValue, formDetailId, detailInfo, reportTypeCd } = get();
    const { flight, flightCrew, event, weather, bird } = formValue;
    const { report } = detailInfo || {};

    // 'report'
    const serverReportParam = {
      ...report,
      reportId: formDetailId ? formDetailId : null,
      reportTypeCd: reportTypeCd,
      ...event,
    };
    // 'reportAsr'
    const serverAsrReportParam = {
      reportId: formDetailId ? formDetailId : null,
      ...weather,
      ...bird,
      runwayNm: event.runwayNm,
      flightPhaseCd: event.flightPhaseCd,
      altitudeUnitCd: event.altitudeUnitCd,
      altitudeCo: event.altitudeCo,
      speedUnitCd: event.speedUnitCd,
      speedCo: event.speedCo,
      weatherCdarr: weather.weatherCodeList ? weather.weatherCodeList.join(',') : '',
    };
    // 최종 적용
    const reportApiParam = {
      flight: { ...flight, reportId: formDetailId ? formDetailId : null },
      flightCrew: flightCrew.map((info) => {
        const flightServerInfo = {
          crewTypeCd: info.tagName,
          empNo: info.empNo,
        };
        return flightServerInfo;
      }),
      report: serverReportParam,
      reportAsr: serverAsrReportParam,
    };
    return reportApiParam;
  },

  // 임시저장
  tempSave: async () => {
    const { getApiParam, formType, formDetailId } = get();
    const apiParam = getApiParam();
    let createId = null;
    if (formType === FORM_TYPE_ADD) {
      const createData: any = await ApiService.post(`avn/report/reportInsert`, apiParam);
      createId = createData.ItemCount;
    } else {
      await ApiService.put(`avn/report/reportUpdate/${formDetailId}`, apiParam);
    }
    await set({ isDirty: false });
    if (formType === FORM_TYPE_ADD) {
      // 등록시 받은 reportId 기준으로 정보를 다시 셋팅하기
      history.replace(`/aviation/report-form/ASR/${createId}`);
    }
    ToastService.success('저장되었습니다.');
  },

  // 제출
  save: async () => {
    // avn/report/submitReport
    const { validate, getApiParam, formType } = get();
    const isValid = await validate();
    if (isValid) {
      ModalService.confirm({
        body: '저장하시겠습니까?',
        ok: async () => {
          const apiParam = getApiParam();
          let createId = null;
          const createData: any = await ApiService.post(`avn/report/submitReport`, apiParam);
          if (formType === FORM_TYPE_ADD) {
            createId = createData.ItemCount;
          }
          await set({ isDirty: false });
          if (formType === FORM_TYPE_ADD) {
            // 등록시 받은 reportId 기준으로 정보를 다시 셋팅하기
            history.replace(`/aviation/report-form/ASR/${createId}`);
          }
          ToastService.success('제출되었습니다.');
        },
      });
    }
  },

  toggleAccordionExpanded: (accordionExapndedName) => {
    const state = get();
    const expaned = !state[accordionExapndedName];
    set({ [accordionExapndedName]: expaned });
  },

  print: () => {
    // TODO : 인쇄기능
  },

  clear: () => {
    set(initFormData);
  },
}));

export default useAsrFormStore;
