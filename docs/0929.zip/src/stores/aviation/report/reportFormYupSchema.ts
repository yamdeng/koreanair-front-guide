import * as yup from 'yup';

export const asrFlightYupSchema = yup.object().shape({
  departureDt: yup.string().required(),
  flightNo: yup.string().required(),
  regNo: yup.string().required(),
  aircraftTypeCd: yup.string().required(),
  departureAirportCd: yup.string().required(),
  arrivalAirportCd: yup.string().required(),
  divertAirportCd: yup.string(),
  stdTime: yup.string(),
  staTime: yup.string(),
  atdTime: yup.string(),
  ataTime: yup.string(),
  delayedMinCo: yup.number().nullable(),
  supplyNm: yup.string(),
  checkinNm: yup.string(),
});
