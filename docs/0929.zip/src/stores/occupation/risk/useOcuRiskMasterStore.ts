import { create } from 'zustand';

/* zustand store 생성 */
const useOcuRiskMasterStore = create<any>((set, get) => ({
  tabIndex: 0,

  changeTab: (tabIndex) => {
    const { chk } = get();

    set({ tabIndex: tabIndex });
    // TODO : 탭이 바뀔때 마다 해당 탭의 데이터를 조회할지 여부 판단
    if (tabIndex === 0) {
      // 현황 탭일때 초기화
      //console.log('이곳에옴');
      // useOcuRiskTab1FormStore.getState().test();
    } else {
      chk();
      // 조회 탭일때 초기화
    }
  },

  chk: () => {
    const { addChk } = get();

    console.log('확인값==>', addChk);
    if (addChk == 'add') {
      alert('위험성평가 등록 시 사전준비 등록 후 탭 변경 가능합니다.');
      set({ tabIndex: 0 });
    }
  },

  clear: () => {
    // TODO : clear
    set({ tabIndex: 0 });
  },
}));

export default useOcuRiskMasterStore;
