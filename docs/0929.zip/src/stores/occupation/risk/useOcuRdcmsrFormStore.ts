import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';
import { FORM_TYPE_ADD, FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import history from '@/utils/history';
import { el } from '@faker-js/faker';

/* yup validation */
const yupFormSchema = yup.object({
  /* 위험성정보 */

  // 공정명
  procNm: yup.string(),
  // 세부 작업명
  detailWrkNm: yup.string(),

  // 위험분류
  riskClsNm: yup.string(),
  // 위험요인
  riskFactorCd: yup.string(),
  // 위험발생 상황 및 결과
  riskOcurStatRes: yup.string(),
  // 현재의 안전보건 조치
  currHlthSftyAction: yup.string(),
  // 가능성
  riskDcsnPsbltVal: yup.string(),
  // 중대성
  riskDcsnImprtVal: yup.string(),
  // 위험도
  riskDcsnRiskVal: yup.string(),
  // 위험성 결정
  riskDcsnCd: yup.string(),
  // 감소대책 수립
  rdcmsrCd: yup.string(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  /* 위험성정보 */

  // 공정명
  procNm: '',
  // 세부 작업명
  detailWrkNm: '',

  // 위험분류
  riskClsNm: '',
  // 위험요인
  riskFactorCd: '',
  // 위험발생 상황 및 결과
  riskOcurStatRes: '',
  // 현재의 안전보건 조치
  currHlthSftyAction: '',
  // 가능성
  riskDcsnPsbltVal: '',
  // 중대성
  riskDcsnImprtVal: '',
  // 위험도
  riskDcsnRiskVal: '',
  // 위험성 결정
  riskDcsnCd: '',
  // 감소대책 수립
  rdcmsrCd: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/risk/rdcmsr',
  baseRoutePath: '/occupation/risk/rdcmsr',
  formName: 'useOcuRdcmsrFormStore',
  formValue: {
    ...initFormValue,
  },
};

//  store
const useOcuRdcmsrFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...createListSlice(set, get),

  ...initFormData,

  // 근로자 의견 정보 삭제 list
  deleteRdcmsrOpnnInfoList: [],

  yupFormSchema: yupFormSchema,

  // from 상세 조회
  getDetail: async (id) => {
    const { setList, setTotalCount, procChange, empCmtChange } = get();

    //const { formApiPath } = get();
    const formApiPath = 'ocu/risk/rdcmsr';
    const response: any = await ApiService.get(`${formApiPath}/${id}`);
    const detailInfo = response.data;

    console.log('조회값=====>', detailInfo);
    set({
      // 위험성 결정 폼 정보
      detailInfo: detailInfo.rdcmsrDetail,
      formValue: detailInfo.rdcmsrDetail,
      formType: FORM_TYPE_UPDATE,
    });

    // 위험성 결정 정보
    setTotalCount(detailInfo.revalEmpCmt.length);
    setList(detailInfo.revalEmpCmt);
    // set({ rEvalDocNo: id });

    const { list } = get();
    // 상태값 N 추가
    list.map((info) => {
      info.empCmtGubun = 'N';
    });

    console.log(' 리스트==>', list);
    empCmtChange(detailInfo.revalEmpCmt[0], 0);

    // 위험성 결정 조회 정보
    // procChange(detailInfo.revalProcess[0], 0);
  },
  // 근로자 의견 저장
  empCmtSaveStrore: (empCmtData) => {
    const { empCmtRow, list } = get();

    let empCmtGubun = '';
    if (list[empCmtRow].rdcmsrOpnnId) {
      // 구분
      empCmtGubun = 'U';
    } else {
      // 구분
      empCmtGubun = 'I';
    }

    console.log('list[procRow]==>', list[empCmtRow]);
    console.log('저장값==>', empCmtData);

    const data = {
      // 저장 구분(N: 기본 ,I: 신규,U:수정)
      empCmtGubun: (list[empCmtRow].empCmtGubun = empCmtGubun),
      // 이름
      rdcmsrEmplNm: (list[empCmtRow].rdcmsrEmplNm = empCmtData.rdcmsrEmplNm),
      // 의견
      rdcmsrOpnnCn: (list[empCmtRow].rdcmsrOpnnCn = empCmtData.rdcmsrOpnnCn),
    };

    // 추진팀 저장 list
    //originExecDeptlist.push(data);

    console.log('저장 후 LIST값==>', list);
  },

  // 근로자 의견 삭제
  deleteEmpCmtList: (delEmpCmtData) => {
    const { deleteRdcmsrOpnnInfoList } = get();

    // 삭제 row 추가
    if (delEmpCmtData.data.rdcmsrOpnnId) {
      deleteRdcmsrOpnnInfoList.push(delEmpCmtData.data);
    }

    console.log('삭제후 위험성 결정  리스트==>', deleteRdcmsrOpnnInfoList);
  },

  // 근로자 의견 행 추가
  empCmtAddRowStore: () => {
    const { empCmtRow, list, formValue, setList } = get();

    console.log('로우 추가::', list);
    //console.log('newItem::', newItem);
    // console.log('clearNewItem::', clearNewItem);

    const newItem = {
      // 구분 값
      empCmtGubun: 'I',
      // 번호
      num: list.length + 1,
      // 이름
      rdcmsrEmplNm: '',
      // 의견
      rdcmsrOpnnCn: '',
    };

    setList([...list, newItem]);
    // 위험성 결정 행
    set({ empCmtRow: list.length });
  },

  // 위험성 결정 row 변경
  empCmtChange: (data, rowIndex) => {
    const { detailInfo, formValue, list } = get();

    console.log('data===>', data);

    // 이름
    detailInfo.rdcmsrEmplNm = data.rdcmsrEmplNm;
    // 의견
    detailInfo.rdcmsrOpnnCn = data.rdcmsrOpnnCn;

    set({ empCmtRow: rowIndex, formValue: detailInfo });
  },

  goFormPage: (id) => {
    const { baseRoutePath } = get();
    history.push(`${baseRoutePath}/${id}/edit`);
  },

  // 위험성평가 위험성 결정 탭 저장
  saveUseOcuRiskProc: async () => {
    const { list, formDetailId, formApiPath, search, formValue, baseRoutePath, deleteRdcmsrOpnnInfoList, rEvalDocNo } =
      get();

    //const { list, formDetailId, formApiPath, search, formValue, baseRoutePath } = get();

    //useOcuRiskTab1ProcessListStore.getState().list;
    const apiList = _.cloneDeep(list);

    console.log('폼 값===>', formValue);
    console.log('감소대책 수립 리스트===>', apiList);
    console.log('감소대책 수립 삭제 ===>', deleteRdcmsrOpnnInfoList);

    // 상태 변경 안된 항목 빼고 위험성 결정 List 재구성
    const empCmtInfoList = apiList.filter((item) => item.empCmtGubun !== 'N');

    console.log('감소대책 수립 N 제거 후===>', empCmtInfoList);

    ModalService.confirm({
      body: '저장하시겠습니까?',
      ok: async () => {
        const formParam = formValue;
        const apiParam = {
          // 감소대책 수립 및 실시
          form: formParam,
          // 근로자 의견
          rdcmsrOpnnInfoList: empCmtInfoList,
          // 근로자 의견 삭제 리스트
          deleteRdcmsrOpnnInfoList: deleteRdcmsrOpnnInfoList,
        };

        console.log('보내는 저장값===>', apiParam);

        await ApiService.post(`${formApiPath}/saveRdcMsr`, apiParam);
        // await ApiService.post(`${formApiPath}/${formDetailId}`, apiParam);
        search();
        history.push(`${baseRoutePath}`);
        ToastService.success('저장되었습니다.');
      },
    });
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuRdcmsrFormStore;
