import { create } from 'zustand';
import { produce } from 'immer';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';

/* yup validation */
const yupFormSchema = yup.object({
  // 외주작업 특별교육 선택
  spclEduChcId: yup.number(), // 특별교육 선택 ID
  spclEduItemCd: yup.string(), // 특별교육 항목 코드
  chcYn: yup.string(), // 선택 여부
  cntrId: yup.number().required(), // 공사_ID
  fileId: yup.number().required(), // 첨부파일_ID
  regDttm: yup.string().required(), // 등록_일시
  regUserId: yup.string().required(), // 등록자_ID
  updDttm: yup.string().required(), // 수정_일시
  updUserId: yup.string().required(), // 수정자_ID
});

/* form 초기값 상세 설정 */
const initFormValue = {
  spclEduChcId: '', // 특별교육 선택 ID
  spclEduItemCd: '', // 특별교육 항목 코드
  chcYn: '', // 선택 여부
  cntrId: '', // 공사_ID
  fileId: '', // 첨부파일_ID
  regDttm: '', // 등록_일시
  regUserId: '', // 등록자_ID
  updDttm: '', // 수정_일시
  updUserId: '', // 수정자_ID
};

/** form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitEduChoiceModalStore',

  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuWorkPermitEduChoiceModalStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  isEduChoiceModalOpen: false,

  eduChoiceModalInfo: null,

  saveEduChoiceModal: (eduChoiceFormValue) => {
    set(
      produce((state: any) => {
        const newFormValue = { ...state.formValue };
        newFormValue.eduChocieList.push(eduChoiceFormValue);
        state.formValue = newFormValue;
        state.isEduChoiceModalOpen = false;
      })
    );
  },

  removeFileAttach: (removeIndex) => {
    set(
      produce((state: any) => {
        const newFormValue = { ...state.formValue };
        newFormValue.eduChocieList.splice(removeIndex, 1);
        state.formValue = newFormValue;
      })
    );
  },

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

export default useOcuWorkPermitEduChoiceModalStore;
