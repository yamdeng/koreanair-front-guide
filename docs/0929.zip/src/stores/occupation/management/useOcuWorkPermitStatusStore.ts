import { create } from 'zustand';
import CommonUtil from '@/utils/CommonUtil';
import { DATE_PICKER_TYPE_MONTH } from '@/config/CommonConstant';
import { createFormSliceYup } from '@/stores/slice/formSlice';
import { formBaseState } from '@/stores/slice/formListSlice';

/* formValue 초기값 */
const initFormValue = {
  cntrNm: '',
  spclEduTargetYn: '',
  cntrLocationCd: '',
  cntrPositionNm: '',
  cntrApplyStartDttm: '',
  cntrApplyEndDttm: '',
  preConsentYn: '',
  applyEmpno: '',
  aprvEmpno: '',
  aprvDeptOpnn: '',
  applyStatusCd: '',
  wrkStatusCd: '',
  wrkStartDt: '',
  wrkStartRemark: '',
  wrkEndDt: '',
  wrkEndRemark: '',
  regDttm: '',
  regUserId: '',
  updDttm: '',
  updUserId: '',
  cntrLocationNm: '',
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'ocu/management/permits/calendar',
  baseRoutePath: '/occupation/management/permits',
  formName: 'useOcuWorkPermitStatusFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useOcuWorkPermitStatusStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),
  ...initFormData,
  // 월 선택 초기 false
  monthDatePickerOpen: false,
  // 월 검색
  searchMonth: '',
  // 클릭된 날짜 0으로 초기화
  selectedDate: 0,
  // 달력 안의 날짜 array
  calendarDateList: [],
  // 월에 대한 작업정보 array
  scheduleList: [],
  // 선택된 날짜의 작업 목록
  dateScheduleList: [],

  // 달력의 열림상태 업데이트 할꺼임
  setMonthDatePickerOpen: (openStatus) => {
    set({ monthDatePickerOpen: openStatus });
  },

  prevMonth: () => {
    const { searchMonth, changeSearchMonth } = get();
    const applyMonth = CommonUtil.calculateDate(searchMonth, 'YYYY-MM', DATE_PICKER_TYPE_MONTH, -1);
    changeSearchMonth(applyMonth);
  },

  nextMonth: () => {
    const { searchMonth, changeSearchMonth } = get();
    const applyMonth = CommonUtil.calculateDate(searchMonth, 'YYYY-MM', DATE_PICKER_TYPE_MONTH, 1);
    changeSearchMonth(applyMonth);
  },

  changeSearchMonth: (month) => {
    const calendarDateList = CommonUtil.convertWeekDayList(CommonUtil.getDateListByMonth(month));
    set({ searchMonth: month, calendarDateList: calendarDateList, monthDatePickerOpen: false });
    // TODO : scheduleList api call
  },

  // 1 ~ 31
  changeSelectedDate: (date) => {
    // TODO : 일에 대한 작업 목록 api 호출
    set({ selectedDate: date });
  },

  init: () => {
    const { changeSearchMonth } = get();
    const currentMonth = CommonUtil.getNowMonthString();
    changeSearchMonth(currentMonth);
  },

  changeTab: (tabIndex) => {
    set({ tabIndex: tabIndex });
    // TODO : 탭이 바뀔때 마다 해당 탭의 데이터를 조회할지 여부 판단
    // NEED TO CHECK : The previous data should be remained or not?
  },

  clear: () => {
    // TODO : clear
    set({ tabIndex: 0 });
  },
}));

export default useOcuWorkPermitStatusStore;
