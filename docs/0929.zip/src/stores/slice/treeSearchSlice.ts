import _ from 'lodash';
import CommonUtil from '@/utils/CommonUtil';

export const treeBaseState = {
  treeData: [],
  treeAllList: [],
  selectedKeys: [],
  expandedKeys: [],
  searchInputValue: '',
  beforeSearchInputValue: '',
  searchInputValueTimeoutId: null,
  findList: [],
  currentFindIndex: 0,
  findKey: '',
  labelKey: 'title',
  valueKey: '',
  parentKey: '',
  treeRef: null,
  searchApplyInputLength: 1,
};

export const createTreeSearchSlice = (set, get) => ({
  ...treeBaseState,

  changeStateProps: (propsName, propsValue) => {
    set({ [propsName]: propsValue });
  },

  setTreeRef: (htmlDom) => {
    set({ treeRef: htmlDom });
  },

  setTreeData: (treeData, treeAllList) => {
    const { startInputInterval } = get();
    set({ treeData: treeData, treeAllList: treeAllList });
    startInputInterval();
  },

  onSelect: (selectedKeys) => {
    set({ selectedKeys: selectedKeys });
  },

  onExpand: (expandedKeys) => {
    set({ expandedKeys: expandedKeys });
  },

  searchKeywordToTree: (inputValue) => {
    const { searchInputValue, treeAllList, labelKey, valueKey, parentKey, treeRef } = get();
    let applyFindList = [];
    const expandedKeys = [];
    if (inputValue) {
      const findList = _.filter(treeAllList, (info) => {
        return info[labelKey].indexOf(inputValue) !== -1;
      });
      findList.forEach((info) => {
        CommonUtil.addExpandedKeys(treeAllList, expandedKeys, info, valueKey, parentKey);
      });
      if (findList.length && treeRef && treeRef.current) {
        setTimeout(() => {
          treeRef.current.scrollTo({
            key: findList[0][valueKey],
            align: 'top',
          });
        }, 500);
      }
      applyFindList = findList;
    }
    const applyExpandedKeys = _.uniq(expandedKeys);
    set({
      beforeSearchInputValue: searchInputValue,
      expandedKeys: applyExpandedKeys,
      currentFindIndex: 0,
      findList: applyFindList,
      findKey: applyFindList && applyFindList.length ? applyFindList[0][valueKey] : '',
    });
  },

  startInputInterval: () => {
    const searchInputIntervalId = setInterval(() => {
      const { searchInputValue, beforeSearchInputValue, searchKeywordToTree } = get();
      if (searchInputValue !== beforeSearchInputValue) {
        searchKeywordToTree(searchInputValue);
      }
    }, 1000);
    set({ searchInputValueTimeoutId: searchInputIntervalId });
  },

  changeSearchValue: (newValue) => {
    set({
      searchInputValue: newValue,
    });
  },

  handleSearchInputEnterKey: () => {
    const { findList, currentFindIndex, treeRef, valueKey } = get();
    let applyCurrentFindIndex = 0;
    if (findList.length && findList.length > 1) {
      if (currentFindIndex === findList.length - 1) {
        applyCurrentFindIndex = 0;
      } else {
        applyCurrentFindIndex = currentFindIndex + 1;
      }
      console.log(`applyCurrentFindIndex : ${applyCurrentFindIndex}`);
      const findKey = findList[applyCurrentFindIndex][valueKey];
      setTimeout(() => {
        if (treeRef && treeRef.current) {
          treeRef.current.scrollTo({
            key: findKey,
            align: 'top',
          });
        }
      }, 500);
      set({ currentFindIndex: applyCurrentFindIndex, findKey: findKey });
    }
  },

  clearInputInterval: () => {
    const { searchInputValueTimeoutId } = get();
    if (searchInputValueTimeoutId) {
      clearInterval(searchInputValueTimeoutId);
    }
  },

  clear: () => {
    const { searchInputValueTimeoutId } = get();
    if (searchInputValueTimeoutId) {
      clearInterval(searchInputValueTimeoutId);
    }
    set({ ...treeBaseState });
  },
});
