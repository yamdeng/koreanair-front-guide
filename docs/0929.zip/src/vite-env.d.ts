/// <reference types="vite/client" />

declare const __PROJECT_FOLDER_PATH: string;
declare const DxChart: any;
declare const DxChartBar: any;
declare const DxChartPie: any;
declare const DxChartLine: any;
