package com.koreanair.ksms.batch.mapper;

import com.koreanair.ksms.batch.dto.IfKeUserDto;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class UserFieldSetMapper implements FieldSetMapper<IfKeUserDto> {

    @Override
    public IfKeUserDto mapFieldSet(FieldSet fieldSet) throws BindException {

        IfKeUserDto dto = new IfKeUserDto();
        dto.setEeid(fieldSet.readString(0));
        dto.setNameKor(fieldSet.readString(1));
        dto.setNameEng(fieldSet.readString(2));
        dto.setEmailWork(fieldSet.readString(3));
        dto.setPhone(fieldSet.readString(4));
        dto.setJobLevelId(fieldSet.readString(5));
        dto.setJobLevel(fieldSet.readString(6));
        dto.setCommCode(fieldSet.readString(7));
        dto.setClassC(fieldSet.readString(8));
        dto.setClassN(fieldSet.readString(9));
        dto.setPostTitle(fieldSet.readString(10));
        dto.setDivisionId(fieldSet.readString(11));
        dto.setDivisionCode(fieldSet.readString(12));
        dto.setDivisionName(fieldSet.readString(13));
        dto.setDepartmentId(fieldSet.readString(14));
        dto.setDepartmentCode(fieldSet.readString(15));
        dto.setDepartmentName(fieldSet.readString(16));
        dto.setTeamId(fieldSet.readString(17));
        dto.setTeamCode(fieldSet.readString(18));
        dto.setTeamName(fieldSet.readString(19));
        dto.setGroupId(fieldSet.readString(20));
        dto.setGroupCode(fieldSet.readString(21));
        dto.setGroupName(fieldSet.readString(22));
        dto.setLineteamId(fieldSet.readString(23));
        dto.setLineteamCode(fieldSet.readString(24));
        dto.setLineteamName(fieldSet.readString(25));

        return dto;
    }
}
