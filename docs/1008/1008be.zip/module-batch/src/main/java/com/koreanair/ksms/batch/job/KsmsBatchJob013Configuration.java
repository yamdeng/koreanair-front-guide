package com.koreanair.ksms.batch.job;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;

/**
 * 리포트 미제출 건에 대해서 부문에 알림 기능 Batch Job
 */
@Slf4j
//@Configuration
public class KsmsBatchJob013Configuration {

    public static final String JOB_NAME = "ksmsBatchJob013";
    public static final String STEP_NAME = "ksmsBatchStep013";

}
