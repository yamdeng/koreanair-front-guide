package com.koreanair.ksms.system.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.TbSysUserDto;
import com.koreanair.ksms.system.service.SystemUserService;
import com.koreanair.ksms.utils.ExcelUtil;
import com.koreanair.ksms.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 관리자 사이트 - 사용자관리
 */
@Tag(name = "SystemUser", description = "시스템 사용자관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/sys")
public class SystemUserController {

    @Autowired
    SystemUserService service;

    @Operation(summary = "전체 사용자 목록 조회", description = "전체 사용자 목록 조회 API")
    @GetMapping(value = "/users")
    public ResponseEntity<?> getUserList(
             @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="searchWord", required=false) String searchWord) {

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbSysUserDto> pageList = service.selectUserListPage(searchWord);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "전체 사용자 엑셀 다운로드", description = "전체 사용자 엑셀 다운로드 API")
    @GetMapping(value = "/users/excel")
    public ResponseEntity<?> getUserExcel(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 최대 60000개 까지만 다운로드 가능
        PageHelper.startPage(0, 60000);
        PageInfo<TbSysUserDto> pageList = service.selectUserListPage(searchWord);
        List<TbSysUserDto> excelList = pageList.getList();

        // 엑셀 다운로드
        String excelFileName = "사용자_목록";
        Map<String, String> excelFields = new LinkedHashMap<String, String>();
        excelFields.put("userId", "아이디");
        excelFields.put("empNo", "사번");
        excelFields.put("nameKor", "한글이름");
        excelFields.put("nameEng", "영문이름");
        excelFields.put("deptNmKor", "부서명");
        excelFields.put("deptNmEng", "영문부서명");
        excelFields.put("rankNmKor", "직급명");
        excelFields.put("rankNmEng", "영문직급명");

        return ExcelUtil.downloadExcel(
                excelList,
                excelFields,
                excelFileName
        );
    }

    @Operation(summary = "특정 사용자 하나의 상세정보 조회", description = "특정 사용자 하나의 상세정보 조회 API")
    @GetMapping(value = "/users/{userId}")
    public ResponseEntity<?> getUserInfo(@PathVariable(value="userId", required=true) String userId) {

        TbSysUserDto result = service.selectUser(userId);
        return ResponseUtil.createSuccessResponse(result);
    }
}
