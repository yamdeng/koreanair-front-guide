package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnInstructorHistDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnInstructorManageServiceImpl extends AbstractBaseService implements AvnInstructorManageService {

    // 강사이력관리 목록 조회
    @Override
    public PageInfo<TbAvnInstructorHistDto> selectInstructorManage(TbAvnInstructorHistDto tbAvnInstructorHistDto) {
        List<TbAvnInstructorHistDto> resultList = commonSql.selectList("AvnInstructorManage.selectInstructorManage", tbAvnInstructorHistDto);
        return PageInfo.of(resultList);
    }

    // 강사이력관리 신규 등록
    @Override
    public void inserInstructorManage(TbAvnInstructorHistDto tbAvnInstructorHistDto) {

        // 날짜 포맷 변경
        String DtFormatChange = tbAvnInstructorHistDto.getEmplymentDt();
        DtFormatChange = DtFormatChange.replace("-", "");
        DtFormatChange = DtFormatChange.substring(0,8);

        tbAvnInstructorHistDto.setEmplymentDt(DtFormatChange);

        commonSql.insert("AvnInstructorManage.inserInstructorManage", tbAvnInstructorHistDto);
    }

    // 강사이력관리 상세
    @Override
    public TbAvnInstructorHistDto selectInstructorManageDetail(String empNo) {
        return commonSql.selectOne("AvnInstructorManage.selectInstructorManageDetail", empNo);
    }

    // 강사이력관리 수정
    @Override
    public void updateInstructorManage(TbAvnInstructorHistDto tbAvnInstructorHistDto) {
        commonSql.update("AvnInstructorManage.updateInstructorManage", tbAvnInstructorHistDto);
    }

    // 강사이력관리 삭제
    @Override
    public void deleteInstructorManage(String empNo) {
        commonSql.delete("AvnInstructorManage.deleteInstructorManage", empNo);
    }
}
