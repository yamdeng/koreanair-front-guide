package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class TbAvnIvCaRecommentDto extends CommonDto {

    @Schema(description = "ID")
    private String id;

    @Schema(description = "tb_avn_iv_ca ID")
    private String caId;

    @Schema(description = "Recommendation ID. No")
    private String recommendNo;

    @Schema(description = "Recommendation")
    private String recommend;

    @Schema(description = "Action Taken")
    private String actionTaken;

    @Schema(description = "Division")
    private String deptCd;

    @Schema(description = "등록자 사원번호")
    private String empNo;

    @Schema(description = "발생일자")
    private String issueAt;
    
    @Schema(description = "회신일자")
    private String dueAt;

    @Schema(description = "첨부파일")
    private String fileGroupSeq;

    @Schema(description = "리포트ID")
    private String reportId;

    @Schema(description = "마지막 번호")
    private String lastnumber;

}
