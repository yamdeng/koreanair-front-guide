package com.koreanair.ksms.avn.audit.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.util.List;
import java.util.Map;


@Getter
@Setter
@ToString
@Schema(description = "Checklist / Checklist 목록")
public class TBAuditChecklistChapterDto extends CommonDto {

    @Schema(description = "checklistId")
    @NotNull
    private int checklistId;

    @Schema(description = "원본아이디")
    private int checklistOrigId;

    @Schema(description = "체크리스트명")
    private String checklistName;

    @Schema(description = "Audit 부문")
    private String division;

    private List<Map> chapters;

    private List<ChecklistRevisionsVo> revisions;
}
