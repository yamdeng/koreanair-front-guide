package com.koreanair.ksms.avn.sftp.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnManualDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnSafetyManualServiceImpl extends AbstractBaseService implements AvnSafetyManualService {
    //안전정책 > 안전매뉴얼 목록 조회
    @Override
    public PageInfo<TbAvnManualDto> selectSafetyManualList(TbAvnManualDto tbAvnManualDto){
        List<TbAvnManualDto> resultList = commonSql.selectList("AvnSafetyManual.selectSafetyManualList", tbAvnManualDto);
        return PageInfo.of(resultList);
    }

    //안전정책 > 안전매뉴얼 상세 조회
    @Override
    public TbAvnManualDto selectSafetyManualInfo(int manualId){
        return commonSql.selectOne("AvnSafetyManual.selectSafetyManualInfo", manualId);
    }
}
