package com.koreanair.ksms.common.dto;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "변화관리")
public class TbAvnChangeMgmtDto extends CommonDto {
    
    @Schema(description = "순번")
    @NotNull
    private int num;

    @Schema(description = "페이지번호")
    @NotNull
    private int pageNum;

    @Schema(description = "페이지사이즈")
    @NotNull
    private int pageSize;

    @Schema(description = "변화관리ID")
    @NotNull
    private int changeMgmtId;
    
    @Schema(description = "변화관리연도")
    @NotBlank
    private String changeMgmtYear;
    
    @Schema(description = "부문코드배열")
    private List<String> searchDivisionCdarr;

    @Schema(description = "부문코드배열")
    private String divisionCdarr;
    
    @Schema(description = "사원번호")
    private String empNo;
    
    @Schema(description = "시작일자")
    private String fromDt;
    
    @Schema(description = "끝일자")
    private String toDt;
    
    @Schema(description = "변화텍스트내용")
    private String changeTxtcn;
    
    @Schema(description = "링크그룹SEQ")
    private int linkGroupSeq;
    
    @Schema(description = "파일그룹SEQ")
    private int fileGroupSeq;

    @Schema(description = "제목명")
    private String subjectNm;

    @Schema(description = "변화관리상태코드")
    private String changeMgmtStatusCd;

    @Builder
    public TbAvnChangeMgmtDto(
            Integer pageNum,
            Integer pageSize,
            Integer changeMgmtId,
            String  changeMgmtYear,
            List<String>  searchDivisionCdarr,
            String  divisionCdarr,
            String  empNo,
            String  fromDt,
            String  toDt,
            String  changeTxtcn,
            String  subjectNm,
            String  changeMgmtStatusCd,
            int  linkGroupSeq,
            int  fileGroupSeq
            ) {
        this.pageNum = pageNum == null ? 1 : pageNum;
        this.pageSize = pageSize == null ? 10 : pageSize;
        this.changeMgmtId = changeMgmtId == null ? 0 : changeMgmtId;
        this.changeMgmtYear = changeMgmtYear;
        this.searchDivisionCdarr = searchDivisionCdarr;
        this.divisionCdarr = divisionCdarr;
        this.empNo = empNo;
        this.fromDt = fromDt;
        this.toDt = toDt;
        this.changeTxtcn = changeTxtcn;
        this.subjectNm = subjectNm;
        this.changeMgmtStatusCd = changeMgmtStatusCd;
        this.linkGroupSeq = linkGroupSeq;
        this.fileGroupSeq = fileGroupSeq;
    }

}
