package com.koreanair.ksms.avn.srm.dto;

import jakarta.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(of = { "id" })
public class BirdStrikeVo {

	@NotNull
	private int id;
	
	@NotNull
	private int asrEventId;

	@Length(max = 50)
	private String birdType;

	@Length(max = 50)
	private String birdSize;

	@Length(max = 50)
	private String numberSeen;

	@Length(max = 50)
	private String numberStruck;

	@Length(max = 50)
	private String timeType;
	
	@Length(max = 1)
	private String isLandingLight;
	
	@Length(max = 1)
	private String isPilotWarned;
	
	@Length(max = 100)
	private String impactPoint;
	
	private String descr;

	private String numberSeenNameKo;
	
	private String numberSeenNameEn;
	
	private String numberStruckNameKo;
	
	private String numberStruckNameEn;
	
	private String timeTypeNameKo;
	
	private String timeTypeNameEn;
	
	private String birdSizeNameKo;
	
	private String birdSizeNameEn;
	
	
}
