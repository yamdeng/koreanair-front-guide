package com.koreanair.ksms.avn.audit.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.audit.dto.*;
import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AvnMyAuditServiceImpl extends AbstractBaseService implements AvnMyAuditService {

    // My Audit 현황 조회
    @Override
    public TBMyAuditStatisticsDto selectMyAuditStatistics(Map paramMap) {
        return commonSql.selectOne("AvnMyAudit.selectMyAuditStatistics", paramMap);
    }
        
    // My Audit 목록 조회
    @Override
    public PageInfo<TBMyAuditListDto> selectMyAuditList(Map paramMap) {
        List<TBMyAuditListDto> resultList = commonSql.selectList("AvnMyAudit.selectMyAuditList", paramMap);
        return PageInfo.of(resultList);
    }

    // Audit 정보 조회
    @Override
    public TBAuditDto selectAuditInfo(int auditId) {
        // Audit 상세 조회 (with Auditors,Auditee)
        TBAuditDto auditInfoDto = commonSql.selectOne("AvnMyAuditPlan.selectAuditInfo", auditId);
        return auditInfoDto;
    }

    // 부문별 Checklist 정보 조회
    @Override
    public List<TBAuditChecklistDto> selectChecklistByDivision(String division) {
        List<TBAuditChecklistDto> checklistDto = commonSql.selectList("AvnMyAuditPlan.selectChecklistByDivision", division);
        return checklistDto;
    }

    // Airport의 area 정보 조회
    @Override
    public List<Map<String, Object>> selectAreaByAirport(String airportCode) {
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("airportCode", airportCode);
        return commonSql.selectList("AvnMyAuditPlan.selectAreaByAirport", param);
    }

    // Audit Plan 저장
    @Override
    @Transactional
    public Integer insertAuditPlanInfo(TBAuditDto tBAuditDto){
        // Audit 정보 저장
        if(tBAuditDto.getAuditId() == 0) {
            commonSql.insert("AvnMyAuditPlan.insertAuditPlanInfo", tBAuditDto);
            // Auditee 정보 저장
            if(tBAuditDto.getAuditeeInfo() != null) {
                tBAuditDto.getAuditeeInfo().setAuditId(tBAuditDto.getAuditId());
                commonSql.insert("AvnMyAuditPlan.insertAuditeePlanInfo", tBAuditDto.getAuditeeInfo());
            }
        }
        else {
            commonSql.update("AvnMyAuditPlan.updateAuditPlanInfo", tBAuditDto);
            commonSql.update("AvnMyAuditPlan.updateAuditeePlanInfo", tBAuditDto);
        }

        // Checklist 정보 저장
        if(tBAuditDto.getChecklistInfo() != null) {
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("auditId", tBAuditDto.getAuditId());
            param.put("auditChecklistList", tBAuditDto.getChecklistInfo());
            commonSql.insert("AvnMyAuditPlan.insertAuditChecklistInfo", param);
        }

        // Auditor 정보 저장
        if(tBAuditDto.getAuditorInfo() != null) {
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("auditId", tBAuditDto.getAuditId());
            param.put("auditorList", tBAuditDto.getAuditorInfo());
            commonSql.insert("AvnMyAuditPlan.insertAuditorInfo", param);
        }

        return tBAuditDto.getAuditId();
    }

    // Audit Checklist 정보 조회
    @Override
    public List<TBAuditChecklistDto> selectConductChecklistInfo(int auditId) {
        // Checklist 조회 (Chapter, Question 포함)
        List<TBAuditChecklistDto> checklistDto = commonSql.selectList("AvnMyAuditConduct.selectAuditChecklistInfo", auditId);
        //List<TBAuditChecklistDto> checklistDto = commonSql.selectList("AvnMyAudit.selectAuditChecklistInfo2", auditId);
        //auditDto.setChecklistInfo(checklistDto);
        return checklistDto;
    }

    // Audit Conduct 저장
    @Override
    @Transactional
    public Integer insertAuditConductInfo(TBAuditDto tBAuditDto){
        // Audit 정보 저장
        commonSql.update("AvnMyAuditConduct.updateAuditConductInfo", tBAuditDto);

        // Finding 정보 저장
        if(tBAuditDto.getFindingInfo() != null) {
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("auditId", tBAuditDto.getAuditId());
            param.put("findingList", tBAuditDto.getFindingInfo());
            commonSql.insert("AvnMyAuditConduct.insertAuditFindingInfo", param);
        }

        return tBAuditDto.getAuditId();
    }

    // Audit Finding 정보 조회
    @Override
    public List<TBAuditFindingDto> selectCarFindingInfo(int auditId) {
        List<TBAuditFindingDto> checklistDto = commonSql.selectList("AvnMyAuditCar.selectCarFindingInfo", auditId);
        return checklistDto;
    }
}
