package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import jakarta.validation.Valid;

import java.util.List;

public interface AvnReportMitigationService {

    ReportMitigationDto selectMitigationByReportId(ReportInfoDto.GET_Request dto);

    SmMitigation insertMitigationAssign(MitigationAssignDto.POST_Request parameter) throws Exception;

    SmMitigation updateMitigationAssign(@Valid MitigationAssignDto.PUT_Request parameter) throws Exception;

    void updatePlanDueAt(MitigationAcceptDto.POST_Request parameter) throws Exception;

    SmMitigation selectMitigation(int hazardId);

    void updateMitigationAppointer(MitigationAcceptDto.POST_Request_Appointer parameter) throws Exception;

    MitigationResultVo selectMitigationResult(MitigationResultDto.GET_Request parameter) throws Exception;

    void updateMitigationResult(MitigationResultDto.PUT_Request parameter) throws Exception;

    void updateMitigationPlanSubmit(int hazardId);

    void updateMitigationResultSubmit(int hazardId);

    void deleteMitigationProgressRateList(int listId);

    SmMitigation updateMitigationTransfer(MitigationAssignDto.PUT_Request parameter) throws Exception;

    List<SmReport> selectMitigationDeptUserList(MitigationAssignDto.PUT_Request param);

    String selectMitigationDeptSectorInfo(Integer param);

    List<SmMitigation> selectMitigationEmpNo(MitigationAcceptDto.POST_Request_Appointer parameter);
}
