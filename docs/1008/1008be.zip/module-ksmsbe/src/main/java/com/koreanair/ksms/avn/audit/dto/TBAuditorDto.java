package com.koreanair.ksms.avn.audit.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
public class TBAuditorDto {
    private int auditorId;
    private int auditId;
    private String auditorType;
    private String empNo;
    private String nameKor;
    private String nameEng;
    private String rankNmKor;
    private String rankNmEng;
    private String deptNmKor;
    private String deptNmEng;
}
