package com.koreanair.ksms.avn.sftm.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.avn.sftm.service.AvnSafetyCommunicationService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 안전증진 - 안전 Communication
 */
@Tag(name = "AvnSafetyCommunication", description = "안전증진 - 안전 Communication API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyCommunicationController {

    @Autowired
    AvnSafetyCommunicationService service;

    /**
     * Newsletter 목록 조회
     *
     * @param boardSearchDto the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Newsletter 목록 조회", description = "Newsletter 목록 조회 API")
    @GetMapping(value = "/promotion/communication/newsletters")
    public ResponseEntity<?> getNewsletterList(@RequestParam Map<String, Object> paramMap) {
        BoardSearchDto boardSearchDto =
                BoardSearchDto
                        .builder()
                        .pageNum( Integer.parseInt(paramMap.get("pageNum").toString()))
                        .pageSize( Integer.parseInt(paramMap.get("pageSize").toString()))
                        .notiType( paramMap.get("notiType") != null ? paramMap.get("notiType").toString() : "")
                        .titleKo( paramMap.get("titleKo") != null ? paramMap.get("titleKo").toString() : "")

                        .build();
        // Page 조회
        PageHelper.startPage(boardSearchDto.getPageNum(), boardSearchDto.getPageSize());
        PageInfo<TbAvnBoardDto> pageList = service.selectBoardList(boardSearchDto);

        // 전체 조회
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "Newsletter 상세정보 조회", description = "Newsletter 상세정보 조회 API")
    @GetMapping(value = "/promotion/communication/newsletters/{newsletterId}")
    public ResponseEntity<?> getNewsletterInfo(@PathVariable(value="newsletterId", required=true) int boardId) {

        TbAvnBoardDto result = service.selectBoardDetail(boardId);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * SkySafety21 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "SkySafety21 목록 조회", description = "SkySafety21 목록 조회 API")
    @GetMapping(value = "/promotion/communication/skysafety21")
    public ResponseEntity<?> getSkySafety21List(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "SkySafety21 상세정보 조회", description = "SkySafety21 상세정보 조회 API")
    @GetMapping(value = "/promotion/communication/skysafety21/{skysafety21Id}")
    public ResponseEntity<?> getSkySafety21Info(@PathVariable(value="skysafety21Id", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
