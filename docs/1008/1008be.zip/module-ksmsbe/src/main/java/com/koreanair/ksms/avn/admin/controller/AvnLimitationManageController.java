package com.koreanair.ksms.avn.admin.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.service.AvnLimitationManageService;
import com.koreanair.ksms.common.dto.FoqaLimitationDto;
import com.koreanair.ksms.common.dto.TbAvnReportFoqaLimitation;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * 관리자 - Limitation 관리
 */
@Tag(name = "AvnLimitationManage", description = "관리자 - Limitation관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnLimitationManageController {

    @Autowired
    AvnLimitationManageService avnLimitationManageService;

    @Autowired
    AvnCommonService avnCommonService;

    /**
     * Limitation 목록 조회
     *
     * @param FoqaLimitationDto the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Limitation 목록 조회", description = "Limitation 목록 조회 API")
    @GetMapping(value = "/admin/limitation")
    public ResponseEntity<?> getLimitationManageList(@Valid FoqaLimitationDto param) {

        PageHelper.startPage(param.getPageNum(), param.getPageSize());
        PageInfo<TbAvnReportFoqaLimitation> pageList = avnLimitationManageService.selectLimitationManageList(param);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "Limitation 상세정보 조회", description = "Limitation 상세정보 조회 API")
    @GetMapping(value = "/admin/limitation/{id}")
    public ResponseEntity<?> getLimitationManageInfo(@PathVariable(value="id", required=true) Integer id) {
        FoqaLimitationDto param = new FoqaLimitationDto();
        param.setId(id);
        TbAvnReportFoqaLimitation result = avnLimitationManageService.selectLimitationManageInfo(param);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "Limitation 신규 등록", description = "신규 Limitation 등록 API")
    @PostMapping(value = "/admin/limitation")
    public ResponseEntity<?> insertLimitationManage(@Valid @RequestBody(required=true) TbAvnReportFoqaLimitation dto) {
        FoqaLimitationDto param = new FoqaLimitationDto();
        param.setEventTypeId(dto.getEventTypeId());
        param.setFleetCode(dto.getFleetCode());
        TbAvnReportFoqaLimitation result = avnCommonService.selectFoqaLimitation(param);
        if (result != null) {
            throw new CustomBusinessException("Limitation 저장 실패하였습니다.(중복등록)");
        }

        avnLimitationManageService.insertLimitationManage(dto);
        return ResponseUtil.createSuccessResponse(dto);
    }

    @Operation(summary = "Limitation 정보 수정", description = "Limitation 정보 수정 API")
    @PutMapping(value = "/admin/limitation/{id}")
    public ResponseEntity<?> updateLimitationManage(
            @PathVariable(value="id", required=true) Integer id,
            @Valid @RequestBody(required=true) TbAvnReportFoqaLimitation dto) {
        dto.setId(id);
        avnLimitationManageService.updateLimitationManageInfo(dto);
        return ResponseUtil.createSuccessResponse(dto);
    }

    @Operation(summary = "Limitation 삭제", description = "Limitation 삭제 API")
    @DeleteMapping(value = "/admin/limitation/{id}")
    public ResponseEntity<?> deleteLimitationManage(@PathVariable(value="id", required=true) Integer id) {
        avnLimitationManageService.deleteLimitationManageInfo(id);
        return ResponseUtil.createSuccessResponse(id);
    }
}
