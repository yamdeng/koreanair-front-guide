package com.koreanair.ksms.avn.srm.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

public class HazardViewlistDto {
	
	@Getter
	@Setter
	@ToString
	public static class GET_Request {

		private Integer groupId;
		private Integer hazardId;

		@NotNull
		private String phase;
		
		private String empNo;
		
		private List<String> reportList;
		
		private String assignedReportEmpNo;

		private String mitigationEmpType;

		private Integer mitigationDeptId;
	}
/*

	@Getter
	@Setter
	@AllArgsConstructor
	public static class GET_Response {
		private int id;
		private List<KeField> headerInfo;
		private List<HazardViewlistVo> dataSource;
		private final ReportPaths reportPaths = ReportPaths.getInstance();
	}

*/

}


