package com.koreanair.ksms.avn.audit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.security.PrivateKey;
import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
@Schema(description = "Audit / Finding")
@JsonIgnoreProperties(value = {"handler"})
public class TBAuditFindingDto extends CommonDto {
    @Schema(description = "findingId")
    @NotNull
    private int findingId;
    private String findingNo;
    private int auditId;
    private int questionId;
    private int chapterId;
    private int checklistId;
    private String findingType;
    private String findingPhase;
    private String findingPhaseNm;
    private Timestamp dueAt;
    private Timestamp lastestDueAt;
    private String auditedBy;
    private String auditedByNm;
    private String flightPhaseOy;
    private String flightPhaseUf;
    private String findingTitle;
    private String riskLevel;
    private String riskLevelHm;
    private int categoryId;
    private String hazardLevel3;
    private String riskRegister;
    private String potentialConsequence;
    private String descr;
    private String isSpecialAudit;
    private String timezone;
    private String isCaConfirmed;
    private String comment;
    private String isMitCompleted;
    private String useYn;
    private Timestamp mitigationAt;
    private Timestamp mitigatedAt;

    // 체크리스트 정보
    private String checklistNm;
    private String chapterNm;
    private String questionContent;
    private String questionRefManual;
    private String priority;
    private String probability;
    private String severity;

    // mitigation 정보
    private List<TBAuditMitigationDto> mitigationInfo;

    // RootCause 정보
    private List<TBAuditRootCauseDto> rootCauseInfo;
}
