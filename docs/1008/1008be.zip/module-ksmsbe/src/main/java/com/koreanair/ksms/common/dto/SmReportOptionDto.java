package com.koreanair.ksms.common.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class SmReportOptionDto {
		
	private String viewType;
	
	private String codeGrpId;
	
	private List<String> valueFilter;

	public SmReportOptionDto(String viewType, String codeGrpId) {
		super();
		this.viewType = viewType;
		this.codeGrpId = codeGrpId;
	}
}
