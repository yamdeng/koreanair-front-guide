package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.constants.AvnStatusCode.*;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AvnReportSysNotiServiceImpl extends AbstractBaseService implements AvnReportSysNotiService {

    //todo khw. 작성필요
    //@Value("${site.user.url}")
    private String siteUrl;

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Override
    public boolean sendSysMsg(List<String> to, String notiType, String link, Map<String, String> contentsMap) {
        try {
            logger.debug("\r\n\r\n\r\n=== [REPORT PROCESS - SEND SYSTEM MESSAGE] to: {} / notiType: {} ===\r\n\r\n", to, notiType);
            //return sendNotificationService.sendSysMsg(to, notiType, link, contentsMap);

            //todo khw. 확인필요
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean sendMail(String from, List<String> to, String notiType, Map<String, String> contentsMap) {
        try {
            //logger.debug("\r\n\r\n\r\n=== [REPORT PROCESS - SEND MAIL] from: {} / to: {} / notiType: {} ===\r\n\r\n", from, to, notiType);
            //return sendNotificationService.sendEmail(from, to, notiType, contentsMap);

            //todo khw. 확인필요
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void sendNoti(ReportProcessVo processVo, ReportStatus stat) {
        try {
            ReportProcessDto reportStatus = selectReportStatus(processVo.getReportId());
            TbSysUserDto user = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
            String reportType = reportStatus.getReportType();
            HazardProcessDto hazardStatus = new HazardProcessDto();
            if(processVo.getHazardId() != null && processVo.getHazardId() > 0) {
                hazardStatus = selectHazardStatus(processVo.getHazardId());
            }
            String queryDocNo="doc_no=" + reportStatus.getDocNo();
            String queryParam = "?submitted_at=" + reportStatus.getSubmittedAt() + "&"+queryDocNo;
            String href = "<a href=\"$link$\" target=\"_blank\">$msg$</a>";
            String myMenu =siteUrl +"/myMenu?"+queryDocNo;

            //TODO KHW URL 정보 setting 필요
            /*
            String recption = siteUrl + "/" + PortalAppIdStore.valueOf("RECEPTION").getAppUrl() + queryParam;
            String lsc = siteUrl + "/" + PortalAppIdStore.valueOf("RISK_ASSESSMENT").getAppUrl() + queryParam;
            */
            String recption = "";
            String lsc = "";

            String secondLsc = lsc+"&phase=second";

            String mit = "";
            String detail = "";
            String finalAppr = "";
            /*
            String mit = siteUrl + "/" + PortalAppIdStore.valueOf("MITIGATION").getAppUrl() + queryParam;
            String detail = siteUrl + "/" + PortalAppIdStore.valueOf(reportType.toUpperCase()).getAppUrl() + "/view/"+ processVo.getReportId();
            String finalAppr = siteUrl + "/" + PortalAppIdStore.valueOf("RISK_ACCEPTANCE_APPROVAL").getAppUrl() + queryParam;
            */
            String link = "";

            Map<String, String> contentsMap = new HashMap<>();
            contentsMap.put("emp_no", processVo.getEmpNo());
            contentsMap.put("emp_ko", user.getNameKor());
            contentsMap.put("emp_en", user.getNameEng());
            contentsMap.put("report_type", reportStatus.getReportType().equalsIgnoreCase("HZR") ? "Hazard Report"
                    : reportStatus.getReportType().toUpperCase()); // TODO Report full name
            contentsMap.put("static_doc_no", reportStatus.getDocNo());
            contentsMap.put("doc_no", reportStatus.getDocNo());
            contentsMap.put("hazard_no", hazardStatus.getHazardNo());
            contentsMap.put("reason", processVo.getReason());
            contentsMap.put("lsc_page", href.replace("$link$", lsc).replace("$msg$", lsc));
            contentsMap.put("mitigation_page", href.replace("$link$", mit).replace("$msg$", mit));
            contentsMap.put("report_detail_page", href.replace("$link$", detail).replace("$msg$", detail));

            if(reportType.equals("asr")) {

                String eventAt = reportStatus.getEventAt() != null ? new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(reportStatus.getEventAt()) : "";

                contentsMap.put("subject", reportStatus.getSubject());
                contentsMap.put("event_at", eventAt);
                contentsMap.put("flight_no", reportStatus.getFlightNo());
            } else {
                contentsMap.put("subject", "");
                contentsMap.put("event_at", "");
                contentsMap.put("flight_no", "");
            }

            switch (stat) {
                case REPORTING_SUBMITTED:
                    if(!reportType.equalsIgnoreCase("RSR")) { //RSR 일경우 제외
                        link = recption;

                        // FROM: 보고서 작성자, TO: 보고서 접수 담당그룹
                        List<String> rsMangerList = getReportManagerList(reportStatus);
                        sendSysMsg(rsMangerList, "N0018", link, contentsMap);

                        contentsMap.put("doc_no", href.replace("$link$", link).replace("$msg$", reportStatus.getDocNo()));
                        sendMail(reportStatus.getEmpNo(), rsMangerList, "N0018", contentsMap);
                    }
                    break;
                case RECEPTION_APPROVED:
                    if("rsr".equals(reportType)) { //rsr 접수완료시 메일및 알람보내기 X
                        break;
                    }
                    link = myMenu;

                    // FROM: 보고서 접수한 담당자, TO: 보고서 작성자
                    sendSysMsg(Arrays.asList(reportStatus.getEmpNo()), "N0003", link, contentsMap);

                    // FROM: 접수한 HZR 담당자, TO: 보고서 작성자
                    if(contentsMap.get("report_type") == "Hazard Report") {
                        contentsMap.put("doc_no", href.replace("$link$", link).replace("$msg$", reportStatus.getDocNo()));
                        sendMail(reportStatus.getManagerEmpNo(), Arrays.asList(reportStatus.getEmpNo()), "N0045", contentsMap);
                    }

                    link = lsc;

                    // FROM: 보고서 접수한 담당자, TO: LSC 담당 전체
                    List<LscMemberDto> raLscMemberList = selectLscMember(processVo.getReportId());
                    Set<String> raLscSet = raLscMemberList.stream().map(LscMemberDto::getEmpNo).collect(Collectors.toSet());

                    sendSysMsg(new ArrayList<String>(raLscSet), "N0005", link, contentsMap);

                    contentsMap.put("doc_no", href.replace("$link$", link).replace("$msg$", reportStatus.getDocNo()));
                    sendMail(reportStatus.getManagerEmpNo(), new ArrayList<String>(raLscSet), "N0005", contentsMap);

//				22-09-06 알림제외 [현업확인]
//				// FROM: 시스템 TO: ARS, FOQA 담당자 (보고접수에서 SPI 지표 포함 체크된 보고서 접수 완료 시)
//				if(reportType.equalsIgnoreCase("ASR") || reportType.equalsIgnoreCase("FOQA")) {
//					if(!reportStatus.getIsSpi().equalsIgnoreCase("Y")) {
//						break;
//					}
//
//					link = detail;
//
//					List<ManagerMemberDto> spiList = selectManagerMember(false, "ASR", "FOQA");
//					List<String> spiEmpNoList = spiList.stream().map(ManagerMemberDto::getEmpNo).collect(Collectors.toList());
//
//					sendSysMsg(spiEmpNoList, "N0017", link, contentsMap);
//
//					contentsMap.put("doc_no", href.replace("$link$", link).replace("$msg$", reportStatus.getDocNo()));
//					sendMail("", spiEmpNoList, "N0017", contentsMap);
//				}

                    break;
                case RECEPTION_REJECTED:
                    link = myMenu;

                    // FROM: 보고서 접수한 담당자, TO: 보고서 작성자
                    sendSysMsg(Arrays.asList(reportStatus.getEmpNo()), "N0004", link, contentsMap);

                    contentsMap.put("doc_no", href.replace("$link$", link).replace("$msg$", reportStatus.getDocNo()));
                    sendMail(user.getEmpNo(), Arrays.asList(reportStatus.getEmpNo()), "N0004", contentsMap);
                    break;

                case ACCEPTANCE_REJECTED:
                    link = lsc;

                    // TO: LSC 담당 전체
                    List<LscMemberDto> arLscMemberList = selectLscMember(processVo.getReportId());
                    Set<String> arLscSet = arLscMemberList.stream().map(LscMemberDto::getEmpNo).collect(Collectors.toSet());

                    sendSysMsg(new ArrayList<String>(arLscSet), "N0006", link, contentsMap);
                    break;
                case ACCEPTANCE_APPROVED_MIT:
                    link = lsc;

                    // TO: LSC 담당 전체
                    List<LscMemberDto> aamLscMemberList = selectLscMember(processVo.getReportId());
                    Set<String> aamLscSet = aamLscMemberList.stream().map(LscMemberDto::getEmpNo).collect(Collectors.toSet());
                    sendSysMsg(new ArrayList<String>(aamLscSet), "N0007", lsc, contentsMap);
                    break;
                case MIT_ASSIGN_SUBMITTED:
                    link = mit;

                    // FROM: (수행담당 팀장을 지정한)보고서 접수담당 -> 해당 보고서를 접수한 접수담당

                    // TO: 보고서 접수담당 팀장
                    String masMangeLeader = getReportManageLeader(reportStatus);
                    sendSysMsg(Arrays.asList(masMangeLeader), "N0008", link, contentsMap);
                    sendMail(reportStatus.getManagerEmpNo(), Arrays.asList(masMangeLeader), "N0008", contentsMap);
                    break;
                case MIT_ASSIGN_APPROVED:
                    link = mit;

                    // FROM: (수행담당 팀장을 지정한)보고서 접수담당 -> 해당 보고서를 접수한 접수담당
                    // TO: 경감조치 수행팀 팀장 + 팀원
                    MitigationMemberDto maaMitigationMember = selectMitigationMember(processVo.getHazardId());

                    // 중복 발송 제거
                    Set<String> maaMitigationMemberSet = new HashSet<String>();
                    maaMitigationMemberSet.add(maaMitigationMember.getLeaderEmpNo());
                    // maaMitigationMemberSet.add(maaMitigationMember.getEmpNo()); // 경감조치 담당자 미지정 상태
                    if(!maaMitigationMember.getMemberEmpNoList().isEmpty()) {
                        maaMitigationMemberSet.addAll(maaMitigationMember.getMemberEmpNoList());
                    }
                    List<String> maaMitigationMemberList = new ArrayList<String>(maaMitigationMemberSet);

                    sendSysMsg(maaMitigationMemberList, "N0009", link, contentsMap);
                    sendMail(reportStatus.getManagerEmpNo(), maaMitigationMemberList, "N0009", contentsMap);

                    // FROM: 보고서 접수담당 팀장
                    String maaMangeLeader = getReportManageLeader(reportStatus); // TODO user.getEMP_NO();
                    // TO: (수행담당 팀장을 지정한)보고서 접수담당 -> 해당 보고서를 접수한 접수담당자 + 담당자와 같은 부서 접수담당
                    // maaMitigationMember.getRequestedBy()
                    List<String> maaMangerList = getReportManagerList(reportStatus);

                    link = mit;
                    sendSysMsg(maaMangerList, "N0025", link, contentsMap);

                    contentsMap.put("hazard_no", href.replace("$link$", link).replace("$msg$", hazardStatus.getHazardNo()));
                    sendMail(maaMangeLeader, maaMangerList, "N0025", contentsMap);
                    break;

                case MIT_ASSIGN_REJECTED:

                    // FROM: 보고서 접수담당 팀장
                    String marMangeLeader = getReportManageLeader(reportStatus); // TODO user.getEMP_NO();

                    // TO: (수행담당 팀장을 지정한)보고서 접수담당 -> 해당 보고서를 접수한 접수담당자 + 담당자와 같은 부서 접수담당
                    List<String> marMangerList = getReportManagerList(reportStatus);

                    link = mit;
                    sendSysMsg(marMangerList, "N0026", link, contentsMap);

                    contentsMap.put("hazard_no", href.replace("$link$", link).replace("$msg$", hazardStatus.getHazardNo()));
                    sendMail(marMangeLeader, marMangerList, "N0026", contentsMap);

                    break;
                case MIT_ACCEPT_APPROVED:
                    link= mit;
                    // FROM: 경감조치 수행팀 팀장
                    // TO: (수행담당 팀장을 지정한)보고서 접수담당 -> 해당 보고서를 접수한 접수담당자 + 담당자와 같은 부서 접수담당
                    List<String> maa2MangerList = getReportManagerList(reportStatus);

                    sendSysMsg(maa2MangerList, "N0010", link, contentsMap);
                    break;
                case MIT_ACCEPT_REJECTED:
                    link=mit;
                    // FROM: 경감조치 수행팀 팀장
                    MitigationMemberDto mar2MitigationMember = selectMitigationMember(processVo.getHazardId());

                    // TO: (수행담당 팀장을 지정한)보고서 접수담당 -> 해당 보고서를 접수한 접수담당자 + 담당자와 같은 부서 접수담당
                    List<String> mar2MangerList = getReportManagerList(reportStatus);

                    String receptionLeader = getReportManageLeader(reportStatus);
                    List<String> receptionTeam = new ArrayList<String>(mar2MangerList);
                    receptionTeam.add(receptionLeader);

                    // sendSysMsg(mar2MangerList, "N0023", link, contentsMap);
                    sendSysMsg(receptionTeam, "N0023", link, contentsMap);

                    contentsMap.put("doc_no", href.replace("$link$", link).replace("$msg$", hazardStatus.getHazardNo()));
                    // sendMail(mar2MitigationMember.getLeaderEmpNo(), mar2MangerList, "N0023", contentsMap);
                    sendMail(mar2MitigationMember.getLeaderEmpNo(), receptionTeam, "N0023", contentsMap);

                    break;

                /* N0010(메일/메시지)은 PROCESS 처리 상태에서 발송 처리 불가 -> N0011
                 * [팝업에서 담당자 지정시 해당하는 상황에서는 스텝은 없음]
                 * FROM: 경감조치 수행팀 팀장 MitigationMemberDto.getLeaderEmpNo()
                 * TO: 경감조치 책임 담당자 MitigationMemberDto.getEmpNo()
                 * contentsMap.put("due date", MitigationMemberDto.getPlanDueAt()) */
                case MIT_RESULT_PLANNED:
                    link = mit;

                    // FROM: 경감조치 책임 담당자
                    MitigationMemberDto mrpMitigationMember = selectMitigationMember(processVo.getHazardId());

                    // TO: (수행담당 팀장을 지정한)보고서 접수담당 -> 해당 보고서를 접수한 접수담당자 + 담당자와 같은 부서 접수담당
                    List<String> mrpMangerList = getReportManagerList(reportStatus);

                    sendSysMsg(mrpMangerList, "N0012", link, contentsMap);
                    sendMail(mrpMitigationMember.getEmpNo(), mrpMangerList, "N0012", contentsMap);
                    break;
                case MIT_RESULT_SUBMITTED:
                    link = secondLsc;

                    // FROM: 경감조치 책임 담당자
                    MitigationMemberDto mrsMitigationMember = selectMitigationMember(processVo.getHazardId());

                    // TO: LSC 참석자 전체 (+ 경감조치 수행팀장 2022-10-21)
                    List<LscMemberDto> mrsLscMemberList = selectLscMember(processVo.getReportId());
                    Set<String> mrsLscSet = mrsLscMemberList.stream().map(LscMemberDto::getEmpNo).collect(Collectors.toSet());
                    mrsLscSet.add(mrsMitigationMember.getLeaderEmpNo());

                    sendSysMsg(new ArrayList<String>(mrsLscSet), "N0013", link, contentsMap);
                    sendMail(mrsMitigationMember.getEmpNo(), new ArrayList<String>(mrsLscSet), "N0013", contentsMap);
                    break;
                case SECOND_RISK_APPROVED:
                    link = mit;

                    // FROM: LSC 리더
                    List<LscMemberDto> srdLscMemberList = selectLscMember(processVo.getReportId());
                    String srdLscLeader = srdLscMemberList.stream().filter(LscMemberDto::isLeader).findFirst()
                            .map(LscMemberDto::getEmpNo).orElse(null);

                    // TO: 경감조치 책임 담당자
                    MitigationMemberDto srdMitigationMember = selectMitigationMember(processVo.getHazardId());

                    sendSysMsg(Arrays.asList(srdMitigationMember.getEmpNo()), "N0014", link, contentsMap);
                    sendMail(srdLscLeader, Arrays.asList(srdMitigationMember.getEmpNo()), "N0014", contentsMap);
                    break;
                case SECOND_RISK_REJECTED:
                    link = mit;

                    // FROM: LSC 리더
                    List<LscMemberDto> srrLscMemberList = selectLscMember(processVo.getReportId());
                    String srrLscLeader = srrLscMemberList.stream().filter(LscMemberDto::isLeader).findFirst()
                            .map(LscMemberDto::getEmpNo).orElse(null);

                    // TO: 경감조치 책임 담당자
                    MitigationMemberDto srrMitigationMember = selectMitigationMember(processVo.getHazardId());

                    sendSysMsg(Arrays.asList(srrMitigationMember.getEmpNo()), "N0024", link, contentsMap);
                    sendMail(srrLscLeader, Arrays.asList(srrMitigationMember.getEmpNo()), "N0024", contentsMap);
                    break;
                case SECOND_RISK_SUBMITTED:
                    //todo khw. 2차평가 이후 알림 발송 변경 필요....


                case ACCEPTANCE_APPROVED:
				/* 2022-10-20 필요없음,  1차 위험도 평가후 SSC에서 승인시 메시지
				link = lsc;
				// TO: LSC 담당 전체
				List<LscMemberDto> aaLscMemberList = selectLscMember(processVo.getReportId());
				Set<String> aaLscSet = aaLscMemberList.stream().map(LscMemberDto::getEmpNo).collect(Collectors.toSet());
				sendSysMsg(new ArrayList<String>(aaLscSet), "N0007", lsc, contentsMap);
				 */
                    link = finalAppr;

                    // FROM: 해당 보고서를 접수한 접수담당
                    // TO: 보고서 접수 담당의 팀장
                    String srsManageLeader = getReportManageLeader(reportStatus);

                    sendSysMsg(Arrays.asList(srsManageLeader), "N0015", link, contentsMap);

                    contentsMap.put("doc_no", href.replace("$link$", link).replace("$msg$", reportStatus.getDocNo()));
                    sendMail(reportStatus.getManagerEmpNo(), Arrays.asList(srsManageLeader), "N0015", contentsMap);
                    break;
                case HZD_CLOSE_APPROVED:

                    // FROM: 보고서 접수담당 팀장
                    String hcaManageLeader = getReportManageLeader(reportStatus); // TODO user.getEMP_NO();

                    // TO: 해당 보고서를 접수한 접수담당자 + 담당자와 같은 부서 접수담당
                    List<String> hcaManagerList = getReportManagerList(reportStatus);

                    link = detail;

                    sendSysMsg(hcaManagerList, "N0027", link, contentsMap);

                    contentsMap.put("hazard_no", href.replace("$link$", link).replace("$msg$", hazardStatus.getHazardNo()));
                    sendMail(hcaManageLeader, hcaManagerList, "N0027", contentsMap);

                    break;
                case HZD_CLOSE_REJECTED:
                case HZD_CLOSE_REJECTED_MIT:

                    // FROM: 보고서 접수담당 팀장
                    String hcrManageLeader = getReportManageLeader(reportStatus); // TODO user.getEMP_NO();

                    // TO: 해당 보고서를 접수한 접수담당자 + 담당자와 같은 부서 접수담당 +(경감조치가 있는경우 LSC Leader)
                    Set<String> managerList = new HashSet<String> (getReportManagerList(reportStatus));
                    if(stat == ReportStatus.HZD_CLOSE_REJECTED_MIT) {
                        List<LscMemberDto> hcrmLscMemberList = selectLscMember(processVo.getReportId());
                        String hcrmLscLeader = hcrmLscMemberList.stream().filter(LscMemberDto::isLeader).findFirst()
                                .map(LscMemberDto::getEmpNo).orElse(null);
                        managerList.add(hcrmLscLeader);

                        link = secondLsc;
                    }else {
                        link=finalAppr;
                    }

                    List<String>hcrManagerList=new ArrayList<String>(managerList);
                    sendSysMsg(hcrManagerList, "N0028", link, contentsMap);

                    contentsMap.put("hazard_no", href.replace("$link$", link).replace("$msg$", hazardStatus.getHazardNo()));
                    sendMail(hcrManageLeader, hcrManagerList, "N0028", contentsMap);

                    break;
                case REPORT_CLOSE_APPROVED:
                    link = detail;
                    // TO: 보고서 접수 담당
                    sendSysMsg(getReportManagerList(reportStatus), "N0016", link, contentsMap);
                    break;
                default:
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ReportProcessDto selectReportStatus(int id) throws Exception {
        ReportProcessDto result = new ReportProcessDto();
        try {
            result = commonSql.selectOne("AvnReportProcess.selectSmReportStatus", id);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return result;
    }

    @Override
    public HazardProcessDto selectHazardStatus(int id) throws Exception {
        HazardProcessDto result = new HazardProcessDto();
        try {
            result = commonSql.selectOne("AvnReportProcess.selectSmHazardStatus", id);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return result;
    }

    @Override
    public MitigationMemberDto selectMitigationMember(int hazardId) throws Exception {
        MitigationMemberDto mitMember = new MitigationMemberDto();
        try {
            mitMember = commonSql.selectOne("AvnReportProcess.selectMitigationMember", hazardId);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return mitMember;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<LscMemberDto> selectLscMember(int reportId) throws Exception {
        List<LscMemberDto> empList = new ArrayList<LscMemberDto>();
        empList = commonSql.selectList("AvnReportProcess.selectLscMember", reportId);
        return empList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ManagerMemberDto> selectManagerMember(boolean isIncludeSA, String ...reportType) throws Exception {
        List<ManagerMemberDto> managerList = new ArrayList<ManagerMemberDto>();

        List<String> roleCdList = new ArrayList<String>();

        if(isIncludeSA) {
            roleCdList.add("SA");
        }

        for(String r : reportType) {
            roleCdList.add(RoleByReport.find(r).getManagerRoleCd());
        }

        if(roleCdList.size() > 1) {
            List<Integer> grpIdList = commonSql.selectList("AvnReportProcess.selectRoleCdGrpId", roleCdList);
            managerList = commonSql.selectList("AvnReportProcess.selectReportManagerMemberByIds", grpIdList);
        } else {
            managerList = commonSql.selectList("AvnReportProcess.selectReportManagerMemberByRoleCd", roleCdList.get(0));
        }

        return managerList;
    }

    /** 보고서 담당자의 팀장 **/
    private String getReportManageLeader(ReportProcessDto reportStatus) throws Exception {
        TbSysUserDto reportManager = ksmsCommonService.selectUser(reportStatus.getManagerEmpNo());
        List<ManagerMemberDto> mangerList = selectManagerMember(false, reportStatus.getReportType());
        ManagerMemberDto manageLeader = mangerList.stream().filter(mgr -> mgr.isManager(reportManager.getDeptId()))
                .findFirst().orElseGet(ManagerMemberDto::new);
        //.map(ManagerMemberDto::getEmpNo).collect(Collectors.toSet());
        return manageLeader.getEmpNo();
    }

    /** 보고서 담당자의 팀원[팀장제외] (자기 자신 포함)
     *  2022. 09. 23. 팀장 추가 **/
    private List<String> getReportManagerList(ReportProcessDto reportStatus) throws Exception {
        TbSysUserDto reportManager = ksmsCommonService.selectUser(reportStatus.getManagerEmpNo());
        List<ManagerMemberDto> mangerList = selectManagerMember(false, reportStatus.getReportType());
        // 보고서 제출시 leader 여부만 체크하여 대상 산출
        if("".equals(reportStatus.getManagerEmpNo())){
            Set<String> managerEmpNoSet = mangerList.stream()
//					.filter(mgr -> !mgr.isManager())
                    .map(ManagerMemberDto::getEmpNo).collect(Collectors.toSet());
            //logger.debug("manager size {}",mangerList.size());
            //logger.debug("managerEmpNoSet size {}",managerEmpNoSet.size());
            return new ArrayList<String>(managerEmpNoSet);
        }
        Set<String> managerEmpNoSet = mangerList.stream()
                .filter(mgr -> mgr.getDeptId() == reportManager.getDeptId() && !mgr.isManager(reportManager.getDeptId()))
                .map(ManagerMemberDto::getEmpNo).collect(Collectors.toSet());
        return new ArrayList<String>(managerEmpNoSet);
    }

}
