package com.koreanair.ksms.avn.audit.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.audit.dto.*;
import com.koreanair.ksms.avn.audit.service.AvnMyAuditService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * AUDIT - 나의 품질심사(My Audit)
 */
@Tag(name = "AvnMyAudit", description = "AUDIT - 나의 품질심사(My Audit) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnMyAuditController {

    @Autowired
    AvnMyAuditService service;

    /**
     * My Audit 현황 조회
     * @param divYear
     * @param myYear
     * @param processingGubun
     * @param empNo
     * @param divSearchList
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Audit 현황 조회", description = "My Audit 현황 조회 API")
    @GetMapping(value = "/audit/my-audit/0/list/audit-statistics")
    public ResponseEntity<?> getAuditMyAuditStatistics(@RequestParam(value="divYear", required=false) String divYear,
                                                       @RequestParam(value="myYear", required=false) String myYear,
                                                       @RequestParam(value="processingGubun", required=false) String processingGubun,
                                                       @RequestParam(value="empNo", required=false) String empNo,
                                                       @RequestParam(value="divSearchList", required=false) String[] divSearchList) {
        Map paramMap = new HashMap();
        paramMap.put("divYear", divYear);
        paramMap.put("myYear", myYear);
        paramMap.put("processingGubun", processingGubun);
        paramMap.put("empNo", empNo);
        paramMap.put("divSearchList", divSearchList);
        TBMyAuditStatisticsDto result = service.selectMyAuditStatistics(paramMap);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * My Audit 목록 조회
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Audit 목록 조회", description = "My Audit 목록 조회 API")
    @Parameters({
            @Parameter(name = "searchType", description = "조회구분(통계클릭 or 조회클릭"),
            @Parameter(name = "staSearchYear", description = "상단통계년도"),
            @Parameter(name = "staSearchGubun", description = "상단통계구분"),
            @Parameter(name = "staSearchDetail", description = "상단통계구분상세"),
            @Parameter(name = "processingGubun", description = "결재권자조회구분"),
            @Parameter(name = "divSearchList", description = "부문"),
            @Parameter(name = "phaseSearchList", description = "진행단계"),
            @Parameter(name = "auditStartDtSearch", description = "Audit Start Date"),
            @Parameter(name = "auditEndDtSearch", description = "Audit End Date"),
            @Parameter(name = "dueStartDtSearch", description = "Due Start Date"),
            @Parameter(name = "dueEndDtSearch", description = "Due End Date"),
            @Parameter(name = "titleSearch", description = "제목"),
            @Parameter(name = "empNo", description = "사번"),
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수")
        })
    @GetMapping(value = "/audit/my-audit/0/list/audit-list")
    public ResponseEntity<?> getAuditMyAuditList(
            @RequestParam(value="searchType", required=false) String searchType,
            @RequestParam(value="staSearchYear", required=false) String staSearchYear,
            @RequestParam(value="staSearchGubun", required=false) String staSearchGubun,
            @RequestParam(value="staSearchDetail", required=false) String staSearchDetail,
            @RequestParam(value="processingGubun", required=false) String processingGubun,
            @RequestParam(value="divSearchList", required=false) String[] divSearchList,
            @RequestParam(value="phaseSearchList", required=false) String[] phaseSearchList,
            @RequestParam(value="auditStartDtSearch", required=false) String auditStartDtSearch,
            @RequestParam(value="auditEndDtSearch", required=false) String auditEndDtSearch,
            @RequestParam(value="dueStartDtSearch", required=false) String dueStartDtSearch,
            @RequestParam(value="dueEndDtSearch", required=false) String dueEndDtSearch,
            @RequestParam(value="titleSearch", required=false) String titleSearch,
            @RequestParam(value="empNo", required=false) String empNo,
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum,
            @RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize) {

        Map paramMap = new HashMap();
        paramMap.put("searchType", searchType);
        paramMap.put("empNo", empNo);
        paramMap.put("divSearchList", divSearchList);

        // 상단통계 클릭시 조회
        if(searchType.equals("statistics")) {
            paramMap.put("staSearchYear", staSearchYear);
            paramMap.put("staSearchGubun", staSearchGubun);
            paramMap.put("staSearchDetail", staSearchDetail);
            paramMap.put("processingGubun", processingGubun);
        }
        // 조회조건으로 조회
        else {
            paramMap.put("phaseSearchList", phaseSearchList);
            paramMap.put("auditStartDtSearch", auditStartDtSearch);
            paramMap.put("auditEndDtSearch", auditEndDtSearch);
            paramMap.put("dueStartDtSearch", dueStartDtSearch);
            paramMap.put("dueEndDtSearch", dueEndDtSearch);
            paramMap.put("titleSearch", titleSearch);
        }

        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TBMyAuditListDto> pageList = service.selectMyAuditList(paramMap);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    /**
     * Audit 일괄등록
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit 일괄등록", description = "Audit 일괄등록 API")
    @PostMapping(value = "/audit/my-audit/0/list/audit-batch")
    public ResponseEntity<?> insertMyAuditBatch(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Audit 상세조회
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit 상세조회", description = "Audit 상세조회 API")
    @GetMapping(value = "/audit/my-audit/0/list/audit/{auditId}")
    public ResponseEntity<?> getMyAuditInfo(@PathVariable(value="auditId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    /**
     * Audit 정보 조회
     * @param auditId the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit 정보 조회", description = "Audit 정보 조회 API")
    @GetMapping(value = "/audit/my-audit/1/audit/{auditId}")
    public ResponseEntity<?> getPlanAuditInfo(@PathVariable(value="auditId", required=true) int auditId) {

        TBAuditDto result = service.selectAuditInfo(auditId);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * 부문별 Checklist 정보 조회
     * @param division
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "부문별 Checklist 정보 조회", description = "부문별 Checklist 정보 조회 API")
    @GetMapping(value = "/audit/my-audit/1/audit/checklist/{division}")
    public ResponseEntity<?> getChecklistByDivision(@PathVariable(value="division", required=true) String division) {
        List<TBAuditChecklistDto> result = service.selectChecklistByDivision(division);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * Airport의 area 정보 조회
     * @param airportCode
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Airport의 area 정보 조회", description = "Airport의 area 정보 조회 API")
    @GetMapping(value = "/audit/my-audit/1/audit/airport/{airportCode}")
    public ResponseEntity<?> getAreaByAirport(@PathVariable(value="airportCode", required=true) String airportCode) {
        List<Map<String, Object>> result = service.selectAreaByAirport(airportCode);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * Plan
     * @param dto the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit Plan 등록", description = "Audit Plan 등록 API")
    @PostMapping(value = "/audit/my-audit/1/plan")
    public ResponseEntity<?> insertMyAuditPlan(@Valid @RequestBody(required=true) TBAuditDto tBAuditDto) {

        Integer returnAuditId = service.insertAuditPlanInfo(tBAuditDto);
        return ResponseUtil.createSuccessResponse(returnAuditId);
    }

    @Operation(summary = "Audit Plan 수정", description = "Audit Plan 수정 API")
    @PutMapping(value = "/audit/my-audit/1/plan/{planId}")
    public ResponseEntity<?> updateMyAuditPlan(
            @PathVariable(value="planId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {
        dto.setKey(key);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Audit Plan 삭제", description = "Audit Plan 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/1/plan/{planId}")
    public ResponseEntity<?> deleteMyAuditPlan(@PathVariable(value="planId", required=true) String key) {
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Plan 정보 제출", description = "Plan 정보 제출 API")
    @PutMapping(value = "/audit/my-audit/1/plan/submit/{planId}")
    public ResponseEntity<?> submitMyAuditPlan(
            @PathVariable(value="planId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Conduct
     * Checklist 정보 조회
     * @param auditId the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit Checklist 정보 조회", description = "Audit Checklist 정보 조회 API")
    @GetMapping(value = "/audit/my-audit/2/conduct/checklist/{auditId}")
    public ResponseEntity<?> getConductChecklistInfo(@PathVariable(value="auditId", required=true) int auditId) {

        List<TBAuditChecklistDto> result = service.selectConductChecklistInfo(auditId);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * Conduct
     * @param dto the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit Conduct 등록", description = "Audit Conduct 등록 API")
    @PostMapping(value = "/audit/my-audit/2/conduct")
    public ResponseEntity<?> insertMyAuditConduct(@Valid @RequestBody(required=true) TBAuditDto tBAuditDto) {
        Integer returnAuditId = service.insertAuditConductInfo(tBAuditDto);
        return ResponseUtil.createSuccessResponse(returnAuditId);
    }

    @Operation(summary = "Conduct 정보 수정", description = "Conduct 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/2/conduct/{auditId}")
    public ResponseEntity<?> updateMyAuditConduct(
            @PathVariable(value="conductId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Conduct 삭제", description = "Conduct 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/2/conduct/{auditId}")
    public ResponseEntity<?> deleteMyAuditConduct(@PathVariable(value="conductId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
    @Operation(summary = "Conduct 정보 제출", description = "Conduct 정보 제출 API")
    @PutMapping(value = "/audit/my-audit/2/conduct/submit/{auditId}")
    public ResponseEntity<?> submitMyAuditConduct(
            @PathVariable(value="conductId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * CAR
     * Finding 정보 조회
     * @param auditId the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit Finding 정보 조회", description = "Audit Finding 정보 조회 API")
    @GetMapping(value = "/audit/my-audit/3/cars/ca/{auditId}")
    public ResponseEntity<?> getCarFindingInfo(@PathVariable(value="auditId", required=true) int auditId) {

        List<TBAuditFindingDto> result = service.selectCarFindingInfo(auditId);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * CAR
     * @param dto the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "신규 CAR 등록", description = "신규 CAR 등록 API")
    @PostMapping(value = "/audit/my-audit/3/cars/ca")
    public ResponseEntity<?> insertMyAuditCAR(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "CAR 정보 수정", description = "CAR 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/3/cars/ca/{carId}")
    public ResponseEntity<?> updateMyAuditCAR(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "CAR 삭제", description = "CAR 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/3/cars/ca/{carId}")
    public ResponseEntity<?> deleteMyAuditCAR(@PathVariable(value="carId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "신규 Action Taken 등록", description = "신규 CAR 등록 API")
        @PostMapping(value = "/audit/my-audit/3/cars/ac")
        public ResponseEntity<?> insertMyAuditCARAc(@Valid @RequestBody(required=true) GenericDto dto) {

            return ResponseUtil.createSuccessResponse();
        }

        @Operation(summary = "Action Taken 정보 수정", description = "CAR 정보 수정 API")
        @PutMapping(value = "/audit/my-audit/3/cars/ac/{carId}")
        public ResponseEntity<?> updateMyAuditCARAc(
                @PathVariable(value="carId", required=true) String key,
                @Valid @RequestBody(required=true) GenericDto dto) {

            dto.setKey(key);

            return ResponseUtil.createSuccessResponse();
        }

        @Operation(summary = "Action Taken 삭제", description = "CAR 삭제 API")
        @DeleteMapping(value = "/audit/my-audit/3/cars/ac/{carId}")
        public ResponseEntity<?> deleteMyAuditCARAc(@PathVariable(value="carId", required=true) String key) {

            return ResponseUtil.createSuccessResponse();
        }

    @Operation(summary = "CAR 정보 제출", description = "CAR 정보 제출 API")
    @PutMapping(value = "/audit/my-audit/3/cars/submit/{carId}")
    public ResponseEntity<?> submitMyAuditCAR(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Close
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "Close 공유 등록", description = "Close 공유 등록 API")
    @PostMapping(value = "/audit/my-audit/4/close")
    public ResponseEntity<?> insertMyAuditClose(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Close 공유 현황 조회
     * @param key the key
     * @return the deadline manage info
     * @throws Exception the exception
     */
    @Operation(summary = "Close 공유 현황 조회", description = "Close 공유 현황 조회 API")
    @GetMapping(value = "/audit/my-audit/4/close/{closeId}")
    public ResponseEntity<?> getMyAuditCloseInfo(@PathVariable(value="closeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
