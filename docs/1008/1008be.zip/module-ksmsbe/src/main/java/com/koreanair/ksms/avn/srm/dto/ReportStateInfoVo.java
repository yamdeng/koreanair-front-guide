package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.util.List;

@Getter
@Setter
@ToString
@Accessors(chain = true)
@Schema(description = "보고서 접수 상세 데이터")
public class ReportStateInfoVo {

    private String reportType;

    @Schema(description = "보고서상태리스트")
    private List<SmReport> reportStateList;

    @Schema(description = "step Open 여부(Y | N)")
    private String isStep1Open;
    private String isStep2Open;
    private String isStep3Open;
    private String isStep4Open;
    private String isStep5Open;
    private String isStep6Open;
    private String isStep7Open;
    private String isStep8Open;
    private String isStep9Open;

    @Schema(description = "step 사용자 권한 타입 : 일반(열람) VW | 담당 MG | 관리자 SA ")
    private String step1Auth;
    private String step2Auth;
    private String step3Auth;
    private String step4Auth;
    private String step5Auth;
    private String step6Auth;
    private String step7Auth;
    private String step8Auth;
    private String step9Auth;

    @Schema(description = "리더 여부.. ")
    private String isTeamLeader;

    @Schema(description = "부문의 안전팀 여부..")
    private String isSectorSafety;

    @Schema(description = "경감팀의 리더나 팀원인지 여부..")
    private String isMitigationTeamMng;

    @Schema(description = "경감팀의 책임자 여부..")
    private String isMitigationTeamWork;
}
