package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnEquipCodeMgmtDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnRsrManageServiceImpl extends AbstractBaseService implements AvnRsrManageService {
    // EquipCd 목록 조회
    @Override
    public PageInfo<TbAvnEquipCodeMgmtDto> selectEquipCdList(TbAvnEquipCodeMgmtDto tbAvnEquipCodeMgmtDto) {
        List<TbAvnEquipCodeMgmtDto> resultList = commonSql.selectList("AvnRsrManage.selectEquipCdList", tbAvnEquipCodeMgmtDto);
        return PageInfo.of(resultList);
    }

    // EquipCd 신규 등록
    @Override
    public void insertEquipCd(TbAvnEquipCodeMgmtDto tbAvnEquipCodeMgmtDto) {

        //날짜 포맷 변경
        String DtFormatChange = tbAvnEquipCodeMgmtDto.getProductionDt();
        DtFormatChange = DtFormatChange.replace("-", "");
        DtFormatChange = DtFormatChange.substring(0,8);

        tbAvnEquipCodeMgmtDto.setProductionDt(DtFormatChange);

        commonSql.insert("AvnRsrManage.insertEquipCd", tbAvnEquipCodeMgmtDto);
    }

    // EquipCd 상세
    @Override
    public TbAvnEquipCodeMgmtDto selectEquipCdDetail(String equipCd) {
        return commonSql.selectOne("AvnRsrManage.selectEquipCdDetail", equipCd);
    }

    // EquipCd 수정
    @Override
    public void updateEquipCd(TbAvnEquipCodeMgmtDto tbAvnEquipCodeMgmtDto) {
        commonSql.update("AvnRsrManage.updateEquipCd", tbAvnEquipCodeMgmtDto);
    }

    // EquipCd 삭제
    @Override
    public void deleteEquipCd(String equipCd) {
        commonSql.delete("AvnRsrManage.deleteEquipCd", equipCd);
    }
}
