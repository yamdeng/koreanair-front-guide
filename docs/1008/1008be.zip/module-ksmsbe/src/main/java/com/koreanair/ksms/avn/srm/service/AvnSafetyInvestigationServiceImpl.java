package com.koreanair.ksms.avn.srm.service;

import java.util.ArrayList;
import java.util.List;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.dto.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.koreanair.ksms.avn.srm.dto.IvStatusCode.Status;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;

@RequiredArgsConstructor
@Service
public class AvnSafetyInvestigationServiceImpl extends AbstractBaseService implements AvnSafetyInvestigationService {

    private final IvApprovalService ivApprovalService;

    @Override
    public PageInfo<AvnSafetyInvestigationDto>selectInveReportList(AvnSafetyInvestigationDto avnSafetyInvestigationDto){
        List<AvnSafetyInvestigationDto> resultList = commonSql.selectList("AvnSafetyInvestigation.selectInveReportList", avnSafetyInvestigationDto);
        return PageInfo.of(resultList);
    }

    @Override
    public List<AvnSafetyInvestigationEventTypeDto>selectEventTypeASRList(){
        List<AvnSafetyInvestigationEventTypeDto> resultList = commonSql.selectList("AvnSafetyInvestigation.selectEventTypeASRList");
        return resultList;
    }

    @Override
    public List<AvnSafetyInvestifationConsequenceDto> selectConsequenceList(){
        List<AvnSafetyInvestifationConsequenceDto> resultList = commonSql.selectList("AvnSafetyInvestigation.selectConsequenceList");
        return resultList;
    }

    @Override
    public List<AvnSafetyInvestifationHazardDto> selectHazardList(){
        List<AvnSafetyInvestifationHazardDto> resultList = commonSql.selectList("AvnSafetyInvestigation.selectHazardList");
        return resultList;
    }

    @Override
    public void insertInvestigation(AvnSafetyInvestigationFormDto avnSafetyInvestigationFormDto){
        //조사보고서 신규 등록
        commonSql.insert("AvnSafetyInvestigation.insertInvestigation", avnSafetyInvestigationFormDto);
        int boardID = avnSafetyInvestigationFormDto.getId();

        //위험평가 신규 등록
        for(TbAvnIvHazard tbAvnIvHazard : avnSafetyInvestigationFormDto.getHazardList()){
            tbAvnIvHazard.setReportId(boardID);
            tbAvnIvHazard.setInvestigationId(avnSafetyInvestigationFormDto.getCreateReportID());

            commonSql.insert("AvnSafetyInvestigation.insertRiskAssessment",tbAvnIvHazard);
        }

        //승무원 신규 등록
        for(IvCrewMemberDTO ivCrewMemberDTO : avnSafetyInvestigationFormDto.getCrewMemberList()){
            TbAvnIvCrew tbAvnIvCrew = new TbAvnIvCrew();
            tbAvnIvCrew.setEmpNo(ivCrewMemberDTO.getEmpNo());
            tbAvnIvCrew.setReportID(boardID);

            commonSql.insert("AvnSafetyInvestigation.insertCrewMember",tbAvnIvCrew);
        }

        //참고문서 신규 등록
        for(SmSearchReport smSearchReport : avnSafetyInvestigationFormDto.getReportDocument()){
            TbAvnIvReportSmReport tbAvnIvReportSmReport = new TbAvnIvReportSmReport();
            tbAvnIvReportSmReport.setIvReportId(boardID);
            tbAvnIvReportSmReport.setSmReportId(smSearchReport.getId());

            commonSql.insert("AvnSafetyInvestigation.insertIvReportSmReport", tbAvnIvReportSmReport);
        }
        //결재 그룹 멤버 수정( 결재 멤버 추가 or 결재 그룹 정렬번호 수정 )
        for(AvnIvReportApprovalGroupMember member : avnSafetyInvestigationFormDto.getApprovalMemberList()){
            commonSql.insert("AvnCommon.insertIvApprovalGroupMember",member);
        }

        //조사보고서 개요 저장
        commonSql.insert("AvnSafetyInvestigation.insertIvPost",avnSafetyInvestigationFormDto);
        commonSql.insert("AvnSafetyInvestigation.insertIvPostNum",avnSafetyInvestigationFormDto);


        //보고서 결재 이력 신규 추가
        Status status = avnSafetyInvestigationFormDto.getIsSubmitted().equals("Y")? Status.REPORTING_SUBMITTED : Status.REPORTING_DRAFT;
        IvProcessDto process = IvProcessDto.builder()
                .id(boardID)
                .empNo(avnSafetyInvestigationFormDto.getEmpNo())
                .status(status)
                .timezone("utc")
                .build();

        ivApprovalService.processInvestigation(process);
    }

    @Override
    public List<AvnIvReportApprovalGroup> selectApprovalGroupList(){

        CommonDto commonDto = new CommonDto();
        return commonSql.selectList("AvnCommon.selectIvApprovalGroup",commonDto);
    }

    @Override
    public List<AvnIvReportApprovalGroupMember> selectApprovalGroupMemberList(int groupId){
        return commonSql.selectList("AvnCommon.selectIvApprovalGroupMember",groupId);
    }

    @Override
    public void insertIvApprovalGroup(AvnIvReportApproval avnIvReportApproval){
        if(avnIvReportApproval.getGroup().getInsertGroupFlag().equals("Y")){
            commonSql.insert("AvnCommon.insertIvApprovalGroup",avnIvReportApproval);
        }else{
            for(AvnIvReportApprovalGroupMember member : avnIvReportApproval.getMemberList()){
                commonSql.insert("AvnCommon.insertIvApprovalGroupMember",member);
            }

        }
    }

    @Override
    public TbAvnSysUserDto searchEmpNoUserInfo(AvnIvReportApprovalGroupMember avnIvReportApprovalGroupMember){
        return commonSql.selectOne("AvnCommon.searchEmpNoUserInfo", avnIvReportApprovalGroupMember);
    }

    @Override
    public AvnSafetyInvestigationDetailDto selectIvReportDetail(int id){

        //조사보고서 view 테이블 조회
        AvnSafetyInvestigationDto viewIvReportDetailInfo = commonSql.selectOne("AvnSafetyInvestigation.selectViewIvReport", id);
        //조사보고서 테이블 조회
        TbAvnIvReportDTO tbAvnIvReportDTO = commonSql.selectOne("AvnSafetyInvestigation.selectIvReport",id);
        //조사보고서 결재자 회원정보 조회
        IvCrewMemberDTO investigatorInfo = commonSql.selectOne("AvnSafetyInvestigation.searchIvEmpNoUserInfo", tbAvnIvReportDTO.getInvestigateBy());
        //조사보고서 승무원 회원정보 조회
        List<IvCrewMemberDTO> crewMemberList = commonSql.selectList("AvnSafetyInvestigation.selectCrewMemberInfoList",id);
        //조사보고서 개요ID, 개요내용, 첨부파일, 조사자 조회
        IvInvestigationReportDTO ivInvestigationReportDTO = commonSql.selectOne("AvnSafetyInvestigation.selectInvestigationReport", id);

        //위험평가 조회
        List<TbAvnIvHazard> ivHazard = commonSql.selectList("AvnSafetyInvestigation.selectIvHazard", id);
        List<IvAssumptionDTO> ivAssumption = new ArrayList<>();
        List<IvRadicalDTO> ivRadical = new ArrayList<>();

        for(TbAvnIvHazard tbAvnIvHazard : ivHazard){
            if(tbAvnIvHazard.getHazardType().equals("ast")){
                IvAssumptionDTO ivAssumptionDTO = new IvAssumptionDTO();

                ivAssumptionDTO.setRiskAssessmentId(tbAvnIvHazard.getId());
                ivAssumptionDTO.setHazardType(tbAvnIvHazard.getHazardType());
                ivAssumptionDTO.setHazardId(tbAvnIvHazard.getHazardId());
                ivAssumptionDTO.setHazardName(tbAvnIvHazard.getHazardName());
                ivAssumptionDTO.setConsequenceId(tbAvnIvHazard.getConsequenceId());
                ivAssumptionDTO.setConsequenceName(tbAvnIvHazard.getConsequenceName());
                ivAssumption.add(ivAssumptionDTO);
            }else{
                IvRadicalDTO ivRadicalDTO = new IvRadicalDTO();

                ivRadicalDTO.setRiskAssessmentId(tbAvnIvHazard.getId());
                ivRadicalDTO.setHazardType(tbAvnIvHazard.getHazardType());
                ivRadicalDTO.setHazardId(tbAvnIvHazard.getHazardId());
                ivRadicalDTO.setHazardName(tbAvnIvHazard.getHazardName());
                ivRadicalDTO.setConsequenceId(tbAvnIvHazard.getConsequenceId());
                ivRadicalDTO.setConsequenceName(tbAvnIvHazard.getConsequenceName());
                ivRadical.add(ivRadicalDTO);
            }
        }

        CommonDto commonDto = new CommonDto();
        //결재 그룹 목록 조회
        List<AvnIvReportApprovalGroup> approvalGroupList = commonSql.selectList("AvnCommon.selectIvApprovalGroup",commonDto);
        //결재 그룹 멤버 목록 조회
        List<AvnIvReportApprovalGroupMember> approvalMemberList = commonSql.selectList("AvnCommon.selectIvApprovalGroupMember",Integer.parseInt(tbAvnIvReportDTO.getApprovedId()));
        //결재 그룹 멤버회원정보 조회
        List<IvCrewMemberDTO> approvalMemberInfoList = commonSql.selectList("AvnSafetyInvestigation.approvalMemberInfoList", Integer.parseInt(tbAvnIvReportDTO.getApprovedId()));

        //참고문서 조회
        List<SmSearchReport> reportDocumentList = commonSql.selectList("AvnSafetyInvestigation.selectReportDocumentList", id);

        //FormDTO
        AvnSafetyInvestigationDetailDto avnSafetyInvestigationDetailDto = AvnSafetyInvestigationDetailDto.builder()
                .id(tbAvnIvReportDTO.getId())
                .reportNo(tbAvnIvReportDTO.getReportNo())
                .reportTitle(tbAvnIvReportDTO.getReportTitle())
                //발생정보
                .occurrenceInformation(IvOccurrenceInformationDTO.builder()
                    .eventAt(tbAvnIvReportDTO.getEventAt())
                    .eventAtTz(tbAvnIvReportDTO.getEventAtTz())
                    .classification(tbAvnIvReportDTO.getClassification())
                    .classificationNameKor(tbAvnIvReportDTO.getClassificationNameKor())
                    .classificationNameEng(tbAvnIvReportDTO.getClassificationNameEng())
                    .eventId(tbAvnIvReportDTO.getEventId())
                    .eventNm(tbAvnIvReportDTO.getEventNm())
                    .airport(tbAvnIvReportDTO.getAirport())
                    .flightPhase(tbAvnIvReportDTO.getFlightPhase())
                    .flightPhaseNameKor(tbAvnIvReportDTO.getFlightPhaseNameKor())
                    .flightPhaseNameEng(tbAvnIvReportDTO.getFlightPhaseNameEng())
                    .weatherText(tbAvnIvReportDTO.getWeatherText())
                    .isSpi(tbAvnIvReportDTO.getIsSpi())
                    .spiFileGroupSeq(tbAvnIvReportDTO.getSpiFileGroupSeq())
                    .locationText(tbAvnIvReportDTO.getLocationText())
                    .build()
                )
                //비행정보
                .flight(IvFlightDTO.builder()
                        .departureAt(tbAvnIvReportDTO.getDepartureAt())
                        .flightNo(tbAvnIvReportDTO.getFlightNo())
                        .registrationNo(tbAvnIvReportDTO.getRegistrationNo())
                        .aircraftTypeText(tbAvnIvReportDTO.getAircraftTypeText())
                        .fromAirport(tbAvnIvReportDTO.getFromAirport())
                        .toAirport(tbAvnIvReportDTO.getToAirport())
                        .divertAirport(tbAvnIvReportDTO.getDivertAirport())
                        .supply(tbAvnIvReportDTO.getSupply())
                        .checkIn(tbAvnIvReportDTO.getCheckIn())
                        .build()
                )
                //조사보고서
                .investigationReport(IvInvestigationReportDTO.builder()
                        .postId(ivInvestigationReportDTO.getPostId())
                        .postContents(ivInvestigationReportDTO.getPostContents())
                        .reportFileGroupSeq(tbAvnIvReportDTO.getReportFileGroupSeq())
                        .investigateBy(tbAvnIvReportDTO.getInvestigateBy())
                        .build()
                )
                .crewMemberList(crewMemberList)
                .hazardList(ivHazard)
                .hazardId("")
                .hazardType("ast")
                .consequenceId("")
                .approvalGroupID(Integer.parseInt(tbAvnIvReportDTO.getApprovedId()))
                .approvalGroupList(approvalGroupList)
                //1차위험평가
                .memberList(approvalMemberInfoList)
                .approvalMemberList(approvalMemberList)
                .reportDocument(reportDocumentList)
                .radicalList(ivRadical)
                .assumptionList(ivAssumption)
                .investigateName(investigatorInfo.getCustomLabel())
                .isSubmitted(tbAvnIvReportDTO.getIsSubmitted())
                .empNo(tbAvnIvReportDTO.getEmpNo())
                .viewIvReportInfo(viewIvReportDetailInfo)
                .build();


        return avnSafetyInvestigationDetailDto;
    }
    //조사보고서 수정
    @Override
    public void updateInvestigation(AvnSafetyInvestigationUpdateFormDto avnSafetyInvestigationUpdateFormDto) {

        //조사보고서 수정
        commonSql.update("AvnSafetyInvestigation.updateInvestigation", avnSafetyInvestigationUpdateFormDto);

        //승무원 삭제 후 재등록
        commonSql.delete("AvnSafetyInvestigation.deleteCrewMember", avnSafetyInvestigationUpdateFormDto.getId());

        for (IvCrewMemberDTO ivCrewMemberDTO : avnSafetyInvestigationUpdateFormDto.getCrewMemberList()) {
            TbAvnIvCrew tbAvnIvCrew = new TbAvnIvCrew();
            tbAvnIvCrew.setEmpNo(ivCrewMemberDTO.getEmpNo());
            tbAvnIvCrew.setReportID(avnSafetyInvestigationUpdateFormDto.getId());

            commonSql.insert("AvnSafetyInvestigation.insertCrewMember", tbAvnIvCrew);
        }

        //위험평가 삭제 후 재등록
        commonSql.delete("AvnSafetyInvestigation.deleteRiskAssessment", avnSafetyInvestigationUpdateFormDto.getId());

        for (TbAvnIvHazard tbAvnIvHazard : avnSafetyInvestigationUpdateFormDto.getHazardList()) {
            tbAvnIvHazard.setReportId(avnSafetyInvestigationUpdateFormDto.getId());
            tbAvnIvHazard.setInvestigationId(avnSafetyInvestigationUpdateFormDto.getReportNo());

            commonSql.insert("AvnSafetyInvestigation.insertRiskAssessment", tbAvnIvHazard);
        }


        //참고문서 삭제 후 재등록
        commonSql.delete("AvnSafetyInvestigation.deleteIvReportSmReport", avnSafetyInvestigationUpdateFormDto.getId());

        for (SmSearchReport smSearchReport : avnSafetyInvestigationUpdateFormDto.getReportDocument()) {
            TbAvnIvReportSmReport tbAvnIvReportSmReport = new TbAvnIvReportSmReport();
            tbAvnIvReportSmReport.setIvReportId(avnSafetyInvestigationUpdateFormDto.getId());
            tbAvnIvReportSmReport.setSmReportId(smSearchReport.getId());

            commonSql.insert("AvnSafetyInvestigation.insertIvReportSmReport", tbAvnIvReportSmReport);
        }
        //결재 그룹 멤버 수정( 결재 멤버 추가 or 결재 그룹 정렬번호 수정 )
        for (AvnIvReportApprovalGroupMember member : avnSafetyInvestigationUpdateFormDto.getApprovalMemberList()) {
            commonSql.insert("AvnCommon.insertIvApprovalGroupMember", member);
        }

        //조사보고서 개요 저장
        commonSql.update("AvnSafetyInvestigation.updateIvPost", avnSafetyInvestigationUpdateFormDto);


        //보고서 결재 이력 신규 추가
        Status status = avnSafetyInvestigationUpdateFormDto.getIsSubmitted().equals("Y") ? Status.REPORTING_SUBMITTED : Status.REPORTING_DRAFT;
        IvProcessDto process = IvProcessDto.builder()
                .id(avnSafetyInvestigationUpdateFormDto.getId())
                .empNo(avnSafetyInvestigationUpdateFormDto.getEmpNo())
                .status(status)
                .timezone("utc")
                .build();

        ivApprovalService.processInvestigation(process);
    }

    @Override
    public AvnSafetyInvestigationMitigationDetailDto selectIvReportMitigationDetail(int id){

        //조사보고서 view 테이블 조회
        AvnSafetyInvestigationDto viewIvReportDetailInfo = commonSql.selectOne("AvnSafetyInvestigation.selectViewIvReport", id);
        //조사보고서 테이블 조회
        TbAvnIvReportDTO tbAvnIvReportDTO = commonSql.selectOne("AvnSafetyInvestigation.selectIvReport",id);
        //조사보고서 결재자 회원정보 조회
        IvCrewMemberDTO investigatorInfo = commonSql.selectOne("AvnSafetyInvestigation.searchIvEmpNoUserInfo", tbAvnIvReportDTO.getInvestigateBy());
        //조사보고서 승무원 회원정보 조회
        List<IvCrewMemberDTO> crewMemberList = commonSql.selectList("AvnSafetyInvestigation.selectCrewMemberInfoList",id);
        //조사보고서 개요ID, 개요내용, 첨부파일, 조사자 조회
        IvInvestigationReportDTO ivInvestigationReportDTO = commonSql.selectOne("AvnSafetyInvestigation.selectInvestigationReport", id);

        //위험평가 조회
        List<TbAvnIvHazard> ivHazard = commonSql.selectList("AvnSafetyInvestigation.selectIvHazard", id);
        List<IvAssumptionDTO> ivAssumption = new ArrayList<>();
        List<IvRadicalDTO> ivRadical = new ArrayList<>();

        for(TbAvnIvHazard tbAvnIvHazard : ivHazard){
            if(tbAvnIvHazard.getHazardType().equals("ast")){
                IvAssumptionDTO ivAssumptionDTO = new IvAssumptionDTO();

                ivAssumptionDTO.setRiskAssessmentId(tbAvnIvHazard.getId());
                ivAssumptionDTO.setHazardType(tbAvnIvHazard.getHazardType());
                ivAssumptionDTO.setHazardId(tbAvnIvHazard.getHazardId());
                ivAssumptionDTO.setHazardName(tbAvnIvHazard.getHazardName());
                ivAssumptionDTO.setConsequenceId(tbAvnIvHazard.getConsequenceId());
                ivAssumptionDTO.setConsequenceName(tbAvnIvHazard.getConsequenceName());
                ivAssumption.add(ivAssumptionDTO);
            }else{
                IvRadicalDTO ivRadicalDTO = new IvRadicalDTO();

                ivRadicalDTO.setRiskAssessmentId(tbAvnIvHazard.getId());
                ivRadicalDTO.setHazardType(tbAvnIvHazard.getHazardType());
                ivRadicalDTO.setHazardId(tbAvnIvHazard.getHazardId());
                ivRadicalDTO.setHazardName(tbAvnIvHazard.getHazardName());
                ivRadicalDTO.setConsequenceId(tbAvnIvHazard.getConsequenceId());
                ivRadicalDTO.setConsequenceName(tbAvnIvHazard.getConsequenceName());
                ivRadical.add(ivRadicalDTO);
            }
        }

        CommonDto commonDto = new CommonDto();
        //결재 그룹 목록 조회
        List<AvnIvReportApprovalGroup> approvalGroupList = commonSql.selectList("AvnCommon.selectIvApprovalGroup",commonDto);

        List<AvnIvReportApprovalGroupMember> approvalMemberList = new ArrayList<>();
        List<IvCrewMemberDTO> approvalMemberInfoList = new ArrayList<>();

        if(tbAvnIvReportDTO.getApprovedId() != null && !tbAvnIvReportDTO.getApprovedId().isEmpty()){
            //결재 그룹 멤버 목록 조회
            approvalMemberList = commonSql.selectList("AvnCommon.selectIvApprovalGroupMember",Integer.parseInt(tbAvnIvReportDTO.getApprovedId()));
            //결재 그룹 멤버회원정보 조회
            approvalMemberInfoList = commonSql.selectList("AvnSafetyInvestigation.approvalMemberInfoList", Integer.parseInt(tbAvnIvReportDTO.getApprovedId()));
        }
        //참고문서 조회
        List<SmSearchReport> reportDocumentList = commonSql.selectList("AvnSafetyInvestigation.selectReportDocumentList", id);

        List<TbAvnIvCaRecommentDto> tbAvnIvCaRecommentDto = commonSql.selectList("AvnSafetyInvestigation.selectTbAvnIvRecomment",id);

        List<TbAvnIvCaSafetyDto> tbAvnIvCaSafetyDto = commonSql.selectList("AvnSafetyInvestigation.selectTbAvnIvSafety",id);

        //FormDTO
        AvnSafetyInvestigationMitigationDetailDto avnSafetyInvestigationMitigationDetailDto = AvnSafetyInvestigationMitigationDetailDto.builder()
                .id(tbAvnIvReportDTO.getId())
                .reportNo(tbAvnIvReportDTO.getReportNo())
                .reportTitle(tbAvnIvReportDTO.getReportTitle())
                //발생정보
                .occurrenceInformation(IvOccurrenceInformationDTO.builder()
                        .eventAt(tbAvnIvReportDTO.getEventAt())
                        .eventAtTz(tbAvnIvReportDTO.getEventAtTz())
                        .classification(tbAvnIvReportDTO.getClassification())
                        .classificationNameKor(tbAvnIvReportDTO.getClassificationNameKor())
                        .classificationNameEng(tbAvnIvReportDTO.getClassificationNameEng())
                        .eventId(tbAvnIvReportDTO.getEventId())
                        .eventNm(tbAvnIvReportDTO.getEventNm())
                        .airport(tbAvnIvReportDTO.getAirport())
                        .flightPhase(tbAvnIvReportDTO.getFlightPhase())
                        .flightPhaseNameKor(tbAvnIvReportDTO.getFlightPhaseNameKor())
                        .flightPhaseNameEng(tbAvnIvReportDTO.getFlightPhaseNameEng())
                        .weatherText(tbAvnIvReportDTO.getWeatherText())
                        .isSpi(tbAvnIvReportDTO.getIsSpi())
                        .spiFileGroupSeq(tbAvnIvReportDTO.getSpiFileGroupSeq())
                        .locationText(tbAvnIvReportDTO.getLocationText())
                        .build()
                )
                //비행정보
                .flight(IvFlightDTO.builder()
                        .departureAt(tbAvnIvReportDTO.getDepartureAt())
                        .flightNo(tbAvnIvReportDTO.getFlightNo())
                        .registrationNo(tbAvnIvReportDTO.getRegistrationNo())
                        .aircraftTypeText(tbAvnIvReportDTO.getAircraftTypeText())
                        .fromAirport(tbAvnIvReportDTO.getFromAirport())
                        .toAirport(tbAvnIvReportDTO.getToAirport())
                        .divertAirport(tbAvnIvReportDTO.getDivertAirport())
                        .supply(tbAvnIvReportDTO.getSupply())
                        .checkIn(tbAvnIvReportDTO.getCheckIn())
                        .build()
                )
                //조사보고서
                .investigationReport(IvInvestigationReportDTO.builder()
                        .postId(ivInvestigationReportDTO.getPostId())
                        .postContents(ivInvestigationReportDTO.getPostContents())
                        .reportFileGroupSeq(tbAvnIvReportDTO.getReportFileGroupSeq())
                        .investigateBy(tbAvnIvReportDTO.getInvestigateBy())
                        .build()
                )
                .crewMemberList(crewMemberList)
                .hazardList(ivHazard)
                .hazardId("")
                .hazardType("ast")
                .consequenceId("")
                .approvalGroupID(tbAvnIvReportDTO.getApprovedId())
                .approvalGroupList(approvalGroupList)
                .memberList(approvalMemberInfoList)
                .approvalMemberList(approvalMemberList)
                .reportDocument(reportDocumentList)
                .radicalList(ivRadical)
                .assumptionList(ivAssumption)
                .investigateName(investigatorInfo.getCustomLabel())
                .isSubmitted(tbAvnIvReportDTO.getIsSubmitted())
                .empNo(tbAvnIvReportDTO.getEmpNo())
                .viewIvReportInfo(viewIvReportDetailInfo)
                .safetyAdvList(tbAvnIvCaRecommentDto)
                .safetyActList(tbAvnIvCaSafetyDto)
                .build();

        return avnSafetyInvestigationMitigationDetailDto;
    }

    //조사보고서 수정
    @Override
    public void updateInvestigationMitigation(AvnSafetyInvestigationMitigationUpdateFormDto avnSafetyInvestigationMitigationUpdateFormDto) {
        
//        //안전권고 삭제
//        commonSql.delete("AvnSafetyInvestigation.deleteIvCaRecomment",avnSafetyInvestigationMitigationUpdateFormDto.getId());
//
//        //Safety Day 삭제
//        commonSql.delete("AvnSafetyInvestigation.deleteIvCaSafetyAction",avnSafetyInvestigationMitigationUpdateFormDto.getId());

        //안전권고 신규 or 수정
        for(TbAvnIvCaRecommentDto tbAvnIvCaRecommentDto : avnSafetyInvestigationMitigationUpdateFormDto.getSafetyAdvList()){
            tbAvnIvCaRecommentDto.setReportId(String.valueOf(avnSafetyInvestigationMitigationUpdateFormDto.getId()));
            if(tbAvnIvCaRecommentDto.getId() == null){
                TbAvnIvCaDto tbAvnIvCaDto = new TbAvnIvCaDto();
                tbAvnIvCaDto.setReportId(avnSafetyInvestigationMitigationUpdateFormDto.getId());
                commonSql.insert("AvnSafetyInvestigation.insertIvCa",tbAvnIvCaDto);

                tbAvnIvCaRecommentDto.setCaId(String.valueOf(tbAvnIvCaDto.getId()));
                tbAvnIvCaRecommentDto.setRecommendNo(avnSafetyInvestigationMitigationUpdateFormDto.getReportNo()+"-R");
            }
            commonSql.insert("AvnSafetyInvestigation.insertSafetyAdv", tbAvnIvCaRecommentDto);
        }
        //Safety Day 신규 or 수정
        for(TbAvnIvCaSafetyDto tbAvnIvCaSafetyDto : avnSafetyInvestigationMitigationUpdateFormDto.getSafetyActList()){
            tbAvnIvCaSafetyDto.setReportId(String.valueOf(avnSafetyInvestigationMitigationUpdateFormDto.getId()));
            if(tbAvnIvCaSafetyDto.getId() == null){
                TbAvnIvCaDto tbAvnIvCaDto = new TbAvnIvCaDto();
                tbAvnIvCaDto.setReportId(avnSafetyInvestigationMitigationUpdateFormDto.getId());
                commonSql.insert("AvnSafetyInvestigation.insertIvCa",tbAvnIvCaDto);

                tbAvnIvCaSafetyDto.setCaId(String.valueOf(tbAvnIvCaDto.getId()));
                tbAvnIvCaSafetyDto.setSafetyNo("Safety Action-");
            }
            commonSql.insert("AvnSafetyInvestigation.insertSafetyAction", tbAvnIvCaSafetyDto);
        }
        
        //2차 위험평가 수정
        for (TbAvnIvHazard tbAvnIvHazard : avnSafetyInvestigationMitigationUpdateFormDto.getHazardList()) {
            commonSql.update("AvnSafetyInvestigation.updateRiskAssessment", tbAvnIvHazard);
        }

        
        //보고서 결재 이력 신규 추가
        Status status = avnSafetyInvestigationMitigationUpdateFormDto.getIsSubmitted().equals("Y") ? Status.MITIGATION_SUBMITTED : Status.MITIGATION_DRAFT;
        IvProcessDto process = IvProcessDto.builder()
                .id(avnSafetyInvestigationMitigationUpdateFormDto.getId())
                .empNo(avnSafetyInvestigationMitigationUpdateFormDto.getEmpNo())
                .status(status)
                .timezone("utc")
                .build();

        ivApprovalService.processInvestigation(process);
    }

    //안전조사 > 조사보고서 > 안전권고, Safety Action 삭제
    @Override
    public void deleteInveReportCa(TbAvnIvCaDto tbAvnIvCaDto){
        commonSql.update("AvnSafetyInvestigation.deleteIvCa", tbAvnIvCaDto);
    }

    //안전조사 > 조사보고서 삭제
    @Override
    public void deleteInvestigation(int reportId){
        commonSql.update("AvnSafetyInvestigation.deleteInvestigationAll", reportId);
    }
}
