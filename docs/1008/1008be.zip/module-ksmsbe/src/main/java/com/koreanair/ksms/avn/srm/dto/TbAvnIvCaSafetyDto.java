package com.koreanair.ksms.avn.srm.dto;


import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbAvnIvCaSafetyDto extends CommonDto {

    @Schema(description = "ID")
    private String id;

    @Schema(description = "tb_avn_iv_ca ID")
    private String caId;

    @Schema(description = "safety ID. No")
    private String safetyNo;

    @Schema(description = "Action Taken")
    private String actionTaken;

    @Schema(description = "Action일자(YYYY-MM-DD)")
    private String actionAt;

    @Schema(description = "Division")
    private String deptCd;

    @Schema(description = "등록자 사원번호")
    private String empNo;

    @Schema(description = "리포트 번호")
    private String reportId;

    @Schema(description = "마지막 번호")
    private String lastnumber;
}
