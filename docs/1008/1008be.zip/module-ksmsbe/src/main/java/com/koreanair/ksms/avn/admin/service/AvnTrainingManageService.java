package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnEducationDto;

public interface AvnTrainingManageService {

    // 관리자 > SMS교육 > 교육관리 목록 조회
    PageInfo<TbAvnEducationDto> selectAvnEducationMgmt(TbAvnEducationDto tbAvnEducationDto);

    // 관리자 > SMS교육 > 교육관리 신규 등록
    void insertAvnEducationMgmt(TbAvnEducationDto tbAvnEducationDto);

    // 관리자 > SMS교육 > 교육관리 상세
    TbAvnEducationDto selectAvnEducationMgmtDetail(int educationId);

    // 관리자 > SMS교육 > 교육관리 수정
    void updateAvnEducationMgmt(TbAvnEducationDto tbAvnEducationDto);

    // 관리자 > SMS교육 > 교육관리 삭제
    void deleteAvnEducationMgmt(int educationId);
}
