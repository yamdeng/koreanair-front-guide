package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.TbSysUserDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "접수 - lsc정보")
public class ReceiptLscVo extends SmLsc {

    private int userId;
    private String nameKo;
    private String nameEn;
    private String deptNameKo;
    private String deptNameEn;
    private String rankNameKo;
    private String rankNameEn;

    public void setDefaultValue(TbSysUserDto userInfo) {
        this.setMemberType("leader");
        this.setUserId(Integer.parseInt(userInfo.getUserId()));
        this.setEmpNo(userInfo.getEmpNo());
        this.setNameKo(userInfo.getNameKor());
        this.setNameEn(userInfo.getNameEng());
        this.setDeptNameKo(userInfo.getDeptNmKor());
        this.setDeptNameEn(userInfo.getDeptNmEng());
        this.setRankNameKo(userInfo.getRankNmKor());
        this.setRankNameEn(userInfo.getRankNmEng());
    }
}
