package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RiskAssessmentVo extends SmReport {
    private String linkUrl;
    private List<SmReportHazardVo> reportHazardList;
    private List<SmReportHazardVo> reportHazardOcuList;
    private List<SmReportHazardVo> deleteList;
    private boolean isLeader;
    private boolean isMember;

    private boolean visibleNote = true;

    private List<PoFileVo> attachment;
    private String earNo;
    private String isHf;

    //@Schema(description = "LSC종결여부")
    //private String isLscClose;

    //@Schema(description = "산업안전종결여부")
    //private String isOcuClose;


}