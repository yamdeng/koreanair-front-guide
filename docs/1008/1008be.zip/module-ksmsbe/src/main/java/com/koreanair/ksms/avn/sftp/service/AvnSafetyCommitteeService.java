package com.koreanair.ksms.avn.sftp.service;

import com.koreanair.ksms.common.dto.TbAvnSafeConferenceDto;
import com.github.pagehelper.PageInfo;
import java.util.List;

public interface AvnSafetyCommitteeService {
    //안전정책 > 안전회의체 목록 조회
    PageInfo<TbAvnSafeConferenceDto> selectCommitteeList(TbAvnSafeConferenceDto tbAvnSafeConferenceDto);

    //안전정책 > 안전회의체 회의구분별 count 조회
    List<TbAvnSafeConferenceDto> selectCommitteeGroupCount(TbAvnSafeConferenceDto tbAvnSafeConferenceDto);

    //안전정책 > 안전회의체 신규 등록
    void insertCommittee(TbAvnSafeConferenceDto tbAvnSafeConferenceDto);

    //안전정책 > 안전회의체 상세 조회
    TbAvnSafeConferenceDto selectCommitteeInfo(int safeConferenceId);

    //안전정책 > 안전회의체 수정
    void updateCommittee(TbAvnSafeConferenceDto tbAvnSafeConferenceDto);

    //안전정책 > 안전회의체 삭제
    void deleteCommittee(String safeConferenceId);


}
