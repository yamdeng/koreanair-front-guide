package com.koreanair.ksms.avn.audit.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.audit.dto.*;

import java.util.List;
import java.util.Map;

public interface AvnMyAuditService {

    /* MyAudit 목록 */
    // My Audit 현황 조회
    TBMyAuditStatisticsDto selectMyAuditStatistics(Map paramMap);

    // My Audit 목록 조회
    PageInfo<TBMyAuditListDto> selectMyAuditList(Map paramMap);

    /* MyAudit Plan */
    // Audit 정보 조회
    TBAuditDto selectAuditInfo(int auditId);

    // 부문별 Checklist 정보 조회
    List<TBAuditChecklistDto> selectChecklistByDivision(String division);

    // Airport의 area 정보 조회
    List<Map<String, Object>> selectAreaByAirport(String airportCode);

    // Audit Plan 저장
    Integer insertAuditPlanInfo(TBAuditDto tBAuditDto);

    /* MyAudit Conduct */
    // Audit Checklsit 정보 조회
    List<TBAuditChecklistDto> selectConductChecklistInfo(int auditId);
    
    // Audit Conduct 저장
    Integer insertAuditConductInfo(TBAuditDto tBAuditDto);

    /* MyAudit CAR */
    // Audit Finding 정보 조회
    List<TBAuditFindingDto> selectCarFindingInfo(int auditId);
}
