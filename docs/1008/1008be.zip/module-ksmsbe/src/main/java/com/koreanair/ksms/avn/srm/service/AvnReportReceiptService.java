package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.ReceiptVo;
import com.koreanair.ksms.avn.srm.dto.ReportInfoDto;
import com.koreanair.ksms.avn.srm.dto.SmReceptionMember;
import com.koreanair.ksms.avn.srm.dto.SmReport;

import java.util.List;

public interface AvnReportReceiptService {

    SmReport selectReportDetail(int groupId);

    SmReport selectReportDraftDetail(int reportId);

    ReceiptVo selectReportReceipt(ReportInfoDto.GET_Request dtc);

    //접수 Insert
    void insertReceiptDetail(ReceiptVo parameter) throws Exception;

    //접수 Update
    void updateReceiptDetail(ReceiptVo parameter) throws Exception;

    void updateReceiptAt(int receiptId) throws Exception;

    List<SmReceptionMember> selectReceiptMember(String roleCd) throws Exception;


    //void editReceiptDetail (@Valid ReceiptDto.PATCH_Request parameter, @RequestAttribute("sessionInfo") JsonObject sessionInfo) throws Exception;
}
