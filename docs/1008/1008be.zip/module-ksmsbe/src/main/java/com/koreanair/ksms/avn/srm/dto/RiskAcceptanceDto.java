package com.koreanair.ksms.avn.srm.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;

public class RiskAcceptanceDto {
	
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class	POST_Request {
		@NotNull
		private int id; // hazardId
		@NotNull
		private int groupId;
		private String approvalType;
		private String reason;
		
		private int assuranceMonth;
	}

}
