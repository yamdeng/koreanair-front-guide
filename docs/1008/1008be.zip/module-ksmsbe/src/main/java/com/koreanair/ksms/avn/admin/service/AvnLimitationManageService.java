package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.FoqaLimitationDto;
import com.koreanair.ksms.common.dto.TbAvnReportFoqaLimitation;

public interface AvnLimitationManageService {
    PageInfo<TbAvnReportFoqaLimitation> selectLimitationManageList(FoqaLimitationDto param);

    TbAvnReportFoqaLimitation selectLimitationManageInfo(FoqaLimitationDto param);

    void insertLimitationManage(TbAvnReportFoqaLimitation tbAvnReportFoqaLimitation);

    void updateLimitationManageInfo(TbAvnReportFoqaLimitation tbAvnReportFoqaLimitation);

    void deleteLimitationManageInfo(int id);
}
