package com.koreanair.ksms.avn.srm.dto;


import com.koreanair.ksms.common.dto.CommonDto;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

public class SSCReveiwDto {
	
	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class	POST_Request {
		@NotNull
		private int id; // hazardId
		@NotNull
		private int groupId;
		private String approvalType;
		private String reason;

		private String riskLevel1;
		private String riskLevel1Color;

		private String riskLevel2;
		private String riskLevel2Color;

		private String assessmentNotes;
	}

	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	public static class	POST_SeveralRequest extends CommonDto {
		@NotNull
		List<SSCReveiwDto.POST_Request> list;

		private String reason;

		@NotNull
		private String approvalType;
	}
}
