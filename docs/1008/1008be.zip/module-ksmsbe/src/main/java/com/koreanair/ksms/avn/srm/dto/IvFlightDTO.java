package com.koreanair.ksms.avn.srm.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class IvFlightDTO {
    private String departureAt;
    private String flightNo;
    private String registrationNo;
    private String aircraftTypeText;
    private String fromAirport;
    private String toAirport;
    private String divertAirport;
    private String supply;
    private String checkIn;
}
