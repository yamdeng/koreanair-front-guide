package com.koreanair.ksms.common.dto;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@RequiredArgsConstructor
public class FlightDto {

	private final String inqDT;

	private final String firstDepGmtDt;

	private final String firstDepLocDt;

	private final String carrCd;

	private final String fltNo;

	private final String legNo;

	private final String stnFr;

	private final String stnTo;

	private final String schDepDT;

	private final String schArrDT;

	private final String estDepDT;

	private final String estArrDT;

	private final String actDepDT;

	private final String actArvDT;

	private final String schDepLocDT;

	private final String schArrLocDT;

	private final String estDepLocDT;

	private final String estArrLocDT;

	private final String actDepLocDT;

	private final String actArrLocDT;

	private final String depStatus;

	private final String arrStatus;

	private final String takeoffT;

	private final String landT;

	private final String acTypKe;

	private final String acTyp;

	private final String acGrp;

	private final String acVer;

	private final String fltSvcTyp;

	private final String acRegNo;

	private final String onwardFltNo;

	private final String divRzn;

	private final String divStn;

	private final String delayRzn1;

	private final String delayMin1;

	private final String delayRzn2;

	private final String delayMin2;

	private final String delayRzn3;

	private final String delayMin3;

	private final String delayRzn4;

	private final String delayMin4;

	private final String delayRzn5;

	private final String delayMin5;

	private final String depApoGmtOffset;

	private final String arrApoGmtOffset;

	private final String frSalableSeat;

	private final String prSalableSeat;

	private final String eySalableSeat;

	private final String schSeason;

	private final String schActionId;

	private final String updBy;

	private final String updDT;

	private final String updDcs;

	private final String schChngRzn;

	private final String depGate;

	private final String arrGate;

	private final String depSpot;

	private final String arrSpot;

	private final String fltRgnNo;

	private final String legRgnNo;

	private final String chkIn;

	private final String supply;
	
	public FlightResponseDto toFlightResponseDto() {
//		DateTimeFormatter = formatter = DateTimeFormatter.ofPattern("YYYYMMDD")
		LocalDateTime localDate = null;
		if (firstDepLocDt != null) {
			localDate = stringToLocalDate(firstDepLocDt);
		} else {
			localDate = null;
		}
		
		
		return FlightResponseDto.builder()
				.flightNo(fltNo)
				.aircraftType(acTyp)
				.ata(actArvDT)
				.atd(actDepDT)
				.checkIn(chkIn)
				.fleetCode(acGrp)
				.from(stnFr)
				.registrationNo(acRegNo)
				.sta(schArrDT)
				.std(schDepDT)
				.supply(supply)
				.to(stnTo)
				.delay(delayMin1)
				.staLocTime(schArrLocDT)
				.stdLocTime(schDepLocDT)
				.ataLocTime(actArrLocDT)
				.atdLocTime(actDepLocDT)
				.departureLocAt(localDate != null ? Timestamp.valueOf(localDate) : null)
				.build();
	}
	
	private LocalDateTime stringToLocalDate(String time) {
		
		String pattern = "yyyyMMdd";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		LocalDate localDate = LocalDate.from(formatter.parse(time));
		LocalDateTime result = LocalDateTime.of(localDate, LocalTime.of(0, 0, 0));
		return result;
	}
}
