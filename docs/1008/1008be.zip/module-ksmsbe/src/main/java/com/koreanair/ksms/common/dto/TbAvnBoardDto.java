package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "게시판")
public class TbAvnBoardDto extends CommonDto {
    @Schema(description = "순번")
    private int num;
    
    @Schema(description = "게시판 ID")
    @NotNull
    private int boardId;
    
    @Schema(description = "게시판유형코드")
    @NotBlank
    private String boardTypeCd;
    private String boardTypeNm;
    
    @Schema(description = "공지유형코드")
    private String notiTypeCd;
    private String notiTypeNm;
    
    @Schema(description = "팝업시작일자")
    private String popupFromDt;
    
    @Schema(description = "팝업끝일자")
    private String popupToDt;
    
    @Schema(description = "팝업여부")
    @NotBlank
    private String popupYn;
    
    @Schema(description = "분석일자")
    private String analysisDt;
    
    @Schema(description = "표시여부")
    @NotBlank
    private String viewYn;
    
    @Schema(description = "상단고정여부")
    @NotBlank
    private String topFixYn;
    
    @Schema(description = "메인표출여부")
    @NotBlank
    private String mainShowYn;
    
    @Schema(description = "업무유형코드")
    private String jobTypeCd;
    private String jobTypeNm;
    
    @Schema(description = "정책유형코드")
    private String policyTypeCd;
    private String policyTypeNm;
    
    @Schema(description = "제목국문명")
    private String subjectKoNm;
    
    @Schema(description = "제목영문명")
    private String subjectEnNm;
    
    @Schema(description = "링크국문명")
    private String linkKoNm;
    
    @Schema(description = "링크영문명")
    private String linkEnNm;
    
    @Schema(description = "배너유형코드")
    private String bannerTypeCd;
    private String bannerTypeNm;
    
    @Schema(description = "게시판텍스트내용")
    private String boardTxtcn;
    
    @Schema(description = "SAFETYURL명")
    private String safetyurlNm;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "링크그룹SEQ")
    private Integer linkGroupSeq;
    
    @Schema(description = "파일그룹SEQ")
    private Integer fileGroupSeq;
    
    @Schema(description = "조회수")
    @NotNull
    private int viewCo;
    
    @Schema(description = "표시순번")
    private int viewSn;

    @Schema(description = "작성일")
    private String writeDt;

    @Schema(description = "언어구분")
    private String languageType;
}
