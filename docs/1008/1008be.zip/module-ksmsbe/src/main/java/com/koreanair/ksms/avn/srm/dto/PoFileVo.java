package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
public class PoFileVo {

    private long seq;
    private int type;
    private String ext;
    private String name;
    private String path;
    private String title;
    private String desctn;
    private String imageS;
    private String imageM;
    private String imageB;
    private String oid;
    private String empNo;
    private String edEmpNo;
    private String svKey;
    private Timestamp regDt;
    private Timestamp modDt;
    private String fileKey;
    private long fileSize;
    private int workSeq;
    private int taskSeq;
    private int userId;
    private String delYn;
    private String location;
    private String timezone;

}
