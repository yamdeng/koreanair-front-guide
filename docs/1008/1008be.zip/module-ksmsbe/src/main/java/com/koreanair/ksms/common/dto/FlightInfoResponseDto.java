package com.koreanair.ksms.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
public class FlightInfoResponseDto {

	private String code;
	
	private String message;
	
	@JsonProperty("records")
	private List<FlightDto> flights;
	
}
