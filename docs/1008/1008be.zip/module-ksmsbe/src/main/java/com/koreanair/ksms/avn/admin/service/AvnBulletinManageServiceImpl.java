package com.koreanair.ksms.avn.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.dto.TbAvnManualDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnBulletinManageServiceImpl extends AbstractBaseService implements AvnBulletinManageService {

    // 게시판 관리 > 게시글 목록 조회
    @Override
    public PageInfo<TbAvnBoardDto> selectBoardList(BoardSearchDto boardSearchDto) {
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnBulletinManage.selectBoardList", boardSearchDto);
        return PageInfo.of(resultList);
    }

    // 게시판 관리 > 게시글 상세 조회
    @Override
    public TbAvnBoardDto selectBoardDetail(int boardId) {
        TbAvnBoardDto tbAvnBoardDto = new TbAvnBoardDto();
        tbAvnBoardDto.setBoardId(boardId);

        commonSql.update("AvnBulletinManage.updateViewCount", boardId);
        commonSql.insert("AvnBulletinManage.insertBoardDetail", tbAvnBoardDto);

        BoardSearchDto boardSearchDto = BoardSearchDto.builder().boardId(boardId).build();
        return commonSql.selectOne("AvnBulletinManage.selectBoardList", boardSearchDto);
    }

    // 게시판 관리 > 게시글 신규 등록
    @Override
    public  void insertBoard(TbAvnBoardDto tbAvnBoardDto) {

        //날짜 포맷 변경 - FROM
        String FromDtFormatChange = tbAvnBoardDto.getPopupFromDt();
        FromDtFormatChange = FromDtFormatChange.replace("-", "");
        FromDtFormatChange = FromDtFormatChange.substring(0,8);

        tbAvnBoardDto.setPopupFromDt(FromDtFormatChange);

        //날짜 포맷 변경 - TO
        String ToDtFormatChange = tbAvnBoardDto.getPopupToDt();
        ToDtFormatChange = ToDtFormatChange.replace("-", "");
        ToDtFormatChange = ToDtFormatChange.substring(0,8);

        tbAvnBoardDto.setPopupToDt(ToDtFormatChange);

        commonSql.insert("AvnBulletinManage.insertBoard", tbAvnBoardDto);
    }

    // 게시판 관리 > 게시글 수정
    @Override
    public void updateBoard(TbAvnBoardDto tbAvnBoardDto) {
        commonSql.update("AvnBulletinManage.updateBoard", tbAvnBoardDto);
    }

    // 게시판 관리 > 게시글 삭제
    @Override
    public void deleteBoard(int boardId) {
        commonSql.delete("AvnBulletinManage.deleteBoard", boardId);
    }

    @Override
    public List<GenericDto> selectList() {
        return List.of();
    }

    //관리자 > 게시판 관리 > 안전정책 목록 조회
    @Override
    public PageInfo<TbAvnBoardDto> selectSafetyPolicisList(TbAvnBoardDto tbAvnBoardDto){
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnBulletinManage.selectSafetyPolicisList", tbAvnBoardDto);
        return PageInfo.of(resultList);
    }

    //관리자 > 게시판 관리 > 안전정책 신규 등록
    @Override
    public void insertSafetyPolicy(TbAvnBoardDto tbAvnBoardDto){
        commonSql.insert("AvnBulletinManage.insertSafetyPolicy", tbAvnBoardDto);
    }

    //관리자 > 게시판 관리 > 안전정책 상세
    @Override
    public TbAvnBoardDto selectSafetyPolicy(int boardId){
        return commonSql.selectOne("AvnBulletinManage.selectSafetyPolicy", boardId);
    }

    //관리자 > 게시판 관리 > 안전정책 수정
    @Override
    public void updateSafetyPolicy(TbAvnBoardDto tbAvnBoardDto){
        commonSql.update("AvnBulletinManage.updateSafetyPolicy", tbAvnBoardDto);
    }

    //관리자 > 게시판 관리 > 안전정책 삭제
    @Override
    public void deleteSafetyPolicy(int boardId){
        commonSql.delete("AvnBulletinManage.deleteSafetyPolicy", boardId);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 목록 조회
    @Override
    public PageInfo<TbAvnManualDto> selectManualList(TbAvnManualDto tbAvnManualDto){
        List<TbAvnManualDto> resultList = commonSql.selectList("AvnBulletinManage.selectManualList", tbAvnManualDto);
        return PageInfo.of(resultList);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 신규 등록
    @Override
    public void insertManual(TbAvnManualDto tbAvnManualDto){

        //날짜 포맷 변경
        String DateFormatChange = tbAvnManualDto.getRevisionDt();
        DateFormatChange = DateFormatChange.replace("-","");
        DateFormatChange = DateFormatChange.substring(2,8);
        tbAvnManualDto.setRevisionDt(DateFormatChange);

        commonSql.insert("AvnBulletinManage.insertManual", tbAvnManualDto);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 상세
    @Override
    public TbAvnManualDto selectManualInfo(int manualId){
        return commonSql.selectOne("AvnBulletinManage.selectManualInfo", manualId);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 수정
    @Override
    public void updateManual(TbAvnManualDto tbAvnManualDto){

        //날짜 포맷 변경
        String DateFormatChange = tbAvnManualDto.getRevisionDt();
        DateFormatChange = DateFormatChange.replace("-","");
        DateFormatChange = DateFormatChange.substring(2,8);
        tbAvnManualDto.setRevisionDt(DateFormatChange);

        commonSql.update("AvnBulletinManage.updateManual", tbAvnManualDto);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 삭제
    @Override
    public void deleteManual(int manualId){
        commonSql.delete("AvnBulletinManage.deleteManual", manualId);
    }


}
