package com.koreanair.ksms.common.dto;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class LscGroupDto extends CommonDto
{
    private int id;
    private int userId;
    private String groupName;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    public LscGroupDto(int userId, String groupName) {
        super();
        this.userId = userId;
        this.groupName = groupName;
    }

    public LscGroupDto(int id) {
        super();
        this.id = id;
    }

    public Map<String,Object>getAddMap() {
        HashMap<String,Object> res = new HashMap<String,Object>();
        res.put("userId", userId);
        res.put("groupName", groupName);
        res.put("regUserId", this.getRegUserId());
        res.put("updUserId", this.getUpdUserId());
        return res;
    }

    public Map<String,Object>getDelMap() {
        HashMap<String,Object> res = new HashMap<String,Object>();
        res.put("id", id);
        res.put("regUserId", this.getRegUserId());
        res.put("updUserId", this.getUpdUserId());
        return res;
    }
}
