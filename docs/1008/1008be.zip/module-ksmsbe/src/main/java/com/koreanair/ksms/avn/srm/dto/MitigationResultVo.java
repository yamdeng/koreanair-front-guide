package com.koreanair.ksms.avn.srm.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MitigationResultVo extends SmReportHazard{

	private MitigationVo mitigation;

	private List<PoFileVo> attachment;

	private List<ProgressRateVo> progressRate;

	private List<MitigationVo> empInfo;
}