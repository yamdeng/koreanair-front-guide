package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "보고서 접수 이벤트 정보")
public class SmReceptionKeEvent {
    @NotNull
    private int receptionId;
    @NotNull
    private int eventId;
}
