package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@Schema(description = "결재정보 저장용 DTO")
public class TbApprovalSaveDto extends CommonDto {

    @Schema(description = "결재ID")
    private int approvalId;

    @Schema(description = "업무구분(항공 A/안전 O)")
    private String workType;

    @Schema(description = "결재구분 - 공통코드 APPROVAL_TYPE")
    private String approvalType;

    @Schema(description = "결재제목")
    private String approvalSubject;

    @Schema(description = "결재Key정보(URL)")
    private String approvalKey;

    @Schema(description = "결재요청 사원번호")
    private String empNo;

    @Schema(description = "결재요청 메시지")
    private String approvalMsg;

    @Schema(description = "업무(리포트) Key")
    private String reportKey;

    @Schema(description = "결재자 목록")
    private List<TbApprovalDtlDto> empList;
}
