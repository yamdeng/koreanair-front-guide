package com.koreanair.ksms.avn.sftr.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sftr.dto.ReportSearchDto;
import com.koreanair.ksms.avn.sftr.dto.TreeCodeDto;
import com.koreanair.ksms.common.dto.TbAvnAircrafts;
import com.koreanair.ksms.common.dto.TbAvnReportAsrDto;
import com.koreanair.ksms.common.dto.TbAvnReportCsrDtlInfoDto;
import com.koreanair.ksms.common.dto.TbAvnReportCsrDto;
import com.koreanair.ksms.common.dto.TbAvnReportDsrDto;
import com.koreanair.ksms.common.dto.TbAvnReportDto;
import com.koreanair.ksms.common.dto.TbAvnReportFlightCrewDto;
import com.koreanair.ksms.common.dto.TbAvnReportFlightDto;
import com.koreanair.ksms.common.dto.TbAvnReportFoqaDto;
import com.koreanair.ksms.common.dto.TbAvnReportGsrDtlInfoDto;
import com.koreanair.ksms.common.dto.TbAvnReportGsrDto;
import com.koreanair.ksms.common.dto.TbAvnReportHzrDto;
import com.koreanair.ksms.common.dto.TbAvnReportMsrDtlInfoDto;
import com.koreanair.ksms.common.dto.TbAvnReportMsrDto;
import com.koreanair.ksms.common.dto.TbAvnReportRsrDto;
import com.koreanair.ksms.common.dto.TbAvnReportSmrDto;
import com.koreanair.ksms.common.dto.TbSysCodeDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;

@Service
public class AvnSafetyReportServiceImpl extends AbstractBaseService implements AvnSafetyReportService {

    @Autowired
    AvnCommonService avnCommonService;

    @Override
    public PageInfo<TbAvnReportDto> selectMyReportList(ReportSearchDto param) {

        List<TbAvnReportDto> resultList = commonSql.selectList("AvnSafetyReport.selectMyReportList", param);
        return PageInfo.of(resultList);
    }

    @Override
    public Map<String, Object> selectMyReportCountInfo(ReportSearchDto param) {
        return commonSql.selectOne("AvnSafetyReport.selectMyReportCountInfo", param);
    }

    @Override
    public Map<String, Object> selectMyReportDetail(int reportId) {
        
        ReportSearchDto reportSearchDto = ReportSearchDto.builder().reportId(reportId).build();
        Map<String, Object> rtnMap = new HashMap<>();

        TbAvnReportDto report = commonSql.selectOne("AvnSafetyReport.selectMyReportDetail", reportSearchDto);
        rtnMap.put("report", report);

        String rptTypeCd = report.getReportTypeCd();
        if ("asr".equals(rptTypeCd)){
            TbAvnReportAsrDto reportAsr = commonSql.selectOne("AvnSafetyReport.selectReportAsr", reportSearchDto);
            
            reportAsr.setWeatherCdList(commonCodeList("CODE_GRP_008", reportAsr.getWeatherCdarr()));

            rtnMap.put("reportAsr", reportAsr);

        }else if("csr".equals(rptTypeCd)){
            TbAvnReportCsrDto reportCsr = commonSql.selectOne("AvnSafetyReport.selectReportCsr", reportSearchDto);
            List<TbAvnReportCsrDtlInfoDto> reportDtl = commonSql.selectList("AvnSafetyReport.selectReportCsrDtlInfo", reportSearchDto);

            reportCsr.setUseMedicalEquipCdList(commonCodeList("CODE_GRP_016", reportCsr.getUseMedicalEquipCdarr()));
            reportCsr.setCarCdList(commonCodeList("CODE_GRP_164", reportCsr.getCarCdarr()));
            reportCsr.setAddCarCdList(commonCodeList("CODE_GRP_164", reportCsr.getAddCarCdarr()));
            reportCsr.setUseEmergencyEquipCdList(commonCodeList("CODE_GRP_038", reportCsr.getUseEmergencyEquipCdarr()));

            rtnMap.put("reportCsr", reportCsr);
            rtnMap.put("reportDtl", reportDtl);

        }else if("msr".equals(rptTypeCd)){
            TbAvnReportMsrDto reportMsr = commonSql.selectOne("AvnSafetyReport.selectReportMsr", reportSearchDto);
            List<TbAvnReportMsrDtlInfoDto> reportDtl = commonSql.selectList("AvnSafetyReport.selectReportMsrDtlInfo", reportSearchDto);
            
            rtnMap.put("reportMsr", reportMsr);
            rtnMap.put("reportDtl", reportDtl);

        }else if("gsr".equals(rptTypeCd)){
            TbAvnReportGsrDto reportGsr = commonSql.selectOne("AvnSafetyReport.selectReportGsr", reportSearchDto);
            List<TbAvnReportGsrDtlInfoDto> reportDtl = commonSql.selectList("AvnSafetyReport.selectReportGsrDtlInfo", reportSearchDto);


            reportGsr.setWeatherCdList(commonCodeList("CODE_GRP_043", reportGsr.getWeatherCdarr()));

            rtnMap.put("reportGsr", reportGsr);
            rtnMap.put("reportDtl", reportDtl);

        }else if("hzr".equals(rptTypeCd)){
            TbAvnReportHzrDto reportHzr = commonSql.selectOne("AvnSafetyReport.selectReportHzr", reportSearchDto);
            rtnMap.put("reportHzr", reportHzr);

        }else if("dsr".equals(rptTypeCd)){
            TbAvnReportDsrDto reportDsr = commonSql.selectOne("AvnSafetyReport.selectReportDsr", reportSearchDto);
            rtnMap.put("reportDsr", reportDsr);

        }else if("rsr".equals(rptTypeCd)){
            TbAvnReportRsrDto reportRsr = commonSql.selectOne("AvnSafetyReport.selectReportRsr", reportSearchDto);
            rtnMap.put("reportRsr", reportRsr);

        }else if("foqa".equals(rptTypeCd)){
            TbAvnReportFoqaDto reportFoqa = commonSql.selectOne("AvnSafetyReport.selectReportFoqa", reportSearchDto);
            rtnMap.put("reportFoqa", reportFoqa);

            if ("Y".equals(reportFoqa.getOldDataRiskLevYn())) {
                //todo khw 작업 필요
            }
        }
        
        
        TbAvnReportFlightDto flight = commonSql.selectOne("AvnSafetyReport.selectReportFlight", reportSearchDto);
        List<TbAvnReportFlightCrewDto> flightCrewList = commonSql.selectList("AvnSafetyReport.selectReportFlightCrew", reportSearchDto);
        rtnMap.put("flight", flight);
        rtnMap.put("flightCrew", flightCrewList);
        
        return rtnMap;
    }

    @Override
    @Transactional(rollbackFor={Exception.class})
    public Integer insertReport(ObjectNode saveObj) throws CustomBusinessException{
        
        ObjectMapper mapper = new ObjectMapper();   // JSON을 Object화 하기 위한 Jackson ObjectMapper 이용
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        Integer reportId = null;
        
        try {
            TbAvnReportDto tbAvnReportDto = mapper.treeToValue(saveObj.get("report"), TbAvnReportDto.class);
            
            reportId = commonSql.selectOne("AvnSafetyReport.selectMaxReportId");
            
            /* 레포트 마스터 등록 */
            tbAvnReportDto.setReportId(reportId);
            tbAvnReportDto.setReportPhaseCd("reporting");
            tbAvnReportDto.setReportStatusCd("Draft");

            //foqa 인 경우 별도로 doc no 생성함
            if("foqa".equals(tbAvnReportDto.getReportTypeCd())){
                //E777-210001 :  (777기종 Event로 2021년도에 001번째 등록 Event)
                //R330-210002 :  (330기종 Risk Level로 2021년도에 002번째로 등록된 Risk Level)
                TbAvnReportFoqaDto foqaInfo = mapper.treeToValue(saveObj.get("reportFoqa"), TbAvnReportFoqaDto.class);
                String category = foqaInfo.getCategory(); // E or R
                String deIdYear = foqaInfo.getDeIdDate().substring(2, 4);  // 년도 24, 25 ...

                TbAvnReportFlightDto flightInfo = mapper.treeToValue(saveObj.get("flight"), TbAvnReportFlightDto.class);
                String aircraftType = flightInfo.getAircraftTypeCd();

                //74N -->> 747로 가져오기 위함..
                PageHelper.startPage(1, 10);
                PageInfo<TbAvnAircrafts> resultList = avnCommonService.selectAircraftList(aircraftType);
                aircraftType = resultList.getList().get(0).getFleetCode().toString();

                String tempDocNo = category.concat(aircraftType).concat("-").concat(deIdYear);
                tbAvnReportDto.setReportDocno(tempDocNo);
            }
            commonSql.insert("AvnSafetyReport.insertReport", tbAvnReportDto);
            
            /* 개별 레포트 등록 */
            String rptTypeCd = tbAvnReportDto.getReportTypeCd();
            if ("asr".equals(rptTypeCd)){
                TbAvnReportAsrDto tbAvnReportAsrDto = mapper.treeToValue(saveObj.get("reportAsr"), TbAvnReportAsrDto.class);
                tbAvnReportAsrDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportAsr", tbAvnReportAsrDto);

            }else if("csr".equals(rptTypeCd)){
                TbAvnReportCsrDto tbAvnReportCsrDto = mapper.treeToValue(saveObj.get("reportCsr"), TbAvnReportCsrDto.class);
                List<Map<String, Object>> reportDtlList = mapper.treeToValue(saveObj.get("reportDtl"), ArrayList.class);
                tbAvnReportCsrDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportCsr", tbAvnReportCsrDto);

                for (Map<String, Object> data : reportDtlList) {
                    TbAvnReportCsrDtlInfoDto tbAvnReportCsrDtlInfoDto = 
                        TbAvnReportCsrDtlInfoDto
                            .builder()
                            .reportId( reportId)
                            .reportDtlInfoTypeCd( data.get("reportDtlInfoTypeCd") != null ? data.get("reportDtlInfoTypeCd").toString() : "")
                            .empNo( data.get("empNo") != null ? data.get("empNo").toString() : "")
                            .involveCd( data.get("involveCd") != null ? data.get("involveCd").toString() : "")
                            .paxNm( data.get("paxNm") != null ? data.get("paxNm").toString() : "")
                            .genderCd( data.get("genderCd") != null ? data.get("genderCd").toString() : "")
                            .ageCo( data.get("ageCo") != null ? Integer.parseInt(data.get("ageCo").toString()) : 0)
                            .nationNm( data.get("nationNm") != null ? data.get("nationNm").toString() : "")
                            .seatNm( data.get("seatNm") != null ? data.get("seatNm").toString() : "")
                            .hiddenFindSeatCd( data.get("hiddenFindSeatCd") != null ? data.get("hiddenFindSeatCd").toString() : "")
                            .hiddenFindPlaceCd( data.get("hiddenFindPlaceCd") != null ? data.get("hiddenFindPlaceCd").toString() : "")
                            .build();

                    commonSql.insert("AvnSafetyReport.insertReportCsrDtlInfo", tbAvnReportCsrDtlInfoDto);
                };
            }else if("msr".equals(rptTypeCd)){
                TbAvnReportMsrDto tbAvnReportMsrDto = mapper.treeToValue(saveObj.get("reportMsr"), TbAvnReportMsrDto.class);
                List<Map<String, Object>> reportDtlList = mapper.treeToValue(saveObj.get("reportDtl"), ArrayList.class);
                tbAvnReportMsrDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportMsr", tbAvnReportMsrDto);

                for (Map<String, Object> data : reportDtlList) {
                    TbAvnReportMsrDtlInfoDto tbAvnReportMsrDtlInfoDto = 
                        TbAvnReportMsrDtlInfoDto
                            .builder()
                            .reportId( reportId)
                            .reportDtlInfoTypeCd( data.get("reportDtlInfoTypeCd") != null ? data.get("reportDtlInfoTypeCd").toString() : "")
                            .nomenclatureNm( data.get("nomenclatureNm") != null ? data.get("nomenclatureNm").toString() : "")
                            .partNm( data.get("partNm") != null ? data.get("partNm").toString() : "")
                            .serialnoNm( data.get("serialnoNm") != null ? data.get("serialnoNm").toString() : "")
                            .build();

                    commonSql.insert("AvnSafetyReport.insertReportMsrDtlInfo", tbAvnReportMsrDtlInfoDto);
                };
            }else if("gsr".equals(rptTypeCd)){
                TbAvnReportGsrDto tbAvnReportGsrDto = mapper.treeToValue(saveObj.get("reportGsr"), TbAvnReportGsrDto.class);
                List<Map<String, Object>> reportDtlList = mapper.treeToValue(saveObj.get("reportDtl"), ArrayList.class);
                tbAvnReportGsrDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportGsr", tbAvnReportGsrDto);

                for (Map<String, Object> data : reportDtlList) {
                    TbAvnReportGsrDtlInfoDto tbAvnReportGsrDtlInfoDto = 
                        TbAvnReportGsrDtlInfoDto
                            .builder()
                            .reportId( reportId)
                            .reportDtlInfoTypeCd( data.get("reportDtlInfoTypeCd") != null ? data.get("reportDtlInfoTypeCd").toString() : "")
                            .aircraftDamageAreaCd( data.get("aircraftDamageAreaCd") != null ? data.get("aircraftDamageAreaCd").toString() : "")
                            .aircraftDamageCn( data.get("aircraftDamageCn") != null ? data.get("aircraftDamageCn").toString() : "")
                            .relEquipCd( data.get("relEquipCd") != null ? data.get("relEquipCd").toString() : "")
                            .regNoNm( data.get("regNoNm") != null ? data.get("regNoNm").toString() : "")
                            .mntcHistNm( data.get("mntcHistNm") != null ? data.get("mntcHistNm").toString() : "")
                            .relGspCd( data.get("relGspCd") != null ? data.get("relGspCd").toString() : "")
                            .chargeDeptCd( data.get("chargeDeptCd") != null ? data.get("chargeDeptCd").toString() : "")
                            .gsrCn( data.get("gsrCn") != null ? data.get("gsrCn").toString() : "")
                            .build();


                    commonSql.insert("AvnSafetyReport.insertReportGsrDtlInfo", tbAvnReportGsrDtlInfoDto);
                };
            }else if("hzr".equals(rptTypeCd)){
                TbAvnReportHzrDto tbAvnReportHzrDto = mapper.treeToValue(saveObj.get("reportHzr"), TbAvnReportHzrDto.class);
                tbAvnReportHzrDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportHzr", tbAvnReportHzrDto);

            }else if("dsr".equals(rptTypeCd)){
                TbAvnReportDsrDto tbAvnReportDsrDto = mapper.treeToValue(saveObj.get("reportDsr"), TbAvnReportDsrDto.class);
                tbAvnReportDsrDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportDsr", tbAvnReportDsrDto);

            }else if("rsr".equals(rptTypeCd)){
                TbAvnReportRsrDto tbAvnReportRsrDto = mapper.treeToValue(saveObj.get("reportRsr"), TbAvnReportRsrDto.class);
                tbAvnReportRsrDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportRsr", tbAvnReportRsrDto);

            }else if("foqa".equals(rptTypeCd)){
                TbAvnReportFoqaDto tbAvnReportFoqaDto = mapper.treeToValue(saveObj.get("reportFoqa"), TbAvnReportFoqaDto.class);
                tbAvnReportFoqaDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportFoqa", tbAvnReportFoqaDto);

            }else if("smr".equals(rptTypeCd)) {
                TbAvnReportSmrDto tbAvnReportSmrDto = mapper.treeToValue(saveObj.get("reportSmr"), TbAvnReportSmrDto.class);
                tbAvnReportSmrDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportSmr", tbAvnReportSmrDto);
            }

            if( saveObj.get("flight") != null ){
                TbAvnReportFlightDto tbAvnReportFlightDto = mapper.treeToValue(saveObj.get("flight"), TbAvnReportFlightDto.class);
                List<Map<String, Object>> flightCrewList = mapper.treeToValue(saveObj.get("flightCrew"), ArrayList.class);
                
                tbAvnReportFlightDto.setReportId(reportId);
                commonSql.insert("AvnSafetyReport.insertReportFlight", tbAvnReportFlightDto);
    
                if (flightCrewList != null) {
                    for (Map<String, Object> data : flightCrewList) {
                        TbAvnReportFlightCrewDto tbAvnReportFlightCrewDto = new TbAvnReportFlightCrewDto();

                        tbAvnReportFlightCrewDto.setReportId(reportId);
                        tbAvnReportFlightCrewDto.setEmpNo(data.get("empNo").toString() );
                        tbAvnReportFlightCrewDto.setCrewTypeCd(data.get("crewTypeCd").toString());

                        commonSql.insert("AvnSafetyReport.insertReportFlightCrew", tbAvnReportFlightCrewDto);
                    };
                }
            }
            
        } catch (JsonProcessingException | IllegalArgumentException e) {
            throw new CustomBusinessException(e.getMessage());
        }
        

        return reportId;
    }

    @Override
    @Transactional(rollbackFor={Exception.class})
    public void updateReport(int reportId, ObjectNode saveObj) throws CustomBusinessException{
        
        ObjectMapper mapper = new ObjectMapper();   // JSON을 Object화 하기 위한 Jackson ObjectMapper 이용
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
            TbAvnReportDto tbAvnReportDto = mapper.treeToValue(saveObj.get("report"), TbAvnReportDto.class);
            
            commonSql.update("AvnSafetyReport.updateReport", tbAvnReportDto);
            
            /* 개별 레포트 등록 */
            String rptTypeCd = tbAvnReportDto.getReportTypeCd();
            if ("asr".equals(rptTypeCd)){
                TbAvnReportAsrDto tbAvnReportAsrDto = mapper.treeToValue(saveObj.get("reportAsr"), TbAvnReportAsrDto.class);
                commonSql.update("AvnSafetyReport.updateReportAsr", tbAvnReportAsrDto);

            }else if("csr".equals(rptTypeCd)){
                TbAvnReportCsrDto tbAvnReportCsrDto = mapper.treeToValue(saveObj.get("reportCsr"), TbAvnReportCsrDto.class);
                List<Map<String, Object>> reportDtlList = mapper.treeToValue(saveObj.get("reportDtl"), ArrayList.class);
                commonSql.update("AvnSafetyReport.updateReportCsr", tbAvnReportCsrDto);
                commonSql.delete("AvnSafetyReport.deleteReportCsrDtlInfo", reportId);

                for (Map<String, Object> data : reportDtlList) {
                    TbAvnReportCsrDtlInfoDto tbAvnReportCsrDtlInfoDto = 
                        TbAvnReportCsrDtlInfoDto
                            .builder()
                            .reportId( reportId)
                            .reportDtlInfoTypeCd( data.get("reportDtlInfoTypeCd") != null ? data.get("reportDtlInfoTypeCd").toString() : "")
                            .empNo( data.get("empNo") != null ? data.get("empNo").toString() : "")
                            .involveCd( data.get("involveCd") != null ? data.get("involveCd").toString() : "")
                            .paxNm( data.get("paxNm") != null ? data.get("paxNm").toString() : "")
                            .genderCd( data.get("genderCd") != null ? data.get("genderCd").toString() : "")
                            .ageCo( data.get("ageCo") != null ? Integer.parseInt(data.get("ageCo").toString()) : 0)
                            .nationNm( data.get("nationNm") != null ? data.get("nationNm").toString() : "")
                            .seatNm( data.get("seatNm") != null ? data.get("seatNm").toString() : "")
                            .hiddenFindSeatCd( data.get("hiddenFindSeatCd") != null ? data.get("hiddenFindSeatCd").toString() : "")
                            .hiddenFindPlaceCd( data.get("hiddenFindPlaceCd") != null ? data.get("hiddenFindPlaceCd").toString() : "")
                            .build();

                    commonSql.insert("AvnSafetyReport.insertReportCsrDtlInfo", tbAvnReportCsrDtlInfoDto);
                };
            }else if("msr".equals(rptTypeCd)){
                TbAvnReportMsrDto tbAvnReportMsrDto = mapper.treeToValue(saveObj.get("reportMsr"), TbAvnReportMsrDto.class);
                List<Map<String, Object>> reportDtlList = mapper.treeToValue(saveObj.get("reportDtl"), ArrayList.class);
                commonSql.update("AvnSafetyReport.updateReportMsr", tbAvnReportMsrDto);
                commonSql.delete("AvnSafetyReport.deleteReportMsrDtlInfo", reportId);

                for (Map<String, Object> data : reportDtlList) {
                    TbAvnReportMsrDtlInfoDto tbAvnReportMsrDtlInfoDto = 
                        TbAvnReportMsrDtlInfoDto
                            .builder()
                            .reportId( reportId)
                            .reportDtlInfoTypeCd( data.get("reportDtlInfoTypeCd") != null ? data.get("reportDtlInfoTypeCd").toString() : "")
                            .nomenclatureNm( data.get("nomenclatureNm") != null ? data.get("nomenclatureNm").toString() : "")
                            .partNm( data.get("partNm") != null ? data.get("partNm").toString() : "")
                            .serialnoNm( data.get("serialnoNm") != null ? data.get("serialnoNm").toString() : "")
                            .build();

                    commonSql.insert("AvnSafetyReport.insertReportMsrDtlInfo", tbAvnReportMsrDtlInfoDto);
                };
            }else if("gsr".equals(rptTypeCd)){
                TbAvnReportGsrDto tbAvnReportGsrDto = mapper.treeToValue(saveObj.get("reportGsr"), TbAvnReportGsrDto.class);
                List<Map<String, Object>> reportDtlList = mapper.treeToValue(saveObj.get("reportDtl"), ArrayList.class);
                commonSql.update("AvnSafetyReport.updateReportGsr", tbAvnReportGsrDto);
                commonSql.delete("AvnSafetyReport.deleteReportGsrDtlInfo", reportId);

                for (Map<String, Object> data : reportDtlList) {
                    TbAvnReportGsrDtlInfoDto tbAvnReportGsrDtlInfoDto = 
                        TbAvnReportGsrDtlInfoDto
                            .builder()
                            .reportId( reportId)
                            .reportDtlInfoTypeCd( data.get("reportDtlInfoTypeCd") != null ? data.get("reportDtlInfoTypeCd").toString() : "")
                            .aircraftDamageAreaCd( data.get("aircraftDamageAreaCd") != null ? data.get("aircraftDamageAreaCd").toString() : "")
                            .aircraftDamageCn( data.get("aircraftDamageCn") != null ? data.get("aircraftDamageCn").toString() : "")
                            .relEquipCd( data.get("relEquipCd") != null ? data.get("relEquipCd").toString() : "")
                            .regNoNm( data.get("regNoNm") != null ? data.get("regNoNm").toString() : "")
                            .mntcHistNm( data.get("mntcHistNm") != null ? data.get("mntcHistNm").toString() : "")
                            .relGspCd( data.get("relGspCd") != null ? data.get("relGspCd").toString() : "")
                            .chargeDeptCd( data.get("chargeDeptCd") != null ? data.get("chargeDeptCd").toString() : "")
                            .gsrCn( data.get("gsrCn") != null ? data.get("gsrCn").toString() : "")
                            .build();


                    commonSql.insert("AvnSafetyReport.insertReportGsrDtlInfo", tbAvnReportGsrDtlInfoDto);
                };
            }else if("hzr".equals(rptTypeCd)){
                TbAvnReportHzrDto tbAvnReportHzrDto = mapper.treeToValue(saveObj.get("reportHzr"), TbAvnReportHzrDto.class);
                commonSql.update("AvnSafetyReport.updateReportHzr", tbAvnReportHzrDto);

            }else if("dsr".equals(rptTypeCd)){
                TbAvnReportDsrDto tbAvnReportDsrDto = mapper.treeToValue(saveObj.get("reportDsr"), TbAvnReportDsrDto.class);
                commonSql.update("AvnSafetyReport.updateReportDsr", tbAvnReportDsrDto);

            }else if("rsr".equals(rptTypeCd)){
                TbAvnReportRsrDto tbAvnReportRsrDto = mapper.treeToValue(saveObj.get("reportRsr"), TbAvnReportRsrDto.class);
                commonSql.update("AvnSafetyReport.updateReportRsr", tbAvnReportRsrDto);

            }else if("foqa".equals(rptTypeCd)){
                TbAvnReportFoqaDto tbAvnReportFoqaDto = mapper.treeToValue(saveObj.get("reportFoqa"), TbAvnReportFoqaDto.class);
                commonSql.update("AvnSafetyReport.updateReportFoqa", tbAvnReportFoqaDto);

            }else if("smr".equals(rptTypeCd)){
                TbAvnReportSmrDto tbAvnReportSmrDto = mapper.treeToValue(saveObj.get("reportSmr"), TbAvnReportSmrDto.class);
                commonSql.update("AvnSafetyReport.updateReportSmr", tbAvnReportSmrDto);

            }

            if( saveObj.get("flight") != null ){
                TbAvnReportFlightDto tbAvnReportFlightDto = mapper.treeToValue(saveObj.get("flight"), TbAvnReportFlightDto.class);
                List<Map<String, Object>> flightCrewList = mapper.treeToValue(saveObj.get("flightCrew"), ArrayList.class);
                
                commonSql.update("AvnSafetyReport.updateReportFlight", tbAvnReportFlightDto);
                commonSql.delete("AvnSafetyReport.deleteReportFlightCrew", reportId);
    
                if (flightCrewList != null) {
                    for (Map<String, Object> data : flightCrewList) {
                        TbAvnReportFlightCrewDto tbAvnReportFlightCrewDto = new TbAvnReportFlightCrewDto();
                        
                        tbAvnReportFlightCrewDto.setReportId(reportId);
                        tbAvnReportFlightCrewDto.setEmpNo(data.get("empNo").toString() );
                        tbAvnReportFlightCrewDto.setCrewTypeCd(data.get("crewTypeCd").toString());
        
                        commonSql.insert("AvnSafetyReport.insertReportFlightCrew", tbAvnReportFlightCrewDto);
                    };
                }
            }
            
        } catch (JsonProcessingException | IllegalArgumentException e) {
            throw new CustomBusinessException(e.getMessage());
        }

        return ;
    }

    @Override
    public void deleteReport(int param) {
        TbAvnReportDto tbAvnReportDto = new TbAvnReportDto();
        
        tbAvnReportDto.setReportId(param);
        tbAvnReportDto.setReportStatusCd("voided");

        commonSql.update("AvnSafetyReport.updateReportStatus", tbAvnReportDto);
        return;
    }

    @Override
    @Transactional(rollbackFor={Exception.class})
    public Integer submitReport(ObjectNode saveObj) throws CustomBusinessException{
        
        ObjectMapper mapper = new ObjectMapper();   // JSON을 Object화 하기 위한 Jackson ObjectMapper 이용
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        Integer reportId = null;
        String workGb = "";
        try {
            TbAvnReportDto tbAvnReportDto = mapper.treeToValue(saveObj.get("report"), TbAvnReportDto.class);

            /* 레포트 마스터 등록 */
            tbAvnReportDto.setReportPhaseCd("reception");
            tbAvnReportDto.setReportStatusCd("Open");
            
            if(tbAvnReportDto.getReportId() == null){
                reportId = commonSql.selectOne("AvnSafetyReport.selectMaxReportId");
                tbAvnReportDto.setReportId(reportId);
                workGb = "insert";
            }else{
                reportId = tbAvnReportDto.getReportId();
                workGb = "update";
            }
            commonSql.update("AvnSafetyReport." + workGb + "Report", tbAvnReportDto);
            
            /* 개별 레포트 등록 */
            String rptTypeCd = tbAvnReportDto.getReportTypeCd();
            if ("asr".equals(rptTypeCd)){
                TbAvnReportAsrDto tbAvnReportAsrDto = mapper.treeToValue(saveObj.get("reportAsr"), TbAvnReportAsrDto.class);
                tbAvnReportAsrDto.setReportId(reportId);
                commonSql.update("AvnSafetyReport." + workGb + "ReportAsr", tbAvnReportAsrDto);

            }else if("csr".equals(rptTypeCd)){
                TbAvnReportCsrDto tbAvnReportCsrDto = mapper.treeToValue(saveObj.get("reportCsr"), TbAvnReportCsrDto.class);
                List<Map<String, Object>> reportDtlList = mapper.treeToValue(saveObj.get("reportDtl"), ArrayList.class);
                tbAvnReportCsrDto.setReportId(reportId);
                commonSql.update("AvnSafetyReport." + workGb + "ReportCsr", tbAvnReportCsrDto);
                commonSql.delete("AvnSafetyReport.deleteReportCsrDtlInfo", reportId);

                for (Map<String, Object> data : reportDtlList) {
                    TbAvnReportCsrDtlInfoDto tbAvnReportCsrDtlInfoDto = 
                        TbAvnReportCsrDtlInfoDto
                            .builder()
                            .reportId( reportId)
                            .reportDtlInfoTypeCd( data.get("reportDtlInfoTypeCd") != null ? data.get("reportDtlInfoTypeCd").toString() : "")
                            .empNo( data.get("empNo") != null ? data.get("empNo").toString() : "")
                            .involveCd( data.get("involveCd") != null ? data.get("involveCd").toString() : "")
                            .paxNm( data.get("paxNm") != null ? data.get("paxNm").toString() : "")
                            .genderCd( data.get("genderCd") != null ? data.get("genderCd").toString() : "")
                            .ageCo( data.get("ageCo") != null ? Integer.parseInt(data.get("ageCo").toString()) : 0)
                            .nationNm( data.get("nationNm") != null ? data.get("nationNm").toString() : "")
                            .seatNm( data.get("seatNm") != null ? data.get("seatNm").toString() : "")
                            .hiddenFindSeatCd( data.get("hiddenFindSeatCd") != null ? data.get("hiddenFindSeatCd").toString() : "")
                            .hiddenFindPlaceCd( data.get("hiddenFindPlaceCd") != null ? data.get("hiddenFindPlaceCd").toString() : "")
                            .build();

                    commonSql.insert("AvnSafetyReport.insertReportCsrDtlInfo", tbAvnReportCsrDtlInfoDto);
                };
            }else if("msr".equals(rptTypeCd)){
                TbAvnReportMsrDto tbAvnReportMsrDto = mapper.treeToValue(saveObj.get("reportMsr"), TbAvnReportMsrDto.class);
                List<Map<String, Object>> reportDtlList = mapper.treeToValue(saveObj.get("reportDtl"), ArrayList.class);
                tbAvnReportMsrDto.setReportId(reportId);
                commonSql.update("AvnSafetyReport." + workGb + "ReportMsr", tbAvnReportMsrDto);
                commonSql.delete("AvnSafetyReport.deleteReportMsrDtlInfo", reportId);

                for (Map<String, Object> data : reportDtlList) {
                    TbAvnReportMsrDtlInfoDto tbAvnReportMsrDtlInfoDto = 
                        TbAvnReportMsrDtlInfoDto
                            .builder()
                            .reportId( reportId)
                            .reportDtlInfoTypeCd( data.get("reportDtlInfoTypeCd") != null ? data.get("reportDtlInfoTypeCd").toString() : "")
                            .nomenclatureNm( data.get("nomenclatureNm") != null ? data.get("nomenclatureNm").toString() : "")
                            .partNm( data.get("partNm") != null ? data.get("partNm").toString() : "")
                            .serialnoNm( data.get("serialnoNm") != null ? data.get("serialnoNm").toString() : "")
                            .build();

                    commonSql.insert("AvnSafetyReport.insertReportMsrDtlInfo", tbAvnReportMsrDtlInfoDto);
                };
            }else if("gsr".equals(rptTypeCd)){
                TbAvnReportGsrDto tbAvnReportGsrDto = mapper.treeToValue(saveObj.get("reportGsr"), TbAvnReportGsrDto.class);
                List<Map<String, Object>> reportDtlList = mapper.treeToValue(saveObj.get("reportDtl"), ArrayList.class);
                tbAvnReportGsrDto.setReportId(reportId);
                commonSql.update("AvnSafetyReport." + workGb + "ReportGsr", tbAvnReportGsrDto);
                commonSql.delete("AvnSafetyReport.deleteReportGsrDtlInfo", reportId);

                for (Map<String, Object> data : reportDtlList) {
                    TbAvnReportGsrDtlInfoDto tbAvnReportGsrDtlInfoDto = 
                        TbAvnReportGsrDtlInfoDto
                            .builder()
                            .reportId( reportId)
                            .reportDtlInfoTypeCd( data.get("reportDtlInfoTypeCd") != null ? data.get("reportDtlInfoTypeCd").toString() : "")
                            .aircraftDamageAreaCd( data.get("aircraftDamageAreaCd") != null ? data.get("aircraftDamageAreaCd").toString() : "")
                            .aircraftDamageCn( data.get("aircraftDamageCn") != null ? data.get("aircraftDamageCn").toString() : "")
                            .relEquipCd( data.get("relEquipCd") != null ? data.get("relEquipCd").toString() : "")
                            .regNoNm( data.get("regNoNm") != null ? data.get("regNoNm").toString() : "")
                            .mntcHistNm( data.get("mntcHistNm") != null ? data.get("mntcHistNm").toString() : "")
                            .relGspCd( data.get("relGspCd") != null ? data.get("relGspCd").toString() : "")
                            .chargeDeptCd( data.get("chargeDeptCd") != null ? data.get("chargeDeptCd").toString() : "")
                            .gsrCn( data.get("gsrCn") != null ? data.get("gsrCn").toString() : "")
                            .build();


                    commonSql.insert("AvnSafetyReport.insertReportGsrDtlInfo", tbAvnReportGsrDtlInfoDto);
                };
            }else if("hzr".equals(rptTypeCd)){
                TbAvnReportHzrDto tbAvnReportHzrDto = mapper.treeToValue(saveObj.get("reportHzr"), TbAvnReportHzrDto.class);
                tbAvnReportHzrDto.setReportId(reportId);
                commonSql.update("AvnSafetyReport." + workGb + "ReportHzr", tbAvnReportHzrDto);

            }else if("dsr".equals(rptTypeCd)){
                TbAvnReportDsrDto tbAvnReportDsrDto = mapper.treeToValue(saveObj.get("reportDsr"), TbAvnReportDsrDto.class);
                tbAvnReportDsrDto.setReportId(reportId);
                commonSql.update("AvnSafetyReport." + workGb + "ReportDsr", tbAvnReportDsrDto);

            }else if("rsr".equals(rptTypeCd)){
                TbAvnReportRsrDto tbAvnReportRsrDto = mapper.treeToValue(saveObj.get("reportRsr"), TbAvnReportRsrDto.class);
                tbAvnReportRsrDto.setReportId(reportId);
                commonSql.update("AvnSafetyReport." + workGb + "ReportRsr", tbAvnReportRsrDto);

            }else if("foqa".equals(rptTypeCd)){
                TbAvnReportFoqaDto tbAvnReportFoqaDto = mapper.treeToValue(saveObj.get("reportFoqa"), TbAvnReportFoqaDto.class);
                tbAvnReportFoqaDto.setReportId(reportId);
                commonSql.update("AvnSafetyReport." + workGb + "ReportFoqa", tbAvnReportFoqaDto);

            }else if("smr".equals(rptTypeCd)){
                TbAvnReportSmrDto tbAvnReportSmrDto = mapper.treeToValue(saveObj.get("reportFoqa"), TbAvnReportSmrDto.class);
                tbAvnReportSmrDto.setReportId(reportId);
                commonSql.update("AvnSafetyReport." + workGb + "ReportSmr", tbAvnReportSmrDto);

            }

            if( saveObj.get("flight") != null ){
                TbAvnReportFlightDto tbAvnReportFlightDto = mapper.treeToValue(saveObj.get("flight"), TbAvnReportFlightDto.class);
                List<Map<String, Object>> flightCrewList = mapper.treeToValue(saveObj.get("flightCrew"), ArrayList.class);
                tbAvnReportFlightDto.setReportId(reportId);
                
                commonSql.update("AvnSafetyReport." + workGb + "ReportFlight", tbAvnReportFlightDto);
                commonSql.delete("AvnSafetyReport.deleteReportFlightCrew", reportId);
    
                for (Map<String, Object> data : flightCrewList) {
                    TbAvnReportFlightCrewDto tbAvnReportFlightCrewDto = new TbAvnReportFlightCrewDto();
                    
                    tbAvnReportFlightCrewDto.setReportId(reportId);
                    tbAvnReportFlightCrewDto.setEmpNo(data.get("empNo").toString() );
                    tbAvnReportFlightCrewDto.setCrewTypeCd(data.get("crewTypeCd").toString());
    
                    commonSql.insert("AvnSafetyReport.insertReportFlightCrew", tbAvnReportFlightCrewDto);
                };
            }
            
        } catch (JsonProcessingException | IllegalArgumentException e) {
            throw new CustomBusinessException(e.getMessage());
        }

        return reportId;
    }

    public List<TreeCodeDto> selectTreeCodeList(String codeGrpId){
        TbSysCodeDto tbSysCodeDto = new TbSysCodeDto();

            tbSysCodeDto.setCodeGrpId(codeGrpId);
            List<TreeCodeDto> rtnCdList = commonSql.selectList("AvnSafetyReport.selectTreeCodeList", tbSysCodeDto);
            
        return rtnCdList;
    }

    public List<TbSysCodeDto> commonCodeList(String codeGrpId, String cdArr){
        TbSysCodeDto tbSysCodeDto = new TbSysCodeDto();

            tbSysCodeDto.setCodeGrpId(codeGrpId);
            tbSysCodeDto.setCodeIdArr(cdArr);
            List<TbSysCodeDto> rtnCdList = commonSql.selectList("KsmsCommon.selectCodeArrList", tbSysCodeDto);
            
        return rtnCdList;
    }
}
