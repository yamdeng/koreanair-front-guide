package com.koreanair.ksms.avn.srm.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class IvApprovalDto {

    @NotBlank
    private String Phase;

    @NotBlank
    private String approvalType;

    private String reason;
}
