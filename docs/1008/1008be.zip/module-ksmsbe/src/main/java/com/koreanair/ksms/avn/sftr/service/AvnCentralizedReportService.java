package com.koreanair.ksms.avn.sftr.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sftr.dto.CentralizedGroupDto;
import com.koreanair.ksms.avn.sftr.dto.CentralizedReportDto;
import com.koreanair.ksms.avn.sftr.dto.CentralizedReportSearchDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;

import java.util.List;

public interface AvnCentralizedReportService {
    PageInfo<CentralizedGroupDto> selectCentralizedGroupList(CentralizedReportSearchDto reportSearchDto);

    List<CentralizedReportDto> selectCentralizedReportList(CentralizedGroupDto param);

    CentralizedGroupDto selectCentralizedGroupReportInfo(CentralizedGroupDto param);

    void updateCentralizedGroup(CentralizedGroupDto param) throws CustomBusinessException;

    void insertCentralizedReport(CentralizedGroupDto param) throws CustomBusinessException;

    void deleteCentralizedReport(CentralizedGroupDto param) throws CustomBusinessException;



    void insertBatchCentralizedReport();
}
