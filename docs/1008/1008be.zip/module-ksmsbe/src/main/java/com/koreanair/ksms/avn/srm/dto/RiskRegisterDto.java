package com.koreanair.ksms.avn.srm.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RiskRegisterDto {
	
	private String dateType;

	@NotNull
	private String startDate;

	@NotNull
	private String endDate;

	private List<String> multipleDocumentType;
	
	private List<String> riskSeverity;
	
}
