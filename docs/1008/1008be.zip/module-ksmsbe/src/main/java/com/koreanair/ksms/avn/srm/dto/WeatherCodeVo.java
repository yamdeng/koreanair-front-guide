package com.koreanair.ksms.avn.srm.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class WeatherCodeVo extends SmWeatherKeCodeWeather {

	private String codeValue;
	
	private String nameKo;
	
	private String nameEn;
}
