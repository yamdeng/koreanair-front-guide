package com.koreanair.ksms.avn.admin.controller;

import java.util.List;

import com.koreanair.ksms.common.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.service.AvnCriteriaManageService;
import com.koreanair.ksms.common.utils.ResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 관리자 - 필수 항목 관리
 */
@Tag(name = "AvnCriteriaManage", description = "관리자 - 필수 항목 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnCriteriaManageController {

    @Autowired
    AvnCriteriaManageService service;

    /**
     * 위해요인 등록부 관리 목록 조회
     *
     * @param pageNum the pageNum
     * @param pageSize the pageSize

     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "위해요인 등록부 관리 목록 조회", description = "위해요인 등록부 관리 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "hazardLv1Id", description = "hazardLv1Id"),
            @Parameter(name = "hazardLv2Id", description = "hazardLv2Id"),
            @Parameter(name = "hazardLv3Id", description = "hazardLv3Id"),
            @Parameter(name = "hazardLvoneNm", description = "Level 1"),
            @Parameter(name = "hazardLvtwoNm", description = "Level 2"),
            @Parameter(name = "hazardLvthreeNm", description = "Level 3"),
            @Parameter(name = "hazardCn", description = "위해요인 내용"),
            @Parameter(name = "sourcesCn", description = "출처"),
            @Parameter(name = "consequenceCn", description = "잠재결과"),
            @Parameter(name = "useYn", description = "사용여부"),
            @Parameter(name = "notesCn", description = "비고"),
            @Parameter(name = "viewSn", description = "정렬순서")
    })
    @GetMapping(value = "/admin/criteria/taxonomies")
    public ResponseEntity<?> getHazardTaxonomyList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="hazardLvthreeNm") String hazardLvthreeNm
            ,@RequestParam(value="hazardLvtwoId") int hazardLvtwoId
            ,@RequestParam(value="hazardLvthreeId") int hazardLvthreeId
            ,@RequestParam(value="hazardCn") String hazardCn
            ,@RequestParam(value="sourcesCn") String sourcesCn
            ,@RequestParam(value="consequenceCn") String consequenceCn
            ,@RequestParam(value="useYn") String useYn
            ,@RequestParam(value="notesCn") String notesCn
            ,@RequestParam(value="viewSn") int viewSn) {

        // 조회조건 parameter
        TbAvnHazardLv3Dto tbAvnHazardLv3Dto = new TbAvnHazardLv3Dto();

        tbAvnHazardLv3Dto.setHazardLvthreeNm(hazardLvthreeNm);
        tbAvnHazardLv3Dto.setHazardLvtwoId(hazardLvtwoId);                  // hazardLv2Id
        tbAvnHazardLv3Dto.setHazardLvthreeId(hazardLvthreeId);              // hazardLv3Id
        tbAvnHazardLv3Dto.setHazardCn(hazardCn);                            // 위해요인 내용
        tbAvnHazardLv3Dto.setSourcesCn(sourcesCn);                          // 출처
        tbAvnHazardLv3Dto.setConsequenceCn(consequenceCn);                  // 잠재결과
        tbAvnHazardLv3Dto.setUseYn(useYn);                                  // 사용여부
        tbAvnHazardLv3Dto.setNotesCn(notesCn);                              // 비고
        tbAvnHazardLv3Dto.setViewSn(viewSn);                // 정렬순서

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnHazardLv3Dto> pageList = service.selectTaxonomyList(tbAvnHazardLv3Dto);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "위해요인 등록부 관리 상세정보 조회", description = "위해요인 등록부 관리 상세정보 조회 API")
    @Parameter(name = "hazardLv3Id", description = "")
    @GetMapping(value = "/admin/criteria/taxonomies/{hazardLv3Id}")
    public ResponseEntity<?> getHazardTaxonomyInfo(@PathVariable(value="hazardLv3Id", required=true) int hazardLvthreeId) {

        TbAvnHazardLv3Dto result = service.selectTaxonomyDetail(hazardLvthreeId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 위해요인 등록부 관리 등록", description = "신규 위해요인 등록부 관리 등록 API")
    @PostMapping(value = "/admin/criteria/taxonomies")
    public ResponseEntity<?> insertHazardTaxonomy(@Valid @RequestBody(required=true) TbAvnHazardLv3Dto tbAvnHazardLv3Dto) {

        service.insertTaxonomy(tbAvnHazardLv3Dto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "위해요인 등록부 관리 정보 수정", description = "위해요인 등록부 관리 정보 수정 API")
    @PutMapping(value = "/admin/criteria/taxonomies/{hazardLv3Id}")
    public ResponseEntity<?> updateHazardTaxonomy(
            @PathVariable(value="hazardLv3Id", required=true) int hazardLvthreeId,
            @Valid @RequestBody(required=true) TbAvnHazardLv3Dto tbAvnHazardLv3Dto) {

        tbAvnHazardLv3Dto.setHazardLvthreeId(hazardLvthreeId);
        service.updateTaxonomy(tbAvnHazardLv3Dto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "위해요인 등록부 관리 삭제", description = "위해요인 등록부 관리 삭제 API")
    @Parameter(name = "hazardLv3Id", description = "")
    @DeleteMapping(value = "/admin/criteria/taxonomies/{hazardLv3Id}")
    public ResponseEntity<?> deleteHazardRegister(@PathVariable(value="hazardLv3Id", required=true) int hazardLvthreeId) {

        service.deleteTaxonomy(hazardLvthreeId);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Potential Consequence 목록 조회
     *
     * @param pageNum the page num
     * @param pageSize the page size

     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Potential Consequence 목록 조회", description = "Potential Consequence 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "ConsequenceId", description = "잠재결과ID"),
            @Parameter(name = "reportType", description = "리포트타입"),
            @Parameter(name = "nameKo", description = "잠재적결과 국문명"),
            @Parameter(name = "nameEn", description = "잠재적결과 영문명"),
            @Parameter(name = "useYn", description = "사용여부"),
            @Parameter(name = "notes", description = "비고")
    })
    @GetMapping(value = "/admin/criteria/consequences")
    public ResponseEntity<?> getPotentialConsequenceList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="reportTypeCd") String reportTypeCd
            ,@RequestParam(value="consequenceKoNm") String consequenceKoNm
            ,@RequestParam(value="consequenceEnNm") String consequenceEnNm
            ,@RequestParam(value="useYn") String useYn
            ,@RequestParam(value="notesCn") String notesCn)  {

        // 조회조건 parameter
        TbAvnConsequenceDto tbAvnConsequenceDto = new TbAvnConsequenceDto();

        tbAvnConsequenceDto.setReportTypeCd(reportTypeCd);   // 리포트 타입
        tbAvnConsequenceDto.setConsequenceKoNm(consequenceKoNm);           // 잠재적결과 국문명
        tbAvnConsequenceDto.setConsequenceEnNm(consequenceEnNm);           // 잠재적결과 영문명
        tbAvnConsequenceDto.setUseYn(useYn);             // 사용여부
        tbAvnConsequenceDto.setNotesCn(notesCn);             // 비고

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnConsequenceDto> pageList = service.selectConsequenceList(tbAvnConsequenceDto);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "Potential Consequence 상세정보 조회", description = "Potential Consequence 상세정보 조회 API")
    @Parameter(name = "consequenceId", description = "잠재결과 ID")
    @GetMapping(value = "/admin/criteria/consequences/{consequenceId}")
    public ResponseEntity<?> getPotentialConsequenceInfo(@PathVariable(value="consequenceId", required=true) int consequenceId) {

        TbAvnConsequenceDto result = service.selectConsequenceDetail(consequenceId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 Potential Consequence 등록", description = "신규 Potential Consequence 등록 API")
    @PostMapping(value = "/admin/criteria/consequences")
    public ResponseEntity<?> insertPotentialConsequence(@Valid @RequestBody(required=true) TbAvnConsequenceDto tbAvnConsequenceDto) {

        service.insertPotentialConsequence(tbAvnConsequenceDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Potential Consequence 정보 수정", description = "Potential Consequence 정보 수정 API")
    @Parameter(name = "consequenceId", description = "잠재결과 ID")
    @PutMapping(value = "/admin/criteria/consequences/{consequenceId}")
    public ResponseEntity<?> updatePotentialConsequence(
            @PathVariable(value="consequenceId", required=true) int consequenceId,
            @Valid @RequestBody(required=true) TbAvnConsequenceDto tbAvnConsequenceDto) {

        tbAvnConsequenceDto.setConsequenceId(consequenceId);
        service.updatePotentialConsequence(tbAvnConsequenceDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Potential Consequence 삭제", description = "Potential Consequence 삭제 API")
    @Parameter(name = "consequenceId", description = "잠재결과 ID")
    @DeleteMapping(value = "/admin/criteria/consequences/{consequenceId}")
    public ResponseEntity<?> deletePotentialConsequence(@PathVariable(value="consequenceId", required=true) int consequenceId) {

        service.deletePotentialConsequence(consequenceId);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 이벤트 타입 관리 목록 조회
     *
     * @param pageNum the page num
     * @param pageSize the page size

     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "이벤트 타입 관리 목록 조회", description = "이벤트 타입 관리 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호")
            ,@Parameter(name = "pageSize", description = "페이지 목록 개수")
            ,@Parameter(name = "reportTypeCd", description = "리포트 구분")
            ,@Parameter(name = "eventNm", description = "이벤트명")
            ,@Parameter(name = "useYn", description = "사용여부")
            ,@Parameter(name = "notesCn", description = "비고")
    })
    @GetMapping(value = "/admin/criteria/event-types")
    public ResponseEntity<?> getEventTypeList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
           , @RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
           , @RequestParam(value="reportTypeCd") String reportTypeCd
           , @RequestParam(value="eventNm") String eventNm
           , @RequestParam(value="useYn") String useYn
           , @RequestParam(value="notesCn") String notesCn) {
        
        // 조회조건 parameter
        TbAvnEventDto tbAvnEventDto = new TbAvnEventDto();
        
        tbAvnEventDto.setReportTypeCd(reportTypeCd);  // 리포트 구분
        tbAvnEventDto.setEventNm(eventNm);  // 이벤트명
        tbAvnEventDto.setUseYn(useYn);  // 사용여부
        tbAvnEventDto.setNotesCn(notesCn);  // 비고

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnEventDto> pageList = service.selectEventTypeList(tbAvnEventDto);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "이벤트 타입 관리 상세정보 조회", description = "이벤트 타입 관리 상세정보 조회 API")
    @Parameter(name = "eventId", description = "이벤트 ID")
    @GetMapping(value = "/admin/criteria/event-types/{eventId}")
    public ResponseEntity<?> getEventTypeInfo(@PathVariable(value="eventId", required=true) int eventId) {

        TbAvnEventDto result = service.selectEventTypeDetail(eventId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 이벤트 타입 관리 등록", description = "신규 이벤트 타입 관리 등록 API")
    @PostMapping(value = "/admin/criteria/event-types")
    public ResponseEntity<?> insertEventType(@Valid @RequestBody(required=true) TbAvnEventDto tbAvnEventDto) {

        service.insertEventType(tbAvnEventDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "이벤트 타입 관리 정보 수정", description = "이벤트 타입 관리 정보 수정 API")
    @Parameter(name = "eventId", description = "이벤트 ID")
    @PutMapping(value = "/admin/criteria/event-types/{eventId}")
    public ResponseEntity<?> updateEventType(
            @PathVariable(value="eventId", required=true) int eventId,
            @Valid @RequestBody(required=true) TbAvnEventDto tbAvnEventDto) {

        tbAvnEventDto.setEventId(eventId);
        service.updateEventType(tbAvnEventDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "이벤트 타입 관리 삭제", description = "이벤트 타입 관리 삭제 API")
    @Parameter(name = "eventId", description = "이벤트 ID")
    @DeleteMapping(value = "/admin/criteria/event-types/{eventId}")
    public ResponseEntity<?> deleteEventType(@PathVariable(value="eventId", required=true) int eventId) {

        service.deleteEventType(eventId);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * RISK MATRIX 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "RISK MATRIX 관리 목록 조회", description = "RISK MATRIX 관리 목록 조회 API")
    @GetMapping(value = "/admin/criteria/risk-matrix")
    public ResponseEntity<?> getRiskMatrixList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "RISK MATRIX 관리 상세정보 조회", description = "RISK MATRIX 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/criteria/risk-matrix/{riskMatrixId}")
    public ResponseEntity<?> getRiskMatrixInfo(@PathVariable(value="riskMatrixId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "RISK MATRIX 관리 정보 수정", description = "RISK MATRIX 관리 정보 수정 API")
    @PutMapping(value = "/admin/criteria/risk-matrix/{riskMatrixId}")
    public ResponseEntity<?> updateRiskMatrix(
            @PathVariable(value="riskMatrixId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }
}
