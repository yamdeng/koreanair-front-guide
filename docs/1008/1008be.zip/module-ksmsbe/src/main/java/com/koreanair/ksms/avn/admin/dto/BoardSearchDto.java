package com.koreanair.ksms.avn.admin.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BoardSearchDto {

    @Schema(description = "게시판 ID")
    private int boardId;

    @Schema(description = "페이지 번호")
    private int pageNum;
    
    @Schema(description = "페이지 사이즈")
    private int pageSize;
    
    @Schema(description = "게시판구분")
    private String boardType;
    
    @Schema(description = "정책구분")
    private String policyType;

    @Schema(description = "업무구분")
    private String jobType;

    @Schema(description = "공지구분")
    private String notiType;

    @Schema(description = "배너구분")
    private String bannerType;

    @Schema(description = "부문")
    private String division;
    
    @Schema(description = "보고서구분")
    private String reportType;
    
    @Schema(description = "시작일자")
    private String fromDate;
    
    @Schema(description = "종료일자")
    private String toDate;
    
    @Schema(description = "구분")
    private String gubun;
    
    @Schema(description = "코드")
    private String code;
    
    @Schema(description = "타이틀 한글명")
    private String titleKo;
    
    @Schema(description = "타이틀 영문명")
    private String titleEn;
    
    @Schema(description = "사용여부")
    private String useYn;

    @Schema(description = "팝업여부")
    private String popupYn;

    @Schema(description = "게시판 구분 목록")
    private String selectAll;
    
    @Schema(description = "보기여부")
    private String viewYn;

    @Schema(description = "언어구분")
    private String languageType;
    
    @Builder
    public BoardSearchDto(
            int boardId,
            Integer pageNum,
            Integer pageSize,
            String boardType,
            String policyType,
            String jobType,
            String notiType,
            String bannerType,
            String division,
            String reportType,
            String fromDate,
            String toDate,
            String gubun,
            String code,
            String titleKo,
            String titleEn,
            String useYn,
            String popupYn,
            String viewYn,
            String selectAll,
            String languageType
            ) {
        this.boardId = boardId;
        this.pageNum = pageNum == null ? 1 : pageNum;
        this.pageSize = pageSize == null ? 10 : pageSize;
        this.boardType = boardType;
        this.policyType = policyType;
        this.jobType = jobType;
        this.notiType = notiType;
        this.bannerType = bannerType;
        this.division = division;
        this.reportType = reportType;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.gubun = gubun;
        this.code = code;
        this.titleKo = titleKo;
        this.titleEn = titleEn;
        this.useYn = useYn;
        this.popupYn = popupYn;
        this.viewYn = viewYn;
        this.selectAll = selectAll;
        this.languageType = languageType;
    }
}
