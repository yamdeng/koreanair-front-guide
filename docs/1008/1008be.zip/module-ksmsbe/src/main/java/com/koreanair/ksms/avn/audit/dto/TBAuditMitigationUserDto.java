package com.koreanair.ksms.avn.audit.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
@Schema(description = "Audit / MitigationUser")
@JsonIgnoreProperties(value = {"handler"})
public class TBAuditMitigationUserDto extends CommonDto {
    @Schema(description = "mitigationId")
    @NotNull
    private int mitigationId;
    private String empNo;
    private String empNm;
}
