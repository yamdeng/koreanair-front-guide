package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.constants.AvnStatusCode.ReportStatus;
import com.koreanair.ksms.common.dto.TbAvnSmGroupList;
import com.koreanair.ksms.common.exception.CustomBusinessException;

import java.util.List;
import java.util.Map;

public interface AvnReportProcessService {

    //그룹묶기 유효성 체크
    boolean getIsValidateGroupReport(Integer groupId);

    //그룹묶기 유효성 체크 : 묶음 카운트 체크
    List<String> getIsValidateCountGroupReport(Integer groupId);

    //(그리드)그룹묶기 처리
    void insertMergeGroupReport(List<Integer> groupReportList);

    //(접수)그룹묶기 처리
    void updateMergeGroupReport(Integer groupId, List<Integer> groupReportList);

    //(접수)그룹묶기 삭제 처리
    void deleteMergeGroupReport(Integer groupId, Integer reportId) throws Exception;

    //보고서 대표 보고서 수정
    void updateIsMainReport(TbAvnSmGroupList tbAvnSmGroupList);

    Map<String, Object> selectGroupedValidateReportId(Integer reportId);

    int voidReport(ReportVoidVo vo) throws CustomBusinessException;

    int updateVoidReportId(ReportVoidVo voidVo) throws CustomBusinessException;

    boolean smsReportProcess(ReportProcessVo processVo) throws CustomBusinessException;

    boolean smsHazardProcess(ReportProcessVo processVo) throws CustomBusinessException;

    boolean smsHazardProcessExpt(ReportProcessVo processVo) throws CustomBusinessException;

    void processAction(ReportProcessVo processVo, String reportType, ReportStatus stat) throws CustomBusinessException;

    void updateReportStatus(ReportProcessVo processVo, String reportType, ReportStatus stat) throws CustomBusinessException;

    void updateHazardStatus(ReportProcessVo processVo, String reportType, ReportStatus stat) throws CustomBusinessException;

    void insertReportRole(ReportProcessVo processVo, String reportType, ReportStatus stat) throws CustomBusinessException;

    void deleteReportRole(ReportProcessVo processVo, String reportType, ReportStatus stat) throws CustomBusinessException;

    ReportProcessDto selectReportStatus(ReportProcessVo processVo) throws CustomBusinessException;

    HazardProcessDto selectHazardStatus(int id) throws CustomBusinessException;

    MitigationMemberDto selectMitigationMember(int hazardId) throws CustomBusinessException;

    boolean insertLscMember(ReportRoleAccountDto param) throws CustomBusinessException;

    boolean validateDeleteMitigationRole(RejectMitigationDto param)  throws CustomBusinessException;

    List<HazardCommentLogVo> selectCommentLog(Integer hazardId);

    List<HazardViewlistVo> selectHazardlist(HazardViewlistDto.GET_Request param);

    ReportStateInfoVo selectReportStateSetting(ReportInfoDto.GET_Request dto);

    void updateFirstRiskAssessment(SSCReveiwDto.POST_Request parameter);

    boolean isSectorSafetyTeamChecked(String deptCd);

    List<SmReport> selectReportCurrentStateInfo(HazardViewlistDto.GET_Request hazardParam);

    void updateFirstRiskAssessmentSeveral(SSCReveiwDto.POST_SeveralRequest parameter) throws CustomBusinessException;
}
