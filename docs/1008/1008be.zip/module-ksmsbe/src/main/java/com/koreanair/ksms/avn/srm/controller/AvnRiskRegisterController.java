package com.koreanair.ksms.avn.srm.controller;

import com.koreanair.ksms.avn.srm.dto.RiskRegisterDto;
import com.koreanair.ksms.avn.srm.dto.RiskRegisterResponseDto;
import com.koreanair.ksms.avn.srm.service.AvnRiskRegisterService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.avn.srm.dto.RiskRegisterVo;
import com.koreanair.ksms.common.dto.SmReportOptionDto;
import com.koreanair.ksms.common.dto.ViewlistOptionEntityDto;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.utils.KeUtils;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * 안전위험관리 - 위험도대장
 */
@Tag(name = "AvnRiskRegister", description = "안전위험관리 - 위험도대장 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnRiskRegisterController {

    @Autowired
    AvnRiskRegisterService avnRiskRegisterService;

    @Autowired
    AvnCommonService avnCommonService;

    private static final List<String> defaultMultiplePayload = Arrays.asList("all");

    /**
     * 위험도 대장 목록 조회
     *
     * @param RiskRegisterDto the parameter
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "위험도 대장 목록 조회", description = "위험도 대장 목록 조회 API")
    @GetMapping(value = "/srm/risk-registers")
    public ResponseEntity<?> getRiskRegisterList(
            @Valid @ModelAttribute RiskRegisterDto parameter)
    {
        java.sql.Date startDate = java.sql.Date.valueOf(parameter.getStartDate());
        java.sql.Date endDate = java.sql.Date.valueOf(parameter.getEndDate());

        RiskRegisterResponseDto data = new RiskRegisterResponseDto();
        if (KeUtils.validatePeriodByYear(startDate, endDate, 5)) {
            List<String> auth = new ArrayList<>();
            auth.add("risk_register");
            List<String> reportAuthority = avnCommonService.getAuthReportList(auth);
            SmReportOptionDto reportOptionDto = new SmReportOptionDto("riskRegister","CODE_GRP_092");
            if(reportAuthority.size() > 0) {
                reportOptionDto.setValueFilter(reportAuthority);
            }
            List<ViewlistOptionEntityDto> reportList = avnCommonService.selectReportOptionEntityList(reportOptionDto);

            List<String> documentType = Optional.ofNullable(parameter.getMultipleDocumentType())
        					    .orElseGet(() -> defaultMultiplePayload);
            List<String> riskSeverity = Optional.ofNullable(parameter.getRiskSeverity())
                    .orElseGet(() -> defaultMultiplePayload);

            if(riskSeverity.isEmpty()) {
                parameter.setRiskSeverity(null);
            }

            //all 로 들어온경우 데이터를 삭제해야 정상적으로 쿼리 조회가능
            if(documentType.size() == 1) {
                // 시스템관리자인 경우 null로 파라미터를 처리
                if("all".equals(documentType.get(0)) && reportAuthority.isEmpty()) {
                    parameter.setMultipleDocumentType(null);
                }else if("all".equals(documentType.get(0))) {
                    parameter.setMultipleDocumentType(reportAuthority);
                }
            }

            if(riskSeverity.size() == 1) {
                if("all".equals(riskSeverity.get(0))) {
                    parameter.setRiskSeverity(null);
                }
            }

            List<RiskRegisterVo> dataSource = avnRiskRegisterService.selectRiskRegisterViewlist(parameter);
            Map<String,List<ViewlistOptionEntityDto>> rangeSearchOption = new HashMap<String,List<ViewlistOptionEntityDto>>();
            if (reportList.size() == 1) {
                rangeSearchOption.put("reportList", reportList);
            } else {
                ViewlistOptionEntityDto treeReport = new ViewlistOptionEntityDto("all","all","모두");
                treeReport.removeKey();
                List<ViewlistOptionEntityDto> treeReportList = new ArrayList<ViewlistOptionEntityDto>();
                //프론트 콘솔오류 제거용함수호출
                for(ViewlistOptionEntityDto item:reportList) {
                    item.removeKey();
                }
                treeReport.setChildren(reportList);
                treeReportList.add(treeReport);
                rangeSearchOption.put("reportList", treeReportList);
            }
            data.setDataSource(dataSource);
            data.setRangeSearchOption(rangeSearchOption);
            return ResponseUtil.createSuccessResponse(data);
        }
        return ResponseUtil.createSuccessResponse(data);
    }

    @Operation(summary = "위험도 대장 상세정보 조회", description = "위험도 대장 상세정보 조회 API")
    @GetMapping(value = "/srm/risk-registers/{riskRegisterId}")
    public ResponseEntity<?> getRiskRegisterInfo(@PathVariable(value="riskRegisterId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
