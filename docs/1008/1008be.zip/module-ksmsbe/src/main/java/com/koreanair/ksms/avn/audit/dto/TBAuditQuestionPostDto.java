package com.koreanair.ksms.avn.audit.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.util.List;
import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "Checklist / QuestionPost")
public class TBAuditQuestionPostDto extends CommonDto {
    @NotNull
    private int checklistOrigId;

    private int chapterOrigId;

    private String listName;

    private boolean revisionUpdate;

    private List<TBAuditQuestionDto> inserted;

    private List<TBAuditQuestionDto> updated;

    private List<Integer> deleted;
}
