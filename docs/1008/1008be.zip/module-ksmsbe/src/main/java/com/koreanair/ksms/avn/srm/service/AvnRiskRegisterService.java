package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.RiskRegisterDto;
import com.koreanair.ksms.avn.srm.dto.RiskRegisterVo;

import java.util.List;

public interface AvnRiskRegisterService {
    List<RiskRegisterVo> selectRiskRegisterViewlist(RiskRegisterDto parameter);
}
