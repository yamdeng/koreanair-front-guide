package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.dto.ViewlistOptionEntityDto;
import lombok.*;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class RiskRegisterResponseDto {

	private  List<RiskRegisterVo> dataSource;
	
	private  Map<String,List<ViewlistOptionEntityDto>> rangeSearchOption;
}
