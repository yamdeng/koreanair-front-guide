package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.FoqaLimitationDto;
import com.koreanair.ksms.common.dto.TbAvnReportFoqaLimitation;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnLimitationManageServiceImpl extends AbstractBaseService implements AvnLimitationManageService {

    @Override
    public PageInfo<TbAvnReportFoqaLimitation> selectLimitationManageList(FoqaLimitationDto param) {
        List<TbAvnReportFoqaLimitation> resultList = commonSql.selectList("AvnLimitationManage.selectLimitationManageList", param);
        return PageInfo.of(resultList);
    }

    @Override
    public TbAvnReportFoqaLimitation selectLimitationManageInfo(FoqaLimitationDto param) {
        return commonSql.selectOne("AvnLimitationManage.selectLimitationManageList", param);
    }

    @Override
    public void insertLimitationManage(TbAvnReportFoqaLimitation param) {
        commonSql.insert("AvnLimitationManage.insertLimitation", param);
    }

    @Override
    public void updateLimitationManageInfo(TbAvnReportFoqaLimitation param) {
        commonSql.update("AvnLimitationManage.updateLimitation", param);
    }

    @Override
    public void deleteLimitationManageInfo(int id) {
        commonSql.delete("AvnLimitationManage.deleteLimitation", id);
    }
}
