package com.koreanair.ksms.common.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class FoqaLimitationDto {
	private int pageNum = 1;
    private int pageSize = 10;

	private Integer id;

	private String eventTypeId;

	private String fleetCode;
}
