package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;
import java.util.List;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import com.koreanair.ksms.common.dto.CommonDto;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SmMitigation extends CommonDto {
	@NotNull
	private int id;
	@NotNull
	private int hazardId;
	@NotNull
	private int deptId;

	private String empNo;

	private String plan;

	private String result;

	private String hazardNo;

	private List<ProgressRateVo> progressRate;

	private String isSubmittedPlan;

	private String isSubmittedResult;
	@NotNull
	private String leaderEmpNo;

	private List<String> memberEmpNoList;
	@NotNull
	private Timestamp createdAt;
	@NotNull
	private Timestamp updatedAt;

	private Timestamp planSubmittedAt;

	private Timestamp resultSubmittedAt;
	@NotNull
	private String timezone;

	private Timestamp deletedAt;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "Asia/Seoul")
	private Timestamp planDueAt;

	private Integer mitigationCenterDeptId;
	private Integer realMitigationPerform;

}