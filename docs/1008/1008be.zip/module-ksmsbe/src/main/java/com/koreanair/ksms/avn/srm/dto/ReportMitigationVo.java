package com.koreanair.ksms.avn.srm.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ReportMitigationVo {

	private int id;

	private int hazardId;

	private int consequenceId;

	private String riskLevel1;

	private String riskLevel2;

	private String isMitigation;

	private String hazardText;

	private String hazardPath;

	private String deptNameKo;

	private String deptNameEn;

	private String mitPlan;

	private String mitResult;

	private String duty;

	private String stepCode;

	private String leaderEmpNo;

	private String leaderNameKo;

	private String leaderNameEn;

	private String dutyEmpNo;

	private String dutyNameKo;

	private String dutyNameEn;

	private String textUserKo;

	private String textUserEn;

	private String textAdminKo;

	private String textAdminEn;

	private Timestamp planSubmittedAt;

	private Timestamp resultSubmittedAt;

	private List<ProgressRateVo> progressRate;

}