package com.koreanair.ksms.avn.srm.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@ToString
@Schema(description = "보고서 분석 리스트")
public class ReportViewlistVo extends CommonDto {

    @Schema(description = "ID")
    private  int id;

    @Schema(description = "report Id")
    private  int reportId;

    @Schema(description = "group Id")
    private  int groupId;

    @Schema(description = "리포트 유형, code_group=Report Type")
    private  String reportType;

    @Schema(description = "리포트 번호")
    private  String docNo;

    @Schema(description = "제목")
    private  String subject;

    @Schema(description = "step")
    private  String step;

    @Schema(description = "공항코드")
    private  String fleetCode;

    @Schema(description = "비행기 번호")
    private String flightNo;

    @Schema(description = "진행단계")
    private  String phase;

    @Schema(description = "최종 제출일자")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "Asia/Seoul")
    private Timestamp submittedAt;

    @Schema(description = "접수완료일자")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "Asia/Seoul")
    private  Timestamp receiptedAt;

    @Schema(description = "도착일자")
    private  String departureAt;

    @Schema(description = "State타입")
    private  String stateType;

    @Schema(description = "Step Code")
    private  String stepCode;

    @Schema(description = "")
    private  String action;

    @Schema(description = "State타입(한글)")
    private String statusKo;

    @Schema(description = "State타입(영문)")
    private String statusEn;

    @Schema(description = "사유")
    private String reason;

    @Schema(description = "lscMember")
    private String lscMember;

    @Schema(description = "작성자 사원번호")
    private String reportedBy;

    @Schema(description = "작성자 사원명(한글)")
    private String reportedByUserNameKo;

    @Schema(description = "작성자 사원명(영문)")
    private String reportedByUserNameEn;

    @Schema(description = "접수 제출한 접수담당 사원번호")
    private String receiptedBy;

    @Schema(description = "접수 제출한 접수담당 사원명(한글)")
    private String receiptedByUserNameKo;

    @Schema(description = "접수 제출한 접수담당 사원명(영문)")
    private String receiptedByUserNameEn;

    @Schema(description = "익명여부")
    private String isConfidential;

    @Schema(description = "")
    private String headname;

    @Schema(description = "")
    private String deptname;

    @Schema(description = "safetyDay 참여여부")
    private String isSafety;

    @Schema(description = "kairs 동의여부")
    private String isKairs;

    @Schema(description = "비행기 등록 번호")
    private String registrationNo;

    @Schema(description = "접수일자")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "Asia/Seoul")
    private Timestamp receiptAt;

    @Schema(description = "접수자ID")
    private String receiptEmpNo;

    @Schema(description = "접수자 부서ID")
    private int receiptDeptId;

    @Schema(description = "lv3 명")
    private String lv3Name;

    @Schema(description = "lv2 명")
    private String lv2Name;

    @Schema(description = "lv1 명")
    private String lv1Name;

    @Schema(description = "컨시퀀스 ko")
    private String consequenceKo;

    @Schema(description = "컨시퀀스 En")
    private String consequenceEn;

    @Schema(description = "리스크레벨1")
    private String riskLevel1;

    @Schema(description = "리스크점수1")
    private int firstScore;

    @Schema(description = "리스크레벨2")
    private String riskLevel2;

    @Schema(description = "리스크점수2")
    private int secondScore;

    @Schema(description = "경감수행부서ID")
    private int mitigationDeptId;

    @Schema(description = "경감수행부서명 Ko")
    private String mitigationDeptNameKo;

    @Schema(description = "경감수행부서명 En")
    private String mitigationDeptNameEn;

    @Schema(description = "경감수행결과")
    private String mitigationResult;

    @Schema(description = "경감수행책임자ID")
    private String mitigationEmpNo;

    @Schema(description = "경감수행리더ID")
    private String mitigationLeaderEmpNo;

    @Schema(description = "경감수행멤버ID 리스트")
    private String mitigationMemberEmpNoList;

    @Schema(description = "lsc 리더ID")
    private String lscLeaderEmpNo;

    @Schema(description = "이름 Ko")
    private String nameKo;

    @Schema(description = "이름 En")
    private String nameEn;

    @Schema(description = "내용")
    private String contents;

    @Schema(description = "경감여부")
    private String isMitigation;

    private String realMitigationPerform;

    private List<Map> subReportList;

    private boolean hasChildren;
    private boolean expanded;
}
