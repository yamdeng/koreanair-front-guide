import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import _ from 'lodash';
import history from '@/utils/history';

/* zustand store 생성 */
const useMyAuditCloseStore = create<any>((set, get) => ({
  dsAuditCloseInfo: [],

  setAuditCloseInfo: async (auditInfo) => {
    set({ dsAuditCloseInfo: auditInfo });
    const { dsAuditCloseInfo } = get();

    //alert(dsAuditCloseInfo.auditNo);
  },
}));

export default useMyAuditCloseStore;
