import ApiService from '@/services/ApiService';
import { create } from 'zustand';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import _ from 'lodash';
import history from '@/utils/history';
import { produce } from 'immer';
import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import ToastService from '@/services/ToastService';
import ModalService from '@/services/ModalService';
import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';

/* zustand store 생성 */
const useMyAuditCarStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  dsAuditCarInfo: [],
  dsAuditCarList: [],

  // Finding 목록 조회
  setAuditCarInfo: async (auditInfo) => {
    set({ dsAuditCarInfo: auditInfo });
    const { setTotalCount, dsAuditCarInfo } = get();
    const apiResult: any = await ApiService.get(`avn/audit/my-audit/3/cars/ca/${dsAuditCarInfo.auditId}`);
    const data = apiResult.data;
    // const list = disablePaging ? data : data.list;
    const auditCarList = data;
    //const totalCount = disablePaging && list ? list.length : data.total;
    const totalCount = auditCarList.length;
    setTotalCount(totalCount);
    set({ dsAuditCarList: auditCarList || [] });
  },
}));

export default useMyAuditCarStore;
