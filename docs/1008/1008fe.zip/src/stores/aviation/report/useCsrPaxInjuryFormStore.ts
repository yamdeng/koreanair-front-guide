import { FORM_TYPE_UPDATE } from '@/config/CommonConstant';
import ApiService from '@/services/ApiService';
import { formBaseState } from '@/stores/slice/formSlice';
import _ from 'lodash';
import * as yup from 'yup';
import { create } from 'zustand';
import { flighBaseValue } from './reportFormBaseValue';
import {
  csrFlightYupSchema,
  csrInvolveCrewListYupSchema,
  csrInvolveCustomerListYupSchema,
} from './reportFormYupSchema';
import { createCsrReportEditForm, createReportEditForm } from './useEditFormStore';
import CommonYupSchema from '@/utils/CommonYupSchema';

/* 보고서 작성 CSR : 승객부상 */

/* yup validation */
const yupFormSchema = yup.object().shape({
  flight: csrFlightYupSchema,
  flightCrew: yup.array(),
  event: yup.object().shape({
    occurAirportCd: yup.string(),
    occurTimeCd: yup.string().required(),
    inflightOccurLocationCd: yup.string().required(),
    mainCauseCd: yup.string().required(),
    useMedicalEquipCodeList: yup.array().required().min(1),
    injuryPartCodeList: yup.array().required().min(1),
    carCodeList: yup.array().required().min(1),
    seatbeltViewYn: yup.string().required(),
    subjectNm: yup.string().label('제목').required(),
    descriptionTxtcn: CommonYupSchema.editorRequiredYupSchema,
  }),
  involveCustomerList: csrInvolveCustomerListYupSchema,
  involveCrewList: csrInvolveCrewListYupSchema,
});

const initFormValue = {
  flight: { ...flighBaseValue },
  flightCrew: [],
  event: {
    occurAirportCd: '',
    occurTimeCd: '',
    inflightOccurLocationCd: '',
    mainCauseCd: '',
    useMedicalEquipCodeList: [],
    injuryPartCodeList: [],
    carCodeList: [],
    seatbeltViewYn: '',
    subjectNm: '',
    descriptionTxtcn: '',
    fileGroupSeq: null,
  },
  involveCustomerList: [],
  involveCrewList: [],
};

/* form 초기화 */
const initFormData = {
  formName: '',
  ...formBaseState,
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const useCsrPaxInjuryFormStore = create<any>((set, get) => ({
  ...createReportEditForm(set, get),
  ...createCsrReportEditForm(set),

  initFormValue: _.cloneDeep(initFormValue),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  editFormPath: '/aviation/report-form/CSR/paxinjury',

  getDetail: async (id) => {
    const response: any = await ApiService.get(`avn/report/my-reports/${id}`);
    const detailInfo = response.data;
    const { report, reportCsr, flight, flightCrew, reportDtl } = detailInfo;

    // 'report' api에서 event 정보 추출
    const applyEvent = _.pick(report, ['occurAirportCd', 'subjectNm', 'descriptionTxtcn', 'fileGroupSeq']);

    // 'reportCsr' api에서 event 정보 추출
    const applyEvent2 = _.pick(reportCsr, ['occurTimeCd', 'inflightOccurLocationCd', 'mainCauseCd', 'seatbeltViewYn']);

    // 'reportDtl'을 ui 변수에 맞게끔 변환
    let involveCustomerList = [];
    let involveCrewList = [];

    if (reportDtl && reportDtl.length) {
      involveCustomerList = reportDtl.filter((info) => info.reportDtlInfoTypeCd === 'CSR_01');
      involveCrewList = reportDtl.filter((info) => info.reportDtlInfoTypeCd === 'CSR_02');
    }

    // AppCodeSelect : isMultiple
    const useMedicalEquipCodeList = reportCsr.useMedicalEquipCdarr ? reportCsr.useMedicalEquipCdarr.split(',') : [];
    const carCodeList = reportCsr.carCdarr ? reportCsr.carCdarr.split(',') : [];
    const injuryPartCodeList = reportCsr.injuryPartCdarr ? reportCsr.injuryPartCdarr.split(',') : [];

    const applyFormValue = {
      flight: flight,
      flightCrew: flightCrew.map((info) => {
        info.tagName = info.crewTypeCd;
        return info;
      }),
      event: {
        ...applyEvent,
        ...applyEvent2,
        useMedicalEquipCodeList: useMedicalEquipCodeList,
        carCodeList: carCodeList,
        injuryPartCodeList: injuryPartCodeList,
      },
      involveCustomerList: involveCustomerList,
      involveCrewList: involveCrewList,
    };

    set({
      detailInfo: detailInfo,
      formValue: applyFormValue,
      formDetailId: id,
      formType: FORM_TYPE_UPDATE,
    });
  },

  getApiParam: () => {
    const { formValue, formDetailId, detailInfo, reportTypeCd } = get();
    const { flight, flightCrew, event, involveCustomerList, involveCrewList } = formValue;
    const { report, reportCsr } = detailInfo || {};

    // 'report'
    const serverReportParam = {
      ...report,
      reportId: formDetailId ? formDetailId : null,
      reportTypeCd: reportTypeCd,
      ...event,
    };

    // 'reportDtl'
    const serveReportDetailListParam = [];

    involveCustomerList.forEach((customerInfo) => {
      serveReportDetailListParam.push({ ...customerInfo, reportDtlInfoTypeCd: 'CSR_01' });
    });

    involveCrewList.forEach((crewInfo) => {
      serveReportDetailListParam.push({ ...crewInfo, reportDtlInfoTypeCd: 'CSR_02' });
    });

    // 'reportCsr'
    const serverCsrReportParam = {
      reportId: formDetailId ? formDetailId : null,
      reportDtlTypeCd: 'CSR_01',
      ...reportCsr,
      occurTimeCd: event.occurTimeCd,
      inflightOccurLocationCd: event.inflightOccurLocationCd,
      mainCauseCd: event.mainCauseCd,
      seatbeltViewYn: event.seatbeltViewYn,
      useMedicalEquipCdarr: event.useMedicalEquipCodeList ? event.useMedicalEquipCodeList.join(',') : '',
      carCdarr: event.carCodeList ? event.carCodeList.join(',') : '',
      injuryPartCdarr: event.injuryPartCodeList ? event.injuryPartCodeList.join(',') : '',
    };

    // 최종 적용
    const reportApiParam = {
      flight: { ...flight, reportId: formDetailId ? formDetailId : null },
      flightCrew: flightCrew.map((info) => {
        const flightServerInfo = {
          crewTypeCd: info.tagName,
          empNo: info.empNo,
        };
        return flightServerInfo;
      }),
      report: serverReportParam,
      reportCsr: serverCsrReportParam,
      reportDtl: serveReportDetailListParam,
    };
    return reportApiParam;
  },
}));

export default useCsrPaxInjuryFormStore;
