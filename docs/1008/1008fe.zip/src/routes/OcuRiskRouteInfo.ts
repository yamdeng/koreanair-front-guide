import RevalList from '@/components/occupation/risk/reval/RevalList';
import RevalDetail from '@/components/occupation/risk/reval/RevalDetail';
import RevalForm from '@/components/occupation/risk/reval/RevalForm';
import RdcmsrList from '@/components/occupation/risk/rdcmsr/RdcmsrList';
import RdcmsrDetail from '@/components/occupation/risk/rdcmsr/RdcmsrDetail';
import RdcmsrForm from '@/components/occupation/risk/rdcmsr/RdcmsrForm';

import RevalPartnerList from '@/components/occupation/risk/partner/RevalPartnerList';

import RevalPartnerDetail from '@/components/occupation/risk/partner/RevalPartnerDetail';

import RevalPartnerForm from '@/components/occupation/risk/partner/RevalPartnerForm';

import RevalDataList from '@/components/occupation/risk/revalData/RevalDataList';

const RouteInfo: any = { rootPath: 'risk/' };

RouteInfo.list = [
  //** 위험성평가  **/
  // 위험성평가 목록
  {
    Component: RevalList,
    path: 'reval',
  },
  // 위험성평가 상세
  {
    Component: RevalDetail,
    path: 'reval/:detailId',
  },
  // 위험성평가 입력,수정
  {
    Component: RevalForm,
    path: 'reval/:detailId/edit',
  },

  // ** 감소대책 수립 및 실시**/

  // 감소대책 수립 및 실시
  {
    Component: RdcmsrList,
    path: 'rdcmsr',
  },
  // 감소대책 수립 및 실시 상세
  {
    Component: RdcmsrDetail,
    path: 'rdcmsr/:detailId',
  },
  // 감소대책 수립 및 실시 입력,수정
  {
    Component: RdcmsrForm,
    path: 'rdcmsr/:detailId/edit',
  },

  // ** 협력사 위험성평가**/

  // 협력사 위험성평가 목록
  {
    Component: RevalPartnerList,
    path: 'partner',
  },
  // 협력사 위험성평가 상세
  {
    Component: RevalPartnerDetail,
    path: 'partner/:detailId',
  },
  // 협력사 위험성평가 입력,수정
  {
    Component: RevalPartnerForm,
    path: 'partner/:detailId/edit',
  },

  // ** 중요위험 관리**/

  // 중요위험 관리 목록
  {
    Component: RevalDataList,
    path: 'revalData',
  },
];

export default RouteInfo;
