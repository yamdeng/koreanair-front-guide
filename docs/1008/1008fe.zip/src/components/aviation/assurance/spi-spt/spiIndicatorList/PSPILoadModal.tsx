import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import ApiService from '@/services/ApiService';
import ToastService from '@/services/ToastService';
import CommonUtil from '@/utils/CommonUtil';
import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import { useImmer } from 'use-immer';
import * as yup from 'yup';

const yupFormSchema = yup.object({
  loadYear: yup.string().required(),
  loadSpiType: yup.string().required(),
  createYear: yup.string().required(),
});
const initFormValue = {
  loadYear: '',
  loadSpiType: '',
  createYear: '',
};

const formName = 'PSPILoadModal';

function PSPILoadModal(props) {
  const { isOpen, closeModal, ok, searchInfo } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});
  const { loadYear, loadSpiType, createYear } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
  };

  const handleOk = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;
    console.log(formValue);

    if (success) {
      await ApiService.post(`avn/assurance/spi-spt/indicators/loadSpiIndicator`, formValue).then((apiResult) => {
        const detailInfo = apiResult.data;
        if (detailInfo) {
          ToastService.error(detailInfo);
        } else {
          ToastService.success('저장되었습니다.');
          ok(formValue);
        }
      });
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  const handleClose = () => {
    setFormValue({ ...initFormValue });
    closeModal();
  };

  useEffect(() => {
    if (isOpen && detailInfo) {
      // const { loadYear, loadSpiType, createYear } = searchInfo;
      const { spiType, year } = searchInfo;
      // spiName, spiType, year
      setFormValue({
        loadYear: year,
        loadSpiType: spiType,
        createYear: '' + (Number(year) + 1),
      });
    }
  }, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'confirm-modal-content'}
      onRequestClose={() => {
        handleClose();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">지표 불러오기</h3>
        <div className="pop_cont">
          <div className="editbox">
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppDatePicker
                    id="PSPILoadModalloadYear"
                    label="대상연도"
                    value={loadYear}
                    pickerType="year"
                    required
                    onChange={(value) => changeInput('loadYear', value)}
                    errorMessage={errors.loadYear}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppDatePicker
                    id="PSPILoadModalcreateYear"
                    label="생산연도"
                    value={createYear}
                    pickerType="year"
                    required
                    onChange={(value) => changeInput('createYear', value)}
                    errorMessage={errors.createYear}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppCodeSelect
                    id="PSPILoadModalloadSpiType"
                    label={'지표구분'}
                    codeGrpId="CODE_GRP_113"
                    value={loadSpiType}
                    onChange={(value) => changeInput('loadSpiType', value)}
                    errorMessage={errors.loadSpiType}
                  />
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={handleClose}>
            닫기
          </button>
          <button className="btn_text text_color_neutral-10 btn_confirm" onClick={handleOk}>
            저장
          </button>
        </div>
        <span className="pop_close" onClick={handleClose}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default PSPILoadModal;
