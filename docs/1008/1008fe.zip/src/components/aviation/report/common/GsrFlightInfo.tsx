import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppSelect from '@/components/common/AppSelect';
import AppTextInput from '@/components/common/AppTextInput';
import AppTimePicker from '@/components/common/AppTimePicker';
import AirportSearch from '../../common/AirportSearch';

function GsrFlightInfo({ store = {} }) {
  const { changeInput, formValue, searchFligh, errors } = store as any;
  const { flight } = formValue;

  const {
    departureDt,
    flightNo,
    regNo,
    aircraftTypeCd,
    departureAirportCd,
    arrivalAirportCd,
    divertAirportCd,
    stdTime,
    staTime,
    atdTime,
    ataTime,
    delayedMinCo,
    supplyNm,
    checkinNm,
  } = flight;

  return (
    <div className="edit-area">
      <div className="detail-form">
        <div className="detail-list">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <div className="df">
                  <div className="type3">
                    <AppDatePicker
                      label="출발일자"
                      valueFormat="YYYYMMDD"
                      value={departureDt}
                      onChange={(value) => {
                        changeInput('flight.departureDt', value);
                      }}
                      errorMessage={errors['flight.departureDt']}
                    />
                  </div>
                  <div className="type4">
                    <AppSelect disabled value="UTC" />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group va-t ant-input wid100">
                <span className="ant-input-group-addon1">KE</span>
                <div className="ant-input-group-addon1-input wid50 df">
                  {/*비행편명 */}
                  <AppSearchInput
                    label="비행편명"
                    value={flightNo}
                    onChange={(value) => {
                      changeInput('flight.flightNo', value);
                    }}
                    search={searchFligh}
                    errorMessage={errors['flight.flightNo']}
                  />
                  <div className="btn-area">
                    <button
                      type="button"
                      name="button"
                      className="btn-sm btn_text btn-darkblue-line"
                      onClick={searchFligh}
                    >
                      Search
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group va-t ant-input wid100">
                <span className="ant-input-group-addon1">HL</span>
                <div className="ant-input-group-addon1-input wid50">
                  {/*등록기호 */}
                  <AppTextInput
                    label="등록부호"
                    value={regNo}
                    onChange={(value) => {
                      changeInput('flight.regNo', value);
                    }}
                    errorMessage={errors['flight.regNo']}
                  />
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*항공기형식 */}
                <AppCodeSelect
                  label="항공기형식"
                  codeGrpId="CODE_GRP_159"
                  value={aircraftTypeCd}
                  onChange={(value) => {
                    changeInput('flight.aircraftTypeCd', value);
                  }}
                  errorMessage={errors['flight.aircraftTypeCd']}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*출발공항 */}
                <AirportSearch
                  label="출발공항"
                  value={departureAirportCd}
                  onChange={(value) => {
                    changeInput('flight.departureAirportCd', value);
                  }}
                  errorMessage={errors['flight.departureAirportCd']}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AirportSearch
                  label="도착공항"
                  value={arrivalAirportCd}
                  onChange={(value) => {
                    changeInput('flight.arrivalAirportCd', value);
                  }}
                  errorMessage={errors['flight.arrivalAirportCd']}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*회항공항 */}
                <AirportSearch
                  label="회항공항"
                  value={divertAirportCd}
                  onChange={(value) => {
                    changeInput('flight.divertAirportCd', value);
                  }}
                  errorMessage={errors['flight.divertAirportCd']}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*STD */}
                <AppTimePicker
                  label={'STD'}
                  excludeSecondsTime
                  value={stdTime}
                  valueFormat="HHmm"
                  displayFormat="HH:mm"
                  onChange={(value) => {
                    changeInput('flight.stdTime', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*STA */}
                <AppTimePicker
                  label={'STA'}
                  excludeSecondsTime
                  value={staTime}
                  valueFormat="HHmm"
                  displayFormat="HH:mm"
                  onChange={(value) => {
                    changeInput('flight.staTime', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*ATD */}
                <AppTimePicker
                  label={'ATD'}
                  excludeSecondsTime
                  value={atdTime}
                  valueFormat="HHmm"
                  displayFormat="HH:mm"
                  onChange={(value) => {
                    changeInput('flight.atdTime', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*ATA */}
                <AppTimePicker
                  label={'ATA'}
                  excludeSecondsTime
                  value={ataTime}
                  valueFormat="HHmm"
                  displayFormat="HH:mm"
                  onChange={(value) => {
                    changeInput('flight.ataTime', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/*Delay */}
                <AppTextInput
                  inputType={'number'}
                  label="Delay"
                  value={delayedMinCo}
                  onChange={(value) => {
                    changeInput('flight.delayedMinCo', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="좌석수(F/C/Y)"
                  value={supplyNm}
                  onChange={(value) => {
                    changeInput('flight.supplyNm', value);
                  }}
                  errorMessage={errors['flight.supplyNm']}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="탑승자(F/C/Y)"
                  value={checkinNm}
                  onChange={(value) => {
                    changeInput('flight.checkinNm', value);
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GsrFlightInfo;
