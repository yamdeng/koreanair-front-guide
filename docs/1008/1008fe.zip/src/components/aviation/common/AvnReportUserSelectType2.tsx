import AppAutoComplete from '@/components/common/AppAutoComplete';
import { getUserInfoByLocale, getUserLabelByLocale } from '@/services/i18n';
import CommonInputError from '@/components/common/CommonInputError';
import AppSelect from '@/components/common/AppSelect';
import Code from '@/config/Code';

function AvnReportUserSelectType2(props) {
  const {
    label,
    required,
    errorMessage,
    onSelect,
    userSelectKind,
    changeUserSelectKind,
    deleteUser,
    userList,
    up,
    down,
    displaySort = false,
    ...rest
  } = props;
  return (
    <>
      <div className={errorMessage ? 'UserChicebox Flight error' : 'UserChicebox Flight'}>
        <div className="form-group wid100">
          <AppSelect
            name="userSelectKindex"
            options={Code.aviationReportUserSelectKind}
            value={userSelectKind}
            onChange={changeUserSelectKind}
          />
          <label className="file-label">
            {label} {required ? <span className="required"></span> : null}
          </label>
        </div>
        <div className="form-group wid100">
          <AppAutoComplete
            apiUrl="avn/common/users"
            valueKey="empNo"
            dataKey="data.list"
            onSelect={(value) => {
              onSelect(value);
            }}
            onlySelect
            isMultiple={false}
            getOptionLabel={(info) => {
              return getUserLabelByLocale(info);
            }}
            filterOption={() => true}
            {...rest}
          />
          <div className="SelectedList memberClass mt10" style={{ display: userList && userList.length ? '' : 'none' }}>
            <ul>
              {userList.map((userInfo, userListIndex) => {
                const applyUserInfo = getUserInfoByLocale(userInfo);
                const { empNo, userName, deptName, rankName, tagName } = applyUserInfo;
                return (
                  <li key={empNo}>
                    <span className="InfoBox"></span>
                    <div className="Info">
                      <div className="Name">
                        {userName} ({empNo})
                      </div>
                      <div className="Dept">
                        {deptName} / {rankName}
                      </div>
                    </div>
                    <div className="column-box" style={{ display: displaySort ? '' : 'none' }}>
                      <span className="column-btn">
                        <a href={undefined} onClick={() => up(userListIndex)}>
                          <span className="up">up</span>
                        </a>
                        <a href={undefined} onClick={() => down(userListIndex)}>
                          <span className="down">down</span>
                        </a>
                      </span>
                    </div>
                    <span className="class leader" style={{ display: tagName ? '' : 'none' }}>
                      {tagName}
                    </span>
                    <a href={undefined} onClick={() => deleteUser(userListIndex)}>
                      <span className="delete">X</span>
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
      <CommonInputError errorMessage={errorMessage} label={label} />
    </>
  );
}

export default AvnReportUserSelectType2;
