import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import dayjs from 'dayjs';
import { useTranslation } from 'react-i18next';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/assurance/spi-spt/bulletins',
  baseRoutePath: '/aviation/board-manage/spi-board',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  boardType: '120',
  notiType: '',
  popupFromDt: dayjs().format('YYYY-MM-DD'),
  popupToDt: dayjs().format('YYYY-MM-DD'),
  titleKo: '',
};

/* zustand store 생성 */
const AvnSPIBoardListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    boardType: '120',
    notiType: '',
    popupFromDt: dayjs().format('YYYY-MM-DD'),
    popupToDt: dayjs().format('YYYY-MM-DD'),
    titleKo: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function SPIBoardList() {
  const { t } = useTranslation();
  const state = AvnSPIBoardListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번', cellStyle: { textAlign: 'center' } },
      { field: 'notiType', headerName: '게시판 구분', cellStyle: { textAlign: 'center' } },
      { field: 'titleKo', headerName: '제목', cellStyle: { textAlign: 'left' } },
      { field: 'regUserId', headerName: '작성자', cellStyle: { textAlign: 'center' } },
      { field: 'regDttm', headerName: '작성일', cellStyle: { textAlign: 'center' } },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    clear,
    search,
    goDetailPage,
  } = state;
  // TODO : 검색 파라미터 나열
  const { notiType, popupFromDt, popupToDt, titleKo } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.boardId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>SPI게시판</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppCodeSelect
                  // 공통코드 새로 생성해야 함 (세부항목 문의)
                  // codeGrpId="CODE_GRP_142"
                  applyAllSelect
                  label={t('ke.safety.Notice.label.00001')}
                  value={notiType}
                  onChange={(value) => {
                    changeSearchInput('notiType', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={t('admin.AdminMain.NotifyAdmin.regDttm')}
                      pickerType="date"
                      value={popupFromDt}
                      onChange={(value) => {
                        changeSearchInput('popupFromDt', value);
                      }}
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label={t('admin.AdminMain.NotifyAdmin.regDttm')}
                      pickerType="date"
                      value={popupToDt}
                      onChange={(value) => {
                        changeSearchInput('popupToDt', value);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label={t('ke.safety.policy.label.00002')}
                  value={titleKo}
                  onChange={(value) => {
                    changeSearchInput('titleKo', value);
                  }}
                  search={search}
                />
              </div>
            </div>

            <div className="btn-area df">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                {t('ke.safety.common.label.00002')}
              </button>
              <button
                type="button"
                name="button"
                className="btn-sm btn_text btn-darkblue-line"
                onClick={initSearchInput}
              >
                {t('ke.safety.common.label.00003')}
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* //검색영역 */}
      {/*그리드영역 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
        />
      </div>
      {/*그리드영역 */}
      {/* 하단버튼영역 */}
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
      {/* 하단버튼영역 */}
    </>
  );
}

export default SPIBoardList;
