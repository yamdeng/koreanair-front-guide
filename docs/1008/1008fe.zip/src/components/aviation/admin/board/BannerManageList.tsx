import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
// import AppCodeSelect from '@/components/common/AppCodeSelect';
import { useTranslation } from 'react-i18next';
import AppCodeSelect from '@/components/common/AppCodeSelect';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/board/boardList',
  baseRoutePath: '/aviation/board-manage/banner-manage',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  boardType: '60',
  titleKo: '',
  bannerType: '',
  useYn: '',
};

/* zustand store 생성 */
const AvnBannerManageListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    boardType: '60',
    titleKo: '',
    bannerType: '',
    useYn: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    //set({ ...listBaseState, searchParam: { ...initSearchParam } });
    set(initListData);
  },
}));

function BannerManageList() {
  const { t } = useTranslation();
  const state = AvnBannerManageListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번' },
      { field: 'subjectKoNm', headerName: '제목' },
      { field: 'bannerTypeCd', headerName: '배너구분' },
      { field: 'popupFromDt', headerName: '게시시작일자' },
      { field: 'popupToDt', headerName: '게시종료일자' },
      { field: 'linkKoNm', headerName: '링크' },
      { field: 'useYn', headerName: '사용여부' },
      { field: 'regUserId', headerName: '등록자' },
      { field: 'regDttm', headerName: '등록일' },
      { field: 'updUserId', headerName: '수정자ID' },
      { field: 'updDttm', headerName: '수정일시' },
    ])
  );

  // AvnBannerManageListStore 정의된 메소드 사용 시 이곳에 분해할당
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;

  // input value에 넣기 위한 분리 선언
  const { titleKo, bannerType, useYn } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.boardId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    initSearchInput();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>배너관리</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="제목"
                  value={titleKo}
                  onChange={(value) => {
                    changeSearchInput('titleKo', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid25">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_151"
                  applyAllSelect
                  label={'배너구분'}
                  value={bannerType}
                  onChange={(value) => {
                    changeSearchInput('bannerType', value);
                  }}
                  search={bannerType}
                />
              </div>
            </div>

            <div className="form-cell wid25">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_146"
                  applyAllSelect
                  label={'사용여부'}
                  value={useYn}
                  onChange={(value) => {
                    changeSearchInput('useYn', value);
                  }}
                  search={useYn}
                />
              </div>
            </div>
            <div className="btn-area df">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                {t('ke.safety.common.label.00002')}
              </button>
              <button
                type="button"
                name="button"
                className="btn-sm btn_text btn-darkblue-line"
                onClick={initSearchInput}
              >
                {t('ke.safety.common.label.00003')}
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* //검색영역 */}
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
    </>
  );
}

export default BannerManageList;
