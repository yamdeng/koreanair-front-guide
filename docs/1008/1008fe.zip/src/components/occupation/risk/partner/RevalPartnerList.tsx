import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppNavigation from '@/components/common/AppNavigation';
import AppSearchInput from '@/components/common/AppSearchInput';
// import AppSelect from '@/components/common/AppSelect';
import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import { useCallback, useEffect, useState } from 'react';
import { create } from 'zustand';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';

// /occupation/notice/{id} : 상세
// /occupation/notice/{id}/edit : 폼(등록/수정)

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/risk/partner',
  baseRoutePath: '/occupation/risk/partner',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 작성자
  regUserId: '',
  // 작성기간 FROM
  fromRegDttm: '',
  // 작성기간 TO
  toRegDttm: '',
  // 부문
  prtnrRevalSectCd: '',
  // 부서
  prtnrRevalDeptCd: '',
  // 사업장
  bizPlaceClsCd: '',
  // 평가시기
  prtnrRevalClsCd: '',
  // 평가년도
  prtnrRevalEvalYear: '',
  // 제목
  prtnrRevalTitle: '',
};

/* zustand store 생성 */
const RevalPartnerListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    // 작성자
    regUserId: '',
    // 작성기간 FROM
    fromRegDttm: '',
    // 작성기간 TO
    toRegDttm: '',
    // 부문
    prtnrRevalSectCd: '',
    // 부서
    prtnrRevalDeptCd: '',
    // 사업장
    bizPlaceClsCd: '',
    // 평가시기
    prtnrRevalClsCd: '',
    // 평가년도
    prtnrRevalEvalYear: '',
    // 제목
    prtnrRevalTitle: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function RevalPartnerList() {
  const state = RevalPartnerListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'prtnrREvalEvalYear', headerName: '평가년도', flex: 1 },
      {
        field: 'prtnrREvalClsCd',
        headerName: '평가시기',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC019',
        },
      },

      {
        field: 'prtnrREvalSectCd',
        headerName: '부문',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC001',
        },
      },
      { field: 'prtnrREvalDeptNm', headerName: '부서', flex: 1 },
      { field: 'prtnrNm', headerName: '협력업체', flex: 1 },
      // { field: 'bizPlaceClsCd', headerName: '사업장', flex: 1 },
      {
        field: 'bizPlaceClsCd',
        headerName: '사업장',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC009',
        },
      },
      { field: 'prtnrREvalTitle', headerName: '제목', flex: 1 },
      { field: 'procNm', headerName: 'Excel', flex: 1 },
      { field: 'detailWrkNm', headerName: 'Pdf', flex: 1 },
      { field: 'regUserNm', headerName: '작성자', flex: 1 },
      { field: 'regDttm', headerName: '작성일자', flex: 1 },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    goDetailPage,
    changeSearchInput,
    //initSearchInput,
    // isExpandDetailSearch,
    // toggleExpandDetailSearch,
    clear,
  } = state;
  const {
    // 작성자
    regUserId,
    // 작성기간 FROM
    fromRegDttm,
    // 작성기간 TO
    toRegDttm,
    // 부문
    prtnrRevalSectCd,
    // 부서
    prtnrRevalDeptCd,
    // 사업장
    bizPlaceClsCd,
    // 평가시기
    prtnrRevalClsCd,
    // 평가년도
    prtnrRevalEvalYear,
    // 제목
    prtnrRevalTitle,
  } = searchParam;

  console.log('list===>', list);

  // 그리드 더블 클릭
  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;

    console.log('data===>', data);

    // id
    const detailId = data.prtnrREvalId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>협력사 위험성 평가</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div id="" className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="작성자"
                  value={regUserId}
                  onChange={(value) => {
                    changeSearchInput('regUserId', value);
                  }}
                  search={regUserId}
                />
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label="작성기간"
                      value={fromRegDttm}
                      onChange={(value) => {
                        changeSearchInput('fromRegDttm', value);
                      }}
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label="작성기간"
                      value={toRegDttm}
                      onChange={(value) => {
                        changeSearchInput('toRegDttm', value);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'부문'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC001"
                  value={prtnrRevalSectCd}
                  onChange={(value) => {
                    changeSearchInput('prtnrRevalSectCd', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDeptSelectInput
                  isMultiple={true}
                  label={'부서'}
                  value={prtnrRevalDeptCd}
                  onChange={(deptCd) => {
                    changeSearchInput('prtnrRevalDeptCd', deptCd);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'사업장'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC009"
                  value={bizPlaceClsCd}
                  onChange={(value) => {
                    changeSearchInput('bizPlaceClsCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'평가시기'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC019"
                  value={prtnrRevalClsCd}
                  onChange={(value) => {
                    changeSearchInput('prtnrRevalClsCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDatePicker
                  label={'평가년도'}
                  pickerType="year"
                  value={prtnrRevalEvalYear}
                  onChange={(value) => {
                    changeSearchInput('prtnrRevalEvalYear', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="제목"
                  value={prtnrRevalTitle}
                  onChange={(value) => {
                    changeSearchInput('prtnrRevalTitle', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              검색
            </button>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button type="button" name="button" className="arrow button _control active">
          <span className="hide">접기</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default RevalPartnerList;
