import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
import useOcuHsCommitteeFormStore from '@/stores/occupation/general/useOcuHsCommitteeFormStore';
import AppNavigation from '@/components/common/AppNavigation';

import AppFileAttach from '@/components/common/AppFileAttach';
import { Viewer } from '@toast-ui/react-editor';
import AppEditorViewer from '@/components/common/AppEditorViewer';
/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuHsCommitteeDetail() {
  /* formStore state input 변수 */
  const { detailInfo, getDetail, formType, cancel, goFormPage, clear } = useOcuHsCommitteeFormStore();
  const {
    // 본부
    advCmitSectNm,
    // 부서
    advCmitDeptNm,
    // 팀
    advCmitTeamNm,
    // 그룹
    advCmitGroupNm,

    // 작성자
    regUserNm,
    // 작성일자
    regDttm,
    // 해당연월
    advCmitImplmYm,
    // 제목
    advCmitTitle,
    // 내용
    advCmitRemark,
    // 회의록
    prcdnFileId,
    // 회의자료
    meetDocFileId,
    // 보고문서
    //reportDocLinkId,
    linkAttachList,
  } = detailInfo;

  console.log('조회된값===>', detailInfo);

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>안전보건협의체</h2>
      </div>
      {/*상세페이지*/}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부문</label>
                    <span className="text-desc-type1">{advCmitSectNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부서</label>
                    <span className="text-desc-type1">{advCmitDeptNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">팀</label>
                    <span className="text-desc-type1">{advCmitTeamNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">그룹</label>
                    <span className="text-desc-type1">{advCmitGroupNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성자</label>
                    <span className="text-desc-type1">{regUserNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성일자</label>
                    <span className="text-desc-type1">{regDttm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">해당연월</label>
                    <span className="text-desc-type1">{advCmitImplmYm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">제목</label>
                    <span className="text-desc-type1">{advCmitTitle}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  {/* <li className="accumlate-list"> */}
                  <label className="t-label">비고</label>
                  <span className="text-desc-type1">
                    <AppEditorViewer value={advCmitRemark} />
                  </span>
                  {/* </li> */}
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">회의록(pdf, 그림 파일)</label>
                    <span className="text-desc-type1">
                      <AppFileAttach
                        mode="view"
                        fileGroupSeq={prcdnFileId}
                        workScope={'O'}
                        // onlyImageUpload={true}
                        useDetail
                        disabled
                      />
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">회의자료(ppt)</label>
                    <span className="text-desc-type1">
                      <AppFileAttach
                        mode="view"
                        fileGroupSeq={meetDocFileId}
                        workScope={'O'}
                        // onlyImageUpload={true}
                        useDetail
                        disabled
                      />
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">보고문서(Link)</label>
                    {linkAttachList
                      ? linkAttachList.map((linkInfo, linkAttachListLindex) => {
                          const { linkUrl, linkSbj } = linkInfo;
                          return (
                            <span key={linkUrl} className="text-desc-type2">
                              <a href={linkUrl} target="_blank">
                                {linkSbj}
                              </a>
                            </span>
                          );
                        })
                      : null}
                    {/* {linkAttachList.map((attachInfo) => {
                      const { linkUrl, linkSbj } = attachInfo;
                      return (
                        <span key={linkUrl} className="text-desc-type2">
                          <a href={linkUrl} target="_blank">
                            {linkSbj}
                          </a>
                        </span>
                      );
                    })} */}
                    {/* <span className="text-desc-type2">
                      <a href="javascript:void(0);">첨부파일링크링크</a>
                    </span>
                    <span className="text-desc-type2">
                      <a href="javascript:void(0);">첨부파일</a>
                    </span> */}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goFormPage}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          수정
        </button>
      </div>
    </>
  );
}
export default OcuHsCommitteeDetail;
