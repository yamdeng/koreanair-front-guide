import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';
import AppTextInput from '@/components/common/AppTextInput';

const formName = 'OcuEnvMeasureForm';

/* yup validation */
const yupFormSchema = yup.object({
  msrId: yup.number().required(),
  msrYear: yup.string().required(),
  halfYearCd: yup.string().required(),
  msrClsCd: yup.string().required(),
  areaCd: yup.string().required(),
  msrStartDt: yup.string().required(),
  msrEndDt: yup.string().required(),
  msrInstt: yup.string().required(),
  msrResult: yup.string().required(),
  opnn: yup.string(),
  resultFileId: yup.number(),
  chmclFileId: yup.number(),
  regDttm: yup.string().required(),
  regUserId: yup.string().required(),
  updDttm: yup.string().required(),
  updUserId: yup.string().required(),
});

/* form 초기화 */
const initFormValue = {
  msrId: null,
  msrYear: "",
  halfYearCd: "",
  msrClsCd: "",
  areaCd: "",
  msrStartDt: "",
  msrEndDt: "",
  msrInstt: "",
  msrResult: "",
  opnn: "",
  resultFileId: null,
  chmclFileId: null,
  regDttm: "",
  regUserId: "",
  updDttm: "",
  updUserId: "",
};

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuEnvMeasureFormModal(props) {

  const { isOpen, closeModal, detailInfo, ok } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});
  const [isDirty, setIsDirty] = useState(false);

  const {  msrId, msrYear, halfYearCd, msrClsCd, areaCd, msrStartDt, msrEndDt, msrInstt, msrResult, opnn, resultFileId, chmclFileId, regDttm, regUserId, updDttm, updUserId, } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
    setIsDirty(true);
  };

  const save = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;
    if (success) {
      // TODO : 모달 최종 저장시 액션 정의
      ok(formValue);
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  useEffect(() => {
    // TODO : isOpen일 경우에 상세 api 호출 할지 결정 : if(isOpen)
    if (isOpen) {
      if (detailInfo) {
        setFormValue(detailInfo);
      } else {
        setFormValue({ ...initFormValue });
      }
    }
  }, [isOpen, detailInfo]);

  return (
    <>
      <Modal
        shouldCloseOnOverlayClick={false}
        isOpen={isOpen}
        ariaHideApp={false}
        overlayClassName={'alert-modal-overlay'}
        className={'list-common-modal-content'}
        onRequestClose={() => {
          closeModal();
        }}
      >
        <div className="popup-container">
          <h3 className="pop_title">TODO : 모달 타이틀</h3>
          <div className="pop_full_cont_box">
            <div className="pop_flex_group">
              <div className="pop_cont_form">
                <div className="editbox">
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          inputType="number"
                          id="OcuEnvMeasureFormmsrId"
                          name="msrId"
                          label="측정_ID"
                          value={msrId}
                          onChange={(value) => changeInput('msrId', value)}
                          errorMessage={errors.msrId}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormmsrYear"
                          name="msrYear"
                          label="측정_년도"
                          value={msrYear}
                          onChange={(value) => changeInput('msrYear', value)}
                          errorMessage={errors.msrYear}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormhalfYearCd"
                          name="halfYearCd"
                          label="반기_코드"
                          value={halfYearCd}
                          onChange={(value) => changeInput('halfYearCd', value)}
                          errorMessage={errors.halfYearCd}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormmsrClsCd"
                          name="msrClsCd"
                          label="측정_구분_코드"
                          value={msrClsCd}
                          onChange={(value) => changeInput('msrClsCd', value)}
                          errorMessage={errors.msrClsCd}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormareaCd"
                          name="areaCd"
                          label="권역_코드"
                          value={areaCd}
                          onChange={(value) => changeInput('areaCd', value)}
                          errorMessage={errors.areaCd}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormmsrStartDt"
                          name="msrStartDt"
                          label="측정_시작_일자"
                          value={msrStartDt}
                          onChange={(value) => changeInput('msrStartDt', value)}
                          errorMessage={errors.msrStartDt}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormmsrEndDt"
                          name="msrEndDt"
                          label="측정_종료_일자"
                          value={msrEndDt}
                          onChange={(value) => changeInput('msrEndDt', value)}
                          errorMessage={errors.msrEndDt}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormmsrInstt"
                          name="msrInstt"
                          label="측정_기관"
                          value={msrInstt}
                          onChange={(value) => changeInput('msrInstt', value)}
                          errorMessage={errors.msrInstt}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormmsrResult"
                          name="msrResult"
                          label="측정_결과"
                          value={msrResult}
                          onChange={(value) => changeInput('msrResult', value)}
                          errorMessage={errors.msrResult}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormopnn"
                          name="opnn"
                          label="의견"
                          value={opnn}
                          onChange={(value) => changeInput('opnn', value)}
                          errorMessage={errors.opnn}
                          
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          inputType="number"
                          id="OcuEnvMeasureFormresultFileId"
                          name="resultFileId"
                          label="결과_첨부_파일_ID"
                          value={resultFileId}
                          onChange={(value) => changeInput('resultFileId', value)}
                          errorMessage={errors.resultFileId}
                          
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          inputType="number"
                          id="OcuEnvMeasureFormchmclFileId"
                          name="chmclFileId"
                          label="화학_첨부_파일_ID"
                          value={chmclFileId}
                          onChange={(value) => changeInput('chmclFileId', value)}
                          errorMessage={errors.chmclFileId}
                          
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormregDttm"
                          name="regDttm"
                          label="등록_일시"
                          value={regDttm}
                          onChange={(value) => changeInput('regDttm', value)}
                          errorMessage={errors.regDttm}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormregUserId"
                          name="regUserId"
                          label="등록자_ID"
                          value={regUserId}
                          onChange={(value) => changeInput('regUserId', value)}
                          errorMessage={errors.regUserId}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormupdDttm"
                          name="updDttm"
                          label="수정_일시"
                          value={updDttm}
                          onChange={(value) => changeInput('updDttm', value)}
                          errorMessage={errors.updDttm}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuEnvMeasureFormupdUserId"
                          name="updUserId"
                          label="수정자_ID"
                          value={updUserId}
                          onChange={(value) => changeInput('updUserId', value)}
                          errorMessage={errors.updUserId}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                </div>
              </div>
            </div>
          </div>
          {/* 하단 버튼 영역 */}
          <div className="pop_btns">
            <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
              취소
            </button>
            <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
              확인
            </button>
          </div>
          <span className="pop_close" onClick={closeModal}>
            X
          </span>
        </div>
      </Modal>
    </>
  );
}
export default OcuEnvMeasureFormModal;
