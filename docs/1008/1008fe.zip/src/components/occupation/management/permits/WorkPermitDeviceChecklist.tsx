import { useEffect } from 'react';
import AppTextInput from '@/components/common/AppTextInput';
import AppFileAttach from '@/components/common/AppFileAttach';
import useOcuWorkPermitFormStore from '@/stores/occupation/management/useOcuWorkPermitFormStore';
import useOcuWorkPermitDeviceChecklistFormStore from '@/stores/occupation/management/useOcuWorkPermitDeviceChecklistStore';

function WorkPermitDeviceChecklist(props) {
  const { updateEquipmentList } = props;
  const {
    changeInput,
    formValue,
    setFormValue,
    selectedWork,
    setSelectedWork,
    selectedDevice,
    changeSelectedDevice,
    equipmentCheckList,
    changeSelectedWork,
    updateImportEqpmNm,
    updateFileId,
  } = useOcuWorkPermitDeviceChecklistFormStore();

  const {
    // 공사 작업코드
    cntrWrkCd,
    // 반입장비코드
    imprtEqpmCd,
    // 파일ID
    fileId,
    // 수기입력
    importEqpmNm,
  } = formValue;

  const handleParentClick = (event) => {
    const { name, checked } = event.target;

    setSelectedWork(name, checked);
    console.log(`Parent checkbox ${name} is now ${checked}`);
    changeSelectedWork(name, checked);
    // selectedDevice 상태 업데이트
    if (name === 'S') {
      changeSelectedDevice('S', 'S1', checked);
    }
  };

  const handleValueChange = (event) => {
    const { name, value, checked } = event.target;

    changeSelectedDevice(name, value, checked);
  };

  useEffect(() => {
    console.log('Currently selected work:', selectedWork);
    console.log('selectedDevice has changed:', selectedDevice);
    console.log('Current equipmentCheckList:', formValue.equipmentCheckList);
  }, [selectedWork, selectedDevice, formValue.equipmentCheckList]);

  return (
    <div className="form-table">
      <div className="form-cell wid50">
        <div className="form-group wid100">
          <h3 className="table-tit">작업 구분</h3>
          <div className="work-group">
            <table className="work-table">
              <thead>
                <tr>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input type="checkbox" checked />
                        <span className="type02">공통(일반)</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input type="checkbox" name="S" checked={selectedWork.S} onClick={handleParentClick} />
                        <span className="type02">밀폐공간작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input type="checkbox" name="E" onClick={handleParentClick} checked={selectedWork.E} />
                        <span className="type02">전기작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input type="checkbox" name="F" onClick={handleParentClick} checked={selectedWork.F} />
                        <span className="type02">화재위험작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input type="checkbox" name="H" onClick={handleParentClick} checked={selectedWork.H} />
                        <span className="type02">고소작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input type="checkbox" name="R" onClick={handleParentClick} checked={selectedWork.R} />
                        <span className="type02">줄걸이작업</span>
                      </label>
                    </div>
                  </th>
                  <th>
                    <div className="radio-wrap-type02">
                      <label className="type02">
                        <input type="checkbox" name="C" onClick={handleParentClick} />
                        <span className="type02">건설기계 사용작업</span>
                      </label>
                    </div>
                  </th>
                </tr>
              </thead>
              {/* The start point of 2nd Chceckbox area */}
              <tbody>
                <tr>
                  <td colSpan={7}>
                    {/* 밀폐공간작업선택 - active */}
                    <div className={`work-ck-list ${selectedWork.S ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th>밀폐공간작업</th>
                          <td>해당사항없음</td>
                          <td>{/* <input type="hidden" name="S" value="S" /> */}</td>
                        </tr>
                      </table>
                    </div>
                    {/* 전기작업선택 - active */}
                    <div className={`work-ck-list ${selectedWork.E ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th>전기작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="E"
                                  value="E1"
                                  checked={selectedDevice.E.E1.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">
                                  고압 전기작업 (1,500~7,000V 직류전압 또는 1,000~7,000V 교류전압)
                                </span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                      </table>
                    </div>

                    {/* 화재위험작업선택 */}
                    <div className={`work-ck-list ${selectedWork.F ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th rowSpan={3}>화재위험작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="F"
                                  value="F1"
                                  checked={selectedDevice.F.F1.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">가스 용접·용단작업</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="F"
                                  value="F2"
                                  checked={selectedDevice.F.F2.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">전기 용접작업</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="F"
                                  value="F3"
                                  checked={selectedDevice.F.F3.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">연삭기 사용작업</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                      </table>
                    </div>

                    {/* 고소 작업선택 */}
                    <div className={`work-ck-list ${selectedWork.H ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th rowSpan={4}>고소 작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="H"
                                  value="H1"
                                  checked={selectedDevice.H.H1.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">이동식 사다리</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="H"
                                  value="H2"
                                  checked={selectedDevice.H.H2.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">달비계</span>
                              </label>
                            </div>
                          </td>
                          <td></td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="H"
                                  value="H3"
                                  checked={selectedDevice.H.H3.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">시저형 고소작업대(렌탈)</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={selectedDevice.H.H3.fileId}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      updateFileId('H', 'H3', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">- 안전인증서</span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="H"
                                  value="H4"
                                  checked={selectedDevice.H.H4.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">차량탑재형 고소작업대(스카이차)</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={selectedDevice.H.H4.fileId}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      updateFileId('H', 'H4', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 자동차등록증 - 안전검사합격증명서 - 기능기운전기능사 또는 교육기관 교육 이수 - 화물운전
                              종사 자격증
                            </span>
                          </td>
                        </tr>
                      </table>
                    </div>

                    {/* 줄걸이 작업선택 */}
                    <div className={`work-ck-list ${selectedWork.R ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th rowSpan={2}>줄걸이 작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="R"
                                  value="R1"
                                  checked={selectedDevice.R.R1.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">기중기(건설기계)</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={selectedDevice.R.R1.fileId}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      updateFileId('R', 'R1', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 건설기계등록증 - 건설기계조종사 면허증 - 건설기계조종사 안전교육 이수증
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="R"
                                  value="R2"
                                  checked={selectedDevice.R.R2.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">차량탑재형 이동식크레인(카고크레인)</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={selectedDevice.R.R2.fileId}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      updateFileId('R', 'R2', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 자동차등록증 - 안전검사합격증명서 - 기능기운전기능사 또는 교육기관 교육 이수 - 화물운전
                              종사 자격증
                            </span>
                          </td>
                        </tr>
                      </table>
                    </div>
                    {/* 건설기계 작업선택 */}
                    <div className={`work-ck-list ${selectedWork.C ? 'active' : ''}`}>
                      <table>
                        <tr>
                          <th rowSpan={3}>건설기계 사용 작업</th>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="C"
                                  value="C1"
                                  checked={selectedDevice.C.C1.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">굴착기</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={selectedDevice.C.C1.fileId}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      updateFileId('C', 'C1', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 건설기계등록증 - 건설기계조종사 면허증 - 건설기계조종사 안전교육 이수증
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="C"
                                  value="C2"
                                  checked={selectedDevice.C.C2.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">지게차</span>
                              </label>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={selectedDevice.C.C2.fileId}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      updateFileId('C', 'C2', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                            <span className="file-guide">
                              - 건설기계등록증 - 건설기계조종사 면허증 - 건설기계조종사 안전교육 이수증
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div className="radio-wrap-type02">
                              <label className="type02">
                                <input
                                  type="checkbox"
                                  name="C"
                                  value="C3"
                                  checked={selectedDevice.C.C3.checked}
                                  onChange={handleValueChange}
                                />
                                <span className="type02">수기 입력 : </span>
                              </label>
                            </div>
                            <div className="form-cell wid100 border-b-no">
                              <div className="form-group wid100">
                                <AppTextInput
                                  label="수기입력"
                                  value={selectedDevice.C.C3.importEqpmNm}
                                  onChange={(value) => {
                                    updateImportEqpmNm('C', 'C3', value);
                                  }}
                                />
                              </div>
                            </div>
                          </td>
                          <td>
                            <div className="form-table">
                              <div className="form-cell wid50 border-b-no">
                                <div className="form-group wid100">
                                  <AppFileAttach
                                    mode="edit"
                                    label="첨부파일"
                                    fileGroupSeq={selectedDevice.C.C3.fileId}
                                    workScope={'O'}
                                    updateFileGroupSeq={(newFileGroupSeq) => {
                                      updateFileId('C', 'C3', newFileGroupSeq);
                                    }}
                                  />
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </table>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            <span className="link-txt">
              <a href={undefined}>※ 첨부 파일 안내문 (Link)</a>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
export default WorkPermitDeviceChecklist;
