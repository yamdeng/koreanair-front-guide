import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import WorkPermitLocationRegisterModal from './WorkPermitLocationRegisterModal';
import OcuWorkPermitApprovalStore from '@/stores/occupation/management/useOcuWorkPermitApprovalStore';
const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/management/permits',
  baseRoutePath: '/occupation/management/permits',
};

/* zustand store 생성 */
const OcuOutSourcingListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  // // 날짜검색용 초기 값
  // duration: ['', ''],

  // // initSearchInput: () => {
  // //   set({
  // //     searchParam: {
  // //       ...initSearchParam,
  // //     },
  // //   });
  // //   // 기간 검색용 날짜 추가 for AppRangeDatePicker
  // //   set({ duration: [currentDate, currentDate] });
  // // },

  clear: () => {},
}));

function WorkPermitApproval() {
  const state = OcuOutSourcingListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'cntrLocationNm', headerName: '공사장소' },
      { field: 'cntrPositionNm', headerName: '공사위치' },
      { field: 'cntrAreaNm', headerName: '공사분야' },
      { field: 'cnstCmpny', headerName: '작업구분' },
      { field: 'cntrNm', headerName: '공사명' },
      {
        field: 'cntrApplyStartDttm',
        headerName: '공사기간',
        valueGetter: (p) => p.data.cntrApplyStartDttm + ' ~ ' + p.data.cntrApplyEndDttm,
      },
      { field: 'regUserId', headerName: '신청자' },
      { field: 'applyStatusNm', headerName: '신청상태' },
      { field: 'wrkStatusNm', headerName: '작업상태' },
      // NEED TO ADD LATER -
      { field: 'fileId', headerName: '작업처리' },
    ])
  );
  const { isLocationRegisterModalOpen, openLocationRegisterModal, closeLocationRegisterModal } =
    OcuWorkPermitApprovalStore();
  const { enterSearch, list, goAddPage, clear, goDetailPage } = state;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.cntrId;
    goDetailPage(detailId);
  }, []);

  const handleModalClick = () => {
    // Set the modal to open
    openLocationRegisterModal({ isLocationRegisterModalOpen: true });
  };

  useEffect(() => {
    if (isLocationRegisterModalOpen) {
      console.log('Modal is now open:', isLocationRegisterModalOpen);
    } else {
      console.log('Modal is now closed:', isLocationRegisterModalOpen);
    }
  }, [isLocationRegisterModalOpen]);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  const customButtons = [
    {
      title: '공사장소관리',
      onClick: () => {
        handleModalClick();
      },
    },
    {
      title: '등록',
      onClick: () => {
        // alert('등록 STILL WORKING ON IT.');
        goAddPage();
      },
    },
  ];

  return (
    <>
      <div className="conts-title">
        <h2>외주작업 신청 현황</h2>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
        customButtons={customButtons}
      />
      {isLocationRegisterModalOpen && (
        <WorkPermitLocationRegisterModal isOpen={isLocationRegisterModalOpen} closeModal={closeLocationRegisterModal} />
      )}
    </>
  );
}

export default WorkPermitApproval;
