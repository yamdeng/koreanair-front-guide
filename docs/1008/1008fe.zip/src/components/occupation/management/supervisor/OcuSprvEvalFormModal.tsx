import { useEffect, useState } from 'react';
import Modal from 'react-modal';
import * as yup from 'yup';
import { useImmer } from 'use-immer';
import CommonUtil from '@/utils/CommonUtil';
import AppTextInput from '@/components/common/AppTextInput';

const formName = 'OcuSprvEvalForm';

/* yup validation */
const yupFormSchema = yup.object({
  mgntSprvEvalId: yup.number().required(),
  sectCd: yup.string(),
  deptCd: yup.string(),
  evalYear: yup.string(),
  qrtrYearCd: yup.string(),
  title: yup.string(),
  evalSubjEmpno: yup.string(),
  evalEmpno: yup.string(),
  fileId: yup.number(),
  linkId: yup.number(),
  remark: yup.string(),
  regDttm: yup.string().required(),
  regUserId: yup.string().required(),
  updDttm: yup.string().required(),
  updUserId: yup.string().required(),
});

/* form 초기화 */
const initFormValue = {
  mgntSprvEvalId: null,
  sectCd: "",
  deptCd: "",
  evalYear: "",
  qrtrYearCd: "",
  title: "",
  evalSubjEmpno: "",
  evalEmpno: "",
  fileId: null,
  linkId: null,
  remark: "",
  regDttm: "",
  regUserId: "",
  updDttm: "",
  updUserId: "",
};

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuSprvEvalFormModal(props) {

  const { isOpen, closeModal, detailInfo, ok } = props;
  const [formValue, setFormValue] = useImmer({ ...initFormValue });
  const [errors, setErrors] = useState<any>({});
  const [isDirty, setIsDirty] = useState(false);

  const {  mgntSprvEvalId, sectCd, deptCd, evalYear, qrtrYearCd, title, evalSubjEmpno, evalEmpno, fileId, linkId, remark, regDttm, regUserId, updDttm, updUserId, } = formValue;

  const changeInput = (inputName, inputValue) => {
    setFormValue((formValue) => {
      formValue[inputName] = inputValue;
    });
    setIsDirty(true);
  };

  const save = async () => {
    const validateResult = await CommonUtil.validateYupForm(yupFormSchema, formValue);
    const { success, firstErrorFieldKey, errors } = validateResult;
    if (success) {
      // TODO : 모달 최종 저장시 액션 정의
      ok(formValue);
    } else {
      setErrors(errors);
      if (formName + firstErrorFieldKey) {
        document.getElementById(formName + firstErrorFieldKey).focus();
      }
    }
  };

  useEffect(() => {
    // TODO : isOpen일 경우에 상세 api 호출 할지 결정 : if(isOpen)
    if (isOpen) {
      if (detailInfo) {
        setFormValue(detailInfo);
      } else {
        setFormValue({ ...initFormValue });
      }
    }
  }, [isOpen, detailInfo]);

  return (
    <>
      <Modal
        shouldCloseOnOverlayClick={false}
        isOpen={isOpen}
        ariaHideApp={false}
        overlayClassName={'alert-modal-overlay'}
        className={'list-common-modal-content'}
        onRequestClose={() => {
          closeModal();
        }}
      >
        <div className="popup-container">
          <h3 className="pop_title">TODO : 모달 타이틀</h3>
          <div className="pop_full_cont_box">
            <div className="pop_flex_group">
              <div className="pop_cont_form">
                <div className="editbox">
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          inputType="number"
                          id="OcuSprvEvalFormmgntSprvEvalId"
                          name="mgntSprvEvalId"
                          label="관리감독자평가_ID"
                          value={mgntSprvEvalId}
                          onChange={(value) => changeInput('mgntSprvEvalId', value)}
                          errorMessage={errors.mgntSprvEvalId}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormsectCd"
                          name="sectCd"
                          label="부문_코드"
                          value={sectCd}
                          onChange={(value) => changeInput('sectCd', value)}
                          errorMessage={errors.sectCd}
                          
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormdeptCd"
                          name="deptCd"
                          label="부서_코드"
                          value={deptCd}
                          onChange={(value) => changeInput('deptCd', value)}
                          errorMessage={errors.deptCd}
                          
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormevalYear"
                          name="evalYear"
                          label="평가년도"
                          value={evalYear}
                          onChange={(value) => changeInput('evalYear', value)}
                          errorMessage={errors.evalYear}
                          
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormqrtrYearCd"
                          name="qrtrYearCd"
                          label="분기_코드"
                          value={qrtrYearCd}
                          onChange={(value) => changeInput('qrtrYearCd', value)}
                          errorMessage={errors.qrtrYearCd}
                          
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormtitle"
                          name="title"
                          label="제목"
                          value={title}
                          onChange={(value) => changeInput('title', value)}
                          errorMessage={errors.title}
                          
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormevalSubjEmpno"
                          name="evalSubjEmpno"
                          label="피평가자_사번"
                          value={evalSubjEmpno}
                          onChange={(value) => changeInput('evalSubjEmpno', value)}
                          errorMessage={errors.evalSubjEmpno}
                          
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormevalEmpno"
                          name="evalEmpno"
                          label="평가자_사번"
                          value={evalEmpno}
                          onChange={(value) => changeInput('evalEmpno', value)}
                          errorMessage={errors.evalEmpno}
                          
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          inputType="number"
                          id="OcuSprvEvalFormfileId"
                          name="fileId"
                          label="첨부_파일_ID"
                          value={fileId}
                          onChange={(value) => changeInput('fileId', value)}
                          errorMessage={errors.fileId}
                          
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          inputType="number"
                          id="OcuSprvEvalFormlinkId"
                          name="linkId"
                          label="첨부_링크_ID"
                          value={linkId}
                          onChange={(value) => changeInput('linkId', value)}
                          errorMessage={errors.linkId}
                          
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormremark"
                          name="remark"
                          label="비고"
                          value={remark}
                          onChange={(value) => changeInput('remark', value)}
                          errorMessage={errors.remark}
                          
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormregDttm"
                          name="regDttm"
                          label="등록_일시"
                          value={regDttm}
                          onChange={(value) => changeInput('regDttm', value)}
                          errorMessage={errors.regDttm}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormregUserId"
                          name="regUserId"
                          label="등록자_ID"
                          value={regUserId}
                          onChange={(value) => changeInput('regUserId', value)}
                          errorMessage={errors.regUserId}
                          required
                        />              
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormupdDttm"
                          name="updDttm"
                          label="수정_일시"
                          value={updDttm}
                          onChange={(value) => changeInput('updDttm', value)}
                          errorMessage={errors.updDttm}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line dp-n"></hr>
                  
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          id="OcuSprvEvalFormupdUserId"
                          name="updUserId"
                          label="수정자_ID"
                          value={updUserId}
                          onChange={(value) => changeInput('updUserId', value)}
                          errorMessage={errors.updUserId}
                          required
                        />              
                      </div>
                    </div>
                  </div>
                  <hr className="line"></hr>
                  
                </div>
              </div>
            </div>
          </div>
          {/* 하단 버튼 영역 */}
          <div className="pop_btns">
            <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
              취소
            </button>
            <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
              확인
            </button>
          </div>
          <span className="pop_close" onClick={closeModal}>
            X
          </span>
        </div>
      </Modal>
    </>
  );
}
export default OcuSprvEvalFormModal;
