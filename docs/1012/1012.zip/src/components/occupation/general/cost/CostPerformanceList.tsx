import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import ApiService from '@/services/ApiService';
import ModalService from '@/services/ModalService';
import ToastService from '@/services/ToastService';
import _ from 'lodash';
import CostList from '@/components/occupation/general/cost/CostList';

import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
import AppTextInput from '@/components/common/AppTextInput';
import AppSelect from '@/components/common/AppSelect';
import CostExecFormModal from '@/components/modal/occupation/CostExecFormModal ';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';

import {
  useOcuCostPerformanceListStore,
  stateAcntTotStore,
  stateAcntListStore,
} from '@/stores/occupation/general/useOcuCostPerformanceListStore';

import history from '@/utils/history';

function OcuCostExecList() {
  const state = useOcuCostPerformanceListStore();
  const stateAcntTot = stateAcntTotStore();
  const stateAcntList = stateAcntListStore();

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'acntCd', headerName: '계정', flex: 1 },
      {
        field: 'acntCd',
        headerName: '계정명',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC045',
        },
      },

      { field: 'planSum', headerName: '합계(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costSum', headerName: '합계(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'totSum', headerName: '합계(실적비)', flex: 1 },
      { field: 'planMon01', headerName: '1월(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costMon01', headerName: '1월(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'ratioTot01', headerName: '1월(실적비)', flex: 1 },
      { field: 'planMon02', headerName: '2월(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costMon02', headerName: '2월(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'ratioTot02', headerName: '2월(실적비)', flex: 1 },

      { field: 'planMon03', headerName: '3월(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costMon03', headerName: '3월(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'ratioTot03', headerName: '3월(실적비)', flex: 1 },

      { field: 'planMon04', headerName: '4월(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costMon04', headerName: '4월(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'ratioTot04', headerName: '4월(실적비)', flex: 1 },

      { field: 'planMon05', headerName: '5월(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costMon05', headerName: '5월(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'ratioTot05', headerName: '5월(실적비)', flex: 1 },

      { field: 'planMon06', headerName: '6월(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costMon06', headerName: '6월(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'ratioTot06', headerName: '6월(실적비)', flex: 1 },

      { field: 'planMon07', headerName: '7월(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costMon07', headerName: '7월(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'ratioTot07', headerName: '7월(실적비)', flex: 1 },

      { field: 'planMon08', headerName: '8월(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costMon08', headerName: '8월(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'ratioTot08', headerName: '8월(실적비)', flex: 1 },

      { field: 'planMon09', headerName: '9월(계획)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'costMon09', headerName: '9월(실적)', flex: 1, valueFormatter: (p) => Number(p.value).toLocaleString() },
      { field: 'ratioTot09', headerName: '9월(실적비)', flex: 1 },

      {
        field: 'planMon10',
        headerName: '10월(계획)',
        flex: 1,
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
      {
        field: 'costMon10',
        headerName: '10월(실적)',
        flex: 1,
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
      { field: 'ratioTot10', headerName: '10월(실적비)', flex: 1 },

      {
        field: 'planMon11',
        headerName: '11월(계획)',
        flex: 1,
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
      {
        field: 'costMon11',
        headerName: '11월(실적)',
        flex: 1,
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
      { field: 'ratioTot11', headerName: '11월(실적비)', flex: 1 },

      {
        field: 'planMon12',
        headerName: '12월(계획)',
        flex: 1,
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
      {
        field: 'costMon12',
        headerName: '12월(실적)',
        flex: 1,
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
      { field: 'ratioTot12', headerName: '12월(실적비)', flex: 1 },
    ])
  );

  const [columns2, setColumns2] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      // { field: 'execYear', headerName: '년도' },
      { field: 'execClsNm', headerName: '구분' },
      { field: 'invoiceDt', headerName: '일자' },
      { field: 'costCenterNm', headerName: '사용부서' },
      { field: 'acntCd', headerName: '계정' },
      { field: 'acntNm', headerName: '계정명' },
      { field: 'invoiceNo', headerName: '전표번호' },
      { field: 'drCrTotAmt', headerName: '금액' },
      { field: 'vendorNm', headerName: '거래처' },
      { field: 'glDt', headerName: '처리일자' },
      { field: 'lineDesc', headerName: '내용' },
    ])
  );

  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    //initSearchInput,
    //isExpandDetailSearch,
    //toggleExpandDetailSearch,
    clear,
    search,
    goDetailPage,
    openFormModal,
    isCodeFormModalOpen,
    closeFormModal,
    okModal,
    // 저장 구분 값
    // saveGubun,
    //selectRespCenter
  } = state;

  // TODO : 검색 파라미터 나열
  const { costYear, sectCd, costCenter, acntCd, itemCd } = searchParam;

  // 부문별
  const handleRowSingleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;

    console.log('data1==> ', data);

    const keyData = {
      // 년도
      costYear: data.costYear,
      // 부문
      sectCd: data.sectCd,
      // Cost Center
      deptGubun: data.deptGubun,
      // Account
      acntCd: data.acntCd,
    };

    // 계정 항목 List 조회
    stateAcntList.search(keyData);
  }, []);

  // // Resp Center
  // const handleRowSingleClick2 = useCallback((selectedInfo) => {
  //   const data = selectedInfo.data;

  //   console.log('data2==> ', data);

  //   const keyData = {
  //     // 년도
  //     planYear: data.planYear,
  //     // 부문
  //     sectCd: data.sectCd,
  //     // Resp Center
  //     respCenter: data.respCenter,
  //     // Account
  //     acntCd: data.acntCd,
  //   };

  //   // 어카운트별 실적 조회
  //   stateExec.search(keyData, 'C');
  // }, []);

  // const handleRowSingleClick3 = useCallback((selectedInfo) => {
  //   const data = selectedInfo.data;

  //   console.log('data3==> ', data);

  //   // 년도, 부문, 부서, account, Item
  //   // const keyData = {
  //   //   planYear: data.planYear,
  //   //   sectCd: data.sectCd,
  //   //   respCenter: data.respCenter,
  //   //   itemCd: data.itemCd,
  //   //   acntCd: data.acntCd,
  //   // };
  // }, []);

  useEffect(() => {
    state.search('C');
    //useOcuCostListStore.search();
    return clear;
  }, []);

  const changeCostTap = () => {
    history.push('costState');
  };

  const changeCostListTap = () => {
    history.push('costList');
  };

  // 산업안전보건 관리비 실적 등록
  const costExecInsert = () => {
    console.log('오픈모달');
    openFormModal('I');
  };

  // 그리드 더블 클릭
  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    data.sectCd = sectCd;

    console.log('data==>', data);
    // 실적 등록 팝업
    openFormModal('U', data);
  }, []);

  return (
    <>
      {/* <AppNavigation /> */}
      <div className="Breadcrumb">홈 / 안전경영 / 산업안전보건 관리비</div>
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>산업안전보건관리비 실적</h2>
      </div>
      {/*탭 */}
      <div className="menu-tab-nav">
        <div className="menu-tab">
          <a href={undefined} data-label="현황" onClick={changeCostTap}>
            현황
          </a>
          <a href={undefined} data-label="계획" onClick={changeCostListTap}>
            계획
          </a>
          <a href={undefined} data-label="실적" className="active">
            실적
          </a>
        </div>
      </div>
      {/*//탭 */}
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDatePicker
                  label={'년도'}
                  pickerType="year"
                  value={costYear}
                  onChange={(value) => {
                    changeSearchInput('costYear', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="부문"
                  // applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC001"
                  value={sectCd}
                  onChange={(value) => {
                    changeSearchInput('sectCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSelect
                  label="Cost Center"
                  value={costCenter}
                  apiUrl={`ocu/general/lawRegInfo/selectLawDeptList`}
                  labelKey="nameKor"
                  valueKey="deptCd"
                  onChange={(value) => {
                    changeSearchInput('costCenter', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label="Account Name"
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC045"
                  value={acntCd}
                  onChange={(value) => {
                    changeSearchInput('acntCd', value);
                  }}
                />
              </div>
            </div>
            <div className="btn-area">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={search}>
                조회
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* //검색영역 */}
      {/*그리드영역 */}

      <div className="table-wrap">
        <div className="left-table">
          <AppTable
            rowData={stateAcntTot.list}
            columns={columns}
            className="h300"
            store={stateAcntTot}
            handleRowSingleClick={handleRowSingleClick}
            hiddenPagination
          />
        </div>
        {/* <div className="right-table">
          <AppTable
            rowData={stateRespCenter.list}
            columns={columns2}
            className="h300"
            store={stateRespCenter}
            handleRowSingleClick={handleRowSingleClick2}
            hiddenPagination
          />
        </div> */}
      </div>
      <AppTable
        rowData={stateAcntList.list}
        columns={columns2}
        store={stateAcntList}
        handleRowDoubleClick={handleRowDoubleClick}
        hiddenPagination
      />

      <CostExecFormModal isOpen={isCodeFormModalOpen} closeModal={closeFormModal} ok={okModal} />

      {/*//그리드영역 */}
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={costExecInsert}
        >
          신규
        </button>
      </div>
    </>
  );
}

export default OcuCostExecList;
