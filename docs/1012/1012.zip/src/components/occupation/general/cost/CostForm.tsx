import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
// import CostExecFormModal from '@/components/modal/occupation/CostExecFormModal ';
import CommonUtil from '@/utils/CommonUtil';
import { useCallback, useEffect, useState } from 'react';
import AppTextArea from '@/components/common/AppTextArea';
import { useParams, useSearchParams } from 'react-router-dom';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDeptListSelectInput from '@/components/common/AppDeptListSelectInput';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';

/* TODO : store 경로를 변경해주세요. */
import useOcuCostFormStore from '@/stores/occupation/general/useOcuCostFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuCostDetail() {
  /* formStore state input 변수 */
  const {
    formValue,
    getDetail,
    cancel,
    goFormPage,
    openFormModal,
    clear,
    list,
    search,
    errors,
    changeInput,
    remove,
    costSave,
    save,
    // isCodeFormModalOpen,
    // closeFormModal,
    // okModal,
    removeByIndex,
    gridChangeStatus,
    monthListChange,

    formType,
    isDirty,
  } = useOcuCostFormStore();
  const {
    // 년도 id
    planYearId,
    // 계획 년도
    planYear,
    // 계획 부문
    planSectCd,
    // 계획 부문명
    planSectNm,
    // 계획 Cost Center
    planCostCenter,
    // 계획 Cost Center 명
    planCostCenterNm,
    // 계획 계정
    planAcntCd,
    // 계획 계정명
    planAcntNm,
    // 계획 항목
    planItemCd,
    // 계획 항목명
    planItemNm,
    // 계획 주기
    planPayTermCd,
    // 계획 주기명
    planPayTermNm,
    // 계획 합계
    planAmt,
    // 계획 시작 월
    planFrMm,
    // 계획 종료 월
    planToMm,
    // 계획 총 합계
    planTotAmt,
    // 계획 기타
    planDesc,
    deptCd,
  } = formValue;

  console.log('formValue@@@===>', formValue.planCostCenter);

  // const [searchParams] = useSearchParams();
  // const planYear = searchParams.get('planYear');
  // const sectCd = searchParams.get('sectCd');
  // const searchRespCenter = searchParams.get('searchRespCenter');
  // const itemCdValue = searchParams.get('itemCd');
  // const searchAcntCd = searchParams.get('acntCd');

  const { detailId } = useParams();

  useEffect(() => {
    console.log('detailId==>', detailId);
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  useFormDirtyCheck(isDirty);
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      //{ field: 'status', headerName: '상태' },
      { field: 'execYear', headerName: '년도' },
      { field: 'execClsNm', headerName: '구분' },
      { field: 'respCenter', headerName: 'Resp Center' },
      { field: 'costCenter', headerName: 'Cost Center' },
      { field: 'acntCd', headerName: 'Acoount' },
      { field: 'acntNm', headerName: 'Account Name' },
      { field: 'invoiceDt', headerName: 'Invocice Date' },
      { field: 'drCrTotAmt', headerName: 'Amount' },
      { field: 'vendorNm', headerName: 'Supplier' },
      { field: 'invoiceNo', headerName: 'Invoice Number' },
      { field: 'glDt', headerName: 'GL Date' },
      { field: 'lineDesc', headerName: 'Description' },
      // { field: 'statRemark', headerName: '등록자' },
      // { field: 'statRemark', headerName: '등록일자' },
      {
        pinned: 'right',
        field: 'action',
        headerName: '',
        cellRenderer: 'deleteActionButton',
        cellRendererParams: {
          onClick: removeByIndex,
        },
      },
    ])
  );

  // const init = async () => {
  //   await getDetail(planYear, sectCd, searchRespCenter, itemCdValue, searchAcntCd);
  //   search();
  // };

  const DeleteActionButton = (props) => {
    const { node, onClick, data } = props;
    const { rowIndex } = node;
    const handleClick = (event) => {
      gridChangeStatus(props);
      event.stopPropagation();
      event.preventDefault();
      event.nativeEvent.stopPropagation();
      onClick(rowIndex);
    };
    // ERP인 경우
    if (data.execClsCd === 'B') {
      return <div onClick={handleClick}>삭제</div>;
    }
  };

  // 주기 변경 시 Total Amount 계산
  const chagePlanPayTermCd = (g, v) => {
    console.log('주기 변경==>', v);

    // 주기
    const planPayTermCdValue = formValue.planPayTermCd;
    // 시작 월
    let planFrMmValue = formValue.planFrMm;
    // 종료 월
    let planToMmValue = formValue.planToMm;
    // 총 합계
    const planTotAmtValue = formValue.planTotAmt;

    formValue.planAmt = '';

    // Annual
    if (v == 'A') {
      // 총 금액과 동일
      const amtValue = planTotAmtValue;

      console.log('종료월===>', planToMmValue);
      console.log('시작월===>', planFrMmValue);
      console.log('총 금액===>', planTotAmtValue);
      console.log('금액===>', amtValue);

      // 금액
      formValue.planAmt = amtValue;
      // 종료월
      formValue.planToMm = formValue.planFrMm;
      planToMmValue = formValue.planFrMm;

      // Semi-Annual
    } else if (v == 'B') {
      const amtValue = planTotAmtValue / 2;

      console.log('semi 종료월===>', planToMmValue);
      console.log('semi 시작월===>', planFrMmValue);
      console.log('semi 총 금액===>', planTotAmtValue);
      console.log('semi 금액===>', amtValue);

      // 금액
      formValue.planAmt = amtValue;

      // 시작월
      formValue.planFrMm = '01';

      // 종료월
      formValue.planToMm = '12';

      planFrMmValue = '01';
      planToMmValue = '12';

      // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 2);
      // Quarterly
    } else if (v == 'C') {
      const amtValue = planTotAmtValue / 4;

      console.log('종료월===>', planToMmValue);
      console.log('시작월===>', planFrMmValue);
      console.log('총 금액===>', planTotAmtValue);
      console.log('금액===>', amtValue);

      // 금액
      formValue.planAmt = amtValue;

      // 시작월
      formValue.planFrMm = '01';

      // 종료월
      formValue.planToMm = '12';

      planFrMmValue = '01';
      planToMmValue = '12';

      // Monthly
    } else if (v == 'D') {
      const amtValue = planTotAmtValue / (planToMmValue - planFrMmValue + 1);

      console.log('종료월===>', planToMmValue);
      console.log('시작월===>', planFrMmValue);
      console.log('총 금액===>', planTotAmtValue);
      console.log('금액===>', amtValue);

      // 금액
      formValue.planAmt = amtValue;

      // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 12);
    }

    // 월 항목 변경 (구분필드, 주기, 시작월, 종료월, 총 금액, 금액)
    // monthListChange(g, v, planFrMmValue, planToMmValue, planTotAmtValue, formValue.planAmt);

    monthListChange(g, v, planFrMmValue, planToMmValue, planTotAmtValue, formValue.planAmt);

    // if (!v || !planFrMmValue || !planToMmValue || !planTotAmtValue) {
    //   // 합계
    //   formValue.planAmt = '';
    // } else {
    //   // Annual
    //   if (v == 'A') {
    //     // 총 금액과 동일
    //     const amtValue = planTotAmtValue;

    //     console.log('종료월===>', planToMmValue);
    //     console.log('시작월===>', planFrMmValue);
    //     console.log('총 금액===>', planTotAmtValue);
    //     console.log('금액===>', amtValue);

    //     // 금액
    //     formValue.planAmt = amtValue;
    //     // 종료월
    //     formValue.planToMm = formValue.planFrMm;
    //     planToMmValue = formValue.planFrMm;

    //     // Semi-Annual
    //   } else if (v == 'B') {
    //     const amtValue = planTotAmtValue / 2;

    //     console.log('semi 종료월===>', planToMmValue);
    //     console.log('semi 시작월===>', planFrMmValue);
    //     console.log('semi 총 금액===>', planTotAmtValue);
    //     console.log('semi 금액===>', amtValue);

    //     // 금액
    //     formValue.planAmt = amtValue;

    //     // 시작월
    //     formValue.planFrMm = '01';

    //     // 종료월
    //     formValue.planToMm = '12';

    //     planFrMmValue = '01';
    //     planToMmValue = '12';

    //     // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 2);
    //     // Quarterly
    //   } else if (v == 'C') {
    //     const amtValue = planTotAmtValue / 4;

    //     console.log('종료월===>', planToMmValue);
    //     console.log('시작월===>', planFrMmValue);
    //     console.log('총 금액===>', planTotAmtValue);
    //     console.log('금액===>', amtValue);

    //     // 금액
    //     formValue.planAmt = amtValue;

    //     // 시작월
    //     formValue.planFrMm = '01';

    //     // 종료월
    //     formValue.planToMm = '12';

    //     planFrMmValue = '01';
    //     planToMmValue = '12';

    //     // Monthly
    //   } else if (v == 'D') {
    //     const amtValue = planTotAmtValue / (planToMmValue - planFrMmValue + 1);

    //     console.log('종료월===>', planToMmValue);
    //     console.log('시작월===>', planFrMmValue);
    //     console.log('총 금액===>', planTotAmtValue);
    //     console.log('금액===>', amtValue);

    //     // 금액
    //     formValue.planAmt = amtValue;

    //     // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 12);
    //   }

    //   // 월 항목 변경 (구분필드, 주기, 시작월, 종료월, 총 금액, 금액)
    //   // monthListChange(g, v, planFrMmValue, planToMmValue, planTotAmtValue, formValue.planAmt);

    //   monthListChange(g, v, planFrMmValue, planToMmValue, planTotAmtValue, formValue.planAmt);
    // }

    changeInput(g, v);
  };

  // 시작 월 변경 시 Total Amount 계산
  const chagePlanFrMm = (g, v) => {
    console.log('시작 월 변경==>', v);

    // 주기
    const planPayTermCdValue = formValue.planPayTermCd;
    // 시작 월
    let planFrMmValue = formValue.planFrMm;
    // 종료 월
    let planToMmValue = formValue.planToMm;
    // 총 합계
    const planTotAmtValue = formValue.planTotAmt;

    const amtValue = 0;

    formValue.planAmt = '';

    // Annual
    if (planPayTermCdValue == 'A') {
      // 총 금액과 동일
      const amtValue = planTotAmtValue;

      console.log('종료월===>', planToMmValue);
      console.log('시작월===>', v);
      console.log('총 금액===>', planTotAmtValue);
      console.log('금액===>', amtValue);

      // 금액
      formValue.planAmt = amtValue;
      // 종료월
      formValue.planToMm = v;
      planToMmValue = v;

      // Semi-Annual
    } else if (planPayTermCdValue == 'B') {
      const amtValue = planTotAmtValue / 2;

      console.log('종료월===>', planToMmValue);
      console.log('시작월===>', v);
      console.log('총 금액===>', planTotAmtValue);
      console.log('금액===>', amtValue);

      // 금액
      formValue.planAmt = amtValue;

      // 시작월
      formValue.planFrMm = '01';

      // 종료월
      formValue.planToMm = '12';

      planFrMmValue = '01';
      planToMmValue = '12';

      // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 2);
      // Quarterly
    } else if (planPayTermCdValue == 'C') {
      const amtValue = planTotAmtValue / 4;

      console.log('종료월===>', planToMmValue);
      console.log('시작월===>', v);
      console.log('총 금액===>', planTotAmtValue);
      console.log('금액===>', amtValue);

      // 금액
      formValue.planAmt = amtValue;

      // 시작월
      formValue.planFrMm = '01';

      // 종료월
      formValue.planToMm = '12';

      planFrMmValue = '01';
      planToMmValue = '12';

      // Monthly
    } else if (planPayTermCdValue == 'D') {
      const amtValue = planTotAmtValue / (planToMmValue - v + 1);

      console.log('종료월===>', planToMmValue);
      console.log('시작월===>', v);
      console.log('총 금액===>', planTotAmtValue);
      console.log('금액===>', amtValue);

      // 금액
      formValue.planAmt = amtValue;

      // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 12);
    }

    // if (!v || !planPayTermCdValue || !planToMmValue || !planTotAmtValue) {
    //   // 합계
    //   formValue.planAmt = '';
    // } else {
    //   // Annual
    //   if (planPayTermCdValue == 'A') {
    //     // 총 금액과 동일
    //     const amtValue = planTotAmtValue;

    //     console.log('종료월===>', planToMmValue);
    //     console.log('시작월===>', v);
    //     console.log('총 금액===>', planTotAmtValue);
    //     console.log('금액===>', amtValue);

    //     // 금액
    //     formValue.planAmt = amtValue;

    //     // Semi-Annual
    //   } else if (planPayTermCdValue == 'B') {
    //     const amtValue = planTotAmtValue / 2;

    //     console.log('종료월===>', planToMmValue);
    //     console.log('시작월===>', v);
    //     console.log('총 금액===>', planTotAmtValue);
    //     console.log('금액===>', amtValue);

    //     // 금액
    //     formValue.planAmt = amtValue;

    //     // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 2);
    //     // Quarterly
    //   } else if (planPayTermCdValue == 'C') {
    //     const amtValue = planTotAmtValue / 4;

    //     console.log('종료월===>', planToMmValue);
    //     console.log('시작월===>', v);
    //     console.log('총 금액===>', planTotAmtValue);
    //     console.log('금액===>', amtValue);

    //     // 금액
    //     formValue.planAmt = amtValue;
    //     // Monthly
    //   } else if (planPayTermCdValue == 'D') {
    //     const amtValue = planTotAmtValue / (planToMmValue - v + 1);

    //     console.log('종료월===>', planToMmValue);
    //     console.log('시작월===>', v);
    //     console.log('총 금액===>', planTotAmtValue);
    //     console.log('금액===>', amtValue);

    //     // 금액
    //     formValue.planAmt = amtValue;

    //     // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 12);
    //   }
    // }

    // 월 항목 변경 (구분필드, 주기, 시작월, 종료월, 총 금액, 금액)
    monthListChange(g, planPayTermCdValue, v, planToMmValue, planTotAmtValue, formValue.planAmt);

    changeInput(g, v);
  };

  // 종료 월 변경 시 Total Amount 계산
  const chagePlanToMm = (g, v) => {
    // 주기
    const planPayTermCdValue = formValue.planPayTermCd;
    // 시작 월
    const planFrMmValue = formValue.planFrMm;
    // 종료 월
    const planToMmValue = formValue.planToMm;
    // 총 합계
    const planTotAmtValue = formValue.planTotAmt;

    if (!v || !planFrMmValue || !planPayTermCdValue || !planTotAmtValue) {
      // 합계
      formValue.planAmt = '';
    } else {
      // Annual
      if (planPayTermCdValue == 'A') {
        // 총 금액과 동일
        const amtValue = planTotAmtValue;

        console.log('종료월===>', v);
        console.log('시작월===>', planFrMmValue);
        console.log('총 금액===>', planTotAmtValue);
        console.log('금액===>', amtValue);

        // 금액
        formValue.planAmt = amtValue;

        // Semi-Annual
      } else if (planPayTermCdValue == 'B') {
        const amtValue = planTotAmtValue / 2;

        console.log('종료월===>', v);
        console.log('시작월===>', planFrMmValue);
        console.log('총 금액===>', planTotAmtValue);
        console.log('금액===>', amtValue);

        // 금액
        formValue.planAmt = amtValue;

        // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 2);
        // Quarterly
      } else if (planPayTermCdValue == 'C') {
        const amtValue = planTotAmtValue / 4;

        console.log('종료월===>', v);
        console.log('시작월===>', planFrMmValue);
        console.log('총 금액===>', planTotAmtValue);
        console.log('금액===>', amtValue);

        // 금액
        formValue.planAmt = amtValue;
        // Monthly
      } else if (planPayTermCdValue == 'D') {
        const amtValue = planTotAmtValue / (v - planFrMmValue + 1);

        console.log('종료월===>', v);
        console.log('시작월===>', planFrMmValue);
        console.log('총 금액===>', planTotAmtValue);
        console.log('금액===>', amtValue);

        // 금액
        formValue.planAmt = amtValue;

        // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 12);
      }
    }

    monthListChange(g, planPayTermCdValue, planFrMmValue, v, planTotAmtValue, formValue.planAmt);

    changeInput(g, v);
  };

  // 금액 변경 시 Total Amount 계산
  const chagePlanTotAmt = (g, v) => {
    console.log('금액  변경==>', v);

    // 주기
    const planPayTermCdValue = formValue.planPayTermCd;
    // 시작 월
    const planFrMmValue = formValue.planFrMm;
    // 종료 월
    const planToMmValue = formValue.planToMm;
    // 총 합계
    const planTotAmtValue = formValue.planTotAmt;

    if (!planPayTermCdValue || !planFrMmValue || !planToMmValue || !v) {
      // 합계
      formValue.planAmt = '';
    } else {
      // Annual
      if (planPayTermCdValue == 'A') {
        // 총 금액과 동일
        const amtValue = v;

        console.log('종료월===>', planToMmValue);
        console.log('시작월===>', planFrMmValue);
        console.log('총 금액===>', v);
        console.log('금액===>', amtValue);

        // 금액
        formValue.planAmt = amtValue;

        // Semi-Annual
      } else if (planPayTermCdValue == 'B') {
        const amtValue = v / 2;

        console.log('종료월===>', planToMmValue);
        console.log('시작월===>', planFrMmValue);
        console.log('총 금액===>', v);
        console.log('금액===>', amtValue);

        // 금액
        formValue.planAmt = amtValue;

        // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 2);
        // Quarterly
      } else if (planPayTermCdValue == 'C') {
        const amtValue = v / 4;

        console.log('종료월===>', planToMmValue);
        console.log('시작월===>', planFrMmValue);
        console.log('총 금액===>', v);
        console.log('금액===>', amtValue);

        // 금액
        formValue.planAmt = amtValue;
        // Monthly
      } else if (planPayTermCdValue == 'D') {
        const amtValue = v / (planToMmValue - planFrMmValue + 1);

        console.log('종료월===>', planToMmValue);
        console.log('시작월===>', planFrMmValue);
        console.log('총 금액===>', v);
        console.log('금액===>', amtValue);

        // 금액
        formValue.planAmt = amtValue;

        // formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 12);
      }
    }

    monthListChange(g, planPayTermCdValue, planFrMmValue, planToMmValue, v, formValue.planAmt);

    changeInput(g, v);
  };

  // Account 변경
  const changeAccount = (gubun, v) => {
    formValue.planAcntCd = v;
    changeInput(gubun, v);
  };

  // 부서 변경시 부문 자동 적용
  const changeSectCd = (gubun, v, data) => {
    // 부문, 부서 초기화
    if (!v) {
      changeInput(gubun, '');
      changeInput('planSectCd', '');
    } else {
      // 부문
      if (data.sectCd) {
        changeInput('planSectCd', data.sectCd);
        // 없는 경우 기타
      } else {
        changeInput('planSectCd', 'DX');
      }
      // // 정비
      // if (v == 'DM') {
      //   formValue.deptCd = 'SELDM';
      //   // 화물
      // } else if (v == 'DF') {
      //   formValue.deptCd = 'SELDF';
      //   // 객실
      // } else if (v == 'DU') {
      //   formValue.deptCd = 'SELDU';
      //   // 여객
      // } else if (v == 'DC') {
      //   formValue.deptCd = 'SELDC';
      //   // 테크센터
      // } else if (v == 'DB') {
      //   formValue.deptCd = 'SELDB';
      //   // 기타
      // } else if (v == 'DX') {
      //   formValue.deptCd = 'SELDX';
      // }

      // changeInput('planCostCenter', value);
      changeInput(gubun, v);
    }
  };

  // Amount 변경시 Total Amount 계산
  // const changePlanAmt = (gubun, v) => {
  //   console.log('페이텀 변경==>', v);

  //   // Amount, payTerm
  //   // if (!v || !formValue.payTerm) {
  //   //   // Total Amount
  //   //   formValue.mainTotAmt = '';
  //   // } else {
  //   //   // Total Amount
  //   //   if (formValue.payTerm == 'A') {
  //   //     formValue.mainTotAmt = v;
  //   //   } else if (formValue.payTerm == 'B') {
  //   //     formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 2);
  //   //   } else if (formValue.payTerm == 'C') {
  //   //     formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 4);
  //   //   } else if (formValue.payTerm == 'D') {
  //   //     formValue.mainTotAmt = Math.floor(v.replaceAll(',', '') * 12);
  //   //   }
  //   // }

  //   changeInput(gubun, v);

  //   //formValue.totAmt = '12';
  // };

  // // payTerm 변경시 Total Amount 계산
  // const chagePlanPayTermCd = (gubun, v) => {
  //   console.log('페이텀 변경==>', v);
  //   // Amount, payTerm
  //   // if (!v || !formValue.mainPlanAmt) {
  //   //   // Total Amount
  //   //   formValue.totAmt = '';
  //   // } else {
  //   //   // Total Amount
  //   //   if (v == 'A') {
  //   //     formValue.mainTotAmt = formValue.mainPlanAmt;
  //   //   } else if (v == 'B') {
  //   //     formValue.mainTotAmt = Math.floor(formValue.mainPlanAmt.replaceAll(',', '') * 2);
  //   //     //detailInfo.mainTotAmt = detailInfo.mainPlanAmt.replaceAll(',', '') / 2;
  //   //   } else if (v == 'C') {
  //   //     formValue.mainTotAmt = Math.floor(formValue.mainPlanAmt.replaceAll(',', '') * 4);
  //   //     //detailInfo.mainTotAmt = detailInfo.mainPlanAmt / 4;
  //   //   } else if (v == 'D') {
  //   //     formValue.mainTotAmt = Math.floor(formValue.mainPlanAmt.replaceAll(',', '') * 12);
  //   //     //detailInfo.mainTotAmt = detailInfo.mainPlanAmt / 12;
  //   //   }
  //   // }

  //   changeInput(gubun, v);
  // };

  // // 실적 등록 버튼
  // const customButtons = [
  //   {
  //     title: '실적 등록',
  //     onClick: () => {
  //       // 산업안전보건 관리비 실적 등록
  //       costExecInsert();
  //     },
  //   },
  // ];

  // // 산업안전보건 관리비 실적 등록
  // const costExecInsert = () => {
  //   openFormModal('I');
  // };

  // // 그리드 더블 클릭
  // const handleRowDoubleClick = useCallback((selectedInfo) => {
  //   const data = selectedInfo.data;
  //   data.sectCd = sectCd;

  //   console.log('data==>', data);
  //   // 실적 등록 팝업
  //   openFormModal('U', data);
  // }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>산업안전보건관리비스</h2>
      </div>
      <div className="table-wrap">
        <div className="left-table">
          {/* 입력영역 */}
          <div className="editbox">
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppDatePicker
                    label="년도"
                    id="planYear"
                    // id={`${formName}advCmitImplmYm`}
                    pickerType="year"
                    value={planYear}
                    onChange={(value) => {
                      changeInput('planYear', value);
                    }}
                    required
                    disabled={formType !== 'add' ? true : false}
                    errorMessage={errors.planYear}
                  />
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppSelect label="본부" /> */}
                  <AppCodeSelect
                    label="본부"
                    codeGrpId="CODE_GRP_OC001"
                    value={planSectCd}
                    // onChange={(value) => changeSectCd('planSectCd', value)}
                    onChange={(value) => {
                      changeInput('planSectCd', value);
                    }}
                    required
                    disabled
                    // disabled={formType !== 'add' ? true : false}
                    errorMessage={errors.planSectCd}
                    // disabled={execTeamClsCd === 'A' ? true : false}
                  />
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* AppDeptSelectInput */}
                  <AppDeptListSelectInput
                    label="부서"
                    value={planCostCenter}
                    onChange={(value, data) => {
                      changeSectCd('planCostCenter', value, data);
                    }}
                    gudun="O"
                    // dept={deptCd}
                    level="4"
                    division="D"
                    required
                    disabled
                    readonly
                    // disabled={formType !== 'add' ? true : false}
                    errorMessage={errors.planCostCenter}
                    //readonly={execTeamClsCd !== 'A' ? true : false}
                    // disabled={execTeamClsCd === 'A' ? true : false}
                  />
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppCodeSelect
                    label="항목"
                    codeGrpId="CODE_GRP_OC017"
                    value={planItemCd}
                    onChange={(value) => {
                      changeInput('planItemCd', value);
                    }}
                    required
                    disabled={formType !== 'add' ? true : false}
                    errorMessage={errors.planItemCd}
                    // disabled={execTeamClsCd === 'A' ? true : false}
                  />
                </div>
              </div>
            </div>

            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppCodeSelect
                    label="계정명"
                    codeGrpId="CODE_GRP_OC045"
                    value={planAcntNm}
                    onChange={(value) =>
                      // changeInput('acntNm', value)

                      changeAccount('planAcntNm', value)
                    }
                    // onChange={(value) => {
                    //   changeInput('planAcntNm', value);
                    // }}
                    required
                    // disabled
                    errorMessage={errors.planAcntNm}
                  />
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    label="계정"
                    codeGrpId="CODE_GRP_OC045"
                    value={planAcntCd}
                    onChange={(value) => {
                      changeInput('planAcntCd', value);
                    }}
                    required
                    disabled
                    errorMessage={errors.planAcntCd}
                    // disabled={execTeamClsCd === 'A' ? true : false}
                  />
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppCodeSelect
                    label="주기"
                    codeGrpId="CODE_GRP_OC018"
                    value={planPayTermCd}
                    onChange={(value) => {
                      chagePlanPayTermCd('planPayTermCd', value);
                      // changeInput('planPayTermCd', value);
                    }}
                    required
                    errorMessage={errors.planPayTermCd}
                    // disabled
                    // disabled={execTeamClsCd === 'A' ? true : false}
                  />
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppSelect label="Month(Start)" /> */}

                  <AppCodeSelect
                    label="Month(Start)"
                    codeGrpId="CODE_GRP_OC053"
                    value={planFrMm}
                    onChange={(value) => {
                      chagePlanFrMm('planFrMm', value);
                      // changeInput('planFrMm', value);
                    }}
                    required
                    errorMessage={errors.planFrMm}
                    disabled={planPayTermCd === 'A' || planPayTermCd === 'D' ? false : true}

                    // disabled
                    // disabled={execTeamClsCd === 'A' ? true : false}
                  />
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppSelect label="Month(End)" /> */}

                  <AppCodeSelect
                    label="Month(End)"
                    codeGrpId="CODE_GRP_OC053"
                    value={planToMm}
                    onChange={(value) => {
                      chagePlanToMm('planToMm', value);
                      // changeInput('planToMm', value);
                    }}
                    required
                    errorMessage={errors.planToMm}
                    disabled={planPayTermCd === 'D' ? false : true}

                    // disabled
                    // disabled={execTeamClsCd === 'A' ? true : false}
                  />
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  {/* <AppTextInput label="금액" /> */}
                  <AppTextInput
                    label="금액"
                    value={planAmt}
                    onChange={(value) => {
                      // chagePlanAmt('planAmt', value);
                      changeInput('planAmt', value);
                    }}
                    required
                    disabled
                    errorMessage={errors.planAmt}
                  />
                </div>
              </div>
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextInput
                    label="총 금액"
                    inputType="number"
                    value={planTotAmt}
                    onChange={(value) => {
                      chagePlanTotAmt('planTotAmt', value);
                      // changeInput('planTotAmt', value)
                    }}
                    required
                    errorMessage={errors.planTotAmt}
                  />
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table">
              <div className="form-cell wid50">
                <div className="form-group wid100">
                  <AppTextArea
                    id="testArea1"
                    label="내용"
                    className="form-tag custom_textarea"
                    value={planDesc}
                    onChange={(value) => changeInput('planDesc', value)}
                    required
                    errorMessage={errors.planDesc}

                    // disabled
                    // style={{ width: '100%' }}
                  />

                  {/* <textarea
                    id="testArea1"
                    className="form-tag custom_textarea"
                    style={{ width: '100%' }}
                    name="testArea1"
                    value={inputValue}
                    onChange={(event) => {
                      setInputValue(event.target.value);
                    }}
                  />
                  <label className="f-label" htmlFor="testArea1">
                    내용
                  </label> */}
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
          {/*//입력영역*/}
        </div>
        <div className="right-table">
          <table className="plan-table">
            <thead>
              <tr>
                <th>월</th>
                <th>금액</th>
              </tr>
            </thead>

            {list &&
              list.map((data) => (
                <>
                  <tbody>
                    {/* <tr onClick={() => userRowClick(dutyData)}> */}
                    <tr>
                      {/* <h3>임직원 리스트</h3> */}
                      <td>{data.planMonth}월</td>
                      <td>{data.planMonAmt}</td>
                    </tr>
                  </tbody>
                </>
              ))}

            {/* <tbody>
              <tr>
                <td>1월</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2월</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>3월</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>4월</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>10,000,000</td>
              </tr>
            </tbody> */}
          </table>
        </div>
      </div>
      {/* 저장, 삭제, 취소  */}
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          style={{ display: formType !== 'add' ? '' : 'none' }}
          onClick={remove}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>

      {/* 하단 버튼 영역 */}
      {/* <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          수정
        </button>
      </div> */}
    </>
  );
}
export default OcuCostDetail;
