import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import CommonUtil from '@/utils/CommonUtil';
import useOcuCheckListFormStore from '@/stores/occupation/inspection/useOcuCheckListFormStore';

function OcuCheckListDetail() {
  const state = useOcuCheckListFormStore();
  const { formValue, detailInfo, getDetail, cancel, goFormPage, clear } = state;
  const { useSectNm, useDeptNm, chkListClsNm, chkListTitle, regDttm, regUserNm } = detailInfo;
  const { detailId } = useParams();

  const [ocuCheckListPlaceColumns, setOcuCheckListPlaceColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'prtnrNm', headerName: '협력업체', flex: 1 },
      { field: 'bizPlaceNm', headerName: '사업장 분류', flex: 1 },
      { field: 'useSectNm', headerName: '사용부문', flex: 1 },
    ])
  );

  const [ocuCheckListItemColumns, setOcuCheckListItemColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'chkClsNm', headerName: '점검분류' },
      { field: 'chkItemNm', headerName: '점검항목', flex: 1 },
    ])
  );

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>점검표 관리</h2>
      </div>
      <div className="editbox">
        <div className="form-table line" style={{ display: 'flex' }}>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">등록자</label>
                    <span className="text-desc-type1">{regUserNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">등록일시</label>
                    <span className="text-desc-type1">{regDttm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부문</label>
                    <span className="text-desc-type1">{useSectNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부서</label>
                    <span className="text-desc-type1">{useDeptNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">점검표 구분</label>
                    <span className="text-desc-type1">{chkListClsNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">점검표 제목</label>
                    <span className="text-desc-type1">{chkListTitle}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="ck-edit-box pd-t0">
              <div className="ck-list">
                <span className="stit-btn">
                  <h3>점검대상</h3>
                </span>
                <AppTable
                  rowData={formValue.placeList || []}
                  columns={ocuCheckListPlaceColumns}
                  setColumns={setOcuCheckListPlaceColumns}
                  hiddenTableHeader={true}
                />
              </div>
              <div className="ck-right-list">
                <div className="ck-list">
                  <span className="stit-btn">
                    <h3>점검항목</h3>
                  </span>
                  <AppTable
                    rowData={formValue.itemList || []}
                    columns={ocuCheckListItemColumns}
                    setColumns={setOcuCheckListItemColumns}
                    hiddenTableHeader={true}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
      </div>

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          수정
        </button>
      </div>
    </>
  );
}

export default OcuCheckListDetail;
