import { create } from 'zustand';
import { useStore } from 'zustand';
import { useEffect, useState, useCallback } from 'react';
import useAppStore from '@/stores/useAppStore';
import Modal from 'react-modal';
import CommonUtil from '@/utils/CommonUtil';
import AppTextInput from '@/components/common/AppTextInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppTable from '@/components/common/AppTable';
import useOcuCheckListFormStore from '@/stores/occupation/inspection/useOcuCheckListFormStore';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/inspection/checklist',
  baseRoutePath: '/occupation/inspection/checklist',
};

const initSearchParam = {
  sectCd: '',
  deptCd: '',
  chkListTitle: '',
  fromRegDttm: '',
  toRegDttm: '',
};

/* zustand store 생성 */
const OcuCheckListListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    ...initSearchParam,
  },

  setPropData: () => {
    set();
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function CheckListModal(props) {
  const state = OcuCheckListListStore();
  const { enterSearch, searchParam, list, changeSearchInput, isExpandDetailSearch, toggleExpandDetailSearch, clear } =
    state;
  const { getPlaceList, getItemList, getDetail } = useOcuCheckListFormStore();
  const { isOpen, closeModal, selectModal } = props;
  const { sectCd, deptCd, chkListTitle, fromRegDttm, toRegDttm } = searchParam;
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'useSectNm', headerName: '부문' },
      { field: 'useDeptNm', headerName: '부서' },
      { field: 'chkListTitle', headerName: '제목', flex: 1 },
      { field: 'regUserNm', headerName: '등록자' },
      { field: 'regDate', headerName: '동록일자' },
    ])
  );
  const profile = useStore(useAppStore, (state) => state.profile);
  const storeDeptCd = profile.userInfo.deptCd; // 사용자 부서
  const adminDeptCd = 'AAA'; // TODO: 관리 부서 세팅

  const handleRowDoubleClick = useCallback(async (selectedInfo) => {
    await getDetail(selectedInfo.data.chkListId);
    await selectModal({
      placeList: getPlaceList(),
      itemList: getItemList(),
    });
    closeModal();
  }, []);

  useEffect(() => {
    if (isOpen) {
      enterSearch();
    } else {
      clear;
    }
  }, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">점검표 검색</h3>
        <div className="pop_cont">
          <div className="boxForm">
            <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppCodeSelect
                      applyAllSelect={adminDeptCd === storeDeptCd ? true : false}
                      label={'부문'}
                      codeGrpId="CODE_GRP_OC001"
                      value={sectCd}
                      onChange={(value) => {
                        changeSearchInput('sectCd', value);
                      }}
                    />
                  </div>
                </div>
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppDeptSelectInput
                      label={'부서'}
                      value={deptCd}
                      onChange={(deptCd) => {
                        changeSearchInput('deptCd', deptCd);
                      }}
                    />
                  </div>
                </div>
                <div className="form-cell wid100">
                  <div className="form-group form-glow">
                    <div className="df">
                      <div className="date1">
                        <AppDatePicker
                          label={'등록기간'}
                          value={fromRegDttm}
                          onChange={(value) => {
                            changeSearchInput('fromRegDttm', value);
                          }}
                        />
                      </div>
                      <span className="unt">~</span>
                      <div className="date2">
                        <AppDatePicker
                          label={'등록기간'}
                          value={toRegDttm}
                          onChange={(value) => {
                            changeSearchInput('toRegDttm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="form-table">
                <div className="form-cell wid50">
                  <div className="form-group wid100">
                    <AppTextInput
                      label={'제목'}
                      value={chkListTitle}
                      onChange={(value) => {
                        changeSearchInput('chkListTitle', value);
                      }}
                    />
                  </div>
                </div>
                <div className="btn-area">
                  <button
                    type="button"
                    name="button"
                    className="btn-sm btn_text btn-darkblue-line"
                    onClick={enterSearch}
                  >
                    조회
                  </button>
                </div>
              </div>
            </div>
            <button
              type="button"
              name="button"
              className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
              onClick={toggleExpandDetailSearch}
            >
              <span className="hide">접기</span>
            </button>
          </div>

          <AppTable
            rowData={list}
            columns={columns}
            setColumns={setColumns}
            store={state}
            handleRowDoubleClick={handleRowDoubleClick}
          />
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            취소
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
    </Modal>
  );
}

export default CheckListModal;
