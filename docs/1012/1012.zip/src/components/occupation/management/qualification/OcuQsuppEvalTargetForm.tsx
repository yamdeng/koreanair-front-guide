import { useEffect } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useParams } from 'react-router-dom';
import AppTextInput from '@/components/common/AppTextInput';
import { create } from "zustand";
import { formBaseState, createFormSliceYup } from "@/stores/slice/formSlice";
import * as yup from "yup"; 

/* yup validation */
const yupFormSchema = yup.object({
  qsuppTargetId: yup.number().required(),
  qsuppId: yup.number().required(),
  evalYear: yup.number().required(),
  evalDeptCd: yup.string().required(),
  regDttm: yup.string().required(),
  regUserId: yup.string().required(),
  updDttm: yup.string().required(),
  updUserId: yup.string().required(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  qsuppTargetId: null,
  qsuppId: null,
  evalYear: null,
  evalDeptCd: "",
  regDttm: "",
  regUserId: "",
  updDttm: "",
  updUserId: "",
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'TODO : api path',
  baseRoutePath: 'TODO : UI route path',
  formName: 'OcuQsuppEvalTargetForm',
  formValue: {
    ...initFormValue,
  }
};

/* zustand store 생성 */
const useOcuQsuppEvalTargetFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function OcuQsuppEvalTargetForm() {

  /* formStore state input 변수 */
  const {
    errors,
    changeInput,
    getDetail,
    formType,
    formValue,
    isDirty,
    save,
    remove,
    cancel,
    clear } =
    useOcuQsuppEvalTargetFormStore();

  const {  qsuppTargetId, qsuppId, evalYear, evalDeptCd, regDttm, regUserId, updDttm, updUserId, } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>TODO : 헤더 타이틀</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                inputType="number"
                id="OcuQsuppEvalTargetFormqsuppTargetId"
                name="qsuppTargetId"
                label="적격수급업체_평가대상_ID"
                value={qsuppTargetId}
                onChange={(value) => changeInput('qsuppTargetId', value)}
                errorMessage={errors.qsuppTargetId}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuQsuppEvalTargetFormqsuppId"
                name="qsuppId"
                label="적격수급업체_ID"
                value={qsuppId}
                onChange={(value) => changeInput('qsuppId', value)}
                errorMessage={errors.qsuppId}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuQsuppEvalTargetFormevalYear"
                name="evalYear"
                label="평가_년도"
                value={evalYear}
                onChange={(value) => changeInput('evalYear', value)}
                errorMessage={errors.evalYear}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuQsuppEvalTargetFormevalDeptCd"
                name="evalDeptCd"
                label="평가_부서_코드"
                value={evalDeptCd}
                onChange={(value) => changeInput('evalDeptCd', value)}
                errorMessage={errors.evalDeptCd}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuQsuppEvalTargetFormregDttm"
                name="regDttm"
                label="등록_일시"
                value={regDttm}
                onChange={(value) => changeInput('regDttm', value)}
                errorMessage={errors.regDttm}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuQsuppEvalTargetFormregUserId"
                name="regUserId"
                label="등록자_ID"
                value={regUserId}
                onChange={(value) => changeInput('regUserId', value)}
                errorMessage={errors.regUserId}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
        <div className="form-table line">          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuQsuppEvalTargetFormupdDttm"
                name="updDttm"
                label="수정_일시"
                value={updDttm}
                onChange={(value) => changeInput('updDttm', value)}
                errorMessage={errors.updDttm}
                required
              />              
            </div>
          </div>          
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="OcuQsuppEvalTargetFormupdUserId"
                name="updUserId"
                label="수정자_ID"
                value={updUserId}
                onChange={(value) => changeInput('updUserId', value)}
                errorMessage={errors.updUserId}
                required
              />              
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          저장
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          삭제
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default OcuQsuppEvalTargetForm;
