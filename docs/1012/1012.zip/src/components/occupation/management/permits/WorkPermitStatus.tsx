import AppDatePicker from '@/components/common/AppDatePicker';
import useOcuWorkPermitStatusStore from '@/stores/occupation/management/useOcuWorkPermitStatusStore';
import { DATE_PICKER_TYPE_MONTH } from '@/config/CommonConstant';
import CommonUtil from '@/utils/CommonUtil';
import classNames from 'classnames';
import WorkPermitApproval from './WorkPermitApproval';
import { useEffect, useState } from 'react';

/*
  1.달력 오픈 제어
  2.현재 월 정보 셋팅 : init
   -초기값으로 셋팅하는 기준이 필요할지 검토
  3.현재 선택된 일 date 정보(1~31)
  4.calendarDateList : 달력의 기준 정보
  5.달 변경 인터페이스
  5-1.이전달
  5-2.다음달
  6.스케줄 목록 정보를 셋팅함
   -클릭 처리
*/

function WorkPermitStatus() {
  const {
    monthDatePickerOpen, // 월 선택 드롭다운 열려있는지 여부
    setMonthDatePickerOpen,
    searchMonth,
    selectedDate,
    calendarDateList, // 캘린더에 표시할 주 단위 날짜 목록
    changeSelectedDate,
    //scheduleList, // 월 리스트
    dateScheduleList, // 특정 날짜 리스트
    changeSearchMonth,
    prevMonth,
    nextMonth,
    goAddPage,
    clear,
  } = useOcuWorkPermitStatusStore();

  // 오늘날짜를 default로 하는게 나은가
  const currentDate = CommonUtil.getToDate();
  console.log('currentDate : ' + currentDate);
  const defaultCurrentDate = CommonUtil.convertDate(currentDate, 'YYYY-MM-DD', 'YYYY년 MM월 DD일');
  console.log('defaultCurrentDate : ', defaultCurrentDate);
  console.log('typeof defaultCurrentDate: ', typeof defaultCurrentDate);

  const [scheduleList, setScheduleList] = useState([]);

  console.log('selectedDate : ', selectedDate);
  console.log('searchMonth : ', searchMonth);
  console.log('typeof searchMonth : ', typeof searchMonth);

  return (
    <>
      {/* 버튼영역 */}
      {/* THE END OF 버튼영역 */}
      <div className="calendar-box">
        <div className="calendar-wrap">
          <div className="calendar-tit">
            <button className="prevday" onClick={prevMonth}>
              버튼
            </button>
            <h2 className="datetitle">
              <AppDatePicker
                style={{ visibility: 'hidden', width: 0 }}
                onOpenChange={(status) => {
                  setMonthDatePickerOpen(status);
                }}
                open={monthDatePickerOpen}
                hidden
                pickerType={DATE_PICKER_TYPE_MONTH}
                getPopupContainer={(trigger) => {
                  return trigger.parentNode;
                }}
                onChange={(value) => {
                  changeSearchMonth(value);
                }}
                showNow={false}
              />
              <span className="month" onClick={() => setMonthDatePickerOpen(true)}>
                {CommonUtil.convertDate(searchMonth, 'YYYY-MM', 'YYYY.MM')}
              </span>
            </h2>

            <button className="nextday" onClick={nextMonth}>
              버튼
            </button>
          </div>
          <table className="calendar-table">
            <thead>
              <tr>
                <th>일</th>
                <th>월</th>
                <th>화</th>
                <th>수</th>
                <th>목</th>
                <th>금</th>
                <th>토</th>
              </tr>
            </thead>
            <tbody>
              {calendarDateList.map((weekList, index) => {
                return (
                  <tr key={index}>
                    {weekList.map((dateInfo) => {
                      let dateComponent = <td></td>;
                      if (dateInfo) {
                        const { date, isHoliday } = dateInfo;
                        // active가 우선
                        const applyClassName = classNames('cld_day', {
                          s_day: date !== selectedDate && isHoliday,
                          active: date === selectedDate,
                        });
                        dateComponent = (
                          <td key={date} onClick={() => changeSelectedDate(date)}>
                            <div className="cld_date">
                              <div className={applyClassName}>{date}</div>
                              <ul className="schedule">
                                {/* 선택된 날짜에 대한 일정 필터링 */}
                                {scheduleList
                                  .filter((item) => {
                                    // item의 시작일과 종료일을 가져옵니다.
                                    const startDate = new Date(item.cntrApplyStartDttm).toISOString().split('T')[0];
                                    const endDate = new Date(item.cntrApplyEndDttm).toISOString().split('T')[0];
                                    return startDate <= date && endDate >= date; // 선택한 날짜가 시작일과 종료일 사이에 있는지 확인
                                  })
                                  .map((item) => (
                                    <li key={item.id}>
                                      {' '}
                                      {/* 각 일정에 고유한 id 추가 */}
                                      <a className={item.workStatus.toLowerCase()} href={undefined}>
                                        {item.workStatus} <span>(1)</span> {/* 작업 상태에 따라 동적으로 표시 */}
                                      </a>
                                    </li>
                                  ))}
                              </ul>
                            </div>
                          </td>
                        );
                      }
                      return dateComponent;
                      // dateComponent = (
                      //   <td key={date} onClick={() => changeSelectedDate(date)}>
                      //     <div className="cld_date">
                      //       <div className={applyClassName}>{date}</div>
                      //       <ul className="schedule">
                      //         {/* workStatusCounts 선언 - 쿼리 count값으로 바꾸는게 나은가?*/}
                      //         const workStatusCounts = scheduleList.reduce((acc, item) => {
                      //           // item의 시작일과 종료일을 가져오기
                      //           const startDate = new Date(item.cntrApplyStartDttm).toISOString().split('T')[0];
                      //           const endDate = new Date(item.cntrApplyEndDttm).toISOString().split('T')[0];

                      //           // 날짜가 시작일과 종료일 사이에 있는지 확인하기
                      //           if (startDate <= date && endDate >= date) {
                      //             // acc 객체에 workStatus를 키로 하여 카운트를 증가
                      //             acc[item.workStatus] = (acc[item.workStatus] || 0) + 1;
                      //           }

                      //           return acc; // 업데이트된 acc를 반환
                      //         }, {}); // 초기값은 빈 객체

                      //         {/* 카운트 결과를 표시 */}
                      //         {Object.entries(workStatusCounts).map(([status, count]) => (
                      //           <li key={status}>
                      //             <a className={status.toLowerCase()} href={undefined}>
                      //               {status} <span>({count})</span> {/* 각 상태의 카운트를 표시 */}
                      //             </a>
                      //           </li>
                      //         ))}
                      //       </ul>
                      //     </div>
                      //   </td>
                      // );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="calendar-list">
          <h3 className="table-tit">
            {/* 클릭된 날짜 표시 */}
            {searchMonth && selectedDate
              ? `${CommonUtil.convertDate(searchMonth, 'YYYY-MM', 'YYYY년 MM월')} ${selectedDate}일`
              : `${defaultCurrentDate}`}
          </h3>
          <ul className="schedule-guide">
            <li>
              <span className="expected"></span>작업예정
            </li>
            <li>
              <span className="ing"></span>작업중
            </li>
            <li>
              <span className="complete"></span>작업완료
            </li>
            <li>
              <span className="wait"></span>작업완료대기
            </li>
          </ul>
          <table className="list-table">
            <thead>
              <tr>
                <th>작업상태</th>
                <th>공사명</th>
              </tr>
            </thead>
            <tbody>
              {dateScheduleList.length > 0 ? (
                dateScheduleList.map((item, index) => (
                  <tr key={index}>
                    <td
                      className={
                        item.workStatus === '작업중'
                          ? 'ing'
                          : item.workStatus === '작업완료'
                            ? 'complete'
                            : item.workStatus === '작업종료'
                              ? 'wait'
                              : 'expected'
                      }
                    >
                      {item.workStatus}
                    </td>
                    <td>{item.cntrNm}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={2}>작업 목록이 없습니다.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      {/* 승인/ 작업종료 그리드 */}
      <WorkPermitApproval />
    </>
  );
}

export default WorkPermitStatus;
