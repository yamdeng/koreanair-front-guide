import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDeptSelectInput from '@/components/common/AppDeptSelectInput';
import AppNavigation from '@/components/common/AppNavigation';
import AppSearchInput from '@/components/common/AppSearchInput';
// import AppSelect from '@/components/common/AppSelect';
import AppTable from '@/components/common/AppTable';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import { useCallback, useEffect, useState } from 'react';
import { useLocation, useNavigate, useHistory } from 'react-router-dom';
import { create } from 'zustand';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';
import AppSelect from '@/components/common/AppSelect';

import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';

// /occupation/notice/{id} : 상세
// /occupation/notice/{id}/edit : 폼(등록/수정)

const initListData = {
  ...listBaseState,
  listApiPath: 'ocu/risk/reval',
  baseRoutePath: '/occupation/risk/reval',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  // 부문
  authorSectCd: '',
  // 부서
  authorDeptCd: '',
  // 작성자
  regUserNm: '',
  // 평가년도
  rEvalYear: '',
  // 평가시기
  rEvalPeriod: '',
  // 문서번호
  rEvalDocNo: '',
  // 제목
  rEvalTitle: '',
};

/* zustand store 생성 */
const RevalListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    // 부문
    authorSectCd: '',
    // 부서
    authorDeptCd: '',
    // 작성자
    regUserNm: '',
    // 평가년도
    rEvalYear: '',
    // 평가시기
    rEvalPeriod: '',
    // 문서번호
    rEvalDocNo: '',
    // 제목
    rEvalTitle: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function RevalList() {
  const state = RevalListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'revalDocNo', headerName: '문서번호', flex: 1 },
      { field: 'revalYear', headerName: '평가년도', flex: 1 },
      // { field: 'revalPeriod', headerName: '평가시기', flex: 1 },
      {
        field: 'revalPeriod',
        headerName: '평가시기',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC019',
        },
      },

      // { field: 'authorSectCd', headerName: '부문', flex: 1 },

      {
        field: 'authorSectCd',
        headerName: '부문',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC001',
        },
      },

      { field: 'nmLevel2', headerName: '부서', flex: 1 },
      { field: 'nmLevel3', headerName: '팀', flex: 1 },
      { field: 'nmLevel4', headerName: '그룹', flex: 1 },
      { field: 'nmLevel5', headerName: '반', flex: 1 },
      { field: 'revalTitle', headerName: '제목', flex: 1 },
      { field: 'regUserNm', headerName: '작성자', flex: 1 },
      { field: 'regDttm', headerName: '작성일자', flex: 1 },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    goDetailPage,
    changeSearchInput,
    //initSearchInput,
    // isExpandDetailSearch,
    // toggleExpandDetailSearch,
    clear,
  } = state;
  const { authorSectCd, authorDeptCd, regUserNm, rEvalYear, rEvalPeriod, rEvalDocNo, rEvalTitle } = searchParam;

  console.log('list===>', list);

  const location = useLocation();
  const userInfo = { ...location.state };
  const navigate = useNavigate();

  console.log('userInfo===>', userInfo.keys);

  // const location = useLocation();
  // const searchSectCd = location.data;
  // console.log('searchSectCd===>', searchSectCd);

  // 그리드 더블 클릭
  const handleRowDoubleClick = useCallback((selectedInfo) => {
    const data = selectedInfo.data;
    // id
    const detailId = data.revalDocNo;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    // 복사 여부 클리어
    useOcuRiskTab1FormStore.getState().tab1CopyChk = 'N';
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>위험성평가조회</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm">
        {/*area-detail명 옆에 active  */}
        <div id="" className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'부문'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC001"
                  value={authorSectCd}
                  onChange={(value) => {
                    changeSearchInput('authorSectCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSelect
                  label={'부서'}
                  value={authorDeptCd}
                  apiUrl={`ocu/general/lawRegInfo/selectLawDeptList`}
                  labelKey="nameKor"
                  valueKey="deptCd"
                  onChange={(deptCd) => {
                    changeSearchInput('authorDeptCd', deptCd);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label={'작성자'}
                  value={regUserNm}
                  onChange={(value) => {
                    changeSearchInput('regUserNm', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppDatePicker
                  label={'평가년도'}
                  pickerType="year"
                  value={rEvalYear}
                  onChange={(value) => {
                    changeSearchInput('rEvalYear', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  label={'평가시기'}
                  applyAllSelect="true"
                  codeGrpId="CODE_GRP_OC019"
                  value={rEvalPeriod}
                  onChange={(value) => {
                    changeSearchInput('rEvalPeriod', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="문서번호"
                  value={rEvalDocNo}
                  onChange={(value) => {
                    changeSearchInput('rEvalDocNo', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="제목"
                  value={rEvalTitle}
                  onChange={(value) => {
                    changeSearchInput('rEvalTitle', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              검색
            </button>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button type="button" name="button" className="arrow button _control active">
          <span className="hide">접기</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          신규
        </button>
      </div>
    </>
  );
}

export default RevalList;
