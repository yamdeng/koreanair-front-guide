import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
/* TODO : store 경로를 변경해주세요. */
//import useOcuRiskTab1FormStore from '@/stores/occupation/risk/useOcuRiskTab1FormStore';
import shareImage from '@/resources/images/share.svg';
import AppFileAttach from '@/components/common/AppFileAttach';
import { useLocation } from 'react-router-dom';
import { Viewer } from '@toast-ui/react-editor';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import CommonUtil from '@/utils/CommonUtil';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';

import AppSearchInput from '@/components/common/AppSearchInput';

import useOcuRiskMasterStore from '@/stores/occupation/risk/useOcuRiskMasterStore';
import AppTextInput from '@/components/common/AppTextInput';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppUserSelectInput from '@/components/common/AppUserSelectInput';
import RiskHelpPeriodModal from '@/components/modal/occupation/RiskHelpPeriodModal';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';
import AppTextArea from '@/components/common/AppTextArea';

import RiskDcsnPsbltValModal from '@/components/modal/occupation/RiskDcsnPsbltValModal';
import RiskrDcsnImprtValModal from '@/components/modal/occupation/RiskrDcsnImprtValModal';
import RiskDcsnRiskValModal from '@/components/modal/occupation/RiskDcsnRiskValModal';

import useOcuRiskTab3FormStore from '@/stores/occupation/risk/useOcuRiskTab3FormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalFormTab2() {
  /* formStore state input 변수 */
  // const { detailInfo, getDetail, formType, cancel, goFormPage, clear, search, list } = useOcuRiskTab1FormStore();

  const {
    detailInfo,
    formValue,
    getDetail,
    formType,
    cancel,
    clear,
    search,
    removeByIndex,

    list,

    //goForm,
    changeInput,
    errors,
    // 청취조사
    procChange,
    procSaveStrore,
    procAddRowStore,
    deleteProcList,
    saveUseOcuRiskTab3,
    openFormModal,
    isCodeFormModalOpen,
    closeFormModal,
    openFormModal2,
    isCodeFormModalOpen2,
    closeFormModal2,
    openFormModal3,
    isCodeFormModalOpen3,
    closeFormModal3,

    // list
    setSelectedPlaceIndex,
    selectedPlaceIndex,
    getPlaceColumn,
    setPlaceColumn,
    getPlaceError,
    saveAll,
    addPlaceRow,
    delPlaceRow,
    revalDocNo,
    isDirty,
  } = useOcuRiskTab3FormStore();

  // const {
  //   revalDocNo,
  //   // 공정명
  //   procNm,
  //   // 세부 작업명
  //   detailWrkNm,

  //   // 위험분류
  //   riskClsNm,
  //   // 위험요인
  //   riskFactorCd,
  //   // 위험발생 상황 및 결과
  //   riskOcurStatRes,
  //   // 현재의 안전보건 조치
  //   currHlthSftyAction,
  //   // 가능성
  //   riskDcsnPsbltVal,
  //   // 중대성
  //   riskDcsnImprtVal,
  //   // 위험도
  //   riskDcsnRiskVal,
  //   // 위험성 결정
  //   riskDcsnCd,
  //   // 감소대책 수립
  //   rdcmsrCd,
  // } = formValue;

  const { detailId } = useParams();
  formValue.revalDocNo = detailId;

  // 위험성결정 행 삭제
  const DeleteActionButton = (props) => {
    const { node, onClick } = props;
    const { rowIndex } = node;

    const handleClick = (event) => {
      event.stopPropagation();
      event.preventDefault();
      event.nativeEvent.stopPropagation();
      onClick(rowIndex);
    };

    console.log('porps==>', props);
    if (props.data.rdcmsrStatCd != 'C') {
      return <div onClick={handleClick}>삭제</div>;
    }
  };

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: '_status', headerName: '상태', editable: true, flex: 1 },
      { field: 'procNm', headerName: '공정명', flex: 1 },
      { field: 'detailWrkNm', headerName: '세부 작업명', flex: 1 },
      {
        field: 'riskClsCd',
        headerName: '위험분류',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC050',
        },
      },
      { field: 'riskFactorCd', headerName: '위험요인', flex: 1 },
      { field: 'riskOcurStatRes', headerName: '위험발생 상황 및 결과', flex: 1 },
      { field: 'currHlthSftyAction', headerName: '현재의 안전보건 조치', flex: 1 },
      { field: 'riskDcsnPsbltVal', headerName: '가능성', flex: 1 },
      { field: 'riskDcsnImprtVal', headerName: '중대성', flex: 1 },
      { field: 'riskDcsnRiskVal', headerName: '위험도', flex: 1 },
      {
        field: 'riskDcsnCd',
        headerName: '위험성 결정',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC024',
        },
      },
      {
        field: 'rdcmsrCd',
        headerName: '감소대책 수립',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC025',
        },
      },
      {
        field: 'rdcmsrStatCd',
        headerName: '개선상태',
        flex: 1,
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_OC026',
        },
      },
      {
        pinned: 'right',
        field: 'action',
        headerName: '삭제',
        //flex: 1,
        // flex: 1,
        cellRenderer: 'deleteActionButton',
        cellRendererParams: {
          onClick: delPlaceRow,
        },
      },
    ])
  );

  const customButtons = [
    {
      title: '추가',
      onClick: () => {
        addPlaceRow();
        // procAddRow();
      },
    },
  ];

  // // 부문
  // const sectCd = profile.userInfo.sectCd;
  // // 부서
  // const deptLevel2 = profile.userInfo.deptLevel2;
  // // 팀
  // const deptLevel3 = profile.userInfo.deptLevel3;
  // // 그룹
  // const deptLevel4 = profile.userInfo.deptLevel4;
  // // 반/섹션
  // const deptLevel5 = profile.userInfo.deptLevel5;
  // // 오늘 날짜
  // const toDate = CommonUtil.getToDate();

  // 위험성결정 행 추가
  // const procAddRow = () => {
  //   console.log('로우 추가');
  //   setColumns((prevColumns) => [...prevColumns]);

  //   // 공정명
  //   formValue.procNm = '';
  //   // 세부 작업명
  //   formValue.detailWrkNm = '';
  //   // 위험분류코드
  //   formValue.riskClsCd = '';
  //   // 위험분류명
  //   formValue.riskClsNm = '';
  //   // 위험요인
  //   formValue.riskFactorCd = '';
  //   // 위험발생 상황 및 결과
  //   formValue.riskOcurStatRes = '';
  //   // 현재의 안전보건 조치
  //   formValue.currHlthSftyAction = '';
  //   // 가능성
  //   formValue.riskDcsnPsbltVal = null;
  //   // 중대성
  //   formValue.riskDcsnImprtVal = null;
  //   // 위험도
  //   formValue.riskDcsnRiskVal = null;
  //   // 위험성 결정
  //   formValue.riskDcsnCd = '';
  //   // 감소대책 수립
  //   formValue.rdcmsrCd = '';

  //   procAddRowStore();
  // };

  // const init = async () => {
  //   getDetail(detailId);
  //   search();
  // };

  // useEffect(() => {
  //   if (detailId && detailId !== 'add') {
  //     init();
  //   } else {
  //     console.log('초기화');
  //     // 리스트 초기화
  //     // list.deleteAll();
  //   }
  //   return clear;

  //   // init();
  // }, []);

  useFormDirtyCheck(isDirty);

  const init = async () => {
    getDetail(detailId);
    // search();
  };

  useEffect(() => {
    init();
    return clear;
  }, []);

  // 첫번째 행 선택
  useEffect(() => {
    if (formValue?.processInfoList && formValue.processInfoList.length > 0 && selectedPlaceIndex === -1) {
      const firstRow = formValue.processInfoList[0];
      handleRowSingleClick({ data: firstRow, rowIndex: 0 });
    }
  }, [formValue, selectedPlaceIndex]);

  const handleRowSingleClick = useCallback(
    (selectedInfo) => {
      setSelectedPlaceIndex(selectedInfo.rowIndex);
    },
    [selectedPlaceIndex]
  );

  // useEffect(() => {
  //   init();
  //   return clear;
  // }, []);

  // // 위험성결정 행 변경
  // const handleRowSingleClick = useCallback((selectedInfo) => {
  //   setColumns((prevColumns) => [...prevColumns]);
  //   procChange(selectedInfo.data, selectedInfo.rowIndex);
  // }, []);

  // // 위험성결정 저장
  // const procSave = () => {
  //   setColumns((prevColumns) => [...prevColumns]);

  //   const data = {
  //     // 공정명
  //     procNm: procNm,
  //     // 세부 작업명
  //     detailWrkNm: detailWrkNm,
  //     // 위험분류
  //     riskClsNm: riskClsNm,
  //     // 위험요인
  //     riskFactorCd: riskFactorCd,
  //     // 위험발생 상황 및 결과
  //     riskOcurStatRes: riskOcurStatRes,
  //     // 현재의 안전보건 조치
  //     currHlthSftyAction: currHlthSftyAction,
  //     // 가능성
  //     riskDcsnPsbltVal: riskDcsnPsbltVal,
  //     // 중대성
  //     riskDcsnImprtVal: riskDcsnImprtVal,
  //     // 위험도
  //     riskDcsnRiskVal: riskDcsnRiskVal,
  //     // 위험성 결정
  //     riskDcsnCd: riskDcsnCd,
  //     // 감소대책 수립
  //     rdcmsrCd: rdcmsrCd,
  //   };

  //   procSaveStrore(data);
  // };

  // 가능성 변경시 ( 위험도 계산)
  const selectRiskDcsnPsbltVal = (v) => {
    /*  가능성 x 중대성 = 위험도 */

    if (!v) {
      // 위험도
      setPlaceColumn('riskDcsnRiskVal', '');
    } else {
      // 중대성
      const riskDcsnImprtVal = getPlaceColumn('riskDcsnImprtVal');

      // 중대성 값이 있는 경우
      if (riskDcsnImprtVal) {
        // 위험도 계산
        setPlaceColumn('riskDcsnRiskVal', Number(v) * riskDcsnImprtVal);
      }
    }

    setPlaceColumn('riskDcsnPsbltVal', Number(v));
    // changeInput('riskDcsnPsbltVal', v);
  };

  // 중대성 변경시 ( 위험도 계산)
  const selectDcsnImprtVal = (v) => {
    /*  가능성 x 중대성 = 위험도 */
    if (!v) {
      // 위험도
      setPlaceColumn('riskDcsnRiskVal', '');
    } else {
      // 가능성
      const riskDcsnPsbltVal = getPlaceColumn('riskDcsnPsbltVal');

      // 중대성 값이 있는 경우
      if (riskDcsnPsbltVal) {
        // 위험도 계산
        setPlaceColumn('riskDcsnRiskVal', Number(v) * riskDcsnPsbltVal);
      }
    }

    setPlaceColumn('riskDcsnImprtVal', Number(v));
  };

  // 위험분류 변경시 (위험요인 값 셋팅)
  const selectRiskFactorCd = (v, data) => {
    // 위험요인
    // formValue.riskFactorCd = data.codeField1;

    // setPlaceColumn('riskClsNm', value)

    // 위험요인 셋팅
    setPlaceColumn('riskFactorCd', data.codeField1);
    getPlaceColumn('riskFactorCd');

    // onChange={(value) => setPlaceColumn('riskFactorCd', value)}

    // 위험분류 셋팅
    setPlaceColumn('riskClsCd', v);
    // getPlaceColumn('riskClsNm');

    // changeInput('riskClsNm', v);
  };

  // 가능성 도움말 팝업
  const RiskDcsnPsbltValModalPop = () => {
    openFormModal(null);
  };

  // 중대성 도움말 팝업
  const RiskrDcsnImprtValModalPoP = () => {
    openFormModal2(null);
  };

  // 위험성 도움말 팝업
  const RiskDcsnRiskValModalPop = () => {
    openFormModal3(null);
  };

  return (
    <>
      {/*//탭 */}
      {/* 입력영역 */}
      <div className="info-wrap toggle">
        <dl className="tg-item active">
          {/* toggle 선택되면  열어지면 active붙임*/}
          <dt>
            <button type="button" className="btn-tg">
              유해, 위험 요인 파악
              <span className="active"></span>
              <div className="tag-info-wrap">
                <div className="tooltip">
                  <div className="tooltiptext tooltip-right">
                    <h3>작성요령 예시</h3>
                    <ul>
                      <li>공정명(크리닝)</li>
                      <li>세부 작업명(분부세척, part 침전, 건조)</li>
                      <li>위험분류(드롭다운 선택)</li>
                      <li>위험발생 상황(어떤 위험요인에 의해 어떤 재해발생이 우려됨)</li>
                      <li>현재의 안전보건조치(공학적, 관리적, 개인적 대책)</li>
                      <li>위험성 결정(사고발생 가능성 및 예상 피해정도)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* <AppTextInput */}
                        <AppSelect
                          label="공정명"
                          apiUrl={`ocu/risk/reval/selectProcess?revalDocNo=${detailId}`}
                          // value={formValue.procNm}
                          // onChange={(value) => {
                          //   changeInput('procNm', value);
                          // }}
                          // errorMessage={errors.procNm}
                          value={getPlaceColumn('procNm')}
                          onChange={(value) => setPlaceColumn('procNm', value)}
                          errorMessage={getPlaceError('procNm')}
                          labelKey="procNm"
                          valueKey="procNm"
                          disabled={getPlaceColumn('rdcmsrStatCd') === 'C' || selectedPlaceIndex === -1 ? true : false}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="세부 작업명"
                          // value={formValue.detailWrkNm}
                          // onChange={(value) => {
                          //   changeInput('detailWrkNm', value);
                          // }}
                          // errorMessage={errors.detailWrkNm}
                          value={getPlaceColumn('detailWrkNm')}
                          onChange={(value) => setPlaceColumn('detailWrkNm', value)}
                          errorMessage={getPlaceError('detailWrkNm')}
                          disabled={getPlaceColumn('rdcmsrStatCd') === 'C' || selectedPlaceIndex === -1 ? true : false}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="위험분류"
                          // value={formValue.riskClsNm}
                          onChange={(value, sd) => {
                            selectRiskFactorCd(value, sd);
                            // changeInput('riskClsNm', value);
                          }}
                          // errorMessage={errors.riskClsNm}
                          codeGrpId="CODE_GRP_OC050"
                          value={getPlaceColumn('riskClsCd')}
                          // onChange={(value) => setPlaceColumn('riskClsCd', value)}
                          errorMessage={getPlaceError('riskClsCd')}
                          disabled={getPlaceColumn('rdcmsrStatCd') === 'C' || selectedPlaceIndex === -1 ? true : false}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="위험요인"
                          disabled
                          // value={formValue.riskFactorCd}
                          // onChange={(value) => {
                          //   changeInput('riskFactorCd', value);
                          // }}
                          // errorMessage={errors.riskFactorCd}
                          value={getPlaceColumn('riskFactorCd')}
                          onChange={(value) => setPlaceColumn('riskFactorCd', value)}
                          errorMessage={getPlaceError('riskFactorCd')}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextArea
                          id="testArea1"
                          label="위험발생 상황 및 결과"
                          // className="form-tag custom_textarea"
                          // style={{ width: '100%' }}
                          // value={formValue.riskOcurStatRes}
                          // errorMessage={errors.riskOcurStatRes}
                          value={getPlaceColumn('riskOcurStatRes')}
                          onChange={(value) => setPlaceColumn('riskOcurStatRes', value)}
                          // onChange={(value) => changeInput('riskOcurStatRes', value)}
                          errorMessage={getPlaceError('riskOcurStatRes')}
                          disabled={getPlaceColumn('rdcmsrStatCd') === 'C' || selectedPlaceIndex === -1 ? true : false}
                        />

                        {/* <textarea
                          id="testArea1"
                          className="form-tag custom_textarea"
                          style={{ width: '100%' }}
                          name="testArea1"
                          value={riskOcurStatRes}
                          // onChange={(event) => {
                          //   setInputValue(event.target.value);
                          // }}
                        />
                        <label className="f-label" htmlFor="testArea1">
                          위험발생 상황 및 결과
                        </label> */}
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextArea
                          id="testArea1"
                          label="현재의 안전보건 조치"
                          // className="form-tag custom_textarea"
                          // style={{ width: '100%' }}
                          // value={formValue.currHlthSftyAction}
                          // onChange={(value) => changeInput('currHlthSftyAction', value)}
                          // errorMessage={errors.currHlthSftyAction}
                          value={getPlaceColumn('currHlthSftyAction')}
                          onChange={(value) => setPlaceColumn('currHlthSftyAction', value)}
                          errorMessage={getPlaceError('currHlthSftyAction')}
                          disabled={getPlaceColumn('rdcmsrStatCd') === 'C' || selectedPlaceIndex === -1 ? true : false}
                        />
                        {/* <textarea
                          id="testArea1"
                          className="form-tag custom_textarea"
                          style={{ width: '100%' }}
                          name="testArea1"
                          value={currHlthSftyAction}
                        />
                        <label className="f-label" htmlFor="testArea1">
                          현재의 안전보건 조치
                        </label> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
          <dt>
            <button type="button" className="btn-tg">
              위험성 결정
              <span className="active"></span>
              {/*가능성, 중대성, 위험도 - 팝업 */}
              <div className="tag-info-wrap-end">
                <div className="tip" onClick={RiskDcsnPsbltValModalPop}>
                  <div>
                    <a href="javascript:void(0);" className="txt" onClick={RiskDcsnPsbltValModalPop}>
                      가능성
                    </a>
                  </div>
                </div>
                <div className="tip" onClick={RiskrDcsnImprtValModalPoP}>
                  <div>
                    <a href="javascript:void(0);" className="txt" onClick={RiskrDcsnImprtValModalPoP}>
                      중대성
                    </a>
                  </div>
                </div>
                <div className="tip" onClick={RiskDcsnRiskValModalPop}>
                  <div>
                    <a href="javascript:void(0);" className="txt" onClick={RiskDcsnRiskValModalPop}>
                      위험도
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts">
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          codeGrpId="CODE_GRP_OC022"
                          label="가능성"
                          // value={formValue.riskDcsnPsbltVal}
                          onChange={(value) => {
                            selectRiskDcsnPsbltVal(value);
                            // changeInput('riskDcsnPsbltVal', value);
                          }}
                          // errorMessage={errors.riskDcsnPsbltVal}
                          value={getPlaceColumn('riskDcsnPsbltVal')}
                          // onChange={(value) => setPlaceColumn('riskDcsnPsbltVal', value)}
                          errorMessage={getPlaceError('riskDcsnPsbltVal')}
                          required
                          disabled={getPlaceColumn('rdcmsrStatCd') === 'C' || selectedPlaceIndex === -1 ? true : false}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="중대성"
                          codeGrpId="CODE_GRP_OC023"
                          // value={formValue.riskDcsnImprtVal}
                          onChange={(value) => {
                            selectDcsnImprtVal(value);
                            //changeInput('riskDcsnImprtVal', value);
                          }}
                          // errorMessage={errors.riskDcsnImprtVal}
                          value={getPlaceColumn('riskDcsnImprtVal')}
                          // onChange={(value) => setPlaceColumn('riskDcsnImprtVal', value)}
                          errorMessage={getPlaceError('riskDcsnImprtVal')}
                          required
                          disabled={getPlaceColumn('rdcmsrStatCd') === 'C' || selectedPlaceIndex === -1 ? true : false}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="위험도"
                          disabled
                          // value={formValue.riskDcsnRiskVal}
                          // onChange={(value) => {
                          //   changeInput('riskDcsnRiskVal', value);
                          // }}
                          // errorMessage={errors.riskDcsnRiskVal}
                          value={getPlaceColumn('riskDcsnRiskVal')}
                          onChange={(value) => setPlaceColumn('riskDcsnRiskVal', value)}
                          errorMessage={getPlaceError('riskDcsnRiskVal')}
                          required
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="위험성 결정"
                          codeGrpId="CODE_GRP_OC024"
                          // value={formValue.riskDcsnCd}
                          value={getPlaceColumn('riskDcsnCd')}
                          onChange={(value) => {
                            setPlaceColumn('riskDcsnCd', value);
                          }}
                          errorMessage={getPlaceError('riskDcsnCd')}
                          required
                          disabled={getPlaceColumn('rdcmsrStatCd') === 'C' || selectedPlaceIndex === -1 ? true : false}
                          // errorMessage={errors.riskDcsnCd}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="감소대책 수립"
                          codeGrpId="CODE_GRP_OC025"
                          // value={formValue.rdcmsrCd}
                          // onChange={(value) => {
                          //   changeInput('rdcmsrCd', value);
                          // }}
                          // errorMessage={errors.rdcmsrCd}
                          value={getPlaceColumn('rdcmsrCd')}
                          onChange={(value) => setPlaceColumn('rdcmsrCd', value)}
                          errorMessage={getPlaceError('rdcmsrCd')}
                          required
                          disabled={getPlaceColumn('rdcmsrStatCd') === 'C' || selectedPlaceIndex === -1 ? true : false}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>
      {/*//입력영역*/}

      {/* 가능성 */}
      <RiskDcsnPsbltValModal isOpen={isCodeFormModalOpen} closeModal={closeFormModal} />
      {/* 중대성 */}
      <RiskrDcsnImprtValModal isOpen={isCodeFormModalOpen2} closeModal={closeFormModal2} />
      {/* 위험도 */}
      <RiskDcsnRiskValModal isOpen={isCodeFormModalOpen3} closeModal={closeFormModal3} />

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        {/* <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
          저장
        </button> */}
        {/*//하단버튼영역*/}
        {/*그리드영역 */}
        <div>
          <AppTable
            rowData={formValue.processInfoList || []}
            columns={columns}
            setColumns={setColumns}
            customButtons={customButtons}
            handleRowSingleClick={handleRowSingleClick}
            hiddenPagination
            components={{
              deleteActionButton: DeleteActionButton,
            }}
            getRowStyle={(params) => {
              const { data, rowIndex } = params;
              if (rowIndex === selectedPlaceIndex) {
                return { background: '#d6d9eb' };
              } else if (data._isError) {
                return { background: '#ebb2b2' };
              }
            }}
          />
        </div>

        <button
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={saveAll}
          // style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          저장
        </button>
        {/* <button type="button" name="button" className="btn_text btn-del">
          삭제
        </button> */}
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          취소
        </button>
      </div>
    </>
  );
}
export default RevalFormTab2;
