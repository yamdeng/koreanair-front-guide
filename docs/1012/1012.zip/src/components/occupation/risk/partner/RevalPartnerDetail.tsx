import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import AppNavigation from '@/components/common/AppNavigation';
import AppFileAttach from '@/components/common/AppFileAttach';
/* TODO : store 경로를 변경해주세요. */
import shareImage from '@/resources/images/share.svg';
import AppTable from '@/components/common/AppTable';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';

import useOcuRdcmsrFormStore from '@/stores/occupation/risk/useOcuRdcmsrFormStore';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';

import CommonUtil from '@/utils/CommonUtil';

import useOcuRevalPartnerFormStore from '@/stores/occupation/risk/useOcuRevalPartnerFormStore';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function RevalPartnerDetail() {
  // // 청취조사
  // const listenInfo = useOcuRiskTab2FormStore();
  // // 현장순화
  // const visitInfo = useOcuRiskTab2SiteVisitListStore();

  const { detailInfo, getDetail, formType, cancel, goFormPage, clear } = useOcuRevalPartnerFormStore();
  const {
    // 부문
    prtnrREvalSectCd,
    // 부서
    prtnrREvalDeptCd,
    // 작성자
    regUserId,
    // 작성자명
    regUserNm,
    // 작성일자
    regDttm,
    // 평가년도
    prtnrREvalEvalYear,
    // 평가시기
    prtnrREvalClsCd,
    // 협력업체
    prtnrId,
    // 사업장
    bizPlaceClsCd,
    // 제목
    prtnrREvalTitle,
    // 파일첨부
    prtnrREvalFileId,
  } = detailInfo;

  console.log('값2==>', detailInfo);

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>협력사 위험성 평가 등록</h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부문</label>
                    <span className="text-desc-type1">{prtnrREvalSectCd}</span>
                  </li>
                </ul>
              </div>
              {/* <AppTextInput label="부문" required disabled /> */}
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">부서</label>
                    <span className="text-desc-type1">{prtnrREvalDeptCd}</span>
                  </li>
                </ul>
              </div>
              {/* <AppTextInput label="부서" required disabled /> */}
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성자</label>
                    <span className="text-desc-type1">{regUserNm}</span>
                  </li>
                </ul>
              </div>
              {/* <AppTextInput label="작성자" required disabled /> */}
            </div>
          </div>
        </div>

        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">작성일자</label>
                    <span className="text-desc-type1">{regDttm}</span>
                  </li>
                </ul>
              </div>
              {/* <AppSelect label={'작성일자'} required disabled /> */}
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">평가년도</label>
                    <span className="text-desc-type1">{prtnrREvalEvalYear}</span>
                  </li>
                </ul>
              </div>
              {/* <AppSelect label={'평가년도'} /> */}
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">평가시기</label>
                    <span className="text-desc-type1">{prtnrREvalClsCd}</span>
                  </li>
                </ul>
              </div>
              {/* <AppTextInput label="평가구분" /> */}
            </div>
          </div>
        </div>

        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">협력업체</label>
                    <span className="text-desc-type1">{prtnrId}</span>
                  </li>
                </ul>
              </div>
              {/* <AppSelect label={'작성일자'} required disabled /> */}
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">사업장</label>
                    <span className="text-desc-type1">{bizPlaceClsCd}</span>
                  </li>
                </ul>
              </div>
              {/* <AppSelect label={'평가년도'} /> */}
            </div>
          </div>
        </div>

        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* <AppTextInput label="제목" /> */}
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">제목</label>
                    <span className="text-desc-type1">{prtnrREvalTitle}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : button */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <h3 className="table-tit mb-10">사진 첨부</h3>
              <div className="form-group wid100">
                <AppFileAttach
                  mode="view"
                  fileGroupSeq={prtnrREvalFileId}
                  workScope={'O'}
                  // onlyImageUpload={true}
                  useDetail
                  disabled
                />
              </div>
              {/* <Upload {...props}>
                <div className="btn-area">
                  <button type="button" name="button" className="btn-big btn_text btn-darkblue-line">
                    파일 첨부
                  </button>
                </div>
              </Upload> */}
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>

      {/*//입력영역*/}

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        {/*//하단버튼영역*/}
        {/*그리드영역 */}

        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goFormPage}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          수정
        </button>
        {/* <button type="button" name="button" className="btn_text btn-del">
          삭제
        </button> */}
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          목록으로
        </button>
      </div>
    </>
  );
}
export default RevalPartnerDetail;
