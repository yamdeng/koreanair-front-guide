import useUIStore from '@/stores/useUIStore';
import { useEffect, useState } from 'react';
import { create, useStore } from 'zustand';
import ApiService from '@/services/ApiService';
import { useNavigate } from 'react-router-dom';

/* zustand store 생성 */
const useOccupationPortalStore = create<any>((set, get) => ({
  searchParam: {},
  formValue: {},
  initInfoSearch: async () => {
    const apiParam = {};
    const apiResult = await ApiService.get(`ocu/main-infos`, apiParam);
    set({ formValue: apiResult.data });
  },

  clear: () => {},
}));

function OccupationPortal() {
  const navigate = useNavigate();

  const setIsOccupationPortal = useStore(useUIStore, (state) => state.setIsOccupationPortal);
  const { formValue, initInfoSearch } = useOccupationPortalStore();

  const tabGroups = [
    [
      { id: 'notice', name: '공지사항', path: '/general/notice' },
      { id: 'committee', name: '산업안전보건위원회', path: '/general/committee' },
      { id: 'law', name: '개정법규', path: '/general/lawRegInfo' },
    ],
    [
      { id: 'hazard', name: 'Hazard Report', path: '/hazard/report' },
      { id: 'corrective', name: '시정개선관리', path: '/risk/corrective' },
    ],
    [
      { id: 'accident', name: '재해율', path: '/risk/accident' },
      { id: 'intensity', name: '강도율', path: '/risk/intensity' },
    ],
  ];

  const [activeTabs, setActiveTabs] = useState(['notice', 'hazard', 'accident']); // 초기 활성 탭 설정

  const handleTabClick = (tabGroupIdx, tabId, event) => {
    if (event) {
      event.preventDefault(); // 기본 이벤트 방지
    }

    const newActiveTabs = [...activeTabs]; 
    newActiveTabs[tabGroupIdx] = tabId; 
    setActiveTabs(newActiveTabs); // 상태 업데이트
  };

  // 페이지 이동
  const handleNavigation = (tabId, params, event) => {
    
    if (event) {
      event.preventDefault(); // 기본 이벤트 방지
    }

    const baseURL = '/occupation'; // 기본 URL
    const tab = tabGroups.flat().find((tab) => tab.id === tabId);

    if (tab) {
      const url = `${baseURL}${tab.path}/${params}`;
      navigate(url); 
    } else {
      const url = `${baseURL}${tabId}/${params}`; 
      navigate(url); 
    }
  };

  // 배너 슬라이드
  const BannerSlider = ({ banners }) => {
    const [currentIndex, setCurrentIndex] = useState(0);

    // 슬라이드가 있을 때만 작동
    const nextSlide = () => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % banners.length);
    };

    useEffect(() => {
      // 배너가 없으면 리턴
      if (!banners || banners.length === 0) return;

      const intervalId = setInterval(nextSlide, 3000);
      return () => clearInterval(intervalId);
    }, [banners]);

    // 배너가 없거나 빈 배열일 경우 메시지를 표시
    if (!banners || banners.length === 0) {
      return <div>등록된 내용이 없습니다.</div>;
    }

    return (
      <div className="main-photo">
        <img src={banners[currentIndex].imageurl} alt={banners[currentIndex].title} />
        <h3 className="img-tit">{banners[currentIndex].title}</h3>
        <ul className="main-photo-btn">
          {banners.map((_, index) => (
            <li key={index} className={index === currentIndex ? 'active' : ''}>
              {index + 1}
            </li>
          ))}
        </ul>
      </div>
    );
  };

  // 내 태스크
  const getHTMLTodoList = () => {
    return (
      <table className="main-table">
        <tbody>
          {formValue?.todoList?.map((item, index) => (
            <tr key={index}>
              <th className="type01">
                <a href="#" onClick={(e) => handleNavigation('', item.link, e)}>
                  [{item.jobNm}] {item.title}
                </a>
              </th>
              <td>{item.regDttm}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  // KSMS 사이렌
  const getHTMLSirenList = () => {
    return (
      <table className="main-table">
        <tbody>
          {formValue?.sirenList?.map((item, index) => (
            <tr key={index}>
              <th className="type01">
                <a href="#" onClick={(e) => handleNavigation('/general/notice', item.noticeId, e)}>
                  {item.noticeTitle}
                </a>
                <span className="date">{item.regDttm}</span>
              </th>
              <td className="part">{item.sectNm}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  // 상태에 따라 클래스 이름을 반환하는 함수
  const getWorkPermitStatusClassName = (status) => {
    switch (status) {
      case 'I':
        return 'ing';
      case 'W':
        return 'wait';
      case 'E':
        return 'expected';
      case 'F':
        return 'complete';
      default:
        return '';
    }
  };

  // 작업허가 현황
  const getHTMLWorkPermit = () => {
    return (
      <ul className="Status">
        {formValue?.workPermitList?.map((item, index) => {
          const className = getWorkPermitStatusClassName(item.wrkStatusCd);

          return (
            <li className={`${className}-bar`} key={index}>
              <a href="#" onClick={(e) => handleNavigation('/management/permits', item.cntrId, e)}>
                <p>{item.cntrNm}</p>
              </a>
              <span className="part">{item.sectNm}</span>
              <span className={className}>{item.wrkStatusNm}</span>
            </li>
          );
        })}
      </ul>
    );
  };

  // 탭 그룹 제목
  const getHTMLTabGroupTitle = (tabGroupIdx) => {
    const currentTabGroup = tabGroups[tabGroupIdx]; 
    const activeTabId = activeTabs[tabGroupIdx]; 

    return (
      <ul className="main-tab">
        {currentTabGroup.map((tab) => (
          <li key={tab.id}>
            <a href="#" onClick={(event) => handleTabClick(tabGroupIdx, tab.id, event)} className={activeTabId === tab.id ? 'active' : ''}>
              {tab.name}
            </a>
          </li>
        ))}
      </ul>
    );
  };

  // TODO 향후 내용이 많으면 Component로 뺄까?
  // 탭0 (공지사항, 산업안전보건위원회, 개정법규)
  // 탭1 (Hazard Report, 시정개선관리)
  // 탭2 (재해율, 강도율)
  const getHTMLTabGroupContents = (tabGroupIdx) => {
    const tabId = activeTabs[tabGroupIdx];
  
    switch (tabId) {
      case 'notice':
        return (
          <table className="main-table">
            <tbody>
              {formValue?.noticeList?.map((item, index) => (
                <tr key={index}>
                  <th className="type01">
                    <a href="#" onClick={(e) => handleNavigation(tabId, item.noticeId, e)}>
                      [{item.sectNm}] {item.noticeTitle}
                    </a>
                    <span className="date">{item.regDttm}</span>
                  </th>
                  <td className="name">관리자</td>
                </tr>
              ))}
            </tbody>
          </table>
        );
      case 'committee':
        return (
          <table className="main-table">
            <tbody>
              {formValue?.committeeList?.map((item, index) => (
                <tr key={index}>
                  <th className="type01">
                    <a href="#" onClick={(e) => handleNavigation(tabId, item.ocuCommitId, e)}>
                      [{item.sectNm}] {item.title}
                    </a>
                    <span className="date">{item.regDttm}</span>
                  </th>
                  <td className="name">관리자</td>
                </tr>
              ))}
            </tbody>
          </table>
        );
      case 'law':
        return (
          <table className="main-table">
            <tbody>
              {formValue?.lawList?.map((item, index) => (
                <tr key={index}>
                  <th className="type01">
                    <a href="#" onClick={(e) => handleNavigation(tabId, item.lawSeq, e)}>
                      {item.lawNm}
                    </a>
                    <span className="date">{item.regDttm}</span>
                  </th>
                  <td className="name">{item.aprvStatNm}</td>
                </tr>
              ))}
            </tbody>
          </table>
        );

      case 'hazard':
        return (
          <>
            <div className="main-graph">
              <div className="main-graph-group">
                <ul className="main-graph-tit">
                  <li>전체</li>
                  <li className="graph-low-bg">
                    <span className="txt-low">10%</span>
                  </li>
                </ul>
                <meter
                  className="main-graph-meter"
                  min={0}
                  max={100}
                  low={30}
                  high={79}
                  optimum={100}
                  value={10}
                ></meter>
              </div>
              <div className="main-graph-group">
                <ul className="main-graph-tit">
                  <li>정비</li>
                  <li className="graph-high-bg">
                    <span className="txt-high">30%</span>
                  </li>
                </ul>
                <meter
                  className="main-graph-meter"
                  min={0}
                  max={100}
                  low={30}
                  high={79}
                  optimum={100}
                  value={30}
                ></meter>
              </div>
              <div className="main-graph-group">
                <ul className="main-graph-tit">
                  <li>항공우주</li>
                  <li className="graph-optimum-bg">
                    <span className="txt-optimum">88%</span>
                  </li>
                </ul>
                <meter
                  className="main-graph-meter"
                  min={0}
                  max={100}
                  low={30}
                  high={79}
                  optimum={100}
                  value={88}
                ></meter>
              </div>
              <div className="main-graph-group">
                <ul className="main-graph-tit">
                  <li>여객</li>
                  <li className="graph-optimum-bg">
                    <span className="txt-optimum">100%</span>
                  </li>
                </ul>
                <meter
                  className="main-graph-meter"
                  min={0}
                  max={100}
                  low={30}
                  high={79}
                  optimum={100}
                  value={100}
                ></meter>
              </div>
              <div className="main-graph-group">
                <ul className="main-graph-tit">
                  <li>화물</li>
                  <li className="graph-optimum-bg">
                    <span className="txt-optimum">70%</span>
                  </li>
                </ul>
                <meter
                  className="main-graph-meter"
                  min={0}
                  max={100}
                  low={30}
                  high={79}
                  optimum={100}
                  value={70}
                ></meter>
              </div>
              <div className="main-graph-group">
                <ul className="main-graph-tit">
                  <li>객실</li>
                  <li className="graph-low-bg">
                    <span className="txt-low">5%</span>
                  </li>
                </ul>
                <meter
                  className="main-graph-meter"
                  min={0}
                  max={100}
                  low={30}
                  high={79}
                  optimum={100}
                  value={5}
                ></meter>
              </div>
            </div>
          </>
        );

      case 'corrective':
        return <>시정개선관리 내용</>;
      case 'accident':
        return <>재해율 내용</>;
      case 'intensity':
        return <>강도율 내용</>;
      default:
        return null;
    }
  };

  useEffect(() => {
    setIsOccupationPortal(true);
    initInfoSearch();
    return () => {
      setIsOccupationPortal(false);
    };
  }, []);

  return (
    <>
      <div className="main-wrap">

        {/* 내 태스크 */}
        <div className="grid-item">
          <h3>내 태스크</h3>
          <div className="main-table-box">{getHTMLTodoList()}</div>
        </div>

        {/* 배너 */}
        <div className="grid-item">
          <div className="main-table-box">
            <BannerSlider banners={formValue?.bannerList || []} />
          </div>
        </div>

        {/* 작업허가현황 */}
        <div className="grid-item">
          <h3>작업허가현황</h3>
          <div>{getHTMLWorkPermit()}</div>
        </div>

        {/* 탭1 */}
        <div className="grid-item">
          <h3>{getHTMLTabGroupTitle(0)}</h3>
          <div className="main-table-box">{getHTMLTabGroupContents(0)}</div>
        </div>

        {/* 사이렌 */}
        <div className="grid-item">
          <h3>
            <span className="siren">아이콘</span>KSMS 사이렌
          </h3>
          <div className="main-table-box">{getHTMLSirenList()}</div>
        </div>

        {/* 탭2 */}
        <div className="grid-item">
          <h3>{getHTMLTabGroupTitle(1)}</h3>
          <div className="main-table-box">{getHTMLTabGroupContents(1)}</div>
        </div>

        {/* 탭3 */}
        <div className="grid-item">
          <h3>{getHTMLTabGroupTitle(2)}</h3>
          <div className="main-table-box">{getHTMLTabGroupContents(2)}</div>
        </div>
        
      </div>
    </>
  );
}

export default OccupationPortal;
