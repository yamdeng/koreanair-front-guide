import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppNavigation from '@/components/common/AppNavigation';
import AppSelect from '@/components/common/AppSelect';
import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
import chartasr from '@/resources/images/ASR-box.svg';
import ApiService from '@/services/ApiService';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import dayjs from 'dayjs';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { create } from 'zustand';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/assurance/changes',
  baseRoutePath: '/aviation/changes/ChangeManageEdit',
};

/* zustand store 생성 */
const useChangeManageListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),
  ...initListData,
  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    changeMgmtYear: '' + dayjs().year(),
    subjectNm: '',
    fromDt: dayjs().format('YYYY-MM-DD'),
    toDt: dayjs().format('YYYY-MM-DD'),
    searchDivisionCdarr: [],
    changeMgmtStatusCd: '20',
  },

  changeMgmtStatusCdList: [],

  changeMgmtStatusCodeSearch: async () => {
    const apiResult = await ApiService.get(`com/code-groups/CODE_GRP_327/codes`);

    const codeData = apiResult.data.filter((info) => info.codeId !== '10');

    set({ changeMgmtStatusCdList: codeData });
  },

  //초기화 버튼 클릭 시 검색 조건 초기화
  initSearchInput: () => {
    set({
      searchParam: {
        changeMgmtYear: '' + dayjs().year(),
        subjectNm: '',
        fromDt: dayjs().format('YYYY-MM-DD'),
        toDt: dayjs().format('YYYY-MM-DD'),
        searchDivisionCdarr: [],
      },
    });
  },

  rowData: {},

  isRowData: (rowData) => {
    set({ rowData: rowData });
  },
  clear: () => {},
}));

function ChangeManageList() {
  const state = useChangeManageListStore();
  const { t } = useTranslation();

  const {
    enterSearch,
    searchParam,
    list,
    changeSearchInput,
    clear,
    rowData,
    isRowData,
    changeMgmtStatusCdList,
    changeMgmtStatusCodeSearch,
  } = state;

  const { changeMgmtYear, subjectNm, fromDt, toDt, searchDivisionCdarr, changeMgmtStatusCd } = searchParam;

  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번', width: 50, cellStyle: { textAlign: 'center' } },
      { field: 'subjectNm', headerName: '변화관리 주제명', width: 350, cellStyle: { textAlign: 'left' } },
      { field: 'changeMgmtStatusNm', headerName: '진행상태', width: 100, cellStyle: { textAlign: 'center' } },
      {
        headerName: '일정',
        groupId: 'groupDate',
        cellStyle: { textAlign: 'center' },
        children: [
          {
            field: 'fromDt',
            headerName: '시작일자',
            width: 150,
            cellStyle: { textAlign: 'center' },
          },
          {
            field: 'toDt',
            headerName: '종료일자',
            width: 150,
            cellStyle: { textAlign: 'center' },
          },
          {
            headerName: '남은일정',
            width: 150,
            cellStyle: { textAlign: 'center' },
            valueGetter: (p) => {
              let rtnVal = '';
              const diffCnt = dayjs(p.data.toDt).diff(dayjs(), 'days');
              if (diffCnt > -1) rtnVal = 'D-' + diffCnt;
              else rtnVal = 'D+' + diffCnt;
              return rtnVal;
            },
          },
        ],
      },
    ])
  );

  const [columns2, setColumns2] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'Doc No.', headerName: 'Doc No.', width: 50, cellStyle: { textAlign: 'center' } },
      { field: 'Hazard', headerName: 'Hazard', width: 350, cellStyle: { textAlign: 'left' } },
      {
        field: 'Potential Consequence',
        headerName: 'Potential Consequence',
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      { field: '소관 부문', headerName: '소관 부문', width: 200, cellStyle: { textAlign: 'center' } },
      { field: '평가자', headerName: '평가자', width: 100, cellStyle: { textAlign: 'center' } },
      { field: '진행상태', headerName: '진행상태', width: 100, cellStyle: { textAlign: 'center' } },
      { field: '1차 위험평가', headerName: '1차 위험평가', width: 100, cellStyle: { textAlign: 'center' } },
      { field: '2차 위험평가', headerName: '2차 위험평가', width: 100, cellStyle: { textAlign: 'center' } },
    ])
  );

  const searchChangeManageDetail = useCallback((selectedInfo) => {
    isRowData(selectedInfo.data);
    console.log(selectedInfo.data);
  }, []);

  useEffect(() => {
    enterSearch();
    changeMgmtStatusCodeSearch();
    return clear;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>변화관리</h2>
      </div>

      {/*검색영역 */}
      <div className="boxForm">
        <div className="form-table">
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <div className="row1">
                <div className="date1">
                  <AppDatePicker
                    label="기준연도"
                    value={changeMgmtYear}
                    onChange={(value) => {
                      changeSearchInput('changeMgmtYear', value);
                    }}
                    pickerType="year"
                    required
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                label="변화관리주제명"
                value={subjectNm}
                search={enterSearch}
                onChange={(value) => {
                  changeSearchInput('subjectNm', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppSelect
                label={'진행상태'}
                codeGrpId="CODE_GRP_327"
                labelKey={'codeNameKor'}
                valueKey={'codeId'}
                options={changeMgmtStatusCdList}
                value={changeMgmtStatusCd}
                onChange={(value) => {
                  changeSearchInput('changeMgmtStatusCd', value);
                }}
              />
            </div>
          </div>
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppCodeSelect
                label={'부문'}
                codeGrpId="CODE_GRP_326"
                value={searchDivisionCdarr}
                isMultiple={true}
                onChange={(value) => {
                  changeSearchInput('searchDivisionCdarr', value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="form-table">
          {' '}
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="df">
                <div className="date1">
                  <AppDatePicker
                    id="searchDateFrom"
                    label={t('ke_change_mgmt_label_00556')}
                    pickerType="date"
                    value={fromDt}
                    onChange={(value) => {
                      changeSearchInput('fromDt', value);
                    }}
                    required
                  />
                </div>
                <span className="unt">~</span>
                <div className="date2">
                  <AppDatePicker
                    id="searchDateTo"
                    label={t('ke_report_label_00203')}
                    pickerType="date"
                    value={toDt}
                    onChange={(value) => {
                      changeSearchInput('toDt', value);
                    }}
                    required
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="btn-area">
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={clear}>
                초기화
              </button>
              <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                조회
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          handleRowSingleClick={searchChangeManageDetail}
          displayCSVExportButton={true}
        />
      </div>
      {/*//그리드영역 */}

      {/*진행률 */}
      <div className="chart-wrap">
        <div className="chart-box">
          <img src={chartasr} className="" alt="ASR" />
        </div>
        <div className="chart-box">
          <img src={chartasr} className="" alt="ASR" />
        </div>
        <div className="chart-box">
          <img src={chartasr} className="" alt="ASR" />
        </div>
        <div className="chart-box">
          <img src={chartasr} className="" alt="ASR" />
        </div>
        <div className="chart-box">
          <img src={chartasr} className="" alt="ASR" />
        </div>
        <div className="chart-box">
          <img src={chartasr} className="" alt="ASR" />
        </div>
        <div className="chart-box">
          <img src={chartasr} className="" alt="ASR" />
        </div>
        <div className="chart-box">
          <img src={chartasr} className="" alt="ASR" />
        </div>
      </div>
      {/*그리드영역 */}
      <div className="">
        <AppTable rowData={list} columns={columns2} />
      </div>
      {/*//그리드영역 */}
    </>
  );
}

export default ChangeManageList;
