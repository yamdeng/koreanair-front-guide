import AppTable from '@/components/common/AppTable';
import {
  eventTabGrd1Store,
  eventTabGrd2Store,
  eventTabGrd3Store,
  eventTabGrd4Store,
  useSmsIntgrAnlysDashBoardStore,
} from '@/stores/aviation/assurance/smsComprehensive/useSmsIntgrAnlysDashBoardStore';
import CommonUtil from '@/utils/CommonUtil';
import { useState } from 'react';

function TopEventList() {
  // PotencialConListStore 에서 정의된 메소드 사용 시 이곳에서 분해할당
  const mainState = useSmsIntgrAnlysDashBoardStore();
  const eventTabGrd1StoreState = eventTabGrd1Store();
  const eventTabGrd2StoreState = eventTabGrd2Store();
  const eventTabGrd3StoreState = eventTabGrd3Store();
  const eventTabGrd4StoreState = eventTabGrd4Store();

  function goEventDetail(params) {
    return (
      <div className="Safety-table-cell tr">
        <a
          href="#"
          onClick={() => {
            mainState.openReport('event', params.data);
          }}
        >
          {Number(params.value).toLocaleString()}
        </a>
      </div>
    );
  }

  function goSummaryDetailInfo(params) {
    return (
      <div className="Safety-table-cell">
        <a
          href="#"
          onClick={() => {
            eventTabGrd1StoreState.selectSummaryRowInfo(params.data);
          }}
        >
          {params.value}
        </a>
      </div>
    );
  }

  const [columns1, setColumns1] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호', width: 50, cellStyle: { textAlign: 'center' } },
      {
        field: 'col01',
        headerName: 'Top Event',
        width: 350,
        cellStyle: { textAlign: 'left' },
      },
      {
        field: 'col02',
        headerName: '보고서 건수',
        width: 50,
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'col03',
        headerName: 'Risk',
        width: 100,
        cellStyle: { textAlign: 'right' },
        valueFormatter: (p) => Number(p.value).toLocaleString(),
      },
    ])
  );

  const [columns2, setColumns2] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '번호', width: 50, cellStyle: { textAlign: 'center' } },
      { field: 'col01', headerName: '레포트 유형', width: 100, cellStyle: { textAlign: 'center' } },
      {
        field: 'col02',
        headerName: '제목',
        cellStyle: { textAlign: 'left' },
        width: 300,
      },
    ])
  );

  return (
    <>
      {/*대시보드*/}
      <div className="DashBoardWrap">
        <div className="DashBoard-chart">
          <div className="DashBoard-row">
            <div className="DashBoard-col">
              <p className="h4">Top 10 Event Risk</p>
              <div className="DashBoard-box">
                <AppTable
                  rowData={eventTabGrd1StoreState.list}
                  columns={columns1}
                  store={eventTabGrd1StoreState}
                  hiddenTableHeader={true}
                  hiddenPagination
                />
              </div>
            </div>
          </div>
          <div className="DashBoard-row">
            <div className="DashBoard-col">
              <p className="h4">Event : Injury (Cabin crew)</p>
              <div className="DashBoard-box">
                <AppTable
                  rowData={eventTabGrd2StoreState.list}
                  columns={columns2}
                  store={eventTabGrd2StoreState}
                  hiddenTableHeader={true}
                  hiddenPagination
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*//대시보드 */}
    </>
  );
}

export default TopEventList;
