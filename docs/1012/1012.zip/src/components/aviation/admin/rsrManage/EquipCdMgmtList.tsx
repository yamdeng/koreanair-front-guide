import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import { useTranslation } from 'react-i18next';
import AppSelect from '@/components/common/AppSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/rsr/equipments',
  baseRoutePath: '/aviation/rsrManage/EquipCodeMgmt',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  equipCd: '', // 장비코드
  equipNm: '', // 장비명
  modelNm: '', // 모델명
  companyTypeCd: '', // 자사구분
  divisionCd: '', // 부서
  companyNm: '', // 업체명
  useYn: '', // 사용여부
};

/* zustand store 생성 */
const AvnEquipCodeMgmtListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    equipCd: '', // 장비코드
    equipNm: '', // 장비명
    modelNm: '', // 모델명
    companyTypeCd: '', // 자사구분
    divisionCd: '', // 부서
    companyNm: '', // 업체명
    useYn: '', // 사용여부
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function EquipCdMgmtList() {
  const { t } = useTranslation();
  const state = AvnEquipCodeMgmtListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번' },
      { field: 'equipCd', headerName: '장비코드' },
      { field: 'equipNm', headerName: '장비명' },
      { field: 'modelNm', headerName: '모델명' },
      { field: 'companyTypeCd', headerName: '자사구분' },
      { field: 'divisionCd', headerName: '부서' },
      { field: 'companyNm', headerName: '업체명' },
      { field: 'productionDt', headerName: '제작일자' },
      { field: 'useYn', headerName: '사용여부' },
      { field: 'regUserId', headerName: '등록자' },
      { field: 'regDttm', headerName: '등록일자' },
      { field: 'updUserId', headerName: '수정자' },
      { field: 'updDttm', headerName: '수정일자' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    toggleExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;
  // TODO : 검색 파라미터 나열
  const { equipCd, equipNm, modelNm, companyTypeCd, divisionCd, companyNm, useYn } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.equipCd;
    goDetailPage(detailId);
  }, []);

  const customButtons = [
    {
      title: '양식 다운로드',
      onClick: () => {
        alert('준비중입니다.');
      },
    },
    {
      title: '양식 업로드',
      onClick: () => {
        alert('준비중입니다.');
      },
      iconClass: 'icon-fields',
    },
  ];

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>장비코드 관리</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppSearchInput
                  label="장비코드"
                  value={equipCd}
                  onChange={(value) => {
                    changeSearchInput('equipCd', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppSearchInput
                  label="장비명"
                  value={equipNm}
                  onChange={(value) => {
                    changeSearchInput('equipNm', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppSearchInput
                  label="모델명"
                  value={modelNm}
                  onChange={(value) => {
                    changeSearchInput('modelNm', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppSelect
                  label="자사구분"
                  value={companyTypeCd}
                  applyAllSelect
                  options={[
                    { label: '자사', value: '1' },
                    { label: '타사', value: '2' },
                  ]}
                  onChange={(value) => {
                    changeSearchInput('companyTypeCd', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_170"
                  label="부서"
                  value={divisionCd}
                  applyAllSelect
                  onChange={(value) => {
                    changeSearchInput('divisionCd', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid40">
              <div className="form-group wid100">
                <AppSearchInput
                  label="업체명"
                  value={companyNm}
                  onChange={(value) => {
                    changeSearchInput('companyNm', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid30">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_146"
                  applyAllSelect
                  label="사용여부"
                  value={useYn}
                  onChange={(value) => {
                    changeSearchInput('useYn', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="btn-area">
                <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                  {t('ke.safety.common.label.00002')}
                </button>
                <button
                  type="button"
                  name="button"
                  className="btn-sm btn_text btn-darkblue-line"
                  onClick={initSearchInput}
                >
                  {t('ke.safety.common.label.00003')}
                </button>
              </div>
            </div>
          </div>
        </div>
        <button
          type="button"
          name="button"
          className={isExpandDetailSearch ? 'arrow button _control active' : 'arrow button _control'}
          onClick={toggleExpandDetailSearch}
        >
          <span className="hide">{t('ke.safety.common.label.00009')}</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
        customButtons={customButtons}
        displayCSVExportButton
      />
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
    </>
  );
}

export default EquipCdMgmtList;
