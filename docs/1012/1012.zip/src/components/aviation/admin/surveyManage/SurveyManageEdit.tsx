import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { FORM_TYPE_ADD } from '@/config/CommonConstant';
import AppTextInput from '@/components/common/AppTextInput';
import AppNavigation from '@/components/common/AppNavigation';
import { useTranslation } from 'react-i18next';
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import AppDatePicker from '@/components/common/AppDatePicker';
import dayjs from 'dayjs';

/* yup validation */
const yupFormSchema = yup.object({
  popupFromDt: yup.string().required('개정일자는 필수 입력 항목입니다.'),
  subjectKoNm: yup.string().required('설문제목은 필수 입력 항목입니다.'),
  linkKoNm: yup.string().required('설문링크는 필수 입력 항목입니다.'),
  linkEnNm: yup.string().required('답변링크는 필수 입력 항목입니다.'),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  boardTypeCd: '140',
  popupFromDt: dayjs().format('YYYY-MM-DD'),
  subjectKoNm: '',
  linkKoNm: 'https://' + '',
  linkEnNm: 'https://' + '',

  // 필수값
  popupToDt: '9999-99-99',
  useYn: 'Y',
  popupYn: 'N',
  viewYn: 'Y',
  topFixYn: 'N',
  mainShowYn: 'N',
  viewCo: 0,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/board/board',
  baseRoutePath: '/aviation/surveyManage/survey',
  formName: 'AvnSurveyManageFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const AvnSurveyManageFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue }, formType: FORM_TYPE_ADD });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SurveyManageEdit() {
  const { t } = useTranslation();
  const { errors, changeInput, getDetail, formType, formValue, isDirty, save, remove, cancel, clear } =
    AvnSurveyManageFormStore();
  const { subjectKoNm, popupFromDt, linkKoNm, linkEnNm } = formValue;
  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>안전문화설문관리 {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid30">
              <AppDatePicker
                id="AvnSurveyManageFormStorepopupFromDt"
                name="popupFromDt"
                label="개정일자"
                value={popupFromDt}
                onChange={(value) => changeInput('popupFromDt', value)}
                errorMessage={errors.popupFromDt}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnSurveyManageFormStoresubjectKoNm"
                name="subjectKoNm"
                label="설문제목"
                value={subjectKoNm}
                onChange={(value) => changeInput('subjectKoNm', value)}
                errorMessage={errors.subjectKoNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnSurveyManageFormStorelinkKoNm"
                name="linkKoNm"
                label="설문링크"
                value={linkKoNm}
                onChange={(value) => changeInput('linkKoNm', value)}
                errorMessage={errors.linkKoNm}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnSurveyManageFormStorelinkEnNm"
                name="linkEnNm"
                label="답변링크"
                value={linkEnNm}
                onChange={(value) => changeInput('linkEnNm', value)}
                errorMessage={errors.linkEnNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
    </>
  );
}
export default SurveyManageEdit;
