import AppTable from '@/components/common/AppTable';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import dayjs from 'dayjs';
import AppSearchInput from '@/components/common/AppSearchInput';
import { useTranslation } from 'react-i18next';
//import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppCodeSelect from '@/components/common/AppCodeSelect';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/instructors',
  baseRoutePath: '/aviation/instructorsManage/instructors',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  fromDate: dayjs().format('YYYY-MM-DD'),
  toDate: dayjs().format('YYYY-MM-DD'),
  //  emplymentDt: '', // 임용일자 FROM ~ 임용일자 TO
  nameKor: '', // 강사명
  employmentTypeCd: '',
  imploymentYn: '', // 임용여부 YN
};

/* zustand store 생성 */
const AvnInstructorHistListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    fromDate: dayjs().format('YYYY-MM-DD'),
    toDate: dayjs().format('YYYY-MM-DD'),
    //  emplymentDt: '', // 임용일자 FROM ~ 임용일자 TO
    nameKor: '', // 강사명
    employment_type_cd: '',
    imploymentYn: '', // 임용여부 YN
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function InstructorHistList() {
  const { t } = useTranslation();
  const state = AvnInstructorHistListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번' },
      { field: 'emplymentDt', headerName: '임용일자' },
      { field: 'deptId', headerName: '부서' },
      { field: 'userId', headerName: '강사ID' },
      { field: 'nameKor', headerName: '강사명' },
      { field: 'imploymentYn', headerName: '임용여부' },
      { field: 'regUserId', headerName: '등록자' },
      { field: 'regDttm', headerName: '등록일시' },
      { field: 'updUserId', headerName: '수정자' },
      { field: 'updDttm', headerName: '수정일시' },
    ])
  );
  const {
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    initSearchInput,
    isExpandDetailSearch,
    clear,
    goDetailPage,
  } = state;
  // TODO : 검색 파라미터 나열
  const { fromDate, toDate, nameKor, imploymentYn } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    const data = selectedInfo.data;
    const detailId = data.boardId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>강사이력관리</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group form-glow">
                <div className="df">
                  <div className="date1">
                    <AppDatePicker
                      label={t('ke_change_mgmt_label_00556')}
                      pickerType="date"
                      value={fromDate}
                      onChange={(value) => {
                        changeSearchInput('fromDate', value);
                      }}
                    />
                  </div>
                  <span className="unt">~</span>
                  <div className="date2">
                    <AppDatePicker
                      label={t('ke_report_label_00203')}
                      pickerType="date"
                      value={toDate}
                      onChange={(value) => {
                        changeSearchInput('toDate', value);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Popup창 띄워서 검색 */}
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSearchInput
                  label="강사명"
                  value={nameKor}
                  onChange={(value) => {
                    changeSearchInput('nameKor', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>

            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_176"
                  applyAllSelect
                  label={'임용여부'}
                  value={imploymentYn}
                  onChange={(value) => {
                    changeSearchInput('imploymentYn', value);
                  }}
                  search={imploymentYn}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="btn-area">
                <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                  {t('ke.safety.common.label.00002')}
                </button>
                <button
                  type="button"
                  name="button"
                  className="btn-sm btn_text btn-darkblue-line"
                  onClick={initSearchInput}
                >
                  {t('ke.safety.common.label.00003')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          handleRowDoubleClick={handleRowDoubleClick}
        />
      </div>
      <div className="contents-btns">
        {/* TODO : 버튼 목록 정의 */}
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
    </>
  );
}

export default InstructorHistList;
