import { useEffect } from 'react';
import { useParams } from 'react-router-dom';

import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import { useTranslation } from 'react-i18next';

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  // formApiPath: 'avn/admin/board/notices',
  // baseRoutePath: '/aviation/maintenance-manage/notices',
  formApiPath: 'avn/admin/instructors',
  baseRoutePath: '/aviation/instructorsManage/instructors',
};

/* zustand store 생성 */
const AvnInstructorHistDetailStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function InstructorHistDetail() {
  // 언어 설정
  const { t } = useTranslation();

  /* formStore state input 변수 */
  const { detailInfo, getDetail, formType, cancel, goFormPage, clear } = AvnInstructorHistDetailStore();
  const { emplymentDt, nameKor, employmentTypeCd, imploymentYn, notesCn, linkGroupSeq, fileGroupSeq } = detailInfo;

  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>강사이력관리 상세</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">임용일자</label>
                    <span className="text-desc-type1">{emplymentDt}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">강사명</label>
                    <span className="text-desc-type1">{nameKor}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">임용구분</label>
                    <span className="text-desc-type1">{employmentTypeCd}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">임용여부</label>
                    <span className="text-desc-type1">{imploymentYn}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">메모내용</label>
                    <span className="text-desc-type1">{notesCn}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">링크그룹SEQ</label>
                    <span className="text-desc-type1">{linkGroupSeq}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">{t('ke.safety.Notice.label.00007')}</label>
                    <span className="text-desc-type1">
                      <AppFileAttach mode="view" onlyImageUpload={true} fileGroupSeq={fileGroupSeq} disabled={true} />
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          {t('ke.safety.common.label.00006')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={goFormPage}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00007')}
        </button>
      </div>
      {/* //하단 버튼 영역 */}
    </>
  );
}
export default InstructorHistDetail;
