import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import Code from '@/config/Code';
import AppNavigation from '@/components/common/AppNavigation';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import { useTranslation } from 'react-i18next';
import AppSelect from '@/components/common/AppSelect';
import { FORM_TYPE_UPDATE } from '@/config/CommonConstant';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/criteria/consequences',
  baseRoutePath: '/aviation/criteriaManage/potential-consequence',
};

const initSearchParam = {
  reportTypeCd: '',
  consequenceKoNm: '',
  consequenceEnNm: '',
  useYn: '',
  notesCn: '',
};

/* zustand store 생성 */
const ConsequenceListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    reportTypeCd: '',
    consequenceKoNm: '',
    consequenceEnNm: '',
    useYn: '',
    notesCn: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

// Potencial Consequence component
function PotentialConList() {
  const { t } = useTranslation();
  const state = ConsequenceListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'num', headerName: '순번' },
      { field: 'reportTypeCd', headerName: '리포트 구분' },
      { field: 'consequenceKoNm', headerName: '잠재적결과(KOR)' },
      { field: 'consequenceEnNm', headerName: '잠재적결과(ENG)' },
      { field: 'useYn', headerName: '사용여부' },
      { field: 'notesCn', headerName: '비고' },
      { field: 'regUserId', headerName: '등록자' },
      { field: 'regDttm', headerName: '등록일' },
      { field: 'updUserId', headerName: '수정자' },
      { field: 'updDttm', headerName: '수정일' },
    ])
  );
  // PotencialConListStore 에서 정의된 메소드 사용 시 이곳에서 분해할당
  const {
    initSearchInput,
    enterSearch,
    searchParam,
    list,
    goAddPage,
    changeSearchInput,
    isExpandDetailSearch,
    clear,
    goDetailPage,
    formType,
  } = state;

  // input value에 넣기 위한 분리 선언
  const { reportTypeCd, consequenceKoNm, consequenceEnNm, useYn, notesCn } = searchParam;

  // 더블클릭 시 상세페이지 또는 모달페이지 오픈
  const handleRowDoubleClick = useCallback((selectedInfo) => {
    // console.log(selectedInfo);
    const data = selectedInfo.data;
    const detailId = data.consequenceId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/* TODO : 헤더 영역입니다 */}
      <div className="conts-title">
        <h2>Potential Consequence 관리</h2>
      </div>
      {/* TODO : 검색 input 영역입니다 */}
      <div className="boxForm">
        <div id="" className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  // codeGrpId="CODE_GRP_092"
                  codeGrpId="CODE_GRP_148"
                  applyAllSelect
                  label={t('ke.safety.Notice.label.00001')}
                  disabled={formType === FORM_TYPE_UPDATE ? true : false}
                  value={reportTypeCd}
                  onChange={(value) => {
                    changeSearchInput('reportTypeCd', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={'잠재적결과(KOR)'}
                  value={consequenceKoNm}
                  onChange={(value) => {
                    changeSearchInput('consequenceKoNm', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label={'잠재적결과(ENG)'}
                  value={consequenceEnNm}
                  onChange={(value) => {
                    changeSearchInput('consequenceEnNm', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppSelect
                  label={'사용여부'}
                  applyAllSelect
                  options={Code.useYn}
                  value={useYn}
                  onChange={(value) => {
                    changeSearchInput('useYn', value);
                  }}
                />
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppTextInput
                  label={'비고'}
                  value={notesCn}
                  onchange={(value) => {
                    changeSearchInput('notesCn', value);
                  }}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              {t('ke.safety.common.label.00002')}
            </button>
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={initSearchInput}>
              {t('ke.safety.common.label.00003')}
            </button>
          </div>
        </div>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
    </>
  );
}

export default PotentialConList;
