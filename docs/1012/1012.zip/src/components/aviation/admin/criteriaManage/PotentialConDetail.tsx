import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import CodeSerivce from '@/services/CodeService';
import AppNavigation from '@/components/common/AppNavigation';
import { useTranslation } from 'react-i18next';
/* store  */
import { create } from 'zustand';
import { formBaseState, createFormSliceYup } from '@/stores/slice/formSlice';
import CodeService from '@/services/CodeService';

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/criteria/consequences',
  baseRoutePath: '/aviation/criteriaManage/potential-consequence',
  formName: 'KeConsequenceDetailStore',
  formValue: {
    reportTypeCd: '',
    consequenceKoNm: '',
    consequenceEnNm: '',
    useYn: '',
    // notes: '',
  },
};

/* zustand store 생성 */
const KeConsequenceDetailStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  clear: () => {
    set({ ...formBaseState });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function PotentialConDetail() {
  const { t } = useTranslation();
  const { detailInfo, getDetail, cancel, goFormPage, clear } = KeConsequenceDetailStore();
  const { reportTypeCd, consequenceKoNm, consequenceEnNm, useYn, notesCn } = detailInfo;
  const { detailId } = useParams();

  useEffect(() => {
    getDetail(detailId);
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>Potential Consequence 상세</h2>
      </div>
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid30">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      리포트 구분 <span className="required"></span>
                    </label>
                    <span className="text-desc">{CodeService.getCodeLabelByValue('CODE_GRP_148', reportTypeCd)}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      잠제적결과(KOR) <span className="required"></span>
                    </label>
                    <span className="text-desc-type1">{consequenceKoNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      잠제적결과(ENG) <span className="required"></span>
                    </label>
                    <span className="text-desc-type1">{consequenceEnNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>

        <div className="form-table line">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">
                      사용여부 <span className="required"></span>
                    </label>
                    <span className="text-desc-type1">{CodeSerivce.getCodeLabelByValue('CODE_GRP_146', useYn)}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">비고</label>
                    <span className="text-desc-type1">{notesCn}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>

      {/* 하단 버튼 영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          {t('ke.safety.common.label.00006')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          {t('ke.safety.common.label.00007')}
        </button>
      </div>
    </>
  );
}
export default PotentialConDetail;
