import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import CodeSerivce from '@/services/CodeService';
import AppNavigation from '@/components/common/AppNavigation';
import ApiService from '@/services/ApiService';
import { useTranslation } from 'react-i18next';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function EventTypeDetail() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [detailInfo, setDetailInfo] = useState<any>({});
  const { reportTypeCd, eventNm, useYn, notesCn } = detailInfo;
  const { detailId } = useParams();

  const cancel = () => {
    navigate(-1);
  };

  const goFormPage = () => {
    navigate(`/aviation/criteriaManage/event-types/${detailId}/edit`);
  };

  useEffect(() => {
    // swagger에서 상세조회 후 Curl에 url복사
    ApiService.get(`avn/admin/criteria/event-types/${detailId}`).then((apiResult) => {
      const detailInfo = apiResult.data || {};
      setDetailInfo(detailInfo);
    });
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>Event Type 상세</h2>
      </div>
      <div className="editbox">
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">리포트 구분</label>
                    <span className="text-desc-type1">
                      {CodeSerivce.getCodeLabelByValue('CODE_GRP_092', reportTypeCd)}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">이벤트명</label>
                    <span className="text-desc-type1">{eventNm}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>

        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">사용여부</label>
                    <span className="text-desc-type1">{CodeSerivce.getCodeLabelByValue('CODE_GRP_146', useYn)}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <div className="box-view-list">
                <ul className="view-list">
                  <li className="accumlate-list">
                    <label className="t-label">비고</label>
                    <span className="text-desc-type1">{notesCn}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={cancel}>
          {t('ke.safety.common.label.00006')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={goFormPage}>
          {t('ke.safety.common.label.00007')}
        </button>
      </div>
    </>
  );
}
export default EventTypeDetail;
