import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppTable from '@/components/common/AppTable';
import AppTextInput from '@/components/common/AppTextInput';
import CodeLabelComponent from '@/components/common/CodeLabelComponent';
import Code from '@/config/Code';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import CommonUtil from '@/utils/CommonUtil';
import { useCallback, useEffect, useState } from 'react';
import { create } from 'zustand';
// import useAppStore from '@/stores/useAppStore';
// import { useStore } from 'zustand';
import { useTranslation } from 'react-i18next';

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/admin/criteria/event-types',
  baseRoutePath: '/aviation/criteriaManage/event-types',
};

const initSearchParam = {
  reportTypeCd: '',
  eventNm: '',
  useYn: '',
  notesCn: '',
};

const EventTypeListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    reportTypeCd: '',
    eventNm: '',
    useYn: '',
    notesCn: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },
}));

function EventTypeList() {
  const { t } = useTranslation();
  // const currentLocale = useStore(useAppStore, (state) => state.currentLocale);

  // const regUserName = (props) => {
  //   if (currentLocale == 'ko') {
  //     return props.data.regUserNameKor;
  //   } else {
  //     return props.data.regUserNameEng;
  //   }
  // };

  // const updUserName = (props) => {
  //   if (currentLocale == 'ko') {
  //     return props.data.updUserNameKor;
  //   } else {
  //     return props.data.updUserNameEng;
  //   }
  // };

  const state = EventTypeListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      {
        field: 'num',
        headerName: '순번',
      },
      {
        field: 'reportTypeCd',
        headerName: '리포트 구분',
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_148',
        },
      },
      { field: 'eventNm', headerName: '이벤트명' },
      {
        field: 'useYn',
        headerName: '사용여부',
        cellRenderer: CodeLabelComponent,
        cellRendererParams: {
          codeGrpId: 'CODE_GRP_146',
        },
      },
      { field: 'notesCn', headerName: '비고' },
      { field: 'regUserId', headerName: '등록자' /*, cellRenderer: regUserName*/ },
      { field: 'regDttm', headerName: '등록일' },
      { field: 'updUserId', headerName: '수정자' /*, cellRenderer: updUserName*/ },
      { field: 'updDttm', headerName: '수정일' },
    ])
  );
  const { enterSearch, searchParam, list, goAddPage, changeSearchInput, isExpandDetailSearch, clear, goDetailPage } =
    state;
  const { reportTypeCd, eventNm, useYn, notesCn } = searchParam;

  const handleRowDoubleClick = useCallback((selectedInfo) => {
    console.log(selectedInfo);
    const data = selectedInfo.data;
    const detailId = data.eventId;
    goDetailPage(detailId);
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>EVENT TYPE 목록</h2>
      </div>
      <div className="boxForm">
        <div className={isExpandDetailSearch ? 'area-detail active' : 'area-detail'}>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_148"
                  applyAllSelect
                  label="리포트 구분"
                  options={Code.reportTypeCd}
                  labelKey="codeNameKor"
                  valueKey="codeId"
                  value={reportTypeCd}
                  onChange={(value) => {
                    changeSearchInput('reportTypeCd', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="이벤트명"
                  value={eventNm}
                  onChange={(value) => {
                    changeSearchInput('eventNm', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppCodeSelect
                  codeGrpId="CODE_GRP_146"
                  applyAllSelect
                  name="useYn"
                  label="사용여부"
                  labelKey="codeNameKor"
                  valueKey="codeId"
                  value={useYn}
                  onChange={(value) => changeSearchInput('useYn', value)}
                  search={enterSearch}
                />
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppTextInput
                  label="비고"
                  value={notesCn}
                  onChange={(value) => {
                    changeSearchInput('notesCn', value);
                  }}
                  search={enterSearch}
                />
              </div>
            </div>
          </div>
          <div className="btn-area">
            <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
              {t('ke.safety.common.label.00002')}
            </button>
          </div>
        </div>
        <button type="button" name="button" className="arrow button _control active">
          <span className="hide">{t('ke.safety.common.label.00009')}</span>
        </button>
      </div>
      <AppTable
        rowData={list}
        columns={columns}
        setColumns={setColumns}
        store={state}
        handleRowDoubleClick={handleRowDoubleClick}
      />
      <div className="contents-btns">
        <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm" onClick={goAddPage}>
          {t('ke.safety.common.label.00001')}
        </button>
      </div>
    </>
  );
}

export default EventTypeList;
