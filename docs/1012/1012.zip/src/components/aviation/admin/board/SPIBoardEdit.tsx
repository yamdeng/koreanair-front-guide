import { createFormSliceYup, formBaseState } from '@/stores/slice/formSlice';
import * as yup from 'yup';
import { create } from 'zustand';

import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppEditor from '@/components/common/AppEditor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import AppTextInput from '@/components/common/AppTextInput';
import { FORM_TYPE_ADD } from '@/config/CommonConstant';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams } from 'react-router-dom';

/* yup validation */
const yupFormSchema = yup.object({
  notiTypeCd: yup.string().required(),
  subjectKoNm: yup.string().required(),
  popupFromDt: yup.string().required(),
  popupToDt: yup.string().required(),
  boardTxtcn: yup.string(),
  fileGroupSeq: yup.number().nullable(),
});

/* TODO : form 초기값 상세 셋팅 */
/* formValue 초기값 */
const initFormValue = {
  boardTypeCd: '120',
  notiType: '',
  subjectKoNm: '',
  popupFromDt: '',
  popupToDt: '',
  boardTxtcn: '',
  fileGroupSeq: null,
  useYn: 'Y',
  viewYn: 'N',
  popupYn: 'N',
  topFixYn: 'N',
  mainShowYn: 'N',
  viewCo: 0,
};

/* form 초기화 */
const initFormData = {
  ...formBaseState,

  formApiPath: 'avn/admin/board/board',
  baseRoutePath: '/aviation/board-manage/spi-board',
  formName: 'AvnSPIBoardFormStore',
  formValue: {
    ...initFormValue,
  },
};

/* zustand store 생성 */
const AvnSPIBoardFormStore = create<any>((set, get) => ({
  ...createFormSliceYup(set, get),

  ...initFormData,

  yupFormSchema: yupFormSchema,

  clear: () => {
    set({ ...formBaseState, formValue: { ...initFormValue } });
  },
}));

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SPIBoardEdit() {
  // 언어 설정
  const { t } = useTranslation();
  /* formStore state input 변수 */
  const { errors, getDetail, formType, formValue, isDirty, save, remove, cancel, clear, enterSearch, changeInput } =
    AvnSPIBoardFormStore();

  const { notiTypeCd, subjectKoNm, popupFromDt, popupToDt, boardTxtcn, fileGroupSeq } = formValue;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    }
    return clear;
  }, []);

  return (
    <>
      <AppNavigation />
      <div className="conts-title">
        <h2>SPI게시판 {formType === FORM_TYPE_ADD ? '신규' : '수정'} </h2>
      </div>
      {/* 입력영역 */}
      <div className="editbox">
        <div className="form-table line">
          <div className="form-cell wid30">
            <div className="form-group wid100">
              <AppCodeSelect
                // 공통코드 새로 생성해야 함 (세부항목 문의)
                codeGrpId="CODE_GRP_142"
                id="AvnSPIBoardListFormStorenotiType"
                label={t('ke.safety.Notice.label.00001')}
                value={notiTypeCd}
                onChange={(value) => {
                  changeInput('notiTypeCd', value);
                }}
                search={enterSearch}
                errorMessage={errors.boardTypeCd}
                required
              />
            </div>
          </div>
          <div className="form-cell wid50">
            <div className="form-group wid50">
              <div className="df">
                <div className="date1">
                  <AppDatePicker
                    id="searchDateFrom"
                    label={'게시기간'}
                    pickerType="date"
                    value={popupFromDt}
                    onChange={(value) => {
                      changeInput('popupFromDt', value);
                    }}
                    required
                  />
                </div>
                <span className="unt">~</span>
                <div className="date2">
                  <AppDatePicker
                    id="searchDateTo"
                    label={'게시기간'}
                    pickerType="date"
                    value={popupToDt}
                    onChange={(value) => {
                      changeInput('popupToDt', value);
                    }}
                    required
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="line dp-n"></hr>
        <div className="form-table">
          <div className="form-cell wid100">
            <div className="form-group wid100">
              <AppTextInput
                id="AvnSPIBoardListFormStoresubjectKoNm"
                label={t('ke.safety.Notice.label.00002')}
                value={subjectKoNm}
                onChange={(value) => changeInput('subjectKoNm', value)}
                errorMessage={errors.subjectKoNm}
                required
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <div className="form-table line">
          <div className="form-cell wid50">
            <div className="form-group wid100 mr5">
              {/*내용 */}
              {/*내용 */}
              <AppEditor label="AppEditor" value={boardTxtcn} onChange={(value) => changeInput('boardTxtcn', value)} />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        {/* 파일첨부영역 : drag */}
        <div className="form-table">
          <div className="form-cell wid50">
            <div className="form-group wid100">
              {/* 파일첨부영역 : drag */}
              <AppFileAttach
                label={t('ke.safety.Notice.label.00007')}
                fileGroupSeq={fileGroupSeq}
                workScope={'A'}
                updateFileGroupSeq={(newFileGroupSeq) => {
                  changeInput('fileGroupSeq', newFileGroupSeq);
                }}
                errorMessage={errors.fileGroupSeq}
              />
            </div>
          </div>
        </div>
        <hr className="line"></hr>
      </div>
      {/*//입력영역*/}
      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button className="btn_text text_color_neutral-10 btn_confirm" onClick={save}>
          {t('ke.safety.common.label.00004')}
        </button>
        <button
          className="btn_text text_color_darkblue-100 btn_close"
          onClick={remove}
          style={{ display: formType !== 'add' ? '' : 'none' }}
        >
          {t('ke.safety.common.label.00008')}
        </button>
        <button className="btn_text text_color_darkblue-100 btn_close" onClick={cancel}>
          {t('ke.safety.common.label.00005')}
        </button>
      </div>
      {/*//하단버튼영역*/}
    </>
  );
}
export default SPIBoardEdit;
