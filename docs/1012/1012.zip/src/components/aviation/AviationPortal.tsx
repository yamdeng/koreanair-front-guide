import mainphoto from '@/resources/images/av-img.jpg';
import aviationSafetyCultureForum from '@/resources/images/aviationSafetyCultureForum.jpg';
import safetyHour from '@/resources/images/safetyHour.png';
import ApiService from '@/services/ApiService';
import ToastService from '@/services/ToastService';
import { createListSlice } from '@/stores/slice/listSlice';
import useUIStore from '@/stores/useUIStore';
import CommonUtil from '@/utils/CommonUtil';
import history from '@/utils/history';
import dayjs from 'dayjs';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import Slider from 'react-slick';
import { create, useStore } from 'zustand';
import MainNoticeModal from './MainNoticeModal';

// TODO : 검색 초기값 설정
const initSearchParam = {
  selectConsequenceId: '',
};

/* zustand store 생성 */
const useAviationPortalStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    selectConsequenceId: '',
  },

  topRisk: [],
  topRiskElement: [],
  reportProcess: [],
  reportProcessChart: [],
  toDo: [],
  banner: [],
  accident: [],
  notice: [],
  noticePop: [],
  isMainNoticeModal: false,

  initInfoSearch: async () => {
    const apiParam = {};
    const apiResult = await ApiService.get(`avn/main/main-infos`, apiParam);

    set({ topRisk: apiResult.data.topRisk });
    set({ reportProcess: apiResult.data.reportProcess });
    set({ toDo: apiResult.data.toDo });
    set({ banner: apiResult.data.banner });
    set({ accident: apiResult.data.accident });
    set({ notice: apiResult.data.notice });

    const arr = [];

    apiResult.data.notice.map((item, index) => {
      if (item.popupYn === 'Y') arr.push(item);
    });

    set({ noticePop: arr });
    const { noticePopView, topRisk, topRiskCreate, createCanvers } = get();
    topRiskCreate(topRisk);
    createCanvers();
    noticePopView(arr);
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  topRiskCreate: (topRisk) => {
    const rtnArr = [];
    let arr = [];
    const riskContsArea = null;
    topRisk.map((info, index) => {
      arr.push(
        <div className="risk-box" key={'topRisk' + index}>
          <div className="IcoTags">
            <span className="ico-tag">{info.viewSn}</span>
          </div>
          <div className="risk-conts">
            <div className="txt">{info.eventNm}</div>
            <span className="sub-txt">
              Number of occurrence <strong>{info.totalOccurCo}</strong>
            </span>
          </div>
          <div className="risk-bottom">
            <ul className="sort-box">
              <li className={info.occurOneCo == 0 ? 'gray' : 'red'}>{info.occurOneCo}</li>
              <li className={info.occurTwoCo == 0 ? 'gray' : 'orange'}>{info.occurTwoCo}</li>
              <li className={info.occurThreeCo == 0 ? 'gray' : 'yellow'}>{info.occurThreeCo}</li>
              <li className={info.occurForCo == 0 ? 'gray' : 'green'}>{info.occurForCo}</li>
            </ul>
          </div>
        </div>
      );
      if (index % 3 === 2 || index === topRisk.length - 1) {
        rtnArr.push(React.createElement('div', { key: 'riskContsArea' + index, className: 'risk-conts-area' }, [arr]));
        arr = [];
      }
    });
    set({ topRiskElement: rtnArr });
  },

  /*
  실제로 차트를 그린다.
  cvs : 차트를 그릴 Div의 하위에 있는 canvas 오브젝트
  data : 화면에 표시할 데이터 
  HLineInfo : 수평선의 정보(값,컬러 등)
*/
  createCanvers: () => {
    const { getColor, reportProcess } = get();

    const rtnArr = [];
    let arr = [];
    reportProcess.map((info, index) => {
      const cvs = (
        <div className="graph-box">
          {info.reportType}
          <canvas id={'reportCvs' + index} width="150" height="150"></canvas>
        </div>
      );

      arr.push(cvs);
      if (index % 4 === 3 || index === reportProcess.length - 1) {
        rtnArr.push(
          React.createElement('div', { key: 'reportProcessChart' + index, className: 'main-conts-graph' }, [arr])
        );
        arr = [];
      }
    });
    set({ reportProcessChart: rtnArr });
  },

  drawChart: (reportProcess) => {
    const { getColor } = get();
    reportProcess.map((info, index) => {
      const cvs = document.getElementById('reportCvs' + index);

      const value = info.rate;
      const color = getColor(value);
      // 차트를 리셋(클리어)한다.
      DxChart.reset(cvs);

      // 첫번째 horseshoe차트를 그린다.
      const hs = new DxChartHorseShoe({
        id: cvs,
        elem: cvs,
        min: 0,
        max: 100,
        value: value,
        options: {
          // 마진정보를 세팅한다.
          margin: { Top: 5, Right: 8, Bottom: 6, Left: 15 },
          // 라벨 정보를 세팅한다.
          labels: {
            CenterSpecific: info.report_type.toUpperCase() + '\n' + info.rate + '%',
            CenterFontStyle: 'bold 20px Pretendard',
          },
          // 원의 반지름의 지정(default:75)
          //radius : 75,
          // 끝부분의 원의 정보를 세팅한다.
          ends: {
            Radius: 7, // LineWidth-1을 빼주면 차트라인과 동일한 두께로 ends를 그림
            //Color : 'red' ,
            LineColor: color,
            LineWidth: 0, // default =3
          },
          // 중심좌표를 지정한다.
          center: { x: 75, y: 75 },
          // 차트의 선두께를 지정한다.
          width: 15,
          // 차트의 컬러를 지정한다.([Front Line Color, back Line Color])
          colors: [color, '#ffffff'],
        },
      });
      hs.drawAni(); // draw,drawAni
    });
  },

  // 값의 범위에 매핑된 색깔을 반환한다.
  getColor: (value) => {
    let color = 'black';
    // 90이상
    if (value >= 90) {
      color = '#01C27F';
    }
    // 80~90
    else if (value >= 80 && value < 90) {
      color = '#FFC147';
    }
    // 60~80
    else if (value >= 60 && value < 80) {
      color = '#FE884D';
    }
    // 60미만
    else if (value < 60) {
      color = '#EE4E10';
    }

    return color;
  },
  noticePopView: (arr) => {
    if (arr.length != 0 && !CommonUtil.hiddenNoticeByExpireInfo('notice', dayjs().format('YYYY-MM-DD')))
      set({ isMainNoticeModal: true });
  },
  handleMainNoticeModal: (val) => {
    set({ isMainNoticeModal: val });
  },
  clear: () => {},
}));

function AviationPortal() {
  const state = useAviationPortalStore();
  const { setIsAviationPortal } = useStore(useUIStore, (state) => state) as any;
  const { t } = useTranslation();

  const {
    initInfoSearch,
    isMainNoticeModal,
    handleMainNoticeModal,
    topRiskElement,
    reportProcess,
    reportProcessChart,
    toDo,
    banner,
    notice,
    noticePop,
    drawChart,
  } = state;

  const [rightIconVisible, setRightIconVisible] = useState(false);
  const togglerightIconVisible = () => {
    setRightIconVisible(!rightIconVisible);
  };

  useEffect(() => {
    initInfoSearch();
    setIsAviationPortal(true);
    return () => {
      setIsAviationPortal(false);
    };
  }, []);

  useEffect(() => {
    drawChart(reportProcess);
  }, [reportProcess]);

  const topRiskSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    vertical: true,
    verticalSwiping: true,
    slidesToShow: 2,
    slidesToScroll: 2,
    autoplay: true,
    autoplaySpeed: 10000,
  };

  const bannerSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 10000,
  };

  return (
    <>
      {/*nav-is-visible - 펼침 */}
      <div className={rightIconVisible ? 'cd-stretchy-nav nav-is-visible' : 'cd-stretchy-nav'}>
        <a href={undefined} className="cd-nav-trigger" onClick={() => togglerightIconVisible()}>
          <span aria-hidden="true"></span>
        </a>
        <ul>
          <li>
            <a href={undefined} className="active">
              <span>HAZARD</span>
            </a>
          </li>
          <li>
            <a href={undefined}>
              <span>Portfolio</span>
            </a>
          </li>
          <li>
            <a href={undefined}>
              <span>Services</span>
            </a>
          </li>
          <li>
            <a href={undefined}>
              <span>Store</span>
            </a>
          </li>
          <li>
            <a href={undefined}>
              <span>Contact</span>
            </a>
          </li>
        </ul>

        <span aria-hidden="true" className="stretchy-nav-bg"></span>
      </div>

      <div className="av-main-wrap">
        {/* Top 10 RISK AREAS*/}
        <div className="grid-item">
          <div className="grid-group" id="riskGridGroup">
            <div className="head-top">
              <h3>Top 10 Events</h3>
            </div>
            <div className="risk-slider-container">
              <Slider {...topRiskSettings} key={'topRiskElement'}>
                {topRiskElement}
              </Slider>
            </div>
          </div>

          {/* 보고서 처리 현황*/}
          <div className="grid-group">
            <div className="head-top">
              <h3>보고서 처리 현황</h3>
              <ul className="guide-info">
                <li>
                  <span className="color green"></span>90% 이상
                </li>
                <li>
                  <span className="color yellow"></span>90%~80%
                </li>
                <li>
                  <span className="color orange"></span>80%~60%
                </li>
                <li>
                  <span className="color red"></span>60% 미만
                </li>
              </ul>
            </div>
            {reportProcessChart}
            {/* <div className="main-conts-graph">
              <div className="graph-box">ASR</div>
              <div className="graph-box">MSR</div>
              <div className="graph-box">GSR</div>
              <div className="graph-box">DSR</div>
            </div>
            <div className="main-conts-graph">
              <div className="graph-box">ASR</div>
              <div className="graph-box">MSR</div>
              <div className="graph-box">GSR</div>
              <div className="graph-box">DSR</div>
            </div> */}
          </div>
        </div>

        {/* TO DO LIST*/}
        <div className="grid-item">
          <h3>To do list</h3>
          <div className="main-table-box">
            <table className="main-table-todo">
              <colgroup>
                <col width="25%" />
                <col width="50%" />
                <col width="25%" />
              </colgroup>
              <thead>
                <tr>
                  <th>Doc No.</th>
                  <th>Subject.</th>
                  <th>Submit Date</th>
                </tr>
              </thead>
              <tbody>
                {toDo.map((item, index) => {
                  return index < 5 ? (
                    <tr key={'toDo' + index}>
                      <td>{item.doc_no}</td>
                      <td>
                        {item.type} {item.subject}
                      </td>
                      <td>{item.submitted_at}</td>
                    </tr>
                  ) : (
                    <></>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* photo*/}
        <div className="grid-item photo">
          <Slider {...bannerSettings} key={'topRiskElement'}>
            <div className="main-photo">
              <img src={mainphoto} className="" alt="photo" />
              <h3 className="ph-img-tit">
                <span>Safety Chapion 시상식</span>
              </h3>
            </div>
            <div className="main-photo">
              <img src={aviationSafetyCultureForum} className="" alt="photo" />
              <h3 className="ph-img-tit">
                <span>2024 항공안전문화포럼</span>
              </h3>
            </div>
            <div className="main-photo">
              <img src={safetyHour} className="" alt="photo" />
              <h3 className="ph-img-tit">
                <span>Safety Together &nbsp;&nbsp;</span>
              </h3>
            </div>
          </Slider>
        </div>

        {/* 공지사항/사고준사고 현황 */}
        <div className="grid-item">
          <h3>
            <ul className="main-tab">
              <li>
                <a className="active" href={undefined}>
                  공지사항
                </a>
              </li>
              <li>
                <a
                  href={undefined}
                  onClick={() => {
                    ToastService.info('개발중 입니다.');
                  }}
                >
                  사고준사고 현황
                </a>
              </li>
            </ul>
          </h3>
          <div className="main-table-box">
            <table className="main-table">
              <tbody>
                {notice.map((item, index) => {
                  return item.num < 7 ? (
                    <tr key={'noticeTr' + item.num}>
                      <th key={'noticeTh' + item.num}>
                        <a
                          href={undefined}
                          onClick={() => {
                            history.push(`aviation/sftm/${item.notiTypeCd}/${item.boardId}`);
                          }}
                        >
                          {'[' + item.notiTypeNm + '] '}
                          {item.subjectKoNm}
                        </a>
                      </th>
                      <td>
                        <span className="date">{item.writeDt}</span>
                        <span className="wait">{item.regUserNm}</span>
                      </td>
                    </tr>
                  ) : (
                    <></>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/*위험도 선택팝업 */}
        <MainNoticeModal
          isOpen={isMainNoticeModal}
          closeModal={() => handleMainNoticeModal(false)}
          params={noticePop}
        />
      </div>
    </>
  );
}

export default AviationPortal;
