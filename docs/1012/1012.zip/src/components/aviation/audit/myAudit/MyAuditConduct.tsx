import { useState } from 'react';
import { DatePicker, TimePicker, Select as AntSelect } from 'antd';
import AppTable from '@/components/common/AppTable';
import AppSelect from '@/components/common/AppSelect';
import { getAllData } from '@/data/grid/example-data-new';
import { testColumnInfos } from '@/data/grid/table-column';
import AppTextInput from '@/components/common/AppTextInput';
import AppTextArea from '@/components/common/AppTextArea';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppAutoComplete from '@/components/common/AppAutoComplete';
import { Upload } from 'antd';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppFileAttach from '@/components/common/AppFileAttach';

import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';
import useMyAuditConductStore from '@/stores/aviation/audit/myAudit/useMyAuditConductStore';

const { Dragger } = Upload;
const props: any = {
  name: 'file',
  multiple: true,
  defaultFileList: [
    {
      uid: '1',
      name: 'xxx.png',
      // status: 'uploading',
      url: 'http://www.baidu.com/xxx.png',
      percent: 33,
    },
    // {
    //   uid: '2',
    //   name: 'yyy.png',
    //   status: 'done',
    //   url: 'http://www.baidu.com/yyy.png',
    // },
    // {
    //   uid: '3',
    //   name: 'zzz.png',
    //   status: 'error',
    //   response: 'Server Error 500',
    //   // custom error message to show
    //   url: 'http://www.baidu.com/zzz.png',
    // },
  ],
  action: 'https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload',

  onChange(info) {
    const { status } = info.file;
    if (status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (status === 'done') {
      alert(`${info.file.name} file uploaded successfully.`);
    } else if (status === 'error') {
      alert(`${info.file.name} file upload failed.`);
    }
  },

  onRemove(file) {
    return false;
  },

  onPreview(file) {
    return false;
  },

  onDrop(e) {
    console.log('Dropped files', e.dataTransfer.files);
  },
};

function MyAuditConduct() {
  const [inputValue, setInputValue] = useState('');
  const rowData = getAllData();
  const columns = testColumnInfos;

  const { dsAuditInfo, auditPhaseLevel, hideConduct } = useMyAuditFrameStore();
  const isDisabled = dsAuditInfo.phaseLevel > 2 ? true : false;

  const {
    formValue,
    dsAuditChecklistList,
    dsAuditChapterList,
    dsAuditQuestionList,
    currentChecklistId,
    currentChapterTabIndex,
    changeChecklist,
    changeChapterTabIndex,
    changeQuestionList,
    changeInput,
    errors,
    saveAuditConduct,
    hideChecklistYn,
    changeInputFindingYn,
  } = useMyAuditConductStore();

  const {
    /* Audit */
    isFinding,
    urlResult,
    resultFileGroupSeq,
  } = formValue;

  return (
    <>
      {/* <div id="area-CONDUCT" className={`myaudit-contents ${hideConduct}`}> */}
      <div id="area-CONDUCT" className="myaudit-contents">
        <div className="audit-box"></div>
        <h3 className="audit-tit">Conduct</h3>
        <div className="editbox ">
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="group-box-wrap wid100">
                <span className="txt">
                  Finding / Observation
                  <span className="required">*</span>
                </span>
                {/* <div className="radio-wrap">
                  <label>
                    <input type="radio" />
                    <span>Yes</span>
                  </label>
                  <label>
                    <input type="radio" />
                    <span>No</span>
                  </label>
                </div> */}
                <AppRadioGroup
                  id="isFinding"
                  name="isFinding"
                  label="Finding / Observation (Checklist 작성후에 자동 표기됩니다.)"
                  options={[
                    { value: 'Y', label: 'Yes' },
                    { value: 'N', label: 'No' },
                  ]}
                  // value={isFinding === '' ? 'N' : isFinding}
                  value={isFinding}
                  onChange={(value) => {
                    changeInput('isFinding', value);
                    changeInputFindingYn(value);
                  }}
                  disabled
                  // required
                  // errorMessage={checkedErrorMessage ? 'error' : ''}
                  // required={checkedRequired}
                  // disabled={checkedDisabled}
                  // toolTipMessage={checkedToolTip ? 'aaa\nbbb\ncccc' : ''}
                />
                {/*<span className="errorText">error</span>*/}
              </div>
            </div>
          </div>
          <hr className="line"></hr>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                <AppTextInput
                  label="Audit 결과 보고"
                  id="urlResult"
                  name="urlResult"
                  value={urlResult}
                  onChange={(value) => changeInput('urlResult', value)}
                  // required
                  errorMessage={errors.urlResult}
                  // disabled={formType === FORM_TYPE_UPDATE}
                />
              </div>
            </div>
          </div>
          {/* 파일첨부영역 : drag */}
          <div className="form-cell wid100 mb-20">
            <div className="form-group wid100">
              {/* 파일첨부영역 : drag */}
              {/* <div className="filebox error">
                <Dragger {...props}>
                  <p className="ant-upload-text ">+ 이 곳을 클릭하거나 마우스로 업로드할 파일을 끌어서 놓으세요.</p>
                </Dragger>
                <label htmlFor="file" className="file-label">
                  첨부파일 <span className="required">*</span>
                </label>
              </div> 
              <span className="errorText">fileerror</span>*/}
              <AppFileAttach
                id="InvestigationReportEditspiFileGroupSeq"
                name="spiFileGroupSeq"
                label="전자 결재 문서"
                fileGroupSeq={resultFileGroupSeq}
                workScope={'A'}
                // updateFileGroupSeq={(newFileGroupSeq) => {
                //   changeInput('resultFileGroupSeq', newFileGroupSeq);
                // }}
                // errorMessage={errors['resultFileGroupSeq']}
              />
            </div>
          </div>
          {/* <hr className="line"></hr> */}
        </div>
        <div className={`editbox ${hideChecklistYn}`}>
          <h3 className="av-table-tit mt-10">Checklist</h3>
          <div className="form-table">
            <div className="form-cell wid50">
              <div className="form-group wid100">
                {/* <AppSelect label={'Checklist'} /> */}
                <AppSelect
                  id="divisionChecklist"
                  options={dsAuditChecklistList}
                  label="Checklist"
                  value={currentChecklistId}
                  //value={checklistInfo}
                  labelKey="listName"
                  valueKey="checklistId"
                  onChange={(selectedValue) => {
                    //changeRevision(appSelectValue);
                    //changeInput('checklistInfo', selectValue);
                    changeChecklist(selectedValue);
                  }}
                  // isMultiple
                  // required
                  // disabled
                />
              </div>
            </div>
          </div>
          <hr className="line"></hr>
          {/*탭 */}
          <div className="menu-tab-nav">
            <div className="swiper-container">
              <div className="menu-tab Audit">
                {dsAuditChapterList.map((tabChapterInfo, index) => {
                  const { chapterId, chapterName } = tabChapterInfo;
                  return (
                    <a
                      key={chapterId}
                      href="javascript:void(0);"
                      className={currentChapterTabIndex === index ? 'active' : ''}
                      data-label={chapterName}
                      onClick={() => changeChapterTabIndex(index)}
                    >
                      {chapterName}
                    </a>
                  );
                })}
              </div>

              <div className="menu-tab-nav-operations">
                <button type="button" name="button" className="menu-tab-nav-more">
                  <span className="hide">더보기</span>
                </button>

                {/*<button type="button" name="button" className="menu-tab-btn-next">
              <span className="hide">다음 탭메뉴</span>
            </button>*/}
              </div>
            </div>
          </div>
          <div className="checklist-contents edit Audit">
            {/* 상세페이지 */}
            {dsAuditQuestionList.map((questionInfo, questionIndex) => {
              const {
                questionId,
                content,
                refManual,
                priorityNm,
                probabilityNm,
                severityNm,
                priorityColor,
                probabilityColor,
                severityColor,
                comment,
                findingType,
              } = questionInfo;
              return (
                <div key={questionId} className="editbox">
                  <div className="form-table line">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="df">
                          <div className="type9 mt10">
                            <div className="text-desc-type1">{content}</div>
                            <div className="form-table">
                              <div className="form-cell wid100">
                                <div className="form-group wid100">
                                  <span className="text-desc-type1">{refManual}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="type10">
                            <div className="form-table">
                              <div className="form-cell">
                                <div className="form-group wid100">
                                  <div className="group-box-wrap wid100">
                                    <span className="txt">Priority</span>
                                    <div className="editarea-box view">
                                      <div className="label-box bwid50">
                                        <span className={priorityColor}>{priorityNm}</span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  <div className="group-box-wrap wid100">
                                    <span className="txt">Severity</span>
                                    <div className="editarea-box view">
                                      <div className="label-box wid50">
                                        <span className={severityColor}>{severityNm}</span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-table">
                              <div className="form-cell wid50">
                                <div className="form-group wid100">
                                  <div className="group-box-wrap wid100">
                                    <span className="txt">Probability</span>
                                    <div className="editarea-box view">
                                      <div className="label-box wid50">
                                        <span className={probabilityColor}>{probabilityNm}</span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        {/* <AppTextInput label="" placeholder="Input Comment" /> */}
                        <AppTextInput
                          inputType="text"
                          //label={'Input Comment'}
                          placeholder="Input Comment"
                          value={comment}
                          onChange={(value) => {
                            changeQuestionList(questionId, questionIndex, 'comment', value);
                          }}
                          disabled={isDisabled}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          id="SysDeptFormrprsnUserId"
                          name={questionId}
                          label=""
                          options={[
                            { value: 'Finding', label: 'Finding' },
                            { value: 'Observation', label: 'Observation' },
                            { value: 'N/A', label: 'N/A' },
                            { value: 'Yes', label: 'Yes' },
                          ]}
                          value={findingType === null ? 'Yes' : findingType}
                          onChange={(value) => {
                            changeQuestionList(questionId, questionIndex, 'findingType', value);
                          }}
                          disabled={isDisabled}
                          // value={rprsnUserId}
                          // onChange={(value) => changeInput('rprsnUserId', value)}
                          // errorMessage={checkedErrorMessage ? 'error' : ''}
                          // required={checkedRequired}
                          // disabled={checkedDisabled}
                          // toolTipMessage={checkedToolTip ? 'aaa\nbbb\ncccc' : ''}
                        />
                      </div>
                    </div>
                  </div>
                  {/* <hr className="line"></hr> */}
                </div>
              );
            })}
            {/*//상세페이지*/}
          </div>
        </div>
        {/* 하단버튼영역 */}
        <div className={auditPhaseLevel > 2 ? 'contents-btns hide' : 'contents-btns'}>
          <button className="btn_text text_color_neutral-10 btn_confirm ">Delete</button>
          <button className="btn_text btn_list" onClick={() => saveAuditConduct('CONDUCT')}>
            Save
          </button>
          <button disabled className="btn_text btn-disabled">
            Rollback
          </button>
          <button
            type="button"
            name="button"
            className="btn_text text_color_neutral-10 btn_confirm"
            onClick={() => saveAuditConduct('CAR')}
          >
            Next
          </button>
        </div>
        {/*//하단버튼영역*/}
      </div>
    </>
  );
}

export default MyAuditConduct;
