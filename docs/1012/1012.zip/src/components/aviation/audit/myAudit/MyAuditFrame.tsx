import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
// import AppNavigation from '@/components/common/AppNavigation';
import useMyAuditFrameStore from '@/stores/aviation/audit/myAudit/useMyAuditFrameStore';
import MyAuditPlan from './MyAuditPlan';
import MyAuditConduct from './MyAuditConduct';
import MyAuditCar from './MyAuditCar';
import MyAuditClose from './MyAuditClose';

function MyAuditFrame() {
  const { auditId, findingId } = useParams();

  const {
    getAuditInfo,
    dsAuditInfo,
    setAuditPhase,
    auditPhaseLevel,
    hidePlan,
    hideConduct,
    hideCar,
    hideClose,
    activePlan,
    activeConduct,
    activeCar,
    activeClose,
  } = useMyAuditFrameStore();
  //const useMyAuditPlanStoreState = useMyAuditPlanStore();
  //const { dsAuditPlanInfo } = useMyAuditPlanStore();

  const init = () => {
    // edit
    if (auditId && auditId.length) {
      getAuditInfo(auditId);
    }
    // add
    else {
      setAuditPhase('PLAN'); // Plan 영역 view
    }
  };

  useEffect(() => {
    init();
    //return clearView;
    //useMyAuditPlanStoreState.isAnybodyHelp();
  }, []);

  return (
    <>
      {/*경로 */}
      {/* <AppNavigation /> */}
      {/*//경로 */}
      <div className="myaudit-container">
        <div className="myaudit-header">
          <div className="ad-number">
            {/* Audit No. <span>{dsAuditInfo.auditNo}</span> */}
            Audit No. {dsAuditInfo.auditNo}
          </div>
          <div className="myaudit-tab">
            <ul>
              <li>
                <a
                  className={auditPhaseLevel == 1 ? 'active' : ''}
                  href="javascript:void(0);"
                  onClick={() => setAuditPhase('PLAN')}
                >
                  <span className={`myaudit-tab-icon ${activePlan}`}>아이콘</span> Plan
                </a>
              </li>
              <li>
                <a
                  className={auditPhaseLevel == 2 ? 'active' : auditPhaseLevel < 2 ? 'disabled' : ''}
                  href="javascript:void(0);"
                  onClick={() => setAuditPhase('CONDUCT')}
                >
                  <span className={`myaudit-tab-icon ${activeConduct}`}>아이콘</span>Conduct
                </a>
              </li>
              <li>
                <a
                  className={auditPhaseLevel == 3 ? 'active' : auditPhaseLevel < 3 ? 'disabled' : ''}
                  href="javascript:void(0);"
                  onClick={() => setAuditPhase('CAR')}
                >
                  <span className={`myaudit-tab-icon ${activeCar}`}>아이콘</span> CAR
                </a>
              </li>
              <li>
                <a
                  className={auditPhaseLevel == 4 ? 'active' : auditPhaseLevel < 4 ? 'disabled' : ''}
                  href="javascript:void(0);"
                  onClick={() => setAuditPhase('CLOSE')}
                >
                  <span className={`myaudit-tab-icon ${activeClose}`}>아이콘</span>Close
                </a>
              </li>
            </ul>
          </div>
        </div>
        {/* {dsAuditInfo.phaseLevel > 0 ? <MyAuditPlan /> : <></>}
        {dsAuditInfo.phaseLevel > 1 ? <MyAuditConduct /> : <></>}
        {dsAuditInfo.phaseLevel > 2 ? <MyAuditCar /> : <></>}
        {dsAuditInfo.phaseLevel > 3 ? <MyAuditClose /> : <></>} */}
        <div className={hidePlan}>{auditPhaseLevel > 0 ? <MyAuditPlan /> : <></>}</div>
        <div className={hideConduct}>{auditPhaseLevel > 1 ? <MyAuditConduct /> : <></>}</div>
        <div className={hideCar}>{auditPhaseLevel > 2 ? <MyAuditCar /> : <></>}</div>
        <div className={hideClose}>{auditPhaseLevel > 3 ? <MyAuditClose /> : <></>}</div>
      </div>
    </>
  );
}

export default MyAuditFrame;
