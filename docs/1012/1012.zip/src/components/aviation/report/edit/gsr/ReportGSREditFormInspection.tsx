import AirportSearch from '@/components/aviation/common/AirportSearch';
import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppNavigation from '@/components/common/AppNavigation';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppTextInput from '@/components/common/AppTextInput';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import useGsrInspectionFormStore from '@/stores/aviation/report/useGsrInspectionFormStore';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import GsrFlightInfo from '../../common/GsrFlightInfo';
import CodeService from '@/services/CodeService';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppEditor from '@/components/common/AppEditor';

function ReportGSREditFormInspection() {
  const formStore = useGsrInspectionFormStore();
  const {
    filghtExpanded,
    eventExpanded,
    errors,
    changeInput,
    getDetail,
    formValue,
    tempSave,
    save,
    print,
    toggleAccordionExpanded,
    isDirty,
    clear,
    formType,
    detailInfo,
  } = formStore;

  const { detailId } = useParams();

  const { report = {} } = detailInfo || {};
  const { event } = formValue;
  const {
    occurPlaceNm,
    occurAirportCd,
    occurDttm,
    occurTimezoneCd,

    checkKindCd,
    controlAuthorityCd,
    reldeptCd,
    inspectionAreaCd,
    inspectionResultCd,

    subjectNm,
    descriptionTxtcn,
    fileGroupSeq,
  } = event;

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      clear();
    }
  }, [detailId]);

  useEffect(() => {
    return clear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['GSR']} />

      <div className="info-wrap toggle">
        <dl className={filghtExpanded ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button type="button" className="btn-tg">
              비행정보
              <span className={filghtExpanded ? 'active' : ''}></span>
              <div className="tag-info-wrap-end">
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      보고서 작성 가이드
                    </a>
                  </div>
                </div>
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      의무보고의 범위
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: filghtExpanded ? '' : 'none' }}>
            <GsrFlightInfo store={formStore} />
          </dd>
        </dl>

        <dl className={eventExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트
              <span className={eventExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid100 ">
                      <div className="form-group wid100">
                        {/*발생위치 */}
                        <AppTextInput
                          label="지점"
                          value={occurPlaceNm}
                          onChange={(value) => {
                            changeInput('event.occurPlaceNm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100 ">
                      <div className="form-group wid100">
                        {/*발생위치 */}
                        <AirportSearch
                          label="발생 공항"
                          value={occurAirportCd}
                          onChange={(value) => {
                            changeInput('event.occurAirportCd', value);
                          }}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="df">
                          <div className="type3">
                            <AppDatePicker
                              label="발생 시간"
                              excludeSecondsTime
                              showTime
                              value={occurDttm}
                              onChange={(value) => {
                                changeInput('event.occurDttm', value);
                              }}
                            />
                          </div>
                          <div className="type4">
                            <AppCodeSelect
                              codeGrpId="CODE_GRP_079"
                              value={occurTimezoneCd}
                              onChange={(value) => {
                                changeInput(`event.occurTimezoneCd`, value);
                              }}
                              required
                              errorMessage={errors[`event.occurTimezoneCd`]}
                              disabled
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="점검 종류"
                          options={CodeService.getOptions('CODE_GRP_104')}
                          value={checkKindCd}
                          onChange={(value) => {
                            changeInput('event.checkKindCd', value);
                          }}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppCodeSelect
                          label="규제기관"
                          codeGrpId="CODE_GRP_047"
                          value={controlAuthorityCd}
                          onChange={(value) => {
                            changeInput('event.controlAuthorityCd', value);
                          }}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppCodeSelect
                          label="부서"
                          codeGrpId="CODE_GRP_105"
                          value={reldeptCd}
                          onChange={(value) => {
                            changeInput('event.reldeptCd', value);
                          }}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppCodeSelect
                          label="지역"
                          codeGrpId="CODE_GRP_048"
                          value={inspectionAreaCd}
                          onChange={(value) => {
                            changeInput('event.inspectionAreaCd', value);
                          }}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="수검 결과"
                          options={CodeService.getOptions('CODE_GRP_106')}
                          value={inspectionResultCd}
                          onChange={(value) => {
                            changeInput('event.inspectionResultCd', value);
                          }}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid100">
                        {/*제목*/}
                        <AppTextInput
                          id={`event.subjectNm`}
                          label="제목"
                          value={subjectNm}
                          onChange={(value) => {
                            changeInput('event.subjectNm', value);
                          }}
                          required
                          errorMessage={errors['event.subjectNm']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100 ">
                        {/*내용 */}
                        <AppEditor
                          id={`event.descriptionTxtcn`}
                          label="AppEditor"
                          value={descriptionTxtcn}
                          onChange={(value, byPassIsDirty) => {
                            changeInput('event.descriptionTxtcn', value, byPassIsDirty);
                          }}
                          required
                          errorMessage={errors['event.descriptionTxtcn']}
                        />
                      </div>
                    </div>
                  </div>
                  {/* 파일첨부영역 : drag */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppFileAttach
                          label={'첨부파일'}
                          fileGroupSeq={fileGroupSeq}
                          workScope={'A'}
                          updateFileGroupSeq={(newFileGroupSeq) => {
                            changeInput('event.fileGroupSeq', newFileGroupSeq);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      {/* 하단버튼영역 */}
      <ReportEditBottomButton
        formType={formType}
        finalSubmittedYn={report.finalSubmittedYn}
        print={print}
        tempSave={tempSave}
        save={save}
      />
    </>
  );
}

export default ReportGSREditFormInspection;
