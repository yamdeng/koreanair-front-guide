import { useEffect } from 'react';
import useRsrFormStore from '@/stores/aviation/report/useRsrFormStore';
import ReportEditBottomButton from '../common/ReportEditBottomButton';

function ReportFOQAEditForm() {
  const formStore = useRsrFormStore();
  const { clear, tempSave, save, print, formType, detailInfo } = formStore;
  const { report = {} } = detailInfo || {};

  useEffect(() => {
    return clear;
  }, []);

  return (
    <>
      <ReportEditBottomButton
        formType={formType}
        finalSubmittedYn={report.finalSubmittedYn}
        print={print}
        tempSave={tempSave}
        save={save}
      />
    </>
  );
}
export default ReportFOQAEditForm;
