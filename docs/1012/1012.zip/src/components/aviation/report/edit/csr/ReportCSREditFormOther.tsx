import AirportSearch from '@/components/aviation/common/AirportSearch';
import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import AppCodeFieldSelect from '@/components/common/AppCodeFieldSelect';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppNavigation from '@/components/common/AppNavigation';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import Code from '@/config/Code';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import CodeService from '@/services/CodeService';
import useCsrOtherFormStore from '@/stores/aviation/report/useCsrOtherFormStore';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import CsrEventContent from '../../common/CsrEventContent';
import CsrFlightInfo from '../../common/CsrFlightInfo';
import CsrInvolveList from '../../common/CsrInvolveList';

function ReportCSREditFormOther() {
  const formStore = useCsrOtherFormStore();

  const {
    filghtExpanded,
    eventExpanded,
    involveExpaned,
    eventContentExpanded,
    errors,
    changeBriefingKindCode,
    changeInput,
    getDetail,
    formValue,
    tempSave,
    save,
    print,
    toggleAccordionExpanded,
    isDirty,
    clear,
    formType,
    detailInfo,
  } = formStore;

  const { report = {} } = detailInfo || {};
  const { event } = formValue;

  const {
    occurAirportCd,
    etcBriefingKindCd,
    etcBriefingItemCd,
    cabinLogYn,
    paxClsCd,
    fireSmokeSmellCd,
    inflightOccurLocationCd,
    etcCauseCd,
    useEmergencyEquipCodeList,
  } = event;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      clear();
    }
  }, [detailId]);

  useEffect(() => {
    return clear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['CSR']} />

      <div className="info-wrap toggle" id="report-edit-form">
        <dl className={filghtExpanded ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button
              type="button"
              className="btn-tg"
              onClick={(event) => {
                event.stopPropagation();
                toggleAccordionExpanded('filghtExpanded');
              }}
            >
              비행정보
              <span className={filghtExpanded ? 'active' : ''}></span>
              <div className="tag-info-wrap-end">
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      보고서 작성 가이드
                    </a>
                  </div>
                </div>
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      의무보고의 범위
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: filghtExpanded ? '' : 'none' }}>
            <CsrFlightInfo store={formStore} />
          </dd>
        </dl>

        <dl className={eventExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트
              <span className={eventExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid100 ">
                      <div className="form-group wid50">
                        이벤트 카테고리 :{' '}
                        <span style={{ textDecoration: 'underline', fontWeight: 'bold' }}>
                          {CodeService.getCodeLabelByValue('CODE_GRP_155', 'CSR_08')}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AirportSearch
                          label="발생 공항"
                          value={occurAirportCd}
                          onChange={(value) => {
                            changeInput('event.occurAirportCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="Notification-wrap wid50">
                          <p className="notice">Notification</p>
                          <ul>
                            <li>
                              <span className="point">①</span>Safety : Asked about Safety Equipments/Regulations mostly.
                            </li>
                            <li>
                              <span className="point">②</span>Security : Asked about Security Equipments/Regulations
                              mostly.
                            </li>
                            <li>
                              <span className="point">③</span>Alcohol/Drug : About the alcohol/drug test
                            </li>
                            <li>
                              <span className="point">④</span>Others : Excluding the above items.
                            </li>
                          </ul>
                          <p className="info-text01">
                            Do not write a simple boarding of a supervisor without questions/checks for cabin crew
                          </p>
                          <p className="info-text01">
                            Inspection officer boarding is not required for other sectors (operation, maintenance, etc.)
                            other than room inspection purposes
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <div className="flex-between">
                              <div className="form-group wid50">
                                <AppCodeSelect
                                  label="보고종류"
                                  codeGrpId="CODE_GRP_032"
                                  value={etcBriefingKindCd}
                                  onChange={(value) => {
                                    changeBriefingKindCode(value);
                                  }}
                                  required
                                  errorMessage={errors[`event.etcBriefingKindCd`]}
                                />
                              </div>
                              <div className="form-group wid100 ml5">
                                <AppCodeFieldSelect
                                  label="보고항목"
                                  codeGrpId="CODE_GRP_033"
                                  codeFieldId={etcBriefingKindCd}
                                  value={etcBriefingItemCd}
                                  onChange={(value) => {
                                    changeInput(`event.etcBriefingItemCd`, value);
                                  }}
                                  required
                                  errorMessage={errors[`event.etcBriefingItemCd`]}
                                />
                              </div>
                            </div>
                            <label htmlFor="file" className="file-label">
                              보고항목 <span className="required"></span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="Cabin Log 작성"
                          options={Code.reportUseYn}
                          value={cabinLogYn}
                          onChange={(value) => {
                            changeInput(`event.cabinLogYn`, value);
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="승객 탑승 클래스"
                          options={CodeService.getOptions('CODE_GRP_103')}
                          value={paxClsCd}
                          onChange={(value) => {
                            changeInput(`event.paxClsCd`, value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="불/연기/냄새"
                          codeGrpId="CODE_GRP_035"
                          value={fireSmokeSmellCd}
                          onChange={(value) => {
                            changeInput(`event.fireSmokeSmellCd`, value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="발생 위치"
                          codeGrpId="CODE_GRP_022"
                          value={inflightOccurLocationCd}
                          onChange={(value) => {
                            changeInput(`event.inflightOccurLocationCd`, value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="원인물"
                          codeGrpId="CODE_GRP_037"
                          value={etcCauseCd}
                          onChange={(value) => {
                            changeInput(`event.etcCauseCd`, value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="사용한 비상 장비"
                          codeGrpId="CODE_GRP_038"
                          isMultiple
                          value={useEmergencyEquipCodeList}
                          onChange={(value) => {
                            changeInput(`event.useEmergencyEquipCodeList`, value);
                          }}
                          required
                          errorMessage={errors[`event.useEmergencyEquipCodeList`]}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </dd>
        </dl>

        {/* 관련자 테이블 */}
        <dl className={involveExpaned ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('involveExpaned');
            }}
          >
            <button type="button" className="btn-tg">
              관련자 세부 정보
              <span className={involveExpaned ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: involveExpaned ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <CsrInvolveList store={formStore} />
              </div>
            </div>
          </dd>
        </dl>

        {/* 이벤트 내용 */}
        <dl className={eventContentExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventContentExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트 내용
              <span className={eventContentExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventContentExpanded ? '' : 'none' }}>
            <CsrEventContent store={formStore} />
          </dd>
        </dl>
      </div>

      {/* 하단버튼영역 */}
      <ReportEditBottomButton
        formType={formType}
        finalSubmittedYn={report.finalSubmittedYn}
        print={print}
        tempSave={tempSave}
        save={save}
      />
    </>
  );
}

export default ReportCSREditFormOther;
