import { useEffect } from 'react';
import useRsrFormStore from '@/stores/aviation/report/useRsrFormStore';
import ReportEditBottomButton from '../common/ReportEditBottomButton';

function ReportRSREditForm() {
  const formStore = useRsrFormStore();
  const { getTreeCodeList, tempSave, save, print, formType, detailInfo } = formStore;
  const { report = {} } = detailInfo || {};

  useEffect(() => {
    getTreeCodeList();
  }, []);

  return (
    <>
      <ReportEditBottomButton
        formType={formType}
        finalSubmittedYn={report.finalSubmittedYn}
        print={print}
        tempSave={tempSave}
        save={save}
      />
    </>
  );
}
export default ReportRSREditForm;
