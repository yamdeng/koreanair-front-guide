import AppNavigation from '@/components/common/AppNavigation';
import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import useMsrAmoFormStore from '@/stores/aviation/report/useMsrAmoFormStore';
import MsrFlightInfo from '../../common/MsrFlightInfo';
import AppTextInput from '@/components/common/AppTextInput';
import AirportSearch from '@/components/aviation/common/AirportSearch';
import AppEditor from '@/components/common/AppEditor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppCodeFieldSelect from '@/components/common/AppCodeFieldSelect';
import MsrDeviceList from '../../common/MsrDeviceList';

function ReportMSREditFormAMO() {
  const formStore = useMsrAmoFormStore();

  const {
    formName,
    filghtExpanded,
    eventExpanded,
    errors,
    changeInput,
    changeMaintenanceChecked,
    getDetail,
    formValue,
    tempSave,
    save,
    print,
    toggleAccordionExpanded,
    isDirty,
    msrFormPageClear,
    formType,
    detailInfo,
  } = formStore;

  const { report = {} } = detailInfo || {};
  const { event, maintenanceChecked } = formValue;
  const {
    occurAirportCd,
    occurPlaceNm,
    subjectNm,
    descriptionTxtcn,
    fileGroupSeq,
    msrEventTypeCd,
    maintenanceScopeCd,
    engCd,
    compoCd,
    etcCd,
  } = event;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      msrFormPageClear();
    }
  }, [detailId]);

  useEffect(() => {
    return msrFormPageClear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['MSR']} />

      <div className="info-wrap toggle" id="report-edit-form">
        <dl className={filghtExpanded ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button
              type="button"
              className="btn-tg"
              onClick={(event) => {
                event.stopPropagation();
                toggleAccordionExpanded('filghtExpanded');
              }}
            >
              비행정보
              <div className="chk-wrap TopCheck">
                <label>
                  <input
                    type="checkbox"
                    checked={maintenanceChecked}
                    onChange={(event) => {
                      changeMaintenanceChecked(event.target.checked);
                    }}
                  />
                  <span>Heavy Maintenance</span>
                </label>
              </div>
              <span className={filghtExpanded ? 'active' : ''}></span>
              <div className="tag-info-wrap-end">
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      보고서 작성 가이드
                    </a>
                  </div>
                </div>
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      의무보고의 범위
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: filghtExpanded ? '' : 'none' }}>
            <MsrFlightInfo store={formStore} />
          </dd>
        </dl>

        <dl className={eventExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트
              <span className={eventExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table" style={{ display: maintenanceChecked ? '' : 'none' }}>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeFieldSelect
                          label="장비 Scope"
                          codeGrpId="CODE_GRP_171"
                          codeFieldId="maintenanceScope"
                          value={maintenanceScopeCd}
                          onChange={(value) => {
                            changeInput(`event.maintenanceScopeCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.maintenanceScopeCd`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeFieldSelect
                          label="장비 엔진"
                          codeGrpId="CODE_GRP_171"
                          codeFieldId="engine"
                          value={engCd}
                          onChange={(value) => {
                            changeInput(`event.engCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.engCd`]}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table" style={{ display: maintenanceChecked ? '' : 'none' }}>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeFieldSelect
                          label="장비 Components"
                          codeGrpId="CODE_GRP_171"
                          codeFieldId="components"
                          value={compoCd}
                          onChange={(value) => {
                            changeInput(`event.compoCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.compoCd`]}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="장비 기타"
                          codeGrpId="CODE_GRP_171"
                          codeFieldId="etc"
                          value={etcCd}
                          onChange={(value) => {
                            changeInput(`event.etcCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.etcCd`]}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppTextInput
                          label="발생 위치"
                          value={occurPlaceNm}
                          onChange={(value) => {
                            changeInput('event.occurPlaceNm', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AirportSearch
                          label="발생 공항"
                          value={occurAirportCd}
                          onChange={(value) => {
                            changeInput('event.occurAirportCd', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50 ">
                      <div className="form-group wid100">
                        {/*제목*/}
                        <AppTextInput
                          id={`${formName}event.subjectNm`}
                          label="제목"
                          value={subjectNm}
                          onChange={(value) => {
                            changeInput('event.subjectNm', value);
                          }}
                          required
                          errorMessage={errors['event.subjectNm']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100 ">
                        {/*내용 */}
                        <AppEditor
                          id={`${formName}event.descriptionTxtcn`}
                          label="AppEditor"
                          value={descriptionTxtcn}
                          onChange={(value, byPassIsDirty) => {
                            changeInput('event.descriptionTxtcn', value, byPassIsDirty);
                          }}
                          required
                          errorMessage={errors['event.descriptionTxtcn']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppFileAttach
                          label={'첨부파일'}
                          fileGroupSeq={fileGroupSeq}
                          workScope={'A'}
                          updateFileGroupSeq={(newFileGroupSeq) => {
                            changeInput('event.fileGroupSeq', newFileGroupSeq);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="Event"
                          codeGrpId="CODE_GRP_051"
                          value={msrEventTypeCd}
                          onChange={(value) => {
                            changeInput(`event.msrEventTypeCd`, value);
                          }}
                          required
                          errorMessage={errors[`event.msrEventTypeCd`]}
                        />
                      </div>
                    </div>
                  </div>
                  <MsrDeviceList store={formStore} />
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      {/* 하단버튼영역 */}
      <ReportEditBottomButton
        formType={formType}
        finalSubmittedYn={report.finalSubmittedYn}
        print={print}
        tempSave={tempSave}
        save={save}
      />
    </>
  );
}

export default ReportMSREditFormAMO;
