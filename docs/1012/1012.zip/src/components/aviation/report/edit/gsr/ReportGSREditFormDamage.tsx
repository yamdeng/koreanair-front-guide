import AirportSearch from '@/components/aviation/common/AirportSearch';
import ReportEditBottomButton from '@/components/aviation/report/common/ReportEditBottomButton';
import AppCodeSelect from '@/components/common/AppCodeSelect';
import AppDatePicker from '@/components/common/AppDatePicker';
import AppEditor from '@/components/common/AppEditor';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppNavigation from '@/components/common/AppNavigation';
import AppRadioGroup from '@/components/common/AppRadioGroup';
import AppTextArea from '@/components/common/AppTextArea';
import AppTextInput from '@/components/common/AppTextInput';
import Code from '@/config/Code';
import { useFormDirtyCheck } from '@/hooks/useFormDirtyCheck';
import CodeService from '@/services/CodeService';
import useGsrDamageFormStore from '@/stores/aviation/report/useGsrDamageFormStore';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import GsrFlightInfo from '../../common/GsrFlightInfo';

function ReportGSREditFormDamage() {
  const formStore = useGsrDamageFormStore();

  const {
    filghtExpanded,
    eventExpanded,
    errors,
    changeInput,
    changeInputByFormName,
    changeCheckKindRadio,
    getDetail,
    formValue,
    tempSave,
    save,
    print,
    toggleAccordionExpanded,
    isDirty,
    gsrDamageFormPageClear,
    equipListCurrentEditFormValue,
    damageListCurrentEditFormValue,
    damageListCurrentChangingIndex,
    equipListCurrentChangingIndex,
    addDamageList,
    saveDamageList,
    cancelDamageList,
    deleteDamageList,
    updateDamageList,
    addEquipList,
    saveEquipList,
    cancelEquipList,
    deleteEquipList,
    updateEquipList,
    toggleDamageContentExpaned,
    toggleEquipContentExpaned,
    formType,
    detailInfo,
  } = formStore;

  const { report = {} } = detailInfo || {};
  const { event, damageList, equipList } = formValue;
  const {
    occurAirportCd,
    findNotifyCd, // 발견(10), 신고(20)
    findTypeCd,
    occurDttm,
    occurTimezoneCd,
    occurLocationCd,
    operationPhaseCd,
    rampHandlingCd,
    aircraftDamageCauseCd,
    rampStatusCd,
    weatherCodeList,

    aircraftDamageAreaCd,
    aircraftDamageCn,

    relEquipCd,
    regNoNm,
    mntcHistNm,
    relGspCd,
    chargeDeptCd,
    gsrCn,

    injuryYn,
    injuryCn,
    carCn,

    subjectNm,
    descriptionTxtcn,
    fileGroupSeq,
  } = event;

  const generateInputRequired = findNotifyCd === '20' ? true : false;

  const { detailId } = useParams();

  useFormDirtyCheck(isDirty);

  useEffect(() => {
    if (detailId && detailId !== 'add') {
      getDetail(detailId);
    } else if (detailId && detailId === 'add') {
      gsrDamageFormPageClear();
    }
  }, [detailId]);

  useEffect(() => {
    return gsrDamageFormPageClear;
  }, []);

  return (
    <>
      <AppNavigation appendTitleList={['MSR']} />

      <div className="info-wrap toggle" id="report-edit-form">
        <dl className={filghtExpanded ? 'tg-item active' : 'tg-item'}>
          <dt>
            <button
              type="button"
              className="btn-tg"
              onClick={(event) => {
                event.stopPropagation();
                toggleAccordionExpanded('filghtExpanded');
              }}
            >
              비행정보
              <span className={filghtExpanded ? 'active' : ''}></span>
              <div className="tag-info-wrap-end">
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      보고서 작성 가이드
                    </a>
                  </div>
                </div>
                <div className="tip">
                  <div>
                    <a href={undefined} className="txt">
                      의무보고의 범위
                    </a>
                  </div>
                </div>
              </div>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: filghtExpanded ? '' : 'none' }}>
            <GsrFlightInfo store={formStore} />
          </dd>
        </dl>

        <dl className={eventExpanded ? 'tg-item active' : 'tg-item'}>
          <dt
            onClick={(event) => {
              event.stopPropagation();
              toggleAccordionExpanded('eventExpanded');
            }}
          >
            <button type="button" className="btn-tg">
              이벤트
              <span className={eventExpanded ? 'active' : ''}></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: eventExpanded ? '' : 'none' }}>
            <div className="edit-area">
              <div className="detail-form">
                <div className="detail-list">
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="group-box-wrap wid100">
                        <AppRadioGroup
                          label="발견/신고"
                          options={CodeService.getOptions('CODE_GRP_165')}
                          value={findNotifyCd}
                          onChange={(value) => {
                            changeCheckKindRadio(value);
                          }}
                          required
                          errorMessage={errors['event.findNotifyCd']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="발견 유형"
                          codeGrpId="CODE_GRP_124"
                          value={findTypeCd}
                          onChange={(value) => {
                            changeInput('event.findTypeCd', value);
                          }}
                          required={findNotifyCd === '10' ? true : false}
                          disabled={findNotifyCd === '10' ? false : true}
                          placeholder={findNotifyCd === '20' ? 'N/A' : ''}
                          errorMessage={errors['event.findTypeCd']}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        {/*발생 공항 */}
                        <AirportSearch
                          label="발생 공항"
                          value={occurAirportCd}
                          onChange={(value) => {
                            changeInput('event.occurAirportCd', value);
                          }}
                          required={generateInputRequired}
                          disabled={!generateInputRequired}
                          errorMessage={errors['event.occurAirportCd']}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="df">
                          <div className="type3">
                            <AppDatePicker
                              label="발생 시간"
                              excludeSecondsTime
                              showTime
                              value={occurDttm}
                              onChange={(value) => {
                                changeInput('event.occurDttm', value);
                              }}
                              required={generateInputRequired}
                              disabled={!generateInputRequired}
                              errorMessage={errors['event.occurDttm']}
                            />
                          </div>
                          <div className="type4">
                            <AppCodeSelect
                              codeGrpId="CODE_GRP_079"
                              value={occurTimezoneCd}
                              onChange={(value) => {
                                changeInput(`event.occurTimezoneCd`, value);
                              }}
                              required={generateInputRequired}
                              disabled={!generateInputRequired}
                              errorMessage={errors['event.occurTimezoneCd']}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="발생 위치"
                          codeGrpId="CODE_GRP_123"
                          value={occurLocationCd}
                          onChange={(value) => {
                            changeInput(`event.occurLocationCd`, value);
                          }}
                          required={generateInputRequired}
                          disabled={!generateInputRequired}
                          errorMessage={errors['event.occurLocationCd']}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="운영 단계"
                          codeGrpId="CODE_GRP_041"
                          value={operationPhaseCd}
                          onChange={(value) => {
                            changeInput(`event.operationPhaseCd`, value);
                          }}
                          disabled={!generateInputRequired}
                          errorMessage={errors['event.operationPhaseCd']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="램프 조작"
                          codeGrpId="CODE_GRP_122"
                          value={rampHandlingCd}
                          onChange={(value) => {
                            changeInput(`event.rampHandlingCd`, value);
                          }}
                          required={generateInputRequired}
                          disabled={!generateInputRequired}
                          errorMessage={errors['event.rampHandlingCd']}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="항공기 손상 원인"
                          codeGrpId="CODE_GRP_121"
                          value={aircraftDamageCauseCd}
                          onChange={(value) => {
                            changeInput(`event.aircraftDamageCauseCd`, value);
                          }}
                          required={generateInputRequired}
                          disabled={!generateInputRequired}
                          errorMessage={errors['event.aircraftDamageCauseCd']}
                        />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppCodeSelect
                          label="램프 상태"
                          codeGrpId="CODE_GRP_042"
                          value={rampStatusCd}
                          onChange={(value) => {
                            changeInput(`event.rampStatusCd`, value);
                          }}
                          required={generateInputRequired}
                          disabled={!generateInputRequired}
                          errorMessage={errors['event.rampStatusCd']}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        {/*multiple selection 처리 */}
                        <AppCodeSelect
                          label="날씨"
                          isMultiple
                          codeGrpId="CODE_GRP_043"
                          value={weatherCodeList}
                          onChange={(value) => {
                            changeInput('event.weatherCodeList', value);
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="UserChicebox bg">
                          <div className="form-group wid100">
                            <div className="df">
                              <div className="type1">
                                <AppCodeSelect
                                  label="항공기 손상 지역"
                                  codeGrpId="CODE_GRP_044"
                                  value={aircraftDamageAreaCd}
                                  onChange={(value) => {
                                    changeInput(`event.aircraftDamageAreaCd`, value);
                                  }}
                                  required
                                  errorMessage={errors['event.aircraftDamageAreaCd']}
                                />
                              </div>
                              <div className="type2">
                                <AppTextArea
                                  label="내용"
                                  style={{ width: '100%', height: 100 }}
                                  value={aircraftDamageCn}
                                  onChange={(value) => {
                                    changeInput(`event.aircraftDamageCn`, value);
                                  }}
                                  errorMessage={errors['event.aircraftDamageCn']}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 손상정보 table start */}
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        {/*버튼영역*/}
                        <div className="btn-area">
                          <button
                            type="button"
                            name="button"
                            className="btn-x-sm btn_text btn-darkblue-line"
                            onClick={addDamageList}
                          >
                            + ADD
                          </button>
                        </div>
                        {/*추가리스트*/}
                        <div className="form-table">
                          <div className="form-cell Add wid100">
                            <div className="form-group wid100">
                              <div className="box-view-list">
                                <ul className="view-list">
                                  <li className="accumlate-list">
                                    <span className="text-desc-type1">
                                      <div className="info-box ">
                                        <table className="notice-board Air">
                                          <colgroup>
                                            <col width="5%" />
                                            <col width="80%" />
                                            <col width="15%" />
                                          </colgroup>
                                          <tr>
                                            <th></th>
                                            <th>항공기 손상 지역</th>
                                            <th>Action</th>
                                          </tr>
                                          {damageList.map((damageInfo, damageListIndex) => {
                                            const { aircraftDamageAreaCd, aircraftDamageCn, contentExpaned } =
                                              damageInfo;
                                            let damageTrComponent = (
                                              <>
                                                <tr>
                                                  <td className="plus">
                                                    {contentExpaned ? (
                                                      <a
                                                        href={undefined}
                                                        className="btn-minus"
                                                        onClick={() =>
                                                          toggleDamageContentExpaned(damageListIndex, contentExpaned)
                                                        }
                                                      >
                                                        -
                                                      </a>
                                                    ) : (
                                                      <a
                                                        href={undefined}
                                                        className="btn-plus"
                                                        onClick={() =>
                                                          toggleDamageContentExpaned(damageListIndex, contentExpaned)
                                                        }
                                                      >
                                                        +
                                                      </a>
                                                    )}
                                                  </td>
                                                  <td className="left">
                                                    {CodeService.getCodeLabelByValue(
                                                      'CODE_GRP_044',
                                                      aircraftDamageAreaCd
                                                    )}
                                                  </td>
                                                  <td className="btns">
                                                    <a
                                                      href={undefined}
                                                      className="btn-modify"
                                                      style={{
                                                        display: damageListCurrentChangingIndex === -1 ? '' : 'none',
                                                      }}
                                                      onClick={() => updateDamageList(damageListIndex, damageInfo)}
                                                    >
                                                      수정{' '}
                                                    </a>
                                                    <a
                                                      href={undefined}
                                                      className="btn-delete"
                                                      style={{
                                                        display: damageListCurrentChangingIndex === -1 ? '' : 'none',
                                                      }}
                                                      onClick={() => deleteDamageList(damageListIndex)}
                                                    >
                                                      삭제{' '}
                                                    </a>
                                                  </td>
                                                </tr>
                                                <tr style={{ display: contentExpaned ? '' : 'none' }}>
                                                  <td colSpan={3} className="left deps-conts">
                                                    {aircraftDamageCn}
                                                  </td>
                                                </tr>
                                              </>
                                            );
                                            if (
                                              damageListCurrentChangingIndex !== -1 &&
                                              damageListIndex === damageListCurrentChangingIndex
                                            ) {
                                              damageTrComponent = (
                                                <>
                                                  <tr>
                                                    <td className="plus">
                                                      {damageListCurrentEditFormValue.contentExpaned ? (
                                                        <a
                                                          href={undefined}
                                                          className="btn-minus"
                                                          onClick={() =>
                                                            changeInputByFormName(
                                                              'damageListCurrentEditFormValue',
                                                              'contentExpaned',
                                                              !damageListCurrentEditFormValue.contentExpaned
                                                            )
                                                          }
                                                        >
                                                          -
                                                        </a>
                                                      ) : (
                                                        <a
                                                          href={undefined}
                                                          className="btn-plus"
                                                          onClick={() =>
                                                            changeInputByFormName(
                                                              'damageListCurrentEditFormValue',
                                                              'contentExpaned',
                                                              !damageListCurrentEditFormValue.contentExpaned
                                                            )
                                                          }
                                                        >
                                                          +
                                                        </a>
                                                      )}
                                                    </td>
                                                    <td className="left">
                                                      {' '}
                                                      <div className="form-table wid50">
                                                        <AppCodeSelect
                                                          placeholder="항공기 손상 지역"
                                                          codeGrpId="CODE_GRP_044"
                                                          value={damageListCurrentEditFormValue.aircraftDamageAreaCd}
                                                          onChange={(value) =>
                                                            changeInputByFormName(
                                                              'damageListCurrentEditFormValue',
                                                              'aircraftDamageAreaCd',
                                                              value
                                                            )
                                                          }
                                                        />
                                                      </div>
                                                    </td>
                                                    <td className="btns">
                                                      <a
                                                        href={undefined}
                                                        className="btn-modify"
                                                        onClick={saveDamageList}
                                                      >
                                                        저장{' '}
                                                      </a>
                                                      <a
                                                        href={undefined}
                                                        className="btn-delete"
                                                        onClick={cancelDamageList}
                                                      >
                                                        취소{' '}
                                                      </a>
                                                    </td>
                                                  </tr>
                                                  <tr
                                                    style={{
                                                      display: damageListCurrentEditFormValue.contentExpaned
                                                        ? ''
                                                        : 'none',
                                                    }}
                                                  >
                                                    <td colSpan={3} className="left deps-conts">
                                                      <AppTextArea
                                                        label=""
                                                        style={{
                                                          width: '100%',
                                                          height: 145,
                                                        }}
                                                        value={damageListCurrentEditFormValue.aircraftDamageCn}
                                                        onChange={(value) =>
                                                          changeInputByFormName(
                                                            'damageListCurrentEditFormValue',
                                                            'aircraftDamageCn',
                                                            value
                                                          )
                                                        }
                                                      />
                                                    </td>
                                                  </tr>
                                                </>
                                              );
                                            }
                                            return damageTrComponent;
                                          })}
                                        </table>
                                      </div>
                                    </span>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* 손상정보 table end */}

                  {/* 관련 장비 시설 form start */}
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="UserChicebox bg">
                          <div className="form-group wid100">
                            <div className="df">
                              <div className="type6">
                                <AppCodeSelect
                                  label="관련 장비/시설"
                                  codeGrpId="CODE_GRP_045"
                                  value={relEquipCd}
                                  onChange={(value) => {
                                    changeInput(`event.relEquipCd`, value);
                                  }}
                                  required
                                  errorMessage={errors['event.relEquipCd']}
                                />
                              </div>
                              <div className="type6">
                                <AppTextInput
                                  label="등록 부호"
                                  value={regNoNm}
                                  onChange={(value) => {
                                    changeInput(`event.regNoNm`, value);
                                  }}
                                />
                              </div>
                            </div>
                            <div className="df">
                              <div className="type6">
                                <AppTextInput
                                  label="유지보수 이력"
                                  value={mntcHistNm}
                                  onChange={(value) => {
                                    changeInput(`event.mntcHistNm`, value);
                                  }}
                                />
                              </div>
                              <div className="type6">
                                <AppCodeSelect
                                  label="관련 GSP"
                                  codeGrpId="CODE_GRP_167"
                                  value={relGspCd}
                                  onChange={(value) => {
                                    changeInput(`event.relGspCd`, value);
                                  }}
                                />
                              </div>
                            </div>
                            <div className="df">
                              <div className="type6 Wd">
                                <AppCodeSelect
                                  label="담당부서"
                                  codeGrpId="CODE_GRP_046"
                                  value={chargeDeptCd}
                                  onChange={(value) => {
                                    changeInput(`event.chargeDeptCd`, value);
                                  }}
                                />
                              </div>
                            </div>
                            <div className="df">
                              <div className="type6 Wd">
                                <AppTextArea
                                  label="내용"
                                  value={gsrCn}
                                  onChange={(value) => {
                                    changeInput(`event.gsrCn`, value);
                                  }}
                                  style={{ width: '100%', height: 100 }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* 관련 장비 시설 form end  */}

                  {/* 관련 장비 시설 table start */}
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        {/*버튼영역*/}
                        <div className="btn-area">
                          <button
                            type="button"
                            name="button"
                            className="btn-x-sm btn_text btn-darkblue-line"
                            onClick={addEquipList}
                          >
                            + ADD
                          </button>
                        </div>
                        {/*추가리스트*/}
                        <div className="form-table">
                          <div className="form-cell Add wid100">
                            <div className="form-group wid100">
                              <div className="box-view-list">
                                <ul className="view-list">
                                  <li className="accumlate-list">
                                    <span className="text-desc-type1">
                                      <div className="info-box ">
                                        <table className="notice-board Air2">
                                          <colgroup>
                                            <col width="5%" />
                                            <col width="20%" />
                                            <col width="15%" />
                                            <col width="15%" />
                                            <col width="15%" />
                                            <col width="15%" />
                                            <col width="15%" />
                                          </colgroup>
                                          <tr>
                                            <th></th>
                                            <th>관련 장비/시설</th>
                                            <th>등록 부호</th>
                                            <th>유지보수 이력</th>
                                            <th>관련 GSP</th>
                                            <th>담당부서</th>
                                            <th>Action</th>
                                          </tr>
                                          {equipList.map((equipInfo, equipListIndex) => {
                                            const {
                                              relEquipCd,
                                              regNoNm,
                                              mntcHistNm,
                                              relGspCd,
                                              chargeDeptCd,
                                              gsrCn,
                                              contentExpaned,
                                            } = equipInfo;
                                            let equipTrComponent = (
                                              <>
                                                <tr>
                                                  <td className="plus">
                                                    {contentExpaned ? (
                                                      <a
                                                        href={undefined}
                                                        className="btn-minus"
                                                        onClick={() =>
                                                          toggleEquipContentExpaned(equipListIndex, contentExpaned)
                                                        }
                                                      >
                                                        -
                                                      </a>
                                                    ) : (
                                                      <a
                                                        href={undefined}
                                                        className="btn-plus"
                                                        onClick={() =>
                                                          toggleEquipContentExpaned(equipListIndex, contentExpaned)
                                                        }
                                                      >
                                                        +
                                                      </a>
                                                    )}
                                                  </td>
                                                  <td className="left Sel">
                                                    {CodeService.getCodeLabelByValue('CODE_GRP_045', relEquipCd)}
                                                  </td>
                                                  <td className="left Sel">{regNoNm}</td>
                                                  <td className="left Sel">{mntcHistNm}</td>
                                                  <td className="left Sel">
                                                    {CodeService.getCodeLabelByValue('CODE_GRP_167', relGspCd)}
                                                  </td>
                                                  <td className="left Sel">
                                                    {CodeService.getCodeLabelByValue('CODE_GRP_046', chargeDeptCd)}
                                                  </td>
                                                  <td className="btns">
                                                    <a
                                                      href={undefined}
                                                      className="btn-modify"
                                                      style={{
                                                        display: equipListCurrentChangingIndex === -1 ? '' : 'none',
                                                      }}
                                                      onClick={() => updateEquipList(equipListIndex, equipInfo)}
                                                    >
                                                      수정
                                                    </a>
                                                    <a
                                                      href={undefined}
                                                      className="btn-delete"
                                                      style={{
                                                        display: equipListCurrentChangingIndex === -1 ? '' : 'none',
                                                      }}
                                                      onClick={() => deleteEquipList(equipListIndex)}
                                                    >
                                                      삭제
                                                    </a>
                                                  </td>
                                                </tr>
                                                <tr style={{ display: contentExpaned ? '' : 'none' }}>
                                                  <td colSpan={7} className="left deps-conts">
                                                    {gsrCn}
                                                  </td>
                                                </tr>
                                              </>
                                            );

                                            if (
                                              equipListCurrentChangingIndex !== -1 &&
                                              equipListIndex === equipListCurrentChangingIndex
                                            ) {
                                              equipTrComponent = (
                                                <>
                                                  <tr>
                                                    <td className="plus">
                                                      {equipListCurrentEditFormValue.contentExpaned ? (
                                                        <a
                                                          href={undefined}
                                                          className="btn-minus"
                                                          onClick={() =>
                                                            changeInputByFormName(
                                                              'equipListCurrentEditFormValue',
                                                              'contentExpaned',
                                                              !equipListCurrentEditFormValue.contentExpaned
                                                            )
                                                          }
                                                        >
                                                          -
                                                        </a>
                                                      ) : (
                                                        <a
                                                          href={undefined}
                                                          className="btn-plus"
                                                          onClick={() =>
                                                            changeInputByFormName(
                                                              'equipListCurrentEditFormValue',
                                                              'contentExpaned',
                                                              !equipListCurrentEditFormValue.contentExpaned
                                                            )
                                                          }
                                                        >
                                                          +
                                                        </a>
                                                      )}
                                                    </td>
                                                    <td className="Sel">
                                                      <AppCodeSelect
                                                        placeholder="항공기 손상 지역"
                                                        codeGrpId="CODE_GRP_045"
                                                        value={equipListCurrentEditFormValue.relEquipCd}
                                                        onChange={(value) =>
                                                          changeInputByFormName(
                                                            'equipListCurrentEditFormValue',
                                                            'relEquipCd',
                                                            value
                                                          )
                                                        }
                                                      />
                                                    </td>
                                                    <td className="Sel">
                                                      <AppTextInput
                                                        value={equipListCurrentEditFormValue.regNoNm}
                                                        onChange={(value) =>
                                                          changeInputByFormName(
                                                            'equipListCurrentEditFormValue',
                                                            'regNoNm',
                                                            value
                                                          )
                                                        }
                                                      />
                                                    </td>
                                                    <td className="Sel">
                                                      <AppTextInput
                                                        value={equipListCurrentEditFormValue.mntcHistNm}
                                                        onChange={(value) =>
                                                          changeInputByFormName(
                                                            'equipListCurrentEditFormValue',
                                                            'mntcHistNm',
                                                            value
                                                          )
                                                        }
                                                      />
                                                    </td>
                                                    <td className="Sel">
                                                      <AppCodeSelect
                                                        placeholder="관련 GSP"
                                                        codeGrpId="CODE_GRP_167"
                                                        value={equipListCurrentEditFormValue.relGspCd}
                                                        onChange={(value) =>
                                                          changeInputByFormName(
                                                            'equipListCurrentEditFormValue',
                                                            'relGspCd',
                                                            value
                                                          )
                                                        }
                                                      />
                                                    </td>
                                                    <td className="Sel">
                                                      <AppCodeSelect
                                                        placeholder="담당부서"
                                                        codeGrpId="CODE_GRP_046"
                                                        value={equipListCurrentEditFormValue.chargeDeptCd}
                                                        onChange={(value) =>
                                                          changeInputByFormName(
                                                            'equipListCurrentEditFormValue',
                                                            'chargeDeptCd',
                                                            value
                                                          )
                                                        }
                                                      />
                                                    </td>
                                                    <td className="btns">
                                                      <a
                                                        href={undefined}
                                                        className="btn-modify"
                                                        onClick={saveEquipList}
                                                      >
                                                        저장{' '}
                                                      </a>
                                                      <a
                                                        href={undefined}
                                                        className="btn-delete"
                                                        onClick={cancelEquipList}
                                                      >
                                                        취소{' '}
                                                      </a>
                                                    </td>
                                                  </tr>
                                                  <tr
                                                    style={{
                                                      display: equipListCurrentEditFormValue.contentExpaned
                                                        ? ''
                                                        : 'none',
                                                    }}
                                                  >
                                                    <td colSpan={7} className="left deps-conts">
                                                      <AppTextArea
                                                        label=""
                                                        style={{ width: '100%', height: 145 }}
                                                        value={equipListCurrentEditFormValue.gsrCn}
                                                        onChange={(value) =>
                                                          changeInputByFormName(
                                                            'equipListCurrentEditFormValue',
                                                            'gsrCn',
                                                            value
                                                          )
                                                        }
                                                      />
                                                    </td>
                                                  </tr>
                                                </>
                                              );
                                            }

                                            return equipTrComponent;
                                          })}
                                        </table>
                                      </div>
                                    </span>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* 관련 장비 시설 table end */}

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <div className="UserChicebox bg">
                          <div className="form-group wid100">
                            <div className="df">
                              <div className="group-box-wrap wid100">
                                <AppRadioGroup
                                  label="부상정보"
                                  options={Code.reportUseYn}
                                  value={injuryYn}
                                  onChange={(value) => {
                                    changeInput('event.injuryYn', value);
                                  }}
                                  errorMessage={errors['event.injuryYn']}
                                  required
                                />
                              </div>
                            </div>
                            <div className="df">
                              <div className="type6 Wd">
                                <AppTextArea
                                  label="내용"
                                  style={{ width: '100%', height: 100 }}
                                  value={injuryCn}
                                  onChange={(value) => {
                                    changeInput('event.injuryCn', value);
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        {/*추가리스트*/}
                        <div className="form-table">
                          <div className="form-cell wid50 ">
                            <div className="form-group wid100">
                              {/*조치사항*/}
                              <AppTextArea
                                label="조치사항"
                                style={{ width: '100%', height: 100 }}
                                value={carCn}
                                onChange={(value) => {
                                  changeInput('event.carCn', value);
                                }}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="form-table">
                          <div className="form-cell wid50 ">
                            <div className="form-group wid100">
                              <AppTextInput
                                label="제목"
                                value={subjectNm}
                                onChange={(value) => {
                                  changeInput('event.subjectNm', value);
                                }}
                                required
                                errorMessage={errors['event.subjectNm']}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="form-table">
                          <div className="form-cell wid50">
                            <div className="group-box-wrap1 wid100 ">
                              <AppEditor
                                id={`event.descriptionTxtcn`}
                                label="AppEditor"
                                value={descriptionTxtcn}
                                onChange={(value, byPassIsDirty) => {
                                  changeInput('event.descriptionTxtcn', value, byPassIsDirty);
                                }}
                                required
                                errorMessage={errors['event.descriptionTxtcn']}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="form-table">
                          <div className="form-cell Add wid50">
                            <div className="form-group wid100">
                              <AppFileAttach
                                label={'첨부파일'}
                                fileGroupSeq={fileGroupSeq}
                                workScope={'A'}
                                updateFileGroupSeq={(newFileGroupSeq) => {
                                  changeInput('event.fileGroupSeq', newFileGroupSeq);
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* form end <detail-list/> */}
                </div>
              </div>
            </div>
          </dd>
        </dl>
      </div>

      {/* 하단버튼영역 */}

      <ReportEditBottomButton
        formType={formType}
        finalSubmittedYn={report.finalSubmittedYn}
        print={print}
        tempSave={tempSave}
        save={save}
      />
    </>
  );
}

export default ReportGSREditFormDamage;
