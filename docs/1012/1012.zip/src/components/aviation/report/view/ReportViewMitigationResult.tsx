import AppDatePicker from '@/components/common/AppDatePicker';
import AppTextArea from '@/components/common/AppTextArea';
import AppFileAttach from '@/components/common/AppFileAttach';
import ReportViewStore from '@/stores/aviation/report/view/ReportViewStore';
import ReportViewMitigationResultStore from '@/stores/aviation/report/view/ReportViewMitigationResultStore';

/* 보고서상세 > 보고서 분석 > 경감조치 > 경감실행 */
function ReportViewMitigationResult() {
  const toggleAccordionExpanded = ReportViewStore((state) => state.toggleAccordionExpanded);
  const mitigationResultExpanded = ReportViewStore((state) => state.mitigationResultExpanded);
  const isStep6Open = ReportViewStore((state) => state.isStep6Open);

  return (
    <div className="detailForm-detail-3deps list-group" id="view-mitigation_result">
      <div className="list bx-toggle">
        <dl className="tg-item rbox01 ">
          <dt onClick={() => toggleAccordionExpanded('mitigationResultExpanded')}>
            <button type="button" className="tg-btn">
              경감실행
              <span
                style={{ display: isStep6Open === 'Y' ? '' : 'none' }}
                className={mitigationResultExpanded ? 'active' : ''}
              ></span>
            </button>
          </dt>
          <dd className="tg-conts" style={{ display: mitigationResultExpanded && isStep6Open === 'Y' ? '' : 'none' }}>
            <div className="edit-area">
              <div className="listtable">
                <table className="info-board">
                  <colgroup>
                    <col width="25%" />
                    <col width="18%" />
                    <col width="12%" />
                    <col width="8%" />
                    <col width="18%" />
                    <col width="10%" />
                    <col width="9%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>Hazard</th>
                      <th>Potential Consequence</th>
                      <th>Risk Level 1</th>
                      <th>Team</th>
                      <th>Mitigation Result</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr
                      onClick={() => {
                        // TODO
                      }}
                    >
                      <td className="tl">Lightning strike Environmental/Weather</td>
                      <td className="tl">Aircraft Change</td>
                      <td>
                        <div className="Safety-table-cell">
                          <span className="Safety-tag riskLevel level1">3A</span>
                        </div>
                      </td>
                      <td className="fix vm">운항지원팀</td>
                      <td className="tl"></td>
                      <td>대기</td>
                      <td></td>
                    </tr>
                    <tr style={{ display: '' }}>
                      <td colSpan={7} className="tl">
                        {/*상세조회 */}
                        <div className="edit-area report">
                          <div className="detail-form">
                            <div className="detail-list">
                              <div className="form-table">
                                <div className="form-cell wid50">
                                  <div className="form-group wid100">
                                    <div className="UserChicebox report">
                                      <span className="txt">Duty Person </span>
                                      <div className="form-group wid100 mt10">
                                        <div className="SelectedList memberClass mt10">
                                          <ul>
                                            <li>
                                              <span className="InfoBox"></span>
                                              <div className="Info">
                                                <div className="Name">홍길동 (170****)</div>
                                                <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                                              </div>
                                            </li>
                                            <li>
                                              <span className="InfoBox"></span>
                                              <div className="Info">
                                                <div className="Name">홍길동 (170****)</div>
                                                <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                                              </div>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="form-table">
                                <div className="form-cell wid50">
                                  <div className="form-group wid50">
                                    <div className="form-group wid100">
                                      <AppDatePicker label="Plan Due Date" required />
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="form-table">
                                <div className="form-cell wid50 ">
                                  <div className="form-group wid100">
                                    <AppTextArea
                                      label="Plan"
                                      style={{ width: '100%', height: 100 }}
                                      errorMessage=""
                                      placeholder=""
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="form-table">
                                <div className="form-cell wid50">
                                  <div className="form-group wid50">
                                    <div className="form-group wid100">
                                      <AppDatePicker label="Plan Input Date" required />
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="form-table">
                                <div className="form-cell wid50 ">
                                  <div className="form-group wid100">
                                    <AppTextArea
                                      label="Result"
                                      style={{ width: '100%', height: 100 }}
                                      errorMessage=""
                                      placeholder=""
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="form-table">
                                <div className="form-cell wid50">
                                  <div className="form-group wid50">
                                    <div className="date2">
                                      <AppDatePicker label="Result Input Data" required />
                                    </div>
                                  </div>
                                </div>
                              </div>
                              {/* 파일첨부영역 : drag */}
                              <div className="form-table ">
                                <div className="form-cell wid50">
                                  <div className="form-group wid100">
                                    <AppFileAttach />
                                  </div>
                                </div>
                              </div>
                              {/* 하단버튼영역 */}
                              <div className="contents-btns">
                                <button type="button" name="button" className="btn_text btn-del">
                                  인쇄
                                </button>
                                <button
                                  type="button"
                                  name="button"
                                  className="btn_text text_color_neutral-10 btn_confirm"
                                >
                                  저장
                                </button>
                                <button
                                  type="button"
                                  name="button"
                                  className="btn_text text_color_neutral-10 btn_confirm"
                                >
                                  Submit
                                </button>
                                <button type="button" name="button" className="btn_text btn_list">
                                  목록
                                </button>
                              </div>
                              {/*//하단버튼영역*/}
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td className="tl">Sandstorm Environmental/Weather</td>
                      <td className="tl">Escape slide deployment</td>
                      <td>
                        <div className="Safety-table-cell">
                          <span className="Safety-tag riskLevel level3">2B</span>
                        </div>
                      </td>
                      <td className="fix vm">정비안전보건팀</td>
                      <td className="tl"></td>
                      <td>대기</td>
                      <td></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </dd>
        </dl>
      </div>
    </div>
  );
}

export default ReportViewMitigationResult;
