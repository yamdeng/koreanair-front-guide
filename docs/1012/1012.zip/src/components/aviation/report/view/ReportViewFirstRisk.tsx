import ReportViewFirstRiskAssessment from './ReportViewFirstRiskAssessment';
import ReportViewFirstRiskReview from './ReportViewFirstRiskReview';

/* 보고서상세 > 보고서 분석 > 1차 위험도 평가 */
function ReportViewFirstRisk() {
  return (
    <div className="edit-area">
      <ReportViewFirstRiskAssessment />
      <ReportViewFirstRiskReview />
    </div>
  );
}

export default ReportViewFirstRisk;
