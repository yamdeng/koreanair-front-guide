import AppAutoComplete from '@/components/common/AppAutoComplete';
import AppFileAttach from '@/components/common/AppFileAttach';
import AppSelect from '@/components/common/AppSelect';
import AppTextArea from '@/components/common/AppTextArea';
import ReportViewReceptionStore from '@/stores/aviation/report/view/ReportViewReceptionStore';
import ReportViewStore from '@/stores/aviation/report/view/ReportViewStore';
import ReportDetail from '../detail/ReportDetail';

/* 보고서상세 > 보고서 분석 > 접수 */
function ReportViewReception() {
  const toggleAccordionExpanded = ReportViewStore((state) => state.toggleAccordionExpanded);
  const receptionDetailExpanded = ReportViewStore((state) => state.receptionDetailExpanded);
  const reportList = ReportViewReceptionStore((state) => state.reportList);
  const reportAccordionExpandList = ReportViewReceptionStore((state) => state.reportAccordionExpandList);
  const toggleReportAccordionExpandList = ReportViewReceptionStore((state) => state.toggleReportAccordionExpandList);
  const isStep1Open = ReportViewStore((state) => state.isStep1Open);

  return (
    <div className="edit-area">
      <div className="detailForm-detail-3deps list-group">
        <div className="list bx-toggle">
          <dl className="tg-item rbox01 ">
            <dt onClick={() => toggleAccordionExpanded('receptionDetailExpanded')}>
              <button type="button" className="tg-btn">
                보고서접수
                <span
                  style={{ display: isStep1Open === 'Y' ? '' : 'none' }}
                  className={receptionDetailExpanded ? 'active' : ''}
                ></span>
              </button>
            </dt>
            <dd className="tg-conts" style={{ display: receptionDetailExpanded && isStep1Open === 'Y' ? '' : 'none' }}>
              <div className="edit-area">
                {/*보고서접수-ASR*/}
                <div className="editbox">
                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSelect label={'이벤트타입'} />
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="chk-wrap">
                        <label>
                          <input type="checkbox" />
                          <span>SPI 지표포함</span>
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSelect label={'ATA Chapter'} />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSelect label={'규제기관 보고'} />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSelect label={'보고항목 구분'} />
                      </div>
                    </div>
                  </div>

                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextArea label={'Event Summary'} style={{ width: '100%', height: 100 }} />
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppTextArea label={'Event Follow up'} style={{ width: '100%', height: 100 }} />
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="group-box-wrap wid50">
                        <span className="txt">Report Links</span>
                        <div className="round-wrap">
                          <span className="icon_report"></span>{' '}
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="btn-area">
                        <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                          Report Links
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="form-table line">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        {/* 파일첨부영역 : drag */}
                        <AppFileAttach />
                      </div>
                    </div>
                  </div>

                  {/* 이 부분수정 */}
                  <div className="form-table">
                    <div className="form-cell wid100">
                      <div className="form-group wid100">
                        <div className="UserChicebox">
                          <div className="form-group wid100">
                            <AppSelect label={'LSC Member'} />
                            <label htmlFor="file" className="file-label">
                              LSC Member <span className="required"></span>
                            </label>
                          </div>
                          <div className="form-group wid100 mt10">
                            <AppAutoComplete label="d" />
                            <div className="SelectedList memberClass mt10">
                              <ul>
                                <li>
                                  <span className="InfoBox"></span>
                                  <div className="Info">
                                    <div className="Name">홍길동 (170****)</div>
                                    <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                                  </div>
                                  <span className="class leader">Leader</span>
                                  <a href="javascript:void(0);">
                                    <span className="delete">X</span>
                                  </a>
                                </li>
                                <li>
                                  <span className="InfoBox"></span>
                                  <div className="Info">
                                    <div className="Name">홍길동 (170****)</div>
                                    <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                                  </div>
                                  <span className="class ">Leader</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid100">
                      <div className="btn-area">
                        <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line">
                          LSC Member 그룹 추가
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                {/* 이 부분수정 */}

                {/*보고서접수-ASR*/}
                <div className="form-table ">
                  <div className="form-cell wid100">
                    <div className="form-group wid100">
                      <div className="info-list">
                        <div className="btn-area inbtn mb5">
                          <button name="button" className="btn_text btn_confirm text_color_neutral-10">
                            대표보고서 지정
                          </button>
                          <button name="button" className="btn_text btn_confirm text_color_neutral-10">
                            보고서 추가
                          </button>
                        </div>
                        <table className="notice-board">
                          <colgroup>
                            <col width="5%" />
                            <col width="8%" />
                            <col width="10%" />
                            <col width="34%" />
                            <col width="10%" />
                            <col width="10%" />
                            <col width="10%" />
                            <col width="10%" />
                          </colgroup>
                          <tr className="fix-bg">
                            <th>선택</th>
                            <th>대표보고서</th>
                            <th>Doc No.</th>
                            <th className="left">Subject</th>
                            <th>Fleet</th>
                            <th>Reg No.</th>
                            <th>FLT No.</th>
                            <th>Action</th>
                          </tr>
                          <tr>
                            <td className="fix vm">
                              <div className="radio-wrap center">
                                <label className="text-no">
                                  <input type="radio" />
                                  <span className="text-no"></span>
                                </label>
                              </div>
                            </td>
                            <td className="bot-left">Y</td>
                            <td className="">
                              <a href="javascript:void(0);">ASR-100308</a>
                            </td>
                            <td className="left">1운항 중 발생한 사항에 대..</td>
                            <td className="">777</td>
                            <td className="">7205</td>
                            <td className="">KE0024</td>
                            <td>
                              <a href="javascript:void(0);">
                                <span className="delete">X</span>
                              </a>
                            </td>
                          </tr>
                          <tr>
                            <td className="fix vm">
                              <div className="radio-wrap center">
                                <label className="text-no">
                                  <input type="radio" />
                                  <span className="text-no"></span>
                                </label>
                              </div>
                            </td>
                            <td className="bot-left">Y</td>
                            <td className="">
                              <a href="javascript:void(0);">ASR-100314</a>
                            </td>
                            <td className="left">1운항 중 발생한 사항에 대..</td>
                            <td className="">777</td>
                            <td className="">7205</td>
                            <td className="">KE0024</td>
                            <td>
                              <a href="javascript:void(0);">
                                <span className="delete">X</span>
                              </a>
                            </td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                {/*보고서 상세*/}

                <div className="detailForm-detail-4deps info-wrap list-group mt10">
                  <div className="list bx-toggle">
                    {reportList.map((reportInfo, index) => {
                      const { reportId, docNo } = reportInfo;
                      return (
                        <dl className="tg-item rbox01" key={reportId}>
                          <dt onClick={() => toggleReportAccordionExpandList(index)}>
                            <button type="button" className="tg-btn">
                              - Doc No. {docNo}
                              <span className={reportAccordionExpandList[index] ? 'active' : ''}></span>
                              {/* 상세 페이지 펼처졌을 시 active*/}
                            </button>
                          </dt>
                          <dd className="tg-conts" style={{ display: reportAccordionExpandList[index] ? '' : 'none' }}>
                            {/* 상세*/}
                            <div className="edit-area">
                              <ReportDetail reportId={reportId} />
                            </div>
                            {/* //상세*/}
                          </dd>
                        </dl>
                      );
                    })}
                  </div>
                  {/* 하단버튼영역 */}
                  <div className="contents-btns">
                    <button type="button" name="button" className="btn_text btn-del">
                      인쇄
                    </button>
                    <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
                      저장
                    </button>
                    <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
                      Submit
                    </button>
                    <button type="button" name="button" className="btn_text btn_list">
                      목록
                    </button>
                  </div>
                  {/*//하단버튼영역*/}
                </div>
                {/* //보고서 상세*/}
              </div>
            </dd>
          </dl>
        </div>
      </div>
    </div>
  );
}

export default ReportViewReception;
