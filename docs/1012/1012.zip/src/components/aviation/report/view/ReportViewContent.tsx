import ReportViewStore from '@/stores/aviation/report/view/ReportViewStore';
import ReportDetail from '../detail/ReportDetail';

/* 보고서상세 > 보고서 내용보기 */
function ReportViewContent() {
  const reportId = ReportViewStore((state) => state.reportId);
  return <ReportDetail reportId={reportId} />;
}

export default ReportViewContent;
