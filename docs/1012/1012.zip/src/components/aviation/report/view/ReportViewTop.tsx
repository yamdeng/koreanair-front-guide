import ReportViewStore from '@/stores/aviation/report/view/ReportViewStore';
import AviationUtil from '@/utils/AviationUtil';

function ReportViewTop() {
  const clickStep = ReportViewStore((state) => state.clickStep);
  const reportList = ReportViewStore((state) => state.reportList);
  const displayReportListToolTip = ReportViewStore((state) => state.displayReportListToolTip);
  const toggleDisplayReportListToolTip = ReportViewStore((state) => state.toggleDisplayReportListToolTip);
  const docNo = ReportViewStore((state) => state.docNo);
  const reportType = ReportViewStore((state) => state.reportType);
  const selectReportId = ReportViewStore((state) => state.selectReportId);
  const currentStep = ReportViewStore((state) => state.currentStep);

  // 툴팁 icon 클릭 핸들러
  const clickReportListToolTipIcon = (event) => {
    event.stopPropagation();
    toggleDisplayReportListToolTip();
  };

  // 보고서 목록 클릭
  const clickReportList = (event, reportInfo) => {
    const { reportId } = reportInfo;
    event.stopPropagation();
    selectReportId(reportId);
  };

  return (
    <>
      <div className="conts-title">
        <h2 className="reportview">
          보고서 보기({reportType.toUpperCase()})
          <span>
            <a href={undefined}>{docNo}</a>
          </span>
          <ul className="section-button" style={{ display: reportList.length > 1 ? '' : '' }}>
            <li className="icon_report tooltip" onClick={clickReportListToolTipIcon}>
              <div className="sub_info" style={{ display: displayReportListToolTip ? '' : 'none' }}>
                <ul className="info-box">
                  {reportList.map((reportInfo) => {
                    const { docNo } = reportInfo;
                    return (
                      <li key={docNo} onClick={(event) => clickReportList(event, reportInfo)}>
                        <a href={undefined}>{docNo}</a>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </li>
            <em>({reportList.length})</em>
          </ul>
        </h2>
      </div>
      <div className="Report-step-area">
        <div className="c-step-wrap">
          <ol className="c-step-list-type-5">
            <li className={AviationUtil.getParaentStepByCurrentStep(currentStep) === 1 ? 'active' : ''}>
              {/* 선택된 class명에 active */}
              <a href={undefined} data-label="접수">
                {/* 선택된 class명에 active */}
                <p className="info-title active">
                  <span className="hide">1단계</span>
                  접수
                </p>
              </a>
              <span className="after-arrow"></span>
            </li>
            <li className={AviationUtil.getParaentStepByCurrentStep(currentStep) === 2 ? 'active' : ''}>
              <a href={undefined} data-label="1차 위험평가">
                <p className="info-title">
                  <span className="hide">2단계</span>
                  1차 위험평가
                </p>
              </a>
              <span className="after-arrow"></span>
            </li>
            <li className={AviationUtil.getParaentStepByCurrentStep(currentStep) === 3 ? 'active' : ''}>
              <a href={undefined} data-label="경감조치">
                <p className="info-title">
                  <span className="hide">3단계</span>
                  경감조치
                </p>
              </a>
              <span className="after-arrow"></span>
            </li>
            <li className={AviationUtil.getParaentStepByCurrentStep(currentStep) === 4 ? 'active' : ''}>
              <a href={undefined} data-label="2차 위험평가">
                <p className="info-title">
                  <span className="hide">4단계</span>
                  2차 위험평가
                </p>
              </a>
              <span className="after-arrow"></span>
            </li>
            <li className={AviationUtil.getParaentStepByCurrentStep(currentStep) === 5 ? 'active' : ''}>
              <a href={undefined} data-label="종결">
                <p className="info-title">
                  <span className="hide">5단계</span>
                  종결
                </p>
              </a>
            </li>
          </ol>
          {/*접수단계 step*/}
          <div className="c-step-wrap -mb-8n-3">
            <ol className="c-step-list default">
              {/*선택되는 부분에 class명 active붙이기*/}
              <li className={currentStep === 1 ? 'active' : ''}>
                <p className="info-title" onClick={() => clickStep(1)}>
                  <span className="hide">1단계</span> 보고서접수
                  <span className="hide">현재 </span>
                </p>
              </li>
              <li className={currentStep === 2 ? 'active' : ''}>
                <p className="info-title" onClick={() => clickStep(2)}>
                  <span className="hide">2단계</span> 위험평가
                  <span className="hide">현재 </span>
                </p>
              </li>
              <li className={currentStep === 3 ? 'active' : ''}>
                <p className="info-title" onClick={() => clickStep(3)}>
                  <span className="hide">3단계</span> SRC리뷰
                  <span className="hide">현재 </span>
                </p>
              </li>
              <li className={currentStep === 4 ? 'active' : ''}>
                <p className="info-title" onClick={() => clickStep(4)}>
                  <span className="hide">4단계</span> 경감지정
                  <span className="hide">현재 </span>
                </p>
              </li>
              <li className={currentStep === 5 ? 'active' : ''}>
                <p className="info-title" onClick={() => clickStep(5)}>
                  <span className="hide">5단계</span> 경감계획
                  <span className="hide">현재 </span>
                </p>
              </li>
              <li className={currentStep === 6 ? 'active' : ''}>
                <p className="info-title" onClick={() => clickStep(6)}>
                  <span className="hide">6단계</span> 경감실행
                  <span className="hide">현재 </span>
                </p>
              </li>
              <li className={currentStep === 7 ? 'active' : ''}>
                <p className="info-title" onClick={() => clickStep(7)}>
                  <span className="hide">7단계</span> 위험평가
                  <span className="hide">현재 </span>
                </p>
              </li>
              <li className={currentStep === 8 ? 'active' : ''}>
                <p className="info-title" onClick={() => clickStep(8)}>
                  <span className="hide">8단계</span> SRC리뷰
                  <span className="hide">현재 </span>
                </p>
              </li>
              <li className={currentStep === 9 ? 'active' : ''}>
                <p className="info-title" onClick={() => clickStep(9)}>
                  <span className="hide">9단계</span> 종결
                  <span className="hide">현재 </span>
                </p>
              </li>
            </ol>
          </div>
          {/*//접수단계 step*/}
        </div>
      </div>
    </>
  );
}

export default ReportViewTop;
