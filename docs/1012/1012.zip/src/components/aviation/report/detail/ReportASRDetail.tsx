function ReportASRDetail({ detailInfo = {} }) {
  const { title } = detailInfo as any;
  return (
    <>
      <div className="detailForm">
        {/* 비행정보*/}
        <div className="editbox report">
          <div className="header-tit">비행정보</div>
          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">출발일자</label>
                      <span className="text-desc-type1"> 2024-08-02 / UTC</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">비행편명</label>
                      <span className="text-desc-type1">KE0787</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">등록 부호</label>
                      <span className="text-desc-type1">HL7783</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">항공기 형식</label>
                      <span className="text-desc-type1">77W</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">출발/도착 공항</label>
                      <span className="text-desc-type1">ICN / FUK</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">Divert</label>
                      <span className="text-desc-type1">
                        INC
                        <div className="ant-row">
                          <div role="label" className="ant-col ant-col-md-2">
                            STD
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            09:45
                          </div>
                          <div role="label" className="ant-col ant-col-md-2">
                            STA
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            19:50
                          </div>
                          <div role="label" className="ant-col ant-col-md-2">
                            ATD
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            09:45
                          </div>
                          <div role="label" className="ant-col ant-col-md-2">
                            ATA
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            19:50
                          </div>
                          <div role="label" className="ant-col ant-col-md-2">
                            Delay
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            0
                          </div>
                        </div>
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">Supply (F/C/Y)</label>
                      <span className="text-desc-type1">0/24/254</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">CHECK_IN (F/C/Y)</label>
                      <span className="text-desc-type1">0/2/0</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">Flight Crew</label>
                      <span className="text-desc-type1">
                        <div className="MemberClass">
                          <div className="flex-e">
                            <span className="ant-tag">PF</span>
                            <span className="InfoBox"></span>
                            <div className="Info">
                              <div className="Name">홍길동 (170****)</div>
                              <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                            </div>
                          </div>
                          <div className="flex-e">
                            <span className="ant-tag">PF</span>
                            <span className="InfoBox"></span>
                            <div className="Info">
                              <div className="Name">홍길동 (170****)</div>
                              <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                            </div>
                          </div>
                        </div>
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* 이벤트*/}
        <div className="editbox report">
          <div className="header-tit">이벤트</div>
          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">이벤트 카테고리</label>
                      <span className="text-desc-type1">{title}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">발생 공항</label>
                      <span className="text-desc-type1">조금</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">검사 유형</label>
                      <span className="text-desc-type1">안전</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">권한의 기반</label>
                      <span className="text-desc-type1">외국의</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">발견</label>
                      <span className="text-desc-type1">77W</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">출발/도착 공항</label>
                      <span className="text-desc-type1">ICN / FUK</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">Divert</label>
                      <span className="text-desc-type1">
                        INC
                        <div className="ant-row">
                          <div role="label" className="ant-col ant-col-md-2">
                            STD
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            09:45
                          </div>
                          <div role="label" className="ant-col ant-col-md-2">
                            STA
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            19:50
                          </div>
                          <div role="label" className="ant-col ant-col-md-2">
                            ATD
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            09:45
                          </div>
                          <div role="label" className="ant-col ant-col-md-2">
                            ATA
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            19:50
                          </div>
                          <div role="label" className="ant-col ant-col-md-2">
                            Delay
                          </div>
                          <div role="data" className="ant-col ant-col-md-2">
                            0
                          </div>
                        </div>
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">Supply (F/C/Y)</label>
                      <span className="text-desc-type1">0/24/254</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">CHECK_IN (F/C/Y)</label>
                      <span className="text-desc-type1">0/2/0</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">Flight Crew</label>
                      <span className="text-desc-type1">
                        <div className="MemberClass">
                          <div className="flex-e">
                            <span className="ant-tag">PF</span>
                            <span className="InfoBox"></span>
                            <div className="Info">
                              <div className="Name">홍길동 (170****)</div>
                              <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                            </div>
                          </div>
                          <div className="flex-e">
                            <span className="ant-tag">PF</span>
                            <span className="InfoBox"></span>
                            <div className="Info">
                              <div className="Name">홍길동 (170****)</div>
                              <div className="Dept">상무대우수석사무장 / (주)대한항공</div>
                            </div>
                          </div>
                        </div>
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 관련자 세부 정보*/}
        <div className="editbox report">
          <div className="header-tit">Person Involved Detail</div>
          <div className="form-table line">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">탑승객</label>
                      <span className="text-desc-type1">
                        <div className="info-box mt5">
                          {/*<p className="h4">탑승객</p>*/}
                          <table className="notice-board">
                            <colgroup>
                              <col width="*" />
                              <col width="10%" />
                              <col width="10%" />
                              <col width="15%" />
                              <col width="15%" />
                              <col width="20%" />
                            </colgroup>
                            <tr>
                              <th>관련자</th>
                              <th>이름</th>
                              <th>성별</th>
                              <th>나이</th>
                              <th>국적</th>
                              <th>좌석번호</th>
                            </tr>
                            <tr>
                              <td className="">가해자</td>
                              <td className="">홍길동</td>
                              <td className="">남성</td>
                              <td className="">10</td>
                              <td className="">한국</td>
                              <td className="">872</td>
                            </tr>
                          </table>
                        </div>
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <div className="box-view-list">
                  <ul className="view-list">
                    <li className="accumlate-list">
                      <label className="t-label">승무원</label>
                      <span className="text-desc-type1">
                        <div className="info-box mt5">
                          {/*<p className="h4">승무원</p>*/}
                          <table className="notice-board">
                            <colgroup>
                              <col width="*" />
                              <col width="20%" />
                              <col width="10%" />
                              <col width="30%" />
                              <col width="10%" />
                            </colgroup>
                            <tr>
                              <th>구분</th>
                              <th>사번</th>
                              <th>이름</th>
                              <th>부서</th>
                              <th>직위</th>
                            </tr>
                            <tr>
                              <td className="">가해자</td>
                              <td className="">900****</td>
                              <td className="">홍홍홍</td>
                              <td className="left">정석비행장운영팀 / 운항훈련원</td>
                              <td className="">SVC매니저</td>
                            </tr>
                          </table>
                        </div>
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* //보고서내용보기 상세*/}
        {/* 버튼*/}
        <div className="contents-btns">
          <button type="button" name="button" className="btn_text text_color_neutral-10 btn_confirm">
            수정
          </button>
        </div>
        {/* //버튼*/}
      </div>
    </>
  );
}

export default ReportASRDetail;
