import { REPORT_TYPE_ASR, REPORT_TYPE_CSR } from '@/config/ReportFormConstant';
import ReportASRDetail from './ReportASRDetail';
import ReportCSRDetail from './ReportCSRDetail';
import ApiService from '@/services/ApiService';
import { useEffect, useState } from 'react';

function ReportDetail({ reportId }) {
  const [reportDetailInfo, setReportDetailInfo] = useState<any>({});
  const [reportTypeCd, setReportTypeCd] = useState<string>('');

  const getReportDetail = async (reportId) => {
    const apiResult = await ApiService.get(`avn/report/my-reports/${reportId}`);
    const reportDetailInfo = apiResult.data || {};
    const { report } = reportDetailInfo || {};
    const { reportTypeCd } = report;
    setReportTypeCd(reportTypeCd);
    setReportDetailInfo(reportDetailInfo);
  };

  useEffect(() => {
    if (reportId) {
      getReportDetail(reportId);
    }
  }, [reportId]);

  let reportDetailComponent = <div className="detailForm">존재하지 않는 보고서 유형입니다.</div>;
  if (reportTypeCd) {
    if (reportTypeCd === REPORT_TYPE_ASR) {
      reportDetailComponent = <ReportASRDetail detailInfo={reportDetailInfo} />;
    } else if (reportTypeCd === REPORT_TYPE_CSR) {
      reportDetailComponent = <ReportCSRDetail detailInfo={reportDetailInfo} />;
    }
  }
  return <>{reportDetailComponent}</>;
}

export default ReportDetail;
