import { useEffect, useState } from 'react';
import AppNavigation from '@/components/common/AppNavigation';
import { useParams } from 'react-router-dom';
import ApiService from '@/services/ApiService';
import AppEditorViewer from '@/components/common/AppEditorViewer';
import AppTextInput from '@/components/common/AppTextInput';
import { Viewer } from '@toast-ui/react-editor';
import AppFileAttach from '@/components/common/AppFileAttach';
import ToastService from '@/services/ToastService';
import ConfirmModal from '@/components/modal/ConfirmModal';
import history from '@/utils/history';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function CentralizedReportDetail() {
  const [detailInfo, setDetailInfo] = useState<any>({});

  //확장 버튼
  const [expanedButtonList, setExpanedButtonList] = useState([]);
  //리포트
  const [reports, setReports] = useState([]);
  //main subject
  const [subject, setSubject] = useState('');
  //confirm popup
  const [isUpdateConfirmModal, setIsUpdateConfirmModal] = useState(false);

  const { id, departureDt, flightNo, regNo, subjectNm } = detailInfo;

  const { detailId } = useParams();

  const cancel = () => {
    history.push('/aviation/centralized-report');
  };

  const goFormPage = () => {
    // TODO : [수정] 버튼 처리
  };

  //수정 확인 팝업 닫기
  const isUpdateConfirmModalClose = () => {
    setIsUpdateConfirmModal(false);
  };

  //버튼 open/hide
  const isOpen = (id, value) => {
    setExpanedButtonList((prevState) => ({
      ...prevState,
      [id]: !value,
    }));
  };

  const update = () => {
    ApiService.put('avn/report/centralized', { id: id, subjectNm: subject }).then((apiResult) => {
      if (apiResult) {
        ToastService.success('저장되었습니다.');
        setIsUpdateConfirmModal(false);
      } else {
        ToastService.error('잠시 후에 다시 시도해주세요.');
        setIsUpdateConfirmModal(false);
      }
    });
  };

  useEffect(() => {
    setReports([]);
    setExpanedButtonList([]);
    setSubject('');

    ApiService.get(`avn/report/centralized/${detailId}`).then((apiResult) => {
      const detailInfo = apiResult.data || {};
      setDetailInfo(detailInfo);

      const reportListData = detailInfo.reportList;

      //id값으로 다시 그룹화
      const groupedData = reportListData.reduce((acc, item) => {
        if (!acc[item.id]) {
          acc[item.id] = [];
        }
        acc[item.id].push(item);
        return acc;
      }, {});

      //화면 보임/숨김
      const expanedButtonData = reportListData.reduce((acc, item) => {
        if (!acc[item.id]) {
          acc[item.id] = true;
        }
        return acc;
      }, {});

      setReports(groupedData);
      setExpanedButtonList(expanedButtonData);
      setSubject(subjectNm);
    });
  }, [subjectNm]);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>Centralized Report</h2>
      </div>
      <div className="editbox">
        <div className="listtable">
          <table className="info-board">
            <colgroup>
              <col width="16%" />
              <col width="15%" />
              <col width="16%" />
              <col width="15%" />
              <col width="16%" />
              <col width="15%" />
            </colgroup>
            <tbody>
              <tr>
                <th>Departure Date</th>
                <td className="tl">{departureDt}</td>
                <th>Flight No.</th>
                <td className="tl">{flightNo}</td>
                <th>Registration No.</th>
                <td className="tl">{regNo}</td>
              </tr>
              <tr>
                <th>Subject</th>
                <td className="tl" colSpan={5}>
                  <AppTextInput
                    value={subject}
                    hiddenClearButton={true}
                    onChange={(value) => {
                      setSubject(value);
                    }}
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        {reports.length == 0
          ? null
          : Object.keys(reports).map((id) => {
              const rows = reports[id];
              const rowSpan = rows.length;
              return (
                <div key={id}>
                  <div className="info-wrap toggle mt20">
                    <dl className={expanedButtonList[id] ? 'tg-item active' : 'tg-item'}>
                      <dt
                        onClick={() => {
                          isOpen(id, expanedButtonList[id]);
                        }}
                      >
                        <button type="button" className="btn-tg">
                          {/* toggle 열어지면 active붙임*/}
                          {rows[0].docNo} <span className={expanedButtonList[id] ? 'active' : ''}></span>
                        </button>
                      </dt>
                      <dd className="tg-conts" style={{ display: expanedButtonList[id] ? '' : 'none' }}>
                        {/* 상세*/}
                        <div className="edit-area">
                          <div className="detailForm">
                            <div className="editbox report">
                              <div className="form-table line">
                                <div className="form-cell wid100">
                                  <div className="form-group wid100">
                                    <div className="box-view-list">
                                      <ul className="view-list">
                                        <li className="accumlate-list">
                                          <label className="t-label">Subject</label>
                                          <span className="text-desc-type1"> {rows[0].subject}</span>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="form-table line">
                                <div className="form-cell wid100">
                                  <div className="form-group wid100">
                                    <div className="box-view-list">
                                      <ul className="view-list">
                                        <li className="accumlate-list">
                                          <label className="t-label">Description</label>
                                          <span className="text-desc-type1">
                                            <AppEditorViewer value={rows[0].descriptionTxtcn} />
                                          </span>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </dd>
                    </dl>
                  </div>

                  <div className="listtable" style={{ display: expanedButtonList[id] ? '' : 'none' }}>
                    <table className="info-board">
                      <colgroup>
                        <col width="16%" />
                        <col width="22%" />
                        <col width="16%" />
                        <col width="15%" />
                        <col width="16%" />
                        <col width="15%" />
                      </colgroup>
                      <thead>
                        <tr>
                          <th>Event Type</th>
                          <th>Hazard</th>
                          <th>Potential Consequence</th>
                          <th>진행상태</th>
                          <th>1차 위험평가</th>
                          <th>2차 위험평가</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rows.map((el, index) => {
                          return (
                            <tr key={index}>
                              {index === 0 ? (
                                <>
                                  <td rowSpan={rowSpan}>{el.eventName}</td>
                                  <td className="tl">{el.lv3Name}</td>
                                  <td className="tl">{el.consequenceKo}</td>
                                  <td className="fix vm">{el.phaseNameKor}</td>
                                  <td>
                                    {/*위험도 컬러CSS level1: 레드, level2: 오렌지 , level3:노랑 , level4:그린*/}
                                    <div className="Safety-table-cell">
                                      <span className={`Safety-tag riskLevel ${el.riskLevel1Color}`}>
                                        {el.riskLevel1}
                                      </span>
                                    </div>
                                  </td>
                                  <td>
                                    <div className="Safety-table-cell">
                                      <span className={`Safety-tag riskLevel ${el.riskLevel2Color}`}>
                                        {el.riskLevel2}
                                      </span>
                                    </div>
                                  </td>
                                </>
                              ) : (
                                <>
                                  <td className="tl">{el.lv3Name}</td>
                                  <td className="tl">{el.consequenceKo}</td>
                                  <td className="fix vm">{el.phaseNameKor}</td>
                                  <td>
                                    {/*위험도 컬러CSS level1: 레드, level2: 오렌지 , level3:노랑 , level4:그린*/}
                                    <div className="Safety-table-cell">
                                      <span className={`Safety-tag riskLevel ${el.riskLevel1Color}`}>
                                        {el.riskLevel1}
                                      </span>
                                    </div>
                                  </td>
                                  <td>
                                    <div className="Safety-table-cell">
                                      <span className={`Safety-tag riskLevel ${el.riskLevel2Color}`}>
                                        {el.riskLevel2}
                                      </span>
                                    </div>
                                  </td>
                                </>
                              )}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}

        <hr className="line dp-n"></hr>
      </div>
      {/* 하단버튼영역 */}
      <div className="contents-btns">
        <button
          type="button"
          name="button"
          className="btn_text text_color_neutral-10 btn_confirm"
          onClick={() => {
            setIsUpdateConfirmModal(true);
          }}
        >
          수정
        </button>
        <button type="button" name="button" className="btn_text btn_list" onClick={cancel}>
          목록
        </button>
      </div>
      <ConfirmModal
        title={'수정하시겠습니까?'}
        body=""
        okLabel="수정"
        cancelLabel="취소"
        isOpen={isUpdateConfirmModal}
        closeModal={() => isUpdateConfirmModalClose()}
        cancel={isUpdateConfirmModalClose}
        ok={update}
      />
    </>
  );
}
export default CentralizedReportDetail;
