import AppTable from '@/components/common/AppTable';
import AppRangeDatePicker from '@/components/common/AppRangeDatePicker';
import AppMaskInput from '@/components/common/AppMaskInput';
import AppTextInput from '@/components/common/AppTextInput';
import AppNavigation from '@/components/common/AppNavigation';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import style from 'react-syntax-highlighter/dist/esm/styles/hljs/a11y-dark';
import { textAlign } from 'html2canvas/dist/types/css/property-descriptors/text-align';
import ApiService from '@/services/ApiService';
import history from '@/utils/history';
import CentralizedReportDocumentModal from '@/components/modal/aviation/CentralizedReportDocumentModal';
import ToastService from '@/services/ToastService';
import ConfirmModal from '@/components/modal/ConfirmModal';

function getDate(cnt) {
  const today = new Date();
  if (cnt > 0) {
    today.setMonth(today.getMonth() - cnt);
  }
  const year = today.getFullYear(); // 년도
  const month = today.getMonth() + 1; // 월
  const date = today.getDate(); // 날짜

  let monthString = '';
  let dateString = '';
  if (month < 10) {
    monthString = '0' + month;
  } else {
    monthString = month.toString();
  }

  if (date < 10) {
    dateString = '0' + date;
  } else {
    dateString = date.toString();
  }
  return year + '-' + monthString + '-' + dateString;
}

const fromDate = getDate(5);
const toDate = getDate(0);

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/report/centralized',
  baseRoutePath: '/aviation/centralized-report',
};

// TODO : 검색 초기값 설정
const initSearchParam = {
  flightNo: '',
  regNo: '',
  subjectNm: '',
  fromDate: fromDate,
  toDate: toDate,
};

/* zustand store 생성 */
const AvnCentralizedGroupListStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  /* TODO : 검색에서 사용할 input 선언 및 초기화 반영 */
  searchParam: {
    flightNo: '',
    regNo: '',
    subjectNm: '',
    fromDate: fromDate,
    toDate: toDate,
  },

  //검색일 rangeDate 값
  rangeDt: [fromDate, toDate],

  //디테일 데이터
  detailInfoList: [],

  detailClickData: [],

  //centralized report id
  groupId: '',

  //detail report id
  detailId: '',
  //detail report Info
  reportInfo: {},

  //centralized report row 클릭 정보 저장
  centralizedRowInfoData: {},
  centralizedRowInfo: (value) => {
    set({ centralizedRowInfoData: value });
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
  },

  clear: () => {
    set({
      ...listBaseState,
      searchParam: { ...initSearchParam },
      rangeDt: [fromDate, toDate],
      detailInfoList: [],
      detailClickData: [],
    });
  },

  getDetailInfo: async (value, eventType) => {
    const apiResult = await ApiService.get(`avn/report/centralized/detail/${value.data.id}`);
    const data = apiResult.data || [];

    //id값으로 다시 그룹화
    const groupedData = data.reduce((acc, item) => {
      if (!acc[item.id]) {
        acc[item.id] = [];
      }
      acc[item.id].push(item);
      return acc;
    }, {});

    //화면 보임/숨김
    const clickListData = data.reduce((acc, item) => {
      if (!acc[item.id]) {
        acc[item.id] = false;
      }
      return acc;
    }, {});

    set({ detailInfoList: groupedData });
    set({ groupId: value.data.id });
    set({ detailClickData: clickListData });
    set({ detailId: '' });
    set({ reportInfo: {} });
    if (eventType == 'click') {
      value.node.setSelected(!value.node.isSelected());
    } else {
      value.node.setSelected(value.node.isSelected());
    }

    // setClickDetail(clickListData);
  },

  //리포트 추가
  saveReport: (saveGroupId, selectedInfo, isSaveReportClose, closeModal) => {
    const { getDetailInfo, centralizedRowInfoData, enterSearch } = get();

    const reportId = selectedInfo.data.id;
    let departureDate = selectedInfo.data.departureAt;
    departureDate = departureDate.replaceAll('-', '');
    const flightNo = selectedInfo.data.flightNo;

    const insertJsonData = { reportId: reportId, departureDt: departureDate, flightNo: flightNo };

    ApiService.post(`avn/report/centralized/detail/${saveGroupId}`, insertJsonData).then((apiResult) => {
      if (apiResult) {
        isSaveReportClose();
        closeModal();
        ToastService.success('추가하였습니다.');
        enterSearch();
        getDetailInfo(centralizedRowInfoData, 'event');
      } else {
        isSaveReportClose();
        closeModal();
        ToastService.error('등록에 실패하였습니다.\n관리자에게 문의해주세요.');
        enterSearch();
        getDetailInfo(centralizedRowInfoData, 'event');
      }
    });
  },

  //버튼 open/hide
  isClick: (id, reportInfo) => {
    const { detailClickData } = get();
    Object.keys(detailClickData).forEach((element) => {
      detailClickData[element] = false;
    });
    detailClickData[id] = true;

    set({ detailClickData: detailClickData });
    set({ detailId: id });
    set({ reportInfo: reportInfo });
  },

  deleteDetailReport: (isDeleteConfirmModalClose) => {
    const { groupId, detailId, getDetailInfo, centralizedRowInfoData, enterSearch } = get();
    console.log(groupId);
    console.log(detailId);
    ApiService.delete(`avn/report/centralized/detail/${groupId}/${detailId}`).then((apiResult) => {
      if (apiResult) {
        ToastService.success('해제하였습니다.');
        isDeleteConfirmModalClose();
        enterSearch();
        getDetailInfo(centralizedRowInfoData, 'event');
      } else {
        ToastService.error('해제에 실패하였습니다.\n관리자에게 문의해주세요.');
        isDeleteConfirmModalClose();
        enterSearch();
        getDetailInfo(centralizedRowInfoData, 'event');
      }
    });
  },
}));

function CentralizedReportList() {
  //group no 커스텀
  const customGroupNo = (props) => {
    return (
      <div className="Safety-table-cell tl">
        <a
          href="javascript:void(0);"
          onDoubleClick={(event) => {
            event.stopPropagation();
            history.push(`centralized-report/${props.data.id}`);
          }}
        >
          {props.value}
        </a>
      </div>
    );
  };

  //lisk Level 커스텀
  const customRiskLevel = (props) => {
    return <span className={`Safety-tag riskLevel ${props.data.riskLevelColor}`}>{props.value}</span>;
  };

  const state = AvnCentralizedGroupListStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      {
        field: 'groupNo',
        headerName: '관리번호',
        headerClass: 'column-box',
        cellStyle: { textAlign: 'center' },
        cellRenderer: customGroupNo,
      },
      { field: 'subjectNm', headerName: 'Subject', width: 500 },
      { field: 'departureDt', headerName: 'Dept Date', cellStyle: { textAlign: 'center' } },
      { field: 'flightNo', headerName: 'Flight No.', cellStyle: { textAlign: 'center' } },
      { field: 'regNo', headerName: 'Reg No.', cellStyle: { textAlign: 'center' } },
      { field: 'riskLevel', headerName: '위험도', cellStyle: { textAlign: 'center' }, cellRenderer: customRiskLevel },
    ])
  );

  //참고문서번호 모달
  const [isReportDocumentOpen, setIsReportDocumentOpen] = useState(false);
  const closeReportDocumentModal = () => {
    setIsReportDocumentOpen(false);
  };

  const [isDeleteConfirmModal, setIsDeleteConfirmModal] = useState(false);
  const isDeleteConfirmModalClose = () => {
    setIsDeleteConfirmModal(false);
  };

  //참고문서번호 모달 끝

  const {
    search,
    enterSearch,
    searchParam,
    list,
    changeSearchInput,
    changeStateProps,
    rangeDt,
    getDetailInfo,
    detailClickData,
    detailInfoList,
    isClick,
    groupId,
    reportInfo,
    detailId,
    saveReport,
    centralizedRowInfo,
    deleteDetailReport,
    clear,
  } = state;
  // TODO : 검색 파라미터 나열
  const { flightNo, regNo, subjectNm } = searchParam;

  // const handleRowDoubleClick = useCallback((selectedInfo) => {
  //   // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
  // }, []);

  const handleRowSingleClick = useCallback((selectedInfo) => {
    // TODO : 한번클릭시 상세 페이지 또는 모달 페이지 오픈
    centralizedRowInfo(selectedInfo);
    getDetailInfo(selectedInfo, 'click');
  }, []);

  useEffect(() => {
    enterSearch();
    return clear;
  }, []);

  return (
    <>
      {/*경로 */}
      <AppNavigation />
      {/*경로 */}
      <div className="conts-title">
        <h2>Centralized Report</h2>
      </div>
      {/*검색영역 */}
      <div className="boxForm det">
        {/*area-detail명 옆에 active  */}
        <div id="" className="area-detail active">
          <div className="form-table">
            <div className="form-cell wid50">
              <AppRangeDatePicker
                label="작성일"
                onChange={(value) => {
                  changeSearchInput('fromDate', value[0]);
                  changeSearchInput('toDate', value[1]);
                  changeStateProps('rangeDt', value);
                }}
                value={rangeDt}
                showNow
                placeholder={['시작일', '종료일']}
              />
            </div>
            <div className="form-cell wid50">
              <div className="form-group va-t ant-input wid100 h4">
                <span className="ant-input-group-addon1">KE</span>
                <div className="ant-input-group-addon1-input wid50">
                  {/*편명 */}
                  <AppMaskInput
                    id="InvestigationReportEditflightNo"
                    mask="9999"
                    name="flightNo"
                    label="비행편명"
                    value={flightNo}
                    onChange={(value) => changeSearchInput('flightNo', value)}
                    hiddenClearButton
                  />
                </div>
              </div>
            </div>
            <div className="form-cell wid50">
              <div className="form-group va-t ant-input wid100 h4">
                <span className="ant-input-group-addon1">HL</span>
                <div className="ant-input-group-addon1-input wid50">
                  {/*등록부호 */}
                  {/*편명 */}
                  <AppMaskInput
                    id="InvestigationReportEditflightNo"
                    mask="9999"
                    name="flightNo"
                    label="등록부호"
                    value={regNo}
                    onChange={(value) => changeSearchInput('regNo', value)}
                    hiddenClearButton
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="form-table">
            <div className="form-cell wid100">
              <div className="form-group wid100">
                <AppSearchInput
                  label={'Subject'}
                  value={subjectNm}
                  onChange={(value) => {
                    changeSearchInput('subjectNm', value);
                  }}
                  search={search}
                />
              </div>
            </div>
            <div className="form-cell wid100">
              {' '}
              <div className="btn-area">
                <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={enterSearch}>
                  조회
                </button>
                <button type="button" name="button" className="btn-sm btn_text btn-darkblue-line" onClick={clear}>
                  초기화
                </button>
              </div>
            </div>
          </div>
        </div>
        {/*__control명 옆에 active  */}
        <button type="button" name="button" className="arrow button _control active">
          <span className="hide">접기</span>
        </button>
      </div>
      {/* //검색영역 */}

      {/*그리드영역 */}
      <div className="">
        <AppTable
          rowData={list}
          columns={columns}
          setColumns={setColumns}
          store={state}
          // handleRowDoubleClick={handleRowDoubleClick}
          handleRowSingleClick={handleRowSingleClick}
          useColumnDynamicSetting
        />
      </div>
      {/*//그리드영역 */}
      <div>
        <div className="table-header">
          <div className="btns-area">
            <button
              name="button"
              className="btn_text btn_confirm text_color_neutral-10"
              onClick={() => {
                if (groupId == null || groupId == '') {
                  ToastService.error('Centralized 보고서를 먼저 선택해주세요');
                  return;
                } else {
                  setIsReportDocumentOpen(true);
                }
              }}
            >
              보고서 추가
            </button>
            <button
              name="button"
              className="btn_text btn_confirm text_color_neutral-10"
              onClick={() => {
                if (groupId == '') {
                  ToastService.error('Centralized Report를 선택해주세요.');
                  return;
                } else if (detailId == '') {
                  ToastService.error('Detail Report를 선택해주세요.');
                  return;
                } else {
                  setIsDeleteConfirmModal(true);
                }
              }}
            >
              보고서 해제
            </button>
          </div>
        </div>
        <div className="tableTop">
          <table className="RiskLevelTable left">
            <caption></caption>
            <colgroup>
              <col width="10%" />
              <col width="25%" />
              <col width="10%" />
              <col width="20%" />
              <col width="15%" />
              <col width="10%" />
              <col width="5%" />
              <col width="5%" />
            </colgroup>
            <thead>
              <tr>
                <th>Doc No.</th>
                <th>Subject</th>
                <th>Event Type</th>
                <th>Hazard</th>
                <th>Potential Consequence</th>
                <th>진행상태</th>
                <th>1차 위험평가</th>
                <th>2차 위험평가</th>
              </tr>
            </thead>
            <tbody>
              {detailInfoList.length == 0
                ? null
                : Object.keys(detailInfoList).map((id) => {
                    const rows = detailInfoList[id];
                    const rowspan = rows.length;
                    return rows.map((row, index) => (
                      <tr
                        key={index}
                        onClick={() => {
                          isClick(id, rows[0]);
                        }}
                        style={
                          detailClickData[id]
                            ? { backgroundColor: '#eef7fe', cursor: 'pointer' }
                            : { backgroundColor: '', cursor: 'pointer' }
                        }
                      >
                        {index === 0 ? (
                          <>
                            <td rowSpan={rowspan}>
                              <a href="javascript:void(0);">{row.docNo}</a>
                            </td>
                            <td rowSpan={rowspan} className="tl">
                              {row.subject}
                            </td>
                            <td rowSpan={rowspan} className="tl">
                              {row.eventName}
                            </td>
                            <td className="tl">{row.lv3Name}</td>
                            <td className="tl">{row.consequenceKo}</td>
                            <td className="tl">{row.phaseNameKor}</td>
                            <td className="">
                              <span className={`Safety-tag riskLevel ${row.riskLevel1Color}`}>{row.riskLevel1}</span>
                            </td>
                            <td className="">
                              <span className={`Safety-tag riskLevel ${row.riskLevel2Color}`}>{row.riskLevel2}</span>
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="tl">{row.lv3Name}</td>
                            <td className="tl">{row.consequenceKo}</td>
                            <td className="tl">{row.phaseNameKor}</td>
                            <td className="">
                              <span className={`Safety-tag riskLevel ${row.riskLevel1Color}`}>{row.riskLevel1}</span>
                            </td>
                            <td className="">
                              <span className={`Safety-tag riskLevel ${row.riskLevel2Color}`}>{row.riskLevel2}</span>
                            </td>
                          </>
                        )}
                      </tr>
                    ));
                  })}
            </tbody>
          </table>
        </div>
      </div>
      <CentralizedReportDocumentModal
        isOpen={isReportDocumentOpen}
        closeModal={closeReportDocumentModal}
        groupId={groupId}
        detailInfoList={detailInfoList}
        saveReport={saveReport}
      />
      <ConfirmModal
        title={`선택한 ${reportInfo.docNo}의 전체 정보를 해제하시겠습니까?`}
        body=""
        okLabel="해제"
        cancelLabel="닫기"
        isOpen={isDeleteConfirmModal}
        closeModal={() => isDeleteConfirmModalClose()}
        cancel={isDeleteConfirmModalClose}
        ok={() => {
          deleteDetailReport(isDeleteConfirmModalClose);
        }}
      />
    </>
  );
}

export default CentralizedReportList;
