import { useEffect } from 'react';
import Modal from 'react-modal';
import { Viewer } from '@toast-ui/react-editor';
import AppFileAttach from '@/components/common/AppFileAttach';

/* TODO : 컴포넌트 이름을 확인해주세요 */
function SafetyActionModal(props) {
  const { isOpen, closeModal, safetyActInfo } = props;

  // TODO : 목록에서 선택한 값을 그대로 이용할지 여부 결정
  // const { detailInfo } = props;

  /* formStore state input 변수 */
  const { id, caId, safetyNo, actionTaken, actionAt, deptCd, empNo, regDttm, regUserId, updDttm, updUserId } =
    safetyActInfo;

  useEffect(() => {
    // TODO : isOpen일 경우에 상세 api 호출 할지 결정
  }, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'alert-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">Safety Action 관리</h3>

        <div className="pop_cont">
          {/*상세 */}
          <div className="editbox">
            <div className="form-table line">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">번호</label>
                        <span className="text-desc-type1">{safetyNo}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
            <div className="form-table line">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">부서</label>
                        <span className="text-desc-type1">{deptCd}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">조치일자</label>
                        <span className="text-desc-type1">{actionAt}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line dp-n"></hr>
            <div className="form-table line">
              <div className="form-cell wid100">
                <div className="form-group wid100">
                  <div className="box-view-list">
                    <ul className="view-list">
                      <li className="accumlate-list">
                        <label className="t-label">조치결과</label>
                        <span className="text-desc-type1">{actionTaken}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <hr className="line"></hr>
          </div>
        </div>
        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            닫기
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>

      {/*style="z-index: 1002; display: block; opacity: 0.5;"*/}
    </Modal>
  );
}
export default SafetyActionModal;
