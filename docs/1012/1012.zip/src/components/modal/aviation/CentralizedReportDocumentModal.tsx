import AppSelect from '@/components/common/AppSelect';
import Modal from 'react-modal';
import AppRangeDatePicker from '@/components/common/AppRangeDatePicker';
import AppTable from '@/components/common/AppTable';
import AppMaskInput from '@/components/common/AppMaskInput';
import { createListSlice, listBaseState } from '@/stores/slice/listSlice';
import { useEffect, useState, useCallback } from 'react';
import CommonUtil from '@/utils/CommonUtil';
import { create } from 'zustand';
import AppSearchInput from '@/components/common/AppSearchInput';
import ConfirmModal from '@/components/modal/ConfirmModal';
import ApiService from '@/services/ApiService';
import AppTreeSelect from '@/components/common/AppTreeSelect';
import history from '@/utils/history';
import ToastService from '@/services/ToastService';

//날짜 생성
function getDate(cnt) {
  const today = new Date();
  if (cnt > 0) {
    today.setMonth(today.getMonth() - cnt);
  }
  const year = today.getFullYear(); // 년도
  const month = today.getMonth() + 1; // 월
  const date = today.getDate(); // 날짜

  let monthString = '';
  let dateString = '';
  if (month < 10) {
    monthString = '0' + month;
  } else {
    monthString = month.toString();
  }

  if (date < 10) {
    dateString = '0' + date;
  } else {
    dateString = date.toString();
  }
  return year + '-' + monthString + '-' + dateString;
}

const fromDate = getDate(5);
const toDate = getDate(0);

const initListData = {
  ...listBaseState,
  listApiPath: 'avn/common/reports',
  baseRoutePath: 'aviation/safety-risk-mgmt/investigation-report/add/edit',
};
const initSearchParam = {
  multipleValue: [],
  dateType: 'submit',
  startDate: fromDate,
  endDate: toDate,
  keyword: '',
  searchInvestigation: true,
  flightNo: '',
  regNo: '',
};
/* zustand store 생성 */
const useReportDocumentModalStore = create<any>((set, get) => ({
  ...createListSlice(set, get),

  ...initListData,

  searchParam: {
    multipleValue: [],
    dateType: 'departure',
    startDate: fromDate,
    endDate: toDate,
    keyword: '',
    searchInvestigation: true,
    flightNo: '',
    regNo: '',
  },

  initSearchInput: () => {
    set({
      searchParam: {
        ...initSearchParam,
      },
    });
    set({
      rangeDt: [fromDate, toDate],
    });
  },

  clear: () => {
    set({ ...listBaseState, searchParam: { ...initSearchParam } });
  },

  //검색일
  rangeDt: [fromDate, toDate],

  saveGroupId: '',
  saveInfoDataList: [],
  selectedId: '',
  selectedInfo: {},

  //화면진입시 해당 값 등록
  saveInfoData: (groupId, saveInfoDataList) => {
    set({ saveGroupId: groupId, saveInfoDataList: saveInfoDataList });
  },

  setSelectedId: (value) => {
    set({ selectedId: value.data.docNo, selectedInfo: value });
  },
}));

function CentralizedReportDocumentModal(props) {
  const { isOpen, closeModal, groupId, detailInfoList, saveReport } = props;

  //선택 버튼 클릭 시 confrim control
  const [isSaveReport, setIsSaveReport] = useState(false);
  const isSaveReportClose = () => {
    setIsSaveReport(false);
  };

  const state = useReportDocumentModalStore();
  const [columns, setColumns] = useState(
    CommonUtil.mergeColumnInfosByLocal([
      { field: 'docNo', headerName: 'Doc No.' },
      { field: 'subject', headerName: 'Subject' },
      { field: 'departureAt', headerName: 'Dept Date' },
      { field: 'flightNo', headerName: 'Flight No.' },
      { field: 'regNo', headerName: 'Reg No.' },
    ])
  );
  const {
    search,
    enterSearch,
    searchParam,
    list,
    changeSearchInput,
    initSearchInput,
    rangeDt,
    changeStateProps,
    saveInfoData,
    selectedId,
    setSelectedId,
    saveInfoDataList,
    saveGroupId,
    selectedInfo,
    clear,
  } = state;
  // TODO : 검색 파라미터 나열
  const { keyword, flightNo, regNo } = searchParam;

  const handleRowSingleClick = useCallback((selectedInfo) => {
    // TODO : 더블클릭시 상세 페이지 또는 모달 페이지 오픈
    selectedInfo.node.setSelected(!selectedInfo.node.isSelected());
    setSelectedId(selectedInfo);
  }, []);

  useEffect(() => {
    //모달close시
    if (!isOpen) {
      initSearchInput();
      // getCondition();
      //모달 open시
    } else {
      enterSearch();
      saveInfoData(groupId, detailInfoList);
    }
    return clear;
  }, [isOpen]);

  return (
    <Modal
      shouldCloseOnOverlayClick={false}
      isOpen={isOpen}
      ariaHideApp={false}
      overlayClassName={'alert-modal-overlay'}
      className={'list-common-modal-content'}
      onRequestClose={() => {
        closeModal();
      }}
    >
      <div className="popup-container">
        <h3 className="pop_title">리포트찾기</h3>
        <div className="pop_full_cont_box">
          <div className="pop_flex_group">
            <div className="pop_cont_form">
              <div className="boxForm">
                <div id="" className="area-detail active">
                  <div className="form-table">
                    <div className="form-cell wid50">
                      <span className="form-group wid100">
                        <AppRangeDatePicker
                          label="출발일자"
                          onChange={(value) => {
                            changeSearchInput('startDate', value[0]);
                            changeSearchInput('endDate', value[1]);
                            changeStateProps('rangeDt', value);
                          }}
                          value={rangeDt}
                          showNow
                          placeholder={['시작일', '종료일']}
                        />
                      </span>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group va-t ant-input wid100 h4">
                        <span className="ant-input-group-addon1">KE</span>
                        <div className="ant-input-group-addon1-input wid50">
                          {/*편명 */}
                          <AppMaskInput
                            id="InvestigationReportEditflightNo"
                            mask="9999"
                            name="flightNo"
                            label="편명"
                            value={flightNo}
                            onChange={(value) => changeSearchInput('flightNo', value)}
                            hiddenClearButton
                          />
                        </div>
                      </div>
                    </div>
                    <div className="form-cell wid50">
                      <div className="form-group va-t ant-input wid100 h4">
                        <span className="ant-input-group-addon1">HL</span>
                        <div className="ant-input-group-addon1-input wid50">
                          {/*등록부호 */}
                          {/*편명 */}
                          <AppMaskInput
                            id="InvestigationReportEditflightNo"
                            mask="9999"
                            name="flightNo"
                            label="등록부호"
                            value={regNo}
                            onChange={(value) => changeSearchInput('regNo', value)}
                            hiddenClearButton
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="form-table">
                    <div className="form-cell wid50">
                      <div className="form-group wid100">
                        <AppSearchInput
                          label="Subject"
                          value={keyword}
                          onChange={(value) => {
                            changeSearchInput('keyword', value);
                          }}
                          search={search}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="btn-area">
                    <button
                      type="button"
                      name="button"
                      className="btn-sm btn_text btn-darkblue-line"
                      onClick={enterSearch}
                    >
                      조회
                    </button>
                    <button
                      type="button"
                      name="button"
                      className="btn-sm btn_text btn-darkblue-line"
                      onClick={() => {
                        initSearchInput();
                      }}
                    >
                      초기화
                    </button>
                  </div>
                </div>

                {/*__control명 옆에 active  */}
                <button type="button" name="button" className="arrow button _control active">
                  <span className="hide">접기</span>
                </button>
              </div>
              {/*그리드영역 */}
              <div>
                <AppTable
                  rowData={list}
                  columns={columns}
                  setColumns={setColumns}
                  store={state}
                  handleRowSingleClick={handleRowSingleClick}
                />
              </div>
              {/*//그리드영역 */}
            </div>
          </div>
        </div>

        <div className="pop_btns">
          <button className="btn_text text_color_neutral-90 btn_close" onClick={closeModal}>
            취소
          </button>
          <button
            className="btn_text text_color_neutral-10 btn_confirm"
            onClick={() => {
              if (selectedId == '') {
                ToastService.error('추가하실 보고서를 선택해주세요.');
              } else {
                setIsSaveReport(true);
              }
            }}
          >
            확인
          </button>
        </div>
        <span className="pop_close" onClick={closeModal}>
          X
        </span>
      </div>
      <ConfirmModal
        title={'추가하시겠습니까?'}
        body=""
        okLabel="확인"
        cancelLabel="취소"
        isOpen={isSaveReport}
        closeModal={() => isSaveReportClose()}
        cancel={isSaveReportClose}
        ok={() => {
          const result = Object.keys(saveInfoDataList).every((id) => {
            const rows = saveInfoDataList[id];
            return selectedId != rows[0].docNo;
          });
          if (result) {
            saveReport(saveGroupId, selectedInfo, isSaveReportClose, closeModal);
          } else {
            ToastService.error('이미 추가된 보고서입니다.');
            isSaveReportClose();
          }
        }}
      />
    </Modal>
  );
}

export default CentralizedReportDocumentModal;
