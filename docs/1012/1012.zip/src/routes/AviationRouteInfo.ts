import AdminSafetyManualDetail from '@/components/aviation/admin/board/AdminSafetyManualDetail';
import AdminSafetyManualEdit from '@/components/aviation/admin/board/AdminSafetyManualEdit';
import AdminSafetyManualList from '@/components/aviation/admin/board/AdminSafetyManualList';
import BannerManageDetail from '@/components/aviation/admin/board/BannerManageDetail';
import BannerManageEdit from '@/components/aviation/admin/board/BannerManageEdit';
import BannerManageList from '@/components/aviation/admin/board/BannerManageList';
import NoticesDetail from '@/components/aviation/admin/board/NoticesDetail';
import NoticesEdit from '@/components/aviation/admin/board/NoticesEdit';
import NoticesList from '@/components/aviation/admin/board/NoticesList';
import SafetyBoardDetail from '@/components/aviation/admin/board/SafetyBoardDetail';
import SafetyBoardEdit from '@/components/aviation/admin/board/SafetyBoardEdit';
import SafetyBoardList from '@/components/aviation/admin/board/SafetyBoardList';
import SafetyDetail from '@/components/aviation/admin/board/SafetyDetail';
import SafetyEdit from '@/components/aviation/admin/board/SafetyEdit';
import SafetyList from '@/components/aviation/admin/board/SafetyList';
import SPIBoardDetail from '@/components/aviation/admin/board/SPIBoardDetail';
import SPIBoardEdit from '@/components/aviation/admin/board/SPIBoardEdit';
import SPIBoardList from '@/components/aviation/admin/board/SPIBoardList';
import MailFormManageDetail from '@/components/aviation/admin/mailform/MailFormManageDetail';
import MailFormManageEdit from '@/components/aviation/admin/mailform/MailFormManageEdit';
import MailFormManageList from '@/components/aviation/admin/mailform/MailFormManageList';
import riskMatrixList from '@/components/aviation/admin/riskMatrix/AdminRiskMatrix';
import riskMatrixDetail from '@/components/aviation/admin/riskMatrix/AdminRiskMatrixDetail';
import SurveyManageDetail from '@/components/aviation/admin/surveyManage/SurveyManageDetail';
import SurveyManageEdit from '@/components/aviation/admin/surveyManage/SurveyManageEdit';
import SurveyManageList from '@/components/aviation/admin/surveyManage/SurveyManageList';
import topRisk from '@/components/aviation/admin/topRisk/AdminTopRisk';
import SafetyCommitteeDetail from '@/components/aviation/policy/SafetyCommitteeDetail';
import SafetyCommitteeEdit from '@/components/aviation/policy/SafetyCommitteeEdit';
import SafetyCommitteeList from '@/components/aviation/policy/SafetyCommitteeList';
import SafetyManual from '@/components/aviation/policy/SafetyManual';
import SafetyManualDetail from '@/components/aviation/policy/SafetyManualDetail';
import SafetyPolicy from '@/components/aviation/policy/SafetyPolicy';
import SafetyInvestigationReport from '@/components/aviation/safetyinvestigation/InvestigationReport';
import SafetyInvestigationReportDetail from '@/components/aviation/safetyinvestigation/InvestigationReportDetail';
import SafetyInvestigationReportEdit from '@/components/aviation/safetyinvestigation/InvestigationReportEdit';
import SafetyInvestigationReportMitigationDetail from '@/components/aviation/safetyinvestigation/InvestigationReportMitigationDetail';
import SafetyInvestigationReportMitigationEdit from '@/components/aviation/safetyinvestigation/InvestigationReportMitigationEdit';
import SafetyInvestigationReportList from '@/components/aviation/safetyinvestigation/InvestigationReportList';
import GroundInvestigationReportList from '@/components/aviation/groundinvestigation/InvestigationReport';

import SafetyCommunicationNewsletterDetail from '@/components/aviation/sftm/safetycommunication/SafetyCommunicationNewsletterDetail';
import SafetyCommunicationNewsletterList from '@/components/aviation/sftm/safetycommunication/SafetyCommunicationNewsletterList';
import SafetyProgramExcellenceDetail from '@/components/aviation/sftm/safetyprogram/SafetyProgramExcellenceDetail';
import SafetyProgramExcellenceList from '@/components/aviation/sftm/safetyprogram/SafetyProgramExcellenceList';
import SafetyProgramSafetyDayDetail from '@/components/aviation/sftm/safetyprogram/SafetyProgramSafetyDayDetail';
import SafetyProgramSafetyDayList from '@/components/aviation/sftm/safetyprogram/SafetyProgramSafetyDayList';
import SafetyProgramWorkShopDetail from '@/components/aviation/sftm/safetyprogram/SafetyProgramWorkShopDetail';
import SafetyProgramWorkShopList from '@/components/aviation/sftm/safetyprogram/SafetyProgramWorkShopList';
import SafetySurveyDetail from '@/components/aviation/sftm/safetysurvey/SafetySurveyDetail';
import SafetySurveyList from '@/components/aviation/sftm/safetysurvey/SafetySurveyList';
import SftmNoticesDetail from '@/components/aviation/sftm/sftmnotice/SftmNoticesDetail';
import SftmNoticesList from '@/components/aviation/sftm/sftmnotice/SftmNoticesList';
import MyReportList from '@/components/aviation/report/MyReportList';
import ReportList from '@/components/aviation/report/ReportList';
import EventTypeDetail from '@/components/aviation/admin/criteriaManage/EventTypeDetail';
import EventTypeEdit from '@/components/aviation/admin/criteriaManage/EventTypeEdit';
import EventTypeList from '@/components/aviation/admin/criteriaManage/EventTypeList';
import PotentialConDetail from '@/components/aviation/admin/criteriaManage/PotentialConDetail';
import PotentialConEdit from '@/components/aviation/admin/criteriaManage/PotentialConEdit';
import PotentialConList from '@/components/aviation/admin/criteriaManage/PotentialConList';
import TaxonomyDetail from '@/components/aviation/admin/criteriaManage/TaxonomyDetail';
import TaxonomyEdit from '@/components/aviation/admin/criteriaManage/TaxonomyEdit';
import TaxonomyList from '@/components/aviation/admin/criteriaManage/TaxonomyList';
import EquipCdMgmtDetail from '@/components/aviation/admin/rsrManage/EquipCdMgmtDetail';
import EquipCdMgmtEdit from '@/components/aviation/admin/rsrManage/EquipCdMgmtEdit';
import EquipCdMgmtList from '@/components/aviation/admin/rsrManage/EquipCdMgmtList';
import EquipChkHistList from '@/components/aviation/admin/rsrManage/EquipChkHistList';
import EducationDetail from '@/components/aviation/admin/trainingManage/EducationsDetail';
import EducationEdit from '@/components/aviation/admin/trainingManage/EducationsEdit';
import EducationList from '@/components/aviation/admin/trainingManage/EducationsList';
import InstructorHistList from '@/components/aviation/admin/instructorManage/InstructorHistList';
import InstructorHistEdit from '@/components/aviation/admin/instructorManage/InstructorHistEdit';
import InstructorHistDetail from '@/components/aviation/admin/instructorManage/InstructorHistDetail';
import CentralizedReportList from '@/components/aviation/report/CentralizedReportList';
import CentralizedReportDetail from '@/components/aviation/report/CentralizedReportDetail';
import ReportView from '@/components/aviation/report/view/ReportView';
const AviationRouteInfo: any = {};

AviationRouteInfo.list = [
  // 관리자 > 게시판 관리 > 안전정책 목록
  {
    Component: SafetyList,
    path: 'board-manage/safety-policy',
  },
  // 관리자 > 게시판 관리 > 안전정책 신규
  {
    Component: SafetyEdit,
    path: 'board-manage/safety-policy/add/edit',
  },
  // 관리자 > 게시판 관리 > 안전정책 상세
  {
    Component: SafetyDetail,
    path: 'board-manage/safety-policy/:detailId',
  },
  // 관리자 > 게시판 관리 > 안전정책 수정
  {
    Component: SafetyEdit,
    path: 'board-manage/safety-policy/:detailId/edit',
  },
  // 관리자 > 게시판 관리 > 안전 메뉴얼
  {
    Component: AdminSafetyManualList,
    path: 'board-manage/safety-manual',
  },
  // 관리자 > 게시판 관리 > 안전 매뉴얼 신규
  {
    Component: AdminSafetyManualEdit,
    path: 'board-manage/safety-manual/add/edit',
  },
  // 관리자 > 게시판 관리 > 안전정책 상세
  {
    Component: AdminSafetyManualDetail,
    path: 'board-manage/safety-manual/:detailId',
  },
  // 관리자 > 게시판 관리 > 안전 매뉴얼 수정
  {
    Component: AdminSafetyManualEdit,
    path: 'board-manage/safety-manual/:detailId/edit',
  },
  // 안전정책 > 안전정책
  {
    Component: SafetyPolicy,
    path: 'policy/safety-policy',
  },
  // 안전정책 > 안전 매뉴얼
  {
    Component: SafetyManual,
    path: 'policy/safety-manual',
  },
  // 안전정책 > 안전 매뉴얼 상세
  {
    Component: SafetyManualDetail,
    path: 'policy/safety-manual/:detailId',
  },
  // 안전정책 > 안전회의체
  {
    Component: SafetyCommitteeList,
    path: 'policy/safety-committee',
  },
  // 안전정책 > 안전회의체 신규
  {
    Component: SafetyCommitteeEdit,
    path: 'policy/safety-committee/add/edit',
  },
  // 안전정책 > 안전회의체 상세
  {
    Component: SafetyCommitteeDetail,
    path: 'policy/safety-committee/:detailId',
  },
  // 안전정책 > 안전회의체 수정
  {
    Component: SafetyCommitteeEdit,
    path: 'policy/safety-committee/:detailId/edit',
  },

  // 관리자 > risk Matrix 목록
  {
    Component: riskMatrixList,
    path: 'risk-matrix',
  },
  // 관리자 > risk Matrix 수정
  {
    Component: riskMatrixDetail,
    path: 'risk-matrix/edit',
  },
  // 관리자 > Top Risk 관리
  {
    Component: topRisk,
    path: 'top-risk',
  },
  // 관리자 > 게시판관리 > 배너관리 목록
  {
    Component: BannerManageList,
    path: 'board-manage/banner-manage',
  },
  // 관리자 > 게시판관리 > 배너관리 신규
  {
    Component: BannerManageEdit,
    path: 'board-manage/banner-manage/add/edit',
  },
  // 관리자 > 게시판관리 > 배너관리 상세
  {
    Component: BannerManageDetail,
    path: 'board-manage/banner-manage/:detailId',
  },
  // 관리자 > 게시판관리 > 배너관리 수정
  {
    Component: BannerManageEdit,
    path: 'board-manage/banner-manage/:detailId/edit',
  },
  // 관리자 > 메일양식관리 목록
  {
    Component: MailFormManageList,
    path: 'mailFormManage/mail-form-manage',
  },
  // 관리자 > 메일양식관리 신규
  {
    Component: MailFormManageEdit,
    path: 'mailFormManage/mail-form-manage/add/edit',
  },
  // 관리자 > 메일양식관리 상세
  {
    Component: MailFormManageDetail,
    path: 'mailFormManage/mail-form-manage/:detailId',
  },
  // 관리자 > 메일양식관리 수정
  {
    Component: MailFormManageEdit,
    path: 'mailFormManage/mail-form-manage/:detailId/edit',
  },
  // 관리자 > 안전문화설문관리 목록
  {
    Component: SurveyManageList,
    path: 'surveyManage/survey',
  },
  // 관리자 > 안전문화설문관리 신규
  {
    Component: SurveyManageEdit,
    path: 'surveyManage/survey/add/edit',
  },
  // 관리자 > 안전문화설문관리 상세
  {
    Component: SurveyManageDetail,
    path: 'surveyManage/survey/:detailId',
  },
  // 관리자 > 안전문화설문관리 수정
  {
    Component: SurveyManageEdit,
    path: 'surveyManage/survey/:detailId/edit',
  },
  // 안전위험관리 > 안전조사 > 조사보고서
  {
    Component: SafetyInvestigationReport,
    path: 'safety-risk-mgmt/investigation-report',
  },
  // 안전위험관리 > 안전조사 > 조사보고서 신규
  {
    Component: SafetyInvestigationReportEdit,
    path: 'safety-risk-mgmt/investigation-report/add/edit',
  },
  // 안전위험관리 > 안전조사 > 조사보고서 상세
  {
    Component: SafetyInvestigationReportDetail,
    path: 'safety-risk-mgmt/investigation-report/:detailId',
  },
  // 안전위험관리 > 안전조사 > 조사보고서 수정
  {
    Component: SafetyInvestigationReportEdit,
    path: 'safety-risk-mgmt/investigation-report/:detailId/edit',
  },
  // 안전위험관리 > 안전조사 > 조사보고서(경감조치) 상세
  {
    Component: SafetyInvestigationReportMitigationDetail,
    path: 'safety-risk-mgmt/investigation-report-mitigation/:detailId',
  },
  // 안전위험관리 > 안전조사 > 조사보고서(경감조치) 수정
  {
    Component: SafetyInvestigationReportMitigationEdit,
    path: 'safety-risk-mgmt/investigation-report-mitigation/:detailId/edit',
  },

  // 안전위험관리 > 안전조사 > ReportList
  {
    Component: SafetyInvestigationReportList,
    path: 'safety-risk-mgmt/investigation-reportlist',
  },
  // 안전위험관리 > 지상조사 > 조사보고서 목록
  {
    Component: GroundInvestigationReportList,
    path: 'safety-risk-mgmt/ground-investigation-report',
  },

  // 안전증진 > 안전문화설문 목록
  {
    Component: SafetySurveyList,
    path: 'sftm/safety-survey',
  },
  // 안전증진 > 안전문화설문 상세
  {
    Component: SafetySurveyDetail,
    path: 'sftm/safety-survey/:detailId',
  },
  // 관리자 > 게시판 관리 > Safety게시판 목록
  {
    Component: SafetyBoardList,
    path: 'board-manage/safety-board',
  },
  // 관리자 > 게시판 관리 > Safety게시판 신규
  {
    Component: SafetyBoardEdit,
    path: 'board-manage/safety-board/add/edit',
  },
  // 관리자 > 게시판 관리 > Safety게시판 상세
  {
    Component: SafetyBoardDetail,
    path: 'board-manage/safety-board/:detailId',
  },
  // 관리자 > 게시판 관리 > Safety게시판 수정
  {
    Component: SafetyBoardEdit,
    path: 'board-manage/safety-board/:detailId/edit',
  },
  // 안전증진 > Safety Program > Excellence 목록
  {
    Component: SafetyProgramExcellenceList,
    path: 'sftm/excellence',
  },
  // 안전증진 > Safety Program > Excellence 상세
  {
    Component: SafetyProgramExcellenceDetail,
    path: 'sftm/excellence/:detailId',
  },
  // 안전증진 > Safety Program > WorkShop 목록
  {
    Component: SafetyProgramWorkShopList,
    path: 'sftm/workshop',
  },
  // 안전증진 > Safety Program > WorkShop 상세
  {
    Component: SafetyProgramWorkShopDetail,
    path: 'sftm/workshop/:detailId',
  },
  // 안전증진 > Safety Program > Safety Day 목록
  {
    Component: SafetyProgramSafetyDayList,
    path: 'sftm/safetyday',
  },
  // 안전증진 > Safety Program > Safety Day 상세
  {
    Component: SafetyProgramSafetyDayDetail,
    path: 'sftm/safetyday/:detailId',
  },
  // 안전증진 > Safety Communication > Newsletter 목록
  {
    Component: SafetyCommunicationNewsletterList,
    path: 'sftm/newsletter',
  },
  // 안전증진 > Safety Communication > Newsletter 상세
  {
    Component: SafetyCommunicationNewsletterDetail,
    path: 'sftm/newsletter/:detailId',
  },
  // 안전증진 > Safety Communication > 안전공지 목록
  {
    Component: SftmNoticesList,
    path: 'sftm/safetynotice',
  },
  // 안전증진 > Safety Communication > 안전공지 상세
  {
    Component: SftmNoticesDetail,
    path: 'sftm/safetynotice/:detailId',
  },

  // 관리자 > 게시판 관리 > SPI게시판 목록
  {
    Component: SPIBoardList,
    path: 'board-manage/spi-board',
  },
  // 관리자 > 게시판 관리 > SPI게시판 신규
  {
    Component: SPIBoardEdit,
    path: 'board-manage/spi-board/add/edit',
  },
  // 관리자 > 게시판 관리 > SPI게시판 상세
  {
    Component: SPIBoardDetail,
    path: 'board-manage/spi-board/:detailId',
  },
  // 관리자 > 게시판 관리 > SPI게시판 수정
  {
    Component: SPIBoardEdit,
    path: 'board-manage/spi-board/:detailId/edit',
  },

  // 관리자 > 게시판 관리 > 공지사항 목록
  {
    Component: NoticesList,
    path: 'board-manage/notices',
  },
  // 관리자 > 게시판 관리 > 공지사항 신규
  {
    Component: NoticesEdit,
    path: 'board-manage/notices/add/edit',
  },
  // 관리자 > 게시판 관리 > 공지사항 상세
  {
    Component: NoticesDetail,
    path: 'board-manage/notices/:detailId',
  },
  // 관리자 > 게시판 관리 > 공지사항 수정
  {
    Component: NoticesEdit,
    path: 'board-manage/notices/:detailId/edit',
  },
  // 안전보고서 > My Report
  {
    Component: MyReportList,
    path: 'report/my-report',
  },
  // 안전보고서 > Report List
  {
    Component: ReportList,
    path: 'reportList',
  },

  // 관리자 > Hazard관리 > consequence 관리
  {
    Component: PotentialConList,
    path: 'criteriaManage/potential-consequence',
  },
  // 관리자 > Hazard관리 > consequence 신규
  {
    Component: PotentialConEdit,
    path: 'criteriaManage/potential-consequence/add/edit',
  },
  // 관리자 > Hazard관리 > consequence 상세
  {
    Component: PotentialConDetail,
    path: 'criteriaManage/potential-consequence/:detailId',
  },
  // 관리자 > Hazard관리 > consequence 상세
  {
    Component: PotentialConEdit,
    path: 'criteriaManage/potential-consequence/:detailId/edit',
  },
  //관리자 > Hazard관리 > Taxonomy 목록
  {
    Component: TaxonomyList,
    path: 'criteriaManage/taxonomy',
  },
  // 관리자 > Hazard관리 > Taxonomy 신규
  {
    Component: TaxonomyEdit,
    path: 'criteriaManage/taxonomy/add/edit',
  },
  // 관리자 > Hazard관리 > Taxonomy 상세
  {
    Component: TaxonomyDetail,
    path: 'criteriaManage/taxonomy/:detailId',
  },
  // 관리자 > Hazard관리 > Taxonomy 수정
  {
    Component: TaxonomyEdit,
    path: 'criteriaManage/taxonomy/:detailId/edit',
  },
  // 관리자 > Event Type 관리 목록
  {
    Component: EventTypeList,
    path: 'criteriaManage/event-types',
  },
  // 관리자 > Event Type 관리 신규
  {
    Component: EventTypeEdit,
    path: 'criteriaManage/event-types/add/edit',
  },
  // 관리자 > Event Type 관리 상세
  {
    Component: EventTypeDetail,
    path: 'criteriaManage/event-types/:detailId',
  },
  // 관리자 > Event Type 관리 수정
  {
    Component: EventTypeEdit,
    path: 'criteriaManage/event-types/:detailId/edit',
  },

  // 관리자 > 지상관리 > 장비코드관리 목록
  {
    Component: EquipCdMgmtList,
    path: 'rsrManage/EquipCodeMgmt',
  },
  // 관리자 > 지상관리 > 장비코드관리 신규
  {
    Component: EquipCdMgmtEdit,
    path: 'rsrManage/EquipCodeMgmt/add/edit',
  },
  // 관리자 > 지상관리 > 장비코드관리 상세
  {
    Component: EquipCdMgmtDetail,
    path: 'rsrManage/EquipCodeMgmt/:detailId',
  },
  // 관리자 > 지상관리 > 장비코드관리 수정
  {
    Component: EquipCdMgmtEdit,
    path: 'rsrManage/EquipCodeMgmt/:detailId/edit',
  },

  // 관리자 > 지상관리 > 장비점검관리 목록
  {
    Component: EquipChkHistList,
    path: 'rsrManage/EquipChkHist',
  },

  // 관리자 > SMS교육 > 교육관리 목록
  {
    Component: EducationList,
    path: 'trainingManage/Educations',
  },
  // 관리자 > SMS교육 > 교육관리  신규
  {
    Component: EducationEdit,
    path: 'trainingManage/Educations/add/edit',
  },
  // 관리자 > SMS교육 > 교육관리  상세
  {
    Component: EducationDetail,
    path: 'trainingManage/Educations/:detailId',
  },
  // 관리자 > SMS교육 > 교육관리  수정
  {
    Component: EducationEdit,
    path: 'trainingManage/Educations/:detailId/edit',
  },

  // 관리자 > SMS교육 > 강사이력관리 목록
  {
    Component: InstructorHistList,
    path: 'instructorsManage/instructors',
  },
  // 관리자 > SMS교육 > 강사이력관리  신규
  {
    Component: InstructorHistEdit,
    path: 'instructorsManage/instructors/add/edit',
  },
  // 관리자 > SMS교육 > 강사이력관리  상세
  {
    Component: InstructorHistDetail,
    path: 'instructorsManage/instructors/:detailId',
  },
  // 관리자 > SMS교육 > 강사이력관리  수정
  {
    Component: InstructorHistEdit,
    path: 'instructorsManage/instructors/:detailId/edit',
  },
  // 안전보고서 > Centralized Report
  {
    Component: CentralizedReportList,
    path: 'centralized-report',
  },
  // 안전보고서 > Centralized Report 상세
  {
    Component: CentralizedReportDetail,
    path: 'centralized-report/:detailId',
  },
  {
    Component: ReportView,
    path: 'reportList/:reportId',
  },
  {
    Component: ReportView,
    path: 'reportList/:reportId/:hazardId',
  },
];

export default AviationRouteInfo;
